# 小组进度与验收记录

更新：2026-11-14。本页以有证据的结果为准；机器摘要为[team-progress.json](../../configs/research/team-progress.json)。本机报告目录不等于已远程发布的数据或权重。GitHub发布状态由实际远端提交确认，不由本页预先声明。

## 当前已经验收的范围

- **81项CPU基础测试通过，Ruff通过**。范围：统一letterbox与逆变换、米制相机/深度、几何参数资格、静态GLB解析、V/A/ownership/部件合同、可见部件安全导出。
- 已有源文件：`workers/tree_models/metric_camera.py`、`deployment_preprocess.py`、`synthetic_geometry.py`、`metric_dataset_contract.py`、`visible_tree_parts.py`；入口：`scripts/audit_metric_tree_assets.py`、`scripts/export_visible_tree_parts.py`。
- 已审计一棵fig 1830。指定虚拟树高9m，冠幅顶点包络约9.85×9.54m；主干未核验，DBH不可用；bark有1118条边界边/未焊接接缝，木质体积不可用。没有修复源资产。
- 生产要求已记录在`configs/research/metric-tree-dataset-2026-11-14.json`，完整定义在[米制数据与模型计划](../metric-tree-dataset-and-model-plan-2026-11-14.md)。

本机证据为`reports/metric-dataset-foundation-2026-11-14/implementation-summary.json`、`unit-tests.xml`、`asset-1830-audit.json`和`resource-preflight.json`。前述验证**不代表**已生成合格新数据集、已训练新权重或已提升模型精度。仓库发布时应另外保留小型、可公开的证据摘要和hash；不要假定被Git忽略的报告会自动上传。

## 仍待验收的工作

| 工作包 | 当前可核验状态 | 下一项具体交付 | 验收条件 |
| --- | --- | --- | --- |
| A 资产资格 | 一棵fig静态核查完成；尚未有该资产的合格DBH/材积 | 少量候选的语义/尺度/木质拓扑清单，必要时修副本 | 数值来自最终渲染几何；不可用理由明确 |
| B 场景与遮挡 | 有paired-v6可靠标签机制可复用；新5%–25%主批尚未验收 | clear/contact/轻中遮挡成组的小批场景 | 大主树完整入镜，实际树间隐藏率通过，前后方向均有 |
| C 部件与深度 | CPU转换/部件工具通过；完整渲染输出尚未验收 | 同场景前端part-ID、Position/深度与相机元数据 | 透明覆盖一致、保留自身遮挡、米制反投影通过 |
| D 审计与读取 | 合同和坐标工具通过；历史入口未全部迁移 | 生成产物审计、所有角色来源清单与统一loader接入 | 逐图、去重、分组、任务级准入记录完整 |
| E 模型与训练 | 模型已有相关头和历史训练；当前组合效果未重新验收 | 固定结构/权重/预处理后，逐项受控验证 | 召回与污染同时过门槛，部件不被空标签分数掩盖 |

表中状态表示本页最后核验到的**验收结果**。其他成员正在工作的实现可在PR中更新为in_progress；没有验收证据前不改成accepted，不覆盖原有失败记录。

## 保留已有研究结果与失败证据

- 当前检查到的本地HEAD为`b11d067`，提交日期为2026-09-28。它保留了边界学习、截断边界宽度推断及平行遮挡压力失败；文档为[boundary-learning-pilot-v1](../research/boundary-learning-pilot-v1.md)与[censored-boundary-measurement](../research/censored-boundary-measurement.md)。这条研究线不因本次数据工程被删除，也不能把其小型2D试验当新米制森林数据集。
- 最新已核查的SAM数据/训练产物主要来自11月9–10日。focused60有效RGB数量、坐标和部件标签有问题，focused3D60主目标隐藏率全0；详见[11月14日现状核查](../project-status-2026-11-14.md)。它们保留历史复现用途，不能自动作为新正式训练集。
- ownership在小型合成验证有局部收益，但跨来源开发检查未通过保召回门槛，尚未晋级默认模型。相关[记录](../query-ownership-development-2026-11-08.md)仍有效，不能只摘取污染下降宣称解决粘连。
- 模型已有stem/crown输出，但历史GT和组合流程不足以证明可靠；amodal、visibility和curve均有历史训练，不等于已经证明有效。

## 运行资源与GPU

2026-11-14 11:33:57 UTC的历史预检：可用RAM约1.75GiB，低于现有CPU守卫3GiB；本轮基础工具验证未运行Blender、Torch、GPU或模型训练。该历史值**不是当前值**，也不是永久禁止GPU的结论。

GPU首批渲染/训练需实际检查主机RAM、显存、温度、并发任务与已知稳定性，限制单进程、小批量并保存结果。不能把“有空闲显存”当成“不需要主机内存”，也不通过修改驱动/TDR/电源或重启绕过故障。满足条件后使用GPU做有界试跑；资源不满足时仍可推进静态资产审计、生成器开发和CPU fixture。

## 追加日志

### 2026-11-15：可运行资格入口与发布准备

- 新增 `scripts/qualify_metric_scene.py`：读取 scene JSON 与原生标签NPZ，检查V/A、归属、部件、米制深度及参数声明；输出目录拒绝覆盖，记录输入和源码hash。通过合同仍不自动允许训练。
- 基础工具加资格CLI共96项CPU测试通过；未启动新的渲染、模型训练，也没有新精度提升结论。
- 新增dataset-qualification GitHub Actions，在每次push/PR检查上述入口，并在运行摘要中显示当前工作包进度。工作区不会在无人审核时自动提交或上传。
- 补齐Pillow依赖，排除本地照片、tools资产和临时状态。54个本地模型/HDRI资产登记到 `configs/research/local-asset-inventory.json`；未核验转载许可，不声称已提供可下载资产。
- 小型核验证据已复制至本目录 `evidence/`；其时间和81项历史测试范围保留原样，96项为后续新增入口验证。
- GitHub账户已连接，但尚待私有仓库创建确认；没有假定网址已经可访问。
- `configs/partial-label-drafts-2026-10-12.json`是过期草稿，不进入当前发布/训练入口；20260411继续仅供开发参考。

下一步：将生成器实际导出的同坐标场景接入资格CLI。树间遮挡使用 `--occlusion-scope tree`；只有灌木/杆件遮挡不能通过树间5%–25%门槛。完整米制准入默认严格；缺参数只能明确使用分割合同模式，不能改称完整物理真值。

### 2026-11-14：建立协作交接

- 整理四项数据要求、双准入规则、五个可并行工作包、依赖和验收条件。
- 将81项测试明确限定为基础工具验证；新数据集生成、正式训练和真实效果仍分别记录。
- 未在本条日志声明GitHub已上传、后台实时推送已启用、成员已接单或新渲染已成功；这些需要实际远端/运行证据。

后续记录格式：

```text
日期/时间：
工作包与分支/提交/PR：
本次改动与输入版本：
实际产物位置、清单/hash：
验证命令与结果：
未通过项/资源限制/结论边界：
下一项具体交付：
```

每个可验收交付与进度修改放入同一提交/PR。短时只更新真实状态；不要用没有依据的完成百分比代替已验收场景数、参数资格数或实验结果。

### 2026-11-15：29棵fig源资产池静态审计

逐个静态读取29个GLB，0个解析失败；29个bark均被保守拓扑检查标记为开放表面或未焊接接缝。完整摘要在evidence/fig-pool-audit-2026-11-15.json。没有修改资产，也没有声称UV接缝一定等于实际几何孔洞；需要在副本上焊接/闭合资格核验。主干语义、自交和物理尺度尚未验证，DBH/材积不准入。分割资产资格与完整林木参数资格继续分开。

### 2026-11-15：私有仓库首批资料已发布

已在Edge网页核验 https://github.com/SliverBronya/TreeWeaver 为Private。远端提交5f487fc46c74fe5ec7bea22f9311fd626e53a757包含完整637文件源码ZIP（源提交7ef237a）、START_HERE.md、DATASET_REQUIREMENTS.md、PROGRESS.md。目录式代码同步、Actions和后台自动推送未启用；连接工具仓库授权仍未建立。远端进度文件为提交时快照，发布回执保存在本机reports/github-handoff-2026-11-15/publication-receipt.json。
