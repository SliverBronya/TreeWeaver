"""Render existing fig assets with Cycles CUDA only; never fall back to CPU."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import generate_fig_500 as gen  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1 :])
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    prefs = bpy.context.preferences.addons["cycles"].preferences
    prefs.compute_device_type = "CUDA"
    devices = prefs.get_devices_for_type("CUDA")
    cuda = [device for device in devices if device.type == "CUDA"]
    if not cuda:
        raise RuntimeError("No CUDA device; refusing CPU fallback")
    selected = cuda[0]
    for device in prefs.devices:
        device.use = device == selected
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 64
    scene.cycles.use_denoising = False
    scene.cycles.max_bounces = 6
    scene.cycles.transparent_max_bounces = 16
    scene.render.resolution_x = 1024
    scene.render.resolution_y = 768
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1
    scene.view_settings.view_transform = "AgX"
    gen.OUT = out
    gen.PAIRED = True
    gen.RES_X, gen.RES_Y = 1024, 768
    gen.MASK_X, gen.MASK_Y = 1024, 768
    gen.HEIGHT = 9
    config = {
        "engine": "CYCLES",
        "device": "GPU",
        "backend": "CUDA",
        "selected_gpu": selected.name,
        "cpu_device_enabled": False,
        "resolution": [1024, 768],
        "beauty_samples": 64,
        "qualification_only": True,
        "training_allowed": False,
        "physical_parameters_qualified": False,
    }
    (out / "gpu-config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    print("CUDA_SELECTED " + selected.name, flush=True)
    names = ["realistic_hd_common_fig_tree_1830.glb", "realistic_hd_common_fig_tree_430.glb"]
    trees = [gen.load_tree(gen.ROOT / name) for name in names]
    target, neighbour = trees
    width = gen.bbox(target)[1] - gen.bbox(target)[0]
    neighbour.location.x += width * 0.70
    neighbour.location.y -= 1.7
    for tree in trees:
        tree.hide_render = False
    ground = gen.ground()
    for node in ground.data.materials[0].node_tree.nodes:
        if node.bl_idname == "ShaderNodeMapping":
            node.inputs["Scale"].default_value = (600, 600, 600)
    gen.world()
    bpy.ops.object.light_add(type="SUN", location=(0, -8, 15))
    bpy.context.object.data.energy = 2.0
    camera = gen.camera_for(0, width, 45, 1.7, object_height=9)
    framing = gen.fit_ground_camera_bounds(camera, [target], margin=0.045)
    # The 3D bbox contains large empty corners around a broad crown. Move the
    # observer closer, then qualify the actual rendered amodal support below.
    camera.location.y *= 0.82
    camera.rotation_euler = (
        (Vector((0, 0, 4.5)) - camera.location).to_track_quat("-Z", "Y").to_euler()
    )
    framing = {"initial_bbox_fit": framing, "observer_distance_multiplier": 0.82}
    (out / "images").mkdir()
    scene.render.filepath = str(out / "images/000001.png")
    bpy.ops.render.render(write_still=True)
    controls = gen.write_counterfactuals(1, trees)
    # ID passes retain source alpha and self-occlusion; no global rank subtraction.
    scene.cycles.samples = 8
    gen.write_masks(1, trees, [1, 0], ground)
    masks = out / "masks/000001"
    full = gen.read_coverage(masks / "amodal_1.png") >= 0.5
    visible = gen.read_coverage(masks / "visible_1.png") >= 0.5
    unknown = gen.read_coverage(masks / "raster_unknown_1.png") >= 0.5
    known = ~unknown
    denominator = int((full & known).sum())
    hidden = int((full & ~visible & known).sum())
    fraction = hidden / denominator if denominator else None
    ys, xs = np.nonzero(full & known)
    height_fraction = (int(ys.max() - ys.min()) + 1) / full.shape[0] if len(ys) else None
    touches_frame = bool(full[0].any() or full[-1].any() or full[:, 0].any() or full[:, -1].any())
    report = {
        **config,
        "status": "render_completed",
        "assets": names,
        "camera_framing": framing,
        "controls": controls,
        "target_known_amodal_pixels": denominator,
        "target_known_hidden_pixels": hidden,
        "target_hidden_fraction": fraction,
        "target_amodal_height_fraction": height_fraction,
        "requested_height_range_passed": height_fraction is not None
        and 0.75 <= height_fraction <= 0.95
        and not touches_frame,
        "target_support_touches_frame": touches_frame,
        "requested_hidden_range_passed": fraction is not None and 0.05 <= fraction <= 0.25,
        "neighbour_may_be_frame_truncated": True,
        "depth_export_completed": False,
        "note": "Real rendered V/A/parts qualification scene; not a complete metric dataset.",
    }
    (out / "result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("GPU_RENDER_COMPLETE " + json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
