"""Per-validation-image comparison of focused visible arms."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
ARMS = {
    "base": None,
    "readout": ROOT / "reports/focused-visible-arms-2026-11-10/mask_readout/checkpoint.pth",
    "pf": ROOT / "reports/focused-visible-arms-2026-11-10/encoder_pf_only/checkpoint.pth",
    "lora": ROOT / "reports/focused-visible-arms-2026-11-10/lora_only/checkpoint.pth",
}
OUT = ROOT / "reports/focused-per-image-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def sample(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = mask(DATA / row["scene"] / "visible_target.png")
    ys, xs = np.where(visible)
    box = lb.boxes(np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32))
    target = np.asarray(Image.fromarray(visible.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)) > 127
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        torch.from_numpy(target.astype(np.float32))[None, None],
    )


def build(arm):
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(
        base,
        encoder_lora_rank=4 if arm == "lora" else 0,
        encoder_focus_rank=16 if arm == "pf" else 0,
        encoder_focus_chunked=True,
        encoder_focus_null_token=True,
    ).cuda().eval()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)["decoder"]
    own = model.decoder.state_dict()
    model.decoder.load_state_dict({k: v for k, v in payload.items() if k in own and v.shape == own[k].shape}, strict=False)
    path = ARMS[arm]
    if path is not None:
        model.load_state_dict(torch.load(path, map_location="cpu", weights_only=True)["state"], strict=False)
    return model


def main():
    OUT.mkdir(exist_ok=True)
    rows = [r for r in json.loads((DATA / "index.json").read_text()) if r["split"] == "validation"]
    result = []
    for arm in ARMS:
        model = build(arm)
        for row in rows:
            image, box, target = sample(row)
            with torch.no_grad():
                output = model(image.cuda(), input_boxes=box.cuda())
            pred = output["masks"][0, 0, 0].sigmoid().cpu() > 0.5
            t = target[0, 0] > 0.5
            inter, union = (pred & t).sum().item(), (pred | t).sum().item()
            result.append({"scene": row["scene"], "arm": arm, "iou": inter / union if union else 1.0, "hidden": row["target_hidden_fraction"], "overlap": row["crown_overlap_fraction"]})
        print(arm, flush=True)
    (OUT / "per_image.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    # Pivot table.
    table = {}
    for item in result:
        table.setdefault(item["scene"], {})[item["arm"]] = item["iou"]
    (OUT / "table.json").write_text(json.dumps(table, indent=2), encoding="utf-8")
    for scene, values in table.items():
        print(scene, {k: round(v, 3) for k, v in values.items()})


if __name__ == "__main__":
    main()

