param(
    [string]$Blender,
    [string]$OutputName = ("team-reproduction-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
if ($OutputName -notmatch '^[A-Za-z0-9_-]+$') {
    throw "OutputName must be a simple name containing letters, digits, underscores or hyphens."
}
Push-Location $projectRoot
try {
    $pythonExe = Join-Path $projectRoot ".venv-dataset\Scripts\python.exe"
    if (-not (Test-Path -LiteralPath $pythonExe)) {
        throw "Create .venv-dataset and install requirements-dataset.txt first. See the handoff guide."
    }
    $render = Join-Path $projectRoot "reports\$OutputName"
    $joint = "$render-joint"
    $qualification = "$render-check"
    foreach ($folder in @($render, $joint, $qualification)) {
        if (Test-Path -LiteralPath $folder) { throw "Refusing existing output: $folder" }
    }
    $renderArguments = @("scripts/run_cuda_tree_render.py", "--out", $render)
    if ($Blender) { $renderArguments += @("--blender", $Blender) }
    & $pythonExe @renderArguments
    if ($LASTEXITCODE -ne 0) { throw "GPU rendering failed. Keep the log and watchdog report." }
    & $pythonExe scripts/prepare_rendered_metric_scene.py --render $render --joint-depth --output $joint
    if ($LASTEXITCODE -ne 0) { throw "Packaging failed." }
    & $pythonExe scripts/qualify_metric_scene.py --scene "$joint/scene.json" --labels "$joint/labels.npz" --rgb "$render/images/000001.png" --focal-id 1 --occlusion-scope tree --allow-incomplete-metrics --output $qualification
    if ($LASTEXITCODE -ne 0) { throw "Qualification failed. Do not mark this sample as accepted." }
    Write-Host "Completed qualification scene: $render"
    Write-Host "Report: $qualification/report.json"
    Write-Host "This is a partial RGB-D contract check. Full physical parameters and training admission remain pending."
} finally {
    Pop-Location
}
