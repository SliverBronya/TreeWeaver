"""Convert Cycles depth EXRs to float32 npy arrays (Blender-side)."""

from __future__ import annotations

from pathlib import Path

import bpy
import numpy as np

ROOT = Path(r"D:\TreeWeaver\reports\stem-depth-100-2026-11-06")

for scene_dir in sorted(path for path in ROOT.iterdir() if path.is_dir()):
    exr = sorted(scene_dir.glob("depth_*.exr"))
    if not exr:
        continue
    image = bpy.data.images.load(str(exr[0]))
    width, height = image.size
    pixels = np.array(image.pixels[:], dtype=np.float32).reshape(height, width, 4)
    depth = pixels[..., 0]
    np.save(scene_dir / "depth.npy", depth)
    valid = depth[depth < 1e5]
    print(
        scene_dir.name,
        "min",
        float(valid.min()) if valid.size else None,
        "max",
        float(valid.max()) if valid.size else None,
        "median",
        float(np.median(valid)) if valid.size else None,
        flush=True,
    )
    bpy.data.images.remove(image)


