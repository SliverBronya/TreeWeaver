"""Build a concrete 60-target qualification manifest from existing training cohorts."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(r"D:\TreeWeaver\reports\data-qualification-2026-11-09")
AUDIT = ROOT / "qualification.json"
OUT = ROOT / "cohort_manifest.json"
DESIRED = {"clear": 32, "contact": 12, "overlap": 16}


def main():
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    selected = []
    for root in ("v6", "mixed", "supplement"):
        for record in audit["records"][root]:
            if record["split"] == "train":
                selected.append(record)
    counts = Counter(record["relation"] for record in selected)
    gaps = {key: desired - counts.get(key, 0) for key, desired in DESIRED.items()}
    manifest = {
        "schema_version": "treeweaver-qualification-cohort-1.0",
        "purpose": "development qualification only; not a training expansion",
        "desired": DESIRED,
        "current": dict(counts),
        "targets": len(selected),
        "gap": gaps,
        "complete": all(value == 0 for value in gaps.values()),
        "training_allowed": False,
        "test_accessed": False,
        "source_roots": [
            "fig-paired-v6-framing-30-2026-11-08",
            "mixed-identity-layout-qualification-2026-11-08",
            "qualification-supplement-v2-2026-11-09",
        ],
        "unique_assets": len({record["asset"] for record in selected}),
        "unique_groups": len({record["group"] for record in selected}),
        "hidden_positive": sum(record["hidden_fraction"] > 0 for record in selected),
        "hidden_ge_1pct": sum(record["hidden_fraction"] >= 0.01 for record in selected),
        "max_hidden_fraction": max(record["hidden_fraction"] for record in selected),
        "records": selected,
        "required_additions": {
            "clear": gaps["clear"],
            "contact": gaps["contact"],
            "overlap": gaps["overlap"],
            "rule": "new source groups/assets only; no overlap with selected groups/assets; same-camera control required",
        },
    }
    OUT.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ("targets", "current", "gap", "complete", "unique_assets", "unique_groups", "hidden_positive", "hidden_ge_1pct", "max_hidden_fraction")}, indent=2))


if __name__ == "__main__":
    main()

