"""Audit crown-relation cohorts and hidden-area support in existing paired data."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

ROOTS = {
    "v6": Path(r"D:\TreeWeaver\reports\fig-paired-v6-framing-30-2026-11-08"),
    "mixed": Path(r"D:\TreeWeaver\reports\mixed-identity-layout-qualification-2026-11-08"),
    "focal": Path(r"D:\TreeWeaver\reports\focal-view-qualification-2026-11-09"),
    "supplement": Path(r"D:\TreeWeaver\reports\qualification-supplement-v2-2026-11-09"),
}
OUT = Path(r"D:\TreeWeaver\reports\data-qualification-2026-11-09")
OUT.mkdir(parents=True, exist_ok=True)


def mask(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 127


def dilate(mask: np.ndarray, radius: int = 3) -> np.ndarray:
    padded = np.pad(mask, radius, mode="constant")
    out = np.zeros_like(mask)
    height, width = mask.shape
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            if dx * dx + dy * dy > radius * radius:
                continue
            out |= padded[radius + dy : radius + dy + height, radius + dx : radius + dx + width]
    return out


def relation(target_visible, target_amodal, others):
    if not target_amodal.any():
        return "unknown"
    for other in others:
        if (target_visible & other).any():
            return "overlap"
    expanded = dilate(target_visible, 3)
    for other in others:
        if (expanded & other).any():
            return "contact"
    return "clear"


def bucket(value: float) -> str:
    if value <= 0:
        return "0"
    if value <= 0.01:
        return "<=1%"
    if value <= 0.05:
        return "1-5%"
    if value <= 0.20:
        return "5-20%"
    return ">20%"


def audit(name: str, root: Path):
    payload = json.loads((root / "paired-samples.json").read_text(encoding="utf-8"))
    records = []
    for sample in payload["records"]:
        if sample.get("condition") != "scene":
            continue
        instances = sample.get("instances", [])
        masks = []
        for item in instances:
            visible = mask(root / item["visible"])
            amodal = mask(root / item["amodal"])
            masks.append((visible, amodal))
        for index, item in enumerate(instances):
            if item.get("context"):
                continue
            visible, amodal = masks[index]
            others = [other[1] for other_index, other in enumerate(masks) if other_index != index]
            hidden = float((amodal & ~visible).sum()) / max(1, int(amodal.sum()))
            ys, xs = np.where(amodal)
            height = float(ys.max() - ys.min() + 1) / amodal.shape[0] if len(ys) else 0.0
            records.append(
                {
                    "root": name,
                    "scene": sample["id"],
                    "group": sample.get("group_id"),
                    "split": sample.get("split"),
                    "asset": item.get("asset"),
                    "tree_index": item.get("source_tree_index"),
                    "relation": relation(visible, amodal, others),
                    "hidden_fraction": hidden,
                    "hidden_bucket": bucket(hidden),
                    "height_fraction": height,
                    "area": int(amodal.sum()),
                }
            )
    return records


def main():
    all_records = {}
    for name, root in ROOTS.items():
        all_records[name] = audit(name, root)
    summary = {}
    for name, records in all_records.items():
        by_relation = Counter(record["relation"] for record in records)
        by_hidden = Counter(record["hidden_bucket"] for record in records)
        by_split = Counter(record["split"] for record in records)
        summary[name] = {
            "targets": len(records),
            "by_relation": dict(by_relation),
            "by_hidden": dict(by_hidden),
            "by_split": dict(by_split),
            "hidden_positive": sum(record["hidden_fraction"] > 0 for record in records),
            "hidden_ge_1pct": sum(record["hidden_fraction"] >= 0.01 for record in records),
            "median_height_fraction": float(np.median([r["height_fraction"] for r in records])),
            "max_hidden_fraction": max((r["hidden_fraction"] for r in records), default=0.0),
        }
    result = {"roots": {k: str(v) for k, v in ROOTS.items()}, "summary": summary, "records": all_records}
    (OUT / "qualification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()


