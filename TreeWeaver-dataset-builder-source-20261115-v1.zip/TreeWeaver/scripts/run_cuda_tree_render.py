"""Run one explicitly requested GPU scene with an external resource watchdog.

This bounded renderer has its own admission budget; it does not change the
3 GiB guard for pretrained training, OS settings or any other running jobs.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from resource_guard import SESSION_GPU_STOP, memory_snapshot  # noqa: E402


def gpu_snapshot():
    raw = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=memory.free,temperature.gpu,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        text=True,
        timeout=5,
    )
    free, temperature, utilization = map(int, raw.splitlines()[0].split(","))
    return {"free_gpu_mib": free, "temperature_c": temperature, "utilization_percent": utilization}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--blender", type=Path, help="Path to the Blender 4.2.3 executable")
    args = parser.parse_args()
    blender = args.blender or ROOT / "tools/blender-4.2.3-windows-x64/blender.exe"
    if not blender.is_file():
        found = shutil.which("blender") if args.blender is None else None
        if found is None:
            parser.error("Blender not found; pass --blender with the installed executable path")
        blender = Path(found)
    out = args.out.resolve()
    if out.exists():
        parser.error("output must be new")
    initial = memory_snapshot()
    gpu = gpu_snapshot()
    if SESSION_GPU_STOP.exists():
        parser.error("session stop marker is present")
    if initial["available_ram_bytes"] < 768 * 1024**2 or gpu["free_gpu_mib"] < 2048:
        parser.error("insufficient headroom even for this isolated render")
    if gpu["temperature_c"] >= 76:
        parser.error("GPU already at temperature stop limit")
    out.parent.mkdir(parents=True, exist_ok=True)
    log_path = out.with_suffix(".log")
    watch_path = out.with_suffix(".watchdog.json")
    command = [
        str(blender.resolve()),
        "--background",
        "--factory-startup",
        "--threads",
        "2",
        "--python-exit-code",
        "7",
        "--python",
        str(ROOT / "scripts/render_cuda_tree_scene.py"),
        "--",
        "--out",
        str(out),
    ]
    started = time.monotonic()
    minimum_ram = initial["available_ram_bytes"]
    samples = [{"elapsed_s": 0, **gpu}]
    stop_reason = None
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        print(f"STARTED_GPU_RENDER pid={process.pid} log={log_path}", flush=True)
        next_gpu = time.monotonic() + 5
        try:
            while process.poll() is None:
                memory = memory_snapshot()
                minimum_ram = min(minimum_ram, memory["available_ram_bytes"])
                if memory["available_ram_bytes"] < 256 * 1024**2:
                    stop_reason = "available_RAM_below_256MiB"
                if memory["available_commit_bytes"] < 1024**3:
                    stop_reason = "commit_headroom_below_1GiB"
                if time.monotonic() >= next_gpu:
                    gpu = gpu_snapshot()
                    samples.append({"elapsed_s": round(time.monotonic() - started, 1), **gpu})
                    print(json.dumps(samples[-1]), flush=True)
                    next_gpu = time.monotonic() + 5
                    if gpu["temperature_c"] >= 80 or gpu["free_gpu_mib"] < 256:
                        stop_reason = "GPU_temperature_or_memory_stop"
                if time.monotonic() - started > 600:
                    stop_reason = "render_timeout_600s"
                if stop_reason:
                    process.terminate()
                    break
                time.sleep(0.25)
        finally:
            if process.poll() is None:
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
            code = process.wait()
            record = {
                "exit_code": code,
                "stop_reason": stop_reason,
                "elapsed_s": round(time.monotonic() - started, 2),
                "minimum_available_ram_bytes": minimum_ram,
                "gpu_samples": samples,
                "only_owned_child_process_controlled": True,
            }
            watch_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
            print(json.dumps(record), flush=True)
    return code if code else int(stop_reason is not None)


if __name__ == "__main__":
    raise SystemExit(main())
