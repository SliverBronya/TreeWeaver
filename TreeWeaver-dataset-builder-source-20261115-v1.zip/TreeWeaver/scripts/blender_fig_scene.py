"""Layered scene using the PlantCatalog common fig tree set (CC BY)."""

from __future__ import annotations

import math
import random
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRI = "autumn_field_puresky_2k.hdr"
OUT = Path(r"D:\TreeWeaver\reports\blender-fig-scene\sample.png")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.25


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(v * scale for v in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def load_tree(path, height=TARGET_HEIGHT):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [obj for obj in bpy.data.objects if obj not in before]
    meshes = [
        obj
        for obj in new
        if obj.type == "MESH" and obj.name not in {"Cube", "Camera", "Light"}
    ]
    if not meshes:
        raise RuntimeError(f"no meshes in {path}")
    # The Sketchfab GLB keeps its upright transform on parent empties. Clear the
    # parent *with* transform before deleting the empties, otherwise the tree
    # collapses to its authored Y-up pose and lies on the ground.
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    normalize(tree, height)
    return tree


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def ground():
    bpy.ops.mesh.primitive_plane_add(size=300, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (28, 28, 28)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)


def world(rng):
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / HDRI))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 6.28))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.05
    bpy.context.scene.world = w


def camera(target, lens=35.0):
    bpy.ops.object.camera_add()
    cam = bpy.context.object
    cam.data.lens = lens
    cam.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    cam.location = (0.3, -distance, 1.55)
    look = Vector((0, 0, TARGET_HEIGHT * 0.48))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.dof.use_dof = True
    cam.data.dof.focus_object = target
    cam.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = cam


def main():
    rng = random.Random(99)
    clean()
    target = load_tree(ROOT / "realistic_hd_common_fig_tree_3030.glb")
    target.location = (0, 0, 0)
    target.rotation_euler = (0, 0, math.radians(25))

    neighbour = load_tree(ROOT / "realistic_hd_common_fig_tree_1330.glb", TARGET_HEIGHT * 0.95)
    neighbour.location = (5.0, 3.0, 0)
    neighbour.rotation_euler = (0, 0, math.radians(150))

    left = load_tree(ROOT / "realistic_hd_common_fig_tree_530.glb", TARGET_HEIGHT * 0.9)
    left.location = (-6.0, 6.0, 0)
    left.rotation_euler = (0, 0, math.radians(60))

    numbers = [130, 330, 430, 530, 630, 730, 930, 1030, 1130, 1230, 1330, 1430, 1530, 1730, 1830, 1930, 2030, 2130, 2230, 2530, 2630, 2730, 2830, 2930, 3030]
    rng.shuffle(numbers)
    for number in numbers[:16]:
        path = ROOT / f"realistic_hd_common_fig_tree_{number}30.glb"
        if not path.exists():
            continue
        tree = load_tree(path, TARGET_HEIGHT * rng.uniform(0.55, 1.15))
        tree.location = (rng.uniform(-28, 28), rng.uniform(8, 36), 0)
        tree.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

    ground()
    world(rng)
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 18))
    sun = bpy.context.object
    sun.data.energy = 2.6
    sun.data.angle = math.radians(5)
    sun.rotation_euler = (math.radians(52), 0, math.radians(35))
    camera(target, 35.0)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    bpy.context.scene.render.filepath = str(OUT)
    bpy.ops.render.render(write_still=True)
    print(f"saved {OUT}")


if __name__ == "__main__":
    main()

