"""Build target-centric composites: 90% target height, centered, 5-30% crown overlap."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver\reports\fig-paired-v6-framing-30-2026-11-08")
OUT = Path(r"D:\TreeWeaver\reports\focused-composite-2026-11-10")
S = 1024
COUNT = 20


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def cutout(rgb, mask):
    ys, xs = np.where(mask)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    image = rgb[y0:y1, x0:x1].copy()
    m = mask[y0:y1, x0:x1].copy()
    return image, m


def scale_cutout(image, mask, height):
    h, w = mask.shape
    scale = min(height / h, 1000 / w)
    width = max(1, round(w * scale))
    height = max(1, round(h * scale))
    image = np.asarray(Image.fromarray(image).resize((width, height), Image.BILINEAR))
    m = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)) > 127
    return image, m


def paste(canvas, image, mask, left, top):
    h, w = mask.shape
    left = max(0, min(S - w, left))
    top = max(0, min(S - h, top))
    region = canvas[top : top + h, left : left + w]
    region[mask] = image[mask]
    full = np.zeros((S, S), bool)
    full[top : top + h, left : left + w] = mask
    return full


def background():
    y = np.arange(S)[:, None]
    sky = np.zeros((S, S, 3), np.uint8)
    sky[..., 0] = np.clip(150 - y * 0.12, 0, 255)
    sky[..., 1] = np.clip(190 - y * 0.10, 0, 255)
    sky[..., 2] = np.clip(230 - y * 0.05, 0, 255)
    ground = y[:, 0] > int(S * 0.86)
    sky[ground] = [120, 115, 95]
    return sky


def load_target(record, item):
    rgb = np.asarray(Image.open(ROOT / record["image"]).convert("RGB"))
    mask = alpha(ROOT / item["amodal"])
    if mask.shape != rgb.shape[:2]:
        mask = np.asarray(
            Image.fromarray(mask.astype(np.uint8) * 255).resize(
                (rgb.shape[1], rgb.shape[0]), Image.NEAREST
            )
        ) > 127
    image, m = cutout(rgb, mask)
    stem = alpha(ROOT / item["amodal_stem"])
    if stem.shape != rgb.shape[:2]:
        stem = np.asarray(
            Image.fromarray(stem.astype(np.uint8) * 255).resize(
                (rgb.shape[1], rgb.shape[0]), Image.NEAREST
            )
        ) > 127
    stem_crop = stem[mask.astype(bool)].reshape(-1)
    return image, m, stem_crop


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "images").mkdir(exist_ok=True)
    (OUT / "masks").mkdir(exist_ok=True)
    manifest = json.loads((ROOT / "paired-samples.json").read_text(encoding="utf-8"))
    pool = []
    for record in manifest["records"]:
        if record["condition"] != "scene" or record["split"] != "train":
            continue
        for index, item in enumerate(record["instances"]):
            pool.append((record, item, index))
    rows = []
    for k in range(COUNT):
        target_record, target_item, target_index = pool[k % len(pool)]
        neighbour_record, neighbour_item, _ = pool[(k + 7) % len(pool)]
        if neighbour_item["asset"] == target_item["asset"]:
            neighbour_record, neighbour_item, _ = pool[(k + 11) % len(pool)]
        target_rgb, target_mask, _ = load_target(target_record, target_item)
        neighbour_rgb, neighbour_mask, _ = load_target(neighbour_record, neighbour_item)
        target_rgb, target_mask = scale_cutout(target_rgb, target_mask, 900)
        neighbour_rgb, neighbour_mask = scale_cutout(neighbour_rgb, neighbour_mask, 500)
        target_top = (S - target_mask.shape[0]) // 2
        target_left = (S - target_mask.shape[1]) // 2
        canvas = background()
        # Try a few offsets and pick the one closest to 15% crown overlap.
        best = None
        for shift in range(0, target_mask.shape[1] + neighbour_mask.shape[1], 8):
            neighbour_left = target_left + shift - neighbour_mask.shape[1] // 2 + target_mask.shape[1] // 2
            neighbour_top = (S - neighbour_mask.shape[0]) // 2
            temp = canvas.copy()
            tmask = paste(temp, target_rgb, target_mask, target_left, target_top)
            nmask = paste(temp, neighbour_rgb, neighbour_mask, neighbour_left, neighbour_top)
            inter = (tmask & nmask).sum()
            overlap = inter / max(min(tmask.sum(), nmask.sum()), 1)
            score = abs(overlap - 0.15)
            if best is None or score < best[0]:
                best = (score, overlap, neighbour_left, neighbour_top, tmask, nmask, temp)
        _, overlap, left, top, tmask, nmask, canvas = best
        # Alternate hidden target / hidden neighbour.
        if k % 2 == 0:
            visible_target = tmask & ~nmask
            visible_neighbour = nmask
        else:
            visible_target = tmask
            visible_neighbour = nmask & ~tmask
        scene_dir = OUT / f"{k + 1:06d}"
        scene_dir.mkdir()
        Image.fromarray(canvas).save(scene_dir / "rgb.png")
        for name, mask in (("target", tmask), ("neighbour", nmask)):
            out = np.zeros((S, S, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene_dir / f"amodal_{name}.png")
        for name, mask in (("target", visible_target), ("neighbour", visible_neighbour)):
            out = np.zeros((S, S, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene_dir / f"visible_{name}.png")
        ownership = np.zeros((S, S, 3), np.uint8)
        ownership[visible_target] = [60, 130, 255]
        ownership[visible_neighbour] = [255, 150, 40]
        Image.fromarray(ownership).save(scene_dir / "ownership.png")
        target_h = target_mask.shape[0] / S
        target_hidden = 1 - visible_target.sum() / max(tmask.sum(), 1)
        row = {
            "scene": f"{k + 1:06d}",
            "target_asset": target_item["asset"],
            "neighbour_asset": neighbour_item["asset"],
            "target_height_fraction": float(target_h),
            "crown_overlap_fraction": float(overlap),
            "target_hidden_fraction": float(target_hidden),
            "target_center": [target_left + target_mask.shape[1] / 2, target_top + target_mask.shape[0] / 2],
            "split": target_record["split"],
        }
        (scene_dir / "meta.json").write_text(json.dumps(row, indent=2), encoding="utf-8")
        rows.append(row)
        print(k + 1, row["target_asset"], "h", round(target_h, 3), "overlap", round(overlap, 3), "hidden", round(target_hidden, 3), flush=True)
    (OUT / "index.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print("done", len(rows))


if __name__ == "__main__":
    main()

