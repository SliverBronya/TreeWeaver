"""3D target-centric pilot: HDRI forest, 2-3 fig trees, target at 90% height."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import bpy
import numpy as np
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from blender_stem_pilot import load  # noqa: E402

ASSETS = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env\forest_slope_2k.hdr")
OUT = Path(r"D:\TreeWeaver\reports\focused-3d-pilot-2026-11-10")
RES_X, RES_Y = 1536, 1024
MASK_X, MASK_Y = 768, 512
CASES = [
    ("realistic_hd_common_fig_tree_2830", "realistic_hd_common_fig_tree_1030", "realistic_hd_common_fig_tree_130"),
    ("realistic_hd_common_fig_tree_2930", "realistic_hd_common_fig_tree_2230", "realistic_hd_common_fig_tree_530"),
    ("realistic_hd_common_fig_tree_1830", "realistic_hd_common_fig_tree_2330", "realistic_hd_common_fig_tree_2530"),
    ("realistic_hd_common_fig_tree_2030", "realistic_hd_common_fig_tree_1730", "realistic_hd_common_fig_tree_3030"),
    ("realistic_hd_common_fig_tree_2130", "realistic_hd_common_fig_tree_2630", "realistic_hd_common_fig_tree_1930"),
    ("realistic_hd_common_fig_tree_430", "realistic_hd_common_fig_tree_930", "realistic_hd_common_fig_tree_1630"),
]


def setup():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.eevee.taa_render_samples = 32
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    nodes = world.node_tree.nodes
    background = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV))
    world.node_tree.links.new(env.outputs["Color"], background.inputs["Color"])
    background.inputs["Strength"].default_value = 0.9
    scene.world = world


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points), max(p.x for p in points),
        min(p.y for p in points), max(p.y for p in points),
        min(p.z for p in points), max(p.z for p in points),
    )


def look_at(camera, point):
    camera.rotation_euler = (point - camera.location).to_track_quat("-Z", "Y").to_euler()


def fit_camera(camera, target, camera_height=2.5):
    # Projected target height fraction must be about 0.90.
    def fraction(distance):
        camera.location = (0, -distance, camera_height)
        look_at(camera, Vector((0, 0, 4.5)))
        bpy.context.view_layer.update()
        points = [target.matrix_world @ Vector(c) for c in target.bound_box]
        projected = [world_to_camera_view(bpy.context.scene, camera, p).y for p in points]
        return max(projected) - min(projected)
    low, high = 8.0, 60.0
    for _ in range(28):
        mid = (low + high) / 2
        if fraction(mid) > 1.10:
            low = mid
        else:
            high = mid
    fraction((low + high) / 2)


def ground():
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    obj = bpy.context.object
    material = bpy.data.materials.new("ground")
    material.use_nodes = True
    bsdf = material.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (0.16, 0.14, 0.10, 1)
    bsdf.inputs["Roughness"].default_value = 1.0
    obj.data.materials.append(material)


def render_masks(scene_dir, trees, camera):
    scene = bpy.context.scene
    scene.render.film_transparent = True
    scene.render.resolution_x, scene.render.resolution_y = MASK_X, MASK_Y
    for obj in scene.objects:
        if obj.type in {"MESH", "CURVE"}:
            obj.hide_render = True
    for index, tree in enumerate(trees, start=1):
        for other in trees:
            other.hide_render = True
        tree.hide_render = False
        scene.render.filepath = str(scene_dir / f"amodal_{index}.png")
        bpy.ops.render.render(write_still=True)
    for tree in trees:
        tree.hide_render = False


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for number, names in enumerate(CASES, start=1):
        setup()
        trees = []
        heights = [9.0, 8.0, 7.2]
        for index, name in enumerate(names):
            tree, stem = load(ASSETS / f"{name}.glb", heights[index])
            tree.location.y = index * 2.2
            trees.append(tree)
        ground()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.2
        sun.rotation_euler = (math.radians(45), 0, math.radians(30))
        bpy.ops.object.camera_add(location=(0, -20, 2.5))
        camera = bpy.context.object
        camera.data.lens = 50
        bpy.context.scene.camera = camera
        fit_camera(camera, trees[0])
        # Place neighbours left/right with controlled overlap.
        trees[1].location.x = 7.5
        trees[2].location.x = -7.5
        trees[1].location.y = 4.0
        trees[2].location.y = 6.0
        scene_dir = OUT / f"{number:06d}"
        scene_dir.mkdir()
        bpy.context.scene.render.filepath = str(scene_dir / "rgb.png")
        bpy.ops.render.render(write_still=True)
        render_masks(scene_dir, trees, camera)
        # Build visible masks from amodal masks and front-to-back order.
        amodal = []
        for index in range(1, 4):
            image = bpy.data.images.load(str(scene_dir / f"amodal_{index}.png"))
            width, height = image.size
            array = np.array(image.pixels[:], dtype=np.float32).reshape(height, width, 4)
            amodal.append(array[..., 3] > 0.5)
            bpy.data.images.remove(image)
        visible = []
        for index in range(3):
            current = amodal[index].copy()
            for front in range(index):
                current &= ~amodal[front]
            visible.append(current)
            out = np.zeros((*current.shape, 4), np.uint8)
            out[..., 3] = current.astype(np.uint8) * 255
            bpy.data.images.new("visible", width=current.shape[1], height=current.shape[0], alpha=True)
            image = bpy.data.images["visible"]
            image.pixels = out.astype(np.float32).ravel() / 255.0
            image.filepath_raw = str(scene_dir / f"visible_{index + 1}.png")
            image.file_format = "PNG"
            image.save()
            bpy.data.images.remove(image)
        ys, xs = np.where(visible[0])
        target_height = (ys.max() - ys.min() + 1) / visible[0].shape[0]
        overlap = float((amodal[0] & amodal[1]).sum()) / max(min(amodal[0].sum(), amodal[1].sum()), 1)
        meta = {
            "scene": f"{number:06d}",
            "trees": names,
            "target_height_fraction": float(target_height),
            "target_center": [float((xs.min() + xs.max()) / 2 / visible[0].shape[1]), float((ys.min() + ys.max()) / 2 / visible[0].shape[0])],
            "overlap_target_neighbour": overlap,
            "target_hidden_fraction": float(1 - visible[0].sum() / max(amodal[0].sum(), 1)),
            "background": "HDRI forest",
        }
        (scene_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("SCENE", number, "height", round(target_height, 3), "overlap", round(overlap, 3), flush=True)


if __name__ == "__main__":
    main()




