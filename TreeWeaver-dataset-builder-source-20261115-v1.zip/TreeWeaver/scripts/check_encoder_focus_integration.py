"""Real pretrained Hiera integration; no efficacy claim from the optimizer step."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

WORKSPACE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE / "workers/tree_models"))
from research_protocol import pinned_snapshot  # noqa: E402
from resource_guard import assert_pretrained_experiment_allowed  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors
from transformers import Sam2Model


def main():
    assert_pretrained_experiment_allowed()
    parser = argparse.ArgumentParser()
    parser.add_argument("--chunked", action="store_true")
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--out", type=str, default="reports/encoder-focus-integration-2026-11-09")
    args = parser.parse_args()
    torch.set_num_threads(2)
    torch.manual_seed(20261109)
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    out = ROOT / args.out
    out.mkdir(exist_ok=False)
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = (
        Sam2OcclusionModel(base, encoder_focus_rank=16, encoder_focus_chunked=args.chunked)
        .to(device)
        .eval()
    )
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    model.decoder.load_state_dict(
        torch.load(prior, map_location="cpu", weights_only=True)["decoder"], strict=True
    )
    data = PairedFigDataset(ROOT / "reports/fig-paired-v6-framing-30-2026-11-08", "train")
    sample = data.sample(
        next(
            i
            for i, r in enumerate(data.items)
            if r["condition"] == "scene" and len(r["instances"]) == 2
        )
    )
    inputs, _ = tensors(sample, device)
    focus = model.encoder_focus
    with torch.no_grad():
        model.encoder_focus = None
        plain = model(**inputs)
        model.encoder_focus = focus
        zero = model(**inputs)
    torch.testing.assert_close(plain["masks"], zero["masks"], atol=0.03, rtol=1e-3)
    delta = (plain["masks"] - zero["masks"]).abs()
    model.requires_grad_(False)
    model.encoder_focus.requires_grad_(True)
    frozen = {
        k: v.cpu().clone()
        for k, v in model.state_dict().items()
        if not k.startswith("encoder_focus.")
    }
    optimizer = torch.optim.AdamW(model.encoder_focus.parameters(), lr=0.001)
    output = model(**inputs)
    output["masks"].square().mean().backward()
    gradients = {
        k: float(v.grad.norm())
        for k, v in model.encoder_focus.named_parameters()
        if v.grad is not None
    }
    assert all(
        torch.isfinite(v.grad).all() for v in model.encoder_focus.parameters() if v.grad is not None
    )
    assert any(v > 0 for k, v in gradients.items() if k.endswith("output.weight"))
    optimizer.step()
    for k, v in model.state_dict().items():
        if k in frozen:
            assert torch.equal(v.cpu(), frozen[k]), k
    assert model.encoder_focus.context is None
    report = {
        "global_blocks": list(focus.adapters),
        "zero_init_max_logit_delta": float(delta.max()),
        "zero_init_mean_logit_delta": float(delta.mean()),
        "zero_init_sign_changes": int(((plain["masks"] > 0) != (zero["masks"] > 0)).sum()),
        "encoder_runs_per_image": 2,
        "all_non_pf_weights_unchanged": True,
        "finite_gradients": gradients,
        "note": "Identity at fixed encoder batch; query replication may alter FP kernels",
        "training_efficacy_claim": False,
    }
    (out / "result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
