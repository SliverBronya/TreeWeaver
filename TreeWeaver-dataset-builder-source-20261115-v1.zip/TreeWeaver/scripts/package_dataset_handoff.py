"""Build the explicitly selected dataset handoff; never publish local assets."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import shutil
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GUIDE = "docs/collaboration/DATASET_BUILDER_HANDOFF_2026-11-15.md"
NEW_FILES = [
    GUIDE,
    "requirements-dataset.txt",
    "scripts/run_dataset_handoff.ps1",
    "scripts/check_dataset_handoff.py",
    "scripts/package_dataset_handoff.py",
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def guide_html(markdown):
    lines, code = [], False
    for line in markdown.splitlines():
        if line.startswith("```"):
            lines.append("</code></pre>" if code else "<pre><code>")
            code = not code
        elif code:
            lines.append(html.escape(line) + "\n")
        elif line.startswith("#"):
            n = len(line) - len(line.lstrip("#"))
            lines.append(f"<h{n}>{html.escape(line[n:].strip())}</h{n}>")
        elif line.strip():
            text = html.escape(line)
            text = re.sub(r"https://[^\s；。，]+", lambda m: f'<a href="{m[0]}">{m[0]}</a>', text)
            lines.append("<p>" + text + "</p>")
    return (
        """<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TreeWeaver 合成树数据集制作交接说明</title>
<style>
body{font:17px/1.8 'Microsoft YaHei',sans-serif;color:#17251e;max-width:1000px;
margin:42px auto;padding:0 28px}h1{font-size:30px}h2{font-size:23px;margin-top:38px}
a{color:#17654b;overflow-wrap:anywhere}pre{font:13px/1.7 Consolas,monospace;
background:#f0f3f1;padding:18px;overflow:auto}img{width:100%;height:auto}p{margin:12px 0}
@media print{body{font-size:11pt;margin:0}pre{white-space:pre-wrap;
overflow-wrap:anywhere}h2{break-after:avoid}img{max-height:170mm;object-fit:contain}}
</style>
<body>"""
        + "\n".join(lines[:3])
        + """<p>当前渲染样例与标签对照如下，完整图和原始数组都在交接包中。</p>
<img src="previews/current-scene.png" alt="当前场景 RGB">
<img src="previews/labels-and-depth.png" alt="RGB 可见 完整 隐藏 归属 部件 深度对照">
"""
        + "\n".join(lines[3:])
        + "</body></html>"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--preview", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    stage = out / "TreeWeaver"
    stage.mkdir()
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
    files = set(filter(None, tracked)) | set(NEW_FILES)
    for name in sorted(files):
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(path)
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
    selected_assets = list((ROOT / "tools/assets/sketchfab/fig_trees").glob("*.glb"))
    selected_assets += list((ROOT / "tools/assets/env").glob("*"))
    if len([p for p in selected_assets if p.suffix == ".glb"]) != 29:
        raise ValueError("Expected the 29-tree fig asset pool")
    for path in selected_assets:
        destination = stage / path.relative_to(ROOT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
    for name in (
        "cuda-metric-scene-2026-11-15-03",
        "cuda-metric-scene-qualification-2026-11-15-03",
        "cuda-metric-joint-products-2026-11-15-03",
        "cuda-metric-joint-qualification-2026-11-15-03",
    ):
        shutil.copytree(ROOT / "reports" / name, stage / "reports" / name)
    for suffix in (".log", ".watchdog.json"):
        path = ROOT / "reports" / ("cuda-metric-scene-2026-11-15-03" + suffix)
        if path.is_file():
            shutil.copy2(path, stage / "reports" / path.name)
    previews = stage / "previews"
    previews.mkdir()
    shutil.copy2(args.preview, previews / "labels-and-depth.png")
    shutil.copy2(
        ROOT / "reports/cuda-metric-scene-2026-11-15-03/images/000001.png",
        previews / "current-scene.png",
    )
    guide = (ROOT / GUIDE).read_text(encoding="utf-8")
    (stage / "数据集制作交接说明.html").write_text(guide_html(guide), encoding="utf-8")
    (stage / "开始这里.md").write_text(
        "# TreeWeaver 数据集制作交接包\n\n"
        "先打开 数据集制作交接说明.html，再按说明校验与复现。\n\n"
        "项目：https://github.com/SliverBronya/TreeWeaver\n\n"
        "当前是资格样例，training_allowed=false，尚未完成DBH/材积真值。\n\n"
        "包内含29棵fig与7份环境素材；Blender及Python需按说明单独准备。\n"
        "这些是当前项目既有资产的定向交接副本，许可和原始来源仍待核验，"
        "该清单不授予新的转载许可；不要把原始资产直接上传公开仓库。\n",
        encoding="utf-8",
    )
    (stage / "给组员的消息.txt").write_text(
        "请接手完善TreeWeaver的合成树数据集。\n"
        "GitHub：https://github.com/SliverBronya/TreeWeaver\n"
        "在线交接说明：https://github.com/SliverBronya/TreeWeaver/blob/main/"
        "DATASET_BUILDER_HANDOFF_2026-11-15.md\n\n"
        "附件解压后，先打开数据集制作交接说明.html，按第五节校验并复现一张。\n"
        "确认后按第六节改善5%至25%遮挡、背景真实感、深度一致性和主干语义，"
        "先交16场景试制批，不急于批量生产或训练。\n"
        "包内有29棵fig、7份环境素材、源码和带真值的当前样例；"
        "Python和Blender按说明单独准备。DBH与材积尚未有合格真值。\n",
        encoding="utf-8",
    )
    manifest = {
        "version": "treeweaver-dataset-builder-20261115-v1",
        "created_at_utc": datetime.now(UTC).isoformat(),
        "repository": "https://github.com/SliverBronya/TreeWeaver",
        "base_source_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "source_contains_working_tree_handoff_changes": True,
        "git_history_included": False,
        "fig_assets": 29,
        "environment_assets": len(selected_assets) - 29,
        "asset_redistribution_license_status": "unverified_existing_assets_direct_team_handoff",
        "training_allowed": False,
        "files": [
            {
                "path": p.relative_to(stage).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256(p),
            }
            for p in sorted(stage.rglob("*"))
            if p.is_file()
        ],
    }
    (stage / "HANDOFF_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    archive = out / "TreeWeaver-dataset-builder-20261115-v1.zip"
    print(f"BUILDING_ZIP files={len(manifest['files']) + 1}", flush=True)
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=3) as z:
        for path in sorted(stage.rglob("*")):
            if path.is_file():
                z.write(path, "TreeWeaver/" + path.relative_to(stage).as_posix())
    with zipfile.ZipFile(archive) as z:
        bad = z.testzip()
        if bad is not None:
            raise ValueError("ZIP CRC failure: " + bad)
    record = {
        "archive": str(archive),
        "bytes": archive.stat().st_size,
        "sha256": sha256(archive),
        "zip_crc_verified": True,
        "files_including_manifest": len(manifest["files"]) + 1,
    }
    (out / "package-verification.json").write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8"
    )
    (out / "SHA256SUMS.txt").write_text(
        record["sha256"] + "  " + archive.name + "\n", encoding="ascii"
    )
    print(json.dumps(record, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
