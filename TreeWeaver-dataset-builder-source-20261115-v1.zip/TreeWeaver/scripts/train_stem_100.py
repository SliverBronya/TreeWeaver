"""Train the stem head on the 100-scene Cycles pilot."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = Path(r"D:\TreeWeaver\reports\stem-depth-100-2026-11-06")
CKPT = ROOT / "reports" / "professional-stage4-coupling-2026-11-06" / "best.pth"
RES, MASK = 1024, 256


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def rgb(path, mean, std):
    image = Image.open(path).convert("RGB").resize((RES, RES), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.asarray(mean)) / np.asarray(std)
    return torch.from_numpy(array).permute(2, 0, 1)


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def resize(mask):
    t = torch.from_numpy(mask.astype(np.float32))[None, None]
    return F.interpolate(t, size=(MASK, MASK), mode="nearest")[0, 0] > 0.5


class StemDataset(Dataset):
    def __init__(self, scenes, mean, std):
        self.scenes = scenes
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.scenes)

    def __getitem__(self, index):
        scene = self.scenes[index]
        meta = json.loads((scene / "meta.json").read_text(encoding="utf-8"))
        boxes = torch.tensor(meta["boxes_xyxy"], dtype=torch.float32)
        boxes[:, [0, 2]] *= RES / MASK_WIDTH
        boxes[:, [1, 3]] *= RES / MASK_HEIGHT
        boxes[:, [0, 2]] = boxes[:, [0, 2]].clamp(0, RES - 1)
        boxes[:, [1, 3]] = boxes[:, [1, 3]].clamp(0, RES - 1)
        stems = torch.stack(
            [resize(alpha(scene / f"stem_{i}.png")) for i in range(1, len(meta["trees"]) + 1)]
        )
        return {
            "image": rgb(scene / "rgb.png", self.mean, self.std),
            "boxes": boxes,
            "stem": stems,
            "scene": scene.name,
        }


MASK_WIDTH, MASK_HEIGHT = 480, 270


def build(device):
    path = snapshot()
    processor = Sam2Processor.from_pretrained(path, local_files_only=True)
    mean = processor.image_processor.image_mean
    std = processor.image_processor.image_std
    sam2 = Sam2Model.from_pretrained(path, local_files_only=True).to(device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3, enable_stem=True).to(device)
    payload = torch.load(CKPT, map_location="cpu")
    state = payload["decoder"] if "decoder" in payload else payload
    model.decoder.load_state_dict(state, strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.decoder.named_parameters():
        if name.startswith(("stem_token", "stem_hypernet")):
            parameter.requires_grad_(True)
    return model, mean, std


def dice(logits, target):
    p = logits.sigmoid()
    inter = (p * target).sum()
    return 1 - (2 * inter + 1) / (p.sum() + target.sum() + 1)


def evaluate(model, loader, device):
    model.eval()
    values = []
    with torch.no_grad():
        for batch in loader:
            output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
            logits = output["stem_masks"][:, :, 0].sigmoid() > 0.5
            target = batch["stem"].to(device)
            for i in range(logits.shape[1]):
                inter = (logits[0, i] & target[0, i]).sum().item()
                union = (logits[0, i] | target[0, i]).sum().item()
                if union:
                    values.append(inter / union)
    return float(np.mean(values)) if values else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"exists: {args.output}")
    args.output.mkdir(parents=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, mean, std = build(device)
    scenes = sorted(p for p in DATA.iterdir() if p.is_dir())
    train = scenes[:70]
    val = scenes[70:85]
    test = scenes[85:100]
    train_loader = DataLoader(StemDataset(train, mean, std), batch_size=1, shuffle=True)
    val_loader = DataLoader(StemDataset(val, mean, std), batch_size=1)
    test_loader = DataLoader(StemDataset(test, mean, std), batch_size=1)
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(
        json.dumps(
            {
                "trainable": sum(p.numel() for p in parameters),
                "train": len(train),
                "val": len(val),
                "test": len(test),
            }
        ),
        flush=True,
    )
    optimizer = torch.optim.AdamW(parameters, lr=1e-3, weight_decay=1e-4)
    iterator = iter(train_loader)
    best = -1.0
    for step in range(1, args.steps + 1):
        optimizer.zero_grad(set_to_none=True)
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(train_loader)
            batch = next(iterator)
        output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
        logits = output["stem_masks"][:, :, 0]
        target = batch["stem"].to(device).to(logits.dtype)
        loss = F.binary_cross_entropy_with_logits(logits, target) + dice(logits, target)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        if step % 20 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 25 == 0 or step == args.steps:
            score = evaluate(model, val_loader, device)
            print(json.dumps({"eval_step": step, "stem_iou": score}), flush=True)
            if score > best:
                best = score
                torch.save(
                    {
                        "decoder": model.decoder.state_dict(),
                        "step": step,
                        "stem_iou": score,
                    },
                    args.output / "best.pth",
                )
    test_score = evaluate(model, test_loader, device)
    result = {"best_val_stem_iou": best, "test_stem_iou": test_score}
    (args.output / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

