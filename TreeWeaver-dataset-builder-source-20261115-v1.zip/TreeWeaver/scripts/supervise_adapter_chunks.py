"""One low-priority child at a time; release its memory after each short chunk."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from resource_guard import (  # noqa: E402
    assert_pretrained_experiment_allowed,
    lower_own_priority,
    memory_snapshot,
)


def main():
    assert_pretrained_experiment_allowed()
    parser = argparse.ArgumentParser()
    parser.add_argument("--deadline-epoch", type=float, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[20261109, 20261110, 20261111])
    args = parser.parse_args()
    lower_own_priority()
    root = ROOT / "reports/two-hour-development-2026-11-09/adapter_trials_v2"
    root.mkdir(parents=True, exist_ok=True)
    records = []
    for seed in args.seeds:
        baseline = None
        for arm in ("mask_readout", "lora_only", "encoder_pf_only"):
            out = root / f"seed{seed}-{arm}"
            while time.time() < args.deadline_epoch - 100:
                assert_pretrained_experiment_allowed()
                if memory_snapshot()["available_ram_bytes"] < 4 * 1024**3:
                    print("waiting for 4GiB preflight RAM", flush=True)
                    time.sleep(5)
                    continue
                progress = out / (arm + "-progress.pth")
                result_path = out / "results.json"
                completed = 0
                if result_path.exists():
                    result = json.loads(result_path.read_text()).get(arm, {})
                    completed = result.get("completed_steps", 0)
                    if completed == 600 and result.get("validation") is not None:
                        if arm == "mask_readout":
                            baseline = result_path
                        print("arm finished", seed, arm, flush=True)
                        break
                if out.exists() and not progress.exists():
                    print("stopped: previous child has no recoverable checkpoint", out, flush=True)
                    return
                command = [
                    str(ROOT / ".worker-envs/sam2-shared/Scripts/python.exe"),
                    str(ROOT / "scripts/train_encoder_adapter_controls.py"),
                    "--steps",
                    "600",
                    "--seed",
                    str(seed),
                    "--arms",
                    arm,
                    "--chunk-steps",
                    "25",
                    "--out",
                    str(out),
                    "--deadline-epoch",
                    str(args.deadline_epoch),
                ]
                if progress.exists():
                    command.append("--resume")
                if baseline is not None:
                    command.extend(["--baseline-json", str(baseline)])
                with (root / "children.log").open("a", encoding="utf-8") as log:
                    process = subprocess.run(
                        command,
                        cwd=ROOT,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                    )
                item = {
                    "utc_epoch": time.time(),
                    "seed": seed,
                    "arm": arm,
                    "returncode": process.returncode,
                }
                if result_path.exists():
                    result = json.loads(result_path.read_text()).get(arm, {})
                    item["completed_steps"] = result.get("completed_steps", 0)
                records.append(item)
                (root / "supervision.json").write_text(json.dumps(records, indent=2))
                print(item, flush=True)
                if process.returncode != 0 or item.get("completed_steps", 0) <= completed:
                    print(
                        "stopped: no progress or child failed; no automatic heavy retry", flush=True
                    )
                    return
                time.sleep(2)
            if time.time() >= args.deadline_epoch - 100:
                return


if __name__ == "__main__":
    main()
