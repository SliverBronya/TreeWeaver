"""Controlled visible-only adaptation: readout, image LoRA, encoder prompt focus."""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import random
import sys
import time
from collections import OrderedDict
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from experiment_resume import (  # noqa: E402
    RESUME_SCHEMA,
    validate_resume_checkpoint,
    validate_resume_recipe,
)
from part_readout_objective import part_loss  # noqa: E402
from research_protocol import (  # noqa: E402
    assert_training_allowed,
    hash_files,
    pinned_snapshot,
    sha256_file,
)
from resource_guard import (  # noqa: E402
    ExperimentGuard,
    ResourceLimit,
    assert_pretrained_experiment_allowed,
    lower_own_priority,
)
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

RUN_OUTPUT = None
from whole_tree_objective import competitive_decode  # noqa: E402


def main():
    global RUN_OUTPUT
    assert_pretrained_experiment_allowed()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261109)
    parser.add_argument("--steps", type=int, default=1200)
    parser.add_argument(
        "--arms", nargs="+", default=["mask_readout", "lora_only", "encoder_pf_only"]
    )
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--chunk-steps", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--baseline-json", type=Path)
    parser.add_argument("--pf-null-token", action="store_true")
    parser.add_argument("--deadline-epoch", type=float, default=float("inf"))
    args = parser.parse_args()
    if args.steps < 1 or args.chunk_steps < 0:
        parser.error("steps must be positive and chunk-steps must be nonnegative")
    if set(args.arms) - {"mask_readout", "lora_only", "encoder_pf_only", "lora_pf"}:
        raise ValueError("unknown arm")
    if args.resume and len(args.arms) != 1:
        raise ValueError("resume one arm at a time")
    torch.manual_seed(args.seed)
    torch.set_num_threads(2)
    lower_own_priority()
    guard = ExperimentGuard()
    guard.inspect()
    if torch.cuda.is_available():
        torch.cuda.set_per_process_memory_fraction(0.25)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    roots = [
        ROOT / "reports/fig-paired-v6-framing-30-2026-11-08",
        ROOT / "reports/mixed-identity-layout-qualification-2026-11-08",
    ]
    scopes = [assert_training_allowed(p) for p in roots]
    datasets = [PairedFigDataset(p, "train") for p in roots]
    validation = PairedFigDataset(roots[0], "validation")
    pairs = [
        (di, i, q)
        for di, data in enumerate(datasets)
        for i, r in enumerate(data.items)
        for q in range(len(r["instances"]))
    ]
    train_assets = {x["asset"] for d in datasets for r in d.items for x in r["instances"]}
    val_assets = {x["asset"] for r in validation.items for x in r["instances"]}
    if train_assets & val_assets:
        raise ValueError("cross-corpus source leakage")
    rng = random.Random(args.seed)
    order = []
    while len(order) < args.steps:
        epoch = pairs.copy()
        rng.shuffle(epoch)
        order.extend(epoch)
    order = order[: args.steps]
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    owner = ROOT / "reports/ownership-query-feature-ablation-2026-11-08/query_features-final.pth"
    protocol = {
        "seed": args.seed,
        "seed_scope": "new adapter initialization and sample order; common initialization per arm",
        "resource_limits": {
            "threads": 2,
            "min_free_ram_GiB": 3,
            "gpu_fraction": 0.25,
            "max_gpu_C": 76,
            "cache_records": 0,
            "empty_cuda_cache_each_step": True,
            "step_pause_s": 0.15,
        },
        "precision": "BF16 autocast training; FP32 evaluation; sequential encoder queries",
        "steps": args.steps,
        "lr": 0.0001,
        "weight_decay": 0.0001,
        "arms": args.arms,
        "sam_revision": REVISION,
        "prior_sha256": sha256_file(prior),
        "owner_head_sha256": sha256_file(owner),
        "data_scopes": scopes,
        "train_query_examples": len(pairs),
        "order": order,
        "training_query_batch": 1,
        "lora_rank": 4,
        "encoder_pf_rank": 16,
        "encoder_focus_null_token": args.pf_null_token,
        "global_pf_blocks": [5, 7, 9],
        "same_architecture": "all arms allocate zero-start LoRA/PF; inactive adapters frozen",
        "prompts": "same GT visible box + same native positive per queried tree, no added clicks",
        "supervision": "native known visible BCE+Dice; no amodal, curve, part or layer losses",
        "ownership_heads": "fixed first predeclared query-feature candidate, no owner training",
        "validation": "old v6 native640x360; GT prompts; oracle development only",
        "test_accessed": False,
        "promoted": False,
    }
    sources = [
        Path(__file__),
        ROOT / "workers/tree_models/encoder_prompt_focus.py",
        ROOT / "workers/tree_models/sam2_occlusion.py",
        ROOT / "workers/tree_models/encoder_adapters.py",
        ROOT / "workers/tree_models/ownership_features.py",
        ROOT / "workers/tree_models/paired_fig_dataset.py",
        ROOT / "workers/tree_models/part_readout_objective.py",
        ROOT / "workers/tree_models/experiment_resume.py",
    ]
    content_hashes = {}
    for data in [*datasets, validation]:
        paths = {data.root / "paired-samples.json", data.root / "splits.json"}
        for row in data.items:
            paths.add(data._path(row["image"]))
            for item in row["instances"]:
                paths.update(
                    data._path(value)
                    for value in item.values()
                    if isinstance(value, str) and value.endswith(".png")
                )
        content_hashes[str(data.root) + ":" + data.items[0]["split"]] = hash_files(paths, data.root)
    recipe_keys = (
        "seed",
        "steps",
        "lr",
        "weight_decay",
        "sam_revision",
        "prior_sha256",
        "owner_head_sha256",
        "training_query_batch",
        "lora_rank",
        "encoder_pf_rank",
        "encoder_focus_null_token",
        "global_pf_blocks",
        "prompts",
        "supervision",
        "precision",
    )
    recipe = {key: protocol[key] for key in recipe_keys}
    recipe["order"] = [list(item) for item in order]
    recipe["input_content_sha256"] = content_hashes
    recipe["source_sha256"] = {str(path.relative_to(ROOT)): sha256_file(path) for path in sources}
    protocol["immutable_recipe"] = recipe
    baseline_payload = None
    if args.baseline_json:
        baseline_payload = json.loads(args.baseline_json.read_text(encoding="utf-8"))
        if baseline_payload.get("immutable_recipe") != recipe:
            raise ValueError("cached baseline has a different or unverified immutable recipe")
    previous = None
    if args.resume:
        checkpoint_path = args.out / (args.arms[0] + "-progress.pth")
        previous = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
        validate_resume_recipe(previous, recipe)
        saved_protocol = json.loads((args.out / "protocol.json").read_text(encoding="utf-8"))
        if saved_protocol.get("immutable_recipe") != recipe:
            raise ValueError("saved protocol and atomic checkpoint disagree")
    else:
        args.out.mkdir()
        (args.out / "source").mkdir()
        write(args.out / "protocol.json", protocol)
        for path in sources:
            (args.out / "source" / path.name).write_bytes(path.read_bytes())
    RUN_OUTPUT = args.out
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = (
        Sam2OcclusionModel(
            base,
            encoder_lora_rank=4,
            encoder_focus_rank=16,
            encoder_focus_chunked=True,
            encoder_focus_null_token=args.pf_null_token,
            query_ownership=True,
        )
        .to(device)
        .eval()
    )
    model.decoder.load_state_dict(
        torch.load(prior, map_location="cpu", weights_only=True)["decoder"], strict=True
    )
    for name, state in torch.load(owner, map_location="cpu", weights_only=True)["heads"].items():
        getattr(model.decoder, name).load_state_dict(state, strict=True)
    initial_path = args.out / "initial-state.pth"
    if not args.resume:
        torch.save(model.state_dict(), initial_path)

    def tensor_hash(value):
        return hashlib.sha256(value.detach().cpu().numpy().tobytes()).hexdigest()

    initial_hashes = {k: tensor_hash(v) for k, v in model.state_dict().items()}
    if args.resume:
        original_hashes = json.loads((args.out / "initial-tensor-hashes.json").read_text())
        if initial_hashes != original_hashes:
            raise ValueError("fresh initial tensors changed; original checkpoint preserved")
    else:
        write(args.out / "initial-tensor-hashes.json", initial_hashes)
    samples = OrderedDict()

    def get_sample(di, index):
        if (di, index) not in samples:
            data = datasets[di]
            row = data.items[index]
            sample = data.sample(index)
            sample["native_visible"] = np.stack(
                [data._native_mask(x["visible"]) for x in row["instances"]]
            )
            sample["native_known"] = ~np.stack(
                [data._native_mask(x["raster_unknown"]) for x in row["instances"]]
            )
            samples[di, index] = sample
            while len(samples) > 1:
                samples.popitem(last=False)
        samples.move_to_end((di, index))
        return samples[di, index]

    @torch.no_grad()
    def evaluate():
        model.eval()
        rows = []
        for index, record in enumerate(validation.items):
            if record["condition"] != "scene":
                continue
            guard.inspect()
            sample = validation.sample(index)
            inputs, _ = tensors(sample, device)
            result = model(**inputs)
            target = np.stack([validation._native_mask(x["visible"]) for x in record["instances"]])
            common = ~np.stack(
                [validation._native_mask(x["raster_unknown"]) for x in record["instances"]]
            ).any(0)
            raw = F.interpolate(
                result["masks"][0], target.shape[-2:], mode="bilinear", align_corners=False
            )[:, 0].cpu()
            own = F.interpolate(
                result["ownership_logits"], target.shape[-2:], mode="bilinear", align_corners=False
            )[0].cpu()
            for mode, pred in {
                "independent": raw > 0,
                "mask_winner": competitive_decode(raw),
                "query_owner": competitive_decode(raw, own),
            }.items():
                pred = pred.numpy() & common
                truth = target & common
                for q in range(len(target)):
                    p, t = pred[q], truth[q]
                    intersection = (p & t).sum()
                    foreign = np.delete(truth, q, 0).any(0) & ~t
                    row = {
                        "id": record["id"],
                        "query": q,
                        "multi": len(target) > 1,
                        "mode": mode,
                        "iou": float(intersection / max((p | t).sum(), 1)),
                        "recall": float(intersection / max(t.sum(), 1)),
                        "neighbour_fraction": float((p & foreign).sum() / max(p.sum(), 1)),
                    }
                    for part in ("crown", "stem"):
                        support = (
                            validation._native_mask(record["instances"][q]["visible_" + part])
                            & common
                        )
                        support &= ~validation._native_mask(
                            record["instances"][q]["visible_part_unknown"]
                        )
                        row[part + "_recall"] = (
                            float((p & support).sum() / support.sum()) if support.any() else None
                        )
                    rows.append(row)
        summary = {}
        for mode in ("independent", "mask_winner", "query_owner"):
            selected = [r for r in rows if r["mode"] == mode and r["multi"]]
            summary[mode] = {
                k: float(np.mean([r[k] for r in selected if r[k] is not None]))
                for k in ("iou", "recall", "neighbour_fraction", "crown_recall", "stem_recall")
            }
        return {"multi_instance_macro": summary, "records": rows}

    results = {
        "immutable_recipe": recipe,
        "initial": baseline_payload["initial"]
        if baseline_payload
        else previous["initial_evaluation"]
        if args.resume
        else evaluate(),
    }
    if not args.resume:
        write(args.out / "results.json", results)
    for arm in args.arms:
        if time.time() > args.deadline_epoch - 120:
            break
        model.load_state_dict(
            torch.load(initial_path, map_location="cpu", weights_only=True, mmap=True), strict=True
        )
        model.requires_grad_(False)
        for name, parameter in model.named_parameters():
            enabled = (
                (arm == "mask_readout" and name.startswith("decoder.output_hypernetworks_mlps."))
                or (
                    arm in ("lora_only", "lora_pf")
                    and (name.endswith("lora_a") or name.endswith("lora_b"))
                )
                or (arm in ("encoder_pf_only", "lora_pf") and name.startswith("encoder_focus."))
            )
            parameter.requires_grad_(enabled)
        names = [n for n, p in model.named_parameters() if p.requires_grad]
        optimizer = torch.optim.AdamW(
            [p for p in model.parameters() if p.requires_grad], lr=0.0001, weight_decay=0.0001
        )
        checkpoint_path = args.out / (arm + "-progress.pth")
        start_step = 0
        history = []
        if args.resume:
            start_step, history = validate_resume_checkpoint(
                previous, recipe, arm=arm, trainable_names=names
            )
            state = model.state_dict()
            for key, value in previous["updated_parameters"].items():
                state[key] = value.to(device)
            model.load_state_dict(state, strict=True)
            optimizer.load_state_dict(previous["optimizer"])
            torch.set_rng_state(previous["cpu_rng"])
            if device == "cuda":
                torch.cuda.set_rng_state(previous["cuda_rng"])

        def save_progress(
            completed_steps,
            checkpoint_path=checkpoint_path,
            names=names,
            optimizer=optimizer,
            arm=arm,
            history=history,
        ):
            temporary = checkpoint_path.with_suffix(".tmp.pth")
            torch.save(
                {
                    "resume_schema": RESUME_SCHEMA,
                    "immutable_recipe": recipe,
                    "trainable_names": names,
                    "history": history,
                    "initial_evaluation": results["initial"],
                    "updated_parameters": {
                        k: v.cpu() for k, v in model.state_dict().items() if k in names
                    },
                    "optimizer": optimizer.state_dict(),
                    "completed_steps": completed_steps,
                    "arm": arm,
                    "protocol": protocol,
                    "cpu_rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state()
                    if device == "cuda"
                    else torch.get_rng_state(),
                },
                temporary,
            )
            temporary.replace(checkpoint_path)
            write(args.out / (arm + "-history.json"), history)
            write(args.out / (arm + "-progress.json"), {"completed_steps": completed_steps})

        started = time.time()
        model.train()
        complete = True
        for step, (di, index, query) in enumerate(order[start_step:], start_step + 1):
            if args.chunk_steps and step > start_step + args.chunk_steps:
                complete = False
                break
            if time.time() > args.deadline_epoch - 90:
                complete = False
                break
            try:
                resources = guard.inspect()
            except ResourceLimit as error:
                write(
                    args.out / (arm + "-resource-stop.json"),
                    {"error": str(error), "step": step - 1},
                )
                complete = False
                break
            sample = get_sample(di, index)
            inputs, _ = tensors(sample, device)
            for key in ("input_boxes", "input_points", "input_labels"):
                inputs[key] = inputs[key][:, query : query + 1]
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=device == "cuda"):
                result = model(**inputs)
            gt = torch.from_numpy(sample["native_visible"][query : query + 1])[None].to(device)
            valid = torch.from_numpy(sample["native_known"][query : query + 1])[None].to(device)
            logits = F.interpolate(
                result["masks"][0].float(), gt.shape[-2:], mode="bilinear", align_corners=False
            )[:, 0][None]
            loss = part_loss(logits, gt, valid)
            if not torch.isfinite(loss):
                raise ValueError("nonfinite visible loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            optimizer.step()
            loss_value = float(loss.detach())
            del result, logits, loss, inputs, gt, valid, sample
            samples.clear()
            if device == "cuda":
                torch.cuda.empty_cache()
            if step % 25 == 0:
                gc.collect()
            history.append(
                {
                    "step": step,
                    "data": di,
                    "record": index,
                    "query": query,
                    "loss": loss_value,
                }
            )
            if step % 100 == 0:
                save_progress(step)
            time.sleep(0.15)
            if step % 50 == 0:
                print(
                    json.dumps(
                        {
                            "arm": arm,
                            "step": step,
                            "loss": history[-1]["loss"],
                            "seconds": time.time() - started,
                            "resources": resources,
                            "peak_cuda_mb": torch.cuda.max_memory_allocated() / 2**20
                            if device == "cuda"
                            else None,
                        }
                    ),
                    flush=True,
                )
                write(args.out / (arm + "-history.json"), history)
        save_progress(len(history))
        changed = []
        for key, value in model.state_dict().items():
            if tensor_hash(value) != initial_hashes[key]:
                if key not in names:
                    raise ValueError("frozen tensor changed: " + key)
                changed.append(key)
        torch.save(
            {
                "updated_parameters": {
                    k: v.cpu() for k, v in model.state_dict().items() if k in names
                },
                "protocol": protocol,
                "arm": arm,
                "completed_steps": len(history),
                "budget_complete": complete,
            },
            args.out / (arm + "-final.pth"),
        )
        results[arm] = {
            "validation": evaluate() if complete else None,
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "changed_keys": changed,
            "frozen_weights_unchanged": True,
            "seconds": time.time() - started,
            "budget_complete": complete,
            "completed_steps": len(history),
        }
        write(args.out / "results.json", results)
        print(
            arm,
            "completed_steps",
            len(history),
            "budget_complete",
            complete,
            "validation",
            results[arm]["validation"],
            flush=True,
        )
        if not complete:
            break


if __name__ == "__main__":
    try:
        main()
    except (ResourceLimit, RuntimeError) as error:
        if not isinstance(error, ResourceLimit) and "out of memory" not in str(error).lower():
            raise
        if RUN_OUTPUT is not None:
            write(
                RUN_OUTPUT / "resource-stop.json",
                {"error": str(error), "budget_complete": False, "promoted": False},
            )
        print("RESOURCE STOP; no retry and no other processes changed:", str(error), flush=True)
        raise SystemExit(75) from error
