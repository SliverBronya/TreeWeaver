"""Export one audited two-mesh olive; wood stays part-unknown, never fake trunk GT."""

from __future__ import annotations

import json
import struct
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from fig_data_protocol import material_part, sha256_file, validate_plan  # noqa: E402


def main():
    candidates = json.loads((ROOT / "reports/nonfig-asset-audit-2026-11-08.json").read_text())[
        "candidates"
    ]
    source = next(row for row in candidates if row["path"].endswith("/olive_tree.blend"))
    origin = ROOT / source["path"]
    if sha256_file(origin) != source["sha256"]:
        raise ValueError("source changed after audit")
    native = "--native" in sys.argv
    output = ROOT / (
        "tools/assets/qualified-extra/olive_tree_native_qualification_v3.blend"
        if native
        else "tools/assets/qualified-extra/olive_tree_whole_qualification_v2.glb"
    )
    if output.exists():
        raise FileExistsError(output)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    names = ("OLIVE wood", "OLIVE LEAFS")
    with bpy.data.libraries.load(str(origin), link=False) as (available, requested):
        if not set(names) <= set(available.objects):
            raise ValueError("audited meshes missing")
        requested.objects = list(names)
    records = []
    for obj in requested.objects:
        bpy.context.collection.objects.link(obj)
        transform = obj.matrix_world.copy()
        obj.parent = None
        obj.matrix_world = transform
        obj.hide_render = obj.hide_viewport = False
        obj.hide_set(False)
        for slot in obj.material_slots:
            if slot.material is None:
                slot.material = bpy.data.materials.get(
                    "QualifiedOlive_Unassigned"
                ) or bpy.data.materials.new("QualifiedOlive_Unassigned")
            mat = slot.material
            if mat.name == "Procedural Tree Bark":
                mat.name = "QualifiedOlive_WoodUnknown"
            elif mat.name == "leaf.olive":
                mat.name = "QualifiedOlive_Leaf"
            material_part(mat.name)
        geometry_cleaned = obj.data.validate(clean_customdata=False)
        records.append(
            {
                "mesh": obj.name,
                "geometry_validation_changed": geometry_cleaned,
                "vertices": len(obj.data.vertices),
                "material_faces": {
                    str(i): sum(p.material_index == i for p in obj.data.polygons)
                    for i in range(len(obj.material_slots))
                },
            }
        )
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
    for image in bpy.data.images:
        if (
            image.source == "FILE"
            and not image.packed_file
            and not Path(bpy.path.abspath(image.filepath)).is_file()
        ):
            raise ValueError(f"missing image {image.name}")
    bpy.context.view_layer.update()
    if native:
        bpy.ops.file.pack_all()
        bpy.ops.wm.save_as_mainfile(filepath=str(output), check_existing=False)
    else:
        bpy.ops.export_scene.gltf(
            filepath=str(output), export_format="GLB", use_selection=True, export_apply=True
        )
        payload = output.read_bytes()
        length = struct.unpack("<I", payload[12:16])[0]
        gltf = json.loads(payload[20 : 20 + length])
        if not gltf.get("meshes") or len(payload) < 1000000:
            raise ValueError("empty/incomplete export")
    plan = json.loads((ROOT / "reports/mixed-tree-grounded-plan-2026-11-08.json").read_text())
    identity = output.stem
    plan["asset_pools"]["train"].append(identity)
    plan["asset_manifest"][identity] = {
        "path": str(output),
        "sha256": sha256_file(output),
        "source_family": "olive_tree",
        "source_blend": str(origin),
        "source_blend_sha256": source["sha256"],
        "source_meshes": names,
        "stem_truth_available": False,
        "wood_semantics": "unknown; includes trunk and crown branches",
        "license_provenance_status": "pending; not admitted to formal training",
        "status": "render/label qualification only",
        "mesh_audit": records,
    }
    magnolia = "southern_magnolia_qualified_v3"
    fig = plan["asset_pools"]["train"][0]
    for number, trees, overlap in (
        (34, [identity], 0),
        (35, [identity, magnolia], 0.15),
        (36, [fig, identity, magnolia], 0.30),
    ):
        plan["records"].append(
            {
                "id": number,
                "split": "train",
                "trees": trees,
                "scene_seed": 20261108 + number,
                "requested_bbox_overlap": overlap,
                "spacing_class": "single" if number == 34 else "mixed_qualification",
                "minimum_origin_separation_ratio": 0.6,
            }
        )
    plan["qualification_only"] = True
    plan["qualification_note"] = "Render34..36 only; train disabled, source/wood semantics pending."
    validate_plan(plan)
    path = ROOT / (
        "reports/olive-mixed-native-v3-plan-2026-11-08.json"
        if native
        else "reports/olive-mixed-qualification-v2-plan-2026-11-08.json"
    )
    with path.open("x", encoding="utf-8") as stream:
        json.dump(plan, stream, indent=2)
    print(json.dumps({"export": str(output), "plan": str(path), "mesh_audit": records}))


if __name__ == "__main__":
    main()
