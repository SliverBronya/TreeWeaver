"""Tests for encoder adapters."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

torch = pytest.importorskip("torch")

from encoder_adapters import DepthAdapter, LoRALinear, PromptFocus  # noqa: E402


def test_lora_matches_base_at_initialization():
    base = torch.nn.Linear(16, 32)
    layer = LoRALinear(base, rank=4)
    inputs = torch.randn(2, 16)
    assert torch.allclose(layer(inputs), base(inputs), atol=1e-6)
    assert all(not parameter.requires_grad for parameter in layer.base.parameters())
    assert layer.lora_a.requires_grad and layer.lora_b.requires_grad


def test_focus_zero_strength_preserves_features():
    focus = PromptFocus(strength=0.0)
    features = [torch.randn(2, 4, 8, 8), torch.randn(2, 8, 4, 4)]
    boxes = torch.tensor([[[0.0, 0.0, 512.0, 512.0], [512.0, 512.0, 1024.0, 1024.0]]]).repeat(
        2, 1, 1
    )
    output = focus(features, boxes)
    for actual, feature in zip(output, features, strict=True):
        torch.testing.assert_close(
            actual, feature[:, None].expand(-1, 2, -1, -1, -1), rtol=0, atol=0
        )


def test_focus_uses_all_signed_points_and_ignores_padding():
    points = torch.tensor([[[[20.0, 20.0], [60.0, 60.0], [100.0, 100.0], [float("nan"), 0.0]]]])
    labels = torch.tensor([[[1, 0, 1, -1]]])
    prior = PromptFocus._prior(points=points, labels=labels, size=128, coordinate_size=128)
    assert prior[0, 0, 20, 20] > 0
    assert prior[0, 0, 60, 60] < 0
    assert prior[0, 0, 100, 100] > 0
    reordered = PromptFocus._prior(
        points=points.flip(2), labels=labels.flip(2), size=128, coordinate_size=128
    )
    torch.testing.assert_close(prior, reordered, rtol=0, atol=0)


def test_focus_queries_are_independent_and_equivariant():
    focus = PromptFocus(strength=0.5)
    features = [torch.ones(1, 3, 32, 32)]
    points = torch.tensor([[[[128.0, 128.0]], [[768.0, 768.0]]]])
    labels = torch.ones(1, 2, 1, dtype=torch.long)
    before = focus(features, points=points, labels=labels)[0]
    after = focus(features, points=points.flip(1), labels=labels.flip(1))[0]
    torch.testing.assert_close(after, before.flip(1), rtol=0, atol=0)
    assert before[0, 0, 0, 4, 4] > 1 and before[0, 1, 0, 4, 4] == 1
    assert before[0, 1, 0, 24, 24] > 1
    before.sum().backward()
    assert torch.isfinite(focus.strength.grad) and focus.strength.grad.abs() > 0


def test_focus_rejects_unlabelled_points_and_mismatched_queries():
    points = torch.zeros(1, 2, 3, 2)
    with pytest.raises(ValueError, match="labels"):
        PromptFocus._prior(points=points)
    with pytest.raises(ValueError, match="counts"):
        PromptFocus._prior(boxes=torch.zeros(1, 1, 4), points=points, labels=torch.ones(1, 2, 3))


def test_focus_checkpoint_rejects_legacy_semantics_even_with_non_strict_loading():
    focus = PromptFocus()
    with pytest.raises(RuntimeError, match="explicit migration"):
        focus.load_state_dict({"strength": torch.tensor(0.5)}, strict=False)
    fresh = PromptFocus()
    fresh.load_state_dict(focus.state_dict(), strict=True)
    assert int(fresh.focus_schema) == 2


def test_depth_adapter_changes_feature_shape():
    adapter = DepthAdapter(channels=32)
    feature = torch.zeros(1, 32, 16, 16)
    depth = torch.ones(1, 1, 64, 64)
    output = adapter(feature, depth)
    assert output.shape == feature.shape
    assert not torch.allclose(output, feature)
