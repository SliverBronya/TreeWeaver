import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from identity_prompts import point_prompt_suite  # noqa: E402


def test_signed_points_have_correct_native_membership_and_equal_budget():
    masks = np.zeros((3, 40, 60), bool)
    for q in range(3):
        masks[q, 5:30, 3 + q * 18 : 12 + q * 18] = True
    suite = point_prompt_suite(masks)
    for mode, (points, labels) in suite.items():
        assert points.shape[:2] == labels.shape
        if mode != "single_positive":
            assert (labels != -1).sum(1).tolist() == [3, 3, 3]
        for q in range(3):
            for p, label in zip(points[q], labels[q], strict=True):
                x, y = np.floor(p * np.array([60, 40]) / 1024).astype(int)
                if label == 1:
                    assert masks[q, y, x]
                if label == 0:
                    assert not masks[q, y, x] and masks[:, y, x].any()


def test_unknown_and_overlapping_annotations_cannot_be_negative_anchors():
    masks = np.zeros((2, 20, 30), bool)
    masks[0, 2:18, 2:16] = 1
    masks[1, 2:18, 12:28] = 1
    valid = np.ones_like(masks)
    valid[:, :, 5:8] = 0
    points, labels = point_prompt_suite(masks, valid)["positive_neighbour_negatives"]
    for p, _label in zip(points.reshape(-1, 2), labels.ravel(), strict=True):
        x, y = np.floor(p * np.array([30, 20]) / 1024).astype(int)
        assert valid[:, y, x].all() and masks[:, y, x].sum() == 1


def test_empty_support_rejected():
    with pytest.raises(ValueError, match="known visible"):
        point_prompt_suite(np.zeros((2, 10, 10), bool))
