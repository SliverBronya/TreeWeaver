"""Small synchronous API; heavyweight vision runs through isolated workers."""

from __future__ import annotations

from dataclasses import asdict

try:
    from fastapi import FastAPI
except ImportError as exc:  # pragma: no cover - only occurs without the api extra
    raise RuntimeError('Install the API dependencies with: pip install -e ".[api]"') from exc

from treeweaver import __version__
from treeweaver.calibration.scale import estimate_metric_scale
from treeweaver.domain.models import ScaleAnchor

app = FastAPI(title="TreeWeaver API", version=__version__)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@app.post("/api/v1/calibration/scale")
def calibrate_scale(payload: list[dict[str, float | str]]) -> dict[str, float | int]:
    anchors = tuple(
        ScaleAnchor(
            kind=str(item["kind"]),
            metric_length_m=float(item["metric_length_m"]),
            reconstructed_length=float(item["reconstructed_length"]),
            confidence=float(item.get("confidence", 1.0)),
        )
        for item in payload
    )
    return asdict(estimate_metric_scale(anchors))
