"""HTTP boundary for TreeWeaver."""
