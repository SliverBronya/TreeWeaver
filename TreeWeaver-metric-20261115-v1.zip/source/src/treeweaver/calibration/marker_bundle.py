"""Detect a scale marker across reconstructed capture frames."""

from __future__ import annotations

import json
from pathlib import Path

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.calibration.fiducial import detect_aruco_marker
from treeweaver.calibration.multiview_anchor import MarkerObservation, triangulate_marker_anchor
from treeweaver.io.session import load_capture_session
from treeweaver.providers.colmap_text import load_colmap_text_model


def register_aruco_scale(
    capture_manifest: str | Path,
    colmap_text_model: str | Path,
    output_json: str | Path,
    *,
    marker_id: int,
    edge_length_m: float,
    dictionary: str = "4x4_50",
) -> Path:
    session_path = Path(capture_manifest).resolve()
    validation = load_capture_session(session_path)
    reconstruction = load_colmap_text_model(colmap_text_model)
    frame_by_name = {Path(frame.image_path).name: frame for frame in validation.session.frames}
    camera_by_name = {
        pose.image_name: ProjectionCamera(
            pose.image_name, pose, frame_by_name[pose.image_name].intrinsics
        )
        for pose in reconstruction.poses
        if pose.image_name in frame_by_name
    }
    observations: list[MarkerObservation] = []
    for image_name in sorted(camera_by_name):
        frame = frame_by_name[image_name]
        corners = detect_aruco_marker(
            session_path.parent / frame.image_path, marker_id, dictionary=dictionary
        )
        if corners is not None:
            observations.append(MarkerObservation(image_name, corners))
    marker = triangulate_marker_anchor(
        tuple(camera_by_name.values()),
        tuple(observations),
        edge_length_m=edge_length_m,
    )
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "treefactor-anchors-1.0",
                "source": {
                    "kind": "aruco_multiview_triangulation",
                    "marker_id": marker_id,
                    "dictionary": dictionary,
                    "detected_views": len(observations),
                    "mean_reprojection_error_px": marker.mean_reprojection_error_px,
                },
                "anchors": [
                    {
                        "kind": item.kind,
                        "metric_length_m": item.metric_length_m,
                        "endpoint_a": item.endpoint_a.tolist(),
                        "endpoint_b": item.endpoint_b.tolist(),
                        "confidence": item.confidence,
                    }
                    for item in marker.correspondences
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return destination
