"""Robust metric-scale estimation from user-visible or sensor anchors."""

from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from treeweaver.domain.models import ScaleAnchor


@dataclass(frozen=True, slots=True)
class ScaleEstimate:
    metres_per_unit: float
    standard_deviation: float
    confidence: float
    inlier_count: int


def _weighted_median(values: list[tuple[float, float]]) -> float:
    ordered = sorted(values)
    half = sum(weight for _, weight in ordered) / 2
    accumulated = 0.0
    for value, weight in ordered:
        accumulated += weight
        if accumulated >= half:
            return value
    return ordered[-1][0]


def estimate_metric_scale(anchors: tuple[ScaleAnchor, ...]) -> ScaleEstimate:
    """Fuse anchors while rejecting ratios far from the weighted median.

    Anchors may be a marker, measured camera height, user height, or native
    metric-depth alignment. At least one explicit metric fact is mandatory;
    monocular RGB alone cannot identify absolute scale.
    """

    usable = tuple(anchor for anchor in anchors if anchor.reconstructed_length is not None)
    if not usable:
        raise ValueError("scale estimation requires a reconstructed measurement of an anchor")

    ratios = [(a.metric_length_m / a.reconstructed_length, a.confidence) for a in usable]  # type: ignore[operator]
    centre = _weighted_median(ratios)
    deviations = [abs(ratio - centre) for ratio, _ in ratios]
    mad = median(deviations)
    tolerance = max(3.5 * 1.4826 * mad, centre * 0.03)
    inliers = [(ratio, weight) for ratio, weight in ratios if abs(ratio - centre) <= tolerance]
    if not inliers:
        inliers = ratios

    total_weight = sum(weight for _, weight in inliers)
    estimate = sum(value * weight for value, weight in inliers) / total_weight
    variance = sum(weight * (value - estimate) ** 2 for value, weight in inliers) / total_weight
    diversity_bonus = min(1.0, len(inliers) / 3)
    confidence = min(0.99, (total_weight / len(usable)) * (0.7 + 0.3 * diversity_bonus))
    return ScaleEstimate(estimate, variance**0.5, confidence, len(inliers))
