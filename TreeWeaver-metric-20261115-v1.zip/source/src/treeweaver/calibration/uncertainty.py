"""Validation-only uncertainty calibration and split-conformal intervals."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil, sqrt


@dataclass(frozen=True, slots=True)
class CalibrationPair:
    truth: float
    estimate: float
    predicted_standard_deviation: float

    def __post_init__(self) -> None:
        if self.predicted_standard_deviation <= 0:
            raise ValueError("predicted standard deviation must be positive")


@dataclass(frozen=True, slots=True)
class UncertaintyCalibrator:
    standard_deviation_multiplier: float
    conformal_normalized_radius: float
    miscoverage: float
    calibration_count: int

    def calibrated_standard_deviation(self, predicted: float) -> float:
        if predicted <= 0:
            raise ValueError("predicted standard deviation must be positive")
        return predicted * self.standard_deviation_multiplier

    def conformal_interval(self, estimate: float, predicted: float) -> tuple[float, float]:
        radius = self.conformal_normalized_radius * predicted
        return estimate - radius, estimate + radius


def fit_uncertainty_calibrator(
    pairs: tuple[CalibrationPair, ...], *, miscoverage: float = 0.05
) -> UncertaintyCalibrator:
    """Fit Gaussian scale and finite-sample conformal radius on validation trees."""

    if len(pairs) < 5:
        raise ValueError("uncertainty calibration requires at least five independent trees")
    if not 0 < miscoverage < 1:
        raise ValueError("miscoverage must be in (0, 1)")
    normalized = sorted(
        abs(pair.estimate - pair.truth) / pair.predicted_standard_deviation for pair in pairs
    )
    multiplier = sqrt(sum(value**2 for value in normalized) / len(normalized))
    rank = min(len(normalized), ceil((len(normalized) + 1) * (1 - miscoverage)))
    radius = normalized[rank - 1]
    return UncertaintyCalibrator(multiplier, radius, miscoverage, len(pairs))
