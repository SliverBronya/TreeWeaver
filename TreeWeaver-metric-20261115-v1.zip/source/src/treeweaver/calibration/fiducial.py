"""Data-free OpenCV fiducial detection for explicit metric scale."""

from __future__ import annotations

from pathlib import Path
from typing import cast

import cv2
import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]

_DICTIONARIES = {
    "4x4_50": cv2.aruco.DICT_4X4_50,
    "5x5_100": cv2.aruco.DICT_5X5_100,
    "6x6_250": cv2.aruco.DICT_6X6_250,
}


def generate_aruco_marker_svg(
    output_path: str | Path,
    marker_id: int,
    *,
    edge_length_mm: float,
    dictionary: str = "4x4_50",
) -> Path:
    """Generate a physical-size SVG marker intended for 100% scale printing."""

    if marker_id < 0 or edge_length_mm <= 0:
        raise ValueError("marker id and physical edge length must be valid")
    if dictionary not in _DICTIONARIES:
        raise ValueError(f"unsupported marker dictionary: {dictionary}")
    modules = 6 if dictionary.startswith("4x4") else 7 if dictionary.startswith("5x5") else 8
    side = modules * 10
    bitmap = cv2.aruco.generateImageMarker(
        cv2.aruco.getPredefinedDictionary(_DICTIONARIES[dictionary]), marker_id, side
    )
    sampled = bitmap.reshape(modules, 10, modules, 10).mean(axis=(1, 3))
    rectangles = "".join(
        f'<rect x="{column}" y="{row}" width="1" height="1"/>'
        for row in range(modules)
        for column in range(modules)
        if sampled[row, column] < 128
    )
    label_height = max(8.0, edge_length_mm * 0.12)
    svg = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{edge_length_mm}mm" '
        f'height="{edge_length_mm + label_height}mm" viewBox="0 0 {modules} '
        f'{modules + label_height / edge_length_mm * modules}">\n'
        f'<rect width="{modules}" height="{modules}" fill="white"/>\n'
        f'<g fill="black">{rectangles}</g>\n'
        f'<text x="{modules / 2}" y="{modules + 0.65}" text-anchor="middle" '
        f'font-size="0.42">TreeWeaver {dictionary} ID {marker_id}; '
        f'edge {edge_length_mm:g} mm; print at 100%</text>\n'
        "</svg>\n"
    )
    destination = Path(output_path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(svg, encoding="utf-8")
    return destination


def detect_aruco_marker(
    image_path: str | Path, marker_id: int, *, dictionary: str = "4x4_50"
) -> FloatArray | None:
    """Return canonical clockwise marker corners or ``None`` when not visible."""

    if marker_id < 0:
        raise ValueError("marker id cannot be negative")
    if dictionary not in _DICTIONARIES:
        raise ValueError(f"unsupported marker dictionary: {dictionary}")
    image = cv2.imread(str(Path(image_path).resolve()), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(image_path)
    detector = cv2.aruco.ArucoDetector(
        cv2.aruco.getPredefinedDictionary(_DICTIONARIES[dictionary]),
        cv2.aruco.DetectorParameters(),
    )
    corners, ids, _ = detector.detectMarkers(image)
    if ids is None:
        return None
    matches = np.flatnonzero(ids.reshape(-1) == marker_id)
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        raise ValueError(f"marker id {marker_id} appears more than once")
    return cast(FloatArray, np.asarray(corners[int(matches[0])][0], dtype=np.float64))
