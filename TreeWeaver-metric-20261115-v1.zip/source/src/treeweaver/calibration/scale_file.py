"""File boundary for explicit anchor-derived metric scale."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from treeweaver.factor.file_optimization import load_anchor_correspondences
from treeweaver.reconstruction.scale_registration import estimate_scale_from_correspondences


def estimate_scale_file(anchors_json: str | Path, output_json: str | Path) -> Path:
    anchors = load_anchor_correspondences(anchors_json)
    estimate = estimate_scale_from_correspondences(anchors)
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "metric-scale-1.0",
                "anchors": str(Path(anchors_json).resolve()),
                **asdict(estimate),
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return destination
