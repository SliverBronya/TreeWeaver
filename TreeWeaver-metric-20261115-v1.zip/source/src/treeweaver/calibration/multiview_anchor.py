"""Triangulate a known planar marker into metric scale correspondences."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.reconstruction.scale_registration import AnchorCorrespondence

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class MarkerObservation:
    image_name: str
    corners_px: FloatArray
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if not self.image_name or self.corners_px.shape != (4, 2):
            raise ValueError("marker observation requires four ordered pixel corners")
        if not np.isfinite(self.corners_px).all() or not 0 < self.confidence <= 1:
            raise ValueError("marker pixels and confidence must be valid")


@dataclass(frozen=True, slots=True)
class TriangulatedMarker:
    corners_world: FloatArray
    mean_reprojection_error_px: float
    correspondences: tuple[AnchorCorrespondence, ...]


def _projection(camera: ProjectionCamera) -> FloatArray:
    intrinsics = camera.intrinsics
    matrix = np.array(
        [
            [intrinsics.fx, 0.0, intrinsics.cx],
            [0.0, intrinsics.fy, intrinsics.cy],
            [0.0, 0.0, 1.0],
        ]
    )
    extrinsics = np.column_stack(
        (camera.pose.rotation_world_to_camera, camera.pose.translation_world_to_camera)
    )
    return matrix @ extrinsics


def _triangulate(
    cameras: tuple[ProjectionCamera, ...], pixels: FloatArray, weights: FloatArray
) -> FloatArray:
    rows: list[FloatArray] = []
    for camera, pixel, weight in zip(cameras, pixels, weights, strict=True):
        projection = _projection(camera)
        root_weight = np.sqrt(weight)
        rows.append((pixel[0] * projection[2] - projection[0]) * root_weight)
        rows.append((pixel[1] * projection[2] - projection[1]) * root_weight)
    _, _, vh = np.linalg.svd(np.stack(rows), full_matrices=False)
    homogeneous = vh[-1]
    if abs(float(homogeneous[3])) < 1e-12:
        raise ValueError("marker triangulation is numerically degenerate")
    return cast(FloatArray, (homogeneous[:3] / homogeneous[3]).astype(np.float64, copy=False))


def triangulate_marker_anchor(
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[MarkerObservation, ...],
    *,
    edge_length_m: float,
    maximum_reprojection_error_px: float = 2.0,
) -> TriangulatedMarker:
    """Create four independent scale edges from two or more marker views."""

    if edge_length_m <= 0 or maximum_reprojection_error_px <= 0:
        raise ValueError("marker length and error threshold must be positive")
    camera_by_name = {camera.image_name: camera for camera in cameras}
    if len(camera_by_name) != len(cameras):
        raise ValueError("camera image names must be unique")
    usable = [item for item in observations if item.image_name in camera_by_name]
    if len(usable) < 2:
        raise ValueError("marker must be detected in at least two reconstructed views")
    selected_cameras = tuple(camera_by_name[item.image_name] for item in usable)
    weights = np.array([item.confidence for item in usable], dtype=np.float64)
    corners = np.stack(
        [
            _triangulate(
                selected_cameras,
                np.stack([item.corners_px[index] for item in usable]),
                weights,
            )
            for index in range(4)
        ]
    )
    reprojection_errors: list[float] = []
    for camera, observation in zip(selected_cameras, usable, strict=True):
        projection = _projection(camera)
        homogeneous = np.column_stack((corners, np.ones(4)))
        projected = (projection @ homogeneous.T).T
        if np.any(projected[:, 2] <= 0):
            raise ValueError("triangulated marker lies behind a camera")
        pixels = projected[:, :2] / projected[:, 2, None]
        reprojection_errors.extend(np.linalg.norm(pixels - observation.corners_px, axis=1))
    mean_error = float(np.mean(reprojection_errors))
    if mean_error > maximum_reprojection_error_px:
        raise ValueError(
            f"marker reprojection error {mean_error:.2f}px exceeds "
            f"{maximum_reprojection_error_px:.2f}px"
        )
    confidence = float(np.mean(weights) * np.exp(-mean_error / maximum_reprojection_error_px))
    edges = ((0, 1), (1, 2), (2, 3), (3, 0))
    correspondences = tuple(
        AnchorCorrespondence(
            kind=f"planar_marker_edge_{start}_{end}",
            metric_length_m=edge_length_m,
            endpoint_a=corners[start],
            endpoint_b=corners[end],
            confidence=max(0.05, min(1.0, confidence)),
        )
        for start, end in edges
    )
    return TriangulatedMarker(corners, mean_error, correspondences)
