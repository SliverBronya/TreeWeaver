"""Controlled synthetic trees for exercising geometry before field data exists."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.reconstruction.scale_registration import AnchorCorrespondence

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class SyntheticScenario:
    seed: int = 1
    height_m: float = 15.0
    dbh_cm: float = 35.0
    taper_m_per_m: float = -0.006
    metres_per_unit: float = 0.4
    trunk_points: int = 1000
    crown_points: int = 800
    ground_points: int = 500
    visible_arc_fraction: float = 1.0
    outlier_fraction: float = 0.0
    surface_noise_m: float = 0.008
    ground_slope_x: float = 0.0

    def __post_init__(self) -> None:
        if self.height_m <= 2 or self.dbh_cm <= 1 or self.metres_per_unit <= 0:
            raise ValueError("synthetic tree dimensions and scale must be positive")
        if min(self.trunk_points, self.crown_points, self.ground_points) < 40:
            raise ValueError("synthetic scene requires at least 40 points per part")
        if not 0 < self.visible_arc_fraction <= 1 or not 0 <= self.outlier_fraction < 0.8:
            raise ValueError("invalid synthetic visibility or outlier fraction")


@dataclass(frozen=True, slots=True)
class SyntheticTreeScene:
    trunk_points: FloatArray
    crown_points: FloatArray
    ground_points: FloatArray
    trunk_reliability: FloatArray
    ground_reliability: FloatArray
    anchors: tuple[AnchorCorrespondence, ...]
    truth: dict[str, float]


def generate_tree_scene(scenario: SyntheticScenario) -> SyntheticTreeScene:
    """Generate a tapered stem, ellipsoidal crown, sloped ground and scale marker."""

    rng = np.random.default_rng(scenario.seed)
    trunk_count = scenario.trunk_points
    axial = rng.uniform(0.0, scenario.height_m * 0.72, trunk_count)
    angle = rng.uniform(
        -np.pi * scenario.visible_arc_fraction,
        np.pi * scenario.visible_arc_fraction,
        trunk_count,
    )
    radius_dbh = scenario.dbh_cm / 200.0
    radius = radius_dbh + scenario.taper_m_per_m * (axial - 1.3)
    radius = np.maximum(radius, 0.015)
    radial_noise = rng.normal(0.0, scenario.surface_noise_m, trunk_count)
    trunk_metric = np.column_stack(
        (
            (radius + radial_noise) * np.cos(angle),
            (radius + radial_noise) * np.sin(angle),
            axial,
        )
    )
    outlier_count = round(trunk_count * scenario.outlier_fraction)
    trunk_reliability = np.ones(trunk_count, dtype=np.float64)
    if outlier_count:
        indices = rng.choice(trunk_count, outlier_count, replace=False)
        trunk_metric[indices, :2] += rng.normal(0.0, 0.35, (outlier_count, 2))
        trunk_reliability[indices] = 0.03

    direction = rng.normal(size=(scenario.crown_points, 3))
    direction /= np.linalg.norm(direction, axis=1, keepdims=True)
    shell = rng.uniform(0.25, 1.0, scenario.crown_points) ** (1 / 3)
    crown_radius = max(1.2, scenario.height_m * 0.22)
    crown_metric = direction * shell[:, None] * np.array(
        [crown_radius, crown_radius * 0.8, scenario.height_m * 0.28]
    )
    crown_metric += np.array([0.0, 0.0, scenario.height_m * 0.72])
    crown_metric[:, 2] = np.clip(crown_metric[:, 2], 0.2, scenario.height_m)
    crown_metric[np.argmax(crown_metric[:, 2]), 2] = scenario.height_m

    ground_xy = rng.uniform(-2.5, 2.5, (scenario.ground_points, 2))
    ground_z = (
        scenario.ground_slope_x * ground_xy[:, 0]
        + rng.normal(0.0, scenario.surface_noise_m, scenario.ground_points)
    )
    ground_metric = np.column_stack((ground_xy, ground_z))
    ground_reliability = np.ones(scenario.ground_points, dtype=np.float64)

    scale = scenario.metres_per_unit
    anchor = AnchorCorrespondence(
        kind="synthetic_one_metre_marker",
        metric_length_m=1.0,
        endpoint_a=np.array([2.0, 0.0, 0.0]) / scale,
        endpoint_b=np.array([3.0, 0.0, 0.0]) / scale,
        confidence=1.0,
    )
    return SyntheticTreeScene(
        trunk_metric / scale,
        crown_metric / scale,
        ground_metric / scale,
        trunk_reliability,
        ground_reliability,
        (anchor,),
        {
            "height_m": scenario.height_m,
            "dbh_cm": scenario.dbh_cm,
            "metres_per_unit": scale,
        },
    )
