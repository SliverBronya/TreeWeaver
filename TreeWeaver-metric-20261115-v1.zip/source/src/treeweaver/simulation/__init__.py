"""Synthetic fault injection for pre-field verification."""

from treeweaver.simulation.synthetic_tree import SyntheticScenario, generate_tree_scene

__all__ = ["SyntheticScenario", "generate_tree_scene"]
