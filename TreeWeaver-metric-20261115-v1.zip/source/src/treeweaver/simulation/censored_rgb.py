"""Layered RGB diagnostic scenes for exposed versus censored stem boundaries.

The renderer is deliberately simple and supplies perfect visible target masks.
It tests boundary classification conditional on segmentation, not field RGB
measurement. Hidden geometry is stored for scoring and never fed to the model.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
import numpy.typing as npt

from treeweaver.geometry.censored_stem import StemRowEvidence


@dataclass(frozen=True, slots=True)
class BoundaryObservation:
    y: int
    left: int
    right: int


@dataclass(frozen=True, slots=True)
class SyntheticBoundaryScene:
    group_id: int
    domain: str
    rgb: npt.NDArray[np.uint8]
    visible_mask: npt.NDArray[np.bool_]
    hidden_truth_mask: npt.NDArray[np.bool_]
    oracle_rows: tuple[StemRowEvidence, ...]
    true_width_px: float
    query_y: int


def _texture(rng: np.random.Generator, size: int, bark: bool) -> npt.NDArray[np.uint8]:
    base = rng.uniform(45, 190, size=3)
    noise = rng.normal(0, 16, (size, size)).astype(np.float32)
    smooth = np.asarray(cv2.GaussianBlur(noise, (0, 0), sigmaX=1.5, sigmaY=1.5), dtype=np.float32)
    if bark:
        streak = rng.normal(0, 15, (1, size)).astype(np.float32)
        smooth += streak
    rgb = base + smooth[:, :, None] + rng.normal(0, 3, (size, size, 3))
    return np.asarray(np.clip(rgb, 0, 255), dtype=np.uint8)


def observe_visible_rows(mask: npt.NDArray[np.bool_]) -> tuple[BoundaryObservation, ...]:
    if mask.ndim != 2 or min(mask.shape) < 32:
        raise ValueError("visible target mask must be a 2-D image at least 32 px across")
    result: list[BoundaryObservation] = []
    for y in np.linspace(12, mask.shape[0] - 13, 16).astype(int):
        xs = np.flatnonzero(mask[y])
        if len(xs) >= 4:
            result.append(BoundaryObservation(int(y), int(xs[0]), int(xs[-1])))
    return tuple(result)


def extract_boundary_patches(
    rgb: npt.NDArray[np.uint8], mask: npt.NDArray[np.bool_], *, radius: int = 16
) -> tuple[npt.NDArray[np.float32], tuple[BoundaryObservation, ...]]:
    """Only RGB and visible mask enter features. Right edges are flipped inward."""
    if rgb.shape != (*mask.shape, 3) or rgb.dtype != np.uint8 or radius < 1:
        raise ValueError("aligned RGB and visible target mask required")
    observations = observe_visible_rows(mask)
    channels = np.concatenate((rgb.astype(np.float32) / 255, mask[:, :, None]), axis=2)
    padded = np.pad(channels, ((radius, radius), (radius, radius), (0, 0)), mode="edge")
    patches: list[npt.NDArray[np.float32]] = []
    for row in observations:
        for side, x in enumerate((row.left, row.right)):
            patch = padded[row.y : row.y + 2 * radius + 1, x : x + 2 * radius + 1].copy()
            if side:
                patch = patch[:, ::-1].copy()
            patches.append(np.asarray(patch.transpose(2, 0, 1), dtype=np.float32))
    if not patches:
        return np.empty((0, 4, 2 * radius + 1, 2 * radius + 1), dtype=np.float32), observations
    return np.stack(patches), observations


def render_boundary_scene(group_id: int, domain: str = "standard") -> SyntheticBoundaryScene:
    if group_id < 0 or domain not in {
        "standard",
        "curved_occluders",
        "bark_occluders",
        "parallel_occluders",
    }:
        raise ValueError("invalid group ID or synthetic domain")
    rng = np.random.default_rng(group_id)
    size = 128
    query = size // 2
    width = float(rng.uniform(22, 44))
    center = float(rng.uniform(57, 71))
    lean = float(rng.uniform(-14, 14))
    taper = float(rng.uniform(-6, 6))
    yy, xx = np.mgrid[:size, :size]
    t = (yy - query) / size
    left = center - width / 2 + lean * t
    right = center + width / 2 + (lean + taper) * t
    truth = (xx >= left) & (xx <= right)
    background = _texture(rng, size, bool(rng.integers(2)))
    trunk_rgb = _texture(rng, size, True)
    rgb = background.copy()
    rgb[truth] = trunk_rgb[truth]
    occluder = np.zeros((size, size), dtype=np.uint8)
    scenario = group_id % 5
    if scenario == 4:
        # Entire side hidden: includes fundamentally ambiguous local observations.
        cut = int(round(center + rng.uniform(-3, 3)))
        occluder[:, cut:] = 1
        if domain == "parallel_occluders":
            occluder = (xx >= left + 0.6 * (right - left)).astype(np.uint8)
    elif scenario != 0:
        count = 1 if scenario == 1 else 3
        for index in range(count):
            y = int(rng.integers(15, size - 15))
            side = index % 2 if scenario == 3 else int(rng.integers(2))
            cut = int(round(center + rng.uniform(-width * 0.2, width * 0.2)))
            edge = 0 if side == 0 else size - 1
            half_height = int(rng.integers(7, 23))
            if domain == "curved_occluders":
                x = cut - 20 if side == 0 else cut + 20
                cv2.ellipse(occluder, (x, y), (30, half_height), 0, 0, 360, 1, -1)
            elif scenario == 2:
                points = np.asarray(
                    [
                        [edge, y - half_height],
                        [cut - 5, y - half_height],
                        [cut + 5, y + half_height],
                        [edge, y + half_height],
                    ],
                    dtype=np.int32,
                )
                cv2.fillPoly(occluder, [points], 1)
            else:
                cv2.rectangle(
                    occluder,
                    (min(edge, cut), y - half_height),
                    (max(edge, cut), y + half_height),
                    1,
                    -1,
                )
    obstacle = occluder.astype(bool)
    obstacle_rgb = _texture(rng, size, domain == "bark_occluders" or bool(rng.integers(2)))
    rgb[obstacle] = obstacle_rgb[obstacle]
    visible = truth & ~obstacle
    rows = []
    for row in observe_visible_rows(visible):
        true_x = np.flatnonzero(truth[row.y])
        rows.append(
            StemRowEvidence(
                float(row.y),
                float(row.left),
                float(row.right),
                row.left == int(true_x[0]),
                row.right == int(true_x[-1]),
            )
        )
    return SyntheticBoundaryScene(group_id, domain, rgb, visible, truth, tuple(rows), width, query)


def render_ambiguous_pair(group_id: int) -> tuple[SyntheticBoundaryScene, SyntheticBoundaryScene]:
    """Construct identical RGB/mask observations with different latent widths.

    The same right-side material is foreground hiding a wide stem in one
    scene and background beside a narrow stem in the other. This tests
    identifiability; it is not a field sample.
    """
    if group_id % 5 != 4:
        raise ValueError("ambiguous pair requires a permanent side-occlusion scene")
    wide = render_boundary_scene(group_id, "parallel_occluders")
    narrow_rows = tuple(
        StemRowEvidence(row.y_px, row.left_visible_px, row.right_visible_px, True, True)
        for row in wide.oracle_rows
    )
    narrow = SyntheticBoundaryScene(
        wide.group_id,
        "ambiguous_background",
        wide.rgb.copy(),
        wide.visible_mask.copy(),
        wide.visible_mask.copy(),
        narrow_rows,
        0.6 * wide.true_width_px,
        wide.query_y,
    )
    return wide, narrow


def predicted_rows(
    observations: tuple[BoundaryObservation, ...],
    exposed_probabilities: npt.ArrayLike,
    threshold: float | None,
) -> tuple[StemRowEvidence, ...]:
    scores = np.asarray(exposed_probabilities, dtype=float)
    if scores.shape != (2 * len(observations),) or not np.all(np.isfinite(scores)):
        raise ValueError("one finite exposed probability is needed for each boundary")
    if np.any((scores < 0) | (scores > 1)) or threshold is not None and not 0 <= threshold <= 1:
        raise ValueError("probabilities and threshold must be in [0, 1]")
    return tuple(
        StemRowEvidence(
            float(row.y),
            float(row.left),
            float(row.right),
            threshold is not None and scores[2 * i] >= threshold,
            threshold is not None and scores[2 * i + 1] >= threshold,
        )
        for i, row in enumerate(observations)
    )
