"""Reproducible synthetic TreeFactor fault-injection experiment."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from treeweaver.factor.tree_factor import optimize_tree_factor
from treeweaver.simulation.synthetic_tree import SyntheticScenario, generate_tree_scene


@dataclass(frozen=True, slots=True)
class AblationCase:
    seed: int
    visible_arc_fraction: float
    outlier_fraction: float
    weighted: bool
    height_absolute_error_m: float
    dbh_absolute_error_cm: float
    predicted_height_sd_m: float
    predicted_dbh_sd_cm: float
    success: bool


def run_synthetic_ablation(output: str | Path, *, seeds: int = 3) -> Path:
    """Run visibility/outlier/reliability ablations and save all cases."""

    if seeds < 1:
        raise ValueError("at least one synthetic seed is required")
    cases: list[AblationCase] = []
    for seed in range(seeds):
        for visible_arc in (1.0, 0.5, 0.25):
            for outliers in (0.0, 0.15):
                scene = generate_tree_scene(
                    SyntheticScenario(
                        seed=seed,
                        visible_arc_fraction=visible_arc,
                        outlier_fraction=outliers,
                    )
                )
                for weighted in (False, True):
                    result = optimize_tree_factor(
                        scene.trunk_points,
                        scene.crown_points,
                        scene.ground_points,
                        scene.anchors,
                        trunk_reliability=scene.trunk_reliability if weighted else None,
                        ground_reliability=scene.ground_reliability if weighted else None,
                    )
                    cases.append(
                        AblationCase(
                            seed,
                            visible_arc,
                            outliers,
                            weighted,
                            abs(result.height.value - scene.truth["height_m"]),
                            abs(result.dbh.value - scene.truth["dbh_cm"]),
                            result.height.standard_deviation,
                            result.dbh.standard_deviation,
                            result.success,
                        )
                    )
    destination = Path(output).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "synthetic-ablation-1.0",
                "warning": "synthetic verification is not evidence of field accuracy",
                "cases": [asdict(case) for case in cases],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return destination
