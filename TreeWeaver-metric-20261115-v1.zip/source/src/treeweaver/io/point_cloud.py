"""Strict point-cloud loading boundary for dense reconstruction providers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]
UInt8Array = npt.NDArray[np.uint8]


@dataclass(frozen=True, slots=True)
class PointCloud:
    points: FloatArray
    colors: UInt8Array | None = None
    confidence: FloatArray | None = None

    def __post_init__(self) -> None:
        if self.points.ndim != 2 or self.points.shape[1] != 3 or len(self.points) == 0:
            raise ValueError("point cloud must be a non-empty N x 3 array")
        if not np.isfinite(self.points).all():
            raise ValueError("point cloud contains non-finite coordinates")
        if self.colors is not None and self.colors.shape != self.points.shape:
            raise ValueError("point colors must match point coordinates")
        if self.confidence is not None:
            if self.confidence.shape != (len(self.points),):
                raise ValueError("point confidence must contain one value per point")
            if not np.isfinite(self.confidence).all():
                raise ValueError("point confidence contains non-finite values")


def _load_npz(path: Path) -> PointCloud:
    with np.load(path, allow_pickle=False) as data:
        if "points" not in data.files:
            raise ValueError("NPZ point cloud requires a 'points' array")
        points = np.asarray(data["points"], dtype=np.float64)
        colors = np.asarray(data["colors"], dtype=np.uint8) if "colors" in data.files else None
        confidence = (
            np.asarray(data["confidence"], dtype=np.float64) if "confidence" in data.files else None
        )
    return PointCloud(points, colors, confidence)


def _load_ply(path: Path) -> PointCloud:
    try:
        from plyfile import PlyData
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('install point-cloud support with pip install -e ".[vision]"') from exc

    ply = PlyData.read(str(path))
    if "vertex" not in ply:
        raise ValueError("PLY file has no vertex element")
    vertex = ply["vertex"].data
    names = set(vertex.dtype.names or ())
    if not {"x", "y", "z"}.issubset(names):
        raise ValueError("PLY vertices require x, y, and z properties")
    points = np.column_stack((vertex["x"], vertex["y"], vertex["z"])).astype(np.float64)
    colors = None
    if {"red", "green", "blue"}.issubset(names):
        colors = np.column_stack((vertex["red"], vertex["green"], vertex["blue"])).astype(np.uint8)
    confidence = None
    for candidate in ("confidence", "quality", "score"):
        if candidate in names:
            confidence = np.asarray(vertex[candidate], dtype=np.float64)
            break
    return PointCloud(points, colors, confidence)


def _load_las(path: Path) -> PointCloud:
    try:
        import laspy
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('install LAZ support with pip install -e ".[vision]"') from exc

    cloud = laspy.read(path)
    points = np.column_stack((cloud.x, cloud.y, cloud.z)).astype(np.float64)
    dimensions = set(cloud.point_format.dimension_names)
    colors = None
    if {"red", "green", "blue"}.issubset(dimensions):
        rgb16 = np.column_stack((cloud.red, cloud.green, cloud.blue)).astype(np.float64)
        maximum = float(rgb16.max(initial=0.0))
        if maximum > 255.0:
            rgb16 /= 257.0
        colors = np.clip(np.rint(rgb16), 0, 255).astype(np.uint8)
    return PointCloud(points, colors)


def load_point_cloud(path: str | Path) -> PointCloud:
    source = Path(path).resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    suffix = source.suffix.lower()
    if suffix == ".npz":
        return _load_npz(source)
    if suffix == ".ply":
        return _load_ply(source)
    if suffix in {".las", ".laz"}:
        return _load_las(source)
    raise ValueError(f"unsupported point-cloud format: {suffix}")
