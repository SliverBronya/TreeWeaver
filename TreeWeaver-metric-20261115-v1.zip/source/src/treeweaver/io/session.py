"""Load and verify a versioned capture directory."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from treeweaver.domain.models import (
    CameraIntrinsics,
    CaptureSession,
    DepthSource,
    DeviceCapabilities,
    FrameObservation,
    ScaleAnchor,
)


@dataclass(frozen=True, slots=True)
class SessionValidation:
    session: CaptureSession
    warnings: tuple[str, ...]


def _safe_asset_path(bundle_root: Path, relative: str) -> Path:
    candidate = (bundle_root / relative).resolve()
    root = bundle_root.resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError(f"asset path escapes the capture bundle: {relative}")
    return candidate


def _require_dict(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object")
    return value


def load_capture_session(
    manifest_path: str | Path, *, verify_assets: bool = True
) -> SessionValidation:
    manifest = Path(manifest_path).resolve()
    if not manifest.is_file():
        raise FileNotFoundError(manifest)
    payload = _require_dict(json.loads(manifest.read_text(encoding="utf-8")), "manifest")
    bundle_root = manifest.parent

    device = _require_dict(payload["device"], "device")
    capabilities = DeviceCapabilities(
        has_imu=bool(device["has_imu"]),
        has_arcore=bool(device["has_arcore"]),
        has_metric_depth=bool(device["has_metric_depth"]),
        depth_source=DepthSource(str(device.get("depth_source", "none"))),
    )

    frames: list[FrameObservation] = []
    warnings: list[str] = []
    frame_payloads = payload.get("frames", [])
    if not isinstance(frame_payloads, list) or len(frame_payloads) < 1:
        raise ValueError("a capture session requires at least one RGB image")

    for index, item_value in enumerate(frame_payloads):
        item = _require_dict(item_value, f"frames[{index}]")
        camera = _require_dict(item["intrinsics"], f"frames[{index}].intrinsics")
        image_path = str(item["image_path"])
        if verify_assets and not _safe_asset_path(bundle_root, image_path).is_file():
            raise FileNotFoundError(f"missing frame asset: {image_path}")
        depth_path = str(item["depth_path"]) if "depth_path" in item else None
        confidence_path = (
            str(item["depth_confidence_path"])
            if "depth_confidence_path" in item
            else None
        )
        if verify_assets:
            for asset in (depth_path, confidence_path):
                if asset is not None and not _safe_asset_path(bundle_root, asset).is_file():
                    raise FileNotFoundError(f"missing frame asset: {asset}")
        frames.append(
            FrameObservation(
                frame_id=str(item["frame_id"]),
                timestamp_ns=int(item["timestamp_ns"]),
                image_path=image_path,
                intrinsics=CameraIntrinsics(
                    fx=float(camera["fx"]),
                    fy=float(camera["fy"]),
                    cx=float(camera["cx"]),
                    cy=float(camera["cy"]),
                    width=int(camera["width"]),
                    height=int(camera["height"]),
                ),
                azimuth_deg=(float(item["azimuth_deg"]) if "azimuth_deg" in item else None),
                elevation_deg=(float(item["elevation_deg"]) if "elevation_deg" in item else None),
                blur_score=(float(item["blur_score"]) if "blur_score" in item else None),
                tree_coverage=(float(item["tree_coverage"]) if "tree_coverage" in item else None),
                occlusion_ratio=(
                    float(item["occlusion_ratio"]) if "occlusion_ratio" in item else None
                ),
                depth_path=depth_path,
                depth_confidence_path=confidence_path,
                depth_unit_m=float(item.get("depth_unit_m", 0.001)),
                camera_to_world=(
                    tuple(float(value) for value in item["camera_to_world"])
                    if "camera_to_world" in item
                    else None
                ),
                tracking_state=(str(item["tracking_state"]) if "tracking_state" in item else None),
            )
        )

    anchors_payload = payload.get("scale_anchors", [])
    if not isinstance(anchors_payload, list):
        raise ValueError("scale_anchors must be an array")
    if not anchors_payload and not capabilities.has_metric_depth:
        raise ValueError("absolute measurement requires metric depth or a scale anchor")
    anchors = tuple(
        ScaleAnchor(
            kind=str(item["kind"]),
            metric_length_m=float(item["metric_length_m"]),
            reconstructed_length=(
                float(item["reconstructed_length"]) if "reconstructed_length" in item else None
            ),
            confidence=float(item["confidence"]),
        )
        for item in anchors_payload
    )

    if len(frames) == 1:
        warnings.append(
            "single RGB mode: hidden depth and out-of-plane dimensions may be unidentifiable"
        )
    elif len(frames) < 12:
        warnings.append("fewer than 12 frames may be insufficient for stable multi-view geometry")
    if not capabilities.has_imu:
        warnings.append("session has no IMU; gravity and motion priors will be unavailable")
    metric_frames = [frame for frame in frames if frame.depth_path and frame.camera_to_world]
    if capabilities.has_metric_depth and len(metric_frames) != len(frames):
        warnings.append("some metric-depth frames lack depth assets or ARCore world poses")

    session = CaptureSession(
        schema_version=str(payload["schema_version"]),
        session_id=str(payload["session_id"]),
        device_id=str(device["device_id"]),
        capabilities=capabilities,
        frames=tuple(frames),
        anchors=anchors,
        gravity_down_world=(
            tuple(float(value) for value in payload["gravity_down_world"])  # type: ignore[arg-type]
            if "gravity_down_world" in payload
            else None
        ),
    )
    return SessionValidation(session, tuple(warnings))
