"""Validation and ingestion of raw Android capture bundles."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from treeweaver.domain.models import CameraIntrinsics


@dataclass(frozen=True, slots=True)
class RawCameraMetadata:
    source: str
    intrinsic_calibration: tuple[float, ...] | None
    focal_length_mm: float | None
    active_left: int
    active_top: int
    active_width: int
    active_height: int
    sensor_width_mm: float | None
    sensor_height_mm: float | None


@dataclass(frozen=True, slots=True)
class RawCapture:
    root: Path
    session_id: str
    video_path: Path
    imu_path: Path
    recording_monotonic_start_ns: int
    device_id: str
    has_imu: bool
    anchor_kind: str
    anchor_length_m: float
    anchor_marker_id: int | None
    anchor_dictionary: str | None
    camera: RawCameraMetadata


@dataclass(frozen=True, slots=True)
class IngestionResult:
    manifest_path: Path
    frame_count: int
    video_width: int
    video_height: int
    fps: float
    imu_sample_count: int
    warnings: tuple[str, ...]


def _safe_path(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    resolved_root = root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ValueError(f"asset path escapes raw bundle: {relative}")
    return candidate


def load_raw_capture(manifest_path: str | Path) -> RawCapture:
    manifest = Path(manifest_path).resolve()
    payload: dict[str, Any] = json.loads(manifest.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "raw-1.0":
        raise ValueError("unsupported raw capture schema")
    root = manifest.parent
    video = _safe_path(root, str(payload["video_path"]))
    imu = _safe_path(root, str(payload["imu_path"]))
    if not video.is_file() or video.stat().st_size == 0:
        raise FileNotFoundError(f"missing or empty video: {video}")
    if not imu.is_file():
        raise FileNotFoundError(f"missing IMU file: {imu}")

    camera_payload = payload["camera"]
    active_width = int(
        camera_payload.get("active_width", camera_payload.get("pixel_array_width", 0))
    )
    active_height = int(
        camera_payload.get("active_height", camera_payload.get("pixel_array_height", 0))
    )
    if active_width <= 0 or active_height <= 0:
        raise ValueError("camera active-array dimensions are required")
    intrinsic = camera_payload.get("intrinsic_calibration")
    anchor = payload["scale_anchor"]
    start_ns = int(payload.get("recording_monotonic_start_ns", 0))
    if start_ns <= 0:
        raise ValueError("recording_monotonic_start_ns is required for IMU synchronization")

    return RawCapture(
        root=root,
        session_id=str(payload["session_id"]),
        video_path=video,
        imu_path=imu,
        recording_monotonic_start_ns=start_ns,
        device_id=(
            f"{payload.get('device_manufacturer', 'unknown')}/"
            f"{payload.get('device_model', 'unknown')}"
        ),
        has_imu=bool(payload.get("has_imu", False)),
        anchor_kind=str(anchor["kind"]),
        anchor_length_m=float(anchor["metric_length_m"]),
        anchor_marker_id=(int(anchor["marker_id"]) if "marker_id" in anchor else None),
        anchor_dictionary=(str(anchor["dictionary"]) if "dictionary" in anchor else None),
        camera=RawCameraMetadata(
            source=str(camera_payload["intrinsics_source"]),
            intrinsic_calibration=(tuple(float(v) for v in intrinsic) if intrinsic else None),
            focal_length_mm=(
                float(camera_payload["focal_length_mm"])
                if "focal_length_mm" in camera_payload
                else None
            ),
            active_left=int(camera_payload.get("active_left", 0)),
            active_top=int(camera_payload.get("active_top", 0)),
            active_width=active_width,
            active_height=active_height,
            sensor_width_mm=(
                float(camera_payload["sensor_width_mm"])
                if "sensor_width_mm" in camera_payload
                else None
            ),
            sensor_height_mm=(
                float(camera_payload["sensor_height_mm"])
                if "sensor_height_mm" in camera_payload
                else None
            ),
        ),
    )


def effective_video_intrinsics(
    camera: RawCameraMetadata, width: int, height: int
) -> CameraIntrinsics:
    """Map active-array intrinsics through CameraX's centered fill crop."""
    if camera.intrinsic_calibration is not None and len(camera.intrinsic_calibration) >= 4:
        fx, fy, cx, cy = camera.intrinsic_calibration[:4]
        cx -= camera.active_left
        cy -= camera.active_top
    elif camera.focal_length_mm and camera.sensor_width_mm and camera.sensor_height_mm:
        fx = camera.focal_length_mm / camera.sensor_width_mm * camera.active_width
        fy = camera.focal_length_mm / camera.sensor_height_mm * camera.active_height
        cx = camera.active_width / 2
        cy = camera.active_height / 2
    else:
        raise ValueError("camera metadata cannot produce metric video intrinsics")

    scale = max(width / camera.active_width, height / camera.active_height)
    crop_x = (camera.active_width * scale - width) / 2
    crop_y = (camera.active_height * scale - height) / 2
    return CameraIntrinsics(
        fx=fx * scale,
        fy=fy * scale,
        cx=cx * scale - crop_x,
        cy=cy * scale - crop_y,
        width=width,
        height=height,
    )


def _validate_imu(path: Path, start_ns: int, end_ns: int) -> tuple[int, list[str]]:
    warnings: list[str] = []
    count = 0
    previous = -1
    overlap = 0
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        expected = {"timestamp_ns", "sensor", "x", "y", "z"}
        if set(reader.fieldnames or ()) != expected:
            raise ValueError("IMU CSV header is invalid")
        for row in reader:
            timestamp = int(row["timestamp_ns"])
            if timestamp < previous:
                raise ValueError("IMU timestamps must be monotonically ordered")
            previous = timestamp
            count += 1
            if start_ns <= timestamp <= end_ns:
                overlap += 1
    if count == 0:
        warnings.append("IMU file contains no samples")
    elif overlap == 0:
        warnings.append("IMU samples do not overlap the video clock interval")
    return count, warnings


def ingest_raw_capture(
    manifest_path: str | Path,
    output_root: str | Path,
    *,
    sample_hz: float = 2.0,
    max_frames: int = 240,
) -> IngestionResult:
    if sample_hz <= 0 or max_frames < 2:
        raise ValueError("sample_hz must be positive and max_frames at least 2")
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('install video dependencies with pip install -e ".[vision]"') from exc

    raw = load_raw_capture(manifest_path)
    capture = cv2.VideoCapture(str(raw.video_path))
    if not capture.isOpened():
        raise ValueError(f"cannot decode video: {raw.video_path}")
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if fps <= 0 or total < 2 or width <= 0 or height <= 0:
        capture.release()
        raise ValueError("video metadata is incomplete")
    intrinsics = effective_video_intrinsics(raw.camera, width, height)

    output = Path(output_root).resolve() / raw.session_id
    frames_dir = output / "frames"
    frames_dir.mkdir(parents=True, exist_ok=False)
    interval = max(1, round(fps / sample_hz))
    indices = list(range(0, total, interval))[:max_frames]
    frames: list[dict[str, Any]] = []
    for ordinal, index in enumerate(indices):
        capture.set(cv2.CAP_PROP_POS_FRAMES, index)
        ok, image = capture.read()
        if not ok:
            continue
        name = f"frame_{ordinal:06d}.jpg"
        if not cv2.imwrite(str(frames_dir / name), image, [cv2.IMWRITE_JPEG_QUALITY, 95]):
            raise OSError(f"failed to write {name}")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        sharpness = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        frames.append(
            {
                "frame_id": f"{raw.session_id}:{index}",
                "timestamp_ns": raw.recording_monotonic_start_ns + round(index / fps * 1e9),
                "image_path": f"frames/{name}",
                "intrinsics": asdict(intrinsics),
                "blur_score": max(0.0, min(1.0, sharpness / 500.0)),
            }
        )
    capture.release()
    if len(frames) < 2:
        raise ValueError("fewer than two video frames could be decoded")

    video_end_ns = raw.recording_monotonic_start_ns + round((total - 1) / fps * 1e9)
    imu_count, warnings = _validate_imu(
        raw.imu_path, raw.recording_monotonic_start_ns, video_end_ns
    )
    if len(frames) < 12:
        warnings.append("fewer than 12 key frames were extracted")
    manifest = {
        "schema_version": "1.0",
        "session_id": raw.session_id,
        "device": {
            "device_id": raw.device_id,
            "has_imu": raw.has_imu,
            "has_arcore": False,
            "has_metric_depth": False,
            "depth_source": "none",
        },
        "frames": frames,
        "scale_anchors": [
            {
                "kind": raw.anchor_kind,
                "metric_length_m": raw.anchor_length_m,
                "confidence": 1.0,
                **(
                    {
                        "marker_id": raw.anchor_marker_id,
                        "dictionary": raw.anchor_dictionary,
                    }
                    if raw.anchor_marker_id is not None
                    else {}
                ),
            }
        ],
        "provenance": {
            "raw_manifest": str(Path(manifest_path).resolve()),
            "intrinsics_source": raw.camera.source,
            "intrinsics_transform": "center_crop_fill",
            "sample_hz": sample_hz,
        },
    }
    output_manifest = output / "capture.json"
    output_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return IngestionResult(
        output_manifest, len(frames), width, height, fps, imu_count, tuple(warnings)
    )
