"""File-based, reproducible multiview instance association run."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import (
    InstanceObservation,
    ProjectionCamera,
    associate_instances,
)
from treeweaver.io.point_cloud import load_point_cloud
from treeweaver.io.session import load_capture_session
from treeweaver.providers.colmap_text import load_colmap_text_model


@dataclass(frozen=True, slots=True)
class AssociationRunResult:
    output_directory: Path
    track_count: int
    associated_observations: int
    unassociated_observations: int


def _safe_path(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError(f"mask path escapes observation bundle: {relative}")
    return candidate


def _load_observations(path: Path) -> tuple[InstanceObservation, ...]:
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "instance-observations-1.0":
        raise ValueError("unsupported instance-observation schema")
    observations: list[InstanceObservation] = []
    keys: set[tuple[str, int]] = set()
    for view in payload.get("views", []):
        image_name = str(view["image_name"])
        for item in view.get("instances", []):
            local_id = int(item["local_instance_id"])
            key = image_name, local_id
            if key in keys:
                raise ValueError(f"duplicate local instance: {key}")
            keys.add(key)
            mask_path = _safe_path(path.parent.resolve(), str(item["mask_path"]))
            mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
            if mask is None:
                raise FileNotFoundError(f"cannot read instance mask: {mask_path}")
            observations.append(
                InstanceObservation(
                    image_name=image_name,
                    local_instance_id=local_id,
                    mask=mask > 0,
                    reliability=float(item.get("reliability", 1.0)),
                )
            )
    if not observations:
        raise ValueError("observation bundle contains no instances")
    return tuple(observations)


def associate_instance_bundle(
    capture_manifest: str | Path,
    colmap_text_model: str | Path,
    dense_point_cloud: str | Path,
    observation_manifest: str | Path,
    output_directory: str | Path,
    *,
    minimum_support_points: int = 20,
    minimum_jaccard: float = 0.15,
) -> AssociationRunResult:
    session = load_capture_session(capture_manifest).session
    reconstruction = load_colmap_text_model(colmap_text_model)
    cloud = load_point_cloud(dense_point_cloud)
    observations = _load_observations(Path(observation_manifest).resolve())

    intrinsics_by_name = {}
    for frame in session.frames:
        name = Path(frame.image_path).name
        if name in intrinsics_by_name:
            raise ValueError(f"capture contains duplicate image basename: {name}")
        intrinsics_by_name[name] = frame.intrinsics
    cameras: list[ProjectionCamera] = []
    for pose in reconstruction.poses:
        intrinsics = intrinsics_by_name.get(pose.image_name)
        if intrinsics is None:
            raise ValueError(f"no capture intrinsics for reconstructed image: {pose.image_name}")
        cameras.append(ProjectionCamera(pose.image_name, pose, intrinsics))

    tracks = associate_instances(
        cloud.points,
        tuple(cameras),
        observations,
        minimum_support_points=minimum_support_points,
        minimum_jaccard=minimum_jaccard,
    )
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)

    point_arrays: list[npt.NDArray[np.int64]] = []
    consensus_arrays: list[npt.NDArray[np.int64]] = []
    metadata: list[dict[str, object]] = []
    associated_keys: set[tuple[str, int]] = set()
    for track in tracks:
        point_arrays.append(track.point_indices)
        consensus_arrays.append(track.consensus_point_indices)
        associated_keys.update(track.members)
        metadata.append(
            {
                "track_id": track.track_id,
                "members": [
                    {"image_name": image, "local_instance_id": local_id}
                    for image, local_id in track.members
                ],
                "point_count": len(track.point_indices),
                "consensus_point_count": len(track.consensus_point_indices),
                "association_confidence": track.association_confidence,
            }
        )
    point_lengths = np.array([len(values) for values in point_arrays], dtype=np.int64)
    consensus_lengths = np.array([len(values) for values in consensus_arrays], dtype=np.int64)
    point_offsets = np.r_[0, np.cumsum(point_lengths)]
    consensus_offsets = np.r_[0, np.cumsum(consensus_lengths)]
    flat_points = np.concatenate(point_arrays) if point_arrays else np.empty(0, dtype=np.int64)
    flat_consensus = (
        np.concatenate(consensus_arrays) if consensus_arrays else np.empty(0, dtype=np.int64)
    )
    np.savez_compressed(
        output / "track-points.npz",
        point_indices=flat_points,
        point_offsets=point_offsets,
        consensus_indices=flat_consensus,
        consensus_offsets=consensus_offsets,
    )
    result_payload = {
        "schema_version": "tree-tracks-1.0",
        "capture_manifest": str(Path(capture_manifest).resolve()),
        "colmap_text_model": str(Path(colmap_text_model).resolve()),
        "dense_point_cloud": str(Path(dense_point_cloud).resolve()),
        "minimum_support_points": minimum_support_points,
        "minimum_jaccard": minimum_jaccard,
        "tracks": metadata,
    }
    (output / "tracks.json").write_text(
        json.dumps(result_payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return AssociationRunResult(
        output_directory=output,
        track_count=len(tracks),
        associated_observations=len(associated_keys),
        unassociated_observations=len(observations) - len(associated_keys),
    )
