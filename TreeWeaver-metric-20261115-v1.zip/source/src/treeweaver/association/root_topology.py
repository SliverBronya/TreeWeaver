"""Root-anchored, ambiguity-preserving separation of touching trees."""

from __future__ import annotations

from dataclasses import dataclass
from heapq import heappop, heappush

import numpy as np
import numpy.typing as npt
from scipy.spatial import cKDTree

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]

AMBIGUOUS_LABEL = 0
UNREACHABLE_LABEL = -1


@dataclass(frozen=True, slots=True)
class RootAnchor:
    """A user- or vision-confirmed root position for one physical tree."""

    tree_id: int
    position: FloatArray
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if self.tree_id <= 0:
            raise ValueError("tree_id must be positive; zero is reserved for ambiguous points")
        if self.position.shape != (3,) or not np.isfinite(self.position).all():
            raise ValueError("root position must be a finite three-vector")
        if not 0 < self.confidence <= 1:
            raise ValueError("root confidence must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class RootAssignment:
    """Per-point ownership; uncertain geometry is deliberately not forced."""

    labels: IntArray
    confidence: FloatArray
    ambiguous_indices: IntArray
    unreachable_indices: IntArray
    tree_point_indices: dict[int, IntArray]


def _validate_probabilities(values: npt.ArrayLike | None, count: int) -> FloatArray:
    if values is None:
        return np.ones(count, dtype=np.float64)
    probabilities = np.asarray(values, dtype=np.float64)
    if probabilities.shape != (count,) or not np.isfinite(probabilities).all():
        raise ValueError("trunk_probability must contain one finite value per point")
    if np.any((probabilities < 0) | (probabilities > 1)):
        raise ValueError("trunk probabilities must be in [0, 1]")
    return probabilities


def _graph(
    points: FloatArray,
    trunk_probability: FloatArray,
    up: FloatArray,
    *,
    neighbor_count: int,
    maximum_edge_length: float,
) -> tuple[tuple[tuple[int, float], ...], ...]:
    count = len(points)
    query_count = min(neighbor_count + 1, count)
    distances, neighbors = cKDTree(points).query(points, k=query_count)
    if query_count == 1:
        distances = distances[:, None]
        neighbors = neighbors[:, None]
    adjacency: list[list[tuple[int, float]]] = [[] for _ in range(count)]
    for source in range(count):
        for distance, target_value in zip(
            distances[source, 1:], neighbors[source, 1:], strict=True
        ):
            target = int(target_value)
            if not np.isfinite(distance) or distance <= 0 or distance > maximum_edge_length:
                continue
            displacement = points[target] - points[source]
            vertical_fraction = abs(float(displacement @ up)) / float(distance)
            mean_trunk = float((trunk_probability[source] + trunk_probability[target]) / 2)
            # Woody/trunk evidence should propagate mainly along the vertical tree axis.
            # Crown evidence is less constrained, which lets branches spread laterally.
            cross_axis_penalty = mean_trunk * (1 - vertical_fraction) * 2.5
            cost = float(distance) * (1 + cross_axis_penalty)
            adjacency[source].append((target, cost))
    return tuple(tuple(items) for items in adjacency)


def _shortest_paths(
    adjacency: tuple[tuple[tuple[int, float], ...], ...], source: int
) -> FloatArray:
    distance = np.full(len(adjacency), np.inf, dtype=np.float64)
    distance[source] = 0.0
    queue: list[tuple[float, int]] = [(0.0, source)]
    while queue:
        current, node = heappop(queue)
        if current != distance[node]:
            continue
        for neighbor, edge_cost in adjacency[node]:
            candidate = current + edge_cost
            if candidate < distance[neighbor]:
                distance[neighbor] = candidate
                heappush(queue, (candidate, neighbor))
    return distance


def assign_points_to_root_anchors(
    points_world: npt.ArrayLike,
    roots: tuple[RootAnchor, ...],
    *,
    trunk_probability: npt.ArrayLike | None = None,
    up: npt.ArrayLike = (0.0, 0.0, 1.0),
    neighbor_count: int = 10,
    maximum_edge_length: float = 0.45,
    maximum_root_distance: float = 0.35,
    ambiguity_ratio: float = 0.12,
) -> RootAssignment:
    """Assign reconstructed points by root-constrained 3-D geodesic distance.

    The function is intentionally conservative.  When the two best root paths
    are too similar, the point receives label ``0`` instead of a fabricated
    tree identity.  Disconnected points receive ``-1``.
    """

    points = np.asarray(points_world, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points_world must be a finite N x 3 array")
    if len(points) == 0 or len(roots) == 0:
        raise ValueError("at least one point and one root anchor are required")
    tree_ids = [root.tree_id for root in roots]
    if len(set(tree_ids)) != len(tree_ids):
        raise ValueError("root tree ids must be unique")
    if neighbor_count < 1 or maximum_edge_length <= 0 or maximum_root_distance <= 0:
        raise ValueError("graph parameters must be positive")
    if not 0 <= ambiguity_ratio < 1:
        raise ValueError("ambiguity_ratio must be in [0, 1)")

    up_vector = np.asarray(up, dtype=np.float64)
    if up_vector.shape != (3,) or not np.isfinite(up_vector).all():
        raise ValueError("up must be a finite three-vector")
    norm = float(np.linalg.norm(up_vector))
    if norm <= 1e-9:
        raise ValueError("up cannot be zero")
    up_vector /= norm
    probabilities = _validate_probabilities(trunk_probability, len(points))
    adjacency = _graph(
        points,
        probabilities,
        up_vector,
        neighbor_count=neighbor_count,
        maximum_edge_length=maximum_edge_length,
    )
    tree = cKDTree(points)
    source_indices: list[int] = []
    for root in roots:
        distance, index = tree.query(root.position, k=1)
        if float(distance) > maximum_root_distance:
            raise ValueError(
                f"root {root.tree_id} is {float(distance):.3f} units from the point cloud"
            )
        source_indices.append(int(index))

    costs = np.stack(
        [
            _shortest_paths(adjacency, source) / max(root.confidence, 1e-6)
            for root, source in zip(roots, source_indices, strict=True)
        ]
    )
    order = np.argsort(costs, axis=0)
    best_row = order[0]
    best = costs[best_row, np.arange(len(points))]
    labels = np.array([roots[index].tree_id for index in best_row], dtype=np.int64)
    confidence = np.ones(len(points), dtype=np.float64)
    unreachable = ~np.isfinite(best)
    labels[unreachable] = UNREACHABLE_LABEL
    confidence[unreachable] = 0.0

    ambiguous = np.zeros(len(points), dtype=np.bool_)
    if len(roots) > 1:
        second = costs[order[1], np.arange(len(points))]
        finite = np.isfinite(best) & np.isfinite(second)
        relative_gap = np.zeros(len(points), dtype=np.float64)
        relative_gap[finite] = (second[finite] - best[finite]) / np.maximum(second[finite], 1e-9)
        ambiguous = finite & (relative_gap < ambiguity_ratio)
        labels[ambiguous] = AMBIGUOUS_LABEL
        confidence[finite] = np.clip(relative_gap[finite] / max(ambiguity_ratio, 1e-9), 0, 1)
        confidence[ambiguous] *= 0.49

    return RootAssignment(
        labels=labels,
        confidence=confidence,
        ambiguous_indices=np.flatnonzero(ambiguous).astype(np.int64, copy=False),
        unreachable_indices=np.flatnonzero(unreachable).astype(np.int64, copy=False),
        tree_point_indices={
            tree_id: np.flatnonzero(labels == tree_id).astype(np.int64, copy=False)
            for tree_id in tree_ids
        },
    )
