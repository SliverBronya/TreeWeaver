"""Initialize a reconstructed 3-D target root from one user click."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]


@dataclass(frozen=True, slots=True)
class SingleClickRoot:
    position: FloatArray
    support_indices: IntArray
    pixel_residual_px: float
    position_spread_units: float
    confidence: float


def initialize_root_from_click(
    scene_points: npt.ArrayLike,
    camera: ProjectionCamera,
    pixel: npt.ArrayLike,
    *,
    search_radius_px: float = 8.0,
    relative_depth_band: float = 0.03,
    absolute_depth_band: float = 0.15,
    minimum_support_points: int = 3,
) -> SingleClickRoot:
    """Select the front coherent reconstructed surface around a clicked root pixel."""

    points = np.asarray(scene_points, dtype=np.float64)
    clicked = np.asarray(pixel, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("scene_points must be a finite N x 3 array")
    if clicked.shape != (2,) or not np.isfinite(clicked).all():
        raise ValueError("pixel must be a finite two-vector")
    if search_radius_px <= 0 or relative_depth_band < 0 or absolute_depth_band <= 0:
        raise ValueError("click-search parameters must be positive")
    if minimum_support_points < 1:
        raise ValueError("minimum_support_points must be positive")

    camera_points = (
        camera.pose.rotation_world_to_camera @ points.T
    ).T + camera.pose.translation_world_to_camera
    depth = camera_points[:, 2]
    positive = depth > 1e-8
    safe_depth = np.maximum(depth, 1e-8)
    u = camera.intrinsics.fx * camera_points[:, 0] / safe_depth + camera.intrinsics.cx
    v = camera.intrinsics.fy * camera_points[:, 1] / safe_depth + camera.intrinsics.cy
    residual = np.hypot(u - clicked[0], v - clicked[1])
    candidates = np.flatnonzero(positive & (residual <= search_radius_px))
    if len(candidates) < minimum_support_points:
        raise ValueError("clicked root has insufficient reconstructed support")
    nearest_depth = float(np.min(depth[candidates]))
    depth_band = absolute_depth_band + relative_depth_band * nearest_depth
    support = candidates[depth[candidates] <= nearest_depth + depth_band]
    if len(support) < minimum_support_points:
        raise ValueError("clicked root front surface has insufficient coherent support")

    pixel_weight = np.exp(-0.5 * (residual[support] / max(search_radius_px / 2, 1e-6)) ** 2)
    depth_weight = np.exp(-(depth[support] - nearest_depth) / max(depth_band, 1e-9))
    weights = pixel_weight * depth_weight
    position = np.average(points[support], axis=0, weights=weights)
    spread = float(
        np.sqrt(
            np.average(np.sum((points[support] - position) ** 2, axis=1), weights=weights)
        )
    )
    pixel_residual = float(np.average(residual[support], weights=weights))
    support_factor = min(1.0, len(support) / 20)
    residual_factor = float(np.exp(-pixel_residual / search_radius_px))
    depth_factor = float(np.exp(-spread / max(depth_band, 1e-9)))
    confidence = max(0.01, min(1.0, support_factor * residual_factor * depth_factor))
    return SingleClickRoot(
        np.asarray(position, dtype=np.float64),
        support.astype(np.int64, copy=False),
        pixel_residual,
        spread,
        confidence,
    )
