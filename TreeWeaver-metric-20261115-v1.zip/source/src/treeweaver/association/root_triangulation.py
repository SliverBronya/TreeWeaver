"""Robust multi-view triangulation for user-selected tree roots."""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import acos, degrees, exp
from typing import cast

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class RootPixelObservation:
    image_name: str
    pixel: FloatArray
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if not self.image_name or self.pixel.shape != (2,) or not np.isfinite(self.pixel).all():
            raise ValueError("root observation requires one finite image pixel")
        if not 0 < self.confidence <= 1:
            raise ValueError("root observation confidence must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class TriangulatedRoot:
    tree_id: int
    position: FloatArray
    position_standard_deviation_units: float
    mean_reprojection_error_px: float
    maximum_reprojection_error_px: float
    parallax_deg: float
    inlier_images: tuple[str, ...]
    rejected_images: tuple[str, ...]
    confidence: float


def _projection(camera: ProjectionCamera) -> FloatArray:
    intrinsics = camera.intrinsics
    calibration = np.array(
        [
            [intrinsics.fx, 0.0, intrinsics.cx],
            [0.0, intrinsics.fy, intrinsics.cy],
            [0.0, 0.0, 1.0],
        ]
    )
    extrinsics = np.column_stack(
        (camera.pose.rotation_world_to_camera, camera.pose.translation_world_to_camera)
    )
    return cast(FloatArray, calibration @ extrinsics)


def _triangulate(
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[RootPixelObservation, ...],
) -> FloatArray:
    rows: list[FloatArray] = []
    for camera, observation in zip(cameras, observations, strict=True):
        projection = _projection(camera)
        root_weight = observation.confidence**0.5
        rows.append((observation.pixel[0] * projection[2] - projection[0]) * root_weight)
        rows.append((observation.pixel[1] * projection[2] - projection[1]) * root_weight)
    _, _, vh = np.linalg.svd(np.stack(rows), full_matrices=False)
    homogeneous = vh[-1]
    if abs(float(homogeneous[3])) <= 1e-12:
        raise ValueError("root triangulation is numerically degenerate")
    return cast(FloatArray, homogeneous[:3] / homogeneous[3])


def _errors(
    position: FloatArray,
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[RootPixelObservation, ...],
) -> FloatArray:
    result = np.full(len(cameras), np.inf, dtype=np.float64)
    homogeneous = np.r_[position, 1.0]
    for index, (camera, observation) in enumerate(zip(cameras, observations, strict=True)):
        projected = _projection(camera) @ homogeneous
        if projected[2] <= 1e-9:
            continue
        pixel = projected[:2] / projected[2]
        result[index] = float(np.linalg.norm(pixel - observation.pixel))
    return result


def _maximum_parallax(position: FloatArray, cameras: tuple[ProjectionCamera, ...]) -> float:
    rays = []
    for camera in cameras:
        ray = camera.pose.centre_world - position
        norm = float(np.linalg.norm(ray))
        if norm <= 1e-12:
            return 0.0
        rays.append(ray / norm)
    return max(
        (
            degrees(acos(float(np.clip(left @ right, -1.0, 1.0))))
            for left, right in combinations(rays, 2)
        ),
        default=0.0,
    )


def _position_uncertainty(
    position: FloatArray,
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[RootPixelObservation, ...],
    reprojection_sigma_px: float,
) -> float:
    rows: list[FloatArray] = []
    weights: list[float] = []
    for camera, observation in zip(cameras, observations, strict=True):
        rotation = camera.pose.rotation_world_to_camera
        camera_point = rotation @ position + camera.pose.translation_world_to_camera
        x_value, y_value, depth = camera_point
        if depth <= 1e-9:
            return float("inf")
        du = camera.intrinsics.fx * (rotation[0] * depth - x_value * rotation[2]) / depth**2
        dv = camera.intrinsics.fy * (rotation[1] * depth - y_value * rotation[2]) / depth**2
        rows.extend((du, dv))
        weights.extend((observation.confidence, observation.confidence))
    jacobian = np.stack(rows)
    information = jacobian.T @ (np.asarray(weights)[:, None] * jacobian)
    if np.linalg.matrix_rank(information) < 3:
        return float("inf")
    covariance = np.linalg.inv(information) * reprojection_sigma_px**2
    return float(np.sqrt(np.trace(covariance) / 3))


def triangulate_root_anchor(
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[RootPixelObservation, ...],
    *,
    tree_id: int,
    maximum_reprojection_error_px: float = 3.0,
    minimum_parallax_deg: float = 1.5,
) -> TriangulatedRoot:
    """Triangulate a root while rejecting mistaps and weak-baseline geometry."""

    if tree_id <= 0:
        raise ValueError("tree_id must be positive")
    if maximum_reprojection_error_px <= 0 or minimum_parallax_deg <= 0:
        raise ValueError("quality thresholds must be positive")
    camera_by_name = {camera.image_name: camera for camera in cameras}
    if len(camera_by_name) != len(cameras):
        raise ValueError("camera image names must be unique")
    if len({item.image_name for item in observations}) != len(observations):
        raise ValueError("root observations must use unique images")
    usable = tuple(item for item in observations if item.image_name in camera_by_name)
    if len(usable) < 2:
        raise ValueError("a root requires clicks in at least two reconstructed views")
    selected_cameras = tuple(camera_by_name[item.image_name] for item in usable)

    best_inliers: npt.NDArray[np.bool_] | None = None
    best_key: tuple[int, float] | None = None
    for left, right in combinations(range(len(usable)), 2):
        pair_cameras = (selected_cameras[left], selected_cameras[right])
        pair_observations = (usable[left], usable[right])
        try:
            candidate = _triangulate(pair_cameras, pair_observations)
        except ValueError:
            continue
        errors = _errors(candidate, selected_cameras, usable)
        inliers = errors <= maximum_reprojection_error_px
        count = int(np.count_nonzero(inliers))
        median = float(np.median(errors[inliers])) if count else float("inf")
        key = count, -median
        if count >= 2 and (best_key is None or key > best_key):
            best_key = key
            best_inliers = inliers
    if best_inliers is None:
        raise ValueError("no geometrically consistent root clicks were found")

    inlier_indices = np.flatnonzero(best_inliers)
    inlier_cameras = tuple(selected_cameras[index] for index in inlier_indices)
    inlier_observations = tuple(usable[index] for index in inlier_indices)
    position = _triangulate(inlier_cameras, inlier_observations)
    final_errors = _errors(position, inlier_cameras, inlier_observations)
    if not np.isfinite(final_errors).all():
        raise ValueError("triangulated root is behind an inlier camera")
    mean_error = float(np.mean(final_errors))
    maximum_error = float(np.max(final_errors))
    if maximum_error > maximum_reprojection_error_px:
        raise ValueError("root reprojection error exceeds the accepted threshold")
    parallax = _maximum_parallax(position, inlier_cameras)
    if parallax < minimum_parallax_deg:
        raise ValueError(
            f"root-view parallax {parallax:.2f}° is below {minimum_parallax_deg:.2f}°"
        )
    uncertainty = _position_uncertainty(
        position,
        inlier_cameras,
        inlier_observations,
        max(0.5, mean_error),
    )
    if not np.isfinite(uncertainty):
        raise ValueError("root position uncertainty is unbounded")
    inlier_names = tuple(item.image_name for item in inlier_observations)
    rejected = tuple(item.image_name for item in usable if item.image_name not in inlier_names)
    view_fraction = len(inlier_observations) / len(usable)
    confidence = (
        float(np.mean([item.confidence for item in inlier_observations]))
        * view_fraction
        * exp(-mean_error / maximum_reprojection_error_px)
        * min(1.0, parallax / 8.0)
    )
    return TriangulatedRoot(
        tree_id=tree_id,
        position=position,
        position_standard_deviation_units=uncertainty,
        mean_reprojection_error_px=mean_error,
        maximum_reprojection_error_px=maximum_error,
        parallax_deg=parallax,
        inlier_images=inlier_names,
        rejected_images=rejected,
        confidence=max(0.01, min(1.0, confidence)),
    )
