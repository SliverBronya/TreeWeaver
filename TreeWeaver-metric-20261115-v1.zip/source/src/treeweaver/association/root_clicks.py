"""Initialize reconstructed 3-D roots from one dense-view or multi-view clicks."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.association.root_initialization import initialize_root_from_click
from treeweaver.association.root_triangulation import (
    RootPixelObservation,
    triangulate_root_anchor,
)
from treeweaver.io.point_cloud import load_point_cloud
from treeweaver.io.session import load_capture_session
from treeweaver.providers.colmap_text import load_colmap_text_model


@dataclass(frozen=True, slots=True)
class RootClickRun:
    output_path: Path
    tree_count: int
    accepted_click_count: int
    rejected_click_count: int


def triangulate_root_click_file(
    capture_manifest: str | Path,
    colmap_text_model: str | Path,
    root_clicks_json: str | Path,
    output_json: str | Path,
    *,
    up: npt.ArrayLike | None = None,
    dense_point_cloud: str | Path | None = None,
    maximum_reprojection_error_px: float = 3.0,
    minimum_parallax_deg: float = 1.5,
) -> RootClickRun:
    """Triangulate selected roots and write the root-anchor contract."""

    session_path = Path(capture_manifest).resolve()
    clicks_path = Path(root_clicks_json).resolve()
    session = load_capture_session(session_path).session
    reconstruction = load_colmap_text_model(colmap_text_model)
    intrinsics_by_name = {Path(frame.image_path).name: frame.intrinsics for frame in session.frames}
    cameras = tuple(
        ProjectionCamera(pose.image_name, pose, intrinsics_by_name[pose.image_name])
        for pose in reconstruction.poses
        if pose.image_name in intrinsics_by_name
    )
    if len(cameras) != len(reconstruction.poses):
        raise ValueError("not every reconstructed image has capture intrinsics")
    camera_by_name = {camera.image_name: camera for camera in cameras}

    payload: dict[str, Any] = json.loads(clicks_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "root-clicks-1.0":
        raise ValueError("unsupported root-click schema")
    targets = payload.get("trees", [])
    if not isinstance(targets, list) or not targets:
        raise ValueError("root-click file contains no target trees")
    up_vector = None
    if up is not None:
        up_vector = np.asarray(up, dtype=np.float64)
        if up_vector.shape != (3,) or not np.isfinite(up_vector).all():
            raise ValueError("up must be a finite three-vector in reconstruction coordinates")
        norm = float(np.linalg.norm(up_vector))
        if norm <= 1e-9:
            raise ValueError("up cannot be zero")
        up_vector /= norm

    roots = []
    accepted_clicks = 0
    rejected_clicks = 0
    tree_ids: set[int] = set()
    cloud = load_point_cloud(dense_point_cloud) if dense_point_cloud is not None else None
    for target in targets:
        tree_id = int(target["tree_id"])
        if tree_id in tree_ids:
            raise ValueError(f"duplicate target tree id: {tree_id}")
        tree_ids.add(tree_id)
        observations: list[RootPixelObservation] = []
        for item in target.get("observations", []):
            image_name = str(item["image_name"])
            camera = camera_by_name.get(image_name)
            if camera is None:
                raise ValueError(f"root click references an unreconstructed image: {image_name}")
            pixel = np.array([float(item["x_px"]), float(item["y_px"])], dtype=np.float64)
            if not (
                0 <= pixel[0] < camera.intrinsics.width
                and 0 <= pixel[1] < camera.intrinsics.height
            ):
                raise ValueError(f"root click lies outside image {image_name}")
            observations.append(
                RootPixelObservation(image_name, pixel, float(item.get("confidence", 1.0)))
            )
        if len(observations) == 1:
            if cloud is None:
                raise ValueError("a single root click requires the reconstructed dense point cloud")
            observation = observations[0]
            initialized = initialize_root_from_click(
                cloud.points,
                camera_by_name[observation.image_name],
                observation.pixel,
            )
            accepted_clicks += 1
            roots.append(
                {
                    "tree_id": tree_id,
                    "position": initialized.position.tolist(),
                    "confidence": initialized.confidence * observation.confidence,
                    "position_standard_deviation_units": initialized.position_spread_units,
                    "mean_reprojection_error_px": initialized.pixel_residual_px,
                    "maximum_reprojection_error_px": initialized.pixel_residual_px,
                    "parallax_deg": 0.0,
                    "inlier_images": [observation.image_name],
                    "rejected_images": [],
                    "initialization_method": "single_click_dense_surface",
                    "support_point_count": len(initialized.support_indices),
                }
            )
        else:
            root = triangulate_root_anchor(
                cameras,
                tuple(observations),
                tree_id=tree_id,
                maximum_reprojection_error_px=maximum_reprojection_error_px,
                minimum_parallax_deg=minimum_parallax_deg,
            )
            accepted_clicks += len(root.inlier_images)
            rejected_clicks += len(root.rejected_images)
            roots.append(
                {
                    "tree_id": root.tree_id,
                    "position": root.position.tolist(),
                    "confidence": root.confidence,
                    "position_standard_deviation_units": (
                        root.position_standard_deviation_units
                    ),
                    "mean_reprojection_error_px": root.mean_reprojection_error_px,
                    "maximum_reprojection_error_px": root.maximum_reprojection_error_px,
                    "parallax_deg": root.parallax_deg,
                    "inlier_images": list(root.inlier_images),
                    "rejected_images": list(root.rejected_images),
                    "initialization_method": "robust_multiview_clicks",
                }
            )

    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "root-anchors-1.0",
                "coordinate_system": "reconstruction",
                **({"up": up_vector.tolist()} if up_vector is not None else {}),
                "source": {
                    "kind": "user_target_click_initialization",
                    "capture_manifest": str(session_path),
                    "colmap_text_model": str(Path(colmap_text_model).resolve()),
                    "root_clicks": str(clicks_path),
                    "maximum_reprojection_error_px": maximum_reprojection_error_px,
                    "minimum_parallax_deg": minimum_parallax_deg,
                },
                "roots": roots,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return RootClickRun(destination, len(roots), accepted_clicks, rejected_clicks)
