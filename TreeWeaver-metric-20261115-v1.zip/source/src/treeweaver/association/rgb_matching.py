"""Conservative RGB-only matching of tree masks in unordered photographs.

This is a local-feature baseline, not a claim that matched pixels establish
tree identity. Ambiguous pairs are rejected until a stronger identity check.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import cv2
import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class RgbTreeView:
    image_id: str
    image_bgr: npt.NDArray[np.uint8]
    tree_mask: npt.NDArray[np.bool_]

    def __post_init__(self) -> None:
        if not self.image_id.strip():
            raise ValueError("image ID must be nonempty")
        if self.image_bgr.ndim != 3 or self.image_bgr.shape[2] != 3:
            raise ValueError("image must be H x W x 3 BGR")
        if self.image_bgr.dtype != np.uint8 or self.tree_mask.dtype != np.bool_:
            raise ValueError("image and mask must use uint8 and bool dtypes")
        if self.image_bgr.shape[:2] != self.tree_mask.shape or not np.any(self.tree_mask):
            raise ValueError("tree mask must be nonempty and aligned to image")


@dataclass(frozen=True, slots=True)
class RgbPairEvidence:
    left_id: str
    right_id: str
    left_keypoints: int
    right_keypoints: int
    mutual_matches: int
    geometric_inliers: int
    inlier_fraction: float
    accepted: bool
    reason: str


def _features(
    view: RgbTreeView, *, maximum_side: int, feature_count: int, method: str
) -> tuple[list[cv2.KeyPoint], npt.NDArray[np.uint8] | npt.NDArray[np.float32] | None]:
    height, width = view.tree_mask.shape
    scale = min(1.0, maximum_side / max(height, width))
    size = (max(1, round(width * scale)), max(1, round(height * scale)))
    gray = cv2.cvtColor(view.image_bgr, cv2.COLOR_BGR2GRAY)
    mask = view.tree_mask.astype(np.uint8) * 255
    if size != (width, height):
        gray = cv2.resize(gray, size, interpolation=cv2.INTER_AREA)
        mask = np.asarray(cv2.resize(mask, size, interpolation=cv2.INTER_NEAREST), dtype=np.uint8)
    detector = (
        cv2.ORB.create(nfeatures=feature_count)
        if method == "orb"
        else cv2.SIFT.create(nfeatures=feature_count)
    )
    keypoints, descriptors = detector.detectAndCompute(gray, mask)
    if descriptors is None:
        return list(keypoints), None
    if method == "orb":
        return list(keypoints), np.asarray(descriptors, dtype=np.uint8)
    return list(keypoints), np.asarray(descriptors, dtype=np.float32)


def compare_rgb_tree_views(
    left: RgbTreeView,
    right: RgbTreeView,
    *,
    maximum_side: int = 1200,
    feature_count: int = 2500,
    ratio_threshold: float = 0.75,
    minimum_inliers: int = 15,
    minimum_inlier_fraction: float = 0.35,
    feature_method: str = "sift",
) -> RgbPairEvidence:
    """Check tentative local appearance agreement and 2-D geometry.

    A positive result is only a correspondence candidate. Repeated leaves,
    look-alike trees, shared scenery and homography degeneracy can still give
    false identity; downstream measurement must not treat it as verified.
    """

    if left.image_id == right.image_id:
        raise ValueError("pair image IDs must differ")
    if maximum_side < 64 or feature_count < 32:
        raise ValueError("feature extraction resolution/count is too small")
    if not 0 < ratio_threshold < 1 or not 0 < minimum_inlier_fraction <= 1:
        raise ValueError("match thresholds are invalid")
    if minimum_inliers < 4:
        raise ValueError("homography requires at least four inliers")
    if feature_method not in {"orb", "sift"}:
        raise ValueError("feature method must be orb or sift")
    left_points, left_desc = _features(
        left, maximum_side=maximum_side, feature_count=feature_count, method=feature_method
    )
    right_points, right_desc = _features(
        right, maximum_side=maximum_side, feature_count=feature_count, method=feature_method
    )
    base = (left.image_id, right.image_id, len(left_points), len(right_points))
    if left_desc is None or right_desc is None or min(len(left_desc), len(right_desc)) < 4:
        return RgbPairEvidence(*base, 0, 0, 0.0, False, "too few tree-region features")
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING if feature_method == "orb" else cv2.NORM_L2)
    forward = matcher.knnMatch(left_desc, right_desc, k=2)
    backward = matcher.knnMatch(right_desc, left_desc, k=2)

    def good(pairs: Sequence[Sequence[cv2.DMatch]]) -> dict[int, int]:
        return {
            pair[0].queryIdx: pair[0].trainIdx
            for pair in pairs
            if len(pair) == 2 and pair[0].distance < ratio_threshold * pair[1].distance
        }

    direct = good(forward)
    reverse = good(backward)
    mutual = sorted(
        (source, target) for source, target in direct.items() if reverse.get(target) == source
    )
    if len(mutual) < minimum_inliers:
        return RgbPairEvidence(
            *base, len(mutual), 0, 0.0, False, "too few mutual tree-region matches"
        )
    source_xy = np.asarray([left_points[source].pt for source, _ in mutual], dtype=np.float32)
    target_xy = np.asarray([right_points[target].pt for _, target in mutual], dtype=np.float32)
    _, inliers = cv2.findHomography(source_xy, target_xy, cv2.RANSAC, 4.0)
    count = int(np.count_nonzero(inliers)) if inliers is not None else 0
    fraction = count / len(mutual)
    accepted = count >= minimum_inliers and fraction >= minimum_inlier_fraction
    reason = (
        "geometrically consistent candidate" if accepted else "insufficient geometric agreement"
    )
    return RgbPairEvidence(*base, len(mutual), count, fraction, accepted, reason)
