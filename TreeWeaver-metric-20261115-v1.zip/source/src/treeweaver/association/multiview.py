"""Occlusion-aware 2-D instance to persistent 3-D tree association."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose

BoolArray = npt.NDArray[np.bool_]
FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]


@dataclass(frozen=True, slots=True)
class ProjectionCamera:
    image_name: str
    pose: CameraPose
    intrinsics: CameraIntrinsics


@dataclass(frozen=True, slots=True)
class InstanceObservation:
    image_name: str
    local_instance_id: int
    mask: BoolArray
    reliability: float = 1.0

    def __post_init__(self) -> None:
        if self.mask.ndim != 2 or self.mask.dtype != np.bool_:
            raise ValueError("instance mask must be a two-dimensional boolean array")
        if not 0 < self.reliability <= 1:
            raise ValueError("instance reliability must be in (0, 1]")

    @property
    def key(self) -> tuple[str, int]:
        return self.image_name, self.local_instance_id


@dataclass(frozen=True, slots=True)
class ProjectedSupport:
    observation: InstanceObservation
    point_indices: IntArray
    visible_point_count: int


@dataclass(frozen=True, slots=True)
class TreeTrack:
    track_id: int
    members: tuple[tuple[str, int], ...]
    point_indices: IntArray
    consensus_point_indices: IntArray
    association_confidence: float


def project_visible_support(
    points_world: npt.ArrayLike,
    camera: ProjectionCamera,
    observation: InstanceObservation,
    *,
    relative_depth_tolerance: float = 0.01,
    absolute_depth_tolerance: float = 1e-4,
) -> ProjectedSupport:
    """Project points and retain only the front surface selected by a Z-buffer."""
    points = np.asarray(points_world, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points_world must be a finite N x 3 array")
    intrinsics = camera.intrinsics
    if observation.image_name != camera.image_name:
        raise ValueError("camera and observation image names do not match")
    if observation.mask.shape != (intrinsics.height, intrinsics.width):
        raise ValueError("mask dimensions do not match camera intrinsics")

    camera_points = (
        camera.pose.rotation_world_to_camera @ points.T
    ).T + camera.pose.translation_world_to_camera
    depth = camera_points[:, 2]
    positive = depth > 1e-8
    u_float = intrinsics.fx * camera_points[:, 0] / np.maximum(depth, 1e-8) + intrinsics.cx
    v_float = intrinsics.fy * camera_points[:, 1] / np.maximum(depth, 1e-8) + intrinsics.cy
    u = np.rint(u_float).astype(np.int64)
    v = np.rint(v_float).astype(np.int64)
    inside = positive & (u >= 0) & (u < intrinsics.width) & (v >= 0) & (v < intrinsics.height)
    candidate_indices = np.flatnonzero(inside)
    if len(candidate_indices) == 0:
        return ProjectedSupport(observation, np.empty(0, dtype=np.int64), 0)

    pixel = v[candidate_indices] * intrinsics.width + u[candidate_indices]
    z_buffer = np.full(intrinsics.width * intrinsics.height, np.inf, dtype=np.float64)
    np.minimum.at(z_buffer, pixel, depth[candidate_indices])
    nearest = z_buffer[pixel]
    visible = depth[candidate_indices] <= (
        nearest * (1 + relative_depth_tolerance) + absolute_depth_tolerance
    )
    visible_indices = candidate_indices[visible]
    selected = observation.mask[v[visible_indices], u[visible_indices]]
    return ProjectedSupport(
        observation=observation,
        point_indices=visible_indices[selected].astype(np.int64, copy=False),
        visible_point_count=len(visible_indices),
    )


def _weighted_jaccard(left: ProjectedSupport, right: ProjectedSupport) -> float:
    intersection = np.intersect1d(left.point_indices, right.point_indices, assume_unique=True)
    union = len(left.point_indices) + len(right.point_indices) - len(intersection)
    if union == 0:
        return 0.0
    reliability = np.sqrt(left.observation.reliability * right.observation.reliability)
    return float(len(intersection) / union * reliability)


def associate_instances(
    points_world: npt.ArrayLike,
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[InstanceObservation, ...],
    *,
    minimum_support_points: int = 20,
    minimum_jaccard: float = 0.15,
) -> tuple[TreeTrack, ...]:
    """Greedily join local masks while enforcing one instance per view per tree."""
    camera_by_name = {camera.image_name: camera for camera in cameras}
    if len(camera_by_name) != len(cameras):
        raise ValueError("projection camera image names must be unique")
    supports: list[ProjectedSupport] = []
    for observation in observations:
        camera = camera_by_name.get(observation.image_name)
        if camera is None:
            raise ValueError(f"no camera pose for observation {observation.image_name}")
        support = project_visible_support(points_world, camera, observation)
        if len(support.point_indices) >= minimum_support_points:
            supports.append(support)
    if not supports:
        return ()

    parent = list(range(len(supports)))
    component_views = [{support.observation.image_name} for support in supports]

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    edges: list[tuple[float, int, int]] = []
    for left in range(len(supports)):
        for right in range(left + 1, len(supports)):
            if supports[left].observation.image_name == supports[right].observation.image_name:
                continue
            score = _weighted_jaccard(supports[left], supports[right])
            if score >= minimum_jaccard:
                edges.append((score, left, right))

    for _, left, right in sorted(edges, reverse=True):
        root_left, root_right = find(left), find(right)
        if root_left == root_right:
            continue
        if component_views[root_left] & component_views[root_right]:
            continue
        parent[root_right] = root_left
        component_views[root_left] |= component_views[root_right]

    components: dict[int, list[int]] = {}
    for index in range(len(supports)):
        components.setdefault(find(index), []).append(index)

    tracks: list[TreeTrack] = []
    ordered_components = sorted(
        components.values(),
        key=lambda members: min(supports[index].observation.key for index in members),
    )
    for track_id, members in enumerate(ordered_components, start=1):
        arrays = [supports[index].point_indices for index in members]
        all_indices = np.concatenate(arrays)
        unique, votes = np.unique(all_indices, return_counts=True)
        required_votes = 1 if len(members) == 1 else 2
        consensus = unique[votes >= required_votes]
        confidence = float(np.mean(votes / len(members))) if len(votes) else 0.0
        tracks.append(
            TreeTrack(
                track_id=track_id,
                members=tuple(sorted(supports[index].observation.key for index in members)),
                point_indices=unique.astype(np.int64, copy=False),
                consensus_point_indices=consensus.astype(np.int64, copy=False),
                association_confidence=confidence,
            )
        )
    return tuple(tracks)
