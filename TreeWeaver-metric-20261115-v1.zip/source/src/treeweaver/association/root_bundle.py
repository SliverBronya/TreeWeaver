"""Immutable file boundary for root-anchored topology separation."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

from treeweaver.association.root_topology import RootAnchor, assign_points_to_root_anchors
from treeweaver.io.point_cloud import load_point_cloud


@dataclass(frozen=True, slots=True)
class RootSeparationRun:
    output_directory: Path
    tree_count: int
    assigned_point_count: int
    ambiguous_point_count: int
    unreachable_point_count: int


def _load_roots(
    path: Path,
) -> tuple[tuple[RootAnchor, ...], npt.NDArray[np.float64] | None]:
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "root-anchors-1.0":
        raise ValueError("unsupported root-anchor schema")
    up = np.asarray(payload["up"], dtype=np.float64) if "up" in payload else None
    roots = tuple(
        RootAnchor(
            int(item["tree_id"]),
            np.asarray(item["position"], dtype=np.float64),
            float(item.get("confidence", 1.0)),
        )
        for item in payload.get("roots", [])
    )
    if not roots:
        raise ValueError("root-anchor file contains no roots")
    return roots, up


def _load_index_array(path: Path, keys: tuple[str, ...]) -> npt.NDArray[np.int64]:
    with np.load(path, allow_pickle=False) as arrays:
        for key in keys:
            if key in arrays.files:
                return np.unique(np.asarray(arrays[key], dtype=np.int64))
    raise ValueError(f"NPZ requires one of: {', '.join(keys)}")


def _estimate_ground_up(
    points: npt.NDArray[np.float64], ground_indices: npt.NDArray[np.int64]
) -> npt.NDArray[np.float64]:
    if len(ground_indices) < 12:
        raise ValueError("at least 12 ground points are required to infer gravity-up")
    ground = points[ground_indices]
    selected = np.ones(len(ground), dtype=np.bool_)
    normal = np.zeros(3, dtype=np.float64)
    for _ in range(4):
        subset = ground[selected]
        if len(subset) < 12:
            raise ValueError("too few ground-plane inliers to infer gravity-up")
        centre = np.median(subset, axis=0)
        _, _, vh = np.linalg.svd(subset - centre, full_matrices=False)
        normal = vh[-1]
        distances = np.abs((ground - centre) @ normal)
        median = float(np.median(distances))
        mad = float(1.4826 * np.median(np.abs(distances - median)))
        threshold = max(median + 3 * mad, np.quantile(distances, 0.7))
        selected = distances <= threshold
    normal /= np.linalg.norm(normal)
    return normal


def separate_root_bundle(
    point_cloud: str | Path,
    root_anchors_json: str | Path,
    output_directory: str | Path,
    *,
    trunk_probability_npz: str | Path | None = None,
    candidate_indices_npz: str | Path | None = None,
    ground_indices_npz: str | Path | None = None,
    neighbor_count: int = 10,
    maximum_edge_length: float = 0.45,
    maximum_root_distance: float = 0.35,
    ambiguity_ratio: float = 0.12,
) -> RootSeparationRun:
    """Separate one reconstructed scene into root-owned and uncertain points."""

    cloud_path = Path(point_cloud).resolve()
    roots_path = Path(root_anchors_json).resolve()
    cloud = load_point_cloud(cloud_path)
    roots, up = _load_roots(roots_path)
    candidate_indices: npt.NDArray[np.int64] = np.arange(len(cloud.points), dtype=np.int64)
    if candidate_indices_npz is not None:
        candidate_path = Path(candidate_indices_npz).resolve()
        candidate_indices = _load_index_array(
            candidate_path, ("candidate_indices", "point_indices")
        )
        if len(candidate_indices) == 0:
            raise ValueError("candidate point set cannot be empty")
        if candidate_indices[0] < 0 or candidate_indices[-1] >= len(cloud.points):
            raise ValueError("candidate point index lies outside the point cloud")
    up_source = "root_anchor"
    if up is None:
        if ground_indices_npz is None:
            raise ValueError(
                "gravity-up is absent; provide semantic ground indices for automatic estimation"
            )
        ground_indices = _load_index_array(
            Path(ground_indices_npz).resolve(), ("ground_indices",)
        )
        if ground_indices[0] < 0 or ground_indices[-1] >= len(cloud.points):
            raise ValueError("ground point index lies outside the point cloud")
        up = _estimate_ground_up(cloud.points, ground_indices)
        up_source = "robust_ground_plane"
    trunk_probability = None
    if trunk_probability_npz is not None:
        probability_path = Path(trunk_probability_npz).resolve()
        with np.load(probability_path, allow_pickle=False) as arrays:
            if "trunk_probability" in arrays.files:
                trunk_probability = np.asarray(arrays["trunk_probability"], dtype=np.float64)
            elif {"trunk_indices", "trunk_reliability"}.issubset(arrays.files):
                indices = np.asarray(arrays["trunk_indices"], dtype=np.int64)
                reliability = np.asarray(arrays["trunk_reliability"], dtype=np.float64)
                if len(indices) != len(reliability):
                    raise ValueError("semantic trunk indices and reliability lengths disagree")
                if len(indices) and (indices.min() < 0 or indices.max() >= len(cloud.points)):
                    raise ValueError("semantic trunk index lies outside the point cloud")
                trunk_probability = np.zeros(len(cloud.points), dtype=np.float64)
                np.maximum.at(trunk_probability, indices, reliability)
            else:
                raise ValueError(
                    "trunk evidence NPZ requires probabilities or semantic trunk evidence"
                )
        if trunk_probability.shape == (len(cloud.points),):
            trunk_probability = trunk_probability[candidate_indices]
        elif trunk_probability.shape != (len(candidate_indices),):
            raise ValueError("trunk probabilities must match the cloud or candidate point count")

    candidate_assignment = assign_points_to_root_anchors(
        cloud.points[candidate_indices],
        roots,
        trunk_probability=trunk_probability,
        up=up,
        neighbor_count=neighbor_count,
        maximum_edge_length=maximum_edge_length,
        maximum_root_distance=maximum_root_distance,
        ambiguity_ratio=ambiguity_ratio,
    )
    labels = np.full(len(cloud.points), -1, dtype=np.int64)
    confidence = np.zeros(len(cloud.points), dtype=np.float64)
    labels[candidate_indices] = candidate_assignment.labels
    confidence[candidate_indices] = candidate_assignment.confidence
    ambiguous_indices = candidate_indices[candidate_assignment.ambiguous_indices]
    unreachable_indices = np.flatnonzero(labels < 0).astype(np.int64, copy=False)
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    np.savez_compressed(
        output / "root-assignment.npz",
        labels=labels,
        confidence=confidence,
        ambiguous_indices=ambiguous_indices,
        unreachable_indices=unreachable_indices,
    )
    assigned = int(np.count_nonzero(labels > 0))
    metadata = {
        "schema_version": "root-assignment-1.0",
        "point_cloud": str(cloud_path),
        "root_anchors": str(roots_path),
        "parameters": {
            "neighbor_count": neighbor_count,
            "maximum_edge_length": maximum_edge_length,
            "maximum_root_distance": maximum_root_distance,
            "ambiguity_ratio": ambiguity_ratio,
            "candidate_point_count": len(candidate_indices),
            "up_source": up_source,
            "up": up.tolist(),
        },
        "trees": [
            {
                "tree_id": root.tree_id,
                "root_confidence": root.confidence,
                "assigned_points": int(np.count_nonzero(labels == root.tree_id)),
            }
            for root in roots
        ],
        "assigned_points": assigned,
        "ambiguous_points": len(ambiguous_indices),
        "unreachable_points": len(unreachable_indices),
    }
    (output / "root-assignment.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return RootSeparationRun(
        output,
        len(roots),
        assigned,
        len(ambiguous_indices),
        len(unreachable_indices),
    )
