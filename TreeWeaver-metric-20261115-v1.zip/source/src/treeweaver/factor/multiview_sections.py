"""Derive reliability-aware TreeFactor cross-sections from one view's 3-D support."""

from __future__ import annotations

import numpy as np
import numpy.typing as npt

from treeweaver.factor.tree_factor import CrossSectionObservation
from treeweaver.geometry.cross_section import fit_trunk_cross_section


def fit_view_cross_section(
    view_id: str,
    points_reconstruction: npt.ArrayLike,
    root_reconstruction: npt.ArrayLike,
    axis: npt.ArrayLike,
    initial_scale: float,
    reliability: float,
    *,
    target_height_m: float = 1.3,
    half_window_m: float = 0.18,
) -> CrossSectionObservation | None:
    points = np.asarray(points_reconstruction, dtype=np.float64)
    root = np.asarray(root_reconstruction, dtype=np.float64)
    direction = np.asarray(axis, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or root.shape != (3,) or direction.shape != (3,):
        raise ValueError("view cross-section inputs have invalid dimensions")
    if initial_scale <= 0 or not 0 < reliability <= 1 or half_window_m <= 0:
        raise ValueError("view cross-section scale, reliability, or window is invalid")
    norm = float(np.linalg.norm(direction))
    if norm <= 0:
        raise ValueError("trunk axis cannot be zero")
    direction = direction / norm
    relative = points - root
    axial = relative @ direction
    axial_m = axial * initial_scale
    selected = np.abs(axial_m - target_height_m) <= half_window_m
    if np.count_nonzero(selected) < 16:
        return None
    radial = relative[selected] - np.outer(axial[selected], direction)
    reference = np.array([1.0, 0.0, 0.0])
    if abs(float(reference @ direction)) > 0.9:
        reference = np.array([0.0, 1.0, 0.0])
    basis_x = np.cross(direction, reference)
    basis_x /= np.linalg.norm(basis_x)
    basis_y = np.cross(direction, basis_x)
    section_2d = np.column_stack((radial @ basis_x, radial @ basis_y))
    fitted = fit_trunk_cross_section(section_2d)
    coverage_factor = float(np.clip(fitted.angular_coverage_deg / 180.0, 0.05, 1.0))
    effective_reliability = float(np.clip(reliability * coverage_factor, 0.01, 1.0))
    deviation_m = max(0.004, fitted.residual_standard_deviation * initial_scale)
    return CrossSectionObservation(
        view_id=view_id,
        axial_height_reconstruction=float(np.median(axial[selected])),
        radius_reconstruction=fitted.circumference_equivalent_diameter / 2.0,
        standard_deviation_m=deviation_m / np.sqrt(coverage_factor),
        reliability=effective_reliability,
    )
