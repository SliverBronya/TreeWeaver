"""Reproducible file boundary for TreeFactor experiments."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from treeweaver.factor.tree_factor import (
    CrossSectionObservation,
    TreeFactorResult,
    optimize_tree_factor,
)
from treeweaver.reconstruction.scale_registration import AnchorCorrespondence


@dataclass(frozen=True, slots=True)
class TreeFactorRunResult:
    output_path: Path
    result: TreeFactorResult


def load_anchor_correspondences(path: str | Path) -> tuple[AnchorCorrespondence, ...]:
    path = Path(path).resolve()
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "treefactor-anchors-1.0":
        raise ValueError("unsupported TreeFactor anchor schema")
    anchors = tuple(
        AnchorCorrespondence(
            kind=str(item["kind"]),
            metric_length_m=float(item["metric_length_m"]),
            endpoint_a=np.asarray(item["endpoint_a"], dtype=np.float64),
            endpoint_b=np.asarray(item["endpoint_b"], dtype=np.float64),
            confidence=float(item.get("confidence", 1.0)),
        )
        for item in payload.get("anchors", [])
    )
    if not anchors:
        raise ValueError("anchor file contains no anchors")
    return anchors


def tree_factor_payload(result: TreeFactorResult) -> dict[str, object]:
    return {
        "schema_version": "treefactor-result-1.0",
        "success": result.success,
        "scale_metres_per_unit": result.scale_metres_per_unit,
        "scale_standard_deviation": result.scale_standard_deviation,
        "root_reconstruction": result.root_reconstruction.tolist(),
        "ground_normal": result.ground_normal.tolist(),
        "trunk_axis": result.trunk_axis.tolist(),
        "height": {
            "value_m": result.height.value,
            "standard_deviation_m": result.height.standard_deviation,
            "confidence": result.height.confidence,
        },
        "dbh": {
            "value_cm": result.dbh.value,
            "standard_deviation_cm": result.dbh.standard_deviation,
            "confidence": result.dbh.confidence,
        },
        "volume": {
            "value_m3": result.volume.value,
            "standard_deviation_m3": result.volume.standard_deviation,
            "confidence": result.volume.confidence,
            "diagnostics": list(result.volume.diagnostics),
        },
        "taper_m_per_m": result.taper_m_per_m,
        "covariance": result.covariance.tolist(),
        "cost": result.cost,
        "optimality": result.optimality,
        "evaluations": result.evaluations,
        "diagnostics": list(result.diagnostics),
    }


def optimize_tree_factor_file(
    points_path: str | Path,
    anchors_path: str | Path,
    output_path: str | Path,
) -> TreeFactorRunResult:
    """Optimize arrays from NPZ and write a versioned, auditable JSON result."""
    with np.load(Path(points_path).resolve(), allow_pickle=False) as arrays:
        trunk = np.asarray(arrays["trunk_points"], dtype=np.float64)
        crown = np.asarray(arrays["crown_points"], dtype=np.float64)
        ground = np.asarray(arrays["ground_points"], dtype=np.float64)
        trunk_reliability = (
            np.asarray(arrays["trunk_reliability"], dtype=np.float64)
            if "trunk_reliability" in arrays
            else None
        )
        ground_reliability = (
            np.asarray(arrays["ground_reliability"], dtype=np.float64)
            if "ground_reliability" in arrays
            else None
        )
        if "cross_section_view_ids" in arrays:
            view_ids = np.asarray(arrays["cross_section_view_ids"])
            heights = np.asarray(arrays["cross_section_heights"], dtype=np.float64)
            radii = np.asarray(arrays["cross_section_radii"], dtype=np.float64)
            deviations = np.asarray(
                arrays["cross_section_standard_deviations_m"], dtype=np.float64
            )
            reliabilities = np.asarray(
                arrays["cross_section_reliabilities"], dtype=np.float64
            )
            lengths = {len(view_ids), len(heights), len(radii), len(deviations), len(reliabilities)}
            if len(lengths) != 1:
                raise ValueError("cross-section observation arrays must have equal length")
            cross_sections = tuple(
                CrossSectionObservation(
                    str(view_id),
                    float(height),
                    float(radius),
                    float(deviation),
                    float(reliability),
                )
                for view_id, height, radius, deviation, reliability in zip(
                    view_ids, heights, radii, deviations, reliabilities, strict=True
                )
            )
        else:
            cross_sections = ()
    anchors = load_anchor_correspondences(anchors_path)
    result = optimize_tree_factor(
        trunk,
        crown,
        ground,
        anchors,
        trunk_reliability=trunk_reliability,
        ground_reliability=ground_reliability,
        cross_sections=cross_sections,
    )
    destination = Path(output_path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(tree_factor_payload(result), ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8",
    )
    return TreeFactorRunResult(destination, result)
