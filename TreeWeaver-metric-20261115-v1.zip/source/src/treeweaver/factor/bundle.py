"""Run TreeFactor independently over every fused semantic tree track."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

from treeweaver.factor.file_optimization import (
    load_anchor_correspondences,
    tree_factor_payload,
)
from treeweaver.factor.multiview_sections import fit_view_cross_section
from treeweaver.factor.tree_factor import estimate_initial_tree_frame, optimize_tree_factor
from treeweaver.io.point_cloud import load_point_cloud
from treeweaver.reconstruction.scale_registration import estimate_scale_from_correspondences

IntArray = npt.NDArray[np.int64]
FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class TreeFactorBundleResult:
    output_path: Path
    successful_trees: int
    failed_trees: int


def _slice(flat: IntArray, offsets: IntArray, index: int) -> IntArray:
    return flat[offsets[index] : offsets[index + 1]]


def _slice_float(flat: FloatArray, offsets: IntArray, index: int) -> FloatArray:
    return flat[offsets[index] : offsets[index + 1]]


def _local_ground(
    points: FloatArray,
    ground_indices: IntArray,
    trunk_indices: IntArray,
    radius_reconstruction: float,
) -> IntArray:
    if len(ground_indices) == 0 or len(trunk_indices) == 0:
        return np.empty(0, dtype=np.int64)
    trunk = points[trunk_indices]
    if len(trunk) > 1000:
        trunk = trunk[np.linspace(0, len(trunk) - 1, 1000, dtype=np.int64)]
    accepted: list[IntArray] = []
    for start in range(0, len(ground_indices), 2000):
        indices = ground_indices[start : start + 2000]
        ground = points[indices]
        squared = np.sum((ground[:, None, :] - trunk[None, :, :]) ** 2, axis=2)
        accepted.append(indices[np.min(squared, axis=1) <= radius_reconstruction**2])
    return np.concatenate(accepted) if accepted else np.empty(0, dtype=np.int64)


def optimize_tree_factor_bundle(
    dense_point_cloud: str | Path,
    semantic_directory: str | Path,
    anchors_path: str | Path,
    output_path: str | Path,
    *,
    ground_radius_m: float = 2.0,
) -> TreeFactorBundleResult:
    if ground_radius_m <= 0:
        raise ValueError("ground radius must be positive")
    cloud = load_point_cloud(dense_point_cloud)
    semantic_root = Path(semantic_directory).resolve()
    metadata: dict[str, Any] = json.loads(
        (semantic_root / "semantics.json").read_text(encoding="utf-8")
    )
    if metadata.get("schema_version") != "semantic-tracks-1.0":
        raise ValueError("unsupported semantic-track schema")
    with np.load(semantic_root / "semantic-points.npz", allow_pickle=False) as arrays:
        trunk = np.asarray(arrays["trunk_indices"], dtype=np.int64)
        trunk_offsets = np.asarray(arrays["trunk_offsets"], dtype=np.int64)
        crown = np.asarray(arrays["crown_indices"], dtype=np.int64)
        crown_offsets = np.asarray(arrays["crown_offsets"], dtype=np.int64)
        ground = np.asarray(arrays["ground_indices"], dtype=np.int64)
        trunk_reliability = (
            np.asarray(arrays["trunk_reliability"], dtype=np.float64)
            if "trunk_reliability" in arrays
            else None
        )
        ground_reliability = (
            np.asarray(arrays["ground_reliability"], dtype=np.float64)
            if "ground_reliability" in arrays
            else None
        )
        trunk_view_indices = (
            np.asarray(arrays["trunk_view_indices"], dtype=np.int64)
            if "trunk_view_indices" in arrays
            else np.empty(0, dtype=np.int64)
        )
        trunk_view_offsets = (
            np.asarray(arrays["trunk_view_offsets"], dtype=np.int64)
            if "trunk_view_offsets" in arrays
            else np.zeros(1, dtype=np.int64)
        )
    tracks = metadata.get("tracks", [])
    if len(trunk_offsets) != len(tracks) + 1 or len(crown_offsets) != len(tracks) + 1:
        raise ValueError("semantic metadata and point offsets disagree")

    anchors = load_anchor_correspondences(anchors_path)
    initial_scale = estimate_scale_from_correspondences(anchors).metres_per_unit
    ground_radius_reconstruction = ground_radius_m / initial_scale
    ground_confidence = float(np.clip(metadata.get("ground_confidence", 1.0), 0.05, 1.0))
    if trunk_reliability is not None and len(trunk_reliability) != len(trunk):
        raise ValueError("trunk indices and reliability lengths disagree")
    if ground_reliability is not None and len(ground_reliability) != len(ground):
        raise ValueError("ground indices and reliability lengths disagree")
    ground_reliability_by_index = np.full(len(cloud.points), ground_confidence)
    if ground_reliability is not None:
        ground_reliability_by_index[ground] = ground_reliability
    section_metadata = metadata.get("trunk_view_sections", [])
    if len(trunk_view_offsets) != len(section_metadata) + 1:
        raise ValueError("trunk view metadata and point offsets disagree")
    results: list[dict[str, object]] = []
    successes = 0
    failures = 0
    for index, track in enumerate(tracks):
        trunk_indices = _slice(trunk, trunk_offsets, index)
        crown_indices = _slice(crown, crown_offsets, index)
        nearby_ground = _local_ground(
            cloud.points, ground, trunk_indices, ground_radius_reconstruction
        )
        semantic_confidence = float(np.clip(track.get("semantic_confidence", 1.0), 0.05, 1.0))
        track_trunk_reliability = (
            _slice_float(trunk_reliability, trunk_offsets, index)
            if trunk_reliability is not None
            else np.full(len(trunk_indices), semantic_confidence)
        )
        try:
            track_sections = tuple(
                (section_index, section_item)
                for section_index, section_item in enumerate(section_metadata)
                if int(section_item["track_id"]) == int(track["track_id"])
            )
            if track_sections:
                root0, _, axis0 = estimate_initial_tree_frame(
                    cloud.points[trunk_indices],
                    cloud.points[crown_indices],
                    cloud.points[nearby_ground],
                )
                fitted_sections = (
                    fit_view_cross_section(
                        str(section_item["view_id"]),
                        cloud.points[
                            trunk_view_indices[
                                trunk_view_offsets[section_index] : trunk_view_offsets[
                                    section_index + 1
                                ]
                            ]
                        ],
                        root0,
                        axis0,
                        initial_scale,
                        float(section_item["reliability"]),
                    )
                    for section_index, section_item in track_sections
                )
                cross_sections = tuple(
                    section for section in fitted_sections if section is not None
                )
            else:
                cross_sections = ()
            optimized = optimize_tree_factor(
                cloud.points[trunk_indices],
                cloud.points[crown_indices],
                cloud.points[nearby_ground],
                anchors,
                trunk_reliability=track_trunk_reliability,
                ground_reliability=ground_reliability_by_index[nearby_ground],
                cross_sections=cross_sections,
            )
            item = tree_factor_payload(optimized)
            item.update(
                {
                    "track_id": int(track["track_id"]),
                    "status": "ok" if optimized.success else "not_converged",
                    "semantic_confidence": semantic_confidence,
                    "local_ground_points": len(nearby_ground),
                    "cross_section_views": len(cross_sections),
                }
            )
            results.append(item)
            successes += int(optimized.success)
            failures += int(not optimized.success)
        except ValueError as error:
            results.append(
                {
                    "track_id": int(track["track_id"]),
                    "status": "failed",
                    "reason": str(error),
                    "trunk_points": len(trunk_indices),
                    "crown_points": len(crown_indices),
                    "local_ground_points": len(nearby_ground),
                }
            )
            failures += 1

    payload = {
        "schema_version": "treefactor-tracks-1.0",
        "dense_point_cloud": str(Path(dense_point_cloud).resolve()),
        "semantic_directory": str(semantic_root),
        "anchors": str(Path(anchors_path).resolve()),
        "initial_scale_metres_per_unit": initial_scale,
        "trees": results,
    }
    destination = Path(output_path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )
    return TreeFactorBundleResult(destination, successes, failures)
