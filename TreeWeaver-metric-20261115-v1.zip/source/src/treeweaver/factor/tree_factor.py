"""TreeFactor v0: joint robust metric-scale and tree-structure optimization."""

from __future__ import annotations

from dataclasses import dataclass
from math import exp
from typing import cast

import numpy as np
import numpy.typing as npt
from scipy.optimize import least_squares

from treeweaver.domain.models import Parameter, ParameterEstimate
from treeweaver.reconstruction.scale_registration import (
    AnchorCorrespondence,
    estimate_scale_from_correspondences,
)

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class TreeFactorConfig:
    ground_sigma_m: float = 0.025
    trunk_surface_sigma_m: float = 0.020
    top_sigma_m: float = 0.08
    root_prior_sigma_m: float = 0.15
    axis_prior_sigma: float = 0.15
    anchor_relative_sigma: float = 0.01
    minimum_anchor_sigma_m: float = 0.005
    maximum_points_per_part: int = 2500
    robust_f_scale: float = 1.0
    maximum_evaluations: int = 300


@dataclass(frozen=True, slots=True)
class CrossSectionObservation:
    """One view-specific trunk radius observation in reconstruction units."""

    view_id: str
    axial_height_reconstruction: float
    radius_reconstruction: float
    standard_deviation_m: float
    reliability: float

    def __post_init__(self) -> None:
        if not self.view_id:
            raise ValueError("cross-section observation requires a view id")
        if self.axial_height_reconstruction < 0 or self.radius_reconstruction <= 0:
            raise ValueError("cross-section height and radius are invalid")
        if self.standard_deviation_m <= 0 or not 0 < self.reliability <= 1:
            raise ValueError("cross-section uncertainty or reliability is invalid")


@dataclass(frozen=True, slots=True)
class TreeFactorResult:
    success: bool
    scale_metres_per_unit: float
    scale_standard_deviation: float
    root_reconstruction: FloatArray
    ground_normal: FloatArray
    trunk_axis: FloatArray
    height: ParameterEstimate
    dbh: ParameterEstimate
    volume: ParameterEstimate
    taper_m_per_m: float
    covariance: FloatArray
    cost: float
    optimality: float
    evaluations: int
    diagnostics: tuple[str, ...]


def _points(value: npt.ArrayLike, name: str, minimum: int) -> FloatArray:
    points = np.asarray(value, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < minimum:
        raise ValueError(f"{name} requires at least {minimum} three-dimensional points")
    if not np.isfinite(points).all():
        raise ValueError(f"{name} contains non-finite coordinates")
    return points


def _sample(points: FloatArray, maximum: int) -> FloatArray:
    if len(points) <= maximum:
        return points
    indices = np.linspace(0, len(points) - 1, maximum, dtype=np.int64)
    return points[indices]


def _sample_vector(values: FloatArray, maximum: int) -> FloatArray:
    if len(values) <= maximum:
        return values
    indices = np.linspace(0, len(values) - 1, maximum, dtype=np.int64)
    return values[indices]


def _soft_l1_residual(values: FloatArray, scale: float) -> FloatArray:
    """Encode a soft-L1 penalty while leaving hard constraints Gaussian.

    Applying SciPy's global robust loss would also down-weight the few metric
    anchors relative to thousands of surface points. This residual transform
    robustifies only the noisy geometric observations.
    """
    normalized = values / scale
    magnitude = np.sqrt(2.0 * (np.sqrt(1.0 + normalized**2) - 1.0))
    return cast(FloatArray, np.sign(values) * magnitude * scale)


def estimate_initial_tree_frame(
    trunk: FloatArray, crown: FloatArray, ground: FloatArray
) -> tuple[FloatArray, FloatArray, FloatArray]:
    ground_centre = np.median(ground, axis=0)
    _, _, ground_vh = np.linalg.svd(ground - ground_centre, full_matrices=False)
    normal = ground_vh[-1]
    tree_centre = np.median(np.vstack((trunk, crown)), axis=0)
    if float((tree_centre - ground_centre) @ normal) < 0:
        normal = -normal
    normal /= np.linalg.norm(normal)

    trunk_centre = np.median(trunk, axis=0)
    _, _, trunk_vh = np.linalg.svd(trunk - trunk_centre, full_matrices=False)
    axis = trunk_vh[0]
    if float(axis @ normal) < 0:
        axis = -axis
    axis /= np.linalg.norm(axis)
    if float(axis @ normal) < 0.55:
        raise ValueError("initial trunk axis is inconsistent with the ground normal")

    heights = (trunk - ground_centre) @ normal
    root_points = trunk[heights <= np.quantile(heights, 0.05)]
    root = np.median(root_points, axis=0)
    root -= normal * float((root - ground_centre) @ normal)
    return cast(FloatArray, root), cast(FloatArray, normal), cast(FloatArray, axis)


def _parameter_estimate(
    parameter: Parameter,
    value: float,
    standard_deviation: float,
    count: int,
    diagnostics: tuple[str, ...] = (),
) -> ParameterEstimate:
    relative = standard_deviation / max(abs(value), 1e-12)
    confidence = (1 - exp(-count / 50)) * exp(-3 * relative)
    return ParameterEstimate(
        parameter,
        value,
        standard_deviation,
        float(max(0.0, min(1.0, confidence))),
        count,
        diagnostics,
    )


def _stem_volume(log_radius: float, taper: float, log_height: float) -> float:
    """Integrate a linear-radius solid of revolution from root to estimated top."""
    radius_breast_height = exp(log_radius)
    height = exp(log_height)
    intercept = radius_breast_height - 1.3 * taper
    return float(
        np.pi * (intercept**2 * height + intercept * taper * height**2 + taper**2 * height**3 / 3.0)
    )


def _volume_gradient(values: FloatArray) -> FloatArray:
    gradient = np.zeros(len(values), dtype=np.float64)
    for index in (7, 8, 9):
        step = 1e-5 * max(1.0, abs(float(values[index])))
        upper = values.copy()
        lower = values.copy()
        upper[index] += step
        lower[index] -= step
        gradient[index] = (
            _stem_volume(upper[7], upper[8], upper[9]) - _stem_volume(lower[7], lower[8], lower[9])
        ) / (2 * step)
    return gradient


def optimize_tree_factor(
    trunk_points: npt.ArrayLike,
    crown_points: npt.ArrayLike,
    ground_points: npt.ArrayLike,
    anchors: tuple[AnchorCorrespondence, ...],
    *,
    trunk_reliability: npt.ArrayLike | None = None,
    ground_reliability: npt.ArrayLike | None = None,
    cross_sections: tuple[CrossSectionObservation, ...] = (),
    config: TreeFactorConfig | None = None,
) -> TreeFactorResult:
    """Jointly estimate metric scale and one tree's structural parameters."""
    settings = config if config is not None else TreeFactorConfig()
    trunk_all = _points(trunk_points, "trunk_points", 40)
    crown_all = _points(crown_points, "crown_points", 30)
    ground_all = _points(ground_points, "ground_points", 20)
    if not anchors:
        raise ValueError("TreeFactor requires at least one explicit metric anchor")
    initial_scale = estimate_scale_from_correspondences(anchors)
    root0, normal, axis0 = estimate_initial_tree_frame(trunk_all, crown_all, ground_all)

    trunk = _sample(trunk_all, settings.maximum_points_per_part)
    crown = _sample(crown_all, settings.maximum_points_per_part)
    ground = _sample(ground_all, settings.maximum_points_per_part)
    if trunk_reliability is None:
        trunk_weight: FloatArray = np.ones(len(trunk), dtype=np.float64)
    else:
        reliability = np.asarray(trunk_reliability, dtype=np.float64)
        if reliability.shape != (len(trunk_all),) or np.any((reliability <= 0) | (reliability > 1)):
            raise ValueError("trunk reliability must contain values in (0, 1]")
        trunk_weight = _sample_vector(reliability, settings.maximum_points_per_part)
    if ground_reliability is None:
        ground_weight: FloatArray = np.ones(len(ground), dtype=np.float64)
    else:
        reliability = np.asarray(ground_reliability, dtype=np.float64)
        if reliability.shape != (len(ground_all),) or np.any(
            (reliability <= 0) | (reliability > 1)
        ):
            raise ValueError("ground reliability must contain values in (0, 1]")
        ground_weight = _sample_vector(reliability, settings.maximum_points_per_part)

    scale0 = initial_scale.metres_per_unit
    relative_trunk = trunk - root0
    axial0 = relative_trunk @ axis0
    radial0 = np.linalg.norm(relative_trunk - np.outer(axial0, axis0), axis=1) * scale0
    lower = (axial0 * scale0 > 0.3) & (axial0 * scale0 < 3.0)
    radius0 = float(np.median(radial0[lower])) if np.any(lower) else float(np.median(radial0))
    tree_vertical0 = (np.vstack((trunk, crown)) - root0) @ normal * scale0
    height0 = max(1.0, float(np.quantile(tree_vertical0, 0.995)))
    x0 = np.r_[
        np.log(scale0),
        root0,
        axis0,
        np.log(max(radius0, 0.01)),
        -0.005,
        np.log(height0),
    ]
    extent = max(float(np.ptp(np.vstack((trunk, crown, ground)), axis=0).max()), 1.0)
    lower_bounds = np.r_[
        np.log(scale0 / 5),
        root0 - extent,
        [-2.0, -2.0, -2.0],
        np.log(0.005),
        -0.15,
        np.log(0.5),
    ]
    upper_bounds = np.r_[
        np.log(scale0 * 5),
        root0 + extent,
        [2.0, 2.0, 2.0],
        np.log(3.0),
        0.08,
        np.log(100.0),
    ]
    anchor_lengths = np.array([anchor.reconstructed_length() for anchor in anchors])
    anchor_metric = np.array([anchor.metric_length_m for anchor in anchors])
    anchor_sigma = np.maximum(
        settings.minimum_anchor_sigma_m,
        settings.anchor_relative_sigma
        * anchor_metric
        / np.maximum(np.array([anchor.confidence for anchor in anchors]), 0.05),
    )
    section_heights = np.array(
        [item.axial_height_reconstruction for item in cross_sections], dtype=np.float64
    )
    section_radii = np.array(
        [item.radius_reconstruction for item in cross_sections], dtype=np.float64
    )
    section_sigma = np.array(
        [item.standard_deviation_m for item in cross_sections], dtype=np.float64
    )
    section_weight = np.sqrt(
        np.array([item.reliability for item in cross_sections], dtype=np.float64)
    )

    def residuals(values: FloatArray) -> FloatArray:
        scale = float(np.exp(values[0]))
        root = values[1:4]
        raw_axis = values[4:7]
        axis_norm = max(float(np.linalg.norm(raw_axis)), 1e-9)
        axis = raw_axis / axis_norm
        radius = float(np.exp(values[7]))
        taper = float(values[8])
        height = float(np.exp(values[9]))

        anchor_residual = (scale * anchor_lengths - anchor_metric) / anchor_sigma
        ground_residual = (scale * ((ground - root) @ normal) / settings.ground_sigma_m) * np.sqrt(
            ground_weight
        )
        relative = trunk - root
        axial_reconstruction = relative @ axis
        axial_m = scale * axial_reconstruction
        radial_m = scale * np.linalg.norm(relative - np.outer(axial_reconstruction, axis), axis=1)
        expected_radius = radius + taper * (axial_m - 1.3)
        surface_residual = (
            (radial_m - expected_radius) / settings.trunk_surface_sigma_m
        ) * np.sqrt(trunk_weight)

        tree_vertical = (np.vstack((trunk, crown)) - root) @ normal * scale
        observed_top = float(np.quantile(tree_vertical, 0.995))
        top_residual = np.array([(height - observed_top) / settings.top_sigma_m])
        root_prior = scale * (root - root0) / settings.root_prior_sigma_m
        axis_prior = (axis - axis0) / settings.axis_prior_sigma
        unit_axis = np.array([(axis_norm - 1.0) / 0.02])
        below_ground = np.minimum(axial_m, 0.0) / 0.05
        radius_at_root = radius - 1.3 * taper
        radius_at_top = radius + taper * (height - 1.3)
        positive_radius = np.array(
            [min(radius_at_root - 0.005, 0.0) / 0.01, min(radius_at_top - 0.005, 0.0) / 0.01]
        )
        expected_section_radius = radius + taper * (scale * section_heights - 1.3)
        cross_section_residual = (
            (scale * section_radii - expected_section_radius)
            / np.maximum(section_sigma, 1e-9)
        ) * section_weight
        robust_ground = _soft_l1_residual(
            ground_residual / np.sqrt(ground_weight), settings.robust_f_scale
        ) * np.sqrt(ground_weight)
        robust_surface = _soft_l1_residual(
            surface_residual / np.sqrt(trunk_weight), settings.robust_f_scale
        ) * np.sqrt(trunk_weight)
        robust_below_ground = _soft_l1_residual(below_ground, settings.robust_f_scale) * np.sqrt(
            trunk_weight
        )
        return np.concatenate(
            (
                anchor_residual,
                robust_ground,
                robust_surface,
                top_residual,
                root_prior,
                axis_prior,
                unit_axis,
                robust_below_ground,
                positive_radius,
                cross_section_residual,
            )
        )

    optimized = least_squares(
        residuals,
        x0,
        bounds=(lower_bounds, upper_bounds),
        loss="linear",
        max_nfev=settings.maximum_evaluations,
        x_scale="jac",
    )
    values = optimized.x
    scale = float(np.exp(values[0]))
    root = values[1:4]
    axis = values[4:7] / np.linalg.norm(values[4:7])
    radius = float(np.exp(values[7]))
    taper = float(values[8])
    height = float(np.exp(values[9]))
    degrees_of_freedom = max(len(optimized.fun) - len(values), 1)
    residual_variance = 2 * optimized.cost / degrees_of_freedom
    covariance = np.linalg.pinv(optimized.jac.T @ optimized.jac) * residual_variance
    parameter_sd = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    scale_sd = scale * float(parameter_sd[0])
    radius_sd = radius * float(parameter_sd[7])
    height_sd = height * float(parameter_sd[9])
    volume = _stem_volume(values[7], taper, values[9])
    volume_gradient = _volume_gradient(values)
    volume_variance = float(volume_gradient @ covariance @ volume_gradient)
    volume_sd = float(np.sqrt(max(volume_variance, 0.0)))
    diagnostics: list[str] = []
    if not optimized.success:
        diagnostics.append(str(optimized.message))
    if np.linalg.cond(optimized.jac.T @ optimized.jac) > 1e12:
        diagnostics.append("factor system is poorly conditioned")
    if cross_sections:
        diagnostics.append(f"used {len(cross_sections)} view-specific cross-section factors")
    return TreeFactorResult(
        success=bool(optimized.success),
        scale_metres_per_unit=scale,
        scale_standard_deviation=scale_sd,
        root_reconstruction=root.astype(np.float64, copy=False),
        ground_normal=normal,
        trunk_axis=axis.astype(np.float64, copy=False),
        height=_parameter_estimate(
            Parameter.HEIGHT_M, height, height_sd, len(trunk) + len(crown), tuple(diagnostics)
        ),
        dbh=_parameter_estimate(
            Parameter.DBH_CM, radius * 200, radius_sd * 200, len(trunk), tuple(diagnostics)
        ),
        volume=_parameter_estimate(
            Parameter.VOLUME_M3,
            volume,
            volume_sd,
            len(trunk),
            (*diagnostics, "linear-taper geometric stem model; no species form factor"),
        ),
        taper_m_per_m=taper,
        covariance=covariance.astype(np.float64, copy=False),
        cost=float(optimized.cost),
        optimality=float(optimized.optimality),
        evaluations=int(optimized.nfev),
        diagnostics=tuple(diagnostics),
    )
