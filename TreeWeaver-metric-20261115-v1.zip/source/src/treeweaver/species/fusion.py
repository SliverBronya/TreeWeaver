"""Dependence-aware fusion for replaceable species classifiers."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from math import exp, log


class Organ(StrEnum):
    LEAF = "leaf"
    BARK = "bark"
    CROWN = "crown"
    FLOWER = "flower"
    FRUIT = "fruit"
    WHOLE_TREE = "whole_tree"


@dataclass(frozen=True, slots=True)
class SpeciesEvidence:
    view_id: str
    organ: Organ
    probabilities: dict[str, float]
    reliability: float
    provider: str

    def __post_init__(self) -> None:
        if not self.view_id or not self.provider or not self.probabilities:
            raise ValueError("species evidence requires view, provider and candidates")
        if not 0 < self.reliability <= 1:
            raise ValueError("species reliability must be in (0, 1]")
        if any(value < 0 for value in self.probabilities.values()):
            raise ValueError("species probabilities cannot be negative")
        total = sum(self.probabilities.values())
        if abs(total - 1.0) > 1e-6:
            raise ValueError("species probabilities must sum to one")


@dataclass(frozen=True, slots=True)
class SpeciesResult:
    candidates: tuple[tuple[str, float], ...]
    accepted_name: str | None
    confidence: float
    normalized_entropy: float
    contributing_views: int
    contributing_organs: tuple[Organ, ...]
    diagnostics: tuple[str, ...]


def fuse_species_evidence(
    evidence: tuple[SpeciesEvidence, ...],
    *,
    minimum_confidence: float = 0.65,
    maximum_entropy: float = 0.65,
    top_k: int = 5,
) -> SpeciesResult:
    """Fuse probabilities without letting repeated frames mimic independence."""

    if not evidence:
        raise ValueError("at least one species observation is required")
    if not 0 < minimum_confidence <= 1 or not 0 <= maximum_entropy <= 1 or top_k < 1:
        raise ValueError("invalid species decision thresholds")
    taxa = sorted({taxon for item in evidence for taxon in item.probabilities})
    if len(taxa) < 2:
        raise ValueError("open-set decisions require at least two candidate taxa")

    grouped: dict[tuple[str, Organ], list[SpeciesEvidence]] = {}
    for item in evidence:
        grouped.setdefault((item.view_id, item.organ), []).append(item)
    log_scores = {taxon: 0.0 for taxon in taxa}
    total_weight = 0.0
    for group in grouped.values():
        group_weight = max(item.reliability for item in group)
        total_weight += group_weight
        for taxon in taxa:
            mean_probability = (
                sum(item.probabilities.get(taxon, 0.0) for item in group) / len(group)
            )
            log_scores[taxon] += group_weight * log(max(mean_probability, 1e-9))
    scaled = {taxon: value / max(total_weight, 1e-9) for taxon, value in log_scores.items()}
    peak = max(scaled.values())
    unnormalized = {taxon: exp(value - peak) for taxon, value in scaled.items()}
    normalizer = sum(unnormalized.values())
    probabilities = {taxon: value / normalizer for taxon, value in unnormalized.items()}
    ranked = tuple(sorted(probabilities.items(), key=lambda item: (-item[1], item[0]))[:top_k])
    entropy = -sum(value * log(max(value, 1e-12)) for value in probabilities.values()) / log(
        len(probabilities)
    )
    winner, confidence = ranked[0]
    diagnostics: list[str] = []
    if confidence < minimum_confidence:
        diagnostics.append("top candidate confidence is below the open-set threshold")
    if entropy > maximum_entropy:
        diagnostics.append("candidate distribution is too ambiguous")
    organs = tuple(sorted({item.organ for item in evidence}, key=str))
    if len(organs) < 2:
        diagnostics.append("identification uses only one organ type")
    accepted = winner if not diagnostics else None
    return SpeciesResult(
        ranked,
        accepted,
        confidence,
        entropy,
        len({item.view_id for item in evidence}),
        organs,
        tuple(diagnostics),
    )
