"""Versioned file boundary for multiview species evidence."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from treeweaver.species.fusion import Organ, SpeciesEvidence, fuse_species_evidence


@dataclass(frozen=True, slots=True)
class SpeciesFusionRun:
    output_path: Path
    tree_count: int
    accepted_count: int


def fuse_species_file(input_json: str | Path, output_json: str | Path) -> SpeciesFusionRun:
    source = Path(input_json).resolve()
    payload: dict[str, Any] = json.loads(source.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "species-evidence-1.0":
        raise ValueError("unsupported species-evidence schema")
    results: list[dict[str, object]] = []
    accepted = 0
    seen_tracks: set[int] = set()
    for tree in payload.get("trees", []):
        track_id = int(tree["track_id"])
        if track_id in seen_tracks:
            raise ValueError(f"duplicate species track: {track_id}")
        seen_tracks.add(track_id)
        evidence = tuple(
            SpeciesEvidence(
                view_id=str(item["view_id"]),
                organ=Organ(str(item["organ"])),
                probabilities={
                    str(key): float(value) for key, value in item["probabilities"].items()
                },
                reliability=float(item["reliability"]),
                provider=str(item["provider"]),
            )
            for item in tree.get("evidence", [])
        )
        try:
            result = fuse_species_evidence(evidence)
            result_payload = asdict(result)
            result_payload["track_id"] = track_id
            result_payload["status"] = "accepted" if result.accepted_name else "unknown"
            accepted += int(result.accepted_name is not None)
            results.append(result_payload)
        except ValueError as error:
            results.append({"track_id": track_id, "status": "failed", "reason": str(error)})
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "species-results-1.0",
                "source": str(source),
                "trees": results,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return SpeciesFusionRun(destination, len(results), accepted)
