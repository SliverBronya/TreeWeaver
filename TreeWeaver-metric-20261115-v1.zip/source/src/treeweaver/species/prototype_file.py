"""Immutable file workflow for organ-specific species prototype models."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from treeweaver.species.fusion import Organ
from treeweaver.species.prototype import (
    EmbeddingExample,
    OrganPrototypeModel,
    fit_organ_prototypes,
)


@dataclass(frozen=True, slots=True)
class PrototypeTrainingRun:
    model_directory: Path
    organ_count: int
    taxon_count: int


@dataclass(frozen=True, slots=True)
class PrototypePredictionRun:
    output_path: Path
    tree_count: int
    evidence_count: int


def _load_json(path: str | Path, schema: str) -> tuple[Path, dict[str, Any]]:
    source = Path(path).resolve()
    payload: dict[str, Any] = json.loads(source.read_text(encoding="utf-8"))
    if payload.get("schema_version") != schema:
        raise ValueError(f"unsupported schema; expected {schema}")
    return source, payload


def train_prototype_models(
    examples_json: str | Path,
    output_directory: str | Path,
    *,
    temperature: float = 0.08,
    minimum_similarity: float = 0.35,
    minimum_examples_per_taxon: int = 2,
) -> PrototypeTrainingRun:
    source, payload = _load_json(examples_json, "species-embedding-training-1.0")
    encoder = str(payload.get("encoder", "")).strip()
    revision = str(payload.get("encoder_revision", "")).strip()
    if not encoder or not revision:
        raise ValueError("embedding training data must pin encoder and encoder_revision")
    examples = tuple(
        EmbeddingExample(
            tree_id=str(item["tree_id"]),
            split=str(item["split"]),
            organ=Organ(str(item["organ"])),
            taxon=str(item["taxon"]),
            embedding=np.asarray(item["embedding"], dtype=np.float64),
            expert_verified=bool(item["expert_verified"]),
        )
        for item in payload.get("examples", [])
    )
    if not examples:
        raise ValueError("embedding training file contains no examples")
    organs = tuple(sorted({example.organ for example in examples}, key=str))
    models = tuple(
        fit_organ_prototypes(
            examples,
            organ,
            temperature=temperature,
            minimum_similarity=minimum_similarity,
            minimum_examples_per_taxon=minimum_examples_per_taxon,
        )
        for organ in organs
    )
    dimensions = {model.centroids.shape[1] for model in models}
    if len(dimensions) != 1:
        raise ValueError("all organ models must share one encoder dimension")

    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    arrays: dict[str, Any] = {
        f"centroids_{model.organ.value}": model.centroids for model in models
    }
    np.savez_compressed(output / "centroids.npz", **arrays)
    manifest = {
        "schema_version": "species-prototype-model-1.0",
        "training_source": str(source),
        "encoder": encoder,
        "encoder_revision": revision,
        "embedding_dimension": dimensions.pop(),
        "models": [
            {
                "organ": model.organ.value,
                "taxa": list(model.taxa),
                "centroids_key": f"centroids_{model.organ.value}",
                "temperature": model.temperature,
                "minimum_similarity": model.minimum_similarity,
            }
            for model in models
        ],
    }
    (output / "model.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return PrototypeTrainingRun(output, len(models), len({item.taxon for item in examples}))


def load_prototype_models(
    model_directory: str | Path,
) -> tuple[dict[Organ, OrganPrototypeModel], dict[str, Any]]:
    root = Path(model_directory).resolve()
    _, manifest = _load_json(root / "model.json", "species-prototype-model-1.0")
    models: dict[Organ, OrganPrototypeModel] = {}
    with np.load(root / "centroids.npz", allow_pickle=False) as arrays:
        for item in manifest.get("models", []):
            organ = Organ(str(item["organ"]))
            centroids = np.asarray(arrays[str(item["centroids_key"])], dtype=np.float64)
            model = OrganPrototypeModel(
                organ=organ,
                taxa=tuple(str(taxon) for taxon in item["taxa"]),
                centroids=centroids,
                temperature=float(item["temperature"]),
                minimum_similarity=float(item["minimum_similarity"]),
            )
            if len(model.taxa) != len(model.centroids):
                raise ValueError(f"taxa and centroids disagree for organ {organ.value}")
            models[organ] = model
    if not models:
        raise ValueError("prototype model contains no organs")
    return models, manifest


def predict_prototype_file(
    model_directory: str | Path,
    embeddings_json: str | Path,
    output_json: str | Path,
) -> PrototypePredictionRun:
    models, manifest = load_prototype_models(model_directory)
    source, payload = _load_json(embeddings_json, "species-embedding-prediction-1.0")
    if payload.get("encoder") != manifest["encoder"]:
        raise ValueError("prediction encoder does not match the prototype model")
    if payload.get("encoder_revision") != manifest["encoder_revision"]:
        raise ValueError("prediction encoder revision does not match the prototype model")
    grouped: dict[int, list[dict[str, object]]] = {}
    count = 0
    for item in payload.get("observations", []):
        organ = Organ(str(item["organ"]))
        model = models.get(organ)
        if model is None:
            continue
        prediction = model.predict(np.asarray(item["embedding"], dtype=np.float64))
        grouped.setdefault(int(item["track_id"]), []).append(
            {
                "view_id": str(item["view_id"]),
                "organ": organ.value,
                "probabilities": prediction.probabilities,
                "reliability": float(item["reliability"]),
                "provider": (
                    f"prototype:{manifest['encoder']}@{manifest['encoder_revision']}"
                ),
                "maximum_similarity": prediction.maximum_similarity,
                "open_set_candidate": prediction.accepted_taxon,
            }
        )
        count += 1
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "species-evidence-1.0",
                "embedding_source": str(source),
                "prototype_model": str(Path(model_directory).resolve()),
                "trees": [
                    {"track_id": track_id, "evidence": evidence}
                    for track_id, evidence in sorted(grouped.items())
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return PrototypePredictionRun(destination, len(grouped), count)
