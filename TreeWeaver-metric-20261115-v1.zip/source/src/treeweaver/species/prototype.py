"""Few-shot organ-specific species prototypes over foundation-model embeddings."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.species.fusion import Organ

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class EmbeddingExample:
    tree_id: str
    split: str
    organ: Organ
    taxon: str
    embedding: FloatArray
    expert_verified: bool

    def __post_init__(self) -> None:
        if not self.tree_id or not self.split or not self.taxon:
            raise ValueError("embedding example identity cannot be empty")
        if (
            self.embedding.ndim != 1
            or len(self.embedding) < 2
            or not np.isfinite(self.embedding).all()
        ):
            raise ValueError("species embedding must be a finite vector")


@dataclass(frozen=True, slots=True)
class PrototypePrediction:
    probabilities: dict[str, float]
    accepted_taxon: str | None
    maximum_similarity: float


@dataclass(frozen=True, slots=True)
class OrganPrototypeModel:
    organ: Organ
    taxa: tuple[str, ...]
    centroids: FloatArray
    temperature: float
    minimum_similarity: float

    def predict(self, embedding: npt.ArrayLike) -> PrototypePrediction:
        vector = np.asarray(embedding, dtype=np.float64)
        if vector.shape != (self.centroids.shape[1],):
            raise ValueError("species embedding dimension does not match the model")
        norm = float(np.linalg.norm(vector))
        if norm <= 0:
            raise ValueError("species embedding cannot be zero")
        normalized = vector / norm
        similarities = self.centroids @ normalized
        logits = similarities / self.temperature
        logits -= np.max(logits)
        values = np.exp(logits)
        values /= np.sum(values)
        probabilities = {
            taxon: float(value) for taxon, value in zip(self.taxa, values, strict=True)
        }
        index = int(np.argmax(similarities))
        similarity = float(similarities[index])
        accepted = self.taxa[index] if similarity >= self.minimum_similarity else None
        return PrototypePrediction(probabilities, accepted, similarity)


def fit_organ_prototypes(
    examples: tuple[EmbeddingExample, ...],
    organ: Organ,
    *,
    temperature: float = 0.08,
    minimum_similarity: float = 0.35,
    minimum_examples_per_taxon: int = 2,
) -> OrganPrototypeModel:
    """Fit centroids from expert-verified training trees only."""

    if temperature <= 0 or not -1 <= minimum_similarity <= 1:
        raise ValueError("prototype temperature or similarity threshold is invalid")
    selected = [item for item in examples if item.organ is organ]
    if not selected:
        raise ValueError(f"no examples for organ {organ.value}")
    if any(item.split != "train" for item in selected):
        raise ValueError("only the training split can fit species prototypes")
    if any(not item.expert_verified for item in selected):
        raise ValueError("species prototypes require expert-verified labels")
    dimensions = {item.embedding.shape for item in selected}
    if len(dimensions) != 1:
        raise ValueError("species embeddings must share one dimension")
    grouped: dict[str, list[FloatArray]] = {}
    tree_ids: dict[str, set[str]] = {}
    for item in selected:
        grouped.setdefault(item.taxon, []).append(item.embedding)
        tree_ids.setdefault(item.taxon, set()).add(item.tree_id)
    insufficient = [
        taxon for taxon, trees in tree_ids.items() if len(trees) < minimum_examples_per_taxon
    ]
    if insufficient:
        raise ValueError("too few independent trees for taxa: " + ", ".join(sorted(insufficient)))
    taxa = tuple(sorted(grouped))
    centroids = []
    for taxon in taxa:
        vectors = np.stack(grouped[taxon]).astype(np.float64)
        vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
        centroid = np.mean(vectors, axis=0)
        centroid /= np.linalg.norm(centroid)
        centroids.append(centroid)
    return OrganPrototypeModel(
        organ,
        taxa,
        np.stack(centroids),
        temperature,
        minimum_similarity,
    )
