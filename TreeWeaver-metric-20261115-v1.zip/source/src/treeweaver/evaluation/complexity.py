"""Frozen complex-scene labels used for stratified evaluation."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class SceneChallenge(StrEnum):
    STEM_OCCLUSION = "stem_occlusion"
    CROWN_OVERLAP = "crown_overlap"
    TOUCHING_STEMS = "touching_stems"
    UNDERSTORY_CLUTTER = "understory_clutter"
    FORKED_OR_MULTI_STEM = "forked_or_multi_stem"
    BUTTRESS_OR_IRREGULAR_DBH = "buttress_or_irregular_dbh"
    LEANING_STEM = "leaning_stem"
    TRUNCATED_ROOT_OR_APEX = "truncated_root_or_apex"
    WIND_MOTION = "wind_motion"
    HARSH_LIGHTING = "harsh_lighting"
    DEPTH_OR_RECONSTRUCTION_HOLES = "depth_or_reconstruction_holes"


@dataclass(frozen=True, slots=True)
class ComplexityAnnotation:
    """Human-auditable severities: 0 absent, 1 mild, 2 moderate, 3 severe."""

    severities: dict[SceneChallenge, int]

    def __post_init__(self) -> None:
        if any(challenge not in SceneChallenge for challenge in self.severities):
            raise ValueError("unknown scene challenge")
        if any(value not in {0, 1, 2, 3} for value in self.severities.values()):
            raise ValueError("challenge severity must be an integer from 0 to 3")

    @property
    def maximum_severity(self) -> int:
        return max(self.severities.values(), default=0)

    @property
    def active_challenge_count(self) -> int:
        return sum(value > 0 for value in self.severities.values())

    @property
    def score(self) -> float:
        """A transparent 0--1 summary; per-condition results remain mandatory."""

        if not self.severities:
            return 0.0
        severity = sum(self.severities.values()) / (3 * len(SceneChallenge))
        interaction = max(0, self.active_challenge_count - 1) / (len(SceneChallenge) - 1)
        return min(1.0, 0.8 * severity + 0.2 * interaction)

    @property
    def stratum(self) -> str:
        if self.maximum_severity == 0:
            return "clear"
        if self.maximum_severity == 1 and self.active_challenge_count <= 2:
            return "mild"
        if self.maximum_severity <= 2 and self.active_challenge_count <= 4:
            return "moderate"
        return "severe"

    @property
    def active(self) -> tuple[SceneChallenge, ...]:
        return tuple(
            sorted(
                (item for item, severity in self.severities.items() if severity > 0),
                key=str,
            )
        )
