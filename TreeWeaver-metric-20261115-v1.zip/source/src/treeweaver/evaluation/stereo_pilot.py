"""Auditable assisted-stereo DBH pilot for calibrated public datasets.

This is deliberately an assisted baseline: the caller supplies a trunk seed and
the image row corresponding to breast height.  It validates metric stereo and
evaluation plumbing without claiming that trunk selection or breast-height
localisation is solved.
"""

from __future__ import annotations

import csv
import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class StereoDbhEstimate:
    dbh_cm: float
    standard_deviation_cm: float
    valid_rows: int
    attempted_rows: int
    median_disparity_px: float
    baseline_mm: float


@dataclass(frozen=True, slots=True)
class MaskedStereoDbhEstimate:
    dbh_cm: float
    standard_deviation_cm: float
    breast_height_row: int
    trunk_width_px: int
    breast_height_depth_m: float
    baseline_mm: float
    valid_disparity_ratio: float


def estimate_dbh_from_disparity(
    disparity: Any,
    *,
    baseline_mm: float,
    seed_x: int,
    breast_height_row: int,
    row_half_window: int = 20,
    seed_half_window: int = 20,
    threshold_ratio: float = 0.94,
) -> StereoDbhEstimate:
    """Estimate silhouette diameter around an explicitly supplied DBH location."""

    import numpy as np

    cv2: Any = __import__("cv2")

    if baseline_mm <= 0:
        raise ValueError("stereo baseline must be positive")
    if not 0 < threshold_ratio < 1:
        raise ValueError("threshold ratio must be in (0, 1)")
    height, width = disparity.shape
    if not 0 <= seed_x < width or not 0 <= breast_height_row < height:
        raise ValueError("assisted seed lies outside the disparity image")
    seed = disparity[
        max(0, breast_height_row - 3 * row_half_window) : min(
            height, breast_height_row + 3 * row_half_window + 1
        ),
        max(0, seed_x - seed_half_window) : min(width, seed_x + seed_half_window + 1),
    ]
    valid_seed = seed[seed > 1]
    if valid_seed.size == 0:
        raise ValueError("no valid stereo disparity around the assisted trunk seed")
    median_disparity = float(np.median(valid_seed))
    mask = np.uint8(disparity > threshold_ratio * median_disparity)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((1, 9), np.uint8))

    diameters_cm: list[float] = []
    y0 = max(0, breast_height_row - row_half_window)
    y1 = min(height, breast_height_row + row_half_window + 1)
    for row in range(y0, y1):
        xs = np.flatnonzero(mask[row])
        runs = np.split(xs, np.where(np.diff(xs) > 1)[0] + 1) if xs.size else []
        candidates = [
            run for run in runs if len(run) > 15 and int(run[0]) <= seed_x <= int(run[-1])
        ]
        if not candidates:
            continue
        trunk_run = max(candidates, key=len)
        raw_disparity = disparity[row, trunk_run]
        valid_disparity = raw_disparity[raw_disparity > 1]
        if valid_disparity.size < len(trunk_run) // 2:
            continue
        row_disparity = float(np.median(valid_disparity))
        diameter_mm = baseline_mm * len(trunk_run) / row_disparity
        diameters_cm.append(diameter_mm / 10.0)

    attempted = y1 - y0
    minimum_valid_rows = max(5, int(0.8 * attempted + 0.999))
    if len(diameters_cm) < minimum_valid_rows:
        raise ValueError("insufficient valid stereo rows at the assisted breast-height location")
    values = np.asarray(diameters_cm, dtype=float)
    estimate = float(np.median(values))
    mad = float(np.median(np.abs(values - estimate)))
    robust_sd = max(0.1, 1.4826 * mad)
    return StereoDbhEstimate(
        dbh_cm=estimate,
        standard_deviation_cm=robust_sd,
        valid_rows=len(diameters_cm),
        attempted_rows=attempted,
        median_disparity_px=median_disparity,
        baseline_mm=baseline_mm,
    )


def run_assisted_stereo_dbh(
    left_image: str | Path,
    right_image: str | Path,
    calibration_yml: str | Path,
    output_json: str | Path,
    *,
    truth_cm: float,
    tree_id: str,
    seed_x: int,
    breast_height_row: int,
) -> StereoDbhEstimate:
    """Rectify a real stereo pair, measure DBH, and emit benchmark predictions."""

    import numpy as np

    cv2: Any = __import__("cv2")

    left_path = Path(left_image).resolve()
    right_path = Path(right_image).resolve()
    calibration_path = Path(calibration_yml).resolve()
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    left = cv2.imread(str(left_path))
    right = cv2.imread(str(right_path))
    if left is None or right is None:
        raise ValueError("stereo images could not be decoded")
    if left.shape != right.shape:
        raise ValueError("left and right stereo images must have the same dimensions")

    storage = cv2.FileStorage(str(calibration_path), cv2.FILE_STORAGE_READ)
    if not storage.isOpened():
        raise ValueError(f"could not read OpenCV calibration: {calibration_path}")
    keys = ("K1", "D1", "K2", "D2", "R1", "R2", "P1", "P2")
    matrices = {key: storage.getNode(key).mat() for key in keys}
    storage.release()
    if any(value is None for value in matrices.values()):
        raise ValueError("calibration is missing a required stereo matrix")

    size = (left.shape[1], left.shape[0])
    left_maps = cv2.initUndistortRectifyMap(
        matrices["K1"], matrices["D1"], matrices["R1"], matrices["P1"], size, cv2.CV_32FC1
    )
    right_maps = cv2.initUndistortRectifyMap(
        matrices["K2"], matrices["D2"], matrices["R2"], matrices["P2"], size, cv2.CV_32FC1
    )
    rectified_left = cv2.remap(left, *left_maps, cv2.INTER_LINEAR)
    rectified_right = cv2.remap(right, *right_maps, cv2.INTER_LINEAR)
    matcher = cv2.StereoSGBM_create(
        minDisparity=0,
        numDisparities=128,
        blockSize=7,
        P1=8 * 3 * 7**2,
        P2=32 * 3 * 7**2,
        disp12MaxDiff=1,
        uniquenessRatio=8,
        speckleWindowSize=100,
        speckleRange=2,
        preFilterCap=31,
        mode=cv2.STEREO_SGBM_MODE_SGBM_3WAY,
    )
    disparity = matcher.compute(
        cv2.cvtColor(rectified_left, cv2.COLOR_BGR2GRAY),
        cv2.cvtColor(rectified_right, cv2.COLOR_BGR2GRAY),
    ).astype(np.float32) / 16.0
    projection = matrices["P2"]
    baseline_mm = float(np.linalg.norm(projection[:, 3]) / projection[0, 0])
    estimate = estimate_dbh_from_disparity(
        disparity,
        baseline_mm=baseline_mm,
        seed_x=seed_x,
        breast_height_row=breast_height_row,
    )

    absolute_error = abs(estimate.dbh_cm - truth_cm)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "method": "assisted-calibrated-stereo-sgbm-1.0",
                "limitations": [
                    "tree centre is supplied by a human",
                    "breast-height image row is supplied by a human",
                    "single stereo pair; not the full smartphone-video pipeline",
                ],
                "inputs": {
                    "left_image": str(left_path),
                    "right_image": str(right_path),
                    "calibration": str(calibration_path),
                    "seed_x": seed_x,
                    "breast_height_row": breast_height_row,
                },
                "stereo_diagnostics": {
                    "baseline_mm": estimate.baseline_mm,
                    "median_disparity_px": estimate.median_disparity_px,
                    "valid_rows": estimate.valid_rows,
                    "attempted_rows": estimate.attempted_rows,
                },
                "predictions": [
                    {
                        "tree_id": tree_id,
                        "session_id": left_path.stem,
                        "split": "pilot",
                        "parameter": "dbh_cm",
                        "truth": truth_cm,
                        "estimate": estimate.dbh_cm,
                        "standard_deviation": estimate.standard_deviation_cm,
                        "confidence": estimate.valid_rows / estimate.attempted_rows,
                        "absolute_error": absolute_error,
                        "relative_error_percent": absolute_error / truth_cm * 100.0,
                        "strata": {"automation": "assisted", "sensor": "calibrated-stereo"},
                    }
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return estimate


def estimate_masked_dbh(
    disparity: Any,
    rectified_mask: Any,
    *,
    focal_length_px: float,
    baseline_mm: float,
    cx: float,
    cy: float,
    diagonal_fov_deg: float = 55.0,
) -> MaskedStereoDbhEstimate:
    """Reproduce the published mask/base/BH stereo geometry without truth tuning."""

    import numpy as np

    mask = rectified_mask > 0
    valid = mask & (disparity > 1)
    rows, columns = np.nonzero(valid)
    if rows.size < 100:
        raise ValueError("segmented trunk has insufficient valid disparity")
    base_row = int(rows.max())
    base_band = valid[max(0, base_row - 49) : base_row + 1]
    band_rows, band_columns = np.nonzero(base_band)
    if band_rows.size == 0:
        raise ValueError("trunk base has no valid disparity")
    absolute_band_rows = band_rows + max(0, base_row - 49)
    base_disparities = disparity[absolute_band_rows, band_columns]
    base_disparity = float(np.median(base_disparities))
    base_column = float(np.median(columns[rows >= max(0, base_row - 10)]))

    baseline_m = baseline_mm / 1000.0
    base_depth_m = baseline_m * focal_length_px / base_disparity
    base_x_m = baseline_m * (base_column - cx) / base_disparity
    base_y_m = baseline_m * (base_row - cy) / base_disparity
    ground_distance_m = float(
        np.linalg.norm(np.array([base_x_m, base_y_m, base_depth_m], dtype=float))
    )
    phi = float(np.arctan2(base_y_m, base_depth_m))
    beta = np.pi / 2.0 - phi
    height_distance_m = float(
        np.sqrt(1.3**2 + ground_distance_m**2 - 2.6 * ground_distance_m * np.cos(beta))
    )
    sine = float(1.3 * np.sin(beta) / height_distance_m)
    theta = float(np.arcsin(np.clip(sine, -1.0, 1.0)))
    height, width = disparity.shape
    diagonal_fov = np.deg2rad(diagonal_fov_deg)
    diagonal_pixels = float(np.hypot(height, width))
    vertical_fov = 2.0 * np.arctan(height * np.tan(diagonal_fov / 2.0) / diagonal_pixels)
    breast_height_offset_px = (height / np.tan(vertical_fov / 2.0)) * np.tan(theta / 2.0)
    breast_height_row = base_row - int(breast_height_offset_px)
    if not 0 <= breast_height_row < height:
        raise ValueError("estimated breast-height row lies outside the image")

    widths: list[int] = []
    for row in range(max(0, breast_height_row - 2), min(height, breast_height_row + 3)):
        xs = np.flatnonzero(mask[row])
        if xs.size:
            widths.append(int(xs.max() - xs.min()))
    if not widths:
        raise ValueError("segmentation mask does not intersect the estimated breast height")
    trunk_width_px = int(np.median(np.asarray(widths)))
    bh_band = valid[
        max(0, breast_height_row - 5) : min(height, breast_height_row + 6)
    ]
    bh_rows, bh_columns = np.nonzero(bh_band)
    if bh_rows.size == 0:
        raise ValueError("breast-height band has no valid disparity")
    absolute_bh_rows = bh_rows + max(0, breast_height_row - 5)
    bh_disparity = float(np.median(disparity[absolute_bh_rows, bh_columns]))
    breast_height_depth_m = baseline_m * focal_length_px / bh_disparity
    visible_diameter_m = baseline_m * trunk_width_px / bh_disparity
    left_x = float(np.flatnonzero(mask[breast_height_row]).min())
    tangent_x_m = baseline_m * (left_x - cx) / bh_disparity
    tangent_y_m = baseline_m * (breast_height_row - cy) / bh_disparity
    tangent_distance_m = float(
        np.linalg.norm(
            np.array([tangent_x_m, tangent_y_m, breast_height_depth_m], dtype=float)
        )
    )
    correction_denominator = np.sqrt(
        max(1e-12, tangent_distance_m**2 - (visible_diameter_m / 2.0) ** 2)
    )
    dbh_m = visible_diameter_m * tangent_distance_m / correction_denominator
    row_diameters_cm: list[float] = []
    for row in range(max(0, breast_height_row - 5), min(height, breast_height_row + 6)):
        xs = np.flatnonzero(mask[row])
        row_disparities = disparity[row, xs] if xs.size else np.asarray([])
        row_disparities = row_disparities[row_disparities > 1]
        if xs.size and row_disparities.size >= 5:
            row_width = int(xs.max() - xs.min())
            row_disparity = float(np.median(row_disparities))
            row_diameters_cm.append(baseline_m * row_width / row_disparity * 100.0)
    if len(row_diameters_cm) < 3:
        raise ValueError("too few breast-height rows for uncertainty estimation")
    row_values = np.asarray(row_diameters_cm, dtype=float)
    row_median = float(np.median(row_values))
    row_mad = float(np.median(np.abs(row_values - row_median)))
    return MaskedStereoDbhEstimate(
        dbh_cm=float(dbh_m * 100.0),
        standard_deviation_cm=max(0.3, 1.4826 * row_mad),
        breast_height_row=breast_height_row,
        trunk_width_px=trunk_width_px,
        breast_height_depth_m=float(breast_height_depth_m),
        baseline_mm=baseline_mm,
        valid_disparity_ratio=float(valid.sum() / max(1, mask.sum())),
    )


def run_masked_stereo_dbh(
    left_image: str | Path,
    right_image: str | Path,
    mask_image: str | Path,
    calibration_yml: str | Path,
    output_json: str | Path,
    *,
    truth_cm: float,
    tree_id: str,
    diagonal_fov_deg: float = 55.0,
    segmentation_label: str = "ground-truth-mask",
) -> MaskedStereoDbhEstimate:
    """Run the published-style masked-stereo DBH baseline on one pair."""

    import numpy as np

    cv2: Any = __import__("cv2")
    paths = [Path(item).resolve() for item in (left_image, right_image, mask_image)]
    calibration_path = Path(calibration_yml).resolve()
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    left = cv2.imread(str(paths[0]), cv2.IMREAD_GRAYSCALE)
    right = cv2.imread(str(paths[1]), cv2.IMREAD_GRAYSCALE)
    mask = cv2.imread(str(paths[2]), cv2.IMREAD_GRAYSCALE)
    if left is None or right is None or mask is None:
        raise ValueError("stereo image or mask could not be decoded")
    if left.shape != right.shape or left.shape != mask.shape:
        raise ValueError("left, right, and mask dimensions must match")
    storage = cv2.FileStorage(str(calibration_path), cv2.FILE_STORAGE_READ)
    keys = ("K1", "D1", "K2", "D2", "R1", "R2", "T")
    matrices = {key: storage.getNode(key).mat() for key in keys}
    storage.release()
    if any(value is None for value in matrices.values()):
        raise ValueError("calibration is missing a required stereo matrix")

    height, width = left.shape
    size = (width, height)
    focal_length = float(matrices["K1"][0, 0])
    tx_mm = float(matrices["T"][0, 0])
    left_projection = np.hstack((matrices["K1"], np.zeros((3, 1))))
    right_projection = np.hstack(
        (matrices["K2"], np.array([[tx_mm * focal_length], [0.0], [0.0]]))
    )
    left_maps = cv2.initUndistortRectifyMap(
        matrices["K1"], matrices["D1"], matrices["R1"], left_projection, size, cv2.CV_32FC1
    )
    right_maps = cv2.initUndistortRectifyMap(
        matrices["K2"],
        matrices["D2"],
        matrices["R2"],
        right_projection,
        size,
        cv2.CV_32FC1,
    )
    rectified_left = cv2.remap(left, *left_maps, cv2.INTER_LINEAR)
    rectified_right = cv2.remap(right, *right_maps, cv2.INTER_LINEAR)
    rectified_mask = cv2.remap(mask, *left_maps, cv2.INTER_NEAREST)
    rectified_mask = np.uint8(rectified_mask > 10) * 255
    kernel = np.ones((3, 3), np.uint8)
    rectified_mask = cv2.morphologyEx(rectified_mask, cv2.MORPH_CLOSE, kernel)
    rectified_mask = cv2.morphologyEx(rectified_mask, cv2.MORPH_OPEN, kernel)
    rectified_left = cv2.GaussianBlur(rectified_left, (5, 5), 0)
    rectified_right = cv2.GaussianBlur(rectified_right, (5, 5), 0)
    matcher = cv2.StereoSGBM_create(
        minDisparity=0,
        numDisparities=128,
        blockSize=11,
        P1=8 * 3 * 11**2,
        P2=32 * 3 * 11**2,
        disp12MaxDiff=5,
        uniquenessRatio=10,
        speckleWindowSize=100,
        speckleRange=2,
    )
    disparity = matcher.compute(rectified_left, rectified_right).astype(np.float32) / 16.0
    histogram_values = disparity[(rectified_mask > 0) & (disparity > 10)]
    if histogram_values.size == 0:
        raise ValueError("segmented trunk has no disparity values above the noise floor")
    histogram_bins = np.clip(histogram_values.astype(np.int32), 0, 255)
    disparity_peak = int(np.bincount(histogram_bins, minlength=256).argmax())
    in_peak = (
        (rectified_mask > 0)
        & (disparity >= disparity_peak - 10)
        & (disparity <= disparity_peak + 10)
    )
    disparity = np.where(in_peak, disparity, -1.0)
    baseline_mm = float(np.linalg.norm(matrices["T"]))
    estimate = estimate_masked_dbh(
        disparity,
        rectified_mask,
        focal_length_px=focal_length,
        baseline_mm=baseline_mm,
        cx=float(matrices["K1"][0, 2]),
        cy=float(matrices["K1"][1, 2]),
        diagonal_fov_deg=diagonal_fov_deg,
    )
    error = abs(estimate.dbh_cm - truth_cm)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "method": "published-style-masked-stereo-1.0",
                "inputs": {
                    "left_image": str(paths[0]),
                    "right_image": str(paths[1]),
                    "mask_image": str(paths[2]),
                    "calibration": str(calibration_path),
                    "diagonal_fov_deg": diagonal_fov_deg,
                },
                "stereo_diagnostics": {
                    "baseline_mm": estimate.baseline_mm,
                    "breast_height_row": estimate.breast_height_row,
                    "trunk_width_px": estimate.trunk_width_px,
                    "breast_height_depth_m": estimate.breast_height_depth_m,
                    "valid_disparity_ratio": estimate.valid_disparity_ratio,
                },
                "predictions": [
                    {
                        "tree_id": tree_id,
                        "session_id": paths[0].stem,
                        "split": "pilot-v4",
                        "parameter": "dbh_cm",
                        "truth": truth_cm,
                        "estimate": estimate.dbh_cm,
                        "standard_deviation": estimate.standard_deviation_cm,
                        "confidence": estimate.valid_disparity_ratio,
                        "absolute_error": error,
                        "relative_error_percent": error / truth_cm * 100.0,
                        "strata": {"segmentation": segmentation_label, "sensor": "stereo"},
                    }
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return estimate


def run_masked_stereo_dataset(
    dataset_root: str | Path,
    calibration_yml: str | Path,
    output_json: str | Path,
    *,
    diagonal_fov_deg: float = 55.0,
    mask_directory: str | Path | None = None,
    segmentation_label: str = "ground-truth-mask",
) -> tuple[int, int]:
    """Run the masked-stereo baseline over every DBH attempt in a v4 release."""

    root = Path(dataset_root).resolve()
    truth_path = root / "trunks.csv"
    image_directory = root / "trunks"
    resolved_mask_directory = (
        Path(mask_directory).resolve() if mask_directory is not None else image_directory
    )
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    predictions: list[dict[str, object]] = []
    failures: list[dict[str, str]] = []
    with truth_path.open("r", encoding="utf-8-sig", newline="") as handle:
        truth_rows = list(csv.DictReader(handle))
    with tempfile.TemporaryDirectory(prefix="treeweaver-stereo-") as temporary:
        temporary_root = Path(temporary)
        for index, row in enumerate(truth_rows, start=1):
            source_name = str(row["Image Filename"])
            matches = tuple(image_directory.glob(f"*_{source_name}"))
            tree_id = f"T{index:02d}"
            if len(matches) != 1:
                failures.append({"tree_id": tree_id, "reason": "left image match is not unique"})
                predictions.append(
                    {
                        "tree_id": tree_id,
                        "session_id": source_name,
                        "split": "v4-all",
                        "parameter": "dbh_cm",
                        "truth": float(row["DBH (cm)"]),
                        "estimate": None,
                        "standard_deviation": None,
                        "confidence": 0.0,
                        "strata": {"segmentation": segmentation_label, "sensor": "stereo"},
                    }
                )
                continue
            left_path = matches[0]
            right_path = left_path.with_name(left_path.name.replace("_LEFT.jpg", "_RIGHT.jpg"))
            mask_name = left_path.name.replace("_LEFT.jpg", "_LEFT_mask.jpg")
            mask_path = resolved_mask_directory / mask_name
            attempt_path = temporary_root / f"{tree_id}.json"
            truth_cm = float(row["DBH (cm)"])
            try:
                run_masked_stereo_dbh(
                    left_path,
                    right_path,
                    mask_path,
                    calibration_yml,
                    attempt_path,
                    truth_cm=truth_cm,
                    tree_id=tree_id,
                    diagonal_fov_deg=diagonal_fov_deg,
                    segmentation_label=segmentation_label,
                )
                attempt = json.loads(attempt_path.read_text(encoding="utf-8"))
                prediction = dict(attempt["predictions"][0])
                prediction["split"] = "v4-all"
                predictions.append(prediction)
            except (ValueError, OSError) as exc:
                failures.append({"tree_id": tree_id, "reason": str(exc)})
                predictions.append(
                    {
                        "tree_id": tree_id,
                        "session_id": left_path.stem,
                        "split": "v4-all",
                        "parameter": "dbh_cm",
                        "truth": truth_cm,
                        "estimate": None,
                        "standard_deviation": None,
                        "confidence": 0.0,
                        "strata": {"segmentation": segmentation_label, "sensor": "stereo"},
                    }
                )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "method": "published-style-masked-stereo-1.0",
                "dataset_root": str(root),
                "calibration": str(Path(calibration_yml).resolve()),
                "mask_directory": str(resolved_mask_directory),
                "segmentation_label": segmentation_label,
                "failures": failures,
                "predictions": predictions,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return len(predictions), len(failures)
