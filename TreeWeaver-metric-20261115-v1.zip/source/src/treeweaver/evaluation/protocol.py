"""Frozen, tree-disjoint split manifests for reproducible papers."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class SampleIdentity:
    sample_id: str
    tree_id: str
    session_id: str
    site_id: str
    device_id: str
    operator_id: str

    def __post_init__(self) -> None:
        if not all(asdict(self).values()):
            raise ValueError("sample identity fields cannot be empty")


@dataclass(frozen=True, slots=True)
class SplitAssignment:
    sample_id: str
    tree_id: str
    split: str


def _bucket(tree_id: str, seed: str) -> float:
    digest = hashlib.sha256(f"{seed}\0{tree_id}".encode()).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


def build_frozen_splits(
    samples: tuple[SampleIdentity, ...],
    *,
    external_test_sites: frozenset[str],
    seed: str,
    validation_fraction: float = 0.15,
    internal_test_fraction: float = 0.15,
) -> tuple[SplitAssignment, ...]:
    """Assign whole trees, forcing designated external sites into external test."""

    if not samples or not seed:
        raise ValueError("samples and a non-empty split seed are required")
    if validation_fraction < 0 or internal_test_fraction < 0:
        raise ValueError("split fractions cannot be negative")
    if validation_fraction + internal_test_fraction >= 1:
        raise ValueError("training fraction must remain positive")
    if len({sample.sample_id for sample in samples}) != len(samples):
        raise ValueError("sample ids must be unique")
    sites_by_tree: dict[str, set[str]] = {}
    for sample in samples:
        sites_by_tree.setdefault(sample.tree_id, set()).add(sample.site_id)

    split_by_tree: dict[str, str] = {}
    for tree_id, sites in sites_by_tree.items():
        if sites & external_test_sites:
            split_by_tree[tree_id] = "external_test"
            continue
        value = _bucket(tree_id, seed)
        if value < internal_test_fraction:
            split_by_tree[tree_id] = "internal_test"
        elif value < internal_test_fraction + validation_fraction:
            split_by_tree[tree_id] = "validation"
        else:
            split_by_tree[tree_id] = "train"
    return tuple(
        SplitAssignment(sample.sample_id, sample.tree_id, split_by_tree[sample.tree_id])
        for sample in sorted(samples, key=lambda item: item.sample_id)
    )


def write_frozen_protocol(
    path: str | Path,
    samples: tuple[SampleIdentity, ...],
    assignments: tuple[SplitAssignment, ...],
    *,
    seed: str,
    external_test_sites: frozenset[str],
) -> Path:
    destination = Path(path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    sample_ids = {sample.sample_id for sample in samples}
    if {item.sample_id for item in assignments} != sample_ids:
        raise ValueError("split assignments must cover every sample exactly once")
    payload: dict[str, object] = {
        "schema_version": "treeweaver-protocol-1.0",
        "seed": seed,
        "external_test_sites": sorted(external_test_sites),
        "samples": [asdict(item) for item in sorted(samples, key=lambda item: item.sample_id)],
        "assignments": [asdict(item) for item in assignments],
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    payload["sha256"] = hashlib.sha256(canonical.encode()).hexdigest()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return destination


def verify_frozen_protocol(path: str | Path) -> str:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    expected = str(payload.pop("sha256"))
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    actual = hashlib.sha256(canonical.encode()).hexdigest()
    if actual != expected:
        raise ValueError("frozen protocol checksum mismatch")
    return actual
