"""Dependency-free metrics for accuracy, uncertainty and selective prediction."""

from __future__ import annotations

from dataclasses import dataclass
from math import log, pi, sqrt
from typing import cast


@dataclass(frozen=True, slots=True)
class Prediction:
    tree_id: str
    session_id: str
    split: str
    truth: float
    estimate: float | None
    standard_deviation: float | None
    confidence: float

    def __post_init__(self) -> None:
        if not self.tree_id or not self.session_id or not self.split:
            raise ValueError("prediction identity and split cannot be empty")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be in [0, 1]")
        if self.estimate is None and self.standard_deviation is not None:
            raise ValueError("failed predictions cannot carry uncertainty")
        if self.estimate is not None and (
            self.standard_deviation is not None and self.standard_deviation <= 0
        ):
            raise ValueError("reported prediction uncertainty must be positive")


@dataclass(frozen=True, slots=True)
class RegressionMetrics:
    count: int
    mae: float
    rmse: float
    bias: float
    percentage_count: int
    mean_absolute_percentage_error: float | None
    uncertainty_count: int
    gaussian_nll: float | None
    interval_95_coverage: float | None


@dataclass(frozen=True, slots=True)
class RiskCoveragePoint:
    coverage: float
    mae: float
    accepted_count: int


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    attempted_count: int
    failure_rate: float
    metrics: RegressionMetrics
    risk_coverage: tuple[RiskCoveragePoint, ...]


def assert_tree_disjoint_splits(predictions: tuple[Prediction, ...]) -> None:
    """Reject frame/session leakage of one biological tree across splits."""

    split_by_tree: dict[str, str] = {}
    for item in predictions:
        previous = split_by_tree.setdefault(item.tree_id, item.split)
        if previous != item.split:
            raise ValueError(
                f"tree {item.tree_id!r} occurs in both {previous!r} and {item.split!r}"
            )


def _metrics(successes: list[Prediction]) -> RegressionMetrics:
    if not successes:
        raise ValueError("no successful predictions to evaluate")
    errors = [cast(float, item.estimate) - item.truth for item in successes]
    absolute = [abs(value) for value in errors]
    count = len(successes)
    uncertainty_pairs = [
        (error, item.standard_deviation)
        for error, item in zip(errors, successes, strict=True)
        if item.standard_deviation is not None
    ]
    nll = [
        0.5 * log(2 * pi * deviation**2) + error**2 / (2 * deviation**2)
        for error, deviation in uncertainty_pairs
    ]
    coverage = [abs(error) <= 1.96 * deviation for error, deviation in uncertainty_pairs]
    percentage = [
        abs(error) / abs(item.truth)
        for error, item in zip(errors, successes, strict=True)
        if abs(item.truth) > 1e-12
    ]
    return RegressionMetrics(
        count=count,
        mae=sum(absolute) / count,
        rmse=sqrt(sum(value**2 for value in errors) / count),
        bias=sum(errors) / count,
        percentage_count=len(percentage),
        mean_absolute_percentage_error=(sum(percentage) / len(percentage) if percentage else None),
        uncertainty_count=len(uncertainty_pairs),
        gaussian_nll=(sum(nll) / len(nll) if nll else None),
        interval_95_coverage=(sum(coverage) / len(coverage) if coverage else None),
    )


def evaluate_predictions(predictions: tuple[Prediction, ...]) -> EvaluationResult:
    if not predictions:
        raise ValueError("at least one attempted prediction is required")
    assert_tree_disjoint_splits(predictions)
    successes = [item for item in predictions if item.estimate is not None]
    metrics = _metrics(successes)
    ranked = sorted(successes, key=lambda item: (-item.confidence, item.tree_id, item.session_id))
    checkpoints = sorted(
        {1, len(ranked), *[max(1, round(len(ranked) * q / 10)) for q in range(1, 11)]}
    )
    curve = tuple(
        RiskCoveragePoint(
            accepted / len(predictions),
            sum(abs(cast(float, item.estimate) - item.truth) for item in ranked[:accepted])
            / accepted,
            accepted,
        )
        for accepted in checkpoints
    )
    return EvaluationResult(
        attempted_count=len(predictions),
        failure_rate=1 - len(successes) / len(predictions),
        metrics=metrics,
        risk_coverage=curve,
    )
