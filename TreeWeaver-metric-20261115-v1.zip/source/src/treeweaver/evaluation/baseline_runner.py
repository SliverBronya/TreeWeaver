"""Process-isolated, failure-complete runner for formal paper baselines."""

from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from time import time
from typing import Any

from treeweaver.evaluation.file_evaluation import EvaluationRun, evaluate_prediction_file
from treeweaver.evaluation.protocol import verify_frozen_protocol


@dataclass(frozen=True, slots=True)
class BaselineConfig:
    command: tuple[str, ...]
    baseline_name: str
    baseline_version: str
    parameters: tuple[str, ...]
    timeout_seconds: int = 7200

    def __post_init__(self) -> None:
        if not self.command or not self.baseline_name or not self.baseline_version:
            raise ValueError("baseline command and identity are required")
        if not self.parameters or len(set(self.parameters)) != len(self.parameters):
            raise ValueError("baseline parameters must be non-empty and unique")
        if self.timeout_seconds <= 0:
            raise ValueError("baseline timeout must be positive")


@dataclass(frozen=True, slots=True)
class BaselineRun:
    output_directory: Path
    predictions_path: Path
    evaluation: EvaluationRun
    attempted_count: int
    failure_count: int


def load_baseline_config(path: str | Path) -> BaselineConfig:
    payload: dict[str, Any] = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != "external-baseline-1.0":
        raise ValueError("unsupported external baseline schema")
    return BaselineConfig(
        command=tuple(str(item) for item in payload["command"]),
        baseline_name=str(payload["baseline_name"]),
        baseline_version=str(payload["baseline_version"]),
        parameters=tuple(str(item) for item in payload["parameters"]),
        timeout_seconds=int(payload.get("timeout_seconds", 7200)),
    )


def _validate_complete_predictions(
    predictions_path: Path,
    protocol_path: Path,
    parameters: tuple[str, ...],
) -> tuple[int, int]:
    protocol: dict[str, Any] = json.loads(protocol_path.read_text(encoding="utf-8"))
    assignments = {
        str(item["sample_id"]): (str(item["tree_id"]), str(item["split"]))
        for item in protocol["assignments"]
    }
    predictions: dict[str, Any] = json.loads(predictions_path.read_text(encoding="utf-8"))
    if predictions.get("schema_version") != "benchmark-predictions-1.0":
        raise ValueError("baseline emitted an unsupported prediction schema")
    seen: set[tuple[str, str]] = set()
    failures = 0
    for item in predictions.get("predictions", []):
        sample_id = str(item["sample_id"])
        parameter = str(item["parameter"])
        key = sample_id, parameter
        if key in seen:
            raise ValueError(f"duplicate baseline attempt: {sample_id}/{parameter}")
        seen.add(key)
        if sample_id not in assignments or parameter not in parameters:
            raise ValueError(f"unexpected baseline attempt: {sample_id}/{parameter}")
        tree_id, split = assignments[sample_id]
        if str(item["tree_id"]) != tree_id or str(item["split"]) != split:
            raise ValueError(f"baseline changed frozen identity for sample {sample_id}")
        failures += int(item.get("estimate") is None)
    expected = {(sample_id, parameter) for sample_id in assignments for parameter in parameters}
    missing = expected - seen
    if missing:
        example = sorted(missing)[0]
        raise ValueError(
            f"baseline omitted {len(missing)} attempts; first missing: {example[0]}/{example[1]}"
        )
    return len(seen), failures


def run_external_baseline(
    config: BaselineConfig,
    protocol_json: str | Path,
    output_directory: str | Path,
) -> BaselineRun:
    protocol = Path(protocol_json).resolve()
    protocol_sha256 = verify_frozen_protocol(protocol)
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    predictions = output / "predictions.json"
    command = [
        *config.command,
        "--protocol",
        str(protocol),
        "--output-json",
        str(predictions),
        "--baseline-name",
        config.baseline_name,
        "--baseline-version",
        config.baseline_version,
    ]
    started = time()
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=config.timeout_seconds,
        check=False,
        shell=False,
    )
    duration = time() - started
    run_record = output / "baseline-run.json"
    run_record.write_text(
        json.dumps(
            {
                "schema_version": "baseline-run-1.0",
                "config": asdict(config),
                "protocol": str(protocol),
                "protocol_sha256": protocol_sha256,
                "expanded_command": command,
                "return_code": completed.returncode,
                "duration_seconds": duration,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if completed.returncode:
        raise RuntimeError(
            f"baseline failed with code {completed.returncode}; see {run_record}"
        )
    if not predictions.is_file():
        raise FileNotFoundError("baseline did not emit predictions.json")
    attempts, failures = _validate_complete_predictions(
        predictions, protocol, config.parameters
    )
    evaluation = evaluate_prediction_file(predictions, output / "evaluation.json")
    return BaselineRun(output, predictions, evaluation, attempts, failures)
