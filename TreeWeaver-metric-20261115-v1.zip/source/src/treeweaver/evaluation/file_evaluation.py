"""Canonical file runner for publication-grade benchmark predictions."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from treeweaver.evaluation.metrics import Prediction, evaluate_predictions


@dataclass(frozen=True, slots=True)
class EvaluationRun:
    output_path: Path
    parameter_count: int
    attempted_count: int


def evaluate_prediction_file(input_json: str | Path, output_json: str | Path) -> EvaluationRun:
    source = Path(input_json).resolve()
    payload: dict[str, Any] = json.loads(source.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "benchmark-predictions-1.0":
        raise ValueError("unsupported benchmark-prediction schema")
    grouped: dict[str, list[Prediction]] = {}
    strata: dict[str, dict[str, list[Prediction]]] = {}
    for item in payload.get("predictions", []):
        parameter = str(item["parameter"])
        prediction = Prediction(
            tree_id=str(item["tree_id"]),
            session_id=str(item["session_id"]),
            split=str(item["split"]),
            truth=float(item["truth"]),
            estimate=(float(item["estimate"]) if item.get("estimate") is not None else None),
            standard_deviation=(
                float(item["standard_deviation"])
                if item.get("standard_deviation") is not None
                else None
            ),
            confidence=float(item.get("confidence", 0.0)),
        )
        grouped.setdefault(parameter, []).append(prediction)
        for name, value in item.get("strata", {}).items():
            key = f"{name}={value}"
            strata.setdefault(parameter, {}).setdefault(key, []).append(prediction)
    if not grouped:
        raise ValueError("prediction file contains no attempts")

    results: dict[str, object] = {}
    for parameter, predictions in sorted(grouped.items()):
        overall = evaluate_predictions(tuple(predictions))
        stratified: dict[str, object] = {}
        for key, members in sorted(strata.get(parameter, {}).items()):
            if any(item.estimate is not None for item in members):
                stratified[key] = asdict(evaluate_predictions(tuple(members)))
        results[parameter] = {"overall": asdict(overall), "strata": stratified}
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-evaluation-1.0",
                "source": str(source),
                "parameters": results,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return EvaluationRun(destination, len(grouped), sum(len(items) for items in grouped.values()))
