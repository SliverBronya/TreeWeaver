"""Merge geometry, factor, species and quality evidence without hiding failures."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np

from treeweaver.domain.models import Parameter, ParameterEstimate
from treeweaver.guidance.factor_view import recommend_factor_view
from treeweaver.guidance.next_view import recommend_next_view
from treeweaver.guidance.visibility import AngularSector, VisibilityAssessment
from treeweaver.io.session import load_capture_session
from treeweaver.quality.decision import decide_measurement


@dataclass(frozen=True, slots=True)
class FinalReportRun:
    output_path: Path
    tree_count: int
    accepted_tree_count: int


def _estimate(
    parameter: Parameter, payload: dict[str, Any], value_key: str, deviation_key: str
) -> ParameterEstimate:
    return ParameterEstimate(
        parameter,
        float(payload[value_key]),
        float(payload[deviation_key]),
        float(payload["confidence"]),
        int(payload.get("observation_count", 1)),
        tuple(str(item) for item in payload.get("diagnostics", [])),
    )


def _load_optional_by_track(path: str | Path | None, schema: str) -> dict[int, dict[str, Any]]:
    if path is None:
        return {}
    payload: dict[str, Any] = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != schema:
        raise ValueError(f"unsupported input schema; expected {schema}")
    return {int(item["track_id"]): item for item in payload.get("trees", [])}


def _visibility(payload: dict[str, Any] | None) -> VisibilityAssessment | None:
    if payload is None:
        return None
    return VisibilityAssessment(
        dbh_angular_coverage_deg=float(payload["dbh_angular_coverage_deg"]),
        dbh_point_count=int(payload["dbh_point_count"]),
        missing_dbh_sectors=tuple(
            AngularSector(
                float(item["start_deg"]),
                float(item["end_deg"]),
                float(item["width_deg"]),
            )
            for item in payload.get("missing_dbh_sectors", [])
        ),
        root_visible=bool(payload["root_visible"]),
        apex_visible=bool(payload["apex_visible"]),
        crown_height_coverage=float(payload["crown_height_coverage"]),
        dbh_measurement_allowed=bool(payload["dbh_measurement_allowed"]),
        height_measurement_allowed=bool(payload["height_measurement_allowed"]),
        reasons=tuple(str(item) for item in payload.get("reasons", [])),
    )


def build_final_report(
    capture_manifest: str | Path,
    reconstruction_quality_json: str | Path,
    factor_results_json: str | Path,
    output_json: str | Path,
    *,
    crown_results_json: str | Path | None = None,
    species_results_json: str | Path | None = None,
) -> FinalReportRun:
    """Build the only report intended for downstream display or paper export."""

    session = load_capture_session(capture_manifest).session
    quality: dict[str, Any] = json.loads(
        Path(reconstruction_quality_json).read_text(encoding="utf-8")
    )
    if quality.get("schema_version") != "reconstruction-quality-1.0":
        raise ValueError("unsupported reconstruction quality schema")
    factor: dict[str, Any] = json.loads(Path(factor_results_json).read_text(encoding="utf-8"))
    if factor.get("schema_version") != "treefactor-tracks-1.0":
        raise ValueError("unsupported TreeFactor bundle schema")
    crowns = _load_optional_by_track(crown_results_json, "tree-measurements-1.0")
    species = _load_optional_by_track(species_results_json, "species-results-1.0")

    reports: list[dict[str, object]] = []
    accepted_count = 0
    for tree in factor.get("trees", []):
        track_id = int(tree["track_id"])
        if tree.get("status") != "ok":
            reports.append(
                {
                    "track_id": track_id,
                    "status": "failed",
                    "reason": tree.get("reason", tree.get("diagnostics", ["optimization failed"])),
                }
            )
            continue
        estimates = {
            Parameter.HEIGHT_M: _estimate(
                Parameter.HEIGHT_M, tree["height"], "value_m", "standard_deviation_m"
            ),
            Parameter.DBH_CM: _estimate(
                Parameter.DBH_CM, tree["dbh"], "value_cm", "standard_deviation_cm"
            ),
            Parameter.VOLUME_M3: _estimate(
                Parameter.VOLUME_M3, tree["volume"], "value_m3", "standard_deviation_m3"
            ),
        }
        crown = crowns.get(track_id)
        visibility = _visibility(crown.get("visibility") if crown is not None else None)
        if crown is not None and crown.get("status") == "ok":
            crown_fields = (
                ("crown_width", Parameter.CROWN_WIDTH_M),
                ("crown_depth", Parameter.CROWN_DEPTH_M),
                ("crown_height", Parameter.CROWN_HEIGHT_M),
                ("crown_volume", Parameter.CROWN_VOLUME_M3),
            )
            for field, parameter in crown_fields:
                if field in crown:
                    estimates[parameter] = _estimate(
                        parameter, crown[field], "value", "standard_deviation"
                    )
        semantic_confidence = float(tree.get("semantic_confidence", 0.0))
        blockers: dict[Parameter, tuple[str, ...]] = {}
        if visibility is not None:
            if not visibility.dbh_measurement_allowed:
                reason = ("胸高截面可见性不足",)
                blockers[Parameter.DBH_CM] = reason
                blockers[Parameter.VOLUME_M3] = reason
            if not visibility.height_measurement_allowed:
                reason = ("根部、树梢或垂直区段可见性不足",)
                blockers[Parameter.HEIGHT_M] = reason
                blockers[Parameter.VOLUME_M3] = tuple(
                    dict.fromkeys((*blockers.get(Parameter.VOLUME_M3, ()), *reason))
                )
        decision = decide_measurement(
            estimates,
            reconstruction_passed=bool(quality["passed"]),
            semantic_confidence=semantic_confidence,
            parameter_blockers=blockers,
        )
        covariance = tree.get("covariance")
        if visibility is not None and blockers:
            guidance = recommend_next_view(estimates, session.frames, visibility)
        elif covariance is not None:
            try:
                guidance = recommend_factor_view(covariance, estimates, session.frames)
            except (TypeError, ValueError, np.linalg.LinAlgError):
                guidance = recommend_next_view(estimates, session.frames)
        else:
            guidance = recommend_next_view(estimates, session.frames)
        species_item = species.get(track_id)
        accepted_species = (
            species_item.get("accepted_name")
            if species_item is not None and species_item.get("status") == "accepted"
            else None
        )
        status = "accepted" if decision.accepted else "needs_more_capture"
        accepted_count += int(decision.accepted)
        reports.append(
            {
                "track_id": track_id,
                "status": status,
                "estimates": {
                    parameter.value: asdict(estimate) for parameter, estimate in estimates.items()
                },
                "parameter_decisions": [asdict(item) for item in decision.parameters],
                "species": accepted_species,
                "species_evidence": species_item,
                "visibility": crown.get("visibility") if crown is not None else None,
                "next_capture": asdict(guidance),
            }
        )
    destination = Path(output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "treeweaver-final-report-1.0",
                "session_id": session.session_id,
                "reconstruction_passed": bool(quality["passed"]),
                "trees": reports,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return FinalReportRun(destination, len(reports), accepted_count)
