"""Leakage-safe residual supervision for learned evidence reliability."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt
from scipy.optimize import minimize

from treeweaver.reliability.baseline import ReliabilityFeatures

FloatArray = npt.NDArray[np.float64]

_FEATURE_NAMES = tuple(ReliabilityFeatures.__dataclass_fields__)


@dataclass(frozen=True, slots=True)
class ReliabilityTrainingExample:
    sample_id: str
    tree_id: str
    split: str
    features: ReliabilityFeatures
    normalized_absolute_error: float
    prediction_is_out_of_fold: bool

    def __post_init__(self) -> None:
        if not self.sample_id or not self.tree_id or not self.split:
            raise ValueError("reliability example identity cannot be empty")
        if self.normalized_absolute_error < 0:
            raise ValueError("normalized error cannot be negative")


@dataclass(frozen=True, slots=True)
class MonotonicReliabilityModel:
    intercept: float
    weights: tuple[float, ...]
    feature_names: tuple[str, ...] = _FEATURE_NAMES

    def __post_init__(self) -> None:
        if len(self.weights) != len(self.feature_names) or any(value < 0 for value in self.weights):
            raise ValueError("reliability model requires one non-negative weight per feature")

    def predict(self, features: ReliabilityFeatures) -> float:
        values = np.array([getattr(features, name) for name in self.feature_names])
        logit = self.intercept + float(np.asarray(self.weights) @ values)
        return float(1 / (1 + np.exp(-np.clip(logit, -40, 40))))


def _training_arrays(
    examples: tuple[ReliabilityTrainingExample, ...],
) -> tuple[FloatArray, FloatArray]:
    if len(examples) < 20:
        raise ValueError("reliability fitting requires at least 20 independent observations")
    if len({item.sample_id for item in examples}) != len(examples):
        raise ValueError("reliability sample ids must be unique")
    forbidden = [item.sample_id for item in examples if item.split in {"test", "external_test"}]
    if forbidden:
        raise ValueError("test observations cannot train reliability")
    leaked = [item.sample_id for item in examples if not item.prediction_is_out_of_fold]
    if leaked:
        raise ValueError("reliability labels must come from out-of-fold predictions")
    matrix = np.array(
        [[getattr(item.features, name) for name in _FEATURE_NAMES] for item in examples],
        dtype=np.float64,
    )
    target = np.array(
        [item.normalized_absolute_error <= 1.0 for item in examples], dtype=np.float64
    )
    if len(np.unique(target)) < 2:
        raise ValueError("reliability fitting requires both usable and unusable examples")
    return matrix, target


def fit_monotonic_reliability(
    examples: tuple[ReliabilityTrainingExample, ...], *, regularization: float = 0.01
) -> MonotonicReliabilityModel:
    """Fit a constrained logistic model where better quality cannot lower reliability."""

    if regularization < 0:
        raise ValueError("regularization cannot be negative")
    matrix, target = _training_arrays(examples)

    def objective(parameters: FloatArray) -> float:
        logits = parameters[0] + matrix @ parameters[1:]
        probabilities = 1 / (1 + np.exp(-np.clip(logits, -40, 40)))
        epsilon = 1e-12
        loss = -np.mean(
            target * np.log(probabilities + epsilon)
            + (1 - target) * np.log(1 - probabilities + epsilon)
        )
        return float(loss + regularization * np.sum(parameters[1:] ** 2))

    initial = np.r_[0.0, np.ones(matrix.shape[1])]
    fitted = minimize(
        objective,
        initial,
        method="L-BFGS-B",
        bounds=[(None, None), *[(0.0, None) for _ in range(matrix.shape[1])]],
    )
    if not fitted.success:
        raise RuntimeError(f"reliability optimization failed: {fitted.message}")
    return MonotonicReliabilityModel(
        float(fitted.x[0]), tuple(float(value) for value in fitted.x[1:])
    )
