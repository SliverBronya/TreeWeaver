"""Transparent reliability baseline used before TreeReliabilityNet is trained."""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, log


@dataclass(frozen=True, slots=True)
class ReliabilityFeatures:
    sharpness: float
    visible_fraction: float
    unoccluded_fraction: float
    temporal_consistency: float
    geometric_consistency: float
    view_angle_quality: float
    model_agreement: float

    def __post_init__(self) -> None:
        for name in self.__dataclass_fields__:
            value = getattr(self, name)
            if not 0 <= value <= 1:
                raise ValueError(f"{name} must be in [0, 1]")


@dataclass(frozen=True, slots=True)
class ReliabilityResult:
    score: float
    usable: bool
    reasons: tuple[str, ...]
    feature_contributions: dict[str, float]


_WEIGHTS = {
    "sharpness": 0.10,
    "visible_fraction": 0.18,
    "unoccluded_fraction": 0.18,
    "temporal_consistency": 0.14,
    "geometric_consistency": 0.20,
    "view_angle_quality": 0.08,
    "model_agreement": 0.12,
}


def score_reliability(
    features: ReliabilityFeatures, *, minimum_usable_score: float = 0.35
) -> ReliabilityResult:
    """Score evidence with a weighted geometric mean and explicit vetoes."""

    if not 0 < minimum_usable_score < 1:
        raise ValueError("minimum usable score must be in (0, 1)")
    contributions = {
        name: weight * float(getattr(features, name)) for name, weight in _WEIGHTS.items()
    }
    log_score = sum(
        weight * log(max(float(getattr(features, name)), 1e-6))
        for name, weight in _WEIGHTS.items()
    )
    score = exp(log_score)
    reasons: list[str] = []
    if features.visible_fraction < 0.2:
        reasons.append("less than 20% of the target is visible")
    if features.geometric_consistency < 0.15:
        reasons.append("evidence conflicts with reconstructed geometry")
    if features.unoccluded_fraction < 0.15:
        reasons.append("target is almost completely occluded")
    if score < minimum_usable_score:
        reasons.append("combined reliability is below the acceptance threshold")
    return ReliabilityResult(score, not reasons, tuple(reasons), contributions)
