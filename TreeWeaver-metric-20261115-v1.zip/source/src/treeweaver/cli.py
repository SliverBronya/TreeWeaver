from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from treeweaver.association.bundle import associate_instance_bundle
from treeweaver.association.root_bundle import separate_root_bundle
from treeweaver.association.root_clicks import triangulate_root_click_file
from treeweaver.calibration.fiducial import generate_aruco_marker_svg
from treeweaver.calibration.marker_bundle import register_aruco_scale
from treeweaver.calibration.scale_file import estimate_scale_file
from treeweaver.datasets.acquisition import download_artifact, write_dataset_receipt
from treeweaver.datasets.archive import extract_archive_safely, write_inventory
from treeweaver.datasets.greenlens import prepare_greenlens
from treeweaver.datasets.quebec_geometry import run_quebec_geometry_baseline
from treeweaver.datasets.quebec_volume import write_published_baselines
from treeweaver.datasets.registry import get_dataset, list_datasets
from treeweaver.datasets.whu_stree import inspect_whu_release
from treeweaver.evaluation.baseline_runner import load_baseline_config, run_external_baseline
from treeweaver.evaluation.file_evaluation import evaluate_prediction_file
from treeweaver.evaluation.stereo_pilot import (
    run_assisted_stereo_dbh,
    run_masked_stereo_dataset,
    run_masked_stereo_dbh,
)
from treeweaver.factor.bundle import optimize_tree_factor_bundle
from treeweaver.factor.file_optimization import optimize_tree_factor_file
from treeweaver.geometry.file_measurement import measure_semantic_point_file
from treeweaver.io.raw_capture import ingest_raw_capture
from treeweaver.io.session import load_capture_session
from treeweaver.measurement.bundle import measure_semantic_bundle
from treeweaver.pipeline.full_run import load_full_pipeline_config, run_full_pipeline
from treeweaver.providers.colmap_runner import ColmapConfig, ColmapRunner
from treeweaver.providers.external_worker import (
    load_external_worker_config,
    run_external_vision_worker,
)
from treeweaver.reconstruction.quality import assess_reconstruction_quality, write_quality_report
from treeweaver.reconstruction.rgbd_bundle import fuse_rgbd_tree_bundle
from treeweaver.reporting.final_report import build_final_report
from treeweaver.semantics.bundle import fuse_semantic_bundle
from treeweaver.semantics.root_refinement import refine_semantic_bundle_by_roots
from treeweaver.simulation.ablation import run_synthetic_ablation
from treeweaver.species.file_fusion import fuse_species_file
from treeweaver.species.prototype_file import predict_prototype_file, train_prototype_models


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="treeweaver")
    subcommands = parser.add_subparsers(dest="command", required=True)
    validate = subcommands.add_parser("validate-capture", help="validate a capture manifest")
    validate.add_argument("manifest")
    validate.add_argument("--skip-assets", action="store_true")
    ingest = subcommands.add_parser("ingest-raw", help="extract and validate a raw phone capture")
    ingest.add_argument("manifest")
    ingest.add_argument("output")
    ingest.add_argument("--sample-hz", type=float, default=2.0)
    ingest.add_argument("--max-frames", type=int, default=240)
    measure = subcommands.add_parser(
        "measure-geometry", help="measure metric trunk/crown/ground point arrays"
    )
    measure.add_argument("input_npz")
    measure.add_argument("output_json")
    reconstruct = subcommands.add_parser(
        "reconstruct-colmap", help="run an auditable COLMAP sparse reconstruction"
    )
    reconstruct.add_argument("manifest")
    reconstruct.add_argument("output")
    reconstruct.add_argument("--executable", default="colmap")
    reconstruct.add_argument("--cpu", action="store_true")
    reconstruct.add_argument("--dense", action="store_true")
    reconstruct.add_argument("--dense-max-image-size", type=int, default=2000)
    rgbd = subcommands.add_parser(
        "fuse-arcore-rgbd", help="fuse aligned metric RGB-D frames using ARCore world poses"
    )
    rgbd.add_argument("capture_manifest")
    rgbd.add_argument("masks_manifest")
    rgbd.add_argument("output")
    rgbd.add_argument("--voxel-size-m", type=float, default=0.02)
    rgbd.add_argument("--minimum-depth-confidence", type=float, default=0.35)
    rgbd.add_argument("--minimum-views", type=int, default=1)
    rgbd.add_argument("--stride", type=int, default=1)
    associate = subcommands.add_parser(
        "associate-instances", help="link per-frame tree masks through dense 3-D support"
    )
    associate.add_argument("capture_manifest")
    associate.add_argument("colmap_text_model")
    associate.add_argument("dense_point_cloud")
    associate.add_argument("observation_manifest")
    associate.add_argument("output")
    associate.add_argument("--minimum-support-points", type=int, default=20)
    associate.add_argument("--minimum-jaccard", type=float, default=0.15)
    roots = subcommands.add_parser(
        "separate-roots",
        help="separate touching reconstructed trees by root-anchored 3-D topology",
    )
    roots.add_argument("point_cloud")
    roots.add_argument("root_anchors_json")
    roots.add_argument("output")
    roots.add_argument("--trunk-probability-npz")
    roots.add_argument("--candidate-indices-npz")
    roots.add_argument("--ground-indices-npz")
    roots.add_argument("--neighbor-count", type=int, default=10)
    roots.add_argument("--maximum-edge-length", type=float, default=0.45)
    roots.add_argument("--maximum-root-distance", type=float, default=0.35)
    roots.add_argument("--ambiguity-ratio", type=float, default=0.12)
    root_clicks = subcommands.add_parser(
        "triangulate-roots",
        help="initialize target roots from one dense-view click or robust multi-view clicks",
    )
    root_clicks.add_argument("capture_manifest")
    root_clicks.add_argument("colmap_text_model")
    root_clicks.add_argument("root_clicks_json")
    root_clicks.add_argument("output_json")
    root_clicks.add_argument("--up", type=float, nargs=3)
    root_clicks.add_argument("--dense-point-cloud")
    root_clicks.add_argument("--maximum-reprojection-error-px", type=float, default=3.0)
    root_clicks.add_argument("--minimum-parallax-deg", type=float, default=1.5)
    parts = subcommands.add_parser(
        "fuse-parts", help="fuse trunk, crown, and ground masks into semantic 3-D points"
    )
    parts.add_argument("capture_manifest")
    parts.add_argument("colmap_text_model")
    parts.add_argument("dense_point_cloud")
    parts.add_argument("observation_manifest")
    parts.add_argument("track_directory")
    parts.add_argument("output")
    parts.add_argument("--minimum-score", type=float, default=0.5)
    parts.add_argument("--minimum-margin", type=float, default=0.15)
    root_parts = subcommands.add_parser(
        "refine-semantics-by-roots",
        help="split semantic tree evidence by root ownership and exclude shared geometry",
    )
    root_parts.add_argument("semantic_directory")
    root_parts.add_argument("root_assignment_directory")
    root_parts.add_argument("output")
    batch_measure = subcommands.add_parser(
        "measure-tracks", help="measure fused semantic tracks in metric coordinates"
    )
    batch_measure.add_argument("dense_point_cloud")
    batch_measure.add_argument("semantic_directory")
    batch_measure.add_argument("output_json")
    batch_measure.add_argument("--metres-per-unit", type=float, required=True)
    batch_measure.add_argument("--scale-sd", type=float, default=0.0)
    batch_measure.add_argument("--up", type=float, nargs=3)
    batch_measure.add_argument("--ground-radius-m", type=float, default=2.0)
    factor = subcommands.add_parser(
        "optimize-treefactor", help="jointly optimize scale, height, DBH, and taper"
    )
    factor.add_argument("points_npz")
    factor.add_argument("anchors_json")
    factor.add_argument("output_json")
    factor_tracks = subcommands.add_parser(
        "optimize-factor-tracks", help="run joint TreeFactor optimization for all tree tracks"
    )
    factor_tracks.add_argument("dense_point_cloud")
    factor_tracks.add_argument("semantic_directory")
    factor_tracks.add_argument("anchors_json")
    factor_tracks.add_argument("output_json")
    factor_tracks.add_argument("--ground-radius-m", type=float, default=2.0)
    dataset_list = subcommands.add_parser("dataset-list", help="list registered datasets")
    dataset_list.set_defaults(command="dataset-list")
    dataset_info = subcommands.add_parser("dataset-info", help="show immutable dataset metadata")
    dataset_info.add_argument("key")
    dataset_download = subcommands.add_parser(
        "dataset-download", help="explicitly download and verify a registered dataset"
    )
    dataset_download.add_argument("key")
    dataset_download.add_argument("destination")
    dataset_inventory = subcommands.add_parser(
        "dataset-inventory", help="inspect a ZIP or tar archive without extracting it"
    )
    dataset_inventory.add_argument("archive")
    dataset_inventory.add_argument("output_json")
    dataset_extract = subcommands.add_parser(
        "dataset-extract", help="safely extract a previously inspected ZIP or tar archive"
    )
    dataset_extract.add_argument("archive")
    dataset_extract.add_argument("destination")
    greenlens = subcommands.add_parser(
        "prepare-greenlens", help="validate GreenLens v2 and write an RGB-depth DBH manifest"
    )
    greenlens.add_argument("dataset_root")
    greenlens.add_argument("output_json")
    quebec = subcommands.add_parser(
        "prepare-quebec-volume",
        help="convert Quebec-98 destructive references and supplied baselines",
    )
    quebec.add_argument("tree_attributes_csv")
    quebec.add_argument("output_json")
    quebec_geometry = subcommands.add_parser(
        "benchmark-quebec-geometry",
        help="run TreeWeaver DBH/height/crown geometry on Quebec-98 LAZ files",
    )
    quebec_geometry.add_argument("laz_root")
    quebec_geometry.add_argument("tree_attributes_csv")
    quebec_geometry.add_argument("output_json")
    whu = subcommands.add_parser(
        "inspect-whu-stree", help="validate an obtained WHU-STree final release"
    )
    whu.add_argument("dataset_root")
    whu.add_argument("output_json")
    synthetic = subcommands.add_parser(
        "simulate-ablation", help="run pre-field TreeFactor fault injection"
    )
    synthetic.add_argument("output_json")
    synthetic.add_argument("--seeds", type=int, default=3)
    marker = subcommands.add_parser(
        "register-marker", help="triangulate an ArUco marker into TreeFactor anchors"
    )
    marker.add_argument("capture_manifest")
    marker.add_argument("colmap_text_model")
    marker.add_argument("output_json")
    marker.add_argument("--marker-id", type=int, required=True)
    marker.add_argument("--edge-length-m", type=float, required=True)
    marker.add_argument("--dictionary", default="4x4_50")
    marker_asset = subcommands.add_parser(
        "generate-marker", help="create a physical-size printable ArUco SVG"
    )
    marker_asset.add_argument("output_svg")
    marker_asset.add_argument("--marker-id", type=int, required=True)
    marker_asset.add_argument("--edge-length-mm", type=float, required=True)
    marker_asset.add_argument("--dictionary", default="4x4_50")
    species = subcommands.add_parser(
        "fuse-species", help="fuse multiview multi-organ species probabilities"
    )
    species.add_argument("input_json")
    species.add_argument("output_json")
    species_train = subcommands.add_parser(
        "train-species-prototypes", help="fit immutable organ-specific prototype models"
    )
    species_train.add_argument("examples_json")
    species_train.add_argument("output_directory")
    species_predict = subcommands.add_parser(
        "predict-species-prototypes", help="convert pinned embeddings into species evidence"
    )
    species_predict.add_argument("model_directory")
    species_predict.add_argument("embeddings_json")
    species_predict.add_argument("output_json")
    report = subcommands.add_parser(
        "build-report", help="merge estimates, quality and species into final tree reports"
    )
    report.add_argument("capture_manifest")
    report.add_argument("reconstruction_quality_json")
    report.add_argument("factor_results_json")
    report.add_argument("output_json")
    report.add_argument("--crown-results-json")
    report.add_argument("--species-results-json")
    evaluation = subcommands.add_parser(
        "evaluate", help="compute accuracy, calibration, failure and stratified metrics"
    )
    evaluation.add_argument("predictions_json")
    evaluation.add_argument("output_json")
    stereo = subcommands.add_parser(
        "evaluate-stereo-dbh", help="run an explicitly assisted calibrated-stereo DBH pilot"
    )
    stereo.add_argument("left_image")
    stereo.add_argument("right_image")
    stereo.add_argument("calibration_yml")
    stereo.add_argument("output_json")
    stereo.add_argument("--truth-cm", type=float, required=True)
    stereo.add_argument("--tree-id", required=True)
    stereo.add_argument("--seed-x", type=int, required=True)
    stereo.add_argument("--breast-height-row", type=int, required=True)
    masked_stereo = subcommands.add_parser(
        "evaluate-masked-stereo-dbh", help="run a published-style masked-stereo DBH baseline"
    )
    masked_stereo.add_argument("left_image")
    masked_stereo.add_argument("right_image")
    masked_stereo.add_argument("mask_image")
    masked_stereo.add_argument("calibration_yml")
    masked_stereo.add_argument("output_json")
    masked_stereo.add_argument("--truth-cm", type=float, required=True)
    masked_stereo.add_argument("--tree-id", required=True)
    masked_stereo.add_argument("--diagonal-fov-deg", type=float, default=55.0)
    masked_stereo.add_argument("--segmentation-label", default="ground-truth-mask")
    masked_dataset = subcommands.add_parser(
        "evaluate-masked-stereo-dataset", help="evaluate all v4 DBH pairs and retain failures"
    )
    masked_dataset.add_argument("dataset_root")
    masked_dataset.add_argument("calibration_yml")
    masked_dataset.add_argument("output_json")
    masked_dataset.add_argument("--diagonal-fov-deg", type=float, default=55.0)
    masked_dataset.add_argument("--mask-directory")
    masked_dataset.add_argument("--segmentation-label", default="ground-truth-mask")
    baseline = subcommands.add_parser(
        "run-baseline", help="run and audit a formal baseline on a frozen protocol"
    )
    baseline.add_argument("config_json")
    baseline.add_argument("protocol_json")
    baseline.add_argument("output_directory")
    vision = subcommands.add_parser(
        "run-vision-worker", help="run an isolated learned provider and validate its masks"
    )
    vision.add_argument("config_json")
    vision.add_argument("capture_manifest")
    vision.add_argument("output_directory")
    scale = subcommands.add_parser("estimate-scale", help="estimate metric scale from 3-D anchors")
    scale.add_argument("anchors_json")
    scale.add_argument("output_json")
    full = subcommands.add_parser(
        "run-full", help="run the fail-closed pipeline from a raw phone capture"
    )
    full.add_argument("config_json")
    return parser


def main() -> int:
    args = _build_parser().parse_args()
    if args.command == "validate-capture":
        validation = load_capture_session(args.manifest, verify_assets=not args.skip_assets)
        print(
            f"valid session {validation.session.session_id}: "
            f"{len(validation.session.frames)} frames, "
            f"{len(validation.session.anchors)} scale anchor(s)"
        )
        for warning in validation.warnings:
            print(f"warning: {warning}")
        return 0
    if args.command == "measure-geometry":
        output = measure_semantic_point_file(args.input_npz, args.output_json)
        print(f"geometry result: {output}")
        return 0
    if args.command == "ingest-raw":
        ingestion = ingest_raw_capture(
            args.manifest, args.output, sample_hz=args.sample_hz, max_frames=args.max_frames
        )
        print(
            f"ingested {ingestion.frame_count} frames at "
            f"{ingestion.video_width}x{ingestion.video_height}; "
            f"manifest: {ingestion.manifest_path}"
        )
        for warning in ingestion.warnings:
            print(f"warning: {warning}")
        return 0
    if args.command == "reconstruct-colmap":
        manifest = Path(args.manifest).resolve()
        output = Path(args.output).resolve()
        runner = ColmapRunner(
            ColmapConfig(
                executable=args.executable,
                use_gpu=not args.cpu,
                dense=args.dense,
                dense_max_image_size=args.dense_max_image_size,
            )
        )
        reconstruction = runner.reconstruct(manifest, output)
        expected = len(load_capture_session(manifest).session.frames)
        quality = assess_reconstruction_quality(reconstruction, expected)
        report = write_quality_report(quality, output / "quality.json")
        print(f"COLMAP quality gate: {'PASS' if quality.passed else 'FAIL'}; report: {report}")
        if args.dense:
            print(f"dense point cloud: {output / 'fused.ply'}")
        for issue in quality.issues:
            print(f"issue: {issue}")
        return 0 if quality.passed else 3
    if args.command == "fuse-arcore-rgbd":
        run = fuse_rgbd_tree_bundle(
            args.capture_manifest,
            args.masks_manifest,
            args.output,
            voxel_size_m=args.voxel_size_m,
            minimum_depth_confidence=args.minimum_depth_confidence,
            minimum_views=args.minimum_views,
            stride=args.stride,
        )
        print(
            f"fused {run.frame_count} metric RGB-D frames into {run.point_count} points; "
            f"measurement: {run.measurement_path}"
        )
        return 0
    if args.command == "associate-instances":
        association = associate_instance_bundle(
            args.capture_manifest,
            args.colmap_text_model,
            args.dense_point_cloud,
            args.observation_manifest,
            args.output,
            minimum_support_points=args.minimum_support_points,
            minimum_jaccard=args.minimum_jaccard,
        )
        print(
            f"associated {association.associated_observations} observations into "
            f"{association.track_count} tree tracks; "
            f"unassociated: {association.unassociated_observations}"
        )
        return 0
    if args.command == "separate-roots":
        separation = separate_root_bundle(
            args.point_cloud,
            args.root_anchors_json,
            args.output,
            trunk_probability_npz=args.trunk_probability_npz,
            candidate_indices_npz=args.candidate_indices_npz,
            ground_indices_npz=args.ground_indices_npz,
            neighbor_count=args.neighbor_count,
            maximum_edge_length=args.maximum_edge_length,
            maximum_root_distance=args.maximum_root_distance,
            ambiguity_ratio=args.ambiguity_ratio,
        )
        print(
            f"separated {separation.tree_count} roots: "
            f"{separation.assigned_point_count} assigned, "
            f"{separation.ambiguous_point_count} ambiguous, "
            f"{separation.unreachable_point_count} unreachable points"
        )
        return 0
    if args.command == "triangulate-roots":
        root_run = triangulate_root_click_file(
            args.capture_manifest,
            args.colmap_text_model,
            args.root_clicks_json,
            args.output_json,
            up=args.up,
            dense_point_cloud=args.dense_point_cloud,
            maximum_reprojection_error_px=args.maximum_reprojection_error_px,
            minimum_parallax_deg=args.minimum_parallax_deg,
        )
        print(
            f"triangulated {root_run.tree_count} roots from "
            f"{root_run.accepted_click_count} accepted clicks; "
            f"rejected: {root_run.rejected_click_count}"
        )
        return 0
    if args.command == "fuse-parts":
        semantic = fuse_semantic_bundle(
            args.capture_manifest,
            args.colmap_text_model,
            args.dense_point_cloud,
            args.observation_manifest,
            args.track_directory,
            args.output,
            minimum_score=args.minimum_score,
            minimum_margin=args.minimum_margin,
        )
        print(
            f"fused {semantic.track_count} tracks: {semantic.trunk_points} trunk, "
            f"{semantic.crown_points} crown, {semantic.ground_points} ground, "
            f"{semantic.ambiguous_points} ambiguous points"
        )
        return 0
    if args.command == "refine-semantics-by-roots":
        refined = refine_semantic_bundle_by_roots(
            args.semantic_directory,
            args.root_assignment_directory,
            args.output,
        )
        print(
            f"refined {refined.tree_count} root-owned trees: "
            f"{refined.trunk_points} trunk, {refined.crown_points} crown, "
            f"{refined.excluded_ambiguous_points} shared points excluded"
        )
        return 0
    if args.command == "measure-tracks":
        measurement = measure_semantic_bundle(
            args.dense_point_cloud,
            args.semantic_directory,
            args.output_json,
            metres_per_unit=args.metres_per_unit,
            scale_standard_deviation=args.scale_sd,
            up_hint=args.up,
            ground_radius_m=args.ground_radius_m,
        )
        print(
            f"measured {measurement.successful_trees} trees; "
            f"failed: {measurement.failed_trees}; output: {measurement.output_path}"
        )
        return 0 if measurement.failed_trees == 0 else 4
    if args.command == "optimize-treefactor":
        factor_run = optimize_tree_factor_file(args.points_npz, args.anchors_json, args.output_json)
        print(
            f"TreeFactor {'converged' if factor_run.result.success else 'failed'}: "
            f"height={factor_run.result.height.value:.3f} m, "
            f"DBH={factor_run.result.dbh.value:.2f} cm, "
            f"geometric volume={factor_run.result.volume.value:.3f} m^3, "
            f"output: {factor_run.output_path}"
        )
        return 0 if factor_run.result.success else 5
    if args.command == "optimize-factor-tracks":
        bundle_run = optimize_tree_factor_bundle(
            args.dense_point_cloud,
            args.semantic_directory,
            args.anchors_json,
            args.output_json,
            ground_radius_m=args.ground_radius_m,
        )
        print(
            f"TreeFactor optimized {bundle_run.successful_trees} trees; "
            f"failed: {bundle_run.failed_trees}; output: {bundle_run.output_path}"
        )
        return 0 if bundle_run.failed_trees == 0 else 5
    if args.command == "dataset-list":
        for dataset in list_datasets():
            print(f"{dataset.key}: {dataset.title}")
        return 0
    if args.command == "dataset-info":
        print(json.dumps(asdict(get_dataset(args.key)), ensure_ascii=False, indent=2))
        return 0
    if args.command == "dataset-download":
        descriptor = get_dataset(args.key)
        if not descriptor.files:
            raise SystemExit(
                f"dataset {descriptor.key!r} has no public immutable download; "
                f"{descriptor.access_notes or descriptor.record_url}"
            )
        directory = Path(args.destination).resolve() / descriptor.key
        paths = tuple(
            download_artifact(artifact, directory / artifact.filename).path
            for artifact in descriptor.files
        )
        receipt = write_dataset_receipt(descriptor, directory, paths)
        print(f"verified dataset: {receipt}")
        return 0
    if args.command == "dataset-inventory":
        inventory = write_inventory(Path(args.archive), Path(args.output_json))
        print(
            f"archive contains {inventory.file_count} files, "
            f"{inventory.total_uncompressed_bytes} uncompressed bytes"
        )
        return 0
    if args.command == "dataset-extract":
        inventory = extract_archive_safely(Path(args.archive), Path(args.destination))
        print(f"extracted {inventory.file_count} files to {Path(args.destination).resolve()}")
        return 0
    if args.command == "prepare-greenlens":
        samples = prepare_greenlens(args.dataset_root, args.output_json)
        print(f"prepared GreenLens manifest with {len(samples)} verified RGB-depth pairs")
        return 0
    if args.command == "prepare-quebec-volume":
        trees = write_published_baselines(args.tree_attributes_csv, args.output_json)
        print(f"prepared Quebec destructive-volume benchmark for {trees} trees")
        return 0
    if args.command == "benchmark-quebec-geometry":
        trees, failures = run_quebec_geometry_baseline(
            args.laz_root, args.tree_attributes_csv, args.output_json
        )
        print(f"benchmarked {trees} Quebec trees with {failures} DBH failures")
        return 0
    if args.command == "inspect-whu-stree":
        whu_inventory = inspect_whu_release(args.dataset_root, args.output_json)
        print(
            f"inspected WHU-STree: {whu_inventory.image_files} images, "
            f"{whu_inventory.point_cloud_files} point clouds, "
            f"{whu_inventory.missing_pose_images} missing pose-image links"
        )
        return 0
    if args.command == "evaluate-stereo-dbh":
        stereo_result = run_assisted_stereo_dbh(
            args.left_image,
            args.right_image,
            args.calibration_yml,
            args.output_json,
            truth_cm=args.truth_cm,
            tree_id=args.tree_id,
            seed_x=args.seed_x,
            breast_height_row=args.breast_height_row,
        )
        print(
            f"assisted stereo DBH={stereo_result.dbh_cm:.2f} cm "
            f"(row SD={stereo_result.standard_deviation_cm:.2f} cm; "
            f"{stereo_result.valid_rows}/{stereo_result.attempted_rows} valid rows)"
        )
        return 0
    if args.command == "evaluate-masked-stereo-dbh":
        masked_result = run_masked_stereo_dbh(
            args.left_image,
            args.right_image,
            args.mask_image,
            args.calibration_yml,
            args.output_json,
            truth_cm=args.truth_cm,
            tree_id=args.tree_id,
            diagonal_fov_deg=args.diagonal_fov_deg,
            segmentation_label=args.segmentation_label,
        )
        print(
            f"masked stereo DBH={masked_result.dbh_cm:.2f} cm; "
            f"BH row={masked_result.breast_height_row}; "
            f"width={masked_result.trunk_width_px} px"
        )
        return 0
    if args.command == "evaluate-masked-stereo-dataset":
        attempts, failures = run_masked_stereo_dataset(
            args.dataset_root,
            args.calibration_yml,
            args.output_json,
            diagonal_fov_deg=args.diagonal_fov_deg,
            mask_directory=args.mask_directory,
            segmentation_label=args.segmentation_label,
        )
        print(f"masked stereo dataset: {attempts} attempts, {failures} failures")
        return 0 if failures == 0 else 5
    if args.command == "simulate-ablation":
        output = run_synthetic_ablation(args.output_json, seeds=args.seeds)
        print(f"synthetic ablation: {output}")
        return 0
    if args.command == "register-marker":
        output = register_aruco_scale(
            args.capture_manifest,
            args.colmap_text_model,
            args.output_json,
            marker_id=args.marker_id,
            edge_length_m=args.edge_length_m,
            dictionary=args.dictionary,
        )
        print(f"marker anchors: {output}")
        return 0
    if args.command == "generate-marker":
        output = generate_aruco_marker_svg(
            args.output_svg,
            args.marker_id,
            edge_length_mm=args.edge_length_mm,
            dictionary=args.dictionary,
        )
        print(f"printable marker: {output}")
        return 0
    if args.command == "fuse-species":
        species_run = fuse_species_file(args.input_json, args.output_json)
        print(
            f"species fused for {species_run.tree_count} trees; "
            f"accepted: {species_run.accepted_count}"
        )
        return 0
    if args.command == "train-species-prototypes":
        training_run = train_prototype_models(args.examples_json, args.output_directory)
        print(
            f"species prototypes: {training_run.organ_count} organs, "
            f"{training_run.taxon_count} taxa; model: {training_run.model_directory}"
        )
        return 0
    if args.command == "predict-species-prototypes":
        prediction_run = predict_prototype_file(
            args.model_directory, args.embeddings_json, args.output_json
        )
        print(
            f"species evidence: {prediction_run.evidence_count} observations across "
            f"{prediction_run.tree_count} trees; output: {prediction_run.output_path}"
        )
        return 0
    if args.command == "build-report":
        report_run = build_final_report(
            args.capture_manifest,
            args.reconstruction_quality_json,
            args.factor_results_json,
            args.output_json,
            crown_results_json=args.crown_results_json,
            species_results_json=args.species_results_json,
        )
        print(f"final reports: {report_run.tree_count}; accepted: {report_run.accepted_tree_count}")
        return 0
    if args.command == "evaluate":
        evaluation_run = evaluate_prediction_file(args.predictions_json, args.output_json)
        print(
            f"evaluated {evaluation_run.attempted_count} attempts across "
            f"{evaluation_run.parameter_count} parameters"
        )
        return 0
    if args.command == "run-baseline":
        baseline_run = run_external_baseline(
            load_baseline_config(args.config_json),
            args.protocol_json,
            args.output_directory,
        )
        print(
            f"baseline attempts: {baseline_run.attempted_count}; "
            f"failures: {baseline_run.failure_count}; "
            f"evaluation: {baseline_run.evaluation.output_path}"
        )
        return 0
    if args.command == "run-vision-worker":
        worker = run_external_vision_worker(
            load_external_worker_config(args.config_json),
            args.capture_manifest,
            args.output_directory,
        )
        print(
            f"vision evidence: {worker.instance_count} instances, "
            f"{worker.mask_file_count} masks; manifest: {worker.observation_manifest}"
        )
        return 0
    if args.command == "estimate-scale":
        output = estimate_scale_file(args.anchors_json, args.output_json)
        print(f"metric scale: {output}")
        return 0
    if args.command == "run-full":
        result = run_full_pipeline(load_full_pipeline_config(args.config_json))
        if result.final_report is not None:
            print(f"full pipeline complete; report: {result.final_report}")
            return 0
        print(f"full pipeline halted: {result.status}; reason: {result.reason}")
        return 6
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
