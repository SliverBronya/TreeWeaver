"""Reliability-aware robust fusion: the first executable TreeFactor primitive."""

from __future__ import annotations

from math import exp, sqrt
from statistics import median

from treeweaver.domain.models import Parameter, ParameterEstimate, ScalarObservation


def fuse_scalar_observations(
    parameter: Parameter,
    observations: tuple[ScalarObservation, ...],
    *,
    minimum_reliability: float = 0.05,
) -> ParameterEstimate:
    """Fuse views using measurement precision, learned reliability, and Huber weights.

    This is intentionally model-agnostic. Later, TreeReliabilityNet will predict
    reliability from image/depth/temporal evidence, while TreeFactor will extend
    this scalar primitive to a joint pose-scale-tree optimization graph.
    """

    usable = tuple(obs for obs in observations if obs.reliability >= minimum_reliability)
    if not usable:
        raise ValueError("no observation passed the reliability threshold")

    centre = median(obs.value for obs in usable)
    absolute_residuals = [abs(obs.value - centre) for obs in usable]
    mad = median(absolute_residuals) if len(usable) > 1 else usable[0].standard_deviation
    robust_scale = max(1.4826 * mad, min(obs.standard_deviation for obs in usable), 1e-9)
    huber_delta = 1.5 * robust_scale

    weighted: list[tuple[ScalarObservation, float]] = []
    for obs in usable:
        residual = abs(obs.value - centre)
        huber_weight = 1.0 if residual <= huber_delta else huber_delta / residual
        precision = 1.0 / (obs.standard_deviation**2)
        weighted.append((obs, obs.reliability * huber_weight * precision))

    total_weight = sum(weight for _, weight in weighted)
    value = sum(obs.value * weight for obs, weight in weighted) / total_weight
    posterior_sd = sqrt(1.0 / total_weight)
    disagreement = sqrt(
        sum(weight * (obs.value - value) ** 2 for obs, weight in weighted) / total_weight
    )
    standard_deviation = sqrt(posterior_sd**2 + disagreement**2)
    mean_reliability = sum(obs.reliability for obs in usable) / len(usable)
    relative_uncertainty = standard_deviation / max(abs(value), 1e-9)
    confidence = mean_reliability * (1 - exp(-len(usable) / 2)) * exp(-relative_uncertainty)

    diagnostics: list[str] = []
    rejected = len(observations) - len(usable)
    if rejected:
        diagnostics.append(f"rejected {rejected} low-reliability observation(s)")
    if disagreement > 2 * posterior_sd:
        diagnostics.append("views disagree beyond their reported sensor noise")

    return ParameterEstimate(
        parameter=parameter,
        value=value,
        standard_deviation=standard_deviation,
        confidence=max(0.0, min(1.0, confidence)),
        observation_count=len(usable),
        diagnostics=tuple(diagnostics),
    )
