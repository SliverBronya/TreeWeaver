from treeweaver.fusion.robust import fuse_scalar_observations

__all__ = ["fuse_scalar_observations"]
