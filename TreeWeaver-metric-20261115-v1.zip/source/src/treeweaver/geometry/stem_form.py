"""Interpretable 3-D stem-profile detection for complex diameter cases."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

import numpy as np
import numpy.typing as npt
from scipy.spatial import cKDTree

from treeweaver.forestry.diameter_position import StemFormEvidence

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class StemProfileBin:
    height_m: float
    radius_m: float
    eccentricity: float
    component_count: int
    point_count: int


@dataclass(frozen=True, slots=True)
class StemFormDetection:
    evidence: StemFormEvidence
    profile: tuple[StemProfileBin, ...]
    confidence: float
    diagnostics: tuple[str, ...]


def _basis(axis: FloatArray) -> tuple[FloatArray, FloatArray]:
    helper = np.array([1.0, 0.0, 0.0])
    if abs(float(helper @ axis)) > 0.9:
        helper = np.array([0.0, 1.0, 0.0])
    first = np.cross(axis, helper)
    first /= np.linalg.norm(first)
    return cast(FloatArray, first), cast(FloatArray, np.cross(axis, first))


def _components(points: FloatArray, radius: float) -> int:
    if len(points) < 8:
        return 0
    link_distance = max(0.025, min(0.12, radius * 0.45))
    pairs = cKDTree(points).query_pairs(link_distance)
    parent = list(range(len(points)))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    for left, right in pairs:
        root_left, root_right = find(left), find(right)
        if root_left != root_right:
            parent[root_right] = root_left
    counts: dict[int, int] = {}
    for index in range(len(points)):
        root = find(index)
        counts[root] = counts.get(root, 0) + 1
    minimum = max(6, round(len(points) * 0.15))
    return sum(count >= minimum for count in counts.values())


def _profile(
    points: FloatArray,
    root: FloatArray,
    axis: FloatArray,
    *,
    bin_step_m: float,
    half_width_m: float,
    maximum_height_m: float,
) -> tuple[StemProfileBin, ...]:
    relative = points - root
    axial = relative @ axis
    first, second = _basis(axis)
    radial_2d = np.column_stack((relative @ first, relative @ second))
    centres = np.arange(bin_step_m / 2, maximum_height_m + 1e-9, bin_step_m)
    bins: list[StemProfileBin] = []
    for height in centres:
        selected = np.abs(axial - height) <= half_width_m
        section = radial_2d[selected]
        if len(section) < 12:
            continue
        centre = np.median(section, axis=0)
        centred = section - centre
        radii = np.linalg.norm(centred, axis=1)
        radius = float(np.median(radii))
        _, singular, _ = np.linalg.svd(centred, full_matrices=False)
        eccentricity = float(singular[0] / max(singular[1], 1e-9))
        bins.append(
            StemProfileBin(
                float(height),
                radius,
                eccentricity,
                _components(section, radius),
                len(section),
            )
        )
    return tuple(bins)


def _persistent_fork(profile: tuple[StemProfileBin, ...]) -> tuple[float | None, int]:
    for index in range(len(profile) - 2):
        window = profile[index : index + 3]
        if all(item.component_count >= 2 for item in window):
            return window[0].height_m, min(item.component_count for item in window)
    return None, 1


def infer_stem_form(
    trunk_points_m: npt.ArrayLike,
    *,
    root_m: npt.ArrayLike,
    axis: npt.ArrayLike,
    bin_step_m: float = 0.1,
    half_width_m: float = 0.055,
    maximum_height_m: float = 2.5,
) -> StemFormDetection:
    """Infer special stem-form evidence from metric trunk points.

    This detector is deliberately interpretable and fail-conservative. It only
    emits a fork after three consecutive multi-component sections.
    """

    points = np.asarray(trunk_points_m, dtype=np.float64)
    root = np.asarray(root_m, dtype=np.float64)
    direction = np.asarray(axis, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < 60:
        raise ValueError("stem-form detection requires at least 60 three-dimensional points")
    if not np.isfinite(points).all() or root.shape != (3,) or direction.shape != (3,):
        raise ValueError("stem-form inputs must be finite and three-dimensional")
    norm = float(np.linalg.norm(direction))
    if norm <= 1e-9 or bin_step_m <= 0 or half_width_m <= 0 or maximum_height_m <= 0:
        raise ValueError("stem-form axis and profile parameters must be positive")
    direction /= norm
    profile = _profile(
        points,
        root,
        direction,
        bin_step_m=bin_step_m,
        half_width_m=half_width_m,
        maximum_height_m=maximum_height_m,
    )
    if len(profile) < 10:
        raise ValueError("too few populated stem sections for form detection")

    fork_origin, stem_count = _persistent_fork(profile)
    diagnostics: list[str] = []
    if fork_origin is not None:
        diagnostics.append(
            f"persistent {stem_count}-component stem begins near {fork_origin:.2f} m"
        )

    reference = [
        item.radius_m
        for item in profile
        if 1.5 <= item.height_m <= 2.2 and item.component_count == 1
    ]
    if not reference:
        reference = [
            item.radius_m
            for item in profile
            if 1.0 <= item.height_m <= 2.2 and item.component_count == 1
        ]
    stable_radius = float(np.median(reference)) if reference else float("nan")
    buttress_top = None
    if np.isfinite(stable_radius) and fork_origin is None:
        base_bins = [item for item in profile if item.height_m <= 1.5]
        enlarged = [
            item
            for item in base_bins
            if item.radius_m > stable_radius * 1.12 or item.eccentricity > 1.65
        ]
        if enlarged and enlarged[0].height_m <= 0.2:
            last_enlarged = max(item.height_m for item in enlarged)
            if last_enlarged > 0.9:
                buttress_top = last_enlarged
                diagnostics.append(f"basal enlargement persists to {buttress_top:.2f} m")

    irregularity = None
    target_bins = [item for item in profile if 1.0 <= item.height_m <= 1.6]
    if np.isfinite(stable_radius) and buttress_top is None and fork_origin is None:
        anomalous = [
            item
            for item in target_bins
            if item.radius_m > stable_radius * 1.22
            or item.radius_m < stable_radius * 0.78
            or item.eccentricity > 1.65
        ]
        if anomalous and any(abs(item.height_m - 1.3) <= 0.12 for item in anomalous):
            irregularity = (
                min(item.height_m for item in anomalous) - half_width_m,
                max(item.height_m for item in anomalous) + half_width_m,
            )
            diagnostics.append(
                f"breast-height anomaly spans {irregularity[0]:.2f}-{irregularity[1]:.2f} m"
            )

    evidence = StemFormEvidence(
        fork_origin_m=fork_origin,
        stem_count_above_fork=stem_count,
        buttress_top_m=buttress_top,
        irregularity_interval_m=irregularity,
    )
    populated_fraction = min(1.0, len(profile) / max(10.0, maximum_height_m / bin_step_m))
    point_factor = min(1.0, sum(item.point_count for item in profile) / 1000)
    confidence = float(0.5 * populated_fraction + 0.5 * point_factor)
    return StemFormDetection(evidence, profile, confidence, tuple(diagnostics))
