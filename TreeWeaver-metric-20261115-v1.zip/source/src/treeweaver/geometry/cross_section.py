"""Robust circular/elliptical trunk cross-section estimation."""

from __future__ import annotations

from dataclasses import dataclass
from math import pi, sqrt
from typing import cast

import numpy as np
import numpy.typing as npt
from scipy.optimize import least_squares

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class CrossSectionEstimate:
    centre: FloatArray
    major_radius: float
    minor_radius: float
    orientation_rad: float
    circumference_equivalent_diameter: float
    residual_standard_deviation: float
    angular_coverage_deg: float
    model: str

    @property
    def eccentricity_ratio(self) -> float:
        return self.major_radius / self.minor_radius


def _coverage(points: FloatArray, centre: FloatArray) -> float:
    angles = np.mod(np.arctan2(points[:, 1] - centre[1], points[:, 0] - centre[0]), 2 * pi)
    ordered = np.sort(angles)
    gaps = np.diff(np.r_[ordered, ordered[0] + 2 * pi])
    return float(360 - np.max(gaps) * 180 / pi)


def _circle(points: FloatArray) -> CrossSectionEstimate:
    weights: FloatArray = np.ones(len(points), dtype=np.float64)
    centre = np.zeros(2, dtype=np.float64)
    radius = 0.0
    for _ in range(8):
        x, y = points[:, 0], points[:, 1]
        design = np.column_stack((2 * x, 2 * y, np.ones(len(points))))
        target = x * x + y * y
        root_weight = np.sqrt(weights)
        solution, *_ = np.linalg.lstsq(
            design * root_weight[:, None], target * root_weight, rcond=None
        )
        centre = solution[:2]
        radius = float(np.sqrt(max(solution[2] + centre @ centre, 0.0)))
        residuals = np.abs(np.linalg.norm(points - centre, axis=1) - radius)
        scale = max(float(1.4826 * np.median(np.abs(residuals - np.median(residuals)))), 1e-5)
        delta = 1.5 * scale
        weights = cast(
            FloatArray,
            np.where(residuals <= delta, 1.0, delta / np.maximum(residuals, 1e-12)),
        )
    radial_residual = np.linalg.norm(points - centre, axis=1) - radius
    residual_sd = float(np.std(radial_residual, ddof=1))
    return CrossSectionEstimate(
        centre,
        radius,
        radius,
        0.0,
        2 * radius,
        residual_sd,
        _coverage(points, centre),
        "circle",
    )


def fit_trunk_cross_section(
    points_2d: npt.ArrayLike,
    *,
    minimum_ellipse_coverage_deg: float = 150.0,
    maximum_eccentricity_ratio: float = 2.5,
) -> CrossSectionEstimate:
    """Fit an ellipse when observable; otherwise return a robust circle."""

    points = np.asarray(points_2d, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or len(points) < 16:
        raise ValueError("cross-section fitting requires at least 16 finite 2-D points")
    if not np.isfinite(points).all():
        raise ValueError("cross-section contains non-finite points")
    circle = _circle(points)
    if circle.angular_coverage_deg < minimum_ellipse_coverage_deg:
        return circle

    centre0 = np.median(points, axis=0)
    _, _, vh = np.linalg.svd(points - centre0, full_matrices=False)
    rotated = (points - centre0) @ vh.T
    spans = np.quantile(rotated, 0.99, axis=0) - np.quantile(rotated, 0.01, axis=0)
    order = np.argsort(spans)[::-1]
    major0 = max(float(spans[order[0]] / 2), 1e-4)
    minor0 = max(float(spans[order[1]] / 2), 1e-4)
    major_axis = vh[order[0]]
    angle0 = float(np.arctan2(major_axis[1], major_axis[0]))
    initial = np.array([centre0[0], centre0[1], np.log(major0), np.log(minor0), angle0])

    def residual(parameters: FloatArray) -> FloatArray:
        centre = parameters[:2]
        major, minor = np.exp(parameters[2:4])
        angle = parameters[4]
        cosine, sine = np.cos(angle), np.sin(angle)
        relative = points - centre
        x = relative[:, 0] * cosine + relative[:, 1] * sine
        y = -relative[:, 0] * sine + relative[:, 1] * cosine
        normalized_radius = np.sqrt((x / major) ** 2 + (y / minor) ** 2)
        return cast(FloatArray, (normalized_radius - 1.0) * sqrt(major * minor))

    optimized = least_squares(residual, initial, loss="soft_l1", f_scale=0.01, max_nfev=200)
    radii = np.exp(optimized.x[2:4])
    major, minor = float(max(radii)), float(min(radii))
    if not optimized.success or major / minor > maximum_eccentricity_ratio:
        return circle
    h = ((major - minor) / (major + minor)) ** 2
    perimeter = pi * (major + minor) * (1 + 3 * h / (10 + sqrt(4 - 3 * h)))
    residual_sd = float(np.std(residual(optimized.x), ddof=1))
    return CrossSectionEstimate(
        optimized.x[:2].astype(np.float64, copy=False),
        major,
        minor,
        float(optimized.x[4]),
        perimeter / pi,
        residual_sd,
        _coverage(points, optimized.x[:2]),
        "ellipse",
    )
