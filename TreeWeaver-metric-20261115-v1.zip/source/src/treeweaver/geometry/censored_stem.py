"""Conditional bounds on projected stem width from censored row observations.

This is a research primitive, not an RGB-to-DBH estimator. Edge visibility,
target ownership, and the image row of interest are upstream evidence. Bounds
are conditional on those labels, a locally straight projected stem, and the
declared pixel tolerance; they are NOT calibrated confidence intervals.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from math import isfinite

import numpy as np
from scipy.optimize import linprog


@dataclass(frozen=True, slots=True)
class StemRowEvidence:
    y_px: float
    left_visible_px: float
    right_visible_px: float
    left_is_exposed_edge: bool
    right_is_exposed_edge: bool

    def __post_init__(self) -> None:
        if not all(isfinite(x) for x in (self.y_px, self.left_visible_px, self.right_visible_px)):
            raise ValueError("row coordinates must be finite")
        if self.left_visible_px >= self.right_visible_px:
            raise ValueError("visible interval must have positive width")


class WidthBoundStatus(StrEnum):
    BOUNDED = "bounded"
    UNBOUNDED = "unbounded"
    INCONSISTENT = "inconsistent"
    OUTSIDE_SUPPORT = "outside_support"


@dataclass(frozen=True, slots=True)
class CensoredWidthBounds:
    status: WidthBoundStatus
    query_y_px: float
    minimum_width_px: float | None
    maximum_width_px: float | None
    observation_count: int
    exposed_edge_count: int
    pixel_tolerance: float
    explanation: str


def bound_projected_stem_width(
    rows: tuple[StemRowEvidence, ...],
    query_y_px: float,
    *,
    pixel_tolerance: float = 1.0,
) -> CensoredWidthBounds:
    """Minimize/maximize width over all local line pairs consistent with evidence.

    For visible pixels [a,b], L(y) <= a and R(y) >= b. Only an independently
    exposed silhouette edge adds the reverse inequality. Missing pixels do
    not assert absence of wood. No diameter prior caps an unobserved edge.
    Extrapolation outside the observed vertical span is explicitly refused.
    """

    if not rows or not isfinite(query_y_px):
        raise ValueError("nonempty row observations and finite query row are required")
    if not isfinite(pixel_tolerance) or pixel_tolerance < 0:
        raise ValueError("pixel tolerance must be finite and nonnegative")
    exposed = sum(int(row.left_is_exposed_edge) + int(row.right_is_exposed_edge) for row in rows)
    low_y = min(row.y_px for row in rows)
    high_y = max(row.y_px for row in rows)

    def result(
        status: WidthBoundStatus,
        lower: float | None,
        upper: float | None,
        explanation: str,
    ) -> CensoredWidthBounds:
        return CensoredWidthBounds(
            status, query_y_px, lower, upper, len(rows), exposed, pixel_tolerance, explanation
        )

    if not low_y <= query_y_px <= high_y:
        return result(
            WidthBoundStatus.OUTSIDE_SUPPORT,
            None,
            None,
            "query is outside visible vertical support; no hidden-root extrapolation",
        )
    span = max(1.0, high_y - low_y)
    # theta = [left_at_query, left_slope, right_at_query, right_slope].
    constraints: list[list[float]] = []
    upper_bounds: list[float] = []
    for row in rows:
        t = (row.y_px - query_y_px) / span
        constraints.extend([[1.0, t, 0.0, 0.0], [0.0, 0.0, -1.0, -t]])
        upper_bounds.extend(
            [
                row.left_visible_px + pixel_tolerance,
                -row.right_visible_px + pixel_tolerance,
            ]
        )
        if row.left_is_exposed_edge:
            constraints.append([-1.0, -t, 0.0, 0.0])
            upper_bounds.append(-row.left_visible_px + pixel_tolerance)
        if row.right_is_exposed_edge:
            constraints.append([0.0, 0.0, 1.0, t])
            upper_bounds.append(row.right_visible_px + pixel_tolerance)
    # A linear width is nonnegative throughout the span if it is at both ends.
    for y in (low_y, high_y):
        t = (y - query_y_px) / span
        constraints.append([1.0, t, -1.0, -t])
        upper_bounds.append(0.0)
    matrix = np.asarray(constraints, dtype=np.float64)
    limits = np.asarray(upper_bounds, dtype=np.float64)
    objective = np.asarray([-1.0, 0.0, 1.0, 0.0])
    lower = linprog(objective, A_ub=matrix, b_ub=limits, bounds=[(None, None)] * 4, method="highs")
    if lower.status == 2:
        return result(
            WidthBoundStatus.INCONSISTENT,
            None,
            None,
            "no local straight stem fits the evidence within the declared tolerance",
        )
    if not lower.success:
        raise RuntimeError(f"width lower-bound solver failed: {lower.message}")
    upper = linprog(-objective, A_ub=matrix, b_ub=limits, bounds=[(None, None)] * 4, method="highs")
    minimum = max(0.0, float(lower.fun))
    if upper.status == 3:
        return result(
            WidthBoundStatus.UNBOUNDED,
            minimum,
            None,
            "visible evidence supplies a lower bound but no finite maximum width",
        )
    if not upper.success:
        raise RuntimeError(f"width upper-bound solver failed: {upper.message}")
    return result(
        WidthBoundStatus.BOUNDED,
        minimum,
        max(minimum, -float(upper.fun)),
        "feasible projected-width interval conditional on edge labels, linear model and tolerance",
    )
