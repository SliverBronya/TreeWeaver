"""File boundary for reproducible geometry experiments."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from treeweaver.domain.models import ParameterEstimate
from treeweaver.geometry.tree import measure_tree_geometry


def _estimate_json(estimate: ParameterEstimate) -> dict[str, object]:
    return {
        "parameter": estimate.parameter.value,
        "value": estimate.value,
        "standard_deviation": estimate.standard_deviation,
        "confidence": estimate.confidence,
        "observation_count": estimate.observation_count,
        "diagnostics": list(estimate.diagnostics),
    }


def measure_semantic_point_file(input_path: str | Path, output_path: str | Path) -> Path:
    """Measure a versioned NPZ containing metric trunk/crown/ground arrays."""
    source = Path(input_path).resolve()
    with np.load(source, allow_pickle=False) as data:
        required = {"trunk", "crown", "ground"}
        missing = required - set(data.files)
        if missing:
            raise ValueError(f"semantic point file is missing arrays: {sorted(missing)}")
        result = measure_tree_geometry(data["trunk"], data["crown"], data["ground"])

    payload = {
        "schema_version": "geometry-result-1.0",
        "source": str(source),
        "estimates": {
            "height": _estimate_json(result.height),
            "dbh": _estimate_json(result.dbh),
            "crown_width": _estimate_json(result.crown_width),
            "crown_depth": _estimate_json(result.crown_depth),
        },
        "geometry": {
            "ground_normal": result.ground_normal.tolist(),
            "trunk_axis": result.trunk_axis.tolist(),
            "root_world": result.root_world.tolist(),
            "cross_section_coverage_deg": result.cross_section_coverage_deg,
        },
    }
    destination = Path(output_path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(destination)
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return destination
