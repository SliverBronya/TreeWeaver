"""World-coordinate tree geometry baseline with explicit uncertainty."""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, pi
from typing import cast

import numpy as np
import numpy.typing as npt

from treeweaver.domain.models import Parameter, ParameterEstimate
from treeweaver.forestry.diameter_position import (
    DiameterCase,
    StemFormEvidence,
    plan_diameter_measurement,
)
from treeweaver.geometry.cross_section import fit_trunk_cross_section
from treeweaver.geometry.stem_form import infer_stem_form

Array = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class TreeGeometryEstimate:
    height: ParameterEstimate
    dbh: ParameterEstimate
    crown_width: ParameterEstimate
    crown_depth: ParameterEstimate
    crown_height: ParameterEstimate
    crown_volume: ParameterEstimate
    ground_normal: Array
    trunk_axis: Array
    root_world: Array
    cross_section_coverage_deg: float
    cross_section_model: str
    cross_section_eccentricity_ratio: float
    diameter_measurement_height_m: float
    diameter_case: DiameterCase
    diameter_rule: str
    stem_form_confidence: float | None
    stem_form_diagnostics: tuple[str, ...]


def _points(value: npt.ArrayLike, name: str, minimum: int) -> Array:
    result = np.asarray(value, dtype=np.float64)
    if result.ndim != 2 or result.shape[1] != 3 or len(result) < minimum:
        raise ValueError(f"{name} must contain at least {minimum} finite 3-D points")
    if not np.isfinite(result).all():
        raise ValueError(f"{name} contains non-finite coordinates")
    return result


def _fit_ground(ground: Array, orientation_reference: Array) -> tuple[Array, Array, float]:
    centre = np.median(ground, axis=0)
    _, _, vh = np.linalg.svd(ground - centre, full_matrices=False)
    normal = vh[-1]
    if float(normal @ orientation_reference) < 0:
        normal = -normal
    distances = (ground - centre) @ normal
    residual = float(1.4826 * np.median(np.abs(distances - np.median(distances))))
    return cast(Array, centre), cast(Array, normal / np.linalg.norm(normal)), residual


def _fit_axis(trunk: Array, up: Array) -> Array:
    centre = np.median(trunk, axis=0)
    _, _, vh = np.linalg.svd(trunk - centre, full_matrices=False)
    axis = vh[0]
    if float(axis @ up) < 0:
        axis = -axis
    if float(axis @ up) < 0.65:
        raise ValueError("estimated trunk axis is implausibly horizontal")
    return cast(Array, axis / np.linalg.norm(axis))


def _plane_basis(normal: Array) -> tuple[Array, Array]:
    helper = np.array([1.0, 0.0, 0.0])
    if abs(float(helper @ normal)) > 0.9:
        helper = np.array([0.0, 1.0, 0.0])
    first = np.cross(normal, helper)
    first /= np.linalg.norm(first)
    second = np.cross(normal, first)
    return cast(Array, first), cast(Array, second)


def _fit_circle(points_2d: Array) -> tuple[Array, float, float, float]:
    weights: Array = np.ones(len(points_2d), dtype=np.float64)
    centre: Array = np.zeros(2, dtype=np.float64)
    radius = 0.0
    for _ in range(8):
        x, y = points_2d[:, 0], points_2d[:, 1]
        design = np.column_stack((2 * x, 2 * y, np.ones(len(points_2d))))
        target = x * x + y * y
        root_w = np.sqrt(weights)
        solution, *_ = np.linalg.lstsq(design * root_w[:, None], target * root_w, rcond=None)
        centre = solution[:2]
        radius = float(np.sqrt(max(solution[2] + centre @ centre, 0.0)))
        residuals = np.abs(np.linalg.norm(points_2d - centre, axis=1) - radius)
        scale = max(float(1.4826 * np.median(np.abs(residuals - np.median(residuals)))), 1e-5)
        delta = 1.5 * scale
        weights = cast(
            Array,
            np.where(residuals <= delta, 1.0, delta / np.maximum(residuals, 1e-12)),
        )
    angles = np.mod(np.arctan2(points_2d[:, 1] - centre[1], points_2d[:, 0] - centre[0]), 2 * pi)
    ordered = np.sort(angles)
    gaps = np.diff(np.r_[ordered, ordered[0] + 2 * pi])
    coverage = float(360 - np.max(gaps) * 180 / pi)
    radial = np.linalg.norm(points_2d - centre, axis=1)
    residual_sd = float(np.std(radial - radius, ddof=1)) if len(radial) > 1 else 0.0
    return centre, radius, residual_sd, coverage


def _estimate(
    parameter: Parameter,
    value: float,
    sd: float,
    count: int,
    diagnostics: tuple[str, ...] = (),
) -> ParameterEstimate:
    relative = sd / max(abs(value), 1e-9)
    confidence = (1 - exp(-count / 30)) * exp(-4 * relative)
    return ParameterEstimate(
        parameter, float(value), float(sd), float(confidence), count, tuple(diagnostics)
    )


def measure_tree_geometry(
    trunk_points: npt.ArrayLike,
    crown_points: npt.ArrayLike,
    ground_points: npt.ArrayLike,
    *,
    up_hint: npt.ArrayLike | None = None,
    breast_height_m: float = 1.3,
    dbh_slab_half_width_m: float = 0.06,
    stem_form_evidence: StemFormEvidence | None = None,
    automatic_stem_form: bool = False,
) -> TreeGeometryEstimate:
    """Measure one semantically separated tree in a metric 3-D coordinate system."""
    trunk = _points(trunk_points, "trunk_points", 30)
    crown = _points(crown_points, "crown_points", 30)
    ground = _points(ground_points, "ground_points", 12)
    if up_hint is None:
        ground_centre_initial = np.median(ground, axis=0)
        orientation_reference = np.median(np.vstack((trunk, crown)), axis=0) - ground_centre_initial
    else:
        orientation_reference = np.asarray(up_hint, dtype=np.float64)
    if np.linalg.norm(orientation_reference) <= 1e-9:
        raise ValueError("ground orientation reference cannot be zero")
    orientation_reference /= np.linalg.norm(orientation_reference)
    ground_centre, ground_normal, ground_sd = _fit_ground(ground, orientation_reference)
    axis = _fit_axis(trunk, ground_normal)

    trunk_ground_height = (trunk - ground_centre) @ ground_normal
    root_candidates = trunk[trunk_ground_height <= np.quantile(trunk_ground_height, 0.05)]
    root = np.median(root_candidates, axis=0)
    root -= ground_normal * float((root - ground_centre) @ ground_normal)
    form_confidence = None
    form_diagnostics: tuple[str, ...] = ()
    if stem_form_evidence is None and automatic_stem_form:
        detection = infer_stem_form(trunk, root_m=root, axis=axis)
        if detection.confidence < 0.65:
            raise ValueError("stem-form evidence confidence is below the automatic threshold")
        stem_form_evidence = detection.evidence
        form_confidence = detection.confidence
        form_diagnostics = detection.diagnostics
    diameter_plan = plan_diameter_measurement(
        stem_form_evidence or StemFormEvidence(), breast_height_m=breast_height_m
    )
    if diameter_plan.entity_count != 1:
        raise ValueError(
            "forked tree must be split into separate stem entities before diameter fitting"
        )
    diameter_height_m = diameter_plan.planes[0].height_along_stem_m

    all_tree = np.vstack((trunk, crown))
    vertical = (all_tree - root) @ ground_normal
    median_h = float(np.median(vertical))
    mad_h = max(float(1.4826 * np.median(np.abs(vertical - median_h))), 1e-6)
    plausible = vertical[(vertical >= -0.15) & (vertical <= median_h + 8 * mad_h)]
    if len(plausible) < 30:
        raise ValueError("too few height inliers")
    height_m = float(np.quantile(plausible, 0.995))
    top_band = plausible[plausible >= np.quantile(plausible, 0.98)]
    height_sd = max(float(np.std(top_band, ddof=1) / np.sqrt(len(top_band))), ground_sd)

    axial = (trunk - root) @ axis
    section = trunk[np.abs(axial - diameter_height_m) <= dbh_slab_half_width_m]
    if len(section) < 16:
        raise ValueError("insufficient trunk surface at breast height")
    first, second = _plane_basis(axis)
    relative = section - (root + diameter_height_m * axis)
    section_2d = np.column_stack((relative @ first, relative @ second))
    cross_section = fit_trunk_cross_section(section_2d)
    coverage = cross_section.angular_coverage_deg
    dbh_cm = cross_section.circumference_equivalent_diameter * 100
    coverage_penalty = max(1.0, 180.0 / max(coverage, 1.0))
    dbh_sd_cm = max(
        0.1,
        200
        * cross_section.residual_standard_deviation
        / np.sqrt(len(section))
        * coverage_penalty,
    )

    crown_horizontal = crown - np.outer((crown - root) @ ground_normal, ground_normal)
    crown_centre = np.median(crown_horizontal, axis=0)
    _, _, vh = np.linalg.svd(crown_horizontal - crown_centre, full_matrices=False)
    major, minor = vh[0], vh[1]
    major_values = (crown_horizontal - crown_centre) @ major
    minor_values = (crown_horizontal - crown_centre) @ minor
    major_span = float(np.quantile(major_values, 0.995) - np.quantile(major_values, 0.005))
    minor_span = float(np.quantile(minor_values, 0.995) - np.quantile(minor_values, 0.005))
    crown_vertical = (crown - root) @ ground_normal
    crown_height = float(
        np.quantile(crown_vertical, 0.995) - np.quantile(crown_vertical, 0.005)
    )
    crown_sd = max(
        ground_sd, 0.5 * (np.std(major_values) + np.std(minor_values)) / np.sqrt(len(crown))
    )
    crown_height_sd = max(ground_sd, float(np.std(crown_vertical)) / np.sqrt(len(crown)))
    crown_volume = pi / 6 * major_span * minor_span * crown_height
    relative_volume_sd = np.sqrt(
        (crown_sd / max(major_span, 1e-9)) ** 2
        + (crown_sd / max(minor_span, 1e-9)) ** 2
        + (crown_height_sd / max(crown_height, 1e-9)) ** 2
    )

    dbh_diagnostics: tuple[str, ...] = ()
    if coverage < 180:
        dbh_diagnostics += (f"only {coverage:.1f} degrees of trunk surface observed",)
    dbh_diagnostics += (f"{cross_section.model} circumference-equivalent cross-section",)
    dbh_diagnostics += (
        f"diameter plane {diameter_height_m:.3f} m along stem",
        diameter_plan.rule,
    )
    return TreeGeometryEstimate(
        height=_estimate(Parameter.HEIGHT_M, height_m, height_sd, len(plausible)),
        dbh=_estimate(Parameter.DBH_CM, dbh_cm, dbh_sd_cm, len(section), dbh_diagnostics),
        crown_width=_estimate(Parameter.CROWN_WIDTH_M, major_span, crown_sd, len(crown)),
        crown_depth=_estimate(Parameter.CROWN_DEPTH_M, minor_span, crown_sd, len(crown)),
        crown_height=_estimate(
            Parameter.CROWN_HEIGHT_M, crown_height, crown_height_sd, len(crown)
        ),
        crown_volume=_estimate(
            Parameter.CROWN_VOLUME_M3,
            crown_volume,
            crown_volume * float(relative_volume_sd),
            len(crown),
            ("ellipsoidal crown-envelope approximation",),
        ),
        ground_normal=ground_normal,
        trunk_axis=axis,
        root_world=root,
        cross_section_coverage_deg=coverage,
        cross_section_model=cross_section.model,
        cross_section_eccentricity_ratio=cross_section.eccentricity_ratio,
        diameter_measurement_height_m=diameter_height_m,
        diameter_case=diameter_plan.case,
        diameter_rule=diameter_plan.rule,
        stem_form_confidence=form_confidence,
        stem_form_diagnostics=form_diagnostics,
    )
