"""Covariance-aware next-best-view selection for active tree capture."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class CandidateView:
    view_id: str
    azimuth_deg: float
    elevation_deg: float
    measurement_jacobian: FloatArray
    measurement_noise: FloatArray
    visibility_probability: float

    def __post_init__(self) -> None:
        if not self.view_id or self.measurement_jacobian.ndim != 2:
            raise ValueError("candidate view requires an id and a 2-D Jacobian")
        rows = self.measurement_jacobian.shape[0]
        if self.measurement_noise.shape != (rows, rows):
            raise ValueError("measurement noise must match Jacobian rows")
        if not 0 <= self.visibility_probability <= 1:
            raise ValueError("visibility probability must be in [0, 1]")
        if np.any(np.linalg.eigvalsh(self.measurement_noise) <= 0):
            raise ValueError("measurement noise must be positive definite")


@dataclass(frozen=True, slots=True)
class ViewSelection:
    view: CandidateView
    expected_weighted_variance_reduction: float
    posterior_covariance_if_visible: FloatArray


def select_next_best_view(
    covariance: npt.ArrayLike,
    candidates: tuple[CandidateView, ...],
    *,
    parameter_weights: npt.ArrayLike | None = None,
) -> ViewSelection:
    """Rank views by visibility-discounted posterior trace reduction."""

    prior = np.asarray(covariance, dtype=np.float64)
    if prior.ndim != 2 or prior.shape[0] != prior.shape[1]:
        raise ValueError("state covariance must be square")
    if not np.allclose(prior, prior.T, atol=1e-10) or np.any(np.linalg.eigvalsh(prior) < -1e-10):
        raise ValueError("state covariance must be symmetric positive semidefinite")
    if not candidates:
        raise ValueError("at least one candidate view is required")
    weights = (
        np.ones(prior.shape[0], dtype=np.float64)
        if parameter_weights is None
        else np.asarray(parameter_weights, dtype=np.float64)
    )
    if weights.shape != (prior.shape[0],) or np.any(weights < 0) or not np.any(weights > 0):
        raise ValueError("parameter weights must be a non-negative state vector")

    best: ViewSelection | None = None
    for candidate in candidates:
        jacobian = np.asarray(candidate.measurement_jacobian, dtype=np.float64)
        if jacobian.shape[1] != prior.shape[0]:
            raise ValueError(f"candidate {candidate.view_id} has incompatible state dimension")
        innovation = jacobian @ prior @ jacobian.T + candidate.measurement_noise
        gain = prior @ jacobian.T @ np.linalg.pinv(innovation)
        posterior = prior - gain @ jacobian @ prior
        posterior = (posterior + posterior.T) / 2
        reduction = float(np.sum(weights * (np.diag(prior) - np.diag(posterior))))
        expected = candidate.visibility_probability * max(0.0, reduction)
        selection = ViewSelection(candidate, expected, posterior)
        if best is None or expected > best.expected_weighted_variance_reduction:
            best = selection
    if best is None:  # pragma: no cover - candidates are non-empty
        raise AssertionError("view selection failed")
    return best
