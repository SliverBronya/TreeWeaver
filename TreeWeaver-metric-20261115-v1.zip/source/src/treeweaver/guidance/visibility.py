"""Parameter-specific visibility evidence for fail-closed tree measurement."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class AngularSector:
    start_deg: float
    end_deg: float
    width_deg: float


@dataclass(frozen=True, slots=True)
class VisibilityAssessment:
    dbh_angular_coverage_deg: float
    dbh_point_count: int
    missing_dbh_sectors: tuple[AngularSector, ...]
    root_visible: bool
    apex_visible: bool
    crown_height_coverage: float
    dbh_measurement_allowed: bool
    height_measurement_allowed: bool
    reasons: tuple[str, ...]


def _horizontal_basis(up: FloatArray) -> tuple[FloatArray, FloatArray]:
    helper = np.array([1.0, 0.0, 0.0])
    if abs(float(helper @ up)) > 0.9:
        helper = np.array([0.0, 1.0, 0.0])
    first = np.cross(up, helper)
    first /= np.linalg.norm(first)
    return cast(FloatArray, first), cast(FloatArray, np.cross(up, first))


def _missing_sectors(
    occupied: npt.NDArray[np.bool_], bin_width: float
) -> tuple[AngularSector, ...]:
    count = len(occupied)
    if occupied.all():
        return ()
    if not occupied.any():
        return (AngularSector(0.0, 360.0, 360.0),)
    doubled = np.concatenate((occupied, occupied))
    start = int(np.flatnonzero(occupied)[0])
    sectors: list[AngularSector] = []
    index = start + 1
    stop = start + count + 1
    while index < stop:
        if doubled[index]:
            index += 1
            continue
        run_start = index
        while index < stop and not doubled[index]:
            index += 1
        width_bins = index - run_start
        sector_start = (run_start % count) * bin_width
        width = width_bins * bin_width
        sectors.append(AngularSector(sector_start, (sector_start + width) % 360, width))
    return tuple(sorted(sectors, key=lambda item: item.width_deg, reverse=True))


def assess_tree_visibility(
    observed_points: npt.ArrayLike,
    *,
    root_position: npt.ArrayLike,
    up: npt.ArrayLike = (0.0, 0.0, 1.0),
    breast_height_m: float = 1.3,
    dbh_band_half_width_m: float = 0.12,
    angular_bin_deg: float = 15.0,
    minimum_dbh_coverage_deg: float = 210.0,
    root_band_m: float = 0.18,
    apex_fraction: float = 0.06,
) -> VisibilityAssessment:
    """Summarize which measurement-critical surfaces are actually observed."""

    points = np.asarray(observed_points, dtype=np.float64)
    root = np.asarray(root_position, dtype=np.float64)
    up_vector = np.asarray(up, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("observed_points must be a finite N x 3 array")
    if len(points) < 3 or root.shape != (3,) or up_vector.shape != (3,):
        raise ValueError("visibility requires points plus three-vector root and up")
    if 360 % angular_bin_deg != 0:
        raise ValueError("angular_bin_deg must divide 360 exactly")
    norm = float(np.linalg.norm(up_vector))
    if norm <= 1e-9:
        raise ValueError("up cannot be zero")
    up_vector /= norm
    relative = points - root
    height = relative @ up_vector
    tree_height = float(np.max(height))
    if tree_height <= 0:
        raise ValueError("observed tree must extend above its root")
    first, second = _horizontal_basis(up_vector)
    angle = np.mod(np.degrees(np.arctan2(relative @ second, relative @ first)), 360.0)

    dbh = np.abs(height - breast_height_m) <= dbh_band_half_width_m
    bin_count = int(round(360 / angular_bin_deg))
    occupied = np.zeros(bin_count, dtype=np.bool_)
    angle_bins = np.floor(angle[dbh] / angular_bin_deg).astype(np.int64) % bin_count
    occupied[angle_bins] = True
    coverage = float(np.count_nonzero(occupied) * angular_bin_deg)
    missing = _missing_sectors(occupied, angular_bin_deg)
    root_visible = bool(np.any((height >= -root_band_m) & (height <= root_band_m)))
    apex_visible = bool(np.any(height >= tree_height * (1 - apex_fraction)))

    height_bins = np.linspace(0.0, tree_height, 11)
    occupied_height, _ = np.histogram(height[(height >= 0) & (height <= tree_height)], height_bins)
    crown_height_coverage = float(np.count_nonzero(occupied_height) / len(occupied_height))
    dbh_allowed = bool(
        root_visible
        and np.count_nonzero(dbh) >= 12
        and coverage >= minimum_dbh_coverage_deg
    )
    height_allowed = bool(root_visible and apex_visible and crown_height_coverage >= 0.8)
    reasons: list[str] = []
    if not root_visible:
        reasons.append("树根区域不可见，无法确定高度和胸高起点")
    if np.count_nonzero(dbh) < 12:
        reasons.append("胸高截面的有效三维点不足")
    elif coverage < minimum_dbh_coverage_deg:
        reasons.append("胸高截面观察角度不足，遮挡侧仍未观测")
    if not apex_visible or crown_height_coverage < 0.8:
        reasons.append("树梢或树体垂直区段证据不完整")
    return VisibilityAssessment(
        dbh_angular_coverage_deg=coverage,
        dbh_point_count=int(np.count_nonzero(dbh)),
        missing_dbh_sectors=missing,
        root_visible=root_visible,
        apex_visible=apex_visible,
        crown_height_coverage=crown_height_coverage,
        dbh_measurement_allowed=dbh_allowed,
        height_measurement_allowed=height_allowed,
        reasons=tuple(reasons),
    )
