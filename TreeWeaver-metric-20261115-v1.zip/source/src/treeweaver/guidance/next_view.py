"""Parameter-aware active capture guidance."""

from __future__ import annotations

from dataclasses import dataclass

from treeweaver.domain.models import FrameObservation, Parameter, ParameterEstimate
from treeweaver.guidance.visibility import VisibilityAssessment


@dataclass(frozen=True, slots=True)
class CaptureGuidance:
    required: bool
    target_parameter: Parameter | None
    azimuth_deg: float | None
    instruction: str | None
    reason: str | None
    selection_method: str = "coverage_heuristic"
    expected_variance_reduction: float | None = None


_RELATIVE_SD_LIMITS = {
    Parameter.HEIGHT_M: 0.08,
    Parameter.DBH_CM: 0.10,
    Parameter.CROWN_WIDTH_M: 0.12,
    Parameter.CROWN_DEPTH_M: 0.15,
    Parameter.CROWN_HEIGHT_M: 0.15,
    Parameter.CROWN_VOLUME_M3: 0.25,
    Parameter.VOLUME_M3: 0.20,
    Parameter.BIOMASS_KG: 0.30,
}


def recommend_next_view(
    estimates: dict[Parameter, ParameterEstimate],
    frames: tuple[FrameObservation, ...],
    visibility: VisibilityAssessment | None = None,
) -> CaptureGuidance:
    """Choose a missing view to reduce the weakest parameter's uncertainty."""

    if visibility is not None:
        if not visibility.root_visible:
            return CaptureGuidance(
                True,
                Parameter.HEIGHT_M,
                None,
                "请降低手机并绕开杂草或遮挡物，补拍目标树与地面连接的根部。",
                "根部没有被可靠观测，树高起点和胸高位置均不成立",
                selection_method="critical_surface_visibility",
            )
        if not visibility.dbh_measurement_allowed and visibility.missing_dbh_sectors:
            sector = visibility.missing_dbh_sectors[0]
            angle = (sector.start_deg + sector.width_deg / 2) % 360
            return CaptureGuidance(
                True,
                Parameter.DBH_CM,
                angle,
                f"请移动到目标树约 {angle:.0f}° 方位，正对胸高位置补拍被遮挡的一侧。",
                f"胸高截面仅覆盖 {visibility.dbh_angular_coverage_deg:.0f}°",
                selection_method="largest_missing_dbh_sector",
            )
        if not visibility.height_measurement_allowed:
            return CaptureGuidance(
                True,
                Parameter.HEIGHT_M,
                None,
                "请稍微退后并抬高手机，确保树根至最高树梢连续出现在画面中。",
                "树梢或垂直方向仍有未观测区段",
                selection_method="critical_surface_visibility",
            )

    weak: list[tuple[float, Parameter]] = []
    for parameter, estimate in estimates.items():
        relative_sd = estimate.standard_deviation / max(abs(estimate.value), 1e-9)
        weak.append((relative_sd / _RELATIVE_SD_LIMITS[parameter], parameter))

    if not weak:
        return CaptureGuidance(True, None, 0.0, "先正对目标树拍摄完整树形。", "尚无可用测量")

    severity, target = max(weak)
    if severity <= 1 and all(estimate.confidence >= 0.7 for estimate in estimates.values()):
        return CaptureGuidance(False, None, None, None, None)

    observed_angles = [frame.azimuth_deg % 360 for frame in frames if frame.azimuth_deg is not None]
    candidates = [0.0, 60.0, 120.0, 180.0, 240.0, 300.0]
    if observed_angles:
        next_angle = max(
            candidates,
            key=lambda candidate: min(
                min(abs(candidate - angle), 360 - abs(candidate - angle))
                for angle in observed_angles
            ),
        )
    else:
        next_angle = 0.0

    if target is Parameter.HEIGHT_M:
        action = "退后并保持整棵树从根部到树梢都在画面内"
    elif target is Parameter.DBH_CM:
        action = "靠近树干，在胸高位置横向补拍"
    else:
        action = "绕到树冠侧面，避免与邻树重叠"

    return CaptureGuidance(
        required=True,
        target_parameter=target,
        azimuth_deg=next_angle,
        instruction=f"请移动到目标树约 {next_angle:.0f}° 方位，{action}。",
        reason=f"{target.value} 的相对不确定度仍高于目标阈值",
    )
