"""Turn TreeFactor covariance into an actionable next-camera recommendation."""

from __future__ import annotations

from math import cos, radians, sin

import numpy as np
import numpy.typing as npt

from treeweaver.domain.models import FrameObservation, Parameter, ParameterEstimate
from treeweaver.guidance.information_gain import CandidateView, select_next_best_view
from treeweaver.guidance.next_view import CaptureGuidance

FloatArray = npt.NDArray[np.float64]

_RELATIVE_SD_LIMITS = {
    Parameter.HEIGHT_M: 0.08,
    Parameter.DBH_CM: 0.10,
    Parameter.CROWN_WIDTH_M: 0.12,
    Parameter.CROWN_DEPTH_M: 0.15,
    Parameter.CROWN_HEIGHT_M: 0.15,
    Parameter.CROWN_VOLUME_M3: 0.25,
    Parameter.VOLUME_M3: 0.20,
    Parameter.BIOMASS_KG: 0.30,
}


def _angular_distance(left: float, right: float) -> float:
    difference = abs((left - right) % 360.0)
    return min(difference, 360.0 - difference)


def _weakest_parameter(estimates: dict[Parameter, ParameterEstimate]) -> Parameter:
    return max(
        estimates,
        key=lambda parameter: (
            estimates[parameter].standard_deviation
            / max(abs(estimates[parameter].value), 1e-9)
            / _RELATIVE_SD_LIMITS[parameter]
        ),
    )


def _candidate(
    azimuth_deg: float,
    observed_azimuths: tuple[float, ...],
    target: Parameter,
) -> CandidateView:
    """Build a local linearized silhouette/extent observation model.

    TreeFactor state order is log-scale, root xyz, raw axis xyz, log-radius,
    taper, and log-height. Angular terms model the view-dependent coupling
    between projected trunk width and the estimated axis. A view close to an
    existing one is assigned correlated (therefore larger) measurement noise.
    """

    theta = radians(azimuth_deg)
    jacobian = np.zeros((3, 10), dtype=np.float64)
    jacobian[0, 4:7] = (0.12 * cos(theta), 0.12 * sin(theta), 0.0)
    jacobian[0, 7] = 1.0
    jacobian[1, 4:7] = (-0.08 * sin(theta), 0.08 * cos(theta), 0.03)
    jacobian[1, 7:9] = (0.35, 1.0)
    jacobian[2, 6] = 0.08
    jacobian[2, 9] = 1.0

    gap = (
        min(_angular_distance(azimuth_deg, observed) for observed in observed_azimuths)
        if observed_azimuths
        else 180.0
    )
    independence = 0.25 + 0.75 * gap / 180.0
    base_sd = np.array([0.045, 0.018, 0.055], dtype=np.float64) / independence
    noise = np.diag(base_sd**2)
    elevation = 20.0 if target is Parameter.HEIGHT_M else 0.0
    return CandidateView(
        view_id=f"azimuth-{int(azimuth_deg):03d}",
        azimuth_deg=azimuth_deg,
        elevation_deg=elevation,
        measurement_jacobian=jacobian,
        measurement_noise=noise,
        visibility_probability=0.85,
    )


def recommend_factor_view(
    covariance: npt.ArrayLike,
    estimates: dict[Parameter, ParameterEstimate],
    frames: tuple[FrameObservation, ...],
) -> CaptureGuidance:
    """Select the view with maximum expected weighted covariance reduction."""

    prior = np.asarray(covariance, dtype=np.float64)
    if prior.shape != (10, 10):
        raise ValueError("TreeFactor guidance requires a 10 by 10 covariance")
    if not estimates:
        raise ValueError("TreeFactor guidance requires parameter estimates")
    target = _weakest_parameter(estimates)
    if target not in {Parameter.HEIGHT_M, Parameter.DBH_CM, Parameter.VOLUME_M3}:
        raise ValueError("weakest parameter is outside the TreeFactor state")
    severity = (
        estimates[target].standard_deviation
        / max(abs(estimates[target].value), 1e-9)
        / _RELATIVE_SD_LIMITS[target]
    )
    if severity <= 1.0 and all(estimate.confidence >= 0.7 for estimate in estimates.values()):
        return CaptureGuidance(
            required=False,
            target_parameter=None,
            azimuth_deg=None,
            instruction=None,
            reason=None,
            selection_method="treefactor_expected_information_gain",
        )
    observed = tuple(
        frame.azimuth_deg % 360.0 for frame in frames if frame.azimuth_deg is not None
    )
    candidates = tuple(
        _candidate(float(angle), observed, target) for angle in range(0, 360, 30)
    )
    weights = np.full(10, 0.01, dtype=np.float64)
    weights[7] = 1.0 if target in {Parameter.DBH_CM, Parameter.VOLUME_M3} else 0.25
    weights[8] = 0.8 if target is Parameter.VOLUME_M3 else 0.2
    weights[9] = 1.0 if target is Parameter.HEIGHT_M else 0.25
    selected = select_next_best_view(prior, candidates, parameter_weights=weights)

    if target is Parameter.HEIGHT_M:
        action = "退后并保持根部和树梢同时完整入镜"
    elif target is Parameter.DBH_CM:
        action = "对准胸高位置横向补拍树干轮廓"
    else:
        action = "保持整株可见并补拍树干上下宽度变化"
    azimuth = selected.view.azimuth_deg
    return CaptureGuidance(
        required=True,
        target_parameter=target,
        azimuth_deg=azimuth,
        instruction=f"请移动到目标树约 {azimuth:.0f}° 方位，{action}。",
        reason=f"该视角对 {target.value} 的预计协方差降低最大",
        selection_method="treefactor_expected_information_gain",
        expected_variance_reduction=selected.expected_weighted_variance_reduction,
    )
