"""Parameter-specific fail-closed routing for complex single-image scenes."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from treeweaver.domain.models import Parameter
from treeweaver.visibility.image_complexity import ImageChallengeCue, TargetViewAudit


class MeasurementReadiness(StrEnum):
    CANDIDATE = "candidate"
    DEGRADED = "degraded"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class ImageParameterGate:
    parameter: Parameter
    readiness: MeasurementReadiness
    reasons: tuple[str, ...]


def _active(audit: TargetViewAudit, cue: ImageChallengeCue, threshold: float = 0.0) -> bool:
    return audit.score(cue) > threshold


def assess_single_image_measurement(
    audit: TargetViewAudit,
    *,
    overlap_block_threshold: float = 0.05,
    fragmentation_block_threshold: float = 0.10,
) -> tuple[ImageParameterGate, ...]:
    """Gate image evidence only; CANDIDATE requires later geometry checks."""

    if not 0 <= overlap_block_threshold <= 1 or not 0 <= fragmentation_block_threshold <= 1:
        raise ValueError("measurement gate thresholds must lie in [0, 1]")

    root_invalid = (
        _active(audit, ImageChallengeCue.ROOT_TRUNCATED)
        or _active(audit, ImageChallengeCue.ROOT_GROUND_GAP)
        or _active(audit, ImageChallengeCue.GROUND_UNAVAILABLE)
    )
    apex_invalid = _active(audit, ImageChallengeCue.APEX_TRUNCATED)
    stem_ambiguous = _active(
        audit, ImageChallengeCue.STEM_OVERLAP, overlap_block_threshold
    ) or _active(audit, ImageChallengeCue.STEM_FRAGMENTED, fragmentation_block_threshold)
    dbh_hidden = _active(audit, ImageChallengeCue.DBH_REGION_HIDDEN)
    dbh_unlocated = _active(audit, ImageChallengeCue.DBH_REGION_UNLOCATED)
    basal_multiple = _active(audit, ImageChallengeCue.BASAL_MULTIPLE_RUNS)
    basal_object_contact = _active(audit, ImageChallengeCue.BASAL_OBJECT_CONTACT, 0.25)
    crown_ambiguous = _active(audit, ImageChallengeCue.CROWN_OVERLAP, overlap_block_threshold)
    crown_cropped = _active(audit, ImageChallengeCue.SIDE_TRUNCATED)

    gates: list[ImageParameterGate] = []

    height_reasons: list[str] = []
    if root_invalid:
        height_reasons.append("根部/地面接触不可验证")
    if basal_object_contact:
        height_reasons.append("树干可见末端紧邻非树物体，根部可能被遮挡")
    if apex_invalid:
        height_reasons.append("树梢触及画面边界")
    if height_reasons:
        height_level = MeasurementReadiness.BLOCKED
    elif stem_ambiguous or crown_ambiguous:
        height_level = MeasurementReadiness.DEGRADED
        height_reasons.append("目标树路径与邻树重叠，需保持更大的不确定度")
    else:
        height_level = MeasurementReadiness.CANDIDATE
    gates.append(ImageParameterGate(Parameter.HEIGHT_M, height_level, tuple(height_reasons)))

    dbh_reasons: list[str] = []
    if root_invalid:
        dbh_reasons.append("无法从可见根部定位胸高起算面")
    if stem_ambiguous or dbh_hidden:
        dbh_reasons.append("胸高区域存在掩膜冲突、隐藏树干假设或树干断裂")
    if dbh_unlocated:
        dbh_reasons.append("缺少独立定位的1.3米胸高区域")
    if basal_multiple:
        dbh_reasons.append("树干基部持续分成多条可见干线，需判定多干或遮挡适用的胸径规则")
    if basal_object_contact:
        dbh_reasons.append("非树物体紧邻树干下端，胸高起点可能被遮挡")
    dbh_level = MeasurementReadiness.BLOCKED if dbh_reasons else MeasurementReadiness.CANDIDATE
    gates.append(ImageParameterGate(Parameter.DBH_CM, dbh_level, tuple(dbh_reasons)))

    crown_reasons: list[str] = []
    if crown_cropped:
        crown_reasons.append("树冠触及侧边，冠幅被截断")
    if crown_ambiguous:
        crown_reasons.append("目标树冠与邻树树冠重叠，外边界不唯一")
    crown_level = MeasurementReadiness.BLOCKED if crown_reasons else MeasurementReadiness.CANDIDATE
    gates.append(ImageParameterGate(Parameter.CROWN_WIDTH_M, crown_level, tuple(crown_reasons)))

    crown_height_reasons: tuple[str, ...]
    if apex_invalid or crown_ambiguous:
        crown_height_reasons = ("树冠顶部或底部边界不可可靠归属",)
        crown_height_level = MeasurementReadiness.BLOCKED
    else:
        crown_height_reasons = ()
        crown_height_level = MeasurementReadiness.CANDIDATE
    gates.append(
        ImageParameterGate(Parameter.CROWN_HEIGHT_M, crown_height_level, crown_height_reasons)
    )

    for parameter, reason in (
        (Parameter.CROWN_DEPTH_M, "单张投影没有树冠前后深度"),
        (Parameter.CROWN_VOLUME_M3, "单张投影不能唯一恢复被遮挡的三维树冠"),
        (Parameter.VOLUME_M3, "单张投影缺少树干锥度和背面截面"),
        (Parameter.BIOMASS_KG, "单图几何不足，且还需要树种与木材密度模型"),
    ):
        gates.append(ImageParameterGate(parameter, MeasurementReadiness.BLOCKED, (reason,)))
    return tuple(gates)
