"""Measure all semantic tree tracks with metric uncertainty propagation."""

from __future__ import annotations

import json
from dataclasses import dataclass
from math import sqrt
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

from treeweaver.domain.models import ParameterEstimate
from treeweaver.geometry.tree import measure_tree_geometry
from treeweaver.guidance.visibility import assess_tree_visibility
from treeweaver.io.point_cloud import load_point_cloud

IntArray = npt.NDArray[np.int64]
FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class MeasurementRunResult:
    output_path: Path
    successful_trees: int
    failed_trees: int


def _slice(flat: IntArray, offsets: IntArray, index: int) -> IntArray:
    return flat[offsets[index] : offsets[index + 1]]


def _local_ground(
    points: FloatArray,
    ground_indices: IntArray,
    trunk_indices: IntArray,
    radius_m: float,
) -> IntArray:
    if len(ground_indices) == 0 or len(trunk_indices) == 0:
        return np.empty(0, dtype=np.int64)
    trunk = points[trunk_indices]
    if len(trunk) > 1000:
        selected = np.linspace(0, len(trunk) - 1, 1000, dtype=np.int64)
        trunk = trunk[selected]
    accepted: list[IntArray] = []
    for start in range(0, len(ground_indices), 2000):
        indices = ground_indices[start : start + 2000]
        ground = points[indices]
        squared = np.sum((ground[:, None, :] - trunk[None, :, :]) ** 2, axis=2)
        accepted.append(indices[np.min(squared, axis=1) <= radius_m**2])
    return np.concatenate(accepted) if accepted else np.empty(0, dtype=np.int64)


def _estimate_payload(estimate: ParameterEstimate, relative_scale_sd: float) -> dict[str, object]:
    scale_component = abs(estimate.value) * relative_scale_sd
    propagated_sd = sqrt(estimate.standard_deviation**2 + scale_component**2)
    relative = propagated_sd / max(abs(estimate.value), 1e-12)
    calibrated_confidence = estimate.confidence * np.exp(-relative)
    return {
        "parameter": estimate.parameter.value,
        "value": estimate.value,
        "standard_deviation": propagated_sd,
        "confidence": float(max(0.0, min(1.0, calibrated_confidence))),
        "observation_count": estimate.observation_count,
        "diagnostics": list(estimate.diagnostics),
        "scale_uncertainty_component": scale_component,
    }


def measure_semantic_bundle(
    dense_point_cloud: str | Path,
    semantic_directory: str | Path,
    output_path: str | Path,
    *,
    metres_per_unit: float,
    scale_standard_deviation: float = 0.0,
    up_hint: npt.ArrayLike | None = None,
    ground_radius_m: float = 2.0,
) -> MeasurementRunResult:
    if metres_per_unit <= 0 or scale_standard_deviation < 0:
        raise ValueError("metric scale must be positive and its deviation non-negative")
    if ground_radius_m <= 0:
        raise ValueError("ground radius must be positive")
    cloud = load_point_cloud(dense_point_cloud)
    metric_points = cloud.points * metres_per_unit
    semantic_root = Path(semantic_directory).resolve()
    metadata: dict[str, Any] = json.loads(
        (semantic_root / "semantics.json").read_text(encoding="utf-8")
    )
    if metadata.get("schema_version") != "semantic-tracks-1.0":
        raise ValueError("unsupported semantic-track schema")
    with np.load(semantic_root / "semantic-points.npz", allow_pickle=False) as arrays:
        trunk = np.asarray(arrays["trunk_indices"], dtype=np.int64)
        trunk_offsets = np.asarray(arrays["trunk_offsets"], dtype=np.int64)
        crown = np.asarray(arrays["crown_indices"], dtype=np.int64)
        crown_offsets = np.asarray(arrays["crown_offsets"], dtype=np.int64)
        ground = np.asarray(arrays["ground_indices"], dtype=np.int64)
    tracks = metadata.get("tracks", [])
    if len(trunk_offsets) != len(tracks) + 1 or len(crown_offsets) != len(tracks) + 1:
        raise ValueError("semantic metadata and point offsets disagree")

    relative_scale_sd = scale_standard_deviation / metres_per_unit
    results: list[dict[str, object]] = []
    successes = 0
    failures = 0
    for index, track in enumerate(tracks):
        trunk_indices = _slice(trunk, trunk_offsets, index)
        crown_indices = _slice(crown, crown_offsets, index)
        nearby_ground = _local_ground(metric_points, ground, trunk_indices, ground_radius_m)
        try:
            geometry = measure_tree_geometry(
                metric_points[trunk_indices],
                metric_points[crown_indices],
                metric_points[nearby_ground],
                up_hint=up_hint,
                automatic_stem_form=True,
            )
            visibility = assess_tree_visibility(
                np.vstack((metric_points[trunk_indices], metric_points[crown_indices])),
                root_position=geometry.root_world,
                up=geometry.ground_normal,
            )
            results.append(
                {
                    "track_id": int(track["track_id"]),
                    "status": "ok",
                    "semantic_confidence": float(track["semantic_confidence"]),
                    "local_ground_points": len(nearby_ground),
                    "height": _estimate_payload(geometry.height, relative_scale_sd),
                    "dbh": _estimate_payload(geometry.dbh, relative_scale_sd),
                    "crown_width": _estimate_payload(geometry.crown_width, relative_scale_sd),
                    "crown_depth": _estimate_payload(geometry.crown_depth, relative_scale_sd),
                    "crown_height": _estimate_payload(geometry.crown_height, relative_scale_sd),
                    "crown_volume": _estimate_payload(
                        geometry.crown_volume, 3 * relative_scale_sd
                    ),
                    "ground_normal": geometry.ground_normal.tolist(),
                    "trunk_axis": geometry.trunk_axis.tolist(),
                    "root_world_m": geometry.root_world.tolist(),
                    "cross_section_coverage_deg": geometry.cross_section_coverage_deg,
                    "cross_section_model": geometry.cross_section_model,
                    "diameter_measurement_height_m": geometry.diameter_measurement_height_m,
                    "diameter_case": geometry.diameter_case.value,
                    "diameter_rule": geometry.diameter_rule,
                    "stem_form_confidence": geometry.stem_form_confidence,
                    "stem_form_diagnostics": list(geometry.stem_form_diagnostics),
                    "cross_section_eccentricity_ratio": (
                        geometry.cross_section_eccentricity_ratio
                    ),
                    "visibility": {
                        "dbh_angular_coverage_deg": visibility.dbh_angular_coverage_deg,
                        "dbh_point_count": visibility.dbh_point_count,
                        "missing_dbh_sectors": [
                            {
                                "start_deg": sector.start_deg,
                                "end_deg": sector.end_deg,
                                "width_deg": sector.width_deg,
                            }
                            for sector in visibility.missing_dbh_sectors
                        ],
                        "root_visible": visibility.root_visible,
                        "apex_visible": visibility.apex_visible,
                        "crown_height_coverage": visibility.crown_height_coverage,
                        "dbh_measurement_allowed": visibility.dbh_measurement_allowed,
                        "height_measurement_allowed": visibility.height_measurement_allowed,
                        "reasons": list(visibility.reasons),
                    },
                }
            )
            successes += 1
        except ValueError as error:
            results.append(
                {
                    "track_id": int(track["track_id"]),
                    "status": "failed",
                    "reason": str(error),
                    "trunk_points": len(trunk_indices),
                    "crown_points": len(crown_indices),
                    "local_ground_points": len(nearby_ground),
                }
            )
            failures += 1

    payload = {
        "schema_version": "tree-measurements-1.0",
        "dense_point_cloud": str(Path(dense_point_cloud).resolve()),
        "semantic_directory": str(semantic_root),
        "metres_per_unit": metres_per_unit,
        "scale_standard_deviation": scale_standard_deviation,
        "up_hint_reconstruction_coordinates": (
            np.asarray(up_hint, dtype=float).tolist() if up_hint is not None else None
        ),
        "trees": results,
    }
    destination = Path(output_path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )
    return MeasurementRunResult(destination, successes, failures)
