"""Conservative evidence fusion for unordered views of one target tree.

This module selects *visible* per-parameter evidence. It does not infer camera
geometry, metric scale, hidden surfaces, or correspondence between trees.
"""

from __future__ import annotations

from dataclasses import dataclass

from treeweaver.domain.models import Parameter
from treeweaver.measurement.image_readiness import (
    MeasurementReadiness,
    assess_single_image_measurement,
)
from treeweaver.visibility.image_complexity import TargetViewAudit


@dataclass(frozen=True, slots=True)
class AssociatedTreeView:
    image_id: str
    audit: TargetViewAudit
    same_tree_verified: bool

    def __post_init__(self) -> None:
        if not self.image_id.strip():
            raise ValueError("image_id cannot be empty")


@dataclass(frozen=True, slots=True)
class MultiviewParameterGate:
    parameter: Parameter
    readiness: MeasurementReadiness
    supporting_view_ids: tuple[str, ...]
    blocked_view_ids: tuple[str, ...]
    reasons: tuple[str, ...]


def assess_unordered_views(
    views: tuple[AssociatedTreeView, ...],
    *,
    overlap_block_threshold: float = 0.05,
    fragmentation_block_threshold: float = 0.10,
) -> tuple[MultiviewParameterGate, ...]:
    """Find an independently visible view for each parameter.

    `same_tree_verified` must be supplied by a separately checked association
    process (or a human); image order and filename are never identity evidence.
    CANDIDATE means image evidence only, not an accurate metric estimate.
    """

    if not views:
        raise ValueError("at least one view is required")
    ids = [view.image_id for view in views]
    if len(ids) != len(set(ids)):
        raise ValueError("image IDs must be unique")
    if not 0 <= overlap_block_threshold <= 1 or not 0 <= fragmentation_block_threshold <= 1:
        raise ValueError("measurement gate thresholds must lie in [0, 1]")

    verified = sorted((view for view in views if view.same_tree_verified), key=lambda v: v.image_id)
    unverified_ids = tuple(sorted(view.image_id for view in views if not view.same_tree_verified))
    by_view = {
        view.image_id: {
            gate.parameter: gate
            for gate in assess_single_image_measurement(
                view.audit,
                overlap_block_threshold=overlap_block_threshold,
                fragmentation_block_threshold=fragmentation_block_threshold,
            )
        }
        for view in verified
    }
    fused: list[MultiviewParameterGate] = []
    for parameter in Parameter:
        candidates = tuple(
            view_id
            for view_id, gates in by_view.items()
            if gates[parameter].readiness is MeasurementReadiness.CANDIDATE
        )
        degraded = tuple(
            view_id
            for view_id, gates in by_view.items()
            if gates[parameter].readiness is MeasurementReadiness.DEGRADED
        )
        blocked = tuple(
            view_id
            for view_id, gates in by_view.items()
            if gates[parameter].readiness is MeasurementReadiness.BLOCKED
        )
        if candidates:
            readiness = MeasurementReadiness.CANDIDATE
            support = candidates
            reasons: tuple[str, ...] = (
                "至少一张已核实同树照片具有该参数的可见候选证据；仍需几何与尺度验证",
            )
        elif degraded:
            readiness = MeasurementReadiness.DEGRADED
            support = degraded
            reasons = ("只有受干扰的可见候选证据；不得声称达到公制测量精度",)
        else:
            readiness = MeasurementReadiness.BLOCKED
            support = ()
            reasons = tuple(
                f"{view_id}: {reason}"
                for view_id in blocked
                for reason in by_view[view_id][parameter].reasons
            ) or ("没有已核实属于目标树的照片",)
        if unverified_ids:
            reasons += (f"未核实同树身份，已排除照片: {', '.join(unverified_ids)}",)
        fused.append(MultiviewParameterGate(parameter, readiness, support, blocked, reasons))
    return tuple(fused)
