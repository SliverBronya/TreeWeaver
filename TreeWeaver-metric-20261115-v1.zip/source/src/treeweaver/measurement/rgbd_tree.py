"""Gravity-aligned measurements from a fused metric tree point cloud."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class FusedTreeGeometry:
    height_m: float
    dbh_cm: float
    crown_width_m: float
    base_height_world_m: float
    breast_height_point_count: int
    point_count: int


def _horizontal_basis(
    up: npt.NDArray[np.float64],
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]]:
    seed = np.array([1.0, 0.0, 0.0])
    if abs(float(np.dot(seed, up))) > 0.9:
        seed = np.array([0.0, 0.0, 1.0])
    first = seed - np.dot(seed, up) * up
    first /= np.linalg.norm(first)
    second = np.cross(up, first)
    return first, second


def measure_fused_tree(
    points_world: npt.NDArray[np.float64],
    gravity_down_world: npt.ArrayLike = (0.0, -1.0, 0.0),
    *,
    breast_height_m: float = 1.3,
    section_half_width_m: float = 0.08,
) -> FusedTreeGeometry:
    """Measure metric geometry after ARCore poses have put all views in one frame."""

    points = np.asarray(points_world, dtype=np.float64)
    gravity = np.asarray(gravity_down_world, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or len(points) < 50:
        raise ValueError("at least 50 finite 3-D tree points are required")
    if not np.isfinite(points).all() or gravity.shape != (3,) or not np.isfinite(gravity).all():
        raise ValueError("points and gravity must be finite")
    norm = float(np.linalg.norm(gravity))
    if norm < 1e-9:
        raise ValueError("gravity vector cannot be zero")
    up = -gravity / norm
    vertical = points @ up
    base = float(np.quantile(vertical, 0.005))
    top = float(np.quantile(vertical, 0.995))
    height = top - base
    if height <= breast_height_m:
        raise ValueError("tree is not tall enough to define DBH")
    first, second = _horizontal_basis(up)
    horizontal = np.column_stack((points @ first, points @ second))

    target = base + breast_height_m
    section = np.abs(vertical - target) <= section_half_width_m
    section_points = horizontal[section]
    if len(section_points) < 12:
        raise ValueError("too few fused points near breast height")
    centre = np.median(section_points, axis=0)
    radii = np.linalg.norm(section_points - centre, axis=1)
    # Multiple views observe the bark surface; twice the robust median radius is
    # stable against a few branch/background points and partial voxel overlap.
    dbh_m = 2.0 * float(np.median(radii))

    crown = horizontal[vertical >= base + 0.35 * height]
    if len(crown) < 20:
        raise ValueError("too few fused crown points")
    centred_crown = crown - np.median(crown, axis=0)
    _, _, axes = np.linalg.svd(centred_crown, full_matrices=False)
    projected = centred_crown @ axes.T
    extents = np.quantile(projected, 0.99, axis=0) - np.quantile(projected, 0.01, axis=0)
    crown_width = float(np.max(extents))
    return FusedTreeGeometry(
        height_m=float(height),
        dbh_cm=dbh_m * 100.0,
        crown_width_m=crown_width,
        base_height_world_m=base,
        breast_height_point_count=int(section.sum()),
        point_count=len(points),
    )
