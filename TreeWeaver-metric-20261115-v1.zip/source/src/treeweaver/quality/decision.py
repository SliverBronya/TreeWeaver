"""Fail-closed publication and application quality gate."""

from __future__ import annotations

from dataclasses import dataclass

from treeweaver.domain.models import Parameter, ParameterEstimate


@dataclass(frozen=True, slots=True)
class ParameterDecision:
    parameter: Parameter
    accepted: bool
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MeasurementDecision:
    accepted: bool
    parameters: tuple[ParameterDecision, ...]
    requires_more_capture: bool


_MAXIMUM_RELATIVE_SD = {
    Parameter.HEIGHT_M: 0.08,
    Parameter.DBH_CM: 0.10,
    Parameter.CROWN_WIDTH_M: 0.15,
    Parameter.CROWN_DEPTH_M: 0.15,
    Parameter.CROWN_HEIGHT_M: 0.18,
    Parameter.CROWN_VOLUME_M3: 0.30,
    Parameter.VOLUME_M3: 0.25,
    Parameter.BIOMASS_KG: 0.35,
}


def decide_measurement(
    estimates: dict[Parameter, ParameterEstimate],
    *,
    reconstruction_passed: bool,
    semantic_confidence: float,
    minimum_confidence: float = 0.60,
    parameter_blockers: dict[Parameter, tuple[str, ...]] | None = None,
) -> MeasurementDecision:
    """Accept each parameter separately; any failed prerequisite causes refusal."""

    if not 0 <= semantic_confidence <= 1 or not 0 <= minimum_confidence <= 1:
        raise ValueError("quality confidences must be in [0, 1]")
    decisions: list[ParameterDecision] = []
    blockers = parameter_blockers or {}
    for parameter, estimate in estimates.items():
        reasons: list[str] = list(blockers.get(parameter, ()))
        if not reconstruction_passed:
            reasons.append("reconstruction quality gate failed")
        if semantic_confidence < 0.5:
            reasons.append("tree-part evidence is unreliable")
        if estimate.confidence < minimum_confidence:
            reasons.append("estimate confidence is below threshold")
        relative_sd = estimate.standard_deviation / max(abs(estimate.value), 1e-12)
        if relative_sd > _MAXIMUM_RELATIVE_SD[parameter]:
            reasons.append("relative uncertainty exceeds the parameter limit")
        decisions.append(ParameterDecision(parameter, not reasons, tuple(reasons)))
    accepted = bool(decisions) and all(decision.accepted for decision in decisions)
    return MeasurementDecision(accepted, tuple(decisions), not accepted)
