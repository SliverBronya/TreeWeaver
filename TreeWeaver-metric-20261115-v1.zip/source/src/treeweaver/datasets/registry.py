"""Machine-readable registry for external research datasets."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class DatasetFile:
    """One immutable downloadable artifact."""

    filename: str
    url: str
    size_bytes: int
    checksum_algorithm: str
    checksum: str


@dataclass(frozen=True, slots=True)
class DatasetDescriptor:
    """Provenance and intended use of one external dataset release."""

    key: str
    title: str
    version: str
    record_url: str
    doi: str
    license_id: str
    citation: str
    files: tuple[DatasetFile, ...]
    intended_uses: tuple[str, ...]
    known_limitations: tuple[str, ...]
    access_notes: str = ""


GREENLENS_ARCORE_V2 = DatasetDescriptor(
    key="greenlens-arcore-v2",
    title="Data From: An App for Tree Trunk Diameter Estimation from Coarse Optical Depth Maps",
    version="v2",
    record_url="https://zenodo.org/records/10776713",
    doi="10.5281/zenodo.10776713",
    license_id="NOASSERTION",
    citation=(
        "Feng, Zhengpeng; Xie, Mingyue; Holcomb, Amelia; Srinivasan, Keshav "
        "(2024), Data From: An App for Tree Trunk Diameter Estimation from "
        "Coarse Optical Depth Maps, Zenodo, v2."
    ),
    files=(
        DatasetFile(
            filename="treedata_version_2.zip",
            url=("https://zenodo.org/api/records/10776713/files/treedata_version_2.zip/content"),
            size_bytes=59_932_765,
            checksum_algorithm="md5",
            checksum="7dcc8c0769fe43e37a3ec63925dad2e8",
        ),
    ),
    intended_uses=(
        "ARCore RGB-depth alignment and confidence filtering",
        "single-view DBH accuracy and failure evaluation",
        "robustness stratification by trunk shape, lean, lighting, and capture conditions",
    ),
    known_limitations=(
        "DBH is the only metric tree attribute supplied",
        "no species, height, crown, volume, camera pose, or video-sequence ground truth",
        "the Zenodo record does not state a machine-readable license",
    ),
)


WHU_STREE_2026 = DatasetDescriptor(
    key="whu-stree-2026",
    title="WHU-STree: A Multi-modal Benchmark Dataset for Street Tree Inventory",
    version="final-2026-03-04",
    record_url="https://github.com/WHU-USI3DV/WHU-STree",
    doi="10.1016/j.isprsjprs.2026.02.011",
    license_id="NOASSERTION",
    citation=(
        "Ding et al. (2026), WHU-STree: A multi-modal benchmark dataset for "
        "street tree inventory, ISPRS Journal of Photogrammetry and Remote Sensing 233."
    ),
    files=(),
    intended_uses=(
        "complex multi-tree instance segmentation",
        "cross-view RGB-point-cloud association using supplied image poses",
        "50-species recognition and cross-city generalization",
        "tree-height and DBH reference comparison",
    ),
    known_limitations=(
        "access is request-gated and download URLs are not immutable public artifacts",
        "mobile-mapping panoramas and lidar are not smartphone ARCore captures",
        "height and DBH are point-cloud-derived references rather than independent "
        "field measurements",
        "no crown-width or destructive-volume reference is supplied",
        "the public repository does not state a dataset license",
    ),
    access_notes=(
        "Submit the official data request at https://wj.qq.com/s2/24852142/0539/ "
        "and place the unmodified final NJ/SY release under data/external/whu-stree-2026."
    ),
)


QUEBEC_HARDWOOD_VOLUME_98_V1 = DatasetDescriptor(
    key="quebec-hardwood-volume-98-v1",
    title=(
        "Mobile laser scanning point clouds, quantitative structure models and "
        "destructive-reference attributes for 98 hardwood trees in Quebec, Canada"
    ),
    version="v1",
    record_url="https://zenodo.org/records/21515256",
    doi="10.5281/zenodo.21515256",
    license_id="CC-BY-4.0",
    citation=(
        "Vandendaele et al. (2026), Mobile laser scanning point clouds, quantitative "
        "structure models and destructive-reference attributes for 98 hardwood trees "
        "in Quebec, Canada, Zenodo, v1."
    ),
    files=(
        DatasetFile(
            filename="01_Sample_trees.zip",
            url="https://zenodo.org/api/records/21515256/files/01_Sample_trees.zip/content",
            size_bytes=287_911_541,
            checksum_algorithm="md5",
            checksum="8c088a37a3aa2651294589509163a646",
        ),
        DatasetFile(
            filename="02_QSM.zip",
            url="https://zenodo.org/api/records/21515256/files/02_QSM.zip/content",
            size_bytes=14_160_587,
            checksum_algorithm="md5",
            checksum="ff45ffdc3132ade2d519dcb4e6b9e7c1",
        ),
        DatasetFile(
            filename="03_Tree_attributes.zip",
            url=("https://zenodo.org/api/records/21515256/files/03_Tree_attributes.zip/content"),
            size_bytes=8_423,
            checksum_algorithm="md5",
            checksum="a19373556a62c30410cb7d7bd00ff09f",
        ),
        DatasetFile(
            filename="QSMs_arbor.R",
            url="https://zenodo.org/api/records/21515256/files/QSMs_arbor.R/content",
            size_bytes=7_142,
            checksum_algorithm="md5",
            checksum="8fa90da8e182c59f1f48f2f90acc8dd3",
        ),
        DatasetFile(
            filename="Readme.docx",
            url="https://zenodo.org/api/records/21515256/files/Readme.docx/content",
            size_bytes=28_577,
            checksum_algorithm="md5",
            checksum="b5ac5feeb3cc058b28b29163c50753d1",
        ),
    ),
    intended_uses=(
        "destructive-reference total, stem, branch, butt, and merchantable volume evaluation",
        "field and felled-height evaluation",
        "DBH and QSM reconstruction evaluation from individual-tree point clouds",
        "species-stratified evaluation for sugar maple and yellow birch",
    ),
    known_limitations=(
        "tree-level mobile-laser point clouds rather than RGB-depth image sequences",
        "only 98 validation trees and two hardwood species",
        "original trajectories and plot-scale raw acquisitions are not included",
        "crown-width reference is not supplied",
    ),
)


URTREES_EVALUATION_2025 = DatasetDescriptor(
    key="urtrees-evaluation-2025",
    title=(
        "Urtrees evaluation dataset: videos collected for evaluating the algorithm "
        "together with ground truth and estimated measurements"
    ),
    version="2025-12-02",
    record_url="https://zenodo.org/records/17780923",
    doi="10.5281/zenodo.17780923",
    license_id="CC-BY-4.0",
    citation=(
        "UrTrees evaluation dataset (2025), Zenodo record 17780923; associated "
        "article: Ecological Informatics 93 (2026), 103552."
    ),
    files=(
        DatasetFile(
            filename="urtrees_evaluation_datasets.tar.gz",
            url=(
                "https://zenodo.org/api/records/17780923/files/"
                "urtrees_evaluation_datasets.tar.gz/content"
            ),
            size_bytes=16_862_031_782,
            checksum_algorithm="md5",
            checksum="cd39e550a664ee1d027b558382213b8b",
        ),
    ),
    intended_uses=(
        "smartphone-video DBH and height accuracy evaluation",
        "robustness evaluation across leaves, surveyors, environment, and accessibility",
        "comparison with the paper's published test protocol",
    ),
    known_limitations=(
        "primarily isolated single-stem Western European urban trees",
        "not a complete multi-organ species-recognition benchmark",
        "crown volume estimates are not independent crown ground truth",
    ),
)


TREE_STEREO_BIOPHYSICAL_V3 = DatasetDescriptor(
    key="tree-stereo-biophysical-v3",
    title="Tree Image Dataset for Biophysical Parameter Estimation using Stereoscopic Vision",
    version="3",
    record_url="https://data.mendeley.com/datasets/nx3ggv7pxf/3",
    doi="10.17632/nx3ggv7pxf.3",
    license_id="CC-BY-4.0",
    citation=(
        "Kiplimo, Cedric; Maina, Ciira; Okal, Billy (2023), Tree Image Dataset "
        "for Biophysical Parameter Estimation using Stereoscopic Vision, Mendeley Data, V3."
    ),
    files=(
        DatasetFile(
            filename="dataset.zip",
            url="https://data.mendeley.com/public-api/zip/nx3ggv7pxf/download/3",
            size_bytes=395_220_647,
            checksum_algorithm="sha256",
            checksum="75ad9cbe36eaa3234db0919278df944c3b391cb42f671429e188976cffdf6feb",
        ),
    ),
    intended_uses=(
        "calibrated-stereo DBH evaluation with metric camera baseline",
        "tree-height and crown-diameter geometry pilots",
        "camera-calibration and stereo-depth regression tests",
    ),
    known_limitations=(
        "stereo pairs rather than ordinary monocular smartphone videos",
        "version 3 has no tree segmentation masks",
        "no species labels or multi-organ species observations",
        "small evaluation set: 20 DBH trees and 10 full trees",
    ),
)


TREE_STEREO_BIOPHYSICAL_V4 = DatasetDescriptor(
    key="tree-stereo-biophysical-v4",
    title="Tree Image Dataset for Biophysical Parameter Estimation using Stereoscopic Vision",
    version="4",
    record_url="https://data.mendeley.com/datasets/nx3ggv7pxf/4",
    doi="10.17632/nx3ggv7pxf.4",
    license_id="CC-BY-4.0",
    citation=(
        "Kiplimo, Cedric; Maina, Ciira; Okal, Billy (2023), Tree Image Dataset "
        "for Biophysical Parameter Estimation using Stereoscopic Vision, Mendeley Data, V4."
    ),
    files=(
        DatasetFile(
            filename="dataset.zip",
            url="https://data.mendeley.com/public-api/zip/nx3ggv7pxf/download/4",
            size_bytes=563_941_204,
            checksum_algorithm="sha256",
            checksum="e763dcd5eee579adeeca457f3de530973247ba7bf973f3044f8cc8b97f52cb06",
        ),
    ),
    intended_uses=(
        "masked calibrated-stereo DBH evaluation over 90 trunks",
        "tree-height and crown-diameter evaluation over 251 full trees",
        "training and evaluation of trunk and whole-tree segmentation",
    ),
    known_limitations=(
        "purpose-built stereo camera rather than ordinary monocular smartphone video",
        "ground-truth masks make geometry results an oracle-segmentation baseline",
        "no organ-level observations for species recognition",
        "some trunk views do not contain the computed physical breast-height row",
    ),
)


_DATASETS = {
    GREENLENS_ARCORE_V2.key: GREENLENS_ARCORE_V2,
    QUEBEC_HARDWOOD_VOLUME_98_V1.key: QUEBEC_HARDWOOD_VOLUME_98_V1,
    TREE_STEREO_BIOPHYSICAL_V3.key: TREE_STEREO_BIOPHYSICAL_V3,
    TREE_STEREO_BIOPHYSICAL_V4.key: TREE_STEREO_BIOPHYSICAL_V4,
    URTREES_EVALUATION_2025.key: URTREES_EVALUATION_2025,
    WHU_STREE_2026.key: WHU_STREE_2026,
}


def get_dataset(key: str) -> DatasetDescriptor:
    """Return a registered dataset or raise a useful error."""

    try:
        return _DATASETS[key]
    except KeyError as exc:
        choices = ", ".join(sorted(_DATASETS))
        raise KeyError(f"unknown dataset {key!r}; available: {choices}") from exc


def list_datasets() -> tuple[DatasetDescriptor, ...]:
    """Return all dataset releases in stable key order."""

    return tuple(_DATASETS[key] for key in sorted(_DATASETS))
