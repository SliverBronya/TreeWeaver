"""Human-reviewed visible-tree labels; unlabelled areas remain unknown by default."""

from __future__ import annotations

import math
from typing import Any


def validate_human_labelme(document: dict[str, Any]) -> None:
    review = document.get("treeweaver_review", {})
    if review.get("state") != "approved" or not str(review.get("reviewer", "")).strip():
        raise ValueError("Explicit human approval and reviewer are required")
    if document.get("treeweaver_provenance") != "human_annotation":
        raise ValueError("Predictions and assistant drafts are not human ground truth")
    if document.get("flags", {}).get("assistant_draft", True):
        raise ValueError("Assistant drafts are not eligible as evaluation truth")
    if document.get("treeweaver_coverage") not in {"partial", "exhaustive_visible"}:
        raise ValueError("Declare partial or exhaustive_visible annotation coverage")
    width, height = document.get("imageWidth"), document.get("imageHeight")
    if type(width) is not int or type(height) is not int or min(width, height) < 1:
        raise ValueError("Positive original image dimensions are required")
    allowed = {
        "visible": "polygon",
        "occluded": "polygon",
        "stem": "polygon",
        "stem_occluded": "polygon",
        "unknown": "polygon",
        "background": "polygon",
        "positive_stem_point": "point",
        "negative_point": "point",
        "prompt_box": "rectangle",
    }
    visible_ids = set()
    for shape in document.get("shapes", []):
        label = shape.get("label")
        if label not in allowed or shape.get("shape_type") != allowed[label]:
            raise ValueError(f"Unsupported annotation label/type: {label}")
        points = shape.get("points", [])
        needed = {"polygon": 3, "rectangle": 2, "point": 1}[allowed[label]]
        if len(points) < needed or (allowed[label] != "polygon" and len(points) != needed):
            raise ValueError("Wrong number of annotation points")
        for point in points:
            if len(point) != 2 or any(
                type(v) not in (float, int) or not math.isfinite(v) for v in point
            ):
                raise ValueError("Finite original-frame XY coordinates required")
            if not (0 <= point[0] < width and 0 <= point[1] < height):
                raise ValueError("Annotation point is outside original image")
        if allowed[label] == "polygon":
            vertices = {tuple(point) for point in points}
            area2 = sum(
                points[i][0] * points[(i + 1) % len(points)][1]
                - points[(i + 1) % len(points)][0] * points[i][1]
                for i in range(len(points))
            )
            if len(vertices) < 3 or abs(area2) < 1e-8:
                raise ValueError("Polygon must have three distinct vertices and nonzero area")
        if label not in {"unknown", "background"}:
            identity = shape.get("group_id")
            if type(identity) is not int or identity < 1:
                raise ValueError("Tree shapes need a positive integer group_id")
            if label == "visible" and not shape.get("flags", {}).get("hole", False):
                visible_ids.add(identity)
    if not visible_ids:
        raise ValueError("No human visible-tree polygons were annotated")
    for shape in document["shapes"]:
        if shape["label"] not in {"unknown", "background"} and shape["group_id"] not in visible_ids:
            raise ValueError("Every annotated tree needs a visible region")


def rasterize_human_labelme(document: dict[str, Any]) -> dict[str, Any]:
    """Rasterize verified polygons without inventing unseen/amodal regions."""
    validate_human_labelme(document)
    import cv2
    import numpy as np

    shape = document["imageHeight"], document["imageWidth"]
    ids = sorted({s["group_id"] for s in document["shapes"] if s["label"] == "visible"})
    visible = {i: np.zeros(shape, np.uint8) for i in ids}
    occluded = {i: np.zeros(shape, np.uint8) for i in ids}
    stems = {i: np.zeros(shape, np.uint8) for i in ids}
    stems_occluded = {i: np.zeros(shape, np.uint8) for i in ids}
    background = np.zeros(shape, np.uint8)
    explicit_unknown = np.zeros(shape, np.uint8)
    points: dict[int, dict[str, Any]] = {
        i: {"positive_points": [], "negative_points": [], "box": None} for i in ids
    }
    # Apply additions before holes, independent of the editor's shape order.
    for subtract in (False, True):
        for item in document["shapes"]:
            label = item["label"]
            if item["shape_type"] != "polygon":
                continue
            hole = bool(item.get("flags", {}).get("hole", False))
            if hole != subtract:
                continue
            target = (
                visible[item["group_id"]]
                if label == "visible"
                else occluded[item["group_id"]]
                if label == "occluded"
                else stems[item["group_id"]]
                if label == "stem"
                else stems_occluded[item["group_id"]]
                if label == "stem_occluded"
                else background
                if label == "background"
                else explicit_unknown
            )
            cv2.fillPoly(target, [np.rint(item["points"]).astype(np.int32)], 0 if hole else 1)
    for item in document["shapes"]:
        if item["label"] == "positive_stem_point":
            points[item["group_id"]]["positive_points"].extend(item["points"])
        elif item["label"] == "negative_point":
            points[item["group_id"]]["negative_points"].extend(item["points"])
        elif item["label"] == "prompt_box":
            (x0, y0), (x1, y1) = item["points"]
            if x0 == x1 or y0 == y1:
                raise ValueError("Prompt box must have positive area")
            points[item["group_id"]]["box"] = [min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)]
    stack = np.stack([visible[i] for i in ids]).astype(bool)
    occluded_stack = np.stack([occluded[i] for i in ids]).astype(bool)
    overlap = stack.sum(axis=0) > 1
    known = stack.any(axis=0) | occluded_stack.any(axis=0) | (background > 0)
    if document["treeweaver_coverage"] == "exhaustive_visible":
        known[:] = True
    background_conflict = stack.any(axis=0) & (background > 0)
    unknown = ~known | overlap | background_conflict | (explicit_unknown > 0)
    ownership = np.zeros(shape, np.uint16)
    instances = []
    for index, identity in enumerate(ids, 1):
        mask = visible[identity].astype(bool)
        hidden = occluded[identity].astype(bool)
        stem = stems[identity].astype(bool)
        stem_hidden = stems_occluded[identity].astype(bool)
        if (stem & ~mask & ~unknown).any():
            raise ValueError("Known stem pixels must belong to the tree visible mask")
        if (stem_hidden & ~hidden & ~unknown).any():
            raise ValueError("Occluded stem pixels must belong to the occluded mask")
        if not (mask & ~unknown).any():
            raise ValueError("A labelled tree has no unambiguous visible pixels")
        ownership[mask] = index
        prompt = points[identity]
        box_source = "human_prompt"
        if prompt["box"] is None:
            ys, xs = np.nonzero(mask & ~unknown)
            prompt["box"] = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]
            box_source = "gt_derived_box_upper_bound"
        instances.append(
            {
                "id": f"tree-{identity}",
                "group_id": identity,
                **prompt,
                "box_source": box_source,
                "visible": mask,
                "occluded": hidden,
                "complete": mask | hidden,
                "stem": stem if stem.any() else None,
                "stem_occluded": stem_hidden if stem_hidden.any() else None,
            }
        )
    ownership[unknown] = 65535
    return {"instances": instances, "unknown": unknown, "ownership": ownership}
