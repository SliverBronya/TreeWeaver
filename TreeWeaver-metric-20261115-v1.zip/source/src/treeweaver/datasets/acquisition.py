"""Explicit, resumable and checksum-verified dataset acquisition."""

from __future__ import annotations

import hashlib
import json
import os
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import IO, Protocol, cast

from treeweaver.datasets.registry import DatasetDescriptor, DatasetFile


class Response(Protocol):
    status: int

    def read(self, size: int = -1) -> bytes: ...

    def __enter__(self) -> Response: ...

    def __exit__(self, *args: object) -> None: ...


class Opener(Protocol):
    def __call__(self, request: urllib.request.Request) -> Response: ...


@dataclass(frozen=True, slots=True)
class DownloadResult:
    path: Path
    bytes_written: int
    resumed_from: int
    checksum: str


def file_checksum(path: Path, algorithm: str, chunk_size: int = 1024 * 1024) -> str:
    """Hash a file without loading it into memory."""

    digest = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_artifact(path: Path, artifact: DatasetFile) -> None:
    """Raise if size or checksum differs from the immutable registry entry."""

    actual_size = path.stat().st_size
    if actual_size != artifact.size_bytes:
        raise ValueError(
            f"size mismatch for {path.name}: expected {artifact.size_bytes}, got {actual_size}"
        )
    actual_checksum = file_checksum(path, artifact.checksum_algorithm)
    if actual_checksum.lower() != artifact.checksum.lower():
        raise ValueError(
            f"{artifact.checksum_algorithm} mismatch for {path.name}: "
            f"expected {artifact.checksum}, got {actual_checksum}"
        )


def _stream_response(response: Response, output: IO[bytes], chunk_size: int) -> int:
    written = 0
    while chunk := response.read(chunk_size):
        output.write(chunk)
        written += len(chunk)
    return written


def download_artifact(
    artifact: DatasetFile,
    destination: Path,
    *,
    opener: Opener | None = None,
    chunk_size: int = 1024 * 1024,
    max_attempts: int = 12,
) -> DownloadResult:
    """Download to ``.part`` and retry premature EOFs with verified byte ranges."""

    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        verify_artifact(destination, artifact)
        return DownloadResult(
            destination,
            bytes_written=0,
            resumed_from=destination.stat().st_size,
            checksum=artifact.checksum,
        )

    part = destination.with_name(destination.name + ".part")
    open_request = opener or cast(Opener, urllib.request.urlopen)
    initial_size = part.stat().st_size if part.exists() else 0
    if initial_size > artifact.size_bytes:
        raise ValueError(f"partial file is larger than registered artifact: {part}")

    stalled_attempts = 0
    for _attempt in range(max_attempts):
        resume_from = part.stat().st_size if part.exists() else 0
        if resume_from == artifact.size_bytes:
            break

        headers = {"User-Agent": "TreeWeaver/0.1 dataset acquisition"}
        if resume_from:
            headers["Range"] = f"bytes={resume_from}-"
        request = urllib.request.Request(artifact.url, headers=headers)
        try:
            with open_request(request) as response:
                status = getattr(response, "status", 200)
                append = resume_from > 0 and status == 206
                mode = "ab" if append else "wb"
                with part.open(mode) as output:
                    _stream_response(response, output, chunk_size)
                    output.flush()
                    os.fsync(output.fileno())
        except (OSError, urllib.error.URLError):
            # Zenodo and similar repositories can close long transfers early.
            # The next attempt resumes from the bytes durably flushed above.
            pass

        new_size = part.stat().st_size if part.exists() else 0
        stalled_attempts = stalled_attempts + 1 if new_size == resume_from else 0
        if stalled_attempts >= 3:
            raise OSError(f"download made no progress for {artifact.filename}")

        if new_size > artifact.size_bytes:
            raise ValueError(f"partial file is larger than registered artifact: {part}")

    verify_artifact(part, artifact)
    part.replace(destination)
    final_size = destination.stat().st_size
    return DownloadResult(
        destination,
        bytes_written=final_size - initial_size,
        resumed_from=initial_size,
        checksum=artifact.checksum,
    )


def write_dataset_receipt(
    descriptor: DatasetDescriptor, directory: Path, files: tuple[Path, ...]
) -> Path:
    """Write provenance only after every listed file has passed verification."""

    for artifact, path in zip(descriptor.files, files, strict=True):
        verify_artifact(path, artifact)
    receipt = directory / "dataset-receipt.json"
    payload = {
        "schema_version": 1,
        "dataset": asdict(descriptor),
        "verified_files": [str(path.resolve()) for path in files],
    }
    receipt.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return receipt
