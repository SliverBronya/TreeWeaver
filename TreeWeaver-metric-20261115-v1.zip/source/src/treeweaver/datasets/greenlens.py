"""Auditable adapter for the GreenLens ARCore RGB-depth DBH dataset."""

from __future__ import annotations

import csv
import json
import re
import zipfile
from collections.abc import Iterator
from dataclasses import asdict, dataclass
from pathlib import Path
from xml.etree import ElementTree

_SHEET_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
_REL_NS = {"r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}


@dataclass(frozen=True, slots=True)
class GreenLensLabel:
    index: int
    dbh_cm: float
    country: str
    site: str
    lighting: str
    non_cylindrical: bool
    with_burls: bool
    leaning: bool
    occlusion_level: int


@dataclass(frozen=True, slots=True)
class GreenLensSample:
    sample_id: str
    rgb_path: str
    depth_path: str
    rgb_width: int
    rgb_height: int
    depth_width: int
    depth_height: int
    depth_to_rgb_scale_x: float
    depth_to_rgb_scale_y: float
    label: GreenLensLabel


@dataclass(frozen=True, slots=True)
class GreenLensDepthPoint:
    x: int
    y: int
    depth_m: float
    confidence: float


def iter_depth_points(path: str | Path) -> Iterator[GreenLensDepthPoint]:
    """Stream one depth text file without materialising its complete grid."""

    with Path(path).open("r", encoding="utf-8", newline="") as stream:
        for line_number, row in enumerate(csv.reader(stream), start=1):
            if len(row) != 4:
                raise ValueError(f"{path}:{line_number}: expected four comma-separated fields")
            x, y = int(row[0]), int(row[1])
            depth_m, confidence = float(row[2]), float(row[3])
            if x < 0 or y < 0 or depth_m < 0.0 or not 0.0 <= confidence <= 1.0:
                raise ValueError(f"{path}:{line_number}: invalid depth sample {row!r}")
            yield GreenLensDepthPoint(x, y, depth_m, confidence)


def _column_index(reference: str) -> int:
    letters = re.match(r"[A-Z]+", reference)
    if letters is None:
        raise ValueError(f"invalid spreadsheet cell reference: {reference}")
    index = 0
    for char in letters.group(0):
        index = index * 26 + ord(char) - ord("A") + 1
    return index - 1


def _xlsx_rows(path: Path, sheet_name: str) -> list[list[str]]:
    with zipfile.ZipFile(path) as workbook:
        strings_root = ElementTree.fromstring(workbook.read("xl/sharedStrings.xml"))
        shared_strings = [
            "".join(node.text or "" for node in item.findall(".//m:t", _SHEET_NS))
            for item in strings_root.findall("m:si", _SHEET_NS)
        ]
        workbook_root = ElementTree.fromstring(workbook.read("xl/workbook.xml"))
        relationship_id = None
        for sheet in workbook_root.findall(".//m:sheet", _SHEET_NS):
            if sheet.get("name") == sheet_name:
                relationship_id = sheet.get(f"{{{_REL_NS['r']}}}id")
                break
        if relationship_id is None:
            raise ValueError(f"worksheet {sheet_name!r} not found in {path}")
        rels_root = ElementTree.fromstring(workbook.read("xl/_rels/workbook.xml.rels"))
        target = next(
            (
                relation.get("Target")
                for relation in rels_root
                if relation.get("Id") == relationship_id
            ),
            None,
        )
        if target is None:
            raise ValueError(f"worksheet relationship {relationship_id!r} is missing")
        sheet_root = ElementTree.fromstring(workbook.read("xl/" + target.lstrip("/")))

    rows: list[list[str]] = []
    for row in sheet_root.findall(".//m:row", _SHEET_NS):
        values: list[str] = []
        for cell in row.findall("m:c", _SHEET_NS):
            column = _column_index(cell.get("r", ""))
            while len(values) <= column:
                values.append("")
            value = cell.find("m:v", _SHEET_NS)
            raw = "" if value is None or value.text is None else value.text
            values[column] = shared_strings[int(raw)] if cell.get("t") == "s" and raw else raw
        rows.append(values)
    return rows


def load_labels(path: str | Path) -> dict[int, GreenLensLabel]:
    """Read the upstream DataLabel worksheet without a spreadsheet dependency."""

    rows = _xlsx_rows(Path(path), "DataLabel")
    if not rows:
        raise ValueError(f"empty GreenLens label workbook: {path}")
    header = {name: index for index, name in enumerate(rows[0])}
    required = {
        "Index",
        "Non_cylindrical",
        "With_burls",
        "Leaning",
        "Occlusion_level",
        "Country",
        "Site",
        "Lighting",
        "GT_D",
    }
    missing = required - header.keys()
    if missing:
        raise ValueError(f"GreenLens labels missing columns: {sorted(missing)}")

    labels: dict[int, GreenLensLabel] = {}
    for row in rows[1:]:
        if not row or not row[header["Index"]]:
            continue

        values = {name: row[column] for name, column in header.items()}
        index = int(float(values["Index"]))
        labels[index] = GreenLensLabel(
            index=index,
            dbh_cm=float(values["GT_D"]),
            country=values["Country"],
            site=values["Site"],
            lighting=values["Lighting"],
            non_cylindrical=bool(int(float(values["Non_cylindrical"]))),
            with_burls=bool(int(float(values["With_burls"]))),
            leaning=bool(int(float(values["Leaning"]))),
            occlusion_level=int(float(values["Occlusion_level"])),
        )
    return labels


def prepare_greenlens(root: str | Path, output_json: str | Path) -> tuple[GreenLensSample, ...]:
    """Validate the v2 layout and emit a provenance-preserving sample manifest."""

    root_path = Path(root).resolve()
    labels = load_labels(root_path / "data_label.xlsx")
    samples: list[GreenLensSample] = []
    for index, label in sorted(labels.items()):
        rgb = root_path / "rgb" / f"{index}.jpg"
        depth = root_path / "depthtxt" / str(index)
        if not rgb.is_file() or not depth.is_file():
            raise FileNotFoundError(f"sample {index} is missing RGB or depth input")
        point_count = 0
        max_x = max_y = -1
        for point in iter_depth_points(depth):
            point_count += 1
            max_x = max(max_x, point.x)
            max_y = max(max_y, point.y)
        depth_width = max_x + 1
        depth_height = max_y + 1
        if point_count != depth_width * depth_height:
            raise ValueError(f"sample {index} depth grid is incomplete")
        samples.append(
            GreenLensSample(
                sample_id=str(index),
                rgb_path=str(rgb),
                depth_path=str(depth),
                rgb_width=480,
                rgb_height=360,
                depth_width=depth_width,
                depth_height=depth_height,
                depth_to_rgb_scale_x=480 / depth_width,
                depth_to_rgb_scale_y=360 / depth_height,
                label=label,
            )
        )

    output_path = Path(output_json).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "dataset_key": "greenlens-arcore-v2",
        "reference_kind": "field_dbh",
        "depth_unit": "metre",
        "samples": [asdict(sample) for sample in samples],
    }
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", "utf-8")
    return tuple(samples)
