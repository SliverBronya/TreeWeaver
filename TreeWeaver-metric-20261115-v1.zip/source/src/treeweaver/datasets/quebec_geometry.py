"""TreeWeaver point-cloud geometry baseline for the Quebec-98 release."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import numpy.typing as npt
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree

from treeweaver.datasets.quebec_volume import load_quebec_references
from treeweaver.geometry.cross_section import fit_trunk_cross_section

FloatArray = npt.NDArray[np.float64]


def _largest_local_surface(points: FloatArray, radius_m: float = 0.04) -> FloatArray:
    """Keep the largest spatially connected bark surface in a height slab."""

    if len(points) < 16:
        return points
    pairs = cKDTree(points).query_pairs(radius_m, output_type="ndarray")
    if len(pairs) == 0:
        return points
    rows = np.r_[pairs[:, 0], pairs[:, 1]]
    columns = np.r_[pairs[:, 1], pairs[:, 0]]
    graph = coo_matrix((np.ones(len(rows)), (rows, columns)), shape=(len(points), len(points)))
    _, labels = connected_components(graph, directed=False)
    counts = np.bincount(labels)
    largest = int(np.argmax(counts))
    selected = points[labels == largest]
    return selected if len(selected) >= 16 else points


def _ransac_circle_surface(
    points: FloatArray,
    tree_id: str,
    *,
    trials: int = 800,
    threshold_m: float = 0.025,
) -> FloatArray:
    """Select bark points supporting one plausible circular stem cross-section."""

    if len(points) < 24:
        return points
    seed = int.from_bytes(hashlib.sha256(tree_id.encode()).digest()[:8], "big")
    generator = np.random.default_rng(seed)
    best_indices: npt.NDArray[np.intp] | None = None
    best_score = -1.0
    for _ in range(trials):
        sample = points[generator.choice(len(points), size=3, replace=False)]
        first = 2 * (sample[1] - sample[0])
        second = 2 * (sample[2] - sample[0])
        matrix = np.vstack((first, second))
        if abs(float(np.linalg.det(matrix))) < 1e-8:
            continue
        target = np.array(
            [
                float(sample[1] @ sample[1] - sample[0] @ sample[0]),
                float(sample[2] @ sample[2] - sample[0] @ sample[0]),
            ]
        )
        centre = np.linalg.solve(matrix, target)
        radius = float(np.linalg.norm(sample[0] - centre))
        if not 0.02 <= radius <= 0.9:
            continue
        residual = np.abs(np.linalg.norm(points - centre, axis=1) - radius)
        indices = np.flatnonzero(residual <= threshold_m)
        if len(indices) < 16:
            continue
        angles = np.mod(
            np.arctan2(points[indices, 1] - centre[1], points[indices, 0] - centre[0]),
            2 * np.pi,
        )
        ordered = np.sort(angles)
        gaps = np.diff(np.r_[ordered, ordered[0] + 2 * np.pi])
        coverage = 2 * np.pi - float(np.max(gaps))
        score = len(indices) * (0.25 + coverage / (2 * np.pi))
        if score > best_score:
            best_score = score
            best_indices = indices
    return points[best_indices] if best_indices is not None else points


def _prediction(
    tree_id: str,
    plot: str,
    site: str,
    species: str,
    parameter: str,
    truth: float,
    estimate: float | None,
    uncertainty: float | None,
    diagnostics: list[str],
) -> dict[str, object]:
    return {
        "tree_id": tree_id,
        "session_id": plot,
        "split": "external_test",
        "parameter": parameter,
        "truth": truth,
        "estimate": estimate,
        "standard_deviation": uncertainty,
        "confidence": 1.0 if estimate is not None else 0.0,
        "strata": {"site": site, "species": species},
        "diagnostics": diagnostics,
    }


def run_quebec_geometry_baseline(
    laz_root: str | Path,
    attributes_csv: str | Path,
    output_json: str | Path,
) -> tuple[int, int]:
    """Measure DBH/height and emit crown width without claiming crown accuracy."""

    try:
        import laspy
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('install LAZ support with pip install -e ".[vision]"') from exc

    root = Path(laz_root).resolve()
    trees = load_quebec_references(attributes_csv)
    predictions: list[dict[str, object]] = []
    crown_estimates: list[dict[str, object]] = []
    failures = 0
    for tree in trees:
        path = next(iter(root.rglob(f"{tree.tree_id}.laz")), None)
        if path is None:
            raise FileNotFoundError(f"missing LAZ for {tree.tree_id}")
        cloud = laspy.read(path)
        x = np.asarray(cloud.x, dtype=np.float64)
        y = np.asarray(cloud.y, dtype=np.float64)
        height_above_ground = np.asarray(cloud.hag, dtype=np.float64)
        wood_probability = np.asarray(cloud.pwood, dtype=np.float64)

        finite = (
            np.isfinite(x)
            & np.isfinite(y)
            & np.isfinite(height_above_ground)
            & np.isfinite(wood_probability)
        )
        x, y = x[finite], y[finite]
        height_above_ground = height_above_ground[finite]
        wood_probability = wood_probability[finite]
        height_m = float(np.quantile(height_above_ground, 0.995))
        top = height_above_ground[height_above_ground >= np.quantile(height_above_ground, 0.98)]
        height_sd = max(float(np.std(top, ddof=1) / np.sqrt(len(top))), 0.01)

        dbh_height = 1.3
        section_mask = (np.abs(height_above_ground - dbh_height) <= 0.06) & (
            wood_probability >= 0.5
        )
        section = np.column_stack((x[section_mask], y[section_mask]))
        raw_section_count = len(section)
        section = _largest_local_surface(section)
        section -= np.median(section, axis=0)
        section = _ransac_circle_surface(section, tree.tree_id)
        dbh_cm: float | None = None
        dbh_sd_cm: float | None = None
        dbh_diagnostics: list[str] = []
        if len(section) >= 16:
            section -= np.median(section, axis=0)
            cross_section = fit_trunk_cross_section(section)
            dbh_cm = cross_section.circumference_equivalent_diameter * 100
            coverage_penalty = max(1.0, 180.0 / max(cross_section.angular_coverage_deg, 1.0))
            dbh_sd_cm = max(
                0.1,
                200
                * cross_section.residual_standard_deviation
                / np.sqrt(len(section))
                * coverage_penalty,
            )
            dbh_diagnostics.extend(
                [
                    f"points={len(section)}",
                    f"raw_points={raw_section_count}",
                    f"coverage_deg={cross_section.angular_coverage_deg:.2f}",
                    f"model={cross_section.model}",
                ]
            )
        else:
            failures += 1
            dbh_diagnostics.append(f"insufficient breast-height points: {len(section)}")

        predictions.extend(
            (
                _prediction(
                    tree.tree_id,
                    tree.plot,
                    tree.site,
                    tree.species,
                    "treeweaver_dbh_130_cm",
                    tree.dbh_ref_cm,
                    dbh_cm,
                    dbh_sd_cm,
                    dbh_diagnostics,
                ),
                _prediction(
                    tree.tree_id,
                    tree.plot,
                    tree.site,
                    tree.species,
                    "treeweaver_height_m",
                    tree.height_felled_ref_m,
                    height_m,
                    height_sd,
                    ["height=99.5th percentile of height-above-ground points"],
                ),
            )
        )

        crown_mask = height_above_ground >= 0.35 * height_m
        crown = np.column_stack((x[crown_mask], y[crown_mask]))
        crown -= np.median(crown, axis=0)
        _, _, axes = np.linalg.svd(crown, full_matrices=False)
        projected = crown @ axes.T
        extents = np.quantile(projected, 0.995, axis=0) - np.quantile(projected, 0.005, axis=0)
        crown_estimates.append(
            {
                "tree_id": tree.tree_id,
                "crown_major_width_m": float(max(extents)),
                "crown_minor_width_m": float(min(extents)),
                "reference_available": False,
            }
        )

    destination = Path(output_json).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "dataset_key": "quebec-hardwood-volume-98-v1",
                "method": "treeweaver-quebec-pointcloud-baseline-v1",
                "measurement_height_m": 1.3,
                "predictions": predictions,
                "unscored_crown_estimates": crown_estimates,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return len(trees), failures
