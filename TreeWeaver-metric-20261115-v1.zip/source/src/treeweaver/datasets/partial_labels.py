"""Auditable sparse RGB instance supervision; drafts are never evaluation truth."""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any


def content_fingerprint(document: dict[str, Any]) -> str:
    payload = {key: value for key, value in document.items() if key != "review"}
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def validate_partial_labels(document: dict[str, Any]) -> None:
    if document.get("schema_version") != "partial-tree-rgb.v1":
        raise ValueError("Unsupported partial annotation version")
    width, height = document["image"]["width"], document["image"]["height"]
    if type(width) is not int or type(height) is not int or min(width, height) <= 0:
        raise ValueError("Positive integer image dimensions required")
    if document.get("coverage") != "partial_positive_only":
        raise ValueError("This contract does not declare exhaustive labels")
    if document.get("role") not in ("train", "development", "protected_test"):
        raise ValueError("Unknown split role")
    ids = [instance["local_id"] for instance in document["instances"]]
    if any(type(identity) is not int or identity <= 0 for identity in ids):
        raise ValueError("Local instance IDs must be positive integers")
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate local instance ID")

    def check_points(points: list[Any]) -> None:
        for point in points:
            if len(point) != 2 or not all(
                type(value) in (int, float) and math.isfinite(value) for value in point
            ):
                raise ValueError("Finite XY coordinates required")
            if not (0 <= point[0] < width and 0 <= point[1] < height):
                raise ValueError("Coordinate outside original RGB image")

    polygons = (
        list(document["unknown_regions"])
        + document["known_background_regions"]
        + document.get("known_nonstem_regions", [])
    )
    for instance in document["instances"]:
        check_points(instance["visible_stem_points"])
        polygons.extend(instance["visible_stem_positive_regions"])
        polygons.extend(instance["certain_branch_regions"])
        polygons.extend(instance["certain_crown_regions"])
    for polygon in polygons:
        if len(polygon) < 3:
            raise ValueError("A region needs at least three vertices")
        check_points(polygon)


def require_reviewed_labels(document: dict[str, Any]) -> None:
    validate_partial_labels(document)
    review = document.get("review", {})
    if review.get("state") != "approved" or not review.get("reviewer"):
        raise ValueError("Unreviewed draft is not eligible for reviewed training/evaluation")
    if review.get("content_sha256") != content_fingerprint(document):
        raise ValueError("Annotation changed after review; re-review required")


def validate_group_split(documents: list[dict[str, Any]]) -> None:
    roles: dict[int, str] = {}
    for document in documents:
        group = document["source_group"]
        role = document["role"]
        if group in roles and roles[group] != role:
            raise ValueError(f"Source group{group} leaks across split roles")
        roles[group] = role


def sparse_instance_map(document: dict[str, Any], *, preview_only: bool = False) -> Any:
    """Unknown=-1 by default. Overlaps/ignore regions override positive polygons.

    Point labels supervise localization separately, never an invented filled mask.
    """
    if preview_only:
        validate_partial_labels(document)
    else:
        require_reviewed_labels(document)
    import cv2
    import numpy as np

    shape = document["image"]["height"], document["image"]["width"]
    labels = np.full(shape, -1, np.int32)
    for polygon in document["known_background_regions"]:
        background = np.zeros(shape, np.uint8)
        cv2.fillPoly(background, [np.round(polygon).astype(np.int32)], 1)
        labels[background > 0] = 0
    coverage = np.zeros(shape, np.int32)
    for instance in document["instances"]:
        local = np.zeros(shape, np.uint8)
        regions = (
            instance["visible_stem_positive_regions"]
            + instance["certain_branch_regions"]
            + instance["certain_crown_regions"]
        )
        for polygon in regions:
            cv2.fillPoly(local, [np.round(polygon).astype(np.int32)], 1)
        positive = local > 0
        labels[positive] = instance["local_id"]
        coverage[positive] += 1
    labels[coverage > 1] = -1
    for polygon in document["unknown_regions"]:
        ignored = np.zeros(shape, np.uint8)
        cv2.fillPoly(ignored, [np.round(polygon).astype(np.int32)], 1)
        labels[ignored > 0] = -1
    return labels


def sparse_stem_map(document: dict[str, Any], *, assistant_experiment: bool = False) -> Any:
    """Main visible-stem positives, explicit negatives, unknown=-1.

    Assistant draft bypass is explicit and forbidden for protected test labels.
    It does not approve a document or turn it into evaluation truth.
    """
    if assistant_experiment:
        validate_partial_labels(document)
        if document.get("role") == "protected_test":
            raise ValueError("Protected test drafts cannot be used by this experiment")
        if document.get("provenance") != "assistant_visual_draft":
            raise ValueError("Experiment requires explicit assistant draft provenance")
    else:
        require_reviewed_labels(document)
    import cv2
    import numpy as np

    shape = document["image"]["height"], document["image"]["width"]
    labels = np.full(shape, -1, np.int32)
    for polygon in document["known_background_regions"] + document.get("known_nonstem_regions", []):
        region = np.zeros(shape, np.uint8)
        cv2.fillPoly(region, [np.round(polygon).astype(np.int32)], 1)
        labels[region > 0] = 0
    for instance in document["instances"]:
        for polygon in instance["visible_stem_positive_regions"]:
            region = np.zeros(shape, np.uint8)
            cv2.fillPoly(region, [np.round(polygon).astype(np.int32)], 1)
            labels[region > 0] = 1
    for polygon in document["unknown_regions"]:
        region = np.zeros(shape, np.uint8)
        cv2.fillPoly(region, [np.round(polygon).astype(np.int32)], 1)
        labels[region > 0] = -1
    return labels
