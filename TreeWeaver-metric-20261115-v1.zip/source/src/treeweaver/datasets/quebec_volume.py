"""Adapter and published baselines for the Quebec destructive-volume dataset."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class QuebecTreeReference:
    site: str
    plot: str
    tree_id: str
    species: str
    dbh_ref_cm: float
    height_felled_ref_m: float
    operational_volume_ref_m3: float
    stem_volume_ref_m3: float
    branch_volume_ref_m3: float
    butt_volume_ref_m3: float
    operational_volume_allometry_m3: float
    dbh_mls_cm: float
    height_mls_m: float
    operational_volume_mls_m3: float
    stem_volume_mls_m3: float
    branch_volume_mls_m3: float
    butt_volume_mls_m3: float


def load_quebec_references(path: str | Path) -> tuple[QuebecTreeReference, ...]:
    """Load independent references and supplied comparison estimates with clear names."""

    rows: list[QuebecTreeReference] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as stream:
        for item in csv.DictReader(stream):
            rows.append(
                QuebecTreeReference(
                    site=item["Site"],
                    plot=item["Plot"],
                    tree_id=item["Tree"],
                    species=item["Species"],
                    dbh_ref_cm=float(item["DBH_ref_cm"]),
                    height_felled_ref_m=float(item["H_felled_ref_m"]),
                    operational_volume_ref_m3=float(item["Vop_ref_m3"]),
                    stem_volume_ref_m3=float(item["Vstem_ref_m3"]),
                    branch_volume_ref_m3=float(item["Vbranch_ref_m3"]),
                    butt_volume_ref_m3=float(item["Vbutt_ref_m3"]),
                    operational_volume_allometry_m3=float(item["Vop_allom_m3"]),
                    dbh_mls_cm=float(item["DBH_mls_FieldH_cm"]),
                    height_mls_m=float(item["H_mls_m"]),
                    operational_volume_mls_m3=float(item["Vop_mls_m3"]),
                    stem_volume_mls_m3=float(item["Vstem_mls_m3"]),
                    branch_volume_mls_m3=float(item["Vbranch_mls_m3"]),
                    butt_volume_mls_m3=float(item["Vbutt_mls_m3"]),
                )
            )
    if len(rows) != 98:
        raise ValueError(f"expected 98 Quebec validation trees, found {len(rows)}")
    if len({row.tree_id for row in rows}) != len(rows):
        raise ValueError("Quebec tree identifiers are not unique")
    return tuple(rows)


def _prediction(
    tree: QuebecTreeReference,
    parameter: str,
    truth: float,
    estimate: float,
) -> dict[str, object]:
    return {
        "tree_id": tree.tree_id,
        "session_id": tree.plot,
        "split": "external_test",
        "parameter": parameter,
        "truth": truth,
        "estimate": estimate,
        "standard_deviation": None,
        "confidence": 1.0,
        "strata": {"site": tree.site, "species": tree.species},
    }


def write_published_baselines(input_csv: str | Path, output_json: str | Path) -> int:
    """Emit supplied MLS/QSM and allometric estimates in TreeWeaver evaluation format."""

    trees = load_quebec_references(input_csv)
    predictions: list[dict[str, object]] = []
    for tree in trees:
        predictions.extend(
            (
                _prediction(tree, "dbh_mls_cm", tree.dbh_ref_cm, tree.dbh_mls_cm),
                _prediction(tree, "height_mls_m", tree.height_felled_ref_m, tree.height_mls_m),
                _prediction(
                    tree,
                    "operational_volume_mls_m3",
                    tree.operational_volume_ref_m3,
                    tree.operational_volume_mls_m3,
                ),
                _prediction(
                    tree,
                    "operational_volume_allometry_m3",
                    tree.operational_volume_ref_m3,
                    tree.operational_volume_allometry_m3,
                ),
                _prediction(
                    tree, "stem_volume_mls_m3", tree.stem_volume_ref_m3, tree.stem_volume_mls_m3
                ),
                _prediction(
                    tree,
                    "branch_volume_mls_m3",
                    tree.branch_volume_ref_m3,
                    tree.branch_volume_mls_m3,
                ),
                _prediction(
                    tree, "butt_volume_mls_m3", tree.butt_volume_ref_m3, tree.butt_volume_mls_m3
                ),
            )
        )
    destination = Path(output_json).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "dataset_key": "quebec-hardwood-volume-98-v1",
                "prediction_source": "upstream supplied MLS-QSM and allometric baselines",
                "predictions": predictions,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return len(trees)
