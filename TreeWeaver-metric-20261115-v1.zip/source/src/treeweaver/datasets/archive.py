"""Safe inventory and extraction helpers for external research archives."""

from __future__ import annotations

import json
import sys
import tarfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


@dataclass(frozen=True, slots=True)
class ArchiveInventory:
    file_count: int
    directory_count: int
    total_uncompressed_bytes: int
    top_level_entries: tuple[str, ...]


def _validated_members(archive: tarfile.TarFile, destination: Path) -> list[tarfile.TarInfo]:
    destination = destination.resolve()
    members = archive.getmembers()
    for member in members:
        logical = PurePosixPath(member.name)
        if logical.is_absolute() or ".." in logical.parts:
            raise ValueError(f"unsafe archive path: {member.name}")
        if member.issym() or member.islnk() or member.isdev():
            raise ValueError(f"unsupported archive link/device: {member.name}")
        target = (destination / Path(*logical.parts)).resolve()
        if destination != target and destination not in target.parents:
            raise ValueError(f"archive entry escapes destination: {member.name}")
    return members


def inspect_tar(path: Path) -> ArchiveInventory:
    """Inspect archive structure without extracting it."""

    with tarfile.open(path, "r:*") as archive:
        members = archive.getmembers()
    files = [member for member in members if member.isfile()]
    directories = [member for member in members if member.isdir()]
    top_level = sorted(
        {
            PurePosixPath(member.name).parts[0]
            for member in members
            if PurePosixPath(member.name).parts
        }
    )
    return ArchiveInventory(
        file_count=len(files),
        directory_count=len(directories),
        total_uncompressed_bytes=sum(member.size for member in files),
        top_level_entries=tuple(top_level),
    )


def write_inventory(path: Path, output: Path) -> ArchiveInventory:
    inventory = inspect_archive(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "archive": str(path.resolve()),
                "file_count": inventory.file_count,
                "directory_count": inventory.directory_count,
                "total_uncompressed_bytes": inventory.total_uncompressed_bytes,
                "top_level_entries": inventory.top_level_entries,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return inventory


def extract_tar_safely(path: Path, destination: Path) -> ArchiveInventory:
    """Extract regular files/directories after rejecting traversal and links."""

    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(path, "r:*") as archive:
        members = _validated_members(archive, destination)
        inventory = ArchiveInventory(
            file_count=sum(member.isfile() for member in members),
            directory_count=sum(member.isdir() for member in members),
            total_uncompressed_bytes=sum(member.size for member in members if member.isfile()),
            top_level_entries=tuple(
                sorted(
                    {
                        PurePosixPath(member.name).parts[0]
                        for member in members
                        if PurePosixPath(member.name).parts
                    }
                )
            ),
        )
        if sys.version_info >= (3, 12):
            archive.extractall(destination, members=members, filter="data")  # noqa: S202
        else:  # pragma: no cover - supported Python 3.11 compatibility
            archive.extractall(destination, members=members)  # noqa: S202
    return inventory


def _validated_zip_members(
    archive: zipfile.ZipFile, destination: Path
) -> list[zipfile.ZipInfo]:
    destination = destination.resolve()
    members = archive.infolist()
    for member in members:
        logical = PurePosixPath(member.filename)
        if logical.is_absolute() or ".." in logical.parts:
            raise ValueError(f"unsafe archive path: {member.filename}")
        target = (destination / Path(*logical.parts)).resolve()
        if destination != target and destination not in target.parents:
            raise ValueError(f"archive entry escapes destination: {member.filename}")
        unix_mode = (member.external_attr >> 16) & 0o170000
        if unix_mode == 0o120000:
            raise ValueError(f"unsupported archive link: {member.filename}")
    return members


def inspect_zip(path: Path) -> ArchiveInventory:
    """Inspect a ZIP archive without extracting it."""

    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
    files = [member for member in members if not member.is_dir()]
    directories = [member for member in members if member.is_dir()]
    top_level = sorted(
        {
            PurePosixPath(member.filename).parts[0]
            for member in members
            if PurePosixPath(member.filename).parts
        }
    )
    return ArchiveInventory(
        file_count=len(files),
        directory_count=len(directories),
        total_uncompressed_bytes=sum(member.file_size for member in files),
        top_level_entries=tuple(top_level),
    )


def extract_zip_safely(path: Path, destination: Path) -> ArchiveInventory:
    """Extract a ZIP after rejecting traversal and symbolic links."""

    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path) as archive:
        members = _validated_zip_members(archive, destination)
        inventory = ArchiveInventory(
            file_count=sum(not member.is_dir() for member in members),
            directory_count=sum(member.is_dir() for member in members),
            total_uncompressed_bytes=sum(
                member.file_size for member in members if not member.is_dir()
            ),
            top_level_entries=tuple(
                sorted(
                    {
                        PurePosixPath(member.filename).parts[0]
                        for member in members
                        if PurePosixPath(member.filename).parts
                    }
                )
            ),
        )
        for member in members:
            archive.extract(member, destination)
    return inventory


def inspect_archive(path: Path) -> ArchiveInventory:
    """Inspect a supported archive based on its actual container format."""

    if zipfile.is_zipfile(path):
        return inspect_zip(path)
    if tarfile.is_tarfile(path):
        return inspect_tar(path)
    raise ValueError(f"unsupported or invalid archive: {path}")


def extract_archive_safely(path: Path, destination: Path) -> ArchiveInventory:
    """Safely extract a supported ZIP or tar archive."""

    if zipfile.is_zipfile(path):
        return extract_zip_safely(path, destination)
    if tarfile.is_tarfile(path):
        return extract_tar_safely(path, destination)
    raise ValueError(f"unsupported or invalid archive: {path}")
