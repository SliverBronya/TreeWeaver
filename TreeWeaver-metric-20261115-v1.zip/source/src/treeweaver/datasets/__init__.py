"""Auditable external-dataset acquisition and staging."""

from treeweaver.datasets.registry import DatasetDescriptor, DatasetFile, get_dataset

__all__ = ["DatasetDescriptor", "DatasetFile", "get_dataset"]
