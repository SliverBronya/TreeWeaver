"""Format checks for the request-gated WHU-STree final release."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class WhuImagePose:
    image_filename: str
    x: float
    y: float
    z: float
    roll: float
    pitch: float
    heading: float


@dataclass(frozen=True, slots=True)
class WhuInventory:
    trajectory_files: int
    pose_records: int
    image_files: int
    point_cloud_files: int
    reference_files: int
    missing_pose_images: int


def read_trajectory(path: str | Path) -> tuple[WhuImagePose, ...]:
    """Read public WHU-STree pose rows, tolerating an optional header."""

    poses: list[WhuImagePose] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as stream:
        for line_number, row in enumerate(csv.reader(stream), start=1):
            if not row or all(not field.strip() for field in row):
                continue
            if len(row) != 7:
                raise ValueError(f"{path}:{line_number}: expected seven trajectory columns")
            try:
                coordinates = [float(value) for value in row[1:]]
            except ValueError:
                if not poses and line_number == 1:
                    continue
                raise ValueError(f"{path}:{line_number}: invalid numeric pose") from None
            poses.append(WhuImagePose(row[0], *coordinates))
    if not poses:
        raise ValueError(f"trajectory contains no poses: {path}")
    return tuple(poses)


def _ply_properties(path: Path) -> set[str]:
    properties: set[str] = set()
    with path.open("rb") as stream:
        for raw_line in stream:
            line = raw_line.decode("ascii", errors="strict").strip()
            if line == "end_header":
                return properties
            if line.startswith("property "):
                properties.add(line.split()[-1])
    raise ValueError(f"PLY header has no end_header: {path}")


def inspect_whu_release(root: str | Path, output_json: str | Path) -> WhuInventory:
    """Check release structure and RGB/pose/point-cloud linkage without loading arrays."""

    root_path = Path(root).resolve()
    trajectory_files = sorted(root_path.glob("*/hdi/*/traj.csv"))
    point_cloud_files = sorted(root_path.glob("*/PCD/*.ply"))
    image_files = sorted(root_path.glob("*/image/*/*.jpg"))
    reference_files = sorted(root_path.glob("reference_data/*.npy"))
    if not trajectory_files or not point_cloud_files or not image_files:
        raise ValueError("WHU-STree release is missing trajectories, images, or point clouds")

    expected_properties = {"x", "y", "z", "intensity", "tree", "label"}
    for point_cloud in point_cloud_files:
        missing = expected_properties - _ply_properties(point_cloud)
        if missing:
            raise ValueError(f"{point_cloud} missing PLY properties: {sorted(missing)}")

    image_names = {path.name for path in image_files}
    poses = tuple(pose for path in trajectory_files for pose in read_trajectory(path))
    missing_pose_images = sum(pose.image_filename not in image_names for pose in poses)
    inventory = WhuInventory(
        trajectory_files=len(trajectory_files),
        pose_records=len(poses),
        image_files=len(image_files),
        point_cloud_files=len(point_cloud_files),
        reference_files=len(reference_files),
        missing_pose_images=missing_pose_images,
    )
    destination = Path(output_json).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "dataset_key": "whu-stree-2026",
                "inventory": asdict(inventory),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return inventory
