"""One-command, fail-closed TreeWeaver research pipeline."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from treeweaver.association.bundle import associate_instance_bundle
from treeweaver.association.root_bundle import separate_root_bundle
from treeweaver.association.root_clicks import triangulate_root_click_file
from treeweaver.calibration.marker_bundle import register_aruco_scale
from treeweaver.calibration.scale_file import estimate_scale_file
from treeweaver.factor.bundle import optimize_tree_factor_bundle
from treeweaver.io.raw_capture import ingest_raw_capture, load_raw_capture
from treeweaver.io.session import load_capture_session
from treeweaver.measurement.bundle import measure_semantic_bundle
from treeweaver.pipeline.journal import initialize_journal, record_stage
from treeweaver.pipeline.plan import Stage
from treeweaver.providers.colmap_runner import ColmapConfig, ColmapRunner
from treeweaver.providers.external_worker import (
    load_external_worker_config,
    run_external_vision_worker,
)
from treeweaver.reconstruction.quality import assess_reconstruction_quality, write_quality_report
from treeweaver.reporting.final_report import build_final_report
from treeweaver.semantics.bundle import fuse_semantic_bundle
from treeweaver.semantics.root_refinement import refine_semantic_bundle_by_roots
from treeweaver.species.file_fusion import fuse_species_file


@dataclass(frozen=True, slots=True)
class FullPipelineConfig:
    run_id: str
    raw_capture_manifest: Path
    output_directory: Path
    vision_worker_config: Path
    colmap_executable: str = "colmap"
    colmap_use_gpu: bool = True
    sample_hz: float = 2.0
    max_frames: int = 240
    marker_id: int | None = None
    marker_edge_length_m: float | None = None
    marker_dictionary: str = "4x4_50"
    species_evidence_json: Path | None = None
    root_clicks_json: Path | None = None


@dataclass(frozen=True, slots=True)
class FullPipelineResult:
    status: str
    output_directory: Path
    final_report: Path | None
    journal: Path
    reason: str | None = None


def _resolved(base: Path, value: str) -> Path:
    path = Path(value)
    return (base / path).resolve() if not path.is_absolute() else path.resolve()


def load_full_pipeline_config(path: str | Path) -> FullPipelineConfig:
    config_path = Path(path).resolve()
    payload: dict[str, Any] = json.loads(config_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "treeweaver-full-run-1.0":
        raise ValueError("unsupported full-pipeline configuration schema")
    base = config_path.parent
    species = payload.get("species_evidence_json")
    root_clicks = payload.get("root_clicks_json")
    config = FullPipelineConfig(
        run_id=str(payload["run_id"]),
        raw_capture_manifest=_resolved(base, str(payload["raw_capture_manifest"])),
        output_directory=_resolved(base, str(payload["output_directory"])),
        vision_worker_config=_resolved(base, str(payload["vision_worker_config"])),
        colmap_executable=str(payload.get("colmap_executable", "colmap")),
        colmap_use_gpu=bool(payload.get("colmap_use_gpu", True)),
        sample_hz=float(payload.get("sample_hz", 2.0)),
        max_frames=int(payload.get("max_frames", 240)),
        marker_id=(int(payload["marker_id"]) if payload.get("marker_id") is not None else None),
        marker_edge_length_m=(
            float(payload["marker_edge_length_m"])
            if payload.get("marker_edge_length_m") is not None
            else None
        ),
        marker_dictionary=str(payload.get("marker_dictionary", "4x4_50")),
        species_evidence_json=(_resolved(base, str(species)) if species is not None else None),
        root_clicks_json=(
            _resolved(base, str(root_clicks)) if root_clicks is not None else None
        ),
    )
    if not config.run_id.strip():
        raise ValueError("run_id cannot be empty")
    if config.sample_hz <= 0:
        raise ValueError("sample_hz must be positive")
    if config.max_frames < 2:
        raise ValueError("max_frames must be at least 2")
    if config.marker_edge_length_m is not None and config.marker_edge_length_m <= 0:
        raise ValueError("marker_edge_length_m must be positive")
    return config


def _write_status(output: Path, status: str, reason: str | None = None) -> Path:
    path = output / "run-status.json"
    path.write_text(
        json.dumps(
            {"schema_version": "treeweaver-run-status-1.0", "status": status, "reason": reason},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def run_full_pipeline(config: FullPipelineConfig) -> FullPipelineResult:
    """Execute a fresh run; every accepted stage is recorded in the journal."""

    output = config.output_directory.resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    journal = initialize_journal(output / "run-journal.json", config.run_id)
    raw = load_raw_capture(config.raw_capture_manifest)
    record_stage(
        journal,
        Stage.CAPTURE,
        (config.raw_capture_manifest,),
        configuration={"session_id": raw.session_id},
    )

    ingestion = ingest_raw_capture(
        config.raw_capture_manifest,
        output / "ingested",
        sample_hz=config.sample_hz,
        max_frames=config.max_frames,
    )
    capture_manifest = ingestion.manifest_path
    record_stage(journal, Stage.INGEST, (capture_manifest,))

    reconstruction_directory = output / "reconstruction"
    runner = ColmapRunner(
        ColmapConfig(
            executable=config.colmap_executable,
            use_gpu=config.colmap_use_gpu,
            dense=True,
        )
    )
    reconstruction = runner.reconstruct(capture_manifest, reconstruction_directory)
    expected_images = len(load_capture_session(capture_manifest).session.frames)
    reconstruction_quality = assess_reconstruction_quality(reconstruction, expected_images)
    quality_json = write_quality_report(
        reconstruction_quality, reconstruction_directory / "quality.json"
    )
    dense_cloud = reconstruction_directory / "fused.ply"
    text_model = reconstruction_directory / "text-model"
    record_stage(
        journal,
        Stage.RECONSTRUCTION,
        (
            quality_json,
            text_model / "images.txt",
            text_model / "points3D.txt",
            dense_cloud,
        ),
        configuration={"passed_quality_gate": reconstruction_quality.passed},
    )
    if not reconstruction_quality.passed:
        reason = "; ".join(reconstruction_quality.issues)
        _write_status(output, "halted_reconstruction_quality", reason)
        return FullPipelineResult(
            "halted_reconstruction_quality", output, None, journal, reason
        )

    marker_id = config.marker_id if config.marker_id is not None else raw.anchor_marker_id
    marker_length = (
        config.marker_edge_length_m
        if config.marker_edge_length_m is not None
        else raw.anchor_length_m
    )
    marker_dictionary = raw.anchor_dictionary or config.marker_dictionary
    if marker_id is None:
        reason = "full automatic run requires a coded marker id"
        _write_status(output, "halted_scale_anchor", reason)
        return FullPipelineResult("halted_scale_anchor", output, None, journal, reason)
    anchors_json = register_aruco_scale(
        capture_manifest,
        text_model,
        output / "anchors.json",
        marker_id=marker_id,
        edge_length_m=marker_length,
        dictionary=marker_dictionary,
    )
    scale_json = estimate_scale_file(anchors_json, output / "scale.json")
    root_anchors_json: Path | None = None
    if config.root_clicks_json is not None:
        root_click_run = triangulate_root_click_file(
            capture_manifest,
            text_model,
            config.root_clicks_json,
            output / "root-anchors.json",
            dense_point_cloud=dense_cloud,
        )
        root_anchors_json = root_click_run.output_path

    evidence = run_external_vision_worker(
        load_external_worker_config(config.vision_worker_config),
        capture_manifest,
        output / "evidence",
    )
    record_stage(journal, Stage.INSTANCE_EVIDENCE, (evidence.observation_manifest,))
    record_stage(journal, Stage.PART_EVIDENCE, (evidence.observation_manifest,))

    association = associate_instance_bundle(
        capture_manifest,
        text_model,
        dense_cloud,
        evidence.observation_manifest,
        output / "tracks",
    )
    record_stage(
        journal,
        Stage.ASSOCIATION,
        (
            association.output_directory / "tracks.json",
            association.output_directory / "track-points.npz",
        ),
    )
    semantic = fuse_semantic_bundle(
        capture_manifest,
        text_model,
        dense_cloud,
        evidence.observation_manifest,
        association.output_directory,
        output / "semantics",
    )
    scale_payload = json.loads(scale_json.read_text(encoding="utf-8"))
    semantic_directory = semantic.output_directory
    semantic_artifacts = [
        semantic.output_directory / "semantics.json",
        semantic.output_directory / "semantic-points.npz",
    ]
    if root_anchors_json is not None:
        scale_value = float(scale_payload["metres_per_unit"])
        root_assignment = separate_root_bundle(
            dense_cloud,
            root_anchors_json,
            output / "root-assignment",
            trunk_probability_npz=semantic.output_directory / "semantic-points.npz",
            candidate_indices_npz=association.output_directory / "track-points.npz",
            ground_indices_npz=semantic.output_directory / "semantic-points.npz",
            maximum_edge_length=0.45 / scale_value,
            maximum_root_distance=0.35 / scale_value,
        )
        refined = refine_semantic_bundle_by_roots(
            semantic.output_directory,
            root_assignment.output_directory,
            output / "root-semantics",
        )
        semantic_directory = refined.output_directory
        semantic_artifacts.extend(
            (
                root_anchors_json,
                root_assignment.output_directory / "root-assignment.json",
                root_assignment.output_directory / "root-assignment.npz",
                refined.output_directory / "semantics.json",
                refined.output_directory / "semantic-points.npz",
            )
        )
    record_stage(
        journal,
        Stage.SEMANTIC_FUSION,
        tuple(semantic_artifacts),
        configuration={"root_topology_enabled": root_anchors_json is not None},
    )
    crown_results = measure_semantic_bundle(
        dense_cloud,
        semantic_directory,
        output / "crown-results.json",
        metres_per_unit=float(scale_payload["metres_per_unit"]),
        scale_standard_deviation=float(scale_payload["standard_deviation"]),
    )
    factor_results = optimize_tree_factor_bundle(
        dense_cloud,
        semantic_directory,
        anchors_json,
        output / "factor-results.json",
    )
    record_stage(journal, Stage.FACTOR_OPTIMIZATION, (factor_results.output_path,))

    species_results: Path | None = None
    if config.species_evidence_json is not None:
        species_run = fuse_species_file(
            config.species_evidence_json, output / "species-results.json"
        )
        species_results = species_run.output_path
        record_stage(journal, Stage.SPECIES_FUSION, (species_results,))

    final = build_final_report(
        capture_manifest,
        quality_json,
        factor_results.output_path,
        output / "final-report.json",
        crown_results_json=crown_results.output_path,
        species_results_json=species_results,
    )
    record_stage(journal, Stage.QUALITY_DECISION, (final.output_path,))
    _write_status(output, "complete")
    return FullPipelineResult("complete", output, final.output_path, journal)
