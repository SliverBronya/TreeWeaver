"""Input-adaptive identifiability before any model is allowed to estimate a parameter."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from treeweaver.domain.models import CaptureSession, Parameter


class InputMode(StrEnum):
    SINGLE_RGB = "single_rgb"
    UNORDERED_RGB = "unordered_rgb"
    METRIC_RGBD = "metric_rgbd"


class Identifiability(StrEnum):
    DIRECT = "direct"
    CONDITIONAL = "conditional"
    NOT_IDENTIFIABLE = "not_identifiable"


@dataclass(frozen=True, slots=True)
class ParameterIdentifiability:
    parameter: Parameter
    level: Identifiability
    reason: str


@dataclass(frozen=True, slots=True)
class InputAssessment:
    mode: InputMode
    user_supplied_camera_relationships: bool
    parameters: tuple[ParameterIdentifiability, ...]


def assess_input(session: CaptureSession) -> InputAssessment:
    """State what the supplied RGB input can support without inventing geometry."""

    if session.capabilities.has_metric_depth:
        mode = InputMode.METRIC_RGBD
    elif len(session.frames) == 1:
        mode = InputMode.SINGLE_RGB
    else:
        mode = InputMode.UNORDERED_RGB

    if mode is InputMode.SINGLE_RGB:
        levels = {
            Parameter.HEIGHT_M: (
                Identifiability.CONDITIONAL,
                "requires visible root and apex plus a colocated reference/vertical constraint",
            ),
            Parameter.DBH_CM: (
                Identifiability.CONDITIONAL,
                "requires a clean trunk section and reference at comparable depth",
            ),
            Parameter.CROWN_WIDTH_M: (
                Identifiability.CONDITIONAL,
                "only the visible image-plane crown span is constrained",
            ),
            Parameter.CROWN_DEPTH_M: (
                Identifiability.NOT_IDENTIFIABLE,
                "one RGB projection does not observe front-to-back crown depth",
            ),
            Parameter.CROWN_HEIGHT_M: (
                Identifiability.CONDITIONAL,
                "requires visible crown base and apex under the vertical-plane constraint",
            ),
            Parameter.CROWN_VOLUME_M3: (
                Identifiability.NOT_IDENTIFIABLE,
                "hidden crown depth and occluded boundary are not determined by one projection",
            ),
            Parameter.VOLUME_M3: (
                Identifiability.NOT_IDENTIFIABLE,
                "direct stem volume needs taper or multiple sections; "
                "allometry is a separate estimate",
            ),
            Parameter.BIOMASS_KG: (
                Identifiability.NOT_IDENTIFIABLE,
                "biomass additionally requires species/wood-density and an allometric model",
            ),
        }
    else:
        geometry_reason = (
            "system must recover camera poses automatically and pass scale, visibility, "
            "and uncertainty gates"
        )
        levels = {
            parameter: (Identifiability.CONDITIONAL, geometry_reason)
            for parameter in Parameter
        }
        if mode is InputMode.METRIC_RGBD:
            levels[Parameter.HEIGHT_M] = (
                Identifiability.DIRECT,
                "metric depth supplies scale, subject to depth confidence and visibility",
            )
            levels[Parameter.DBH_CM] = (
                Identifiability.DIRECT,
                "metric depth supplies scale, subject to section coverage",
            )
    return InputAssessment(
        mode,
        False,
        tuple(
            ParameterIdentifiability(parameter, *levels[parameter])
            for parameter in Parameter
        ),
    )
