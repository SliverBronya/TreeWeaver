"""Deterministic stage graph for one TreeWeaver research run."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class Stage(StrEnum):
    CAPTURE = "capture"
    INGEST = "ingest"
    RECONSTRUCTION = "reconstruction"
    INSTANCE_EVIDENCE = "instance_evidence"
    ASSOCIATION = "association"
    PART_EVIDENCE = "part_evidence"
    SEMANTIC_FUSION = "semantic_fusion"
    FACTOR_OPTIMIZATION = "factor_optimization"
    SPECIES_FUSION = "species_fusion"
    QUALITY_DECISION = "quality_decision"
    EVALUATION = "evaluation"


_DEPENDENCIES: dict[Stage, tuple[Stage, ...]] = {
    Stage.CAPTURE: (),
    Stage.INGEST: (Stage.CAPTURE,),
    Stage.RECONSTRUCTION: (Stage.INGEST,),
    Stage.INSTANCE_EVIDENCE: (Stage.INGEST,),
    Stage.ASSOCIATION: (Stage.RECONSTRUCTION, Stage.INSTANCE_EVIDENCE),
    Stage.PART_EVIDENCE: (Stage.INGEST, Stage.INSTANCE_EVIDENCE),
    Stage.SEMANTIC_FUSION: (Stage.ASSOCIATION, Stage.PART_EVIDENCE),
    Stage.FACTOR_OPTIMIZATION: (Stage.SEMANTIC_FUSION,),
    Stage.SPECIES_FUSION: (Stage.PART_EVIDENCE,),
    Stage.QUALITY_DECISION: (Stage.FACTOR_OPTIMIZATION,),
    Stage.EVALUATION: (Stage.QUALITY_DECISION,),
}


@dataclass(frozen=True, slots=True)
class StageState:
    stage: Stage
    complete: bool
    artifacts: tuple[Path, ...] = ()
    blockers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PipelinePlan:
    states: tuple[StageState, ...]

    @property
    def ready_stages(self) -> tuple[Stage, ...]:
        completed = {state.stage for state in self.states if state.complete}
        blocked = {state.stage for state in self.states if state.blockers}
        return tuple(
            stage
            for stage in Stage
            if stage not in completed
            and stage not in blocked
            and all(dependency in completed for dependency in _DEPENDENCIES[stage])
        )

    @property
    def complete(self) -> bool:
        return all(state.complete for state in self.states)


def audit_pipeline(states: tuple[StageState, ...]) -> PipelinePlan:
    """Validate state consistency and expose the next runnable stages."""

    by_stage = {state.stage: state for state in states}
    if len(by_stage) != len(states):
        raise ValueError("pipeline contains duplicate stage states")
    missing = set(Stage) - set(by_stage)
    if missing:
        names = ", ".join(sorted(stage.value for stage in missing))
        raise ValueError(f"pipeline is missing stage states: {names}")
    for state in states:
        if state.complete and state.blockers:
            raise ValueError(f"completed stage {state.stage.value} cannot have blockers")
        if state.complete:
            incomplete = [
                dependency.value
                for dependency in _DEPENDENCIES[state.stage]
                if not by_stage[dependency].complete
            ]
            if incomplete:
                raise ValueError(
                    f"stage {state.stage.value} is complete before dependencies: "
                    + ", ".join(incomplete)
                )
        for artifact in state.artifacts:
            if state.complete and not artifact.exists():
                raise FileNotFoundError(
                    f"completed stage {state.stage.value} is missing artifact: {artifact}"
                )
    return PipelinePlan(tuple(sorted(states, key=lambda item: list(Stage).index(item.stage))))
