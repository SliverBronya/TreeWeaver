"""Append-only, checksum-backed journal for resumable research runs."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from treeweaver.pipeline.plan import Stage


@dataclass(frozen=True, slots=True)
class ArtifactRecord:
    path: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True, slots=True)
class StageRecord:
    stage: Stage
    completed_at_utc: str
    configuration: dict[str, object]
    artifacts: tuple[ArtifactRecord, ...]


_DEPENDENCIES: dict[Stage, tuple[Stage, ...]] = {
    Stage.CAPTURE: (),
    Stage.INGEST: (Stage.CAPTURE,),
    Stage.RECONSTRUCTION: (Stage.INGEST,),
    Stage.INSTANCE_EVIDENCE: (Stage.INGEST,),
    Stage.ASSOCIATION: (Stage.RECONSTRUCTION, Stage.INSTANCE_EVIDENCE),
    Stage.PART_EVIDENCE: (Stage.INGEST, Stage.INSTANCE_EVIDENCE),
    Stage.SEMANTIC_FUSION: (Stage.ASSOCIATION, Stage.PART_EVIDENCE),
    Stage.FACTOR_OPTIMIZATION: (Stage.SEMANTIC_FUSION,),
    Stage.SPECIES_FUSION: (Stage.PART_EVIDENCE,),
    Stage.QUALITY_DECISION: (Stage.FACTOR_OPTIMIZATION,),
    Stage.EVALUATION: (Stage.QUALITY_DECISION,),
}


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _artifact(path: Path) -> ArtifactRecord:
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(resolved)
    return ArtifactRecord(str(resolved), resolved.stat().st_size, _hash_file(resolved))


def initialize_journal(path: str | Path, run_id: str) -> Path:
    destination = Path(path).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    if not run_id:
        raise ValueError("run id cannot be empty")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {"schema_version": "treeweaver-run-1.0", "run_id": run_id, "stages": []},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return destination


def record_stage(
    journal: str | Path,
    stage: Stage,
    artifacts: tuple[Path, ...],
    *,
    configuration: dict[str, object] | None = None,
) -> StageRecord:
    path = Path(journal).resolve()
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "treeweaver-run-1.0":
        raise ValueError("unsupported run journal schema")
    completed = {Stage(item["stage"]) for item in payload["stages"]}
    if stage in completed:
        raise ValueError(f"stage {stage.value} is already recorded")
    missing = [
        dependency.value
        for dependency in _DEPENDENCIES[stage]
        if dependency not in completed
    ]
    if missing:
        raise ValueError(f"stage {stage.value} is missing dependencies: {', '.join(missing)}")
    record = StageRecord(
        stage,
        datetime.now(UTC).isoformat(),
        configuration or {},
        tuple(_artifact(artifact) for artifact in artifacts),
    )
    payload["stages"].append(asdict(record))
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)
    return record


def verify_journal(journal: str | Path) -> tuple[StageRecord, ...]:
    """Re-hash every artifact and reject changed or missing intermediates."""

    payload: dict[str, Any] = json.loads(Path(journal).read_text(encoding="utf-8"))
    records: list[StageRecord] = []
    completed: set[Stage] = set()
    for item in payload.get("stages", []):
        stage = Stage(item["stage"])
        if stage in completed or any(dep not in completed for dep in _DEPENDENCIES[stage]):
            raise ValueError(f"invalid stage order at {stage.value}")
        artifacts = tuple(ArtifactRecord(**artifact) for artifact in item["artifacts"])
        for artifact in artifacts:
            path = Path(artifact.path)
            if not path.is_file() or path.stat().st_size != artifact.size_bytes:
                raise ValueError(f"artifact changed or missing: {path}")
            if _hash_file(path) != artifact.sha256:
                raise ValueError(f"artifact checksum mismatch: {path}")
        records.append(
            StageRecord(stage, item["completed_at_utc"], item["configuration"], artifacts)
        )
        completed.add(stage)
    return tuple(records)
