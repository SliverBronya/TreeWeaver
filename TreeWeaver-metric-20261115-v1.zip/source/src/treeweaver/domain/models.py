"""Versioned, dependency-free domain models.

The core deliberately avoids framework-specific schemas. API and storage layers
translate these dataclasses at their boundaries, keeping research algorithms
testable and portable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from math import isfinite


class DepthSource(StrEnum):
    NONE = "none"
    MONOCULAR = "monocular"
    ARCORE = "arcore"
    TOF = "tof"
    LIDAR = "lidar"


class Parameter(StrEnum):
    HEIGHT_M = "height_m"
    DBH_CM = "dbh_cm"
    CROWN_WIDTH_M = "crown_width_m"
    CROWN_DEPTH_M = "crown_depth_m"
    CROWN_HEIGHT_M = "crown_height_m"
    CROWN_VOLUME_M3 = "crown_volume_m3"
    VOLUME_M3 = "volume_m3"
    BIOMASS_KG = "biomass_kg"


@dataclass(frozen=True, slots=True)
class CameraIntrinsics:
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int

    def __post_init__(self) -> None:
        if min(self.fx, self.fy) <= 0 or min(self.width, self.height) <= 0:
            raise ValueError("focal lengths and image dimensions must be positive")
        if not all(isfinite(v) for v in (self.fx, self.fy, self.cx, self.cy)):
            raise ValueError("intrinsics must be finite")


@dataclass(frozen=True, slots=True)
class DeviceCapabilities:
    has_imu: bool = True
    has_arcore: bool = False
    has_metric_depth: bool = False
    depth_source: DepthSource = DepthSource.NONE

    def __post_init__(self) -> None:
        if self.has_metric_depth and self.depth_source is DepthSource.NONE:
            raise ValueError("metric depth capability requires a depth source")


@dataclass(frozen=True, slots=True)
class ScaleAnchor:
    """One independent relationship between reconstructed and metric length."""

    kind: str
    metric_length_m: float
    reconstructed_length: float | None = None
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if self.metric_length_m <= 0:
            raise ValueError("anchor metric length must be positive")
        if self.reconstructed_length is not None and self.reconstructed_length <= 0:
            raise ValueError("anchor reconstructed length must be positive when available")
        if not 0 < self.confidence <= 1:
            raise ValueError("anchor confidence must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class FrameObservation:
    frame_id: str
    timestamp_ns: int
    image_path: str
    intrinsics: CameraIntrinsics
    azimuth_deg: float | None = None
    elevation_deg: float | None = None
    blur_score: float | None = None
    tree_coverage: float | None = None
    occlusion_ratio: float | None = None
    depth_path: str | None = None
    depth_confidence_path: str | None = None
    depth_unit_m: float = 0.001
    camera_to_world: tuple[float, ...] | None = None
    tracking_state: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp_ns < 0:
            raise ValueError("timestamp cannot be negative")
        for name in ("blur_score", "tree_coverage", "occlusion_ratio"):
            value = getattr(self, name)
            if value is not None and not 0 <= value <= 1:
                raise ValueError(f"{name} must be in [0, 1]")
        if self.depth_unit_m <= 0 or not isfinite(self.depth_unit_m):
            raise ValueError("depth_unit_m must be finite and positive")
        if (self.depth_path is None) != (self.depth_confidence_path is None):
            raise ValueError("metric depth and confidence paths must be provided together")
        if self.camera_to_world is not None:
            if len(self.camera_to_world) != 16 or not all(
                isfinite(value) for value in self.camera_to_world
            ):
                raise ValueError("camera_to_world must contain 16 finite row-major values")
            if any(abs(value - expected) > 1e-6 for value, expected in zip(
                self.camera_to_world[12:], (0.0, 0.0, 0.0, 1.0), strict=True
            )):
                raise ValueError("camera_to_world must be a homogeneous rigid transform")


@dataclass(frozen=True, slots=True)
class CaptureSession:
    schema_version: str
    session_id: str
    device_id: str
    capabilities: DeviceCapabilities
    frames: tuple[FrameObservation, ...] = ()
    anchors: tuple[ScaleAnchor, ...] = ()
    gravity_down_world: tuple[float, float, float] | None = None

    def __post_init__(self) -> None:
        if self.schema_version not in {"1.0", "2.0"}:
            raise ValueError(f"unsupported capture schema: {self.schema_version}")
        if len({frame.frame_id for frame in self.frames}) != len(self.frames):
            raise ValueError("frame ids must be unique within a session")
        if self.gravity_down_world is not None:
            if not all(isfinite(value) for value in self.gravity_down_world):
                raise ValueError("gravity_down_world must be finite")
            if sum(value * value for value in self.gravity_down_world) <= 1e-12:
                raise ValueError("gravity_down_world cannot be zero")


@dataclass(frozen=True, slots=True)
class ScalarObservation:
    value: float
    standard_deviation: float
    reliability: float
    source: str
    view_id: str

    def __post_init__(self) -> None:
        if not isfinite(self.value) or self.standard_deviation <= 0:
            raise ValueError("observation value must be finite and deviation positive")
        if not 0 < self.reliability <= 1:
            raise ValueError("reliability must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class ParameterEstimate:
    parameter: Parameter
    value: float
    standard_deviation: float
    confidence: float
    observation_count: int
    diagnostics: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.standard_deviation < 0 or not 0 <= self.confidence <= 1:
            raise ValueError("invalid estimate uncertainty")
        if self.observation_count < 1:
            raise ValueError("an estimate requires at least one observation")


@dataclass(frozen=True, slots=True)
class TreeMeasurement:
    tree_id: str
    estimates: dict[Parameter, ParameterEstimate] = field(default_factory=dict)
    species_candidates: tuple[tuple[str, float], ...] = ()
    requires_more_capture: bool = False
    next_capture_instruction: str | None = None
