"""Apply user-registered allometry without pretending it is universal."""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, log, sqrt


@dataclass(frozen=True, slots=True)
class AllometricEquation:
    equation_id: str
    species: str
    region: str
    citation: str
    intercept: float
    dbh_exponent: float
    height_exponent: float
    residual_log_sd: float
    output_unit: str

    def __post_init__(self) -> None:
        if not all((self.equation_id, self.species, self.region, self.citation, self.output_unit)):
            raise ValueError("allometric equations require scope and citation")
        if self.residual_log_sd < 0:
            raise ValueError("allometric residual deviation cannot be negative")


@dataclass(frozen=True, slots=True)
class AllometricResult:
    value: float
    standard_deviation: float
    unit: str
    equation_id: str
    citation: str
    diagnostics: tuple[str, ...]


def apply_allometry(
    equation: AllometricEquation,
    *,
    species: str,
    region: str,
    dbh_cm: float,
    dbh_sd_cm: float,
    height_m: float,
    height_sd_m: float,
) -> AllometricResult:
    """Evaluate ``exp(a) * DBH^b * H^c`` with delta-method uncertainty."""

    if species.casefold() != equation.species.casefold():
        raise ValueError("species does not match the registered allometric equation")
    if region.casefold() != equation.region.casefold():
        raise ValueError("region does not match the registered allometric equation")
    if min(dbh_cm, height_m) <= 0 or min(dbh_sd_cm, height_sd_m) < 0:
        raise ValueError("measurements must be positive and deviations non-negative")
    log_value = (
        equation.intercept
        + equation.dbh_exponent * log(dbh_cm)
        + equation.height_exponent * log(height_m)
    )
    value = exp(log_value)
    log_variance = (
        (equation.dbh_exponent * dbh_sd_cm / dbh_cm) ** 2
        + (equation.height_exponent * height_sd_m / height_m) ** 2
        + equation.residual_log_sd**2
    )
    standard_deviation = value * sqrt(log_variance)
    return AllometricResult(
        value,
        standard_deviation,
        equation.output_unit,
        equation.equation_id,
        equation.citation,
        ("equation valid only for the registered species and region",),
    )
