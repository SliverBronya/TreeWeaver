"""Provenance-locked forestry equations."""

from treeweaver.forestry.allometry import AllometricEquation, AllometricResult, apply_allometry

__all__ = ["AllometricEquation", "AllometricResult", "apply_allometry"]
