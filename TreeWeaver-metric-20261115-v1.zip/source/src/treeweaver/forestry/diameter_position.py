"""Auditable forestry rules for non-standard diameter measurement positions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class DiameterCase(StrEnum):
    STANDARD = "standard"
    LOW_FORK = "low_fork"
    MID_FORK = "mid_fork"
    FORK_AT_BREAST_HEIGHT = "fork_at_breast_height"
    BUTTRESS = "buttress"
    AERIAL_ROOTS = "aerial_roots"
    IRREGULAR_AT_BREAST_HEIGHT = "irregular_at_breast_height"


@dataclass(frozen=True, slots=True)
class StemFormEvidence:
    """Geometry-derived special-form evidence in metres along the stem path."""

    fork_origin_m: float | None = None
    stem_count_above_fork: int = 1
    buttress_top_m: float | None = None
    aerial_root_top_m: float | None = None
    irregularity_interval_m: tuple[float, float] | None = None
    leaning: bool = False
    sloping_ground: bool = False

    def __post_init__(self) -> None:
        for name in ("fork_origin_m", "buttress_top_m", "aerial_root_top_m"):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(f"{name} cannot be negative")
        if self.fork_origin_m is not None and self.stem_count_above_fork < 2:
            raise ValueError("fork evidence requires at least two stems")
        if self.fork_origin_m is None and self.stem_count_above_fork != 1:
            raise ValueError("multiple stems require a fork origin")
        if self.irregularity_interval_m is not None:
            start, end = self.irregularity_interval_m
            if start < 0 or end <= start:
                raise ValueError("irregularity interval must be ordered and non-negative")


@dataclass(frozen=True, slots=True)
class DiameterPlane:
    stem_number: int
    height_along_stem_m: float


@dataclass(frozen=True, slots=True)
class DiameterMeasurementPlan:
    case: DiameterCase
    entity_count: int
    planes: tuple[DiameterPlane, ...]
    aggregation: str
    ground_reference: str
    distance_reference: str
    rule: str
    diagnostics: tuple[str, ...] = ()


def _plane(height: float, stem_count: int = 1) -> tuple[DiameterPlane, ...]:
    if height <= 0:
        raise ValueError("diameter measurement height must be positive")
    return tuple(DiameterPlane(index, height) for index in range(1, stem_count + 1))


def plan_diameter_measurement(
    evidence: StemFormEvidence,
    *,
    breast_height_m: float = 1.3,
    irregularity_clearance_m: float = 0.1,
) -> DiameterMeasurementPlan:
    """Select diameter planes without silently applying the ordinary DBH rule.

    The policy follows the FAO field-manual cases. Conflicting base anomalies
    are rejected because they require an explicit national inventory protocol.
    """

    if breast_height_m <= 0 or irregularity_clearance_m <= 0:
        raise ValueError("measurement heights and clearances must be positive")
    base_cases = sum(
        value is not None for value in (evidence.buttress_top_m, evidence.aerial_root_top_m)
    )
    if base_cases > 1:
        raise ValueError("buttress and aerial-root rules cannot be combined automatically")
    if evidence.fork_origin_m is not None and base_cases:
        raise ValueError("combined fork and root/buttress forms require expert review")

    ground_reference = "uphill_ground_contact" if evidence.sloping_ground else "root_ground_contact"
    distance_reference = "along_leaning_stem_axis" if evidence.leaning else "along_stem_axis"
    diagnostics: list[str] = []
    if evidence.sloping_ground:
        diagnostics.append("ground height is taken from the uphill side")
    if evidence.leaning:
        diagnostics.append("height is measured along the leaning stem, not vertically")

    if evidence.fork_origin_m is not None:
        fork = evidence.fork_origin_m
        stems = evidence.stem_count_above_fork
        if fork < 0.3:
            return DiameterMeasurementPlan(
                DiameterCase.LOW_FORK,
                stems,
                _plane(breast_height_m, stems),
                "report_each_stem_as_separate_tree",
                ground_reference,
                distance_reference,
                "FAO: fork below 0.3 m; measure each stem at breast height",
                tuple(diagnostics),
            )
        if fork < breast_height_m:
            return DiameterMeasurementPlan(
                DiameterCase.MID_FORK,
                stems,
                _plane(fork + 1.0, stems),
                "report_each_stem_as_separate_tree",
                ground_reference,
                distance_reference,
                "FAO: fork between 0.3 m and breast height; measure 1 m above fork",
                tuple(diagnostics),
            )
        height = breast_height_m
        if fork <= breast_height_m + 0.2:
            height = fork - irregularity_clearance_m
            diagnostics.append("measurement moved just below fork swelling")
        return DiameterMeasurementPlan(
            DiameterCase.FORK_AT_BREAST_HEIGHT,
            1,
            _plane(height),
            "single_tree",
            ground_reference,
            distance_reference,
            "FAO: fork at or above breast height; measure the common bole below swelling",
            tuple(diagnostics),
        )

    target_height = breast_height_m
    case = DiameterCase.STANDARD
    rule = "FAO: ordinary diameter at 1.3 m"
    if evidence.buttress_top_m is not None and evidence.buttress_top_m > 0.9:
        target_height = evidence.buttress_top_m + 0.3
        case = DiameterCase.BUTTRESS
        rule = "FAO: measure 0.3 m above the end of buttress or basal enlargement"
    elif evidence.aerial_root_top_m is not None:
        target_height = evidence.aerial_root_top_m + breast_height_m
        case = DiameterCase.AERIAL_ROOTS
        rule = "FAO: measure 1.3 m above the stem/aerial-root boundary"

    irregularity = evidence.irregularity_interval_m
    if irregularity is not None and irregularity[0] <= target_height <= irregularity[1]:
        if case is not DiameterCase.STANDARD:
            raise ValueError("irregularity overlaps a special base-form measurement plane")
        target_height = irregularity[1] + irregularity_clearance_m
        case = DiameterCase.IRREGULAR_AT_BREAST_HEIGHT
        rule = "FAO: measure immediately above the point where irregularity ceases"
        diagnostics.append("standard breast-height section was rejected as deformed")

    return DiameterMeasurementPlan(
        case,
        1,
        _plane(target_height),
        "single_tree",
        ground_reference,
        distance_reference,
        rule,
        tuple(diagnostics),
    )
