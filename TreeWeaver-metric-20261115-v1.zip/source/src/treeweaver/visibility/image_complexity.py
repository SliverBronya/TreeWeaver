"""Auditable complex-scene cues derived from one view's semantic masks."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

import cv2
import numpy as np
import numpy.typing as npt

from treeweaver.visibility.basal_occluder import assess_basal_object_contact
from treeweaver.visibility.stem_topology import assess_basal_stem_topology

BoolArray = npt.NDArray[np.bool_]


class ImageChallengeCue(StrEnum):
    APEX_TRUNCATED = "apex_truncated"
    ROOT_TRUNCATED = "root_truncated"
    SIDE_TRUNCATED = "side_truncated"
    TARGET_OVERLAP = "target_overlap"
    STEM_OVERLAP = "stem_overlap"
    CROWN_OVERLAP = "crown_overlap"
    STEM_FRAGMENTED = "stem_fragmented"
    ROOT_GROUND_GAP = "root_ground_gap"
    DBH_REGION_HIDDEN = "dbh_region_hidden"
    DBH_OCCLUDER_SUPPORT = "dbh_occluder_support"
    GROUND_UNAVAILABLE = "ground_unavailable"
    DBH_REGION_UNLOCATED = "dbh_region_unlocated"
    BASAL_MULTIPLE_RUNS = "basal_multiple_runs"
    BASAL_OBJECT_CONTACT = "basal_object_contact"


@dataclass(frozen=True, slots=True)
class ChallengeEvidence:
    cue: ImageChallengeCue
    score: float
    explanation: str

    @property
    def detected(self) -> bool:
        return self.score > 0


@dataclass(frozen=True, slots=True)
class TargetViewAudit:
    shape: tuple[int, int]
    evidence: tuple[ChallengeEvidence, ...]

    def score(self, cue: ImageChallengeCue) -> float:
        return next(item.score for item in self.evidence if item.cue is cue)

    @property
    def active(self) -> tuple[ImageChallengeCue, ...]:
        return tuple(item.cue for item in self.evidence if item.detected)


def _as_mask(mask: npt.ArrayLike, shape: tuple[int, int] | None = None) -> BoolArray:
    value = np.asarray(mask)
    if value.ndim != 2:
        raise ValueError("semantic masks must be two-dimensional")
    result = value.astype(np.bool_, copy=False)
    if shape is not None and result.shape != shape:
        raise ValueError("all semantic masks must have the same shape")
    return result


def _fraction(numerator: BoolArray, denominator: BoolArray) -> float:
    count = int(np.count_nonzero(denominator))
    return float(np.count_nonzero(numerator & denominator) / count) if count else 0.0


def _border_contact(mask: BoolArray, border: int, edge: str) -> float:
    rows, columns = mask.shape
    if edge == "top":
        band = mask[:border]
        extent = np.any(mask, axis=0)
        return float(np.count_nonzero(np.any(band, axis=0)) / max(1, np.count_nonzero(extent)))
    if edge == "bottom":
        band = mask[rows - border :]
        extent = np.any(mask, axis=0)
        return float(np.count_nonzero(np.any(band, axis=0)) / max(1, np.count_nonzero(extent)))
    band = np.zeros_like(mask)
    band[:, :border] = True
    band[:, columns - border :] = True
    extent = np.any(mask, axis=1)
    return float(np.count_nonzero(np.any(mask & band, axis=1)) / max(1, np.count_nonzero(extent)))


def _fragmentation(mask: BoolArray) -> float:
    count = int(np.count_nonzero(mask))
    if count == 0:
        return 1.0
    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask.astype(np.uint8), connectivity=8
    )
    if component_count <= 2:
        return 0.0
    largest = int(np.max(stats[1:, cv2.CC_STAT_AREA]))
    return float(1.0 - largest / count)


def audit_target_view(
    instance_mask: npt.ArrayLike,
    trunk_mask: npt.ArrayLike,
    crown_mask: npt.ArrayLike,
    *,
    competing_instance_masks: tuple[npt.ArrayLike, ...] = (),
    ground_mask: npt.ArrayLike | None = None,
    dbh_region_mask: npt.ArrayLike | None = None,
    amodal_trunk_mask: npt.ArrayLike | None = None,
    foreground_occluder_mask: npt.ArrayLike | None = None,
    non_tree_object_masks: tuple[npt.ArrayLike, ...] = (),
    border_pixels: int = 2,
    contact_pixels: int = 3,
) -> TargetViewAudit:
    """Measure observable difficulty cues without pretending to infer hidden pixels.

    Visible-mask intersection is model disagreement, not physical occlusion.
    An optional amodal trunk is a hypothesis about hidden geometry; a DBH
    region must come from independently checked marker/ground geometry.
    """

    instance = _as_mask(instance_mask)
    image_shape = (int(instance.shape[0]), int(instance.shape[1]))
    trunk = _as_mask(trunk_mask, image_shape)
    crown = _as_mask(crown_mask, image_shape)
    if not np.any(instance) or not np.any(trunk) or not np.any(crown):
        raise ValueError("instance, trunk, and crown masks must be non-empty")
    if np.any(trunk & ~instance) or np.any(crown & ~instance):
        raise ValueError("tree-part masks must be contained by the instance mask")
    if border_pixels < 1 or contact_pixels < 0:
        raise ValueError("mask audit radii are invalid")
    border = min(border_pixels, min(instance.shape))

    competing = np.zeros_like(instance)
    for mask in competing_instance_masks:
        competing |= _as_mask(mask, image_shape)

    if (dbh_region_mask is None) != (amodal_trunk_mask is None):
        raise ValueError("DBH region and amodal trunk must be supplied together")
    dbh_region = _as_mask(dbh_region_mask, image_shape) if dbh_region_mask is not None else None
    amodal_trunk = (
        _as_mask(amodal_trunk_mask, image_shape) if amodal_trunk_mask is not None else None
    )
    occluder = (
        _as_mask(foreground_occluder_mask, image_shape)
        if foreground_occluder_mask is not None
        else None
    )
    if amodal_trunk is not None and np.any(trunk & ~amodal_trunk):
        raise ValueError("amodal trunk must contain all visible trunk pixels")
    if dbh_region is not None and amodal_trunk is not None:
        if not np.any(dbh_region & amodal_trunk):
            raise ValueError("DBH region must intersect the expected trunk")

    overlap = instance & competing
    apex = _border_contact(crown, border, "top")
    root = _border_contact(trunk, border, "bottom")
    side = _border_contact(instance, border, "side")
    target_overlap = _fraction(overlap, instance)
    stem_region = trunk if dbh_region is None else trunk & dbh_region
    stem_overlap = _fraction(competing, stem_region)
    crown_overlap = _fraction(competing, crown)
    fragmentation = _fragmentation(trunk)
    basal_multiple = assess_basal_stem_topology(trunk).multiple_basal_runs
    basal_object_contact = 0.0
    for mask in non_tree_object_masks:
        object_mask = _as_mask(mask, image_shape)
        contact = assess_basal_object_contact(trunk, object_mask)
        basal_object_contact = max(basal_object_contact, contact.contact_fraction)

    hidden_dbh_fraction = 0.0
    occluder_support = 0.0
    if dbh_region is not None and amodal_trunk is not None:
        expected_dbh = amodal_trunk & dbh_region
        hidden_dbh = expected_dbh & ~trunk
        hidden_dbh_fraction = _fraction(hidden_dbh, expected_dbh)
        if occluder is not None:
            occluder_support = _fraction(occluder, hidden_dbh)

    ground_gap = 0.0
    if ground_mask is not None:
        ground = _as_mask(ground_mask, image_shape)
        kernel_size = 2 * contact_pixels + 1
        kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
        reachable_ground = cv2.dilate(ground.astype(np.uint8), kernel).astype(bool)
        if not np.any(trunk & reachable_ground):
            ground_gap = 1.0

    evidence = (
        ChallengeEvidence(ImageChallengeCue.APEX_TRUNCATED, apex, "crown touches top border"),
        ChallengeEvidence(ImageChallengeCue.ROOT_TRUNCATED, root, "trunk touches bottom border"),
        ChallengeEvidence(ImageChallengeCue.SIDE_TRUNCATED, side, "tree touches a side border"),
        ChallengeEvidence(
            ImageChallengeCue.TARGET_OVERLAP,
            target_overlap,
            "fraction of target instance in conflicting visible-mask predictions",
        ),
        ChallengeEvidence(
            ImageChallengeCue.STEM_OVERLAP,
            stem_overlap,
            "fraction of visible trunk or DBH region in conflicting mask predictions",
        ),
        ChallengeEvidence(
            ImageChallengeCue.CROWN_OVERLAP,
            crown_overlap,
            "fraction of visible crown in conflicting mask predictions",
        ),
        ChallengeEvidence(
            ImageChallengeCue.STEM_FRAGMENTED,
            fragmentation,
            "fraction outside the largest connected trunk component",
        ),
        ChallengeEvidence(
            ImageChallengeCue.ROOT_GROUND_GAP,
            ground_gap,
            "no target-trunk contact with nearby visible ground",
        ),
        ChallengeEvidence(
            ImageChallengeCue.DBH_REGION_HIDDEN,
            hidden_dbh_fraction,
            "fraction of hypothesized DBH trunk region absent from visible trunk mask",
        ),
        ChallengeEvidence(
            ImageChallengeCue.DBH_OCCLUDER_SUPPORT,
            occluder_support,
            "fraction of hypothesized hidden DBH pixels covered by a foreground mask",
        ),
        ChallengeEvidence(
            ImageChallengeCue.GROUND_UNAVAILABLE,
            float(ground_mask is None),
            "ground visibility was not supplied, so root-to-ground contact is unknown",
        ),
        ChallengeEvidence(
            ImageChallengeCue.DBH_REGION_UNLOCATED,
            float(dbh_region is None),
            "independently checked breast-height image region was not supplied",
        ),
        ChallengeEvidence(
            ImageChallengeCue.BASAL_MULTIPLE_RUNS,
            float(basal_multiple),
            "persistent separated basal trunk runs: multi-stem or occluding gap",
        ),
        ChallengeEvidence(
            ImageChallengeCue.BASAL_OBJECT_CONTACT,
            basal_object_contact,
            "non-tree object near visible basal stem; possible root occlusion, "
            "not proven foreground",
        ),
    )
    return TargetViewAudit(image_shape, evidence)
