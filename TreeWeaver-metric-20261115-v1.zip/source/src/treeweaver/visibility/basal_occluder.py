"""Image-plane evidence that a non-tree object may hide the stem base."""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class BasalObjectContact:
    contact_fraction: float
    touching: bool
    basal_endpoint_xy: tuple[int, int]


def assess_basal_object_contact(
    visible_trunk_mask: npt.ArrayLike,
    object_mask: npt.ArrayLike,
    *,
    radius_px: int = 12,
    endpoint_band_fraction: float = 0.03,
    minimum_contact_fraction: float = 0.25,
) -> BasalObjectContact:
    """Flag proximity, never assert which surface is in front.

    The object mask must come from a separate non-tree recognition process.
    This does not establish depth ordering or reconstruct the hidden root.
    """

    trunk = np.asarray(visible_trunk_mask).astype(bool, copy=False)
    obstacle = np.asarray(object_mask).astype(bool, copy=False)
    if trunk.ndim != 2 or trunk.shape != obstacle.shape or not np.any(trunk):
        raise ValueError("aligned nonempty 2-D trunk and object masks are required")
    if radius_px < 1 or not 0 < endpoint_band_fraction <= 0.2:
        raise ValueError("invalid basal contact geometry")
    if not 0 <= minimum_contact_fraction <= 1:
        raise ValueError("minimum contact fraction must lie in [0, 1]")
    ys, xs = np.nonzero(trunk)
    bottom = int(ys.max())
    height = max(1, bottom - int(ys.min()))
    band_top = bottom - max(2, round(height * endpoint_band_fraction))
    basal = trunk.copy()
    basal[:band_top] = False
    centroid_x = int(round(float(np.median(xs[ys >= band_top]))))
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (2 * radius_px + 1, 2 * radius_px + 1)
    )
    near_object = cv2.dilate(obstacle.astype(np.uint8), kernel).astype(bool)
    fraction = float(np.count_nonzero(basal & near_object) / max(1, np.count_nonzero(basal)))
    return BasalObjectContact(fraction, fraction >= minimum_contact_fraction, (centroid_x, bottom))
