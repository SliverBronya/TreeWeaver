"""Image-plane basal-stem multiplicity cue, not a biological diagnosis."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class BasalStemTopology:
    row_fractions: tuple[float, ...]
    visible_run_counts: tuple[int, ...]
    multiple_basal_runs: bool


def _run_count(row: npt.NDArray[np.bool_], minimum_width: int) -> int:
    edges = np.diff(np.r_[False, row, False].astype(np.int8))
    starts = np.flatnonzero(edges == 1)
    ends = np.flatnonzero(edges == -1)
    return int(np.count_nonzero((ends - starts) >= minimum_width))


def assess_basal_stem_topology(
    trunk_mask: npt.ArrayLike,
    *,
    row_fractions: tuple[float, ...] = (0.85, 0.92, 0.97),
    minimum_run_width_px: int = 2,
) -> BasalStemTopology:
    """Flag repeated basal splits; an occluder may produce the same cue.

    Runs are sampled relative to the *visible trunk mask*, not an assumed
    anatomical root height. Thus a positive result blocks single-stem DBH,
    while a negative result cannot certify a single stem.
    """

    trunk = np.asarray(trunk_mask).astype(bool, copy=False)
    if trunk.ndim != 2 or not np.any(trunk):
        raise ValueError("trunk mask must be a nonempty 2-D array")
    if (
        minimum_run_width_px < 1
        or not row_fractions
        or any(not 0 < fraction < 1 for fraction in row_fractions)
    ):
        raise ValueError("invalid basal sampling configuration")
    occupied_rows = np.flatnonzero(np.any(trunk, axis=1))
    top, bottom = int(occupied_rows[0]), int(occupied_rows[-1])
    counts = tuple(
        _run_count(trunk[round(top + fraction * (bottom - top))], minimum_run_width_px)
        for fraction in row_fractions
    )
    return BasalStemTopology(
        row_fractions=row_fractions,
        visible_run_counts=counts,
        multiple_basal_runs=sum(count >= 2 for count in counts) >= 2,
    )
