"""Reject incoherent tree-part masks before any measurement uses them."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class TreePartConsistency:
    accepted: bool
    trunk_area_fraction: float
    trunk_outside_fraction: float
    reasons: tuple[str, ...]


def assess_tree_part_consistency(
    whole_tree_mask: npt.ArrayLike,
    trunk_mask: npt.ArrayLike,
    *,
    maximum_trunk_area_fraction: float = 0.5,
    maximum_outside_fraction: float = 0.01,
) -> TreePartConsistency:
    """Check necessary mask structure, not correctness or biological validity.

    The area limit is an exploratory failure detector for a common zero-shot
    prompt collapse (the whole crown is labeled trunk), not a universal tree
    shape law. Accepted masks still require target and ground validation.
    """

    whole = np.asarray(whole_tree_mask)
    trunk = np.asarray(trunk_mask)
    if whole.ndim != 2 or trunk.shape != whole.shape:
        raise ValueError("whole-tree and trunk masks must be same-shaped 2-D arrays")
    if not 0 < maximum_trunk_area_fraction < 1 or not 0 <= maximum_outside_fraction < 1:
        raise ValueError("part consistency thresholds are invalid")
    whole = whole.astype(bool, copy=False)
    trunk = trunk.astype(bool, copy=False)
    whole_area = int(np.count_nonzero(whole))
    trunk_area = int(np.count_nonzero(trunk))
    if whole_area == 0:
        raise ValueError("whole-tree mask cannot be empty")
    trunk_area_fraction = trunk_area / whole_area
    outside_fraction = float(np.count_nonzero(trunk & ~whole) / trunk_area) if trunk_area else 0.0
    reasons: list[str] = []
    if trunk_area == 0:
        reasons.append("tree trunk was not segmented")
    if outside_fraction > maximum_outside_fraction:
        reasons.append("trunk mask extends outside the selected tree")
    if trunk_area_fraction > maximum_trunk_area_fraction:
        reasons.append("trunk mask occupies too much of the tree; probable crown leakage")
    return TreePartConsistency(
        accepted=not reasons,
        trunk_area_fraction=float(trunk_area_fraction),
        trunk_outside_fraction=outside_fraction,
        reasons=tuple(reasons),
    )
