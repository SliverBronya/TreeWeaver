"""Explicit ray evidence for observed, occluded, absent, and out-of-view surfaces."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
StateArray = npt.NDArray[np.int8]


class SurfaceState(IntEnum):
    OUTSIDE_VIEW = 0
    UNOBSERVED = 1
    OCCLUDED = 2
    VISIBLE = 3


@dataclass(frozen=True, slots=True)
class ViewSurfaceEvidence:
    image_name: str
    states: StateArray
    occluder_indices: IntArray
    expected_depth: FloatArray
    scene_depth: FloatArray


@dataclass(frozen=True, slots=True)
class MultiViewSurfaceEvidence:
    states: StateArray
    visible_view_count: IntArray
    occluded_view_count: IntArray
    unobserved_view_count: IntArray
    outside_view_count: IntArray
    views: tuple[ViewSurfaceEvidence, ...]

    @property
    def visible_fraction(self) -> float:
        return float(np.mean(self.states == int(SurfaceState.VISIBLE)))

    @property
    def occluded_fraction(self) -> float:
        return float(np.mean(self.states == int(SurfaceState.OCCLUDED)))


def _project(
    points: FloatArray, camera: ProjectionCamera
) -> tuple[FloatArray, FloatArray, FloatArray]:
    camera_points = (
        camera.pose.rotation_world_to_camera @ points.T
    ).T + camera.pose.translation_world_to_camera
    depth = camera_points[:, 2]
    safe_depth = np.maximum(depth, 1e-12)
    u = camera.intrinsics.fx * camera_points[:, 0] / safe_depth + camera.intrinsics.cx
    v = camera.intrinsics.fy * camera_points[:, 1] / safe_depth + camera.intrinsics.cy
    return u, v, depth


def _scene_z_buffer(
    scene_points: FloatArray, camera: ProjectionCamera
) -> tuple[FloatArray, IntArray]:
    u_float, v_float, depth = _project(scene_points, camera)
    u = np.rint(u_float).astype(np.int64)
    v = np.rint(v_float).astype(np.int64)
    inside = (
        (depth > 1e-8)
        & (u >= 0)
        & (u < camera.intrinsics.width)
        & (v >= 0)
        & (v < camera.intrinsics.height)
    )
    indices = np.flatnonzero(inside)
    size = camera.intrinsics.width * camera.intrinsics.height
    z_buffer = np.full(size, np.inf, dtype=np.float64)
    owner = np.full(size, -1, dtype=np.int64)
    if len(indices) == 0:
        return z_buffer, owner
    pixels = v[indices] * camera.intrinsics.width + u[indices]
    order = np.argsort(depth[indices], kind="stable")
    sorted_pixels = pixels[order]
    _, first = np.unique(sorted_pixels, return_index=True)
    chosen = order[first]
    chosen_pixels = pixels[chosen]
    chosen_indices = indices[chosen]
    z_buffer[chosen_pixels] = depth[chosen_indices]
    owner[chosen_pixels] = chosen_indices
    return z_buffer, owner


def probe_surface_in_view(
    expected_surface_points: npt.ArrayLike,
    scene_points: npt.ArrayLike,
    camera: ProjectionCamera,
    *,
    pixel_radius: int = 1,
    relative_depth_tolerance: float = 0.01,
    absolute_depth_tolerance: float = 0.02,
) -> ViewSurfaceEvidence:
    """Classify expected surface samples against one view's scene Z-buffer."""

    expected = np.asarray(expected_surface_points, dtype=np.float64)
    scene = np.asarray(scene_points, dtype=np.float64)
    if expected.ndim != 2 or expected.shape[1] != 3 or len(expected) == 0:
        raise ValueError("expected surface must be a non-empty N x 3 array")
    if scene.ndim != 2 or scene.shape[1] != 3 or len(scene) == 0:
        raise ValueError("scene points must be a non-empty N x 3 array")
    if not np.isfinite(expected).all() or not np.isfinite(scene).all():
        raise ValueError("surface and scene points must be finite")
    if pixel_radius < 0 or relative_depth_tolerance < 0 or absolute_depth_tolerance < 0:
        raise ValueError("visibility tolerances cannot be negative")

    z_buffer, owner = _scene_z_buffer(scene, camera)
    u_float, v_float, expected_depth = _project(expected, camera)
    u = np.rint(u_float).astype(np.int64)
    v = np.rint(v_float).astype(np.int64)
    inside = (
        (expected_depth > 1e-8)
        & (u >= 0)
        & (u < camera.intrinsics.width)
        & (v >= 0)
        & (v < camera.intrinsics.height)
    )
    states = np.full(len(expected), int(SurfaceState.OUTSIDE_VIEW), dtype=np.int8)
    occluders = np.full(len(expected), -1, dtype=np.int64)
    observed_depth = np.full(len(expected), np.nan, dtype=np.float64)
    width = camera.intrinsics.width
    height = camera.intrinsics.height
    for index in np.flatnonzero(inside):
        best_depth = np.inf
        best_owner = -1
        for delta_v in range(-pixel_radius, pixel_radius + 1):
            row = v[index] + delta_v
            if row < 0 or row >= height:
                continue
            for delta_u in range(-pixel_radius, pixel_radius + 1):
                column = u[index] + delta_u
                if column < 0 or column >= width:
                    continue
                pixel = row * width + column
                if z_buffer[pixel] < best_depth:
                    best_depth = z_buffer[pixel]
                    best_owner = int(owner[pixel])
        if not np.isfinite(best_depth):
            states[index] = int(SurfaceState.UNOBSERVED)
            continue
        observed_depth[index] = best_depth
        tolerance = absolute_depth_tolerance + relative_depth_tolerance * expected_depth[index]
        difference = expected_depth[index] - best_depth
        if abs(float(difference)) <= tolerance:
            states[index] = int(SurfaceState.VISIBLE)
        elif difference > tolerance:
            states[index] = int(SurfaceState.OCCLUDED)
            occluders[index] = best_owner
        else:
            states[index] = int(SurfaceState.UNOBSERVED)
    return ViewSurfaceEvidence(
        camera.image_name,
        states,
        occluders,
        expected_depth.astype(np.float64, copy=False),
        observed_depth,
    )


def fuse_surface_visibility(
    expected_surface_points: npt.ArrayLike,
    scene_points: npt.ArrayLike,
    cameras: tuple[ProjectionCamera, ...],
    *,
    pixel_radius: int = 1,
    relative_depth_tolerance: float = 0.01,
    absolute_depth_tolerance: float = 0.02,
) -> MultiViewSurfaceEvidence:
    """Fuse views without treating occlusion as negative geometry evidence."""

    if not cameras:
        raise ValueError("surface visibility requires at least one camera")
    views = tuple(
        probe_surface_in_view(
            expected_surface_points,
            scene_points,
            camera,
            pixel_radius=pixel_radius,
            relative_depth_tolerance=relative_depth_tolerance,
            absolute_depth_tolerance=absolute_depth_tolerance,
        )
        for camera in cameras
    )
    stacked = np.stack([view.states for view in views])
    visible = np.sum(stacked == int(SurfaceState.VISIBLE), axis=0).astype(np.int64)
    occluded = np.sum(stacked == int(SurfaceState.OCCLUDED), axis=0).astype(np.int64)
    unobserved = np.sum(stacked == int(SurfaceState.UNOBSERVED), axis=0).astype(np.int64)
    outside = np.sum(stacked == int(SurfaceState.OUTSIDE_VIEW), axis=0).astype(np.int64)
    states = np.full(stacked.shape[1], int(SurfaceState.OUTSIDE_VIEW), dtype=np.int8)
    states[unobserved > 0] = int(SurfaceState.UNOBSERVED)
    states[occluded > 0] = int(SurfaceState.OCCLUDED)
    states[visible > 0] = int(SurfaceState.VISIBLE)
    return MultiViewSurfaceEvidence(states, visible, occluded, unobserved, outside, views)
