"""Ray-based scene visibility and occlusion reasoning."""
