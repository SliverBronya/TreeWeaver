"""Canonical on-disk boundary between vision providers and geometry."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt

BoolArray = npt.NDArray[np.bool_]


@dataclass(frozen=True, slots=True)
class TreeMaskSet:
    image_name: str
    local_instance_id: int
    instance: BoolArray
    trunk: BoolArray
    crown: BoolArray
    reliability: float
    part_reliability: float

    def __post_init__(self) -> None:
        if not self.image_name or self.local_instance_id < 0:
            raise ValueError("tree mask identity is invalid")
        if not (
            self.instance.shape == self.trunk.shape == self.crown.shape
            and self.instance.ndim == 2
            and self.instance.dtype == self.trunk.dtype == self.crown.dtype == np.bool_
        ):
            raise ValueError("instance, trunk and crown must be same-shaped boolean masks")
        if np.any(self.trunk & ~self.instance) or np.any(self.crown & ~self.instance):
            raise ValueError("tree-part masks must be contained by their instance")
        if np.any(self.trunk & self.crown):
            raise ValueError("trunk and crown masks cannot overlap")
        if not 0 < self.reliability <= 1 or not 0 < self.part_reliability <= 1:
            raise ValueError("mask reliabilities must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class GroundMask:
    image_name: str
    mask: BoolArray
    reliability: float

    def __post_init__(self) -> None:
        if not self.image_name or self.mask.ndim != 2 or self.mask.dtype != np.bool_:
            raise ValueError("ground mask must have an image and a 2-D boolean mask")
        if not 0 < self.reliability <= 1:
            raise ValueError("ground reliability must be in (0, 1]")


def _write_mask(path: Path, mask: BoolArray) -> None:
    if not cv2.imwrite(str(path), mask.astype(np.uint8) * 255):
        raise OSError(f"failed to write mask: {path}")


def write_observation_bundle(
    output_directory: str | Path,
    trees: tuple[TreeMaskSet, ...],
    grounds: tuple[GroundMask, ...],
    *,
    provider: str,
    model_version: str,
    run_metadata: dict[str, object] | None = None,
) -> Path:
    """Write provider output in the format consumed by association and fusion."""

    if not trees or not provider or not model_version:
        raise ValueError("tree evidence and provider identity are required")
    keys = {(tree.image_name, tree.local_instance_id) for tree in trees}
    if len(keys) != len(trees):
        raise ValueError("local instance ids must be unique within each image")
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    masks = output / "masks"
    masks.mkdir(parents=True)
    tree_by_image: dict[str, list[TreeMaskSet]] = {}
    ground_by_image = {ground.image_name: ground for ground in grounds}
    if len(ground_by_image) != len(grounds):
        raise ValueError("an image can contain only one fused ground mask")
    for tree in trees:
        tree_by_image.setdefault(tree.image_name, []).append(tree)

    views: list[dict[str, object]] = []
    image_names = sorted(set(tree_by_image) | set(ground_by_image))
    for view_index, image_name in enumerate(image_names):
        items: list[dict[str, object]] = []
        view: dict[str, object] = {"image_name": image_name, "instances": items}
        ground = ground_by_image.get(image_name)
        if ground is not None:
            ground_name = f"v{view_index:06d}_ground.png"
            _write_mask(masks / ground_name, ground.mask)
            view["ground_mask_path"] = f"masks/{ground_name}"
            view["ground_reliability"] = ground.reliability
        ordered_trees = sorted(
            tree_by_image.get(image_name, []), key=lambda item: item.local_instance_id
        )
        for tree in ordered_trees:
            prefix = f"v{view_index:06d}_i{tree.local_instance_id:04d}"
            names = {
                "instance": f"{prefix}_instance.png",
                "trunk": f"{prefix}_trunk.png",
                "crown": f"{prefix}_crown.png",
            }
            _write_mask(masks / names["instance"], tree.instance)
            _write_mask(masks / names["trunk"], tree.trunk)
            _write_mask(masks / names["crown"], tree.crown)
            items.append(
                {
                    "local_instance_id": tree.local_instance_id,
                    "mask_path": f"masks/{names['instance']}",
                    "reliability": tree.reliability,
                    "part_reliability": tree.part_reliability,
                    "parts": {
                        "trunk": f"masks/{names['trunk']}",
                        "crown": f"masks/{names['crown']}",
                    },
                }
            )
        views.append(view)
    manifest = output / "observations.json"
    manifest.write_text(
        json.dumps(
            {
                "schema_version": "instance-observations-1.0",
                "provider": provider,
                "model_version": model_version,
                "run_metadata": run_metadata or {},
                "views": views,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return manifest


def validate_observation_bundle(manifest_path: str | Path) -> tuple[int, int]:
    """Validate provider output before any geometry code consumes it."""

    manifest = Path(manifest_path).resolve()
    payload: dict[str, Any] = json.loads(manifest.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "instance-observations-1.0":
        raise ValueError("unsupported observation bundle schema")
    if not payload.get("provider") or not payload.get("model_version"):
        raise ValueError("observation bundle must identify provider and model version")
    instances = 0
    mask_files = 0
    seen: set[tuple[str, int]] = set()
    for view in payload.get("views", []):
        image_name = str(view.get("image_name", ""))
        if not image_name:
            raise ValueError("observation view is missing image_name")
        relative_paths: list[str] = []
        if "ground_mask_path" in view:
            relative_paths.append(str(view["ground_mask_path"]))
        for item in view.get("instances", []):
            key = image_name, int(item["local_instance_id"])
            if key in seen:
                raise ValueError(f"duplicate local instance: {key}")
            seen.add(key)
            instances += 1
            relative_paths.append(str(item["mask_path"]))
            parts = item.get("parts", {})
            relative_paths.extend(str(value) for value in parts.values())
        for relative in relative_paths:
            path = (manifest.parent / relative).resolve()
            if manifest.parent != path and manifest.parent not in path.parents:
                raise ValueError(f"mask path escapes observation bundle: {relative}")
            mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            if mask is None:
                raise FileNotFoundError(path)
            mask_files += 1
    if instances == 0:
        raise ValueError("observation bundle contains no tree instances")
    return instances, mask_files
