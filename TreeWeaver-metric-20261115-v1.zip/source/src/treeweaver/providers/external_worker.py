"""Process-isolated adapter for heavyweight learned vision providers."""

from __future__ import annotations

import json
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from time import time

from treeweaver.providers.observation_bundle import validate_observation_bundle


@dataclass(frozen=True, slots=True)
class ExternalWorkerConfig:
    command: tuple[str, ...]
    provider_name: str
    model_version: str
    timeout_seconds: int = 3600

    def __post_init__(self) -> None:
        if not self.command or not self.provider_name or not self.model_version:
            raise ValueError("external worker command and identity are required")
        if self.timeout_seconds <= 0:
            raise ValueError("external worker timeout must be positive")


@dataclass(frozen=True, slots=True)
class ExternalWorkerResult:
    observation_manifest: Path
    instance_count: int
    mask_file_count: int
    duration_seconds: float


def load_external_worker_config(path: str | Path) -> ExternalWorkerConfig:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != "external-vision-worker-1.0":
        raise ValueError("unsupported external vision worker schema")
    return ExternalWorkerConfig(
        command=tuple(str(item) for item in payload["command"]),
        provider_name=str(payload["provider_name"]),
        model_version=str(payload["model_version"]),
        timeout_seconds=int(payload.get("timeout_seconds", 3600)),
    )


def run_external_vision_worker(
    config: ExternalWorkerConfig,
    capture_manifest: str | Path,
    output_directory: str | Path,
) -> ExternalWorkerResult:
    """Run an isolated model worker using a stable command-line contract."""

    capture = Path(capture_manifest).resolve()
    if not capture.is_file():
        raise FileNotFoundError(capture)
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [
        *config.command,
        "--capture-manifest",
        str(capture),
        "--output-directory",
        str(output),
        "--provider-name",
        config.provider_name,
        "--model-version",
        config.model_version,
    ]
    started = time()
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=config.timeout_seconds,
        check=False,
        shell=False,
    )
    duration = time() - started
    output.mkdir(parents=True, exist_ok=True)
    (output / "provider-run.json").write_text(
        json.dumps(
            {
                "config": asdict(config),
                "expanded_command": command,
                "return_code": completed.returncode,
                "duration_seconds": duration,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    if completed.returncode:
        raise RuntimeError(
            f"vision worker failed with code {completed.returncode}; "
            f"see {output / 'provider-run.json'}"
        )
    manifest = output / "observations.json"
    instances, masks = validate_observation_bundle(manifest)
    return ExternalWorkerResult(manifest, instances, masks, duration)
