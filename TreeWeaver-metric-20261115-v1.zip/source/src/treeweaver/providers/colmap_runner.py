"""Auditable COLMAP sparse-reconstruction process adapter."""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from time import time

import numpy as np

from treeweaver.io.session import load_capture_session
from treeweaver.providers.colmap_text import load_colmap_text_model
from treeweaver.reconstruction.model import Reconstruction


@dataclass(frozen=True, slots=True)
class ColmapConfig:
    executable: str = "colmap"
    use_gpu: bool = True
    camera_model: str = "PINHOLE"
    mapper_threads: int = 4
    timeout_seconds: int = 3600
    dense: bool = False
    dense_max_image_size: int = 2000


class ColmapRunner:
    name = "colmap"

    def __init__(self, config: ColmapConfig | None = None) -> None:
        self.config = config if config is not None else ColmapConfig()

    def _executable(self) -> str:
        configured = Path(self.config.executable)
        if configured.is_file():
            return str(configured.resolve())
        discovered = shutil.which(self.config.executable)
        if discovered is None:
            raise FileNotFoundError(
                f"COLMAP executable not found: {self.config.executable}. "
                "Install COLMAP or configure its absolute path."
            )
        return discovered

    def reconstruct(self, capture_manifest: Path, output_directory: Path) -> Reconstruction:
        validation = load_capture_session(capture_manifest)
        session = validation.session
        root = capture_manifest.resolve().parent
        image_paths = [(root / frame.image_path).resolve() for frame in session.frames]
        image_parents = {path.parent for path in image_paths}
        if len(image_parents) != 1:
            raise ValueError("COLMAP baseline requires all frames in one image directory")
        first = session.frames[0].intrinsics
        if any(
            frame.intrinsics.width != first.width or frame.intrinsics.height != first.height
            for frame in session.frames
        ):
            raise ValueError("COLMAP single-camera baseline requires one image resolution")
        focal_values = np.array(
            [[frame.intrinsics.fx, frame.intrinsics.fy] for frame in session.frames]
        )
        if float(np.max(np.ptp(focal_values, axis=0))) > 1e-3:
            raise ValueError("COLMAP single-camera baseline requires stable focal calibration")

        executable = self._executable()
        output = output_directory.resolve()
        if output.exists():
            raise FileExistsError(output)
        output.mkdir(parents=True)
        database = output / "database.db"
        sparse = output / "sparse"
        text_model = output / "text-model"
        sparse.mkdir()
        camera_params = f"{first.fx},{first.fy},{first.cx},{first.cy}"
        gpu = "1" if self.config.use_gpu else "0"
        commands = [
            [
                executable,
                "feature_extractor",
                "--database_path",
                str(database),
                "--image_path",
                str(next(iter(image_parents))),
                "--ImageReader.single_camera",
                "1",
                "--ImageReader.camera_model",
                self.config.camera_model,
                "--ImageReader.camera_params",
                camera_params,
                "--FeatureExtraction.use_gpu",
                gpu,
            ],
            [
                executable,
                "sequential_matcher",
                "--database_path",
                str(database),
                "--FeatureMatching.use_gpu",
                gpu,
            ],
            [
                executable,
                "mapper",
                "--database_path",
                str(database),
                "--image_path",
                str(next(iter(image_parents))),
                "--output_path",
                str(sparse),
                "--Mapper.num_threads",
                str(self.config.mapper_threads),
            ],
        ]
        log: list[dict[str, object]] = []
        for command in commands:
            started = time()
            completed = subprocess.run(
                command,
                cwd=output,
                capture_output=True,
                text=True,
                timeout=self.config.timeout_seconds,
                check=False,
                shell=False,
            )
            record = {
                "command": command,
                "return_code": completed.returncode,
                "duration_seconds": time() - started,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }
            log.append(record)
            (output / "run-log.json").write_text(
                json.dumps(
                    {"config": asdict(self.config), "commands": log},
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            if completed.returncode:
                raise RuntimeError(
                    f"COLMAP {command[1]} failed with code {completed.returncode}; "
                    f"see {output / 'run-log.json'}"
                )

        candidates = [path for path in sparse.iterdir() if path.is_dir()]
        if not candidates:
            raise RuntimeError("COLMAP mapper produced no reconstruction")
        model = max(
            candidates, key=lambda path: sum(item.stat().st_size for item in path.iterdir())
        )
        text_model.mkdir()
        convert = [
            executable,
            "model_converter",
            "--input_path",
            str(model),
            "--output_path",
            str(text_model),
            "--output_type",
            "TXT",
        ]
        completed = subprocess.run(
            convert,
            cwd=output,
            capture_output=True,
            text=True,
            timeout=self.config.timeout_seconds,
            check=False,
            shell=False,
        )
        log.append(
            {
                "command": convert,
                "return_code": completed.returncode,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }
        )
        (output / "run-log.json").write_text(
            json.dumps({"config": asdict(self.config), "commands": log}, indent=2),
            encoding="utf-8",
        )
        if completed.returncode:
            raise RuntimeError(f"COLMAP model conversion failed; see {output / 'run-log.json'}")
        if self.config.dense:
            dense = output / "dense"
            dense_commands = [
                [
                    executable,
                    "image_undistorter",
                    "--image_path",
                    str(next(iter(image_parents))),
                    "--input_path",
                    str(model),
                    "--output_path",
                    str(dense),
                    "--output_type",
                    "COLMAP",
                    "--max_image_size",
                    str(self.config.dense_max_image_size),
                ],
                [
                    executable,
                    "patch_match_stereo",
                    "--workspace_path",
                    str(dense),
                    "--workspace_format",
                    "COLMAP",
                    "--PatchMatchStereo.geom_consistency",
                    "true",
                ],
                [
                    executable,
                    "stereo_fusion",
                    "--workspace_path",
                    str(dense),
                    "--workspace_format",
                    "COLMAP",
                    "--input_type",
                    "geometric",
                    "--output_path",
                    str(output / "fused.ply"),
                ],
            ]
            for dense_command in dense_commands:
                dense_completed = subprocess.run(
                    dense_command,
                    cwd=output,
                    capture_output=True,
                    text=True,
                    timeout=self.config.timeout_seconds,
                    check=False,
                    shell=False,
                )
                log.append(
                    {
                        "command": dense_command,
                        "return_code": dense_completed.returncode,
                        "stdout": dense_completed.stdout,
                        "stderr": dense_completed.stderr,
                    }
                )
                (output / "run-log.json").write_text(
                    json.dumps({"config": asdict(self.config), "commands": log}, indent=2),
                    encoding="utf-8",
                )
                if dense_completed.returncode:
                    raise RuntimeError(
                        f"COLMAP {dense_command[1]} failed; see {output / 'run-log.json'}"
                    )
        return load_colmap_text_model(text_model)
