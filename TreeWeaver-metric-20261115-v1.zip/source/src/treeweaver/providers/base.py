"""Replaceable external-model boundaries.

Providers emit evidence with uncertainty and provenance. They never return a
final forestry measurement, which keeps pretrained models scientifically
replaceable and lets TreeFactor remain the inference authority.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Protocol

import numpy as np
import numpy.typing as npt

from treeweaver.reconstruction.model import Reconstruction


class ReconstructionProvider(Protocol):
    name: str
    version: str

    def reconstruct(self, capture_manifest: Path, output_directory: Path) -> Reconstruction:
        """Build or load a reconstruction without leaking provider types."""
        ...


class EvidenceKind(StrEnum):
    INSTANCE = "instance"
    PART = "part"
    DEPTH = "depth"
    SPECIES = "species"


@dataclass(frozen=True, slots=True)
class EvidenceProvenance:
    provider: str
    model_version: str
    source_frame: str
    kind: EvidenceKind

    def __post_init__(self) -> None:
        if not self.provider or not self.model_version or not self.source_frame:
            raise ValueError("evidence provenance fields cannot be empty")


@dataclass(frozen=True, slots=True)
class MaskEvidence:
    local_instance_id: int
    label: str
    mask: npt.NDArray[np.bool_]
    confidence: float
    uncertainty: float
    provenance: EvidenceProvenance

    def __post_init__(self) -> None:
        if self.local_instance_id < 0 or not self.label:
            raise ValueError("mask identity and label must be valid")
        if self.mask.ndim != 2 or self.mask.dtype != np.bool_:
            raise ValueError("mask evidence must contain a 2-D boolean mask")
        if not 0 <= self.confidence <= 1 or self.uncertainty < 0:
            raise ValueError("invalid mask confidence or uncertainty")


@dataclass(frozen=True, slots=True)
class DepthEvidence:
    depth_m: npt.NDArray[np.float64]
    standard_deviation_m: npt.NDArray[np.float64]
    valid_mask: npt.NDArray[np.bool_]
    metric: bool
    provenance: EvidenceProvenance

    def __post_init__(self) -> None:
        if not (
            self.depth_m.shape == self.standard_deviation_m.shape == self.valid_mask.shape
            and self.depth_m.ndim == 2
        ):
            raise ValueError("depth, deviation and validity arrays must share a 2-D shape")
        if np.any(self.standard_deviation_m[self.valid_mask] <= 0):
            raise ValueError("valid depth pixels require positive uncertainty")


class InstanceProvider(Protocol):
    name: str
    version: str

    def predict_instances(self, image: Path) -> tuple[MaskEvidence, ...]: ...


class PartProvider(Protocol):
    name: str
    version: str

    def predict_parts(
        self, image: Path, instances: tuple[MaskEvidence, ...]
    ) -> tuple[MaskEvidence, ...]: ...


class DepthProvider(Protocol):
    name: str
    version: str

    def predict_depth(self, image: Path) -> DepthEvidence: ...


class SpeciesProvider(Protocol):
    name: str
    version: str

    def predict_species(self, image: Path, mask: npt.NDArray[np.bool_]) -> dict[str, float]: ...
