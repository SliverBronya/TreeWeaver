"""Strict reader for COLMAP text model output.

See COLMAP's documented text format. Running COLMAP remains a separate adapter
so experiments can preserve commands, versions, logs, and raw model files.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import numpy as np

from treeweaver.reconstruction.model import CameraPose, FloatArray, Reconstruction, SparsePoint


def _data_lines(path: Path) -> Iterator[str]:
    with path.open("r", encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()
            if line and not line.startswith("#"):
                yield line


def _quaternion_to_rotation(qw: float, qx: float, qy: float, qz: float) -> FloatArray:
    norm = np.linalg.norm([qw, qx, qy, qz])
    if norm == 0:
        raise ValueError("COLMAP quaternion cannot be zero")
    w, x, y, z = np.array([qw, qx, qy, qz], dtype=np.float64) / norm
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def load_colmap_text_model(model_directory: str | Path) -> Reconstruction:
    root = Path(model_directory)
    images_path = root / "images.txt"
    points_path = root / "points3D.txt"
    if not images_path.is_file() or not points_path.is_file():
        raise FileNotFoundError("COLMAP text model requires images.txt and points3D.txt")

    image_records = [
        raw.strip()
        for raw in images_path.read_text(encoding="utf-8").splitlines()
        if not raw.lstrip().startswith("#")
    ]
    while image_records and not image_records[0]:
        image_records.pop(0)
    if len(image_records) % 2:
        raise ValueError("COLMAP images.txt must contain two lines per registered image")
    poses: list[CameraPose] = []
    for record_index in range(0, len(image_records), 2):
        header = image_records[record_index]
        values = header.split()
        if len(values) < 10:
            raise ValueError(f"invalid COLMAP image record: {header}")
        image_id = int(values[0])
        quaternion = tuple(float(value) for value in values[1:5])
        translation = np.array([float(value) for value in values[5:8]], dtype=np.float64)
        camera_id = int(values[8])
        image_name = " ".join(values[9:])
        poses.append(
            CameraPose(
                image_id,
                camera_id,
                image_name,
                _quaternion_to_rotation(*quaternion),
                translation,
            )
        )

    points: list[SparsePoint] = []
    for line in _data_lines(points_path):
        values = line.split()
        if len(values) < 8 or (len(values) - 8) % 2:
            raise ValueError(f"invalid COLMAP point record: {line}")
        points.append(
            SparsePoint(
                point_id=int(values[0]),
                xyz=np.array([float(value) for value in values[1:4]], dtype=np.float64),
                reprojection_error_px=float(values[7]),
                track_length=(len(values) - 8) // 2,
            )
        )
    if len(poses) < 2:
        raise ValueError("reconstruction requires at least two registered images")
    return Reconstruction(tuple(poses), tuple(points))
