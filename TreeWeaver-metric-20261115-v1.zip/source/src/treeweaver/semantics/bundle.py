"""Reproducible file boundary for multiview semantic-part fusion."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import ProjectionCamera, TreeTrack
from treeweaver.io.point_cloud import load_point_cloud
from treeweaver.io.session import load_capture_session
from treeweaver.providers.colmap_text import load_colmap_text_model
from treeweaver.semantics.parts import (
    Part,
    PartObservation,
    fuse_ground_support,
    fuse_track_parts,
    project_part_support,
)

IntArray = npt.NDArray[np.int64]


@dataclass(frozen=True, slots=True)
class SemanticRunResult:
    output_directory: Path
    track_count: int
    trunk_points: int
    crown_points: int
    ambiguous_points: int
    ground_points: int


def _safe_mask(root: Path, relative: str) -> npt.NDArray[np.bool_]:
    path = (root / relative).resolve()
    if path != root and root not in path.parents:
        raise ValueError(f"part mask escapes observation bundle: {relative}")
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise FileNotFoundError(f"cannot read part mask: {path}")
    return mask > 0


def _load_parts(path: Path) -> tuple[PartObservation, ...]:
    payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "instance-observations-1.0":
        raise ValueError("unsupported instance-observation schema")
    root = path.parent.resolve()
    result: list[PartObservation] = []
    for view in payload.get("views", []):
        image_name = str(view["image_name"])
        if "ground_mask_path" in view:
            result.append(
                PartObservation(
                    image_name,
                    0,
                    Part.GROUND,
                    _safe_mask(root, str(view["ground_mask_path"])),
                    float(view.get("ground_reliability", 1.0)),
                )
            )
        for item in view.get("instances", []):
            parts = item.get("parts", {})
            reliability = float(item.get("part_reliability", item.get("reliability", 1.0)))
            for part in (Part.TRUNK, Part.CROWN):
                if part.value in parts:
                    result.append(
                        PartObservation(
                            image_name,
                            int(item["local_instance_id"]),
                            part,
                            _safe_mask(root, str(parts[part.value])),
                            reliability,
                        )
                    )
    if not result:
        raise ValueError("observation bundle contains no semantic part masks")
    return tuple(result)


def _load_tracks(directory: Path) -> tuple[TreeTrack, ...]:
    payload: dict[str, Any] = json.loads((directory / "tracks.json").read_text(encoding="utf-8"))
    if payload.get("schema_version") != "tree-tracks-1.0":
        raise ValueError("unsupported tree-track schema")
    with np.load(directory / "track-points.npz", allow_pickle=False) as arrays:
        point_indices = np.asarray(arrays["point_indices"], dtype=np.int64)
        point_offsets = np.asarray(arrays["point_offsets"], dtype=np.int64)
        consensus = np.asarray(arrays["consensus_indices"], dtype=np.int64)
        consensus_offsets = np.asarray(arrays["consensus_offsets"], dtype=np.int64)
    metadata = payload.get("tracks", [])
    if len(point_offsets) != len(metadata) + 1 or len(consensus_offsets) != len(metadata) + 1:
        raise ValueError("tree-track metadata and point offsets disagree")
    tracks: list[TreeTrack] = []
    for index, item in enumerate(metadata):
        members = tuple(
            (str(member["image_name"]), int(member["local_instance_id"]))
            for member in item["members"]
        )
        tracks.append(
            TreeTrack(
                track_id=int(item["track_id"]),
                members=members,
                point_indices=point_indices[point_offsets[index] : point_offsets[index + 1]],
                consensus_point_indices=consensus[
                    consensus_offsets[index] : consensus_offsets[index + 1]
                ],
                association_confidence=float(item["association_confidence"]),
            )
        )
    return tuple(tracks)


def _pack(arrays: list[IntArray]) -> tuple[IntArray, IntArray]:
    lengths = np.array([len(values) for values in arrays], dtype=np.int64)
    offsets = np.r_[0, np.cumsum(lengths)].astype(np.int64, copy=False)
    flat = np.concatenate(arrays) if arrays else np.empty(0, dtype=np.int64)
    return flat.astype(np.int64, copy=False), offsets


def _pack_float(arrays: list[npt.NDArray[np.float64]]) -> npt.NDArray[np.float64]:
    flat = np.concatenate(arrays) if arrays else np.empty(0, dtype=np.float64)
    return flat.astype(np.float64, copy=False)


def fuse_semantic_bundle(
    capture_manifest: str | Path,
    colmap_text_model: str | Path,
    dense_point_cloud: str | Path,
    observation_manifest: str | Path,
    track_directory: str | Path,
    output_directory: str | Path,
    *,
    minimum_score: float = 0.5,
    minimum_margin: float = 0.15,
) -> SemanticRunResult:
    session = load_capture_session(capture_manifest).session
    reconstruction = load_colmap_text_model(colmap_text_model)
    cloud = load_point_cloud(dense_point_cloud)
    tracks = _load_tracks(Path(track_directory).resolve())
    observations = _load_parts(Path(observation_manifest).resolve())

    intrinsics_by_name = {Path(frame.image_path).name: frame.intrinsics for frame in session.frames}
    cameras = tuple(
        ProjectionCamera(pose.image_name, pose, intrinsics_by_name[pose.image_name])
        for pose in reconstruction.poses
        if pose.image_name in intrinsics_by_name
    )
    if len(cameras) != len(reconstruction.poses):
        raise ValueError("not every reconstructed image has capture intrinsics")

    semantic_tracks = tuple(
        fuse_track_parts(
            cloud.points,
            cameras,
            track,
            observations,
            minimum_score=minimum_score,
            minimum_margin=minimum_margin,
        )
        for track in tracks
    )
    camera_by_name = {camera.image_name: camera for camera in cameras}
    trunk_view_arrays: list[IntArray] = []
    trunk_view_metadata: list[dict[str, object]] = []
    semantic_by_id = {track.track_id: track for track in semantic_tracks}
    for track in tracks:
        semantic_track = semantic_by_id[track.track_id]
        accepted = np.zeros(len(cloud.points), dtype=bool)
        accepted[semantic_track.trunk_indices] = True
        for observation in observations:
            if observation.part is not Part.TRUNK or observation.instance_key not in track.members:
                continue
            support = project_part_support(
                cloud.points, camera_by_name[observation.image_name], observation
            )
            support = support[accepted[support]]
            if len(support) == 0:
                continue
            trunk_view_arrays.append(support)
            trunk_view_metadata.append(
                {
                    "track_id": track.track_id,
                    "view_id": observation.image_name,
                    "local_instance_id": observation.local_instance_id,
                    "reliability": observation.reliability,
                }
            )
    excluded = (
        np.unique(np.concatenate([track.point_indices for track in tracks]))
        if tracks
        else np.empty(0, dtype=np.int64)
    )
    ground = fuse_ground_support(
        cloud.points,
        cameras,
        observations,
        excluded_point_indices=excluded,
    )
    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)

    trunk, trunk_offsets = _pack([track.trunk_indices for track in semantic_tracks])
    trunk_reliability = _pack_float([track.trunk_reliability for track in semantic_tracks])
    crown, crown_offsets = _pack([track.crown_indices for track in semantic_tracks])
    crown_reliability = _pack_float([track.crown_reliability for track in semantic_tracks])
    ambiguous, ambiguous_offsets = _pack([track.ambiguous_indices for track in semantic_tracks])
    unclassified, unclassified_offsets = _pack(
        [track.unclassified_indices for track in semantic_tracks]
    )
    trunk_view_indices, trunk_view_offsets = _pack(trunk_view_arrays)
    np.savez_compressed(
        output / "semantic-points.npz",
        trunk_indices=trunk,
        trunk_offsets=trunk_offsets,
        trunk_reliability=trunk_reliability,
        crown_indices=crown,
        crown_offsets=crown_offsets,
        crown_reliability=crown_reliability,
        ambiguous_indices=ambiguous,
        ambiguous_offsets=ambiguous_offsets,
        unclassified_indices=unclassified,
        unclassified_offsets=unclassified_offsets,
        ground_indices=ground.point_indices,
        ground_reliability=ground.point_reliability,
        trunk_view_indices=trunk_view_indices,
        trunk_view_offsets=trunk_view_offsets,
    )
    metadata = {
        "schema_version": "semantic-tracks-1.0",
        "minimum_score": minimum_score,
        "minimum_margin": minimum_margin,
        "ground_confidence": ground.confidence,
        "ground_contributing_views": ground.contributing_views,
        "trunk_view_sections": trunk_view_metadata,
        "tracks": [
            {
                "track_id": track.track_id,
                "trunk_points": len(track.trunk_indices),
                "crown_points": len(track.crown_indices),
                "ambiguous_points": len(track.ambiguous_indices),
                "unclassified_points": len(track.unclassified_indices),
                "semantic_confidence": track.semantic_confidence,
                "contributing_views": track.contributing_views,
            }
            for track in semantic_tracks
        ],
    }
    (output / "semantics.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return SemanticRunResult(
        output,
        len(semantic_tracks),
        len(trunk),
        len(crown),
        len(ambiguous),
        len(ground.point_indices),
    )
