"""Reliability-weighted multiview tree-part fusion in 3-D."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

import numpy as np
import numpy.typing as npt

from treeweaver.association.multiview import (
    InstanceObservation,
    ProjectionCamera,
    TreeTrack,
    project_visible_support,
)

BoolArray = npt.NDArray[np.bool_]
IntArray = npt.NDArray[np.int64]
FloatArray = npt.NDArray[np.float64]


class Part(StrEnum):
    TRUNK = "trunk"
    CROWN = "crown"
    GROUND = "ground"


@dataclass(frozen=True, slots=True)
class PartObservation:
    image_name: str
    local_instance_id: int
    part: Part
    mask: BoolArray
    reliability: float = 1.0

    def __post_init__(self) -> None:
        if self.mask.ndim != 2 or self.mask.dtype != np.bool_:
            raise ValueError("part mask must be a two-dimensional boolean array")
        if not 0 < self.reliability <= 1:
            raise ValueError("part reliability must be in (0, 1]")

    @property
    def instance_key(self) -> tuple[str, int]:
        return self.image_name, self.local_instance_id


@dataclass(frozen=True, slots=True)
class SemanticTrack:
    track_id: int
    trunk_indices: IntArray
    trunk_reliability: FloatArray
    crown_indices: IntArray
    crown_reliability: FloatArray
    ambiguous_indices: IntArray
    unclassified_indices: IntArray
    semantic_confidence: float
    contributing_views: int


@dataclass(frozen=True, slots=True)
class GroundSupport:
    point_indices: IntArray
    point_reliability: FloatArray
    confidence: float
    contributing_views: int


def project_part_support(
    points_world: npt.ArrayLike,
    camera: ProjectionCamera,
    observation: PartObservation,
) -> IntArray:
    generic = InstanceObservation(
        observation.image_name,
        observation.local_instance_id,
        observation.mask,
        observation.reliability,
    )
    return project_visible_support(points_world, camera, generic).point_indices


def fuse_track_parts(
    points_world: npt.ArrayLike,
    cameras: tuple[ProjectionCamera, ...],
    track: TreeTrack,
    observations: tuple[PartObservation, ...],
    *,
    minimum_score: float = 0.5,
    minimum_margin: float = 0.15,
) -> SemanticTrack:
    """Assign trunk/crown only when weighted multiview evidence is decisive."""
    points = np.asarray(points_world, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3:
        raise ValueError("points_world must be an N x 3 array")
    if not 0 <= minimum_margin <= 1 or minimum_score <= 0:
        raise ValueError("invalid semantic fusion thresholds")
    camera_by_name = {camera.image_name: camera for camera in cameras}
    member_keys = set(track.members)
    candidate = np.zeros(len(points), dtype=bool)
    candidate[track.point_indices] = True
    trunk_score = np.zeros(len(points), dtype=np.float64)
    crown_score = np.zeros(len(points), dtype=np.float64)
    contributing_views: set[str] = set()

    for observation in observations:
        if observation.part is Part.GROUND or observation.instance_key not in member_keys:
            continue
        camera = camera_by_name.get(observation.image_name)
        if camera is None:
            raise ValueError(f"no camera for semantic observation {observation.image_name}")
        indices = project_part_support(points, camera, observation)
        indices = indices[candidate[indices]]
        if len(indices) == 0:
            continue
        contributing_views.add(observation.image_name)
        if observation.part is Part.TRUNK:
            trunk_score[indices] += observation.reliability
        elif observation.part is Part.CROWN:
            crown_score[indices] += observation.reliability

    candidates = track.point_indices
    total = trunk_score + crown_score
    margin = np.abs(trunk_score - crown_score) / np.maximum(total, 1e-12)
    trunk = candidates[
        (trunk_score[candidates] >= minimum_score)
        & (trunk_score[candidates] > crown_score[candidates])
        & (margin[candidates] >= minimum_margin)
    ]
    crown = candidates[
        (crown_score[candidates] >= minimum_score)
        & (crown_score[candidates] > trunk_score[candidates])
        & (margin[candidates] >= minimum_margin)
    ]
    observed = total[candidates] > 0
    ambiguous = candidates[observed & (margin[candidates] < minimum_margin)]
    assigned = np.zeros(len(points), dtype=bool)
    assigned[trunk] = True
    assigned[crown] = True
    assigned[ambiguous] = True
    unclassified = candidates[~assigned[candidates]]
    decisive = np.r_[trunk, crown]
    semantic_confidence = (
        float(np.mean(margin[decisive]) * len(decisive) / len(candidates)) if len(decisive) else 0.0
    )
    trunk_reliability = np.clip(margin[trunk] * (1.0 - np.exp(-trunk_score[trunk])), 0.01, 1.0)
    crown_reliability = np.clip(margin[crown] * (1.0 - np.exp(-crown_score[crown])), 0.01, 1.0)
    return SemanticTrack(
        track_id=track.track_id,
        trunk_indices=trunk.astype(np.int64, copy=False),
        trunk_reliability=trunk_reliability.astype(np.float64, copy=False),
        crown_indices=crown.astype(np.int64, copy=False),
        crown_reliability=crown_reliability.astype(np.float64, copy=False),
        ambiguous_indices=ambiguous.astype(np.int64, copy=False),
        unclassified_indices=unclassified.astype(np.int64, copy=False),
        semantic_confidence=semantic_confidence,
        contributing_views=len(contributing_views),
    )


def fuse_ground_support(
    points_world: npt.ArrayLike,
    cameras: tuple[ProjectionCamera, ...],
    observations: tuple[PartObservation, ...],
    *,
    minimum_score: float = 1.0,
    excluded_point_indices: npt.ArrayLike | None = None,
) -> GroundSupport:
    points = np.asarray(points_world, dtype=np.float64)
    camera_by_name = {camera.image_name: camera for camera in cameras}
    score = np.zeros(len(points), dtype=np.float64)
    views: set[str] = set()
    total_weight = 0.0
    for observation in observations:
        if observation.part is not Part.GROUND:
            continue
        camera = camera_by_name.get(observation.image_name)
        if camera is None:
            raise ValueError(f"no camera for ground observation {observation.image_name}")
        indices = project_part_support(points, camera, observation)
        if len(indices):
            score[indices] += observation.reliability
            views.add(observation.image_name)
            total_weight += observation.reliability
    eligible = score >= minimum_score
    if excluded_point_indices is not None:
        excluded = np.asarray(excluded_point_indices, dtype=np.int64)
        if np.any((excluded < 0) | (excluded >= len(points))):
            raise ValueError("excluded ground point index is out of range")
        eligible[excluded] = False
    selected = np.flatnonzero(eligible).astype(np.int64, copy=False)
    confidence = (
        float(np.mean(score[selected]) / total_weight) if len(selected) and total_weight else 0
    )
    point_reliability = np.clip(1.0 - np.exp(-score[selected]), 0.01, 1.0)
    return GroundSupport(
        selected,
        point_reliability.astype(np.float64, copy=False),
        confidence,
        len(views),
    )
