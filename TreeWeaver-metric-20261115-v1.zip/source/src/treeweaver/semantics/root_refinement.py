"""Split fused semantic evidence by conservative root-topology ownership."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

IntArray = npt.NDArray[np.int64]
FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class RootSemanticRun:
    output_directory: Path
    tree_count: int
    trunk_points: int
    crown_points: int
    excluded_ambiguous_points: int


def _pack(arrays: list[IntArray]) -> tuple[IntArray, IntArray]:
    lengths = np.asarray([len(item) for item in arrays], dtype=np.int64)
    offsets = np.r_[0, np.cumsum(lengths)].astype(np.int64, copy=False)
    flat = np.concatenate(arrays) if arrays else np.empty(0, dtype=np.int64)
    return flat.astype(np.int64, copy=False), offsets


def _unique_with_max_reliability(
    indices: IntArray, reliability: FloatArray, labels: IntArray, tree_id: int
) -> tuple[IntArray, FloatArray]:
    selected = labels[indices] == tree_id
    candidate_indices = indices[selected]
    candidate_reliability = reliability[selected]
    if len(candidate_indices) == 0:
        return np.empty(0, dtype=np.int64), np.empty(0, dtype=np.float64)
    order = np.argsort(candidate_indices, kind="stable")
    sorted_indices = candidate_indices[order]
    sorted_reliability = candidate_reliability[order]
    unique, starts = np.unique(sorted_indices, return_index=True)
    maximum = np.maximum.reduceat(sorted_reliability, starts)
    return unique.astype(np.int64, copy=False), maximum.astype(np.float64, copy=False)


def refine_semantic_bundle_by_roots(
    semantic_directory: str | Path,
    root_assignment_directory: str | Path,
    output_directory: str | Path,
) -> RootSemanticRun:
    """Create measurement tracks from root ownership, excluding shared geometry."""

    semantic_root = Path(semantic_directory).resolve()
    assignment_root = Path(root_assignment_directory).resolve()
    metadata: dict[str, Any] = json.loads(
        (semantic_root / "semantics.json").read_text(encoding="utf-8")
    )
    assignment_metadata: dict[str, Any] = json.loads(
        (assignment_root / "root-assignment.json").read_text(encoding="utf-8")
    )
    if metadata.get("schema_version") != "semantic-tracks-1.0":
        raise ValueError("unsupported semantic-track schema")
    if assignment_metadata.get("schema_version") != "root-assignment-1.0":
        raise ValueError("unsupported root-assignment schema")
    with np.load(semantic_root / "semantic-points.npz", allow_pickle=False) as arrays:
        source = {name: np.asarray(arrays[name]) for name in arrays.files}
    with np.load(assignment_root / "root-assignment.npz", allow_pickle=False) as arrays:
        labels = np.asarray(arrays["labels"], dtype=np.int64)
        root_confidence = np.asarray(arrays["confidence"], dtype=np.float64)
    if labels.shape != root_confidence.shape or labels.ndim != 1:
        raise ValueError("root labels and confidence must be matching vectors")

    trunk = np.asarray(source["trunk_indices"], dtype=np.int64)
    crown = np.asarray(source["crown_indices"], dtype=np.int64)
    trunk_reliability = np.asarray(source["trunk_reliability"], dtype=np.float64)
    crown_reliability = np.asarray(source["crown_reliability"], dtype=np.float64)
    if len(trunk) != len(trunk_reliability) or len(crown) != len(crown_reliability):
        raise ValueError("semantic indices and reliability lengths disagree")
    used_arrays = [array for array in (trunk, crown) if len(array)]
    if used_arrays and max(int(np.max(array)) for array in used_arrays) >= len(labels):
        raise ValueError("semantic point index lies outside root assignment")

    tree_ids = tuple(int(item["tree_id"]) for item in assignment_metadata.get("trees", []))
    if not tree_ids or len(set(tree_ids)) != len(tree_ids):
        raise ValueError("root assignment requires unique tree metadata")
    trunks: list[IntArray] = []
    crowns: list[IntArray] = []
    trunk_reliabilities: list[FloatArray] = []
    crown_reliabilities: list[FloatArray] = []
    track_metadata: list[dict[str, object]] = []
    for tree_id in tree_ids:
        tree_trunk, tree_trunk_reliability = _unique_with_max_reliability(
            trunk, trunk_reliability, labels, tree_id
        )
        tree_crown, tree_crown_reliability = _unique_with_max_reliability(
            crown, crown_reliability, labels, tree_id
        )
        trunks.append(tree_trunk)
        crowns.append(tree_crown)
        trunk_reliabilities.append(tree_trunk_reliability)
        crown_reliabilities.append(tree_crown_reliability)
        owned = np.r_[tree_trunk, tree_crown]
        topology_confidence = float(np.mean(root_confidence[owned])) if len(owned) else 0.0
        semantic_values = np.r_[tree_trunk_reliability, tree_crown_reliability]
        semantic_confidence = float(np.mean(semantic_values)) if len(semantic_values) else 0.0
        track_metadata.append(
            {
                "track_id": tree_id,
                "trunk_points": len(tree_trunk),
                "crown_points": len(tree_crown),
                "ambiguous_points": 0,
                "unclassified_points": 0,
                "semantic_confidence": semantic_confidence,
                "topology_confidence": topology_confidence,
                "contributing_views": 0,
            }
        )

    packed_trunk, trunk_offsets = _pack(trunks)
    packed_crown, crown_offsets = _pack(crowns)
    packed_trunk_reliability = (
        np.concatenate(trunk_reliabilities)
        if trunk_reliabilities
        else np.empty(0, dtype=np.float64)
    )
    packed_crown_reliability = (
        np.concatenate(crown_reliabilities)
        if crown_reliabilities
        else np.empty(0, dtype=np.float64)
    )

    source_view_indices = np.asarray(
        source.get("trunk_view_indices", np.empty(0)), dtype=np.int64
    )
    source_view_offsets = np.asarray(source.get("trunk_view_offsets", [0]), dtype=np.int64)
    source_sections = metadata.get("trunk_view_sections", [])
    if len(source_view_offsets) != len(source_sections) + 1:
        raise ValueError("source trunk-view metadata and offsets disagree")
    view_arrays: list[IntArray] = []
    view_metadata: list[dict[str, object]] = []
    for index, section in enumerate(source_sections):
        indices = source_view_indices[source_view_offsets[index] : source_view_offsets[index + 1]]
        for tree_id in tree_ids:
            selected = np.unique(indices[labels[indices] == tree_id]).astype(
                np.int64, copy=False
            )
            if len(selected) == 0:
                continue
            view_arrays.append(selected)
            view_metadata.append(
                {
                    "track_id": tree_id,
                    "view_id": str(section["view_id"]),
                    "local_instance_id": int(section.get("local_instance_id", 0)),
                    "reliability": float(section.get("reliability", 1.0)),
                }
            )
    packed_views, view_offsets = _pack(view_arrays)
    ambiguous_tree_evidence = np.unique(
        np.r_[trunk[labels[trunk] == 0], crown[labels[crown] == 0]]
    ).astype(np.int64, copy=False)

    output = Path(output_directory).resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    empty_offsets = np.zeros(len(tree_ids) + 1, dtype=np.int64)
    np.savez_compressed(
        output / "semantic-points.npz",
        trunk_indices=packed_trunk,
        trunk_offsets=trunk_offsets,
        trunk_reliability=packed_trunk_reliability,
        crown_indices=packed_crown,
        crown_offsets=crown_offsets,
        crown_reliability=packed_crown_reliability,
        ambiguous_indices=np.empty(0, dtype=np.int64),
        ambiguous_offsets=empty_offsets,
        unclassified_indices=np.empty(0, dtype=np.int64),
        unclassified_offsets=empty_offsets,
        root_ambiguous_indices=ambiguous_tree_evidence,
        ground_indices=np.asarray(source["ground_indices"], dtype=np.int64),
        ground_reliability=np.asarray(source["ground_reliability"], dtype=np.float64),
        trunk_view_indices=packed_views,
        trunk_view_offsets=view_offsets,
    )
    refined_metadata = {
        "schema_version": "semantic-tracks-1.0",
        "refinement": "root_topology_v1",
        "source_semantics": str(semantic_root),
        "root_assignment": str(assignment_root),
        "ground_confidence": float(metadata.get("ground_confidence", 0.0)),
        "ground_contributing_views": int(metadata.get("ground_contributing_views", 0)),
        "excluded_root_ambiguous_points": len(ambiguous_tree_evidence),
        "trunk_view_sections": view_metadata,
        "tracks": track_metadata,
    }
    (output / "semantics.json").write_text(
        json.dumps(refined_metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return RootSemanticRun(
        output,
        len(tree_ids),
        len(packed_trunk),
        len(packed_crown),
        len(ambiguous_tree_evidence),
    )
