"""Register an arbitrary reconstruction to metric scale using explicit anchors."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.calibration.scale import ScaleEstimate, estimate_metric_scale
from treeweaver.domain.models import ScaleAnchor
from treeweaver.reconstruction.model import CameraPose, Reconstruction, SparsePoint


@dataclass(frozen=True, slots=True)
class AnchorCorrespondence:
    kind: str
    metric_length_m: float
    endpoint_a: npt.NDArray[np.float64]
    endpoint_b: npt.NDArray[np.float64]
    confidence: float = 1.0

    def reconstructed_length(self) -> float:
        a = np.asarray(self.endpoint_a, dtype=np.float64)
        b = np.asarray(self.endpoint_b, dtype=np.float64)
        if a.shape != (3,) or b.shape != (3,) or not np.isfinite([a, b]).all():
            raise ValueError("anchor endpoints must be finite 3-D vectors")
        length = float(np.linalg.norm(a - b))
        if length <= 0:
            raise ValueError("anchor endpoints must be distinct")
        return length


def estimate_scale_from_correspondences(
    correspondences: tuple[AnchorCorrespondence, ...],
) -> ScaleEstimate:
    anchors = tuple(
        ScaleAnchor(
            kind=item.kind,
            metric_length_m=item.metric_length_m,
            reconstructed_length=item.reconstructed_length(),
            confidence=item.confidence,
        )
        for item in correspondences
    )
    return estimate_metric_scale(anchors)


def scale_reconstruction(reconstruction: Reconstruction, scale: ScaleEstimate) -> Reconstruction:
    if reconstruction.coordinate_system == "metric":
        raise ValueError("reconstruction is already metric")
    factor = scale.metres_per_unit
    poses = tuple(
        CameraPose(
            image_id=pose.image_id,
            camera_id=pose.camera_id,
            image_name=pose.image_name,
            rotation_world_to_camera=pose.rotation_world_to_camera.copy(),
            translation_world_to_camera=pose.translation_world_to_camera * factor,
        )
        for pose in reconstruction.poses
    )
    points = tuple(
        SparsePoint(
            point_id=point.point_id,
            xyz=point.xyz * factor,
            reprojection_error_px=point.reprojection_error_px,
            track_length=point.track_length,
        )
        for point in reconstruction.points
    )
    return Reconstruction(
        poses=poses,
        points=points,
        coordinate_system="metric",
        scale_metres_per_unit=factor,
        scale_standard_deviation=scale.standard_deviation,
    )
