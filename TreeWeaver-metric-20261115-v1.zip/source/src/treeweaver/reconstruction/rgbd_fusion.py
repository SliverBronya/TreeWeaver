"""Metric RGB-D back-projection and confidence-aware multi-view voxel fusion."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

from treeweaver.domain.models import CameraIntrinsics

FloatArray = npt.NDArray[np.float64]
BoolArray = npt.NDArray[np.bool_]


@dataclass(frozen=True, slots=True)
class MetricRgbdObservation:
    frame_id: str
    depth_m: FloatArray
    tree_mask: BoolArray
    intrinsics: CameraIntrinsics
    camera_to_world: FloatArray
    confidence: FloatArray | None = None
    colors_rgb: npt.NDArray[np.uint8] | None = None

    def __post_init__(self) -> None:
        expected = (self.intrinsics.height, self.intrinsics.width)
        if self.depth_m.shape != expected or self.tree_mask.shape != expected:
            raise ValueError("depth, mask and intrinsics dimensions disagree")
        if self.confidence is not None and self.confidence.shape != expected:
            raise ValueError("depth confidence dimensions disagree")
        if self.colors_rgb is not None and self.colors_rgb.shape != (*expected, 3):
            raise ValueError("RGB image dimensions disagree")
        if self.camera_to_world.shape != (4, 4):
            raise ValueError("camera_to_world must be 4 x 4")
        if not np.isfinite(self.camera_to_world).all():
            raise ValueError("camera_to_world contains non-finite values")
        if not np.allclose(self.camera_to_world[3], (0, 0, 0, 1), atol=1e-8):
            raise ValueError("camera_to_world must be homogeneous")
        rotation = self.camera_to_world[:3, :3]
        if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-4):
            raise ValueError("camera_to_world rotation must be orthonormal")
        if not np.isclose(np.linalg.det(rotation), 1.0, atol=1e-4):
            raise ValueError("camera_to_world rotation must have determinant +1")


@dataclass(frozen=True, slots=True)
class FusedRgbdCloud:
    points_world: FloatArray
    confidence: FloatArray
    view_count: npt.NDArray[np.int64]
    colors_rgb: npt.NDArray[np.uint8] | None = None


def backproject_tree(
    observation: MetricRgbdObservation,
    *,
    minimum_depth_m: float = 0.25,
    maximum_depth_m: float = 25.0,
    minimum_confidence: float = 0.35,
    stride: int = 1,
) -> tuple[FloatArray, FloatArray, npt.NDArray[np.uint8] | None]:
    """Back-project one masked metric-depth frame into ARCore world coordinates."""

    if minimum_depth_m <= 0 or maximum_depth_m <= minimum_depth_m or stride < 1:
        raise ValueError("invalid depth limits or stride")
    depth = np.asarray(observation.depth_m, dtype=np.float64)
    confidence = (
        np.ones_like(depth)
        if observation.confidence is None
        else np.asarray(observation.confidence, dtype=np.float64)
    )
    valid = (
        observation.tree_mask
        & np.isfinite(depth)
        & (depth >= minimum_depth_m)
        & (depth <= maximum_depth_m)
        & np.isfinite(confidence)
        & (confidence >= minimum_confidence)
    )
    if stride > 1:
        sample = np.zeros_like(valid)
        sample[::stride, ::stride] = True
        valid &= sample
    rows, columns = np.nonzero(valid)
    if rows.size == 0:
        return np.empty((0, 3)), np.empty(0), None
    z = depth[rows, columns]
    intrinsics = observation.intrinsics
    camera_points = np.column_stack(
        (
            (columns - intrinsics.cx) * z / intrinsics.fx,
            (rows - intrinsics.cy) * z / intrinsics.fy,
            z,
            np.ones_like(z),
        )
    )
    world = (observation.camera_to_world @ camera_points.T).T[:, :3]
    colors = observation.colors_rgb[rows, columns] if observation.colors_rgb is not None else None
    return world, confidence[rows, columns], colors


def fuse_metric_rgbd(
    observations: tuple[MetricRgbdObservation, ...],
    *,
    voxel_size_m: float = 0.02,
    minimum_confidence: float = 0.35,
    minimum_views: int = 1,
    stride: int = 1,
) -> FusedRgbdCloud:
    """Fuse already metric ARCore frames; no independent scale anchor is required."""

    if not observations:
        raise ValueError("at least one RGB-D observation is required")
    if voxel_size_m <= 0 or minimum_views < 1:
        raise ValueError("voxel size and minimum view count must be positive")
    points_parts: list[FloatArray] = []
    weights_parts: list[FloatArray] = []
    view_parts: list[npt.NDArray[np.int64]] = []
    color_parts: list[npt.NDArray[np.uint8]] = []
    all_have_color = all(item.colors_rgb is not None for item in observations)
    for view_index, observation in enumerate(observations):
        points, weights, colors = backproject_tree(
            observation,
            minimum_confidence=minimum_confidence,
            stride=stride,
        )
        if len(points) == 0:
            continue
        points_parts.append(points)
        weights_parts.append(weights)
        view_parts.append(np.full(len(points), view_index, dtype=np.int64))
        if all_have_color and colors is not None:
            color_parts.append(colors)
    if not points_parts:
        raise ValueError("no valid tree depth samples survived filtering")

    points = np.vstack(points_parts)
    weights = np.concatenate(weights_parts)
    view_ids = np.concatenate(view_parts)
    colors_float = np.vstack(color_parts).astype(np.float64) if all_have_color else None
    voxel_keys = np.floor(points / voxel_size_m).astype(np.int64)
    _, inverse = np.unique(voxel_keys, axis=0, return_inverse=True)
    voxel_count = int(inverse.max()) + 1
    weight_sum = np.bincount(inverse, weights=weights, minlength=voxel_count)
    fused = np.column_stack(
        [
            np.bincount(inverse, weights=weights * points[:, axis], minlength=voxel_count)
            / np.maximum(weight_sum, 1e-12)
            for axis in range(3)
        ]
    )
    sample_count = np.bincount(inverse, minlength=voxel_count)
    mean_confidence = weight_sum / np.maximum(sample_count, 1)
    distinct_views = np.zeros(voxel_count, dtype=np.int64)
    for voxel in range(voxel_count):
        distinct_views[voxel] = np.unique(view_ids[inverse == voxel]).size
    keep = distinct_views >= minimum_views

    fused_colors = None
    if colors_float is not None:
        fused_colors = np.column_stack(
            [
                np.bincount(
                    inverse,
                    weights=weights * colors_float[:, axis],
                    minlength=voxel_count,
                )
                / np.maximum(weight_sum, 1e-12)
                for axis in range(3)
            ]
        )
        fused_colors = np.clip(np.rint(fused_colors[keep]), 0, 255).astype(np.uint8)
    return FusedRgbdCloud(fused[keep], mean_confidence[keep], distinct_views[keep], fused_colors)
