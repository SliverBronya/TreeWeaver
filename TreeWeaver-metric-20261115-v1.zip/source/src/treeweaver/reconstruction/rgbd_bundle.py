"""File boundary for fusing one tree from an ARCore metric RGB-D session."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import numpy.typing as npt

from treeweaver.io.session import load_capture_session
from treeweaver.measurement.rgbd_tree import measure_fused_tree
from treeweaver.reconstruction.rgbd_fusion import MetricRgbdObservation, fuse_metric_rgbd


@dataclass(frozen=True, slots=True)
class RgbdFusionRun:
    frame_count: int
    point_count: int
    cloud_path: Path
    measurement_path: Path


def _maximum_camera_baseline(observations: list[MetricRgbdObservation]) -> float:
    centres = np.asarray([item.camera_to_world[:3, 3] for item in observations])
    offsets = centres[:, None, :] - centres[None, :, :]
    return float(np.max(np.linalg.norm(offsets, axis=2)))


def _leave_one_view_out(
    observations: list[MetricRgbdObservation],
    gravity: tuple[float, float, float],
    *,
    voxel_size_m: float,
    minimum_depth_confidence: float,
    stride: int,
) -> dict[str, float | int]:
    values: list[tuple[float, float, float]] = []
    if len(observations) < 3:
        return {"successful_runs": 0}
    for held_out in range(len(observations)):
        subset = tuple(item for index, item in enumerate(observations) if index != held_out)
        try:
            cloud = fuse_metric_rgbd(
                subset,
                voxel_size_m=voxel_size_m,
                minimum_confidence=minimum_depth_confidence,
                minimum_views=1,
                stride=stride,
            )
            result = measure_fused_tree(cloud.points_world, gravity)
        except ValueError:
            continue
        values.append((result.height_m, result.dbh_cm, result.crown_width_m))
    if not values:
        return {"successful_runs": 0}
    array = np.asarray(values)
    return {
        "successful_runs": len(values),
        "height_sd_m": float(np.std(array[:, 0], ddof=1)) if len(values) > 1 else 0.0,
        "dbh_sd_cm": float(np.std(array[:, 1], ddof=1)) if len(values) > 1 else 0.0,
        "crown_width_sd_m": float(np.std(array[:, 2], ddof=1)) if len(values) > 1 else 0.0,
    }


def _safe(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError(f"asset escapes its bundle: {relative}")
    return candidate


def _load_image(path: Path, flags: int) -> npt.NDArray[Any]:
    import cv2

    image = cv2.imread(str(path), flags)
    if image is None:
        raise ValueError(f"cannot decode image: {path}")
    return np.asarray(image)


def fuse_rgbd_tree_bundle(
    capture_manifest: str | Path,
    masks_manifest: str | Path,
    output_directory: str | Path,
    *,
    voxel_size_m: float = 0.02,
    minimum_depth_confidence: float = 0.35,
    minimum_views: int = 1,
    stride: int = 1,
) -> RgbdFusionRun:
    capture_path = Path(capture_manifest).resolve()
    validation = load_capture_session(capture_path)
    session = validation.session
    if not session.capabilities.has_metric_depth:
        raise ValueError("RGB-D fusion requires metric depth")
    masks_path = Path(masks_manifest).resolve()
    payload: dict[str, Any] = json.loads(masks_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "tree-rgbd-masks-1.0":
        raise ValueError("unsupported RGB-D mask manifest")
    mask_by_frame = {
        str(item["frame_id"]): _safe(masks_path.parent, str(item["mask_path"]))
        for item in payload.get("frames", [])
    }
    observations: list[MetricRgbdObservation] = []
    for frame in session.frames:
        if frame.frame_id not in mask_by_frame or frame.tracking_state != "tracking":
            continue
        if not frame.depth_path or not frame.depth_confidence_path or not frame.camera_to_world:
            continue
        root = capture_path.parent
        depth_raw = _load_image(_safe(root, frame.depth_path), -1)
        confidence_raw = _load_image(_safe(root, frame.depth_confidence_path), 0)
        mask = _load_image(mask_by_frame[frame.frame_id], 0) > 127
        color_bgr = _load_image(_safe(root, frame.image_path), 1)
        expected = (frame.intrinsics.height, frame.intrinsics.width)
        dimensions = (depth_raw.shape, confidence_raw.shape, mask.shape)
        if any(shape != expected for shape in dimensions):
            raise ValueError(
                f"frame {frame.frame_id} depth, confidence and mask must be pre-aligned "
                "to the declared intrinsics"
            )
        observations.append(
            MetricRgbdObservation(
                frame.frame_id,
                depth_raw.astype(np.float64) * frame.depth_unit_m,
                mask,
                frame.intrinsics,
                np.asarray(frame.camera_to_world, dtype=np.float64).reshape(4, 4),
                confidence_raw.astype(np.float64) / 255.0,
                color_bgr[..., ::-1].copy(),
            )
        )
    if len(observations) < 2:
        raise ValueError("at least two tracked, masked RGB-D frames are required")
    cloud = fuse_metric_rgbd(
        tuple(observations),
        voxel_size_m=voxel_size_m,
        minimum_confidence=minimum_depth_confidence,
        minimum_views=minimum_views,
        stride=stride,
    )
    gravity = session.gravity_down_world or (0.0, -1.0, 0.0)
    geometry = measure_fused_tree(cloud.points_world, gravity)
    maximum_baseline_m = _maximum_camera_baseline(observations)
    repeated_support = float(np.mean(cloud.view_count >= 2))
    uncertainty = _leave_one_view_out(
        observations,
        gravity,
        voxel_size_m=voxel_size_m,
        minimum_depth_confidence=minimum_depth_confidence,
        stride=stride,
    )
    quality_issues: list[str] = []
    if maximum_baseline_m < 0.15:
        quality_issues.append("camera translation baseline is below 0.15 m")
    if repeated_support < 0.10:
        quality_issues.append("fewer than 10% of fused voxels have support from two views")
    if len(observations) >= 3 and int(uncertainty["successful_runs"]) < 2:
        quality_issues.append("leave-one-view-out uncertainty could not be estimated")
    output = Path(output_directory).resolve()
    output.mkdir(parents=True, exist_ok=True)
    cloud_path = output / "tree-rgbd-cloud.npz"
    if cloud.colors_rgb is not None:
        np.savez_compressed(
            cloud_path,
            points=cloud.points_world,
            confidence=cloud.confidence,
            view_count=cloud.view_count,
            colors=cloud.colors_rgb,
        )
    else:
        np.savez_compressed(
            cloud_path,
            points=cloud.points_world,
            confidence=cloud.confidence,
            view_count=cloud.view_count,
        )
    measurement_path = output / "tree-rgbd-measurement.json"
    measurement_path.write_text(
        json.dumps(
            {
                "schema_version": "tree-rgbd-measurement-1.0",
                "tree_id": str(payload["tree_id"]),
                "metric_source": "ARCore depth + ARCore world pose",
                "manual_scale_required": False,
                "frame_count": len(observations),
                "voxel_size_m": voxel_size_m,
                "minimum_depth_confidence": minimum_depth_confidence,
                "minimum_views": minimum_views,
                "geometry": asdict(geometry),
                "uncertainty": uncertainty,
                "quality": {
                    "passed": not quality_issues,
                    "maximum_camera_baseline_m": maximum_baseline_m,
                    "multi_view_supported_voxel_fraction": repeated_support,
                    "issues": quality_issues,
                },
                "capture_warnings": list(validation.warnings),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return RgbdFusionRun(len(observations), len(cloud.points_world), cloud_path, measurement_path)
