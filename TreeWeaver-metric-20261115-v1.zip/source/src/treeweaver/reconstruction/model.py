"""Framework-neutral reconstruction outputs."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt

FloatArray = npt.NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class CameraPose:
    image_id: int
    camera_id: int
    image_name: str
    rotation_world_to_camera: FloatArray
    translation_world_to_camera: FloatArray

    @property
    def centre_world(self) -> FloatArray:
        return -self.rotation_world_to_camera.T @ self.translation_world_to_camera


@dataclass(frozen=True, slots=True)
class SparsePoint:
    point_id: int
    xyz: FloatArray
    reprojection_error_px: float
    track_length: int


@dataclass(frozen=True, slots=True)
class Reconstruction:
    poses: tuple[CameraPose, ...]
    points: tuple[SparsePoint, ...]
    coordinate_system: str = "arbitrary_scale"
    scale_metres_per_unit: float | None = None
    scale_standard_deviation: float | None = None

    def xyz(self, *, max_error_px: float | None = None) -> FloatArray:
        selected = self.points
        if max_error_px is not None:
            selected = tuple(
                point for point in selected if point.reprojection_error_px <= max_error_px
            )
        if not selected:
            return np.empty((0, 3), dtype=np.float64)
        return np.stack([point.xyz for point in selected]).astype(np.float64, copy=False)
