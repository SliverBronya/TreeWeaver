"""Reconstruction quality gates used before biological measurement."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from treeweaver.reconstruction.model import Reconstruction


@dataclass(frozen=True, slots=True)
class QualityThresholds:
    minimum_registration_ratio: float = 0.70
    maximum_median_reprojection_error_px: float = 1.5
    minimum_median_track_length: float = 3.0
    minimum_camera_baseline_units: float = 0.05
    minimum_sparse_points: int = 100


@dataclass(frozen=True, slots=True)
class ReconstructionQuality:
    passed: bool
    registered_images: int
    expected_images: int
    registration_ratio: float
    sparse_points: int
    median_reprojection_error_px: float
    p90_reprojection_error_px: float
    median_track_length: float
    camera_baseline: float
    point_extent: tuple[float, float, float]
    issues: tuple[str, ...]


def assess_reconstruction_quality(
    reconstruction: Reconstruction,
    expected_images: int,
    thresholds: QualityThresholds | None = None,
) -> ReconstructionQuality:
    thresholds = thresholds if thresholds is not None else QualityThresholds()
    if expected_images < 2:
        raise ValueError("expected_images must be at least two")
    registered = len(reconstruction.poses)
    ratio = registered / expected_images
    errors = np.array(
        [point.reprojection_error_px for point in reconstruction.points], dtype=np.float64
    )
    tracks = np.array([point.track_length for point in reconstruction.points], dtype=np.float64)
    if len(errors):
        median_error = float(np.median(errors))
        p90_error = float(np.quantile(errors, 0.90))
        median_track = float(np.median(tracks))
        xyz = reconstruction.xyz()
        extent_array = np.ptp(xyz, axis=0)
        extent = (
            float(extent_array[0]),
            float(extent_array[1]),
            float(extent_array[2]),
        )
    else:
        median_error = float("inf")
        p90_error = float("inf")
        median_track = 0.0
        extent = (0.0, 0.0, 0.0)

    centres = [pose.centre_world for pose in reconstruction.poses]
    if len(centres) >= 2:
        centre_array = np.stack(centres)
        camera_baseline = float(np.max(np.linalg.norm(centre_array - centre_array[0], axis=1)))
    else:
        camera_baseline = 0.0

    issues: list[str] = []
    if ratio < thresholds.minimum_registration_ratio:
        issues.append("too few input images were registered")
    if len(errors) < thresholds.minimum_sparse_points:
        issues.append("sparse reconstruction contains too few points")
    if median_error > thresholds.maximum_median_reprojection_error_px:
        issues.append("median reprojection error exceeds threshold")
    if median_track < thresholds.minimum_median_track_length:
        issues.append("point tracks are too short for stable multiview geometry")
    if camera_baseline < thresholds.minimum_camera_baseline_units:
        issues.append("camera motion baseline is too small")

    return ReconstructionQuality(
        passed=not issues,
        registered_images=registered,
        expected_images=expected_images,
        registration_ratio=ratio,
        sparse_points=len(errors),
        median_reprojection_error_px=median_error,
        p90_reprojection_error_px=p90_error,
        median_track_length=median_track,
        camera_baseline=camera_baseline,
        point_extent=extent,
        issues=tuple(issues),
    )


def write_quality_report(report: ReconstructionQuality, output_path: str | Path) -> Path:
    """Write strict JSON, representing unavailable infinite metrics as null."""
    payload: dict[str, object] = {
        "schema_version": "reconstruction-quality-1.0",
        "passed": report.passed,
        "registered_images": report.registered_images,
        "expected_images": report.expected_images,
        "registration_ratio": report.registration_ratio,
        "sparse_points": report.sparse_points,
        "median_reprojection_error_px": (
            report.median_reprojection_error_px
            if np.isfinite(report.median_reprojection_error_px)
            else None
        ),
        "p90_reprojection_error_px": (
            report.p90_reprojection_error_px
            if np.isfinite(report.p90_reprojection_error_px)
            else None
        ),
        "median_track_length": report.median_track_length,
        "camera_baseline": report.camera_baseline,
        "point_extent": report.point_extent,
        "issues": report.issues,
    }
    destination = Path(output_path).resolve()
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )
    return destination
