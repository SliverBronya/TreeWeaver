@echo off
REM =============================================================
REM  Trunk-level ConvexMask training, driven by a repeating task.
REM  1. waits for the v3 annotations; if they are still missing
REM     after ~25 min, builds them itself (the agent-launched build
REM     may have been torn down).
REM  2. starts the watchdog, which restarts training until done.
REM  Uses "ping" for sleeping: "timeout" needs a console and fails
REM  inside a scheduled task.
REM =============================================================
setlocal
cd /d D:\TreeWeaver

set PY=D:\TreeWeaver\.worker-envs\sam2-shared\Scripts\python.exe
set LABELS=D:\TreeWeaver\data\processed\synthtree43k-trunk-v3-2026-10-20
set OUT=D:\TreeWeaver\reports\convexmask-synthtree-trunk-v3-2026-10-20
set LOG=D:\TreeWeaver\reports\trunk-launcher.log
set PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
set /a TRIES=0

echo [%date% %time%] launcher started >> "%LOG%"

:wait
if exist "%LABELS%\test_trunk.json" goto ready
set /a TRIES+=1
if %TRIES% geq 25 goto buildit
ping -n 61 127.0.0.1 >nul 2>&1
goto wait

:buildit
echo [%date% %time%] annotations missing after 25 min, building them here >> "%LOG%"
"%PY%" "D:\TreeWeaver\scripts\build_synthtree_trunk_all.py" >> "%LOG%" 2>&1
set /a TRIES=0
goto wait

:ready
echo [%date% %time%] annotations ready, starting watchdog >> "%LOG%"
"%PY%" "D:\TreeWeaver\scripts\watch_convexmask_training.py" ^
  --output "%OUT%" ^
  --python "%PY%" ^
  --train-script "D:\TreeWeaver\scripts\train_convexmask_synthtree_continuous.py" ^
  --stall-minutes 20 ^
  --backoff 30 ^
  -- ^
  --data-root "D:\TreeWeaver\data\external\synthtree43k" ^
  --label-root "%LABELS%" ^
  --label-template "{split}_trunk.json" ^
  --source "D:\TreeWeaver\data\external\convexmask-source" ^
  --extra-packages "D:\TreeWeaver\.worker-envs\convexmask-extra" ^
  --backbone "C:/Users/Mendel/.cache/torch/hub/checkpoints/resnet50-0676ba61.pth" ^
  --output "%OUT%" ^
  --epochs 29 ^
  --recipe author ^
  --loader-threads 4 ^
  --loader-timeout 120 ^
  --checkpoint-every 200 ^
  --eval-size 960,540 ^
  --validate-every 2000 ^
  --full-validate-every 5 >> "%LOG%" 2>&1

echo [%date% %time%] watchdog exited >> "%LOG%"
