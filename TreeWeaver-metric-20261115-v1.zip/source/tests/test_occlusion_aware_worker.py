"""Run with a PyTorch worker Python; the core project's runtime stays torch-free."""

import importlib.util
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
SPEC = importlib.util.spec_from_file_location(
    "occlusion_aware",
    Path(__file__).resolve().parents[1] / "workers" / "tree_models" / "occlusion_aware.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def tensors(batch=1, instances=2, channels=8, height=8, width=8, mask_dim=32):
    torch.manual_seed(7)
    features = [torch.randn(batch, channels, height, width)]
    anchors = torch.randn(batch, instances, channels)
    proto = torch.randn(batch, mask_dim, height, width)
    modal = torch.randn(batch, instances, height, width)
    return features, anchors, proto, modal


def test_principal_focus_attention_is_normalised():
    features, anchors, _, _ = tensors()
    focus = MODULE.PrincipalFocus((8,), embedding=8)
    result = focus(features, anchors)
    attention = result["attention"][0]
    assert attention.shape == (1, 2, 1, 8, 8)
    torch.testing.assert_close(
        attention.sum(dim=(-1, -2)).squeeze(2), torch.ones(1, 2)
    )
    assert result["pooled"].shape == (1, 2, 8)
    assert torch.isfinite(result["pooled"]).all()


def test_principal_focus_requires_matching_pyramid():
    features, anchors, _, _ = tensors()
    focus = MODULE.PrincipalFocus((8, 8), embedding=8)
    with pytest.raises(ValueError):
        focus(features, anchors)


def test_visibility_head_is_bounded_and_differentiable():
    _, _, _, _ = tensors()
    head = MODULE.VisibilityHead(8)
    instance = torch.randn(1, 2, 8)
    result = head(instance)
    assert (result["mean"] >= 0).all() and (result["mean"] <= 1).all()
    assert (result["log_variance"] >= -8).all() and (result["log_variance"] <= 8).all()
    target = torch.tensor([[[0.9, 0.4], [0.3, 0.8]]])
    loss = MODULE.visibility_nll(
        result["mean"], result["log_variance"], target, weights=torch.ones_like(target)
    )
    loss.backward()
    assert torch.isfinite(head.mlp[0].weight.grad).all()


def test_visibility_nll_rejects_out_of_range_targets():
    with pytest.raises(ValueError):
        MODULE.visibility_nll(
            torch.full((1,), 0.5), torch.zeros(1), torch.tensor([1.2])
        )


def test_moe_routing_sums_to_one_and_tracks_visibility():
    moe = MODULE.InstanceMoE(8, experts=3, hidden=16, centres=(0.2, 0.5, 0.8))
    instance = torch.randn(1, 2, 8)
    low = moe(instance, torch.tensor([[0.2, 0.8]]))
    torch.testing.assert_close(low["weights"].sum(-1), torch.ones(1, 2))
    assert float(low["weights"][0, 0, 0]) > 0.8
    assert float(low["weights"][0, 1, 2]) > 0.8
    assert low["output"].shape == instance.shape


def test_moe_centres_must_match_expert_count():
    with pytest.raises(ValueError):
        MODULE.InstanceMoE(8, experts=3, centres=(0.2, 0.8))


def test_amodal_head_contains_the_modal_mask():
    _, _, proto, modal = tensors()
    instance = torch.randn(1, 2, 8)
    head = MODULE.AmodalHead(8, mask_dim=32)
    result = head(instance, proto, modal)
    assert (result["amodal_logits"] >= modal - 1e-5).all()
    assert result["delta_coefficients"].shape == (1, 2, 32)
    assert result["delta"].min() > 0


def test_containment_loss_is_zero_when_visible_pixels_are_confident():
    modal = torch.full((1, 2, 4, 4), 10.0)
    visible = torch.ones_like(modal)
    assert float(MODULE.amodal_containment_loss(modal, visible)) == 0.0


def test_curve_head_range_and_masked_loss_ignores_missing_knots():
    head = MODULE.CrownCurveHead(8, knots=6, hidden=16)
    result = head(torch.randn(1, 2, 8))
    assert (result["curve"] >= 0).all() and (result["curve"] <= 1).all()
    assert result["log_sigma"].shape == (1, 2, 6)
    observed = torch.tensor([[[True, True, True, False, False, False]]]).expand(1, 2, 6)
    target = torch.zeros(1, 2, 6)
    # Missing knots hold nonsense; the loss must ignore them.
    target[..., 3:] = 99.0
    loss = MODULE.curve_nll(result["curve"], result["log_sigma"], target, observed)
    loss.backward()
    assert torch.isfinite(loss).all()
    assert torch.isfinite(head.mlp[0].weight.grad).all()


def test_fusion_gate_zero_returns_exact_modal_logits():
    _, _, _, modal = tensors()
    head = MODULE.FusionGate()
    amodal = modal + torch.rand_like(modal) * 5
    result = head(modal, amodal, gate_override=0.0)
    assert torch.equal(result["logits"], modal)
    normal = head(modal, amodal)
    assert (normal["gate"] >= 0).all() and (normal["gate"] <= 1).all()


def test_routing_balance_is_zero_for_uniform_usage():
    uniform = torch.full((2, 3, 3), 1 / 3)
    assert abs(float(MODULE.routing_balance_loss(uniform))) < 1e-6
    collapsed = torch.zeros(2, 3, 3)
    collapsed[..., 0] = 1.0
    assert float(MODULE.routing_balance_loss(collapsed)) == pytest.approx(2.0)


def test_amodal_bce_upweights_occluded_errors():
    # Both rows are tree pixels; the visible row is right, the occluded row is wrong.
    logits = torch.tensor([[[[5.0, 5.0], [-5.0, -5.0]]]])
    target = torch.ones_like(logits)
    visible = torch.tensor([[[[1.0, 1.0], [0.0, 0.0]]]])
    base = MODULE.amodal_bce(logits, target, visible, occluded_weight=0.0)
    weighted = MODULE.amodal_bce(logits, target, visible, occluded_weight=3.0)
    assert float(weighted) > float(base)


def test_bundle_forward_and_backward_are_finite():
    _, _, proto, modal = tensors()
    bundle = MODULE.OcclusionAwareHeads(8, mask_dim=32, knots=6, experts=3)
    instance = torch.randn(1, 2, 8)
    out = bundle(instance, proto, modal)
    assert out["amodal_logits"].shape == modal.shape
    assert out["fused_logits"].shape == modal.shape
    assert out["curve"].shape == (1, 2, 6)
    loss = out["fused_logits"].mean() + out["curve"].mean() + out["visibility"]["mean"].sum()
    loss.backward()
    assert torch.isfinite(bundle.visibility.mlp[0].weight.grad).all()
    assert torch.isfinite(bundle.amodal.coefficients.weight.grad).all()
