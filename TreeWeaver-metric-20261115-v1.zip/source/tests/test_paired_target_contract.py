import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from paired_target_contract import (  # noqa: E402
    local_occlusion_targets,
    paired_part_validity,
    visibility_targets,
)


def interleaved():
    # Both trees exist behind each other on different rows; no global rank fits.
    complete = np.ones((2, 2, 3), bool)
    visible = np.zeros_like(complete)
    visible[0, 0] = True
    visible[1, 1] = True
    return visible, complete, np.ones_like(complete)


def test_tree_and_stem_ratios_use_their_own_known_denominators():
    visible, complete, valid = interleaved()
    valid[:, 0, 0] = False  # Known-area ratio is 2/5 and 3/5, not 2/6 and 3/6.
    tree = visibility_targets(visible, complete, valid)
    np.testing.assert_allclose(tree["target"], [0.4, 0.6])
    stem_complete = complete.copy()
    stem_complete[:, :, 1:] = False
    stem = visibility_targets(visible & stem_complete, stem_complete, valid)
    np.testing.assert_allclose(stem["target"], [0, 1])
    assert tree["known_complete_area"].tolist() == [5, 5]
    assert stem["known_complete_area"].tolist() == [1, 1]


def test_empty_part_and_truncated_tree_cannot_supply_visibility_truth():
    visible, complete, valid = interleaved()
    result = visibility_targets(visible, complete, valid, complete_instance=[True, False])
    assert result["eligible"].tolist() == [True, False]
    assert result["target"].tolist() == [0.5, 0]
    assert result["observed_within_frame_ratio"].tolist() == [0.5, 0.5]
    empty = visibility_targets(visible & False, complete & False, valid)
    assert not empty["eligible"].any() and np.isfinite(empty["target"]).all()


def test_interleaved_branches_allow_both_occlusion_directions():
    visible, complete, valid = interleaved()
    result = local_occlusion_targets(visible, complete, valid)
    assert result["directional_pixels"].tolist() == [[0, 3], [3, 0]]
    assert result["bidirectional_pairs"].sum() == 2
    np.testing.assert_array_equal(result["tree_occluder"], result["hidden"])
    assert not result["unexplained_hidden"].any()


def test_unknown_and_unlabelled_occluders_are_not_invented_as_neighbour_trees():
    visible, complete, valid = interleaved()
    valid[0, :, 0] = False
    visible[1, 1, 1] = False  # A hidden pixel without a known rendered tree ID.
    result = local_occlusion_targets(visible, complete, valid)
    assert result["directional_pixels"].tolist() == [[0, 1], [2, 0]]
    assert result["unexplained_hidden"][0, 1, 1]
    assert not result["tree_occluder_valid"][0, 1, 1]
    assert not result["tree_occluder"][:, :, 0].any()


def test_query_permutation_preserves_local_evidence_and_targets():
    visible, complete, valid = interleaved()
    before = local_occlusion_targets(visible, complete, valid)
    after = local_occlusion_targets(visible[::-1], complete[::-1], valid[::-1])
    np.testing.assert_array_equal(
        after["directional_pixels"], before["directional_pixels"][::-1, ::-1]
    )
    np.testing.assert_array_equal(after["tree_occluder"], before["tree_occluder"][::-1])


def test_conflicting_owners_and_visible_outside_amodal_are_rejected():
    visible, complete, valid = interleaved()
    with pytest.raises(ValueError, match="conflict"):
        local_occlusion_targets(complete, complete, valid)
    with pytest.raises(ValueError, match="contained"):
        visibility_targets(visible, complete & False, valid)
    with pytest.raises(ValueError, match="every query"):
        visibility_targets(visible, complete, valid, complete_instance=[True])


def test_part_correspondence_conflict_does_not_become_fake_hidden_part_evidence():
    visible_parts = np.zeros((2, 1, 3, 3), bool)
    amodal_parts = visible_parts.copy()
    visible_parts[0, 0, 1, 1] = True
    amodal_parts[1, 0, 1, 1] = True
    known = np.ones((1, 3, 3), bool)
    valid, conflicts = paired_part_validity(visible_parts, amodal_parts, known)
    assert conflicts.sum() == 1 and not valid[0, 1, 1]
    # Whole-tree support is unchanged; only paired part evidence is undefined.
    np.testing.assert_array_equal(visible_parts.any(0), amodal_parts.any(0))
