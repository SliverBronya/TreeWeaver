import json
import tempfile
import unittest
from pathlib import Path

from treeweaver.evaluation.protocol import (
    SampleIdentity,
    build_frozen_splits,
    verify_frozen_protocol,
    write_frozen_protocol,
)


class EvaluationProtocolTests(unittest.TestCase):
    def test_keeps_tree_together_and_forces_external_site(self) -> None:
        samples = (
            SampleIdentity("a1", "a", "s1", "local", "p1", "o1"),
            SampleIdentity("a2", "a", "s2", "local", "p2", "o2"),
            SampleIdentity("b1", "b", "s3", "external", "p1", "o1"),
        )
        assignments = build_frozen_splits(
            samples, external_test_sites=frozenset({"external"}), seed="paper-v1"
        )
        split = {item.sample_id: item.split for item in assignments}
        self.assertEqual(split["a1"], split["a2"])
        self.assertEqual(split["b1"], "external_test")

    def test_detects_edits_to_frozen_protocol(self) -> None:
        samples = (SampleIdentity("a1", "a", "s1", "local", "p1", "o1"),)
        assignments = build_frozen_splits(
            samples, external_test_sites=frozenset(), seed="paper-v1"
        )
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "protocol.json"
            write_frozen_protocol(
                path,
                samples,
                assignments,
                seed="paper-v1",
                external_test_sites=frozenset(),
            )
            verify_frozen_protocol(path)
            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["seed"] = "changed-after-looking-at-test"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "checksum"):
                verify_frozen_protocol(path)


if __name__ == "__main__":
    unittest.main()
