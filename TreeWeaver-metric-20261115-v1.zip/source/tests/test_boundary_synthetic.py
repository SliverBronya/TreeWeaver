import numpy as np
import pytest

from treeweaver.simulation.censored_rgb import (
    extract_boundary_patches,
    predicted_rows,
    render_ambiguous_pair,
    render_boundary_scene,
)


def test_renderer_truth_and_feature_alignment_are_deterministic() -> None:
    first = render_boundary_scene(1003)
    repeated = render_boundary_scene(1003)
    assert np.array_equal(first.rgb, repeated.rgb)
    assert np.all(first.visible_mask <= first.hidden_truth_mask)
    patches, observations = extract_boundary_patches(first.rgb, first.visible_mask)
    assert patches.shape == (len(observations) * 2, 4, 33, 33)
    assert len(observations) == len(first.oracle_rows)
    assert np.all(patches[:, 3, 16, 16] == 1)
    for row, oracle in zip(observations, first.oracle_rows, strict=True):
        true_x = np.flatnonzero(first.hidden_truth_mask[row.y])
        assert oracle.left_is_exposed_edge == (row.left == true_x[0])
        assert oracle.right_is_exposed_edge == (row.right == true_x[-1])


def test_occluder_domain_changes_do_not_change_underlying_tree_geometry() -> None:
    first = render_boundary_scene(1003)
    shifted = render_boundary_scene(1003, "curved_occluders")
    assert np.array_equal(first.hidden_truth_mask, shifted.hidden_truth_mask)
    assert first.true_width_px == shifted.true_width_px
    assert not np.array_equal(first.visible_mask, shifted.visible_mask)


def test_unqualified_prediction_does_not_assert_any_true_boundary() -> None:
    scene = render_boundary_scene(1000)
    _, observed = extract_boundary_patches(scene.rgb, scene.visible_mask)
    rows = predicted_rows(observed, np.ones(2 * len(observed)), None)
    assert not any(row.left_is_exposed_edge or row.right_is_exposed_edge for row in rows)


def test_prediction_rejects_misaligned_or_nonfinite_probabilities() -> None:
    scene = render_boundary_scene(1000)
    _, observed = extract_boundary_patches(scene.rgb, scene.visible_mask)
    with pytest.raises(ValueError, match="finite exposed"):
        predicted_rows(observed, np.full(2 * len(observed), np.nan), 0.9)


def test_identical_rgb_and_mask_can_have_different_hidden_width_and_edge_labels() -> None:
    wide, narrow = render_ambiguous_pair(30004)
    assert np.array_equal(wide.rgb, narrow.rgb)
    assert np.array_equal(wide.visible_mask, narrow.visible_mask)
    assert wide.true_width_px > narrow.true_width_px
    assert not np.array_equal(wide.hidden_truth_mask, narrow.hidden_truth_mask)
    assert all(not row.right_is_exposed_edge for row in wide.oracle_rows)
    assert all(row.right_is_exposed_edge for row in narrow.oracle_rows)
    wide_x, _ = extract_boundary_patches(wide.rgb, wide.visible_mask)
    narrow_x, _ = extract_boundary_patches(narrow.rgb, narrow.visible_mask)
    assert np.array_equal(wide_x, narrow_x)
