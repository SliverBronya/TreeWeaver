import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from treeweaver.providers.external_worker import (
    ExternalWorkerConfig,
    load_external_worker_config,
    run_external_vision_worker,
)
from treeweaver.providers.observation_bundle import TreeMaskSet, write_observation_bundle


class ExternalWorkerTests(unittest.TestCase):
    def test_loads_versioned_worker_configuration(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "worker.json"
            path.write_text(
                '{"schema_version":"external-vision-worker-1.0",'
                '"command":["python","worker.py"],'
                '"provider_name":"sam-parts","model_version":"fixture"}',
                encoding="utf-8",
            )
            config = load_external_worker_config(path)
            self.assertEqual(config.command, ("python", "worker.py"))

    def test_runs_isolated_command_and_validates_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            capture = root / "capture.json"
            capture.write_text("{}", encoding="utf-8")
            output = root / "provider output"
            mask = np.ones((8, 8), dtype=bool)
            trunk = np.zeros_like(mask)
            trunk[4:] = True
            crown = mask & ~trunk

            def fake_run(command, **kwargs):
                output_argument = Path(command[command.index("--output-directory") + 1])
                write_observation_bundle(
                    output_argument,
                    (TreeMaskSet("f.jpg", 1, mask, trunk, crown, 0.9, 0.8),),
                    (),
                    provider="fixture",
                    model_version="1",
                )
                self.assertFalse(kwargs["shell"])
                return subprocess.CompletedProcess(command, 0, "ok", "")

            with patch(
                "treeweaver.providers.external_worker.subprocess.run", side_effect=fake_run
            ):
                result = run_external_vision_worker(
                    ExternalWorkerConfig(("worker",), "fixture", "1"), capture, output
                )
            self.assertEqual(result.instance_count, 1)
            self.assertTrue((output / "provider-run.json").is_file())


if __name__ == "__main__":
    unittest.main()
