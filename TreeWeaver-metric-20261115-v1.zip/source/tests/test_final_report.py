import json
import tempfile
import unittest
from pathlib import Path

from treeweaver.reporting.final_report import build_final_report


class FinalReportTests(unittest.TestCase):
    def test_merges_only_quality_gated_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for name in ("a.jpg", "b.jpg"):
                (root / name).write_bytes(b"fixture")
            camera = {"fx": 500, "fy": 500, "cx": 320, "cy": 240, "width": 640, "height": 480}
            capture = {
                "schema_version": "1.0",
                "session_id": "final-report",
                "device": {
                    "device_id": "phone",
                    "has_imu": False,
                    "has_arcore": False,
                    "has_metric_depth": False,
                    "depth_source": "none",
                },
                "frames": [
                    {
                        "frame_id": "a",
                        "timestamp_ns": 1,
                        "image_path": "a.jpg",
                        "intrinsics": camera,
                        "azimuth_deg": 0,
                    },
                    {
                        "frame_id": "b",
                        "timestamp_ns": 2,
                        "image_path": "b.jpg",
                        "intrinsics": camera,
                        "azimuth_deg": 90,
                    },
                ],
                "scale_anchors": [{"kind": "marker", "metric_length_m": 1, "confidence": 1}],
            }
            (root / "capture.json").write_text(json.dumps(capture), encoding="utf-8")
            (root / "quality.json").write_text(
                json.dumps({"schema_version": "reconstruction-quality-1.0", "passed": True}),
                encoding="utf-8",
            )
            factor = {
                "schema_version": "treefactor-tracks-1.0",
                "trees": [
                    {
                        "track_id": 5,
                        "status": "ok",
                        "semantic_confidence": 0.9,
                        "height": {"value_m": 20, "standard_deviation_m": 0.5, "confidence": 0.9},
                        "dbh": {"value_cm": 40, "standard_deviation_cm": 2, "confidence": 0.9},
                        "volume": {
                            "value_m3": 1.5,
                            "standard_deviation_m3": 0.1,
                            "confidence": 0.9,
                        },
                        "covariance": [
                            [0.01 if row == column else 0.0 for column in range(10)]
                            for row in range(10)
                        ],
                    }
                ],
            }
            (root / "factor.json").write_text(json.dumps(factor), encoding="utf-8")
            run = build_final_report(
                root / "capture.json",
                root / "quality.json",
                root / "factor.json",
                root / "report.json",
            )
            self.assertEqual(run.accepted_tree_count, 1)
            payload = json.loads(run.output_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["trees"][0]["status"], "accepted")
            self.assertIn("height_m", payload["trees"][0]["estimates"])
            self.assertEqual(
                payload["trees"][0]["next_capture"]["selection_method"],
                "treefactor_expected_information_gain",
            )
            (root / "crown.json").write_text(
                json.dumps(
                    {
                        "schema_version": "tree-measurements-1.0",
                        "trees": [
                            {
                                "track_id": 5,
                                "status": "ok",
                                "visibility": {
                                    "dbh_angular_coverage_deg": 90,
                                    "dbh_point_count": 20,
                                    "missing_dbh_sectors": [
                                        {"start_deg": 90, "end_deg": 360, "width_deg": 270}
                                    ],
                                    "root_visible": True,
                                    "apex_visible": True,
                                    "crown_height_coverage": 1.0,
                                    "dbh_measurement_allowed": False,
                                    "height_measurement_allowed": True,
                                    "reasons": ["胸高截面观察角度不足"],
                                },
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            gated = build_final_report(
                root / "capture.json",
                root / "quality.json",
                root / "factor.json",
                root / "report-gated.json",
                crown_results_json=root / "crown.json",
            )
            self.assertEqual(gated.accepted_tree_count, 0)
            gated_payload = json.loads(gated.output_path.read_text(encoding="utf-8"))
            decisions = {
                item["parameter"]: item for item in gated_payload["trees"][0]["parameter_decisions"]
            }
            self.assertFalse(decisions["dbh_cm"]["accepted"])
            self.assertTrue(decisions["height_m"]["accepted"])
            self.assertEqual(
                gated_payload["trees"][0]["next_capture"]["selection_method"],
                "largest_missing_dbh_sector",
            )

    def test_reconstruction_failure_forces_more_capture(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for name in ("a.jpg", "b.jpg"):
                (root / name).write_bytes(b"fixture")
            camera = {"fx": 500, "fy": 500, "cx": 320, "cy": 240, "width": 640, "height": 480}
            capture = {
                "schema_version": "1.0",
                "session_id": "failed-quality",
                "device": {
                    "device_id": "phone",
                    "has_imu": False,
                    "has_arcore": False,
                    "has_metric_depth": False,
                    "depth_source": "none",
                },
                "frames": [
                    {
                        "frame_id": "a",
                        "timestamp_ns": 1,
                        "image_path": "a.jpg",
                        "intrinsics": camera,
                    },
                    {
                        "frame_id": "b",
                        "timestamp_ns": 2,
                        "image_path": "b.jpg",
                        "intrinsics": camera,
                    },
                ],
                "scale_anchors": [{"kind": "marker", "metric_length_m": 1, "confidence": 1}],
            }
            (root / "capture.json").write_text(json.dumps(capture), encoding="utf-8")
            (root / "quality.json").write_text(
                json.dumps({"schema_version": "reconstruction-quality-1.0", "passed": False}),
                encoding="utf-8",
            )
            factor = {
                "schema_version": "treefactor-tracks-1.0",
                "trees": [
                    {
                        "track_id": 1,
                        "status": "ok",
                        "semantic_confidence": 1.0,
                        "height": {"value_m": 10, "standard_deviation_m": 0.1, "confidence": 1.0},
                        "dbh": {"value_cm": 30, "standard_deviation_cm": 0.1, "confidence": 1.0},
                        "volume": {"value_m3": 1, "standard_deviation_m3": 0.01, "confidence": 1.0},
                    }
                ],
            }
            (root / "factor.json").write_text(json.dumps(factor), encoding="utf-8")
            run = build_final_report(
                root / "capture.json",
                root / "quality.json",
                root / "factor.json",
                root / "report.json",
            )
            self.assertEqual(run.accepted_tree_count, 0)


if __name__ == "__main__":
    unittest.main()
