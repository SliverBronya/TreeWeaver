import unittest

from treeweaver.domain.models import Parameter, ScalarObservation
from treeweaver.fusion.robust import fuse_scalar_observations


class RobustFusionTests(unittest.TestCase):
    def test_outlier_does_not_dominate(self) -> None:
        observations = (
            ScalarObservation(10.0, 0.2, 0.95, "sfm", "a"),
            ScalarObservation(10.2, 0.2, 0.90, "sfm", "b"),
            ScalarObservation(24.0, 0.2, 0.15, "depth", "c"),
        )
        estimate = fuse_scalar_observations(Parameter.HEIGHT_M, observations)
        self.assertLess(abs(estimate.value - 10.1), 0.5)
        self.assertEqual(estimate.observation_count, 3)

    def test_low_reliability_is_removed(self) -> None:
        observations = (
            ScalarObservation(18.0, 0.3, 0.9, "sfm", "a"),
            ScalarObservation(40.0, 0.1, 0.01, "bad", "b"),
        )
        estimate = fuse_scalar_observations(Parameter.HEIGHT_M, observations)
        self.assertAlmostEqual(estimate.value, 18.0)
        self.assertIn("rejected 1", estimate.diagnostics[0])


if __name__ == "__main__":
    unittest.main()
