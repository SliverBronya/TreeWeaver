import unittest

import numpy as np

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.calibration.multiview_anchor import MarkerObservation, triangulate_marker_anchor
from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose
from treeweaver.reconstruction.scale_registration import estimate_scale_from_correspondences


def _camera(name: str, centre_x: float) -> ProjectionCamera:
    rotation = np.eye(3)
    translation = np.array([-centre_x, 0.0, 0.0])
    return ProjectionCamera(
        name,
        CameraPose(1, 1, name, rotation, translation),
        CameraIntrinsics(800, 800, 320, 240, 640, 480),
    )


def _project(camera: ProjectionCamera, points: np.ndarray) -> np.ndarray:
    camera_points = (
        camera.pose.rotation_world_to_camera @ points.T
    ).T + camera.pose.translation_world_to_camera
    return np.column_stack(
        (
            camera.intrinsics.fx * camera_points[:, 0] / camera_points[:, 2]
            + camera.intrinsics.cx,
            camera.intrinsics.fy * camera_points[:, 1] / camera_points[:, 2]
            + camera.intrinsics.cy,
        )
    )


class MultiviewAnchorTests(unittest.TestCase):
    def test_recovers_marker_edges_and_scale(self) -> None:
        cameras = (_camera("a.jpg", -1.0), _camera("b.jpg", 1.0), _camera("c.jpg", 0.3))
        corners = np.array(
            [[-0.5, -0.5, 5.0], [0.5, -0.5, 5.0], [0.5, 0.5, 5.0], [-0.5, 0.5, 5.0]]
        )
        observations = tuple(
            MarkerObservation(camera.image_name, _project(camera, corners)) for camera in cameras
        )
        marker = triangulate_marker_anchor(cameras, observations, edge_length_m=0.4)
        np.testing.assert_allclose(marker.corners_world, corners, atol=1e-8)
        scale = estimate_scale_from_correspondences(marker.correspondences)
        self.assertAlmostEqual(scale.metres_per_unit, 0.4, places=8)
        self.assertLess(marker.mean_reprojection_error_px, 1e-8)


if __name__ == "__main__":
    unittest.main()
