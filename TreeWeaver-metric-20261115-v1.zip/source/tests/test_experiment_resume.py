import copy
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from experiment_resume import RESUME_SCHEMA, validate_resume_checkpoint  # noqa: E402


def fixture():
    recipe = {
        "seed": 17,
        "order": [[0, 1, 2], [1, 3, 0]],
        "data_hash": "abc",
        "encoder_focus_null_token": False,
    }
    saved = {
        "resume_schema": RESUME_SCHEMA,
        "immutable_recipe": copy.deepcopy(recipe),
        "arm": "pf",
        "trainable_names": ["a", "b"],
        "updated_parameters": {"a": 1, "b": 2},
        "completed_steps": 1,
        "history": [{"step": 1, "data": 0, "record": 1, "query": 2, "loss": 0.7}],
        "optimizer": {},
        "cpu_rng": b"cpu",
        "cuda_rng": b"gpu",
        "initial_evaluation": {"iou": 0.5},
    }
    return recipe, saved


def check(saved, recipe, names=("a", "b")):
    return validate_resume_checkpoint(saved, recipe, arm="pf", trainable_names=names)


def test_matching_atomic_checkpoint_returns_the_verified_prefix():
    recipe, saved = fixture()
    completed, history = check(saved, recipe)
    assert completed == 1 and history == saved["history"]


@pytest.mark.parametrize(
    "field,value", [("seed", 18), ("data_hash", "changed"), ("encoder_focus_null_token", True)]
)
def test_same_parameter_shapes_do_not_allow_changed_recipe(field, value):
    recipe, saved = fixture()
    recipe[field] = value
    with pytest.raises(ValueError, match="recipe changed"):
        check(saved, recipe)


def test_optimizer_parameter_order_must_match_not_just_parameter_set():
    recipe, saved = fixture()
    with pytest.raises(ValueError, match="parameter order"):
        check(saved, recipe, names=("b", "a"))


@pytest.mark.parametrize(
    "damage", ["short_history", "wrong_sample", "nan_loss", "missing_rng", "wrong_arm"]
)
def test_corrupt_prefix_and_incomplete_rng_are_rejected(damage):
    recipe, saved = fixture()
    if damage == "short_history":
        saved["history"] = []
    if damage == "wrong_sample":
        saved["history"][0]["query"] = 1
    if damage == "nan_loss":
        saved["history"][0]["loss"] = float("nan")
    if damage == "missing_rng":
        del saved["cpu_rng"]
    if damage == "wrong_arm":
        saved["arm"] = "lora"
    with pytest.raises(ValueError):
        check(saved, recipe)


def test_legacy_checkpoints_cannot_silently_become_verified_resumes():
    recipe, saved = fixture()
    del saved["resume_schema"]
    with pytest.raises(ValueError, match="Legacy"):
        check(saved, recipe)
