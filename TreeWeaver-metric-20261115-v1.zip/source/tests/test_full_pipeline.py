from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from treeweaver.pipeline.full_run import (
    FullPipelineConfig,
    load_full_pipeline_config,
    run_full_pipeline,
)
from treeweaver.reconstruction.quality import ReconstructionQuality


def test_load_full_pipeline_config_resolves_relative_paths(tmp_path: Path) -> None:
    config_path = tmp_path / "run.json"
    config_path.write_text(
        json.dumps(
            {
                "schema_version": "treeweaver-full-run-1.0",
                "run_id": "run-7",
                "raw_capture_manifest": "raw/capture.json",
                "output_directory": "processed/run-7",
                "vision_worker_config": "worker.json",
                "colmap_use_gpu": False,
                "marker_id": 4,
                "marker_edge_length_m": 0.25,
                "root_clicks_json": "raw/root-clicks.json",
            }
        ),
        encoding="utf-8",
    )

    config = load_full_pipeline_config(config_path)

    assert config.run_id == "run-7"
    assert config.raw_capture_manifest == (tmp_path / "raw/capture.json").resolve()
    assert config.output_directory == (tmp_path / "processed/run-7").resolve()
    assert config.vision_worker_config == (tmp_path / "worker.json").resolve()
    assert not config.colmap_use_gpu
    assert config.marker_id == 4
    assert config.marker_edge_length_m == 0.25
    assert config.root_clicks_json == (tmp_path / "raw/root-clicks.json").resolve()


@pytest.mark.parametrize(
    ("field", "value", "message"),
    [
        ("run_id", "", "run_id cannot be empty"),
        ("sample_hz", 0, "sample_hz must be positive"),
        ("max_frames", 1, "max_frames must be at least 2"),
        ("marker_edge_length_m", -0.2, "marker_edge_length_m must be positive"),
    ],
)
def test_load_full_pipeline_config_rejects_invalid_values(
    tmp_path: Path, field: str, value: object, message: str
) -> None:
    payload: dict[str, object] = {
        "schema_version": "treeweaver-full-run-1.0",
        "run_id": "run-8",
        "raw_capture_manifest": "capture.json",
        "output_directory": "output",
        "vision_worker_config": "worker.json",
    }
    payload[field] = value
    path = tmp_path / "run.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match=message):
        load_full_pipeline_config(path)


def test_full_pipeline_refuses_to_overwrite_existing_run(tmp_path: Path) -> None:
    output = tmp_path / "existing"
    output.mkdir()
    config = FullPipelineConfig(
        run_id="immutable-run",
        raw_capture_manifest=tmp_path / "capture.json",
        output_directory=output,
        vision_worker_config=tmp_path / "worker.json",
    )

    with pytest.raises(FileExistsError):
        run_full_pipeline(config)


def test_full_pipeline_halts_before_vision_when_reconstruction_fails(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import treeweaver.pipeline.full_run as module

    raw_manifest = tmp_path / "raw.json"
    raw_manifest.write_text("{}", encoding="utf-8")
    ingested_manifest = tmp_path / "ingested-capture.json"
    ingested_manifest.write_text("{}", encoding="utf-8")

    class FakeRunner:
        def __init__(self, config: Any) -> None:
            self.config = config

        def reconstruct(self, manifest: Path, output: Path) -> object:
            del manifest
            text_model = output / "text-model"
            text_model.mkdir(parents=True)
            (text_model / "images.txt").write_text("images", encoding="utf-8")
            (text_model / "points3D.txt").write_text("points", encoding="utf-8")
            (output / "fused.ply").write_text("cloud", encoding="utf-8")
            return object()

    monkeypatch.setattr(
        module,
        "load_raw_capture",
        lambda path: SimpleNamespace(
            session_id="session",
            anchor_marker_id=7,
            anchor_length_m=0.2,
            anchor_dictionary="4x4_50",
        ),
    )
    monkeypatch.setattr(
        module,
        "ingest_raw_capture",
        lambda *args, **kwargs: SimpleNamespace(manifest_path=ingested_manifest),
    )
    monkeypatch.setattr(
        module,
        "load_capture_session",
        lambda path: SimpleNamespace(session=SimpleNamespace(frames=(object(), object()))),
    )
    monkeypatch.setattr(module, "ColmapRunner", FakeRunner)
    monkeypatch.setattr(
        module,
        "assess_reconstruction_quality",
        lambda reconstruction, expected: ReconstructionQuality(
            False,
            1,
            expected,
            0.5,
            20,
            2.5,
            4.0,
            2.0,
            0.01,
            (1.0, 1.0, 1.0),
            ("too few input images were registered",),
        ),
    )

    def vision_must_not_run(*args: object, **kwargs: object) -> None:
        raise AssertionError("vision ran after a failed reconstruction quality gate")

    monkeypatch.setattr(module, "run_external_vision_worker", vision_must_not_run)
    result = run_full_pipeline(
        FullPipelineConfig(
            run_id="quality-halt",
            raw_capture_manifest=raw_manifest,
            output_directory=tmp_path / "output",
            vision_worker_config=tmp_path / "worker.json",
        )
    )

    assert result.status == "halted_reconstruction_quality"
    assert result.final_report is None
    status = json.loads((result.output_directory / "run-status.json").read_text())
    assert status["status"] == "halted_reconstruction_quality"
    journal = json.loads(result.journal.read_text(encoding="utf-8"))
    assert [item["stage"] for item in journal["stages"]] == [
        "capture",
        "ingest",
        "reconstruction",
    ]
