import copy

import numpy as np
import pytest

from treeweaver.datasets.partial_labels import (
    content_fingerprint,
    require_reviewed_labels,
    sparse_instance_map,
    sparse_stem_map,
    validate_group_split,
    validate_partial_labels,
)


def fixture():
    return {
        "schema_version": "partial-tree-rgb.v1",
        "source_group": 7,
        "role": "train",
        "coverage": "partial_positive_only",
        "image": {"width": 20, "height": 20},
        "instances": [
            {
                "local_id": 1,
                "visible_stem_points": [[5, 5]],
                "visible_stem_positive_regions": [[[3, 3], [8, 3], [8, 8], [3, 8]]],
                "certain_branch_regions": [],
                "certain_crown_regions": [],
            }
        ],
        "unknown_regions": [],
        "known_background_regions": [[[12, 12], [17, 12], [17, 17], [12, 17]]],
        "review": {"state": "draft", "reviewer": None, "content_sha256": None},
    }


def test_draft_cannot_enter_reviewed_training():
    with pytest.raises(ValueError, match="Unreviewed"):
        sparse_instance_map(fixture())


def test_unlabeled_pixels_are_unknown_not_background():
    labels = sparse_instance_map(fixture(), preview_only=True)
    assert labels[0, 0] == -1
    assert labels[5, 5] == 1
    assert labels[14, 14] == 0


def test_unknown_region_overrides_positive():
    document = fixture()
    document["unknown_regions"] = [[[4, 4], [7, 4], [7, 7], [4, 7]]]
    assert sparse_instance_map(document, preview_only=True)[5, 5] == -1


def test_review_is_invalidated_by_coordinate_changes():
    document = fixture()
    document["review"] = {
        "state": "approved",
        "reviewer": "test_fixture_reviewer",
        "content_sha256": content_fingerprint(document),
    }
    require_reviewed_labels(document)
    document["instances"][0]["visible_stem_points"][0][0] = 6
    with pytest.raises(ValueError, match="changed after review"):
        require_reviewed_labels(document)


def test_same_group_cannot_leak_into_test():
    train, test = fixture(), copy.deepcopy(fixture())
    test["role"] = "protected_test"
    with pytest.raises(ValueError, match="leaks"):
        validate_group_split([train, test])


def test_nonfinite_points_rejected():
    document = fixture()
    document["instances"][0]["visible_stem_points"][0][0] = np.nan
    with pytest.raises(ValueError, match="Finite"):
        validate_partial_labels(document)


def test_experiment_does_not_approve_draft():
    document = fixture()
    document["provenance"] = "assistant_visual_draft"
    labels = sparse_stem_map(document, assistant_experiment=True)
    assert labels[5, 5] == 1
    assert labels[0, 0] == -1
    assert document["review"]["state"] == "draft"
    with pytest.raises(ValueError, match="Unreviewed"):
        require_reviewed_labels(document)


def test_protected_test_cannot_be_draft_training():
    document = fixture()
    document["provenance"] = "assistant_visual_draft"
    document["role"] = "protected_test"
    with pytest.raises(ValueError, match="Protected"):
        sparse_stem_map(document, assistant_experiment=True)
