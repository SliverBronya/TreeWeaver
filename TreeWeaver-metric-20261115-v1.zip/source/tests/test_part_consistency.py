import numpy as np
import pytest

from treeweaver.visibility.part_consistency import assess_tree_part_consistency


def test_narrow_trunk_inside_tree_is_accepted() -> None:
    whole = np.ones((20, 20), dtype=bool)
    trunk = np.zeros_like(whole)
    trunk[:, 9:11] = True
    result = assess_tree_part_consistency(whole, trunk)
    assert result.accepted
    assert result.trunk_area_fraction == 0.1


def test_whole_crown_labeled_trunk_is_rejected() -> None:
    whole = np.ones((20, 20), dtype=bool)
    result = assess_tree_part_consistency(whole, whole)
    assert not result.accepted
    assert "crown leakage" in result.reasons[0]


def test_missing_or_foreign_trunk_is_rejected() -> None:
    whole = np.zeros((20, 20), dtype=bool)
    whole[:, 5:15] = True
    assert not assess_tree_part_consistency(whole, np.zeros_like(whole)).accepted
    foreign = np.zeros_like(whole)
    foreign[:, :2] = True
    assert not assess_tree_part_consistency(whole, foreign).accepted


def test_invalid_masks_are_rejected() -> None:
    with pytest.raises(ValueError, match="whole-tree"):
        assess_tree_part_consistency(np.zeros((2, 2)), np.zeros((2, 2)))
    with pytest.raises(ValueError, match="same-shaped"):
        assess_tree_part_consistency(np.ones((2, 2)), np.ones((3, 2)))
