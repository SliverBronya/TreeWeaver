import unittest

from treeweaver.domain.models import Parameter, ParameterEstimate
from treeweaver.quality.decision import decide_measurement


class QualityDecisionTests(unittest.TestCase):
    def test_accepts_precise_measurements_after_all_gates(self) -> None:
        estimates = {
            Parameter.HEIGHT_M: ParameterEstimate(Parameter.HEIGHT_M, 20.0, 0.5, 0.9, 100),
            Parameter.DBH_CM: ParameterEstimate(Parameter.DBH_CM, 40.0, 2.0, 0.85, 80),
        }
        result = decide_measurement(
            estimates, reconstruction_passed=True, semantic_confidence=0.9
        )
        self.assertTrue(result.accepted)

    def test_rejects_precise_looking_output_after_reconstruction_failure(self) -> None:
        estimate = ParameterEstimate(Parameter.HEIGHT_M, 20.0, 0.1, 0.99, 100)
        result = decide_measurement(
            {Parameter.HEIGHT_M: estimate},
            reconstruction_passed=False,
            semantic_confidence=0.9,
        )
        self.assertFalse(result.accepted)
        self.assertIn("reconstruction quality gate failed", result.parameters[0].reasons)

    def test_parameter_prerequisite_blocks_only_affected_measurement(self) -> None:
        estimates = {
            Parameter.HEIGHT_M: ParameterEstimate(Parameter.HEIGHT_M, 20, 0.2, 0.9, 10),
            Parameter.DBH_CM: ParameterEstimate(Parameter.DBH_CM, 40, 0.5, 0.9, 10),
        }
        result = decide_measurement(
            estimates,
            reconstruction_passed=True,
            semantic_confidence=0.9,
            parameter_blockers={Parameter.DBH_CM: ("胸高截面可见性不足",)},
        )
        by_parameter = {item.parameter: item for item in result.parameters}
        self.assertTrue(by_parameter[Parameter.HEIGHT_M].accepted)
        self.assertFalse(by_parameter[Parameter.DBH_CM].accepted)


if __name__ == "__main__":
    unittest.main()
