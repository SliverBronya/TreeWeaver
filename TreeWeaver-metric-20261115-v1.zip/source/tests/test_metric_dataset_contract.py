import copy
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from metric_dataset_contract import (  # noqa: E402
    METRIC_UNITS,
    SCHEMA,
    depth_products,
    derive_scene_labels,
    qualify_focal_target,
    validate_scene_metadata,
    validate_visible_parts,
)


def occluded_scene():
    full = np.zeros((1, 100, 100), bool)
    full[0, 10:90, 40:60] = True
    visible = full.copy()
    visible[0, 30:50, 40:60] = False
    shrub = full & ~visible
    return visible, full, np.ones_like(full), shrub


def metadata():
    metrics = {
        name: {
            "value": 2.0,
            "unit": unit,
            "status": "measured_virtual_geometry",
            "provenance": "qualified_world_mesh",
        }
        for name, unit in METRIC_UNITS.items()
    }
    metrics["wood_volume_m3"] = {
        "value": None,
        "unit": "m3",
        "status": "unavailable",
        "provenance": "asset_qualification",
        "reason": "open bark shell",
    }
    return {
        "schema_version": SCHEMA,
        "world": {
            "unit": "m",
            "blender_unit_in_meters": 1.0,
            "truth_domain": "synthetic_metric_geometry",
        },
        "camera": {
            "model": "pinhole",
            "axes": "opencv_x_right_y_down_z_forward",
            "image_wh": [100, 100],
            "K": [[80, 0, 50], [0, 80, 50], [0, 0, 1]],
            "T_world_from_camera": np.eye(4).tolist(),
        },
        "depth": {"unit": "m", "convention": "camera_z_m", "image_wh": [100, 100]},
        "label_provenance": {
            "visible": "full_scene_instance_id_render",
            "amodal": "same_camera_remove_declared_external_occluders",
            "visible_parts": "full_scene_frontmost_part_id_render",
        },
        "generator_sha256": "a" * 64,
        "asset_manifest_sha256": "b" * 64,
        "instances": [
            {
                "instance_id": 17,
                "asset_id": "fig_1",
                "source_group_id": "family_a",
                "geometry_metrics": metrics,
            }
        ],
    }


def test_true_hidden_fraction_and_large_target_not_bbox_overlap_control_admission():
    visible, full, known, shrub = occluded_scene()
    labels = derive_scene_labels(visible, full, known, instance_ids=[17], other_visible=shrub)
    assert labels["instances"][0]["hidden_fraction"] == 0.25
    assert labels["instances"][0]["amodal_height_fraction"] == 0.8
    assert not labels["unexplained_known_hidden_pixels"].any()
    result = qualify_focal_target(labels, 17, cohort="occluded_primary")
    assert result["qualification_passed"] and result["completion_supervision_allowed"]
    assert not result["training_allowed"]
    np.testing.assert_array_equal(labels["tree_and_object_occluder"], shrub)


def test_clear_control_is_retained_but_never_claimed_as_five_percent_occlusion():
    _, full, known, _ = occluded_scene()
    labels = derive_scene_labels(full, full, known)
    assert qualify_focal_target(labels, 1, cohort="clear_control")["qualification_passed"]
    result = qualify_focal_target(labels, 1, cohort="occluded_primary")
    assert not result["qualification_passed"]
    assert "measured_focal_hidden_fraction_outside_requested_range" in result["issues"]


def test_tree_occlusion_scope_does_not_pass_a_tree_hidden_only_by_a_pole_or_shrub():
    visible, full, known, shrub = occluded_scene()
    labels = derive_scene_labels(visible, full, known, other_visible=shrub)
    assert labels["instances"][0]["tree_occluded_fraction"] == 0
    assert labels["instances"][0]["other_occluded_fraction"] == 0.25
    assert not qualify_focal_target(labels, 1, cohort="occluded_primary", occlusion_scope="tree")[
        "qualification_passed"
    ]


def test_tree_and_non_tree_occlusion_are_separate_and_sum_on_same_domain():
    visible, full, known, occluder = occluded_scene()
    neighbour = occluder.copy()
    neighbour[:, 40:] = False
    other = occluder & ~neighbour
    labels = derive_scene_labels(
        np.concatenate((visible, neighbour)),
        np.concatenate((full, neighbour)),
        np.concatenate((known, known)),
        other_visible=other,
    )
    target = labels["instances"][0]
    assert target["tree_occluded_fraction"] == target["other_occluded_fraction"] == 0.125
    assert target["hidden_fraction"] == 0.25
    assert qualify_focal_target(labels, 1, cohort="occluded_primary", occlusion_scope="tree")[
        "qualification_passed"
    ]


def test_missing_occluder_id_and_frame_cut_are_explicit_reasons():
    visible, full, known, _ = occluded_scene()
    labels = derive_scene_labels(visible, full, known)
    result = qualify_focal_target(labels, 1, cohort="occluded_primary", frame_truncated=True)
    assert not result["completion_supervision_allowed"]
    assert "known_hidden_pixels_have_no_verified_occluding_object" in result["issues"]
    assert not labels["occluder_valid"][labels["hidden"]].any()


def test_local_branch_interleaving_can_have_both_directions():
    full = np.zeros((2, 12, 8), bool)
    full[:, 1:11, 2:6] = True
    visible = full.copy()
    visible[0, 6:] = False
    visible[1, :6] = False
    labels = derive_scene_labels(visible, full, np.ones_like(full))
    assert labels["directional_occlusion_pixels"].tolist() == [[0, 20], [20, 0]]
    assert labels["bidirectional_pairs"].sum() == 2


def test_unknown_pixels_do_not_change_visibility_and_id_disagreement_is_rejected():
    visible, full, known, shrub = occluded_scene()
    known[:, 0] = False
    original = derive_scene_labels(visible, full, known, other_visible=shrub)
    changed_full, changed_visible = full.copy(), visible.copy()
    changed_full[:, 0] = changed_visible[:, 0] = True
    changed = derive_scene_labels(changed_visible, changed_full, known, other_visible=shrub)
    assert changed["instances"][0]["hidden_fraction"] == original["instances"][0]["hidden_fraction"]
    wrong = original["owner"].copy()
    wrong[10, 40] = 99
    with pytest.raises(ValueError, match="disagrees"):
        derive_scene_labels(visible, full, known, owner=wrong, other_visible=shrub)


def test_parts_must_represent_visible_surface_not_stem_hidden_by_own_leaves():
    visible, _, known, _ = occluded_scene()
    stem = np.zeros_like(visible)
    stem[:, 60:90, 48:52] = True
    crown = visible & ~stem
    validate_visible_parts(visible, stem, crown, np.zeros_like(stem), known)
    stem[:, 30:50, 48:52] = True  # Wood projected through an opaque occluder.
    with pytest.raises(ValueError, match="partition"):
        validate_visible_parts(visible, stem, crown, np.zeros_like(stem), known)


def test_metric_depth_distinguishes_optical_axis_and_ray_distance_and_ignores_sky():
    z = np.full((3, 3), 5, np.float32)
    known = np.ones_like(z, bool)
    z[0, 0] = np.inf
    known[0, 0] = False
    k = [[2, 0, 1.5], [0, 2, 1.5], [0, 0, 1]]
    values = depth_products(z, known, k, convention="camera_z_m")
    assert values["ray_distance_m"][1, 1] == 5
    assert values["ray_distance_m"][2, 2] > 5
    assert np.isnan(values["camera_z_m"][0, 0])
    back = depth_products(values["ray_distance_m"], known, k, convention="ray_distance_m")
    np.testing.assert_allclose(back["camera_z_m"][known], 5, atol=1e-6)
    with pytest.raises(ValueError, match="floating"):
        depth_products(np.zeros((3, 3), np.uint8), known, k, convention="camera_z_m")


def test_null_volume_is_honest_but_does_not_satisfy_all_physical_parameter_labels():
    result = validate_scene_metadata(metadata())
    assert result["instance_count"] == 1
    assert not result["metric_labels_complete"]
    assert result["unqualified_geometry_metrics"] == [
        {"instance_id": 17, "metric": "wood_volume_m3", "status": "unavailable"}
    ]
    assert not result["real_tree_field_measurements"] and not result["training_allowed"]


@pytest.mark.parametrize(
    "damage",
    [
        "fake_zero_volume",
        "real_truth_claim",
        "gray_depth",
        "stretched_depth",
        "rank_labels",
        "nonrigid_pose",
    ],
)
def test_metadata_cannot_hide_wrong_units_missing_truth_or_approximate_visibility(damage):
    data = copy.deepcopy(metadata())
    if damage == "fake_zero_volume":
        data["instances"][0]["geometry_metrics"]["wood_volume_m3"]["value"] = 0
    if damage == "real_truth_claim":
        data["world"]["truth_domain"] = "real_measured_tree"
    if damage == "gray_depth":
        data["depth"]["unit"] = "uint8_grayscale"
    if damage == "stretched_depth":
        data["depth"]["image_wh"] = [50, 100]
    if damage == "rank_labels":
        data["label_provenance"]["visible"] = "global_rank_subtraction"
    if damage == "nonrigid_pose":
        data["camera"]["T_world_from_camera"][0][0] = 2
    with pytest.raises(ValueError):
        validate_scene_metadata(data)
