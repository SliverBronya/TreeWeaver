"""Small CPU CLI fixtures; no model packages or checkpoints are needed."""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/export_visible_tree_parts.py"


def fixture(path):
    visible = np.zeros((2, 3, 5), bool)
    visible[0, :, :2] = True
    visible[1, :, 2:4] = True
    stem = np.where(visible, 10.0, -10.0)
    crown = -stem
    crown[0, 1, 1], stem[0, 1, 1] = 10, -10
    # One deliberately conflicting pixel should stay unresolved.
    crown[0, 2, 1] = 10
    np.savez_compressed(
        path,
        visible_masks=visible,
        stem_logits=stem,
        crown_logits=crown,
        valid=np.ones((3, 5), bool),
        query_valid=np.array([True, True]),
        heads_validated=np.array(True),
    )  # NPZ metadata must never enable the gate.
    return visible, stem, crown


def run(source, output, *extra, env=None):
    return subprocess.run(
        [sys.executable, str(SCRIPT), "--input", str(source), "--output", str(output), *extra],
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )


def test_default_does_not_trust_input_readiness_and_preserves_coordinates_and_hash(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    visible, stem, _ = fixture(source)
    original = source.read_bytes()
    result = run(source, output)
    assert result.returncode == 0, result.stderr
    report = json.loads((output / "status.json").read_text(encoding="utf-8"))
    assert report["head_status"] == "part_heads_not_validated"
    assert not report["heads_validated_asserted_by_caller"]
    assert report["shape_KHW"] == [2, 3, 5] and not report["pixel_resampling_performed"]
    assert report["input_sha256"] == hashlib.sha256(original).hexdigest()
    assert report["ignored_input_keys"] == ["heads_validated"]
    with np.load(output / "parts.npz", allow_pickle=False) as data:
        np.testing.assert_array_equal(data["unknown"], visible)
        np.testing.assert_array_equal(data["raw_stem_logits"], stem)
        assert not data["stem"].any() and not data["crown"].any()
        assert data["part_labels"].dtype == np.uint8
    with Image.open(output / "query_0001/unknown.png") as image:
        assert image.size == (5, 3)
        np.testing.assert_array_equal(np.asarray(image) > 0, visible[0])
    assert source.read_bytes() == original


def test_explicit_head_assertion_exports_disjoint_masks_and_conflicts_as_unknown(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    visible, _, _ = fixture(source)
    result = run(source, output, "--heads-validated")
    assert result.returncode == 0, result.stderr
    with np.load(output / "parts.npz", allow_pickle=False) as data:
        assert data["stem"].any() and data["crown"].any()
        assert data["unknown"][0, 2, 1]
        np.testing.assert_array_equal(data["stem"] | data["crown"] | data["unknown"], visible)
        assert not (data["stem"] & data["crown"]).any()
        for q in range(2):
            for name in ("stem", "crown", "unknown"):
                with Image.open(output / f"query_{q + 1:04d}/{name}.png") as image:
                    np.testing.assert_array_equal(np.asarray(image) > 0, data[name][q])
    report = json.loads((output / "status.json").read_text(encoding="utf-8"))
    assert report["heads_validated_asserted_by_caller"]
    assert not report["measurement_readiness_verified"]


def test_owner_ids_and_query_padding_are_passed_to_decoder(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    visible = np.ones((2, 2, 3), bool)
    owner = np.array([[1, 2, 0], [1, 2, -1]])
    np.savez(
        source,
        visible_masks=visible,
        stem_logits=np.full(visible.shape, 10.0),
        crown_logits=np.full(visible.shape, -10.0),
        owner_ids=owner,
        query_valid=np.array([True, False]),
        valid=np.ones((2, 2, 3), bool),
    )
    result = run(source, output, "--heads-validated")
    assert result.returncode == 0, result.stderr
    with np.load(output / "parts.npz", allow_pickle=False) as data:
        np.testing.assert_array_equal(data["stem"][0], owner == 1)
        assert not data["visible_support"][1].any()
        np.testing.assert_array_equal(data["owner_ids"], owner)


def test_missing_head_keeps_unknown_even_with_assertion(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    visible = np.ones((1, 2, 3), bool)
    np.savez(source, visible_masks=visible, stem_logits=np.full(visible.shape, 10.0))
    result = run(source, output, "--heads-validated")
    assert result.returncode == 0, result.stderr
    with np.load(output / "parts.npz", allow_pickle=False) as data:
        assert not data["stem"].any() and "raw_crown_logits" not in data.files
        np.testing.assert_array_equal(data["unknown"], visible)


def test_existing_output_is_refused_without_modification(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    fixture(source)
    output.mkdir()
    marker = output / "existing.txt"
    marker.write_text("keep", encoding="utf-8")
    result = run(source, output, "--heads-validated")
    assert result.returncode == 2 and "refusing to overwrite" in result.stderr
    assert marker.read_text(encoding="utf-8") == "keep"
    assert list(output.iterdir()) == [marker]


def test_invalid_contract_creates_no_output_directory(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    np.savez(source, visible_masks=np.ones((2, 3), bool))
    result = run(source, output)
    assert result.returncode == 2 and "K,H,W" in result.stderr
    assert not output.exists()


def test_npz_object_values_are_not_unpickled(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    np.savez(source, visible_masks=np.array([{"untrusted": True}], dtype=object))
    result = run(source, output)
    assert result.returncode == 2 and "allow_pickle=False" in result.stderr
    assert not output.exists()


def test_cli_runs_when_torch_import_is_forbidden(tmp_path):
    source, output = tmp_path / "saved.npz", tmp_path / "parts"
    fixture(source)
    forbidden = tmp_path / "forbidden_modules"
    forbidden.mkdir()
    (forbidden / "torch.py").write_text("raise RuntimeError('torch import forbidden')\n")
    env = dict(os.environ, PYTHONPATH=str(forbidden))
    result = run(source, output, env=env)
    assert result.returncode == 0, result.stderr
    assert (output / "status.json").exists()
