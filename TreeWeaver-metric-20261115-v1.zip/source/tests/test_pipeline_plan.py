import tempfile
import unittest
from pathlib import Path

from treeweaver.pipeline.plan import Stage, StageState, audit_pipeline


class PipelinePlanTests(unittest.TestCase):
    def test_exposes_only_dependency_ready_stages(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            capture = Path(temporary) / "capture.json"
            capture.write_text("{}", encoding="utf-8")
            states = tuple(
                StageState(
                    stage,
                    stage is Stage.CAPTURE,
                    (capture,) if stage is Stage.CAPTURE else (),
                )
                for stage in Stage
            )
            plan = audit_pipeline(states)
            self.assertEqual(plan.ready_stages, (Stage.INGEST,))

    def test_rejects_completion_before_dependency(self) -> None:
        states = tuple(
            StageState(stage, stage is Stage.RECONSTRUCTION)
            for stage in Stage
        )
        with self.assertRaisesRegex(ValueError, "dependencies"):
            audit_pipeline(states)


if __name__ == "__main__":
    unittest.main()
