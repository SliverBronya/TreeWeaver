import importlib.util
from pathlib import Path

import numpy as np
import pytest

SPEC = importlib.util.spec_from_file_location(
    "instance_metrics_prompt",
    Path(__file__).resolve().parents[1] / "workers/tree_models/instance_metrics.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_postprocessing_that_removes_stem_point_is_blocked():
    masks = np.zeros((1, 20, 20), bool)
    instances = [{"id": "a", "positive_points": [[5, 5]], "negative_points": [[15, 15]]}]
    blocked = MODULE.prompt_constraint_report(masks, instances)["instances"][0]
    assert blocked["measurement_gate"] == "blocked_prompt_violation"
    masks[0, 5, 5] = True
    passed = MODULE.prompt_constraint_report(masks, instances)["instances"][0]
    assert passed["status"] == "satisfied"
    assert passed["measurement_gate"] != "approved"
    masks[0, 15, 15] = True
    assert MODULE.prompt_constraint_report(masks, instances)["violating_instances"] == 1


def test_unspecified_and_wrong_coordinate_frames_are_not_silently_approved():
    masks = np.zeros((1, 10, 10), bool)
    assert (
        MODULE.prompt_constraint_report(masks, [{"id": "a"}])["instances"][0]["status"]
        == "not_specified"
    )
    with pytest.raises(ValueError, match="outside"):
        MODULE.prompt_constraint_report(masks, [{"id": "a", "positive_points": [[20, 20]]}])
