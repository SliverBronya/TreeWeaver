import unittest

from treeweaver.reliability.baseline import ReliabilityFeatures, score_reliability


class ReliabilityTests(unittest.TestCase):
    def test_accepts_consistent_visible_evidence(self) -> None:
        result = score_reliability(ReliabilityFeatures(0.8, 0.9, 0.85, 0.8, 0.9, 0.7, 0.8))
        self.assertTrue(result.usable)
        self.assertGreater(result.score, 0.7)

    def test_vetoes_geometrically_inconsistent_evidence(self) -> None:
        result = score_reliability(ReliabilityFeatures(0.9, 0.9, 0.9, 0.9, 0.1, 0.9, 0.9))
        self.assertFalse(result.usable)
        self.assertIn("evidence conflicts with reconstructed geometry", result.reasons)


if __name__ == "__main__":
    unittest.main()
