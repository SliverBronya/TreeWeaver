"""CPU fixtures for a saved-scene gate, independent of Blender/model execution."""

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "qualify_metric_scene", ROOT / "scripts/qualify_metric_scene.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def inputs(folder, *, complete_metrics=False):
    """Hand-built logic fixture, deliberately not a physically rendered scene."""
    amodal = np.zeros((2, 100, 100), bool)
    amodal[0, 10:90, 40:60] = True
    amodal[1, 30:50, 40:60] = True
    visible = amodal.copy()
    visible[0] &= ~visible[1]
    owner = np.zeros((100, 100), np.int32)
    owner[visible[0]], owner[visible[1]] = 17, 29
    stem = np.zeros_like(visible)
    stem[0, 60:90, 48:52] = True
    arrays = {
        "visible": visible,
        "amodal": amodal,
        "known": np.ones_like(owner, bool),
        "owner": owner,
        "stem": stem,
        "crown": visible & ~stem,
        "part_unknown": np.zeros_like(visible),
        "depth": np.full(owner.shape, 5, np.float32),
        "depth_valid": np.ones_like(owner, bool),
        "instance_ids": np.array([17, 29]),
    }
    instances = []
    for identity in (17, 29):
        metrics = {
            name: {
                "value": 2.0,
                "unit": unit,
                "status": "measured_virtual_geometry",
                "provenance": "hand_built_logic_fixture_not_physical_scene",
            }
            for name, unit in {
                "tree_height_m": "m",
                "crown_width_x_m": "m",
                "crown_width_y_m": "m",
                "dbh_m": "m",
                "wood_volume_m3": "m3",
            }.items()
        }
        if not complete_metrics:
            metrics["wood_volume_m3"] = {
                "value": None,
                "unit": "m3",
                "status": "unavailable",
                "provenance": "asset_qualification",
                "reason": "unqualified wood shell",
            }
        instances.append(
            {
                "instance_id": identity,
                "asset_id": "fixture_" + str(identity),
                "source_group_id": "logic_fixture",
                "frame_truncated": False,
                "geometry_metrics": metrics,
            }
        )
    document = {
        "schema_version": "treeweaver-metric-scene-1.0",
        "world": {
            "unit": "m",
            "blender_unit_in_meters": 1.0,
            "truth_domain": "synthetic_metric_geometry",
        },
        "camera": {
            "model": "pinhole",
            "axes": "opencv_x_right_y_down_z_forward",
            "image_wh": [100, 100],
            "K": [[80, 0, 50], [0, 80, 50], [0, 0, 1]],
            "T_world_from_camera": np.eye(4).tolist(),
        },
        "depth": {"unit": "m", "convention": "camera_z_m", "image_wh": [100, 100]},
        "label_provenance": {
            "visible": "full_scene_instance_id_render",
            "amodal": "same_camera_remove_declared_external_occluders",
            "visible_parts": "full_scene_frontmost_part_id_render",
        },
        "generator_sha256": "a" * 64,
        "asset_manifest_sha256": "b" * 64,
        "instances": instances,
        "focal_instance_id": 17,
    }
    return save_inputs(folder, document, arrays), document, arrays


def save_inputs(folder, document, arrays):
    folder.mkdir(exist_ok=True)
    scene, labels = folder / "scene.json", folder / "labels.npz"
    scene.write_text(json.dumps(document), encoding="utf-8")
    np.savez_compressed(labels, **arrays)
    return scene, labels


def test_segmentation_gate_writes_derived_labels_and_preserves_physical_uncertainty(tmp_path):
    (scene, labels), _, _ = inputs(tmp_path)
    out = tmp_path / "qualification"
    report = MODULE.qualify_scene(scene, labels, out, require_complete_metrics=False)
    assert report["qualification_passed"]
    assert report["focal"]["occlusion_scope"] == "tree"
    assert report["instances"][0]["tree_occluded_fraction"] == 0.25
    assert not report["metadata_validation"]["metric_labels_complete"]
    assert not report["training_allowed"]
    assert not report["geometric_truth_independently_verified"]
    assert not report["renderer_source_declarations_independently_verified"]
    assert not report["rgb_file_dimensions_verified"]
    assert report["input_sha256"]["labels"] == MODULE.sha256_file(labels)
    with np.load(out / "qualification.npz", allow_pickle=False) as archive:
        assert archive["hidden"][0].sum() == 400
        assert archive["camera_z_m"].dtype == np.float32
        assert archive["ray_distance_m"][0, 0] > archive["camera_z_m"][0, 0]
        assert archive["instance_ids"].tolist() == [17, 29]
    assert json.loads((out / "report.json").read_text(encoding="utf-8")) == report


def test_default_full_metric_gate_fails_null_volume_but_writes_a_completed_report(tmp_path):
    (scene, labels), _, _ = inputs(tmp_path)
    report = MODULE.qualify_scene(scene, labels, tmp_path / "out")
    assert not report["qualification_passed"]
    assert report["issues"] == ["requested_full_metric_labels_incomplete"]
    assert report["focal"]["qualification_passed"]
    assert report["status"] == "complete"


def test_complete_metric_declarations_still_do_not_verify_geometry(tmp_path):
    (scene, labels), _, _ = inputs(tmp_path, complete_metrics=True)
    report = MODULE.qualify_scene(scene, labels, tmp_path / "out")
    assert report["qualification_passed"]
    assert report["metadata_validation"]["metric_labels_complete"]
    assert not report["geometric_truth_independently_verified"]
    assert not report["training_allowed"]


@pytest.mark.parametrize(
    "damage",
    [
        "depth_size",
        "mask_size",
        "gray_depth",
        "query_order",
        "part_through_occluder",
        "missing_array",
        "false_owner",
    ],
)
def test_malformed_rasters_are_rejected_before_output_creation(tmp_path, damage):
    _, document, arrays = inputs(tmp_path)
    if damage == "depth_size":
        arrays["depth"] = arrays["depth"][:, :50]
    if damage == "mask_size":
        arrays["visible"] = arrays["visible"][:, :, :50]
    if damage == "gray_depth":
        arrays["depth"] = arrays["depth"].astype(np.uint8)
    if damage == "query_order":
        arrays["instance_ids"] = np.array([29, 17])
    if damage == "part_through_occluder":
        arrays["stem"][0, 35, 45] = True
    if damage == "missing_array":
        arrays.pop("part_unknown")
    if damage == "false_owner":
        arrays["owner"][60, 50] = 29
    scene, labels = save_inputs(tmp_path, document, arrays)
    out = tmp_path / "out"
    with pytest.raises(ValueError):
        MODULE.qualify_scene(scene, labels, out)
    assert not out.exists()


def test_unknown_owner_ignore_and_sky_no_hit_remain_invalid(tmp_path):
    _, document, arrays = inputs(tmp_path)
    arrays["known"][0] = False
    arrays["owner"][0] = -1
    arrays["depth_valid"][0] = False
    arrays["depth"][0] = np.inf
    scene, labels = save_inputs(tmp_path, document, arrays)
    out = tmp_path / "out"
    report = MODULE.qualify_scene(scene, labels, out, require_complete_metrics=False)
    assert report["qualification_passed"]
    with np.load(out / "qualification.npz", allow_pickle=False) as archive:
        assert np.isnan(archive["camera_z_m"][0]).all()
        assert (archive["owner"][0] == -1).all()


def test_missing_known_tree_depth_is_a_reported_failure(tmp_path):
    _, document, arrays = inputs(tmp_path, complete_metrics=True)
    arrays["depth_valid"][60, 50] = False
    scene, labels = save_inputs(tmp_path, document, arrays)
    report = MODULE.qualify_scene(scene, labels, tmp_path / "out")
    assert report["issues"] == ["known_visible_tree_pixels_missing_metric_depth"]
    assert report["depth"]["known_tree_pixels_missing_depth"] == 1


def test_non_tree_occluder_cannot_pass_tree_scope_and_total_scope_is_explicit(tmp_path):
    _, document, arrays = inputs(tmp_path)
    arrays["other_visible"] = arrays["visible"][1:2].copy()
    arrays["visible"][1] = arrays["amodal"][1] = arrays["crown"][1] = False
    arrays["owner"][arrays["owner"] == 29] = 0
    scene, labels = save_inputs(tmp_path, document, arrays)
    tree = MODULE.qualify_scene(scene, labels, tmp_path / "tree", require_complete_metrics=False)
    assert not tree["qualification_passed"]
    total = MODULE.qualify_scene(
        scene, labels, tmp_path / "total", occlusion_scope="total", require_complete_metrics=False
    )
    assert total["qualification_passed"]
    assert total["instances"][0]["tree_occluded_fraction"] == 0
    assert total["instances"][0]["other_occluded_fraction"] == 0.25


def test_output_is_never_overwritten_and_rgb_dimensions_are_checked(tmp_path):
    (scene, labels), _, _ = inputs(tmp_path)
    rgb = tmp_path / "rgb.png"
    Image.new("RGB", (100, 100)).save(rgb)
    out = tmp_path / "out"
    report = MODULE.qualify_scene(scene, labels, out, rgb_path=rgb, require_complete_metrics=False)
    assert report["rgb_file_dimensions_verified"]
    previous = (out / "report.json").read_bytes()
    with pytest.raises(FileExistsError):
        MODULE.qualify_scene(scene, labels, out)
    assert (out / "report.json").read_bytes() == previous
    Image.new("RGB", (50, 100)).save(rgb)
    with pytest.raises(ValueError, match="RGB pixels"):
        MODULE.qualify_scene(scene, labels, tmp_path / "bad", rgb_path=rgb)
    assert not (tmp_path / "bad").exists()


def test_cli_exit_codes_distinguish_full_metric_failure_and_segmentation_contract_pass(tmp_path):
    (scene, labels), _, _ = inputs(tmp_path)
    command = [
        sys.executable,
        str(ROOT / "scripts/qualify_metric_scene.py"),
        "--scene",
        str(scene),
        "--labels",
        str(labels),
    ]
    failed = subprocess.run(
        [*command, "--output", str(tmp_path / "failed")],
        capture_output=True,
        text=True,
        check=False,
    )
    assert failed.returncode == 1, failed.stderr
    assert not json.loads(failed.stdout)["qualification_passed"]
    passed = subprocess.run(
        [*command, "--output", str(tmp_path / "passed"), "--allow-incomplete-metrics"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert passed.returncode == 0, passed.stderr
    assert json.loads(passed.stdout)["qualification_passed"]
