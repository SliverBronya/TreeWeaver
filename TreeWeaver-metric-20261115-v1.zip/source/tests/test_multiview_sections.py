import numpy as np

from treeweaver.factor.multiview_sections import fit_view_cross_section


def test_fits_breast_height_section_and_penalizes_partial_coverage() -> None:
    angle = np.linspace(-0.7, 0.7, 100)
    heights = np.linspace(1.18, 1.42, 5)
    points = np.array(
        [
            [0.22 * np.cos(theta), 0.22 * np.sin(theta), height]
            for height in heights
            for theta in angle
        ]
    )

    result = fit_view_cross_section(
        "front",
        points,
        np.zeros(3),
        np.array([0.0, 0.0, 1.0]),
        1.0,
        0.8,
    )

    assert result is not None
    assert abs(result.radius_reconstruction - 0.22) < 0.01
    assert result.reliability < 0.8


def test_returns_none_when_view_has_too_few_breast_height_points() -> None:
    result = fit_view_cross_section(
        "sparse",
        np.zeros((15, 3)),
        np.zeros(3),
        np.array([0.0, 0.0, 1.0]),
        1.0,
        1.0,
    )
    assert result is None
