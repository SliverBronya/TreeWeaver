import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from partial_supervision import masked_bce_dice  # noqa: E402


def test_unknown_trunk_continuation_is_not_pushed_to_background():
    logits = torch.zeros(12, 8, requires_grad=True)
    target = torch.zeros_like(logits)
    target[6:9, 3:5] = 1
    valid = torch.zeros_like(logits)
    valid[6:9] = 1
    masked_bce_dice(logits, target, valid).backward()
    assert torch.equal(logits.grad[:6], torch.zeros_like(logits.grad[:6]))
    assert (logits.grad[6:9, 3:5] < 0).all()
    assert (logits.grad[6:9, :3] > 0).all()


def test_unknown_pixels_cannot_change_partial_loss():
    target = torch.zeros(12, 8)
    target[6:9, 3:5] = 1
    valid = torch.zeros_like(target)
    valid[6:9] = 1
    logits = torch.zeros_like(target)
    before = masked_bce_dice(logits, target, valid)
    logits[:6] = 100
    target[:6] = 1
    after = masked_bce_dice(logits, target, valid)
    torch.testing.assert_close(before, after, rtol=0, atol=0)


def test_empty_annotation_is_rejected():
    with pytest.raises(ValueError, match="known pixels"):
        masked_bce_dice(torch.zeros(3, 4), torch.zeros(3, 4), torch.zeros(3, 4))
