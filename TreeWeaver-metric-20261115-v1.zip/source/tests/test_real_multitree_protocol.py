"""Original-frame prompts and fail-closed human annotation checks (CPU only)."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import cv2
import numpy as np
import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")

SPEC = importlib.util.spec_from_file_location(
    "real_multitree", Path(__file__).resolve().parents[1] / "scripts" / "evaluate_real_multitree.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_coordinate_scaling_and_negative_point_padding():
    instances = [
        {
            "id": "a",
            "box": [0, 0, 500, 250],
            "positive_points": [[250, 125]],
            "negative_points": [[750, 125]],
        },
        {"id": "b", "box": [500, 0, 1000, 250], "positive_points": [[750, 125]]},
    ]
    prompts = MODULE.prompt_tensors(instances, 1000, 500, "cpu")
    assert prompts["input_boxes"].shape == (1, 2, 4)
    np.testing.assert_allclose(prompts["input_boxes"][0, 1], [512, 0, 1024, 512])
    np.testing.assert_allclose(prompts["input_points"][0, 0, 0], [256, 256])
    assert prompts["input_labels"].tolist() == [[[1, 0], [1, -1]]]


def test_box_selection_removes_duplicate_proposals():
    boxes = np.array([[0, 0, 100, 100], [1, 1, 99, 99], [150, 0, 250, 100]])
    assert MODULE.select_boxes(boxes, [0.9, 0.8, 0.7], 4, 0.5) == [0, 2]


def test_point_out_of_image_and_mixed_missing_boxes_rejected():
    with pytest.raises(ValueError):
        MODULE.prompt_tensors([{"id": "a", "positive_points": [[200, 50]]}], 100, 100, "cpu")
    with pytest.raises(ValueError):
        MODULE.prompt_tensors(
            [{"id": "a", "box": [0, 0, 50, 50]}, {"id": "b", "positive_points": [[75, 75]]}],
            100,
            100,
            "cpu",
        )


def test_verified_annotation_hash_drift_stops_evaluation(tmp_path):
    source = tmp_path / "annotation.json"
    source.write_text("{}")
    record = {
        "review": {
            "status": "human_verified",
            "source": "human_annotation",
            "reviewer": "tester",
            "annotation_sha256": "0" * 64,
            "source_annotation": str(source),
        }
    }
    with pytest.raises(ValueError, match="changed"):
        MODULE.evaluate_annotations(record, tmp_path, {}, None, (20, 20), 2)


def test_reviewed_gt_metrics_and_mask_hash_guard(tmp_path):
    source = tmp_path / "annotation.json"
    source.write_text(
        json.dumps(
            {
                "treeweaver_provenance": "human_annotation",
                "flags": {"assistant_draft": False},
                "treeweaver_review": {"state": "approved", "reviewer": "tester"},
                "treeweaver_coverage": "partial",
                "source_image_sha256": "a" * 64,
            }
        )
    )
    masks = np.zeros((2, 24, 24), bool)
    masks[0, 3:10, 3:10] = True
    masks[1, 13:21, 13:21] = True
    owner = np.zeros((24, 24), np.uint16)
    instances, digests = [], {}
    for i, mask in enumerate(masks):
        path = tmp_path / f"gt_{i}.png"
        cv2.imwrite(str(path), mask.astype(np.uint8) * 255)
        digests[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        instances.append({"id": f"tree-{i}", "visible_mask": str(path)})
        owner[mask] = i + 1
    unknown_path = tmp_path / "unknown.png"
    cv2.imwrite(str(unknown_path), (~masks.any(axis=0)).astype(np.uint8) * 255)
    digests[str(unknown_path)] = hashlib.sha256(unknown_path.read_bytes()).hexdigest()
    record = {
        "image_sha256": "a" * 64,
        "unknown_mask": str(unknown_path),
        "instances": instances,
        "review": {
            "status": "human_verified",
            "source": "human_annotation",
            "reviewer": "tester",
            "source_annotation": str(source),
            "annotation_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "mask_sha256": digests,
        },
    }
    result = MODULE.evaluate_annotations(record, tmp_path, {"raw": masks}, owner, (24, 24), 2)
    assert result["metrics"]["raw"]["mean_iou"] == 1
    assert result["metrics"]["ownership"]["foreground_accuracy"] == 1
    assert result["metrics"]["ownership"]["overlap_accuracy"] is None
    assert result["metrics"]["raw"]["iou_metric_name"] == "partial_known_region_iou"
    assert result["known_background_pixels"] == 0
    assert 0 < result["valid_pixel_fraction"] < 1
    assert result["metrics"]["raw"]["mean_boundary_f1"] is None
    cv2.imwrite(instances[0]["visible_mask"], np.zeros((24, 24), np.uint8))
    with pytest.raises(ValueError, match="changed"):
        MODULE.evaluate_annotations(record, tmp_path, {"raw": masks}, owner, (24, 24), 2)
