from __future__ import annotations

import numpy as np

from treeweaver.association.root_topology import (
    AMBIGUOUS_LABEL,
    UNREACHABLE_LABEL,
    RootAnchor,
    assign_points_to_root_anchors,
)


def test_separates_touching_stems_and_preserves_ambiguous_shared_crown() -> None:
    height = np.arange(0.0, 3.1, 0.2)
    left = np.column_stack((np.full_like(height, -0.5), np.zeros_like(height), height))
    right = np.column_stack((np.full_like(height, 0.5), np.zeros_like(height), height))
    shared = np.array([[0.0, 0.0, 3.0], [0.0, 0.0, 3.2], [0.0, 0.0, 3.4]])
    isolated = np.array([[4.0, 4.0, 1.0]])
    points = np.vstack((left, right, shared, isolated))
    trunk = np.concatenate((np.ones(len(left) + len(right)), np.zeros(len(shared) + 1)))

    result = assign_points_to_root_anchors(
        points,
        (
            RootAnchor(11, np.array([-0.5, 0.0, 0.0])),
            RootAnchor(22, np.array([0.5, 0.0, 0.0])),
        ),
        trunk_probability=trunk,
        neighbor_count=6,
        maximum_edge_length=0.56,
        ambiguity_ratio=0.2,
    )

    assert np.all(result.labels[: len(left)] == 11)
    assert np.all(result.labels[len(left) : len(left) + len(right)] == 22)
    assert AMBIGUOUS_LABEL in result.labels[-4:-1]
    assert result.labels[-1] == UNREACHABLE_LABEL
    assert result.unreachable_indices.tolist() == [len(points) - 1]


def test_rejects_root_far_from_reconstruction() -> None:
    points = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 0.2]])
    with np.testing.assert_raises_regex(ValueError, "from the point cloud"):
        assign_points_to_root_anchors(
            points,
            (RootAnchor(1, np.array([3.0, 0.0, 0.0])),),
            maximum_root_distance=0.1,
        )
