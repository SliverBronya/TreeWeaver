import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from treeweaver.association.bundle import associate_instance_bundle
from treeweaver.semantics.bundle import fuse_semantic_bundle


class AssociationBundleTests(unittest.TestCase):
    def test_end_to_end_bundle_produces_two_persistent_tracks(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            frames = root / "frames"
            masks = root / "masks"
            model = root / "model"
            frames.mkdir()
            masks.mkdir()
            model.mkdir()
            for name in ("a.jpg", "b.jpg"):
                (frames / name).write_bytes(b"fixture")

            camera = {"fx": 300, "fy": 300, "cx": 200, "cy": 150, "width": 400, "height": 300}
            capture = {
                "schema_version": "1.0",
                "session_id": "association-test",
                "device": {
                    "device_id": "test",
                    "has_imu": False,
                    "has_arcore": False,
                    "has_metric_depth": False,
                    "depth_source": "none",
                },
                "frames": [
                    {
                        "frame_id": "a",
                        "timestamp_ns": 1,
                        "image_path": "frames/a.jpg",
                        "intrinsics": camera,
                    },
                    {
                        "frame_id": "b",
                        "timestamp_ns": 2,
                        "image_path": "frames/b.jpg",
                        "intrinsics": camera,
                    },
                ],
                "scale_anchors": [{"kind": "marker", "metric_length_m": 1, "confidence": 1}],
            }
            capture_path = root / "capture.json"
            capture_path.write_text(json.dumps(capture), encoding="utf-8")
            (model / "images.txt").write_text(
                "1 1 0 0 0 0 0 0 1 a.jpg\n\n2 1 0 0 0 -0.35 0 0 1 b.jpg\n\n",
                encoding="utf-8",
            )
            (model / "points3D.txt").write_text("1 0 0 5 1 2 3 0.5 1 0 2 0\n", encoding="utf-8")

            rng = np.random.default_rng(91)
            left = rng.normal(scale=[0.12, 0.25, 0.08], size=(400, 3)) + [-1, 0, 5]
            right = rng.normal(scale=[0.12, 0.25, 0.08], size=(400, 3)) + [1, 0, 5]
            ground = rng.normal(scale=[1.5, 0.04, 0.08], size=(500, 3)) + [0, 1.35, 5]
            np.savez(root / "dense.npz", points=np.vstack((left, right, ground)))

            def save_mask(name: str, x_world: float, translation: float) -> None:
                u = round(300 * (x_world + translation) / 5 + 200)
                mask = np.zeros((300, 400), dtype=np.uint8)
                cv2.circle(mask, (u, 150), 24, 255, -1)
                self.assertTrue(cv2.imwrite(str(masks / name), mask))

            save_mask("a-left.png", -1, 0)
            save_mask("a-right.png", 1, 0)
            save_mask("b-left.png", -1, -0.35)
            save_mask("b-right.png", 1, -0.35)

            def save_point_mask(name: str, points: np.ndarray, translation: float) -> None:
                camera_points = points + [translation, 0, 0]
                u = np.rint(300 * camera_points[:, 0] / camera_points[:, 2] + 200).astype(int)
                v = np.rint(300 * camera_points[:, 1] / camera_points[:, 2] + 150).astype(int)
                mask = np.zeros((300, 400), dtype=np.uint8)
                inside = (u >= 0) & (u < 400) & (v >= 0) & (v < 300)
                mask[v[inside], u[inside]] = 255
                mask = cv2.dilate(mask, np.ones((5, 5), dtype=np.uint8))
                self.assertTrue(cv2.imwrite(str(masks / name), mask))

            for view, translation in (("a", 0.0), ("b", -0.35)):
                save_point_mask(f"{view}-left-trunk.png", left[left[:, 1] >= 0], translation)
                save_point_mask(f"{view}-left-crown.png", left[left[:, 1] < 0], translation)
                save_point_mask(f"{view}-right-trunk.png", right[right[:, 1] >= 0], translation)
                save_point_mask(f"{view}-right-crown.png", right[right[:, 1] < 0], translation)
                save_point_mask(f"{view}-ground.png", ground, translation)
            observations = {
                "schema_version": "instance-observations-1.0",
                "views": [
                    {
                        "image_name": "a.jpg",
                        "ground_mask_path": "masks/a-ground.png",
                        "instances": [
                            {
                                "local_instance_id": 10,
                                "mask_path": "masks/a-left.png",
                                "parts": {
                                    "trunk": "masks/a-left-trunk.png",
                                    "crown": "masks/a-left-crown.png",
                                },
                            },
                            {
                                "local_instance_id": 20,
                                "mask_path": "masks/a-right.png",
                                "parts": {
                                    "trunk": "masks/a-right-trunk.png",
                                    "crown": "masks/a-right-crown.png",
                                },
                            },
                        ],
                    },
                    {
                        "image_name": "b.jpg",
                        "ground_mask_path": "masks/b-ground.png",
                        "instances": [
                            {
                                "local_instance_id": 2,
                                "mask_path": "masks/b-left.png",
                                "parts": {
                                    "trunk": "masks/b-left-trunk.png",
                                    "crown": "masks/b-left-crown.png",
                                },
                            },
                            {
                                "local_instance_id": 1,
                                "mask_path": "masks/b-right.png",
                                "parts": {
                                    "trunk": "masks/b-right-trunk.png",
                                    "crown": "masks/b-right-crown.png",
                                },
                            },
                        ],
                    },
                ],
            }
            observation_path = root / "observations.json"
            observation_path.write_text(json.dumps(observations), encoding="utf-8")

            result = associate_instance_bundle(
                capture_path,
                model,
                root / "dense.npz",
                observation_path,
                root / "tracks",
                minimum_support_points=30,
                minimum_jaccard=0.1,
            )
            self.assertEqual(result.track_count, 2)
            self.assertEqual(result.associated_observations, 4)
            metadata = json.loads((result.output_directory / "tracks.json").read_text())
            self.assertEqual(len(metadata["tracks"]), 2)
            with np.load(result.output_directory / "track-points.npz") as arrays:
                self.assertEqual(len(arrays.files), 4)

            semantic = fuse_semantic_bundle(
                capture_path,
                model,
                root / "dense.npz",
                observation_path,
                result.output_directory,
                root / "semantics",
            )
            self.assertEqual(semantic.track_count, 2)
            self.assertGreater(semantic.trunk_points, 100)
            self.assertGreater(semantic.crown_points, 100)
            self.assertGreater(semantic.ground_points, 100)
            with np.load(semantic.output_directory / "semantic-points.npz") as arrays:
                self.assertEqual(len(arrays["trunk_reliability"]), len(arrays["trunk_indices"]))
                self.assertEqual(len(arrays["crown_reliability"]), len(arrays["crown_indices"]))
                self.assertEqual(len(arrays["ground_reliability"]), len(arrays["ground_indices"]))


if __name__ == "__main__":
    unittest.main()
