import numpy as np

from treeweaver.measurement.image_readiness import (
    MeasurementReadiness,
    assess_single_image_measurement,
)
from treeweaver.visibility.basal_occluder import assess_basal_object_contact
from treeweaver.visibility.image_complexity import ImageChallengeCue, audit_target_view


def test_object_at_visible_stem_endpoint_flags_possible_occlusion() -> None:
    trunk = np.zeros((120, 120), dtype=bool)
    trunk[30:95, 58:62] = True
    car = np.zeros_like(trunk)
    car[96:115, 35:85] = True
    result = assess_basal_object_contact(trunk, car, radius_px=4)
    assert result.touching
    assert result.basal_endpoint_xy == (60, 94)


def test_distant_object_does_not_flag_stem_endpoint() -> None:
    trunk = np.zeros((120, 120), dtype=bool)
    trunk[30:95, 58:62] = True
    car = np.zeros_like(trunk)
    car[96:115, 0:25] = True
    assert not assess_basal_object_contact(trunk, car, radius_px=4).touching


def test_basal_object_contact_blocks_root_dependent_measurements() -> None:
    trunk = np.zeros((120, 120), dtype=bool)
    trunk[30:95, 58:62] = True
    crown = np.zeros_like(trunk)
    crown[15:50, 40:80] = True
    car = np.zeros_like(trunk)
    car[96:115, 35:85] = True
    audit = audit_target_view(trunk | crown, trunk, crown, non_tree_object_masks=(car,))
    assert audit.score(ImageChallengeCue.BASAL_OBJECT_CONTACT) > 0.25
    gates = {gate.parameter.value: gate for gate in assess_single_image_measurement(audit)}
    assert gates["height_m"].readiness == MeasurementReadiness.BLOCKED
    assert gates["dbh_cm"].readiness == MeasurementReadiness.BLOCKED
