from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location(
    "research_protocol",
    Path(__file__).resolve().parents[1] / "workers/tree_models/research_protocol.py",
)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_protected_data_and_children_cannot_be_training(tmp_path):
    policy = tmp_path / "usage.json"
    policy.write_text(
        json.dumps(
            {
                "root": ".",
                "datasets": [
                    {"path": "held-out", "training_allowed": False, "role": "evaluation_only"}
                ],
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Training forbidden"):
        MODULE.assert_training_allowed(tmp_path / "held-out/images", policy)
    MODULE.assert_training_allowed(tmp_path / "held-out-similar-name", policy)


def test_current_policy_protects_local_validation_and_holdout():
    root = Path(__file__).resolve().parents[1]
    for path in (
        "data/20260411",
        "reports/fig-hard-holdout2-2026-11-01",
        "reports/focal-view-qualification-2026-11-09",
    ):
        with pytest.raises(ValueError, match="Training forbidden"):
            MODULE.assert_training_allowed(root / path)
    MODULE.assert_training_allowed(root / "data/external/synthtree43k")


def test_trunk_reference_opens_only_for_train_role_tree_ids():
    root = Path(__file__).resolve().parents[1]
    trunks = root / "data/external/tree-stereo-biophysical-v4/extracted/trunks"
    split = json.loads(
        (root / "reports/real-visible-pilot-2026-11-01/splits.json").read_text(encoding="utf-8")
    )
    # The whole directory is still closed: a caller that only knows the path cannot train.
    with pytest.raises(ValueError, match="Training forbidden"):
        MODULE.assert_training_allowed(trunks)
    train_ids = split["splits"]["train"]
    scope = MODULE.assert_training_allowed(trunks, tree_ids=train_ids[:3])
    assert scope["scope"] != "directory"
    assert len(scope["tree_ids"]) == 3
    # Validation and protected identities are rejected even with an explicit list.
    for leaked in (
        train_ids[:1] + [split["splits"]["validation"][0]],
        train_ids[:1] + [split["protected_reference_tree_ids"][0]],
    ):
        with pytest.raises(ValueError, match="Training forbidden|not in"):
            MODULE.assert_training_allowed(trunks, tree_ids=leaked)


def test_tree_scope_rejects_identities_outside_the_split(tmp_path):
    split = tmp_path / "split.json"
    split.write_text(
        json.dumps(
            {
                "splits": {"train": [1, 2], "validation": [3]},
                "protected_reference_tree_ids": [4],
                "excluded_legacy_tree_ids": [],
            }
        ),
        encoding="utf-8",
    )
    policy = tmp_path / "usage.json"
    policy.write_text(
        json.dumps(
            {
                "root": ".",
                "datasets": [
                    {
                        "path": "trunks",
                        "training_allowed": False,
                        "role": "evaluation_only",
                        "tree_scoped_training": {
                            "split": "split.json",
                            "allowed_roles": ["train"],
                            "max_tree_count": 2,
                        },
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "trunks").mkdir()
    assert MODULE.assert_training_allowed(tmp_path / "trunks", policy, tree_ids=[1]) is not None
    with pytest.raises(ValueError, match="Training forbidden"):
        MODULE.assert_training_allowed(tmp_path / "trunks", policy, tree_ids=[1, 4])
    with pytest.raises(ValueError, match="not in"):
        MODULE.assert_training_allowed(tmp_path / "trunks", policy, tree_ids=[9])
    with pytest.raises(ValueError, match="Training forbidden"):
        MODULE.assert_training_allowed(tmp_path / "trunks", policy)


def test_pinned_revision_does_not_fall_back_to_another_snapshot(tmp_path):
    wrong = tmp_path / "models--a--b/snapshots" / ("a" * 40)
    wrong.mkdir(parents=True)
    with pytest.raises(FileNotFoundError, match="Pinned"):
        MODULE.pinned_snapshot("a/b", "b" * 40, tmp_path)
    assert MODULE.pinned_snapshot("a/b", "a" * 40, tmp_path) == wrong


def test_missing_visibility_channel_has_no_gradient():
    torch = pytest.importorskip("torch")
    spec = importlib.util.spec_from_file_location(
        "supervision", Path(__file__).resolve().parents[1] / "workers/tree_models/supervision.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prediction = torch.tensor([[[0.4, 0.9]]], requires_grad=True)
    target = torch.tensor([[[0.8, float("nan")]]])
    loss = module.masked_visibility_mse(prediction, target, torch.tensor([[[True, False]]]))
    loss.backward()
    assert loss.item() == pytest.approx(0.16)
    assert prediction.grad[0, 0, 1].item() == 0


def test_changed_label_files_invalidate_training_protocol(tmp_path):
    (tmp_path / "index.json").write_text("{}", encoding="utf-8")
    (tmp_path / "splits.json").write_text("{}", encoding="utf-8")
    (tmp_path / "masks").mkdir()
    label = tmp_path / "masks/label.png"
    label.write_bytes(b"first annotation")
    first = MODULE.training_protocol(tmp_path, str(tmp_path / "splits.json"), "a" * 40, 1)
    label.write_bytes(b"changed annotation")
    changed = MODULE.training_protocol(tmp_path, str(tmp_path / "splits.json"), "a" * 40, 1)
    assert first["index_sha256"] == changed["index_sha256"]
    assert first["dataset_content_sha256"] != changed["dataset_content_sha256"]


def test_old_decoder_cannot_be_claimed_as_unseen_asset_initialization():
    protocol = {
        "initial_checkpoint_sha256": "x",
        "split_sha256": "split",
        "index_sha256": "index",
        "dataset_content_sha256": "data",
    }
    with pytest.raises(ValueError, match="compatible split history"):
        MODULE.validate_initialization(protocol, {})
    MODULE.validate_initialization(protocol, {}, allow_unverified=True)
    assert protocol["initialization_split_compatible"] is False
