import unittest

from treeweaver.domain.models import (
    CameraIntrinsics,
    FrameObservation,
    Parameter,
    ParameterEstimate,
)
from treeweaver.guidance.next_view import recommend_next_view


class GuidanceTests(unittest.TestCase):
    def test_targets_parameter_with_largest_normalized_uncertainty(self) -> None:
        estimates = {
            Parameter.HEIGHT_M: ParameterEstimate(Parameter.HEIGHT_M, 10, 0.3, 0.8, 3),
            Parameter.DBH_CM: ParameterEstimate(Parameter.DBH_CM, 20, 5, 0.5, 2),
        }
        intrinsics = CameraIntrinsics(1000, 1000, 500, 400, 1000, 800)
        frames = (FrameObservation("f1", 1, "f1.jpg", intrinsics, azimuth_deg=0),)
        result = recommend_next_view(estimates, frames)
        self.assertTrue(result.required)
        self.assertEqual(result.target_parameter, Parameter.DBH_CM)
        self.assertEqual(result.azimuth_deg, 180.0)


if __name__ == "__main__":
    unittest.main()
