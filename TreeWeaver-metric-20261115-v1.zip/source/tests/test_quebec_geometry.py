import unittest

import numpy as np

from treeweaver.datasets.quebec_geometry import _ransac_circle_surface
from treeweaver.geometry.cross_section import fit_trunk_cross_section


class QuebecGeometryTests(unittest.TestCase):
    def test_ransac_recovers_trunk_ring_among_branch_outliers(self) -> None:
        angles = np.linspace(0, 2 * np.pi, 240, endpoint=False)
        trunk = np.column_stack((0.2 * np.cos(angles), 0.2 * np.sin(angles)))
        branch = np.column_stack((np.linspace(0.3, 1.2, 180), np.full(180, 0.4)))
        selected = _ransac_circle_surface(np.vstack((trunk, branch)), "synthetic-tree")
        estimate = fit_trunk_cross_section(selected)
        self.assertGreater(len(selected), 200)
        self.assertAlmostEqual(estimate.circumference_equivalent_diameter, 0.4, delta=0.02)


if __name__ == "__main__":
    unittest.main()
