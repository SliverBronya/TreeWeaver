import tempfile
import unittest
from pathlib import Path

from treeweaver.pipeline.journal import initialize_journal, record_stage, verify_journal
from treeweaver.pipeline.plan import Stage


class PipelineJournalTests(unittest.TestCase):
    def test_records_dependencies_and_detects_artifact_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            journal = initialize_journal(root / "run.json", "fixture")
            capture = root / "capture.json"
            capture.write_text("capture", encoding="utf-8")
            record_stage(journal, Stage.CAPTURE, (capture,))
            ingest = root / "ingest.json"
            ingest.write_text("ingest", encoding="utf-8")
            record_stage(journal, Stage.INGEST, (ingest,))
            self.assertEqual(len(verify_journal(journal)), 2)
            ingest.write_text("changed", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "changed|checksum"):
                verify_journal(journal)

    def test_refuses_out_of_order_stage(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            journal = initialize_journal(root / "run.json", "fixture")
            artifact = root / "result.json"
            artifact.write_text("result", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "dependencies"):
                record_stage(journal, Stage.FACTOR_OPTIMIZATION, (artifact,))


if __name__ == "__main__":
    unittest.main()
