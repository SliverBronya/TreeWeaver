"""Regressions for real instance evaluation; do not depend on model packages."""

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers" / "tree_models"))
from instance_metrics import (  # noqa: E402
    boundary_f1,
    instance_report,
    mask_iou,
    merge_split,
    ownership_report,
    verified_annotation,
)


def objects():
    masks = np.zeros((2, 24, 24), bool)
    masks[0, 3:11, 3:11] = True
    masks[1, 13:21, 13:21] = True
    return masks


def test_empty_masks_and_unknown_are_not_false_failures():
    empty = np.zeros((24, 24), bool)
    assert mask_iou(empty, empty) == 1
    assert boundary_f1(empty, empty) == 1
    assert mask_iou(empty, empty, empty) is None
    assert instance_report(empty[None], empty[None])["mean_iou"] is None
    assert merge_split(np.zeros((0, 24, 24)), np.zeros((0, 24, 24)))["miss_count"] == 0


def test_large_merge_and_small_splits_detected_without_iou_shortcut():
    gt = objects()
    merged = gt.any(axis=0)[None]
    report = merge_split(merged, gt)
    assert report["merge_count"] == 1
    assert report["matched_at_iou_threshold"] == 1  # one prediction cannot match two GTs
    split = np.zeros((2, 24, 24), bool)
    split[0, 3:7, 3:11] = True
    split[1, 7:11, 3:11] = True
    assert merge_split(split, gt[:1])["split_count"] == 1


def test_prompt_alignment_failure_and_boundaries():
    gt = objects()
    report = instance_report(gt.copy(), gt)
    assert report["mean_iou"] == 1
    assert report["mean_boundary_f1"] == 1
    pred = gt.copy()
    pred[1] = False
    report = instance_report(pred, gt)
    assert report["empty_prediction_failure_rate"] == 0.5
    assert report["merge_split"]["miss_count"] == 1
    assert boundary_f1(gt[0], np.roll(gt[0], 5, axis=0), tolerance=0) < 1
    with pytest.raises(ValueError):
        mask_iou(gt[0], gt[:, :, :10])


def test_unknown_regions_do_not_create_boundary_errors():
    gt = objects()[0]
    pred = gt.copy()
    pred[:, 15:] = True
    valid = np.ones_like(gt)
    valid[:, 14:] = False
    assert mask_iou(pred, gt, valid) == 1
    assert boundary_f1(pred, gt, valid) == 1


def test_ownership_requires_explicit_overlap_and_skips_unknown():
    gt = np.array([[0, 1], [2, 65535]])
    pred = np.array([[1, 1], [1, 1]])
    report = ownership_report(pred, gt)
    assert report["foreground_accuracy"] == 0.5
    assert report["overlap_accuracy"] is None
    report = ownership_report(pred, gt, overlap=np.array([[0, 1], [0, 0]], bool))
    assert report["overlap_accuracy"] == 1


def test_pseudo_or_unreviewed_masks_cannot_be_ground_truth(tmp_path):
    import hashlib
    import json

    annotation = tmp_path / "annotation.json"
    annotation.write_text(
        json.dumps(
            {
                "treeweaver_provenance": "human_annotation",
                "flags": {"assistant_draft": False},
                "treeweaver_review": {"state": "approved", "reviewer": "annotator-1"},
                "treeweaver_coverage": "exhaustive_visible",
                "source_image_sha256": "b" * 64,
            }
        )
    )
    mask = tmp_path / "visible.png"
    mask.write_bytes(b"mask fixture")
    record = {
        "image_sha256": "b" * 64,
        "instances": [{"id": "tree-1", "visible_mask": str(mask)}],
        "review": {
            "status": "human_verified",
            "source": "human_annotation",
            "reviewer": "annotator-1",
            "source_annotation": str(annotation),
            "annotation_sha256": hashlib.sha256(annotation.read_bytes()).hexdigest(),
            "mask_sha256": {str(mask): hashlib.sha256(mask.read_bytes()).hexdigest()},
        },
    }
    assert verified_annotation(record)
    record["review"]["source"] = "model_prediction"
    assert not verified_annotation(record)


def test_missing_mask_hash_or_draft_source_cannot_be_reviewed_truth(tmp_path):
    import hashlib
    import json

    mask = tmp_path / "mask.png"
    mask.write_bytes(b"fixture")
    path = tmp_path / "annotation.json"
    document = {
        "flags": {"assistant_draft": False},
        "treeweaver_provenance": "human_annotation",
        "treeweaver_coverage": "exhaustive_visible",
        "source_image_sha256": "c" * 64,
        "treeweaver_review": {"state": "approved", "reviewer": "tester"},
    }
    path.write_text(json.dumps(document))
    record = {
        "image_sha256": "c" * 64,
        "instances": [{"visible_mask": str(mask)}],
        "review": {
            "status": "human_verified",
            "reviewer": "tester",
            "source": "human_annotation",
            "source_annotation": str(path),
            "annotation_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "mask_sha256": {},
        },
    }
    assert not verified_annotation(record)
    record["review"]["mask_sha256"][str(mask)] = hashlib.sha256(mask.read_bytes()).hexdigest()
    assert verified_annotation(record)
    document["flags"]["assistant_draft"] = True
    path.write_text(json.dumps(document))
    record["review"]["annotation_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert not verified_annotation(record)
    assert not verified_annotation({})
    record["review"]["source"] = "human_annotation"
    path.write_text('{"changed":true}')
    assert not verified_annotation(record)
