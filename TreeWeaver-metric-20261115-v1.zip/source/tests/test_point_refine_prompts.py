import numpy as np
import pytest

from workers.whole_tree_sam2.point_refine import (
    automatic_prompts,
    choose_prompt_consistent_mask,
)


def test_automatic_prompts_stay_inside_tree_mask() -> None:
    tree = np.zeros((100, 100), dtype=bool)
    tree[10:65, 15:85] = True
    tree[65:98, 47:53] = True
    points, labels = automatic_prompts(tree)
    assert labels.count(1) == 3
    assert labels.count(0) == 6
    assert all(tree[round(y), round(x)] for x, y in points)


def test_automatic_prompts_reject_tiny_tree() -> None:
    with pytest.raises(ValueError, match="too small"):
        automatic_prompts(np.zeros((10, 10), dtype=bool))


def test_selection_rejects_high_score_crown_that_ignores_negative_prompts() -> None:
    whole = np.ones((20, 20), dtype=bool)
    crown = np.zeros_like(whole)
    crown[2:18, 2:18] = True
    trunk = np.zeros_like(whole)
    trunk[3:19, 9:11] = True
    points = [[9, 16], [10, 17], [9, 18], [3, 5], [16, 5]]
    labels = [1, 1, 1, 0, 0]
    selected = choose_prompt_consistent_mask(
        [crown, trunk], [0.99, 0.80], whole, points, labels
    )
    assert selected is not None
    mask, chosen, details = selected
    assert np.array_equal(mask, trunk)
    assert chosen["index"] == 1
    assert details[0]["negative_hits"] == 2


def test_selection_fails_closed_without_prompt_consistent_candidate() -> None:
    whole = np.ones((20, 20), dtype=bool)
    crown = np.zeros_like(whole)
    crown[2:18, 2:18] = True
    result = choose_prompt_consistent_mask(
        [crown], [0.99], whole, [[9, 16], [10, 17], [9, 18], [3, 5]], [1, 1, 1, 0]
    )
    assert result is None
