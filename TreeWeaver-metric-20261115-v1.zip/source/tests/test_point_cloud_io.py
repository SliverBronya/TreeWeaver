import tempfile
import unittest
from pathlib import Path

import numpy as np
from plyfile import PlyData, PlyElement

from treeweaver.io.point_cloud import load_point_cloud


class PointCloudIoTests(unittest.TestCase):
    def test_loads_npz_with_optional_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "cloud.npz"
            points = np.array([[0, 1, 2], [3, 4, 5]], dtype=np.float64)
            colors = np.array([[1, 2, 3], [4, 5, 6]], dtype=np.uint8)
            confidence = np.array([0.8, 0.9])
            np.savez(path, points=points, colors=colors, confidence=confidence)
            cloud = load_point_cloud(path)
            np.testing.assert_allclose(cloud.points, points)
            np.testing.assert_array_equal(cloud.colors, colors)
            np.testing.assert_allclose(cloud.confidence, confidence)

    def test_loads_binary_ply_used_by_dense_reconstruction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "fused.ply"
            vertices = np.array(
                [(1.0, 2.0, 3.0, 10, 20, 30), (4.0, 5.0, 6.0, 40, 50, 60)],
                dtype=[
                    ("x", "f4"),
                    ("y", "f4"),
                    ("z", "f4"),
                    ("red", "u1"),
                    ("green", "u1"),
                    ("blue", "u1"),
                ],
            )
            PlyData([PlyElement.describe(vertices, "vertex")], text=False).write(path)
            cloud = load_point_cloud(path)
            np.testing.assert_allclose(cloud.points, [[1, 2, 3], [4, 5, 6]])
            np.testing.assert_array_equal(cloud.colors, [[10, 20, 30], [40, 50, 60]])


if __name__ == "__main__":
    unittest.main()
