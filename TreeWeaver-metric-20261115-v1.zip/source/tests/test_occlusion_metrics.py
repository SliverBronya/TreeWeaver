"""Tests for per-tree occlusion metrics and prompt contract."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from occlusion_metrics import (  # noqa: E402
    AbstainConfig,
    abstain_reasons,
    boundary_f1,
    mask_iou,
    merge_split,
    observed_amodal_recall,
    ownership_accuracy,
    risk_coverage,
)


def test_mask_iou_and_boundary():
    mask = np.zeros((32, 32), bool)
    mask[8:24, 8:24] = True
    assert mask_iou(mask, mask) == 1.0
    assert boundary_f1(mask, mask) == 1.0
    shifted = np.zeros_like(mask)
    shifted[9:25, 9:25] = True
    assert 0.0 < mask_iou(mask, shifted) < 1.0


def test_ownership_accuracy():
    target = np.zeros((4, 4), np.uint8)
    target[0:2, 0:2] = 1
    target[2:4, 2:4] = 2
    predicted = target.copy()
    predicted[0, 0] = 2
    assert ownership_accuracy(predicted, target) == 7 / 8
    assert np.isnan(ownership_accuracy(predicted, np.zeros_like(target)))


def test_merge_split_counts():
    target = np.zeros((3, 8, 8), bool)
    target[0, 0:4, 0:4] = True
    target[1, 4:8, 0:4] = True
    predicted = np.zeros((2, 8, 8), bool)
    predicted[0, 0:4, 0:4] = True
    predicted[1, 4:8, 0:4] = True
    result = merge_split(predicted, target)
    assert result["merge_count"] == 0
    assert result["split_count"] == 0
    assert result["miss_count"] == 0
    merged = np.zeros((1, 8, 8), bool)
    merged[0] = target.any(axis=0)
    result = merge_split(merged, target)
    assert result["merge_count"] == 1


def test_observed_amodal_recall():
    visible = np.zeros((8, 8), bool)
    visible[2:6, 2:4] = True
    observed = visible.copy()
    observed[2:6, 4:7] = True
    predicted = observed.copy()
    assert observed_amodal_recall(predicted, observed, visible) == 1.0


def test_abstain_reasons():
    reasons = abstain_reasons(
        stem_pixels=0,
        border_fraction=0.2,
        depth_contrast=0.01,
        candidate_iou=0.5,
        confidence=0.2,
    )
    assert set(reasons) == {
        "stem_invisible",
        "truncated",
        "depth_ambiguous",
        "mask_ambiguous",
        "low_confidence",
    }
    assert abstain_reasons(
        stem_pixels=100,
        border_fraction=0.0,
        depth_contrast=0.3,
        candidate_iou=0.9,
        confidence=0.9,
        config=AbstainConfig(),
    ) == []


def test_risk_coverage_monotone():
    result = risk_coverage(np.array([1.0, 0.0, 0.5]), np.array([0.1, 0.9, 0.5]))
    assert np.all(np.diff(result["coverage"]) > 0)
    assert np.all((result["risk"] >= 0) & (result["risk"] <= 1))


def test_tree_prompt_tensors():
    # Numerical metrics are part of the torch-free core test suite; only prompt
    # tensor conversion requires the optional model worker environment.
    pytest.importorskip("torch")
    from prompt_api import TreePrompt, stem_point_from_box

    prompt = TreePrompt(
        positive_points=((10.0, 20.0),),
        negative_points=((30.0, 20.0),),
        box=(0.0, 0.0, 40.0, 40.0),
    )
    tensors = prompt.to_tensors()
    assert tensors["input_points"].shape == (1, 1, 2, 2)
    assert tensors["input_labels"].tolist() == [[[1, 0]]]
    assert tensors["input_boxes"].shape == (1, 1, 4)
    assert stem_point_from_box((0, 0, 10, 100), (100, 100)) == (5.0, 88.0)
    try:
        TreePrompt(positive_points=())
    except ValueError:
        pass
    else:
        raise AssertionError("empty positive points must raise")
