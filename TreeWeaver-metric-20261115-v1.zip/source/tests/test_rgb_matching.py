import cv2
import numpy as np

from treeweaver.association.rgb_matching import RgbTreeView, compare_rgb_tree_views


def test_rgb_matching_accepts_geometrically_translated_texture() -> None:
    rng = np.random.default_rng(42)
    source = rng.integers(0, 256, size=(240, 240, 3), dtype=np.uint8)
    shifted = cv2.warpAffine(source, np.float32([[1, 0, 9], [0, 1, 6]]), (240, 240))
    mask = np.ones((240, 240), dtype=bool)
    result = compare_rgb_tree_views(RgbTreeView("a", source, mask), RgbTreeView("b", shifted, mask))
    assert result.accepted
    assert result.geometric_inliers >= 15


def test_rgb_matching_rejects_unrelated_texture_without_inventing_identity() -> None:
    rng = np.random.default_rng(44)
    mask = np.ones((240, 240), dtype=bool)
    left = rng.integers(0, 256, size=(240, 240, 3), dtype=np.uint8)
    right = rng.integers(0, 256, size=(240, 240, 3), dtype=np.uint8)
    result = compare_rgb_tree_views(RgbTreeView("a", left, mask), RgbTreeView("b", right, mask))
    assert not result.accepted
