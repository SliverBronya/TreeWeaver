import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from treeweaver.calibration.fiducial import detect_aruco_marker, generate_aruco_marker_svg


class FiducialTests(unittest.TestCase):
    def test_detects_generated_marker(self) -> None:
        marker = cv2.aruco.generateImageMarker(
            cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50), 7, 240
        )
        canvas = np.full((400, 400), 255, dtype=np.uint8)
        canvas[80:320, 80:320] = marker
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "marker.png"
            cv2.imwrite(str(path), canvas)
            corners = detect_aruco_marker(path, 7)
            self.assertIsNotNone(corners)
            assert corners is not None
            self.assertEqual(corners.shape, (4, 2))

    def test_returns_none_for_absent_marker(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "blank.png"
            cv2.imwrite(str(path), np.full((100, 100), 255, dtype=np.uint8))
            self.assertIsNone(detect_aruco_marker(path, 1))

    def test_generates_physical_size_svg(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = generate_aruco_marker_svg(
                Path(temporary) / "marker.svg", 7, edge_length_mm=100
            )
            content = path.read_text(encoding="utf-8")
            self.assertIn('width="100mm"', content)
            self.assertIn("print at 100%", content)


if __name__ == "__main__":
    unittest.main()
