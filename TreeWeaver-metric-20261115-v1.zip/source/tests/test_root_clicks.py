import json
from pathlib import Path

import numpy as np

from treeweaver.association.root_clicks import triangulate_root_click_file


def test_root_click_file_writes_reconstruction_anchor(tmp_path: Path) -> None:
    frames = tmp_path / "frames"
    model = tmp_path / "model"
    frames.mkdir()
    model.mkdir()
    names = ("a.jpg", "b.jpg", "c.jpg")
    centres = (-1.0, 0.0, 1.0)
    for name in names:
        (frames / name).write_bytes(b"fixture")
    intrinsics = {"fx": 800, "fy": 800, "cx": 320, "cy": 240, "width": 640, "height": 480}
    capture = {
        "schema_version": "1.0",
        "session_id": "roots",
        "device": {
            "device_id": "test",
            "has_imu": False,
            "has_arcore": False,
            "has_metric_depth": False,
            "depth_source": "none",
        },
        "frames": [
            {
                "frame_id": name,
                "timestamp_ns": index + 1,
                "image_path": f"frames/{name}",
                "intrinsics": intrinsics,
            }
            for index, name in enumerate(names)
        ],
        "scale_anchors": [{"kind": "marker", "metric_length_m": 0.2, "confidence": 1}],
    }
    capture_path = tmp_path / "capture.json"
    capture_path.write_text(json.dumps(capture), encoding="utf-8")
    (model / "images.txt").write_text(
        "".join(
            f"{index + 1} 1 0 0 0 {-centre} 0 0 1 {name}\n\n"
            for index, (name, centre) in enumerate(zip(names, centres, strict=True))
        ),
        encoding="utf-8",
    )
    (model / "points3D.txt").write_text("", encoding="utf-8")
    point = np.array([0.1, 0.0, 5.0])
    clicks = {
        "schema_version": "root-clicks-1.0",
        "trees": [
            {
                "tree_id": 4,
                "observations": [
                    {
                        "image_name": name,
                        "x_px": 800 * (point[0] - centre) / point[2] + 320,
                        "y_px": 240,
                    }
                    for name, centre in zip(names, centres, strict=True)
                ],
            }
        ],
    }
    clicks_path = tmp_path / "clicks.json"
    clicks_path.write_text(json.dumps(clicks), encoding="utf-8")

    result = triangulate_root_click_file(
        capture_path,
        model,
        clicks_path,
        tmp_path / "roots.json",
        up=(0, -1, 0),
    )

    assert result.tree_count == 1
    payload = json.loads(result.output_path.read_text())
    np.testing.assert_allclose(payload["roots"][0]["position"], point, atol=1e-8)
    assert payload["roots"][0]["parallax_deg"] > 1.5
    assert payload["up"] == [0.0, -1.0, 0.0]
    deferred = triangulate_root_click_file(
        capture_path,
        model,
        clicks_path,
        tmp_path / "roots-without-up.json",
    )
    deferred_payload = json.loads(deferred.output_path.read_text())
    assert "up" not in deferred_payload
