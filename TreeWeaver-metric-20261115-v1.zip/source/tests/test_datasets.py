import hashlib
import io
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path
from urllib.request import Request

from treeweaver.datasets.acquisition import download_artifact
from treeweaver.datasets.archive import (
    extract_archive_safely,
    extract_tar_safely,
    inspect_archive,
    inspect_tar,
)
from treeweaver.datasets.registry import DatasetFile, get_dataset


class _Response(io.BytesIO):
    def __init__(self, content: bytes, status: int) -> None:
        super().__init__(content)
        self.status = status

    def __enter__(self) -> "_Response":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class DatasetTests(unittest.TestCase):
    def test_registry_contains_immutable_urtrees_release(self) -> None:
        dataset = get_dataset("urtrees-evaluation-2025")
        self.assertEqual(dataset.license_id, "CC-BY-4.0")
        self.assertEqual(dataset.files[0].size_bytes, 16_862_031_782)

    def test_registry_contains_greenlens_arcore_release(self) -> None:
        dataset = get_dataset("greenlens-arcore-v2")
        self.assertEqual(dataset.doi, "10.5281/zenodo.10776713")
        self.assertEqual(dataset.files[0].size_bytes, 59_932_765)
        self.assertEqual(dataset.files[0].checksum, "7dcc8c0769fe43e37a3ec63925dad2e8")

    def test_registry_marks_whu_stree_as_request_gated(self) -> None:
        dataset = get_dataset("whu-stree-2026")
        self.assertEqual(dataset.files, ())
        self.assertIn("data request", dataset.access_notes)

    def test_registry_contains_destructive_volume_release(self) -> None:
        dataset = get_dataset("quebec-hardwood-volume-98-v1")
        self.assertEqual(dataset.doi, "10.5281/zenodo.21515256")
        self.assertEqual(dataset.license_id, "CC-BY-4.0")
        self.assertEqual(len(dataset.files), 5)
        self.assertEqual(dataset.files[0].size_bytes, 287_911_541)

    def test_registry_contains_verified_stereo_release(self) -> None:
        dataset = get_dataset("tree-stereo-biophysical-v3")
        self.assertEqual(dataset.doi, "10.17632/nx3ggv7pxf.3")
        self.assertEqual(dataset.files[0].size_bytes, 395_220_647)
        self.assertEqual(dataset.files[0].checksum_algorithm, "sha256")

    def test_registry_contains_verified_masked_stereo_release(self) -> None:
        dataset = get_dataset("tree-stereo-biophysical-v4")
        self.assertEqual(dataset.doi, "10.17632/nx3ggv7pxf.4")
        self.assertEqual(dataset.files[0].size_bytes, 563_941_204)

    def test_download_resumes_a_partial_artifact(self) -> None:
        content = b"verified tiny fixture"
        artifact = DatasetFile(
            "fixture.bin",
            "https://example.invalid/fixture.bin",
            len(content),
            "md5",
            hashlib.md5(content).hexdigest(),  # noqa: S324 - registry compatibility test
        )
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / artifact.filename
            destination.with_name(artifact.filename + ".part").write_bytes(content[:8])

            def opener(request: Request) -> _Response:
                self.assertEqual(request.get_header("Range"), "bytes=8-")
                return _Response(content[8:], 206)

            result = download_artifact(artifact, destination, opener=opener)
            self.assertEqual(result.resumed_from, 8)
            self.assertEqual(destination.read_bytes(), content)

    def test_download_retries_a_premature_eof(self) -> None:
        content = b"verified retry fixture"
        artifact = DatasetFile(
            "fixture.bin",
            "https://example.invalid/fixture.bin",
            len(content),
            "md5",
            hashlib.md5(content).hexdigest(),  # noqa: S324 - registry compatibility test
        )
        requests: list[str | None] = []

        def opener(request: Request) -> _Response:
            range_header = request.get_header("Range")
            requests.append(range_header)
            if range_header is None:
                return _Response(content[:7], 200)
            self.assertEqual(range_header, "bytes=7-")
            return _Response(content[7:], 206)

        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / artifact.filename
            result = download_artifact(artifact, destination, opener=opener)
            self.assertEqual(requests, [None, "bytes=7-"])
            self.assertEqual(result.bytes_written, len(content))
            self.assertEqual(destination.read_bytes(), content)

    def test_archive_inventory_and_safe_extraction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive_path = root / "fixture.tar.gz"
            payload = b"measurement"
            with tarfile.open(archive_path, "w:gz") as archive:
                member = tarfile.TarInfo("split/truth.csv")
                member.size = len(payload)
                archive.addfile(member, io.BytesIO(payload))
            inventory = inspect_tar(archive_path)
            self.assertEqual(inventory.file_count, 1)
            extract_tar_safely(archive_path, root / "output")
            self.assertEqual((root / "output/split/truth.csv").read_bytes(), payload)

    def test_archive_rejects_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive_path = root / "unsafe.tar"
            with tarfile.open(archive_path, "w") as archive:
                member = tarfile.TarInfo("../escape.txt")
                member.size = 1
                archive.addfile(member, io.BytesIO(b"x"))
            with self.assertRaisesRegex(ValueError, "unsafe"):
                extract_tar_safely(archive_path, root / "output")

    def test_zip_inventory_and_safe_extraction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive_path = root / "fixture.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("split/truth.csv", b"measurement")
            inventory = inspect_archive(archive_path)
            self.assertEqual(inventory.file_count, 1)
            extract_archive_safely(archive_path, root / "output")
            self.assertEqual((root / "output/split/truth.csv").read_bytes(), b"measurement")

    def test_zip_rejects_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive_path = root / "unsafe.zip"
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("../escape.txt", b"x")
            with self.assertRaisesRegex(ValueError, "unsafe"):
                extract_archive_safely(archive_path, root / "output")


if __name__ == "__main__":
    unittest.main()
