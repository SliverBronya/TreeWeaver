import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from treeweaver.providers.observation_bundle import (
    GroundMask,
    TreeMaskSet,
    validate_observation_bundle,
    write_observation_bundle,
)


class ObservationBundleTests(unittest.TestCase):
    def test_writes_canonical_provider_boundary(self) -> None:
        instance = np.zeros((20, 30), dtype=bool)
        instance[2:18, 8:22] = True
        trunk = np.zeros_like(instance)
        trunk[10:18, 12:18] = True
        crown = np.zeros_like(instance)
        crown[2:10, 8:22] = True
        ground = np.zeros_like(instance)
        ground[18:] = True
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "evidence"
            manifest = write_observation_bundle(
                root,
                (TreeMaskSet("f.jpg", 2, instance, trunk, crown, 0.8, 0.7),),
                (GroundMask("f.jpg", ground, 0.9),),
                provider="fixture",
                model_version="1",
                run_metadata={"temporal_mode": "fixture-video"},
            )
            payload = json.loads(manifest.read_text(encoding="utf-8"))
            item = payload["views"][0]["instances"][0]
            self.assertEqual(item["local_instance_id"], 2)
            self.assertEqual(payload["run_metadata"]["temporal_mode"], "fixture-video")
            self.assertIsNotNone(cv2.imread(str(root / item["parts"]["trunk"])))
            self.assertEqual(validate_observation_bundle(manifest), (1, 4))

    def test_rejects_parts_outside_instance(self) -> None:
        instance = np.zeros((5, 5), dtype=bool)
        trunk = np.ones_like(instance)
        with self.assertRaisesRegex(ValueError, "contained"):
            TreeMaskSet("f.jpg", 1, instance, trunk, np.zeros_like(instance), 1.0, 1.0)


if __name__ == "__main__":
    unittest.main()
