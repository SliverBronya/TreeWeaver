import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from completion_metrics import completion_report  # noqa: E402


def report(pa, pv, ta, tv, valid=None, **kwargs):
    known = np.ones_like(ta) if valid is None else valid
    return completion_report(pa, pv, ta, tv, known, full_target_verified=True, **kwargs)


def test_copying_visible_can_have_high_full_iou_but_zero_completion_score():
    ta = np.ones((10, 10), bool)
    tv = ta.copy()
    tv[:, -1] = False
    row = report(tv, tv, ta, tv)
    assert row["amodal_iou"] == 0.9
    assert row["hidden_recall"] == row["hidden_iou_oracle_visible"] == 0


def test_true_completion_and_unoccluded_control_have_different_denominators():
    ta = np.ones((5, 5), bool)
    tv = ta.copy()
    tv[:, -2:] = False
    row = report(ta, tv, ta, tv)
    assert row["hidden_recall"] == row["hidden_iou_oracle_visible"] == 1
    control = report(ta, ta, ta, ta)
    assert control["amodal_iou"] == 1 and control["unoccluded_target"]
    assert control["hidden_recall"] is control["hidden_iou_oracle_visible"] is None


def test_visible_errors_do_not_change_oracle_conditioned_completion_metric():
    ta = np.ones((5, 5), bool)
    tv = ta.copy()
    tv[:, -1] = False
    wrong_visible = tv.copy()
    wrong_visible[:, :2] = False
    row = report(ta, wrong_visible, ta, tv)
    assert row["hidden_iou_oracle_visible"] == 1
    assert row["hidden_iou_predicted_visible"] == pytest.approx(1 / 3)


def test_overexpansion_and_filling_leaf_gaps_are_penalized():
    ta = np.zeros((7, 7), bool)
    ta[1:6, 1:6] = True
    ta[3, 3] = False
    tv = ta.copy()
    tv[:, 5] = False
    filled = ta.copy()
    filled[3, 3] = True
    row = report(filled, tv, ta, tv)
    assert row["outside_target_expansion_fraction"] == pytest.approx(1 / 24)
    assert row["hidden_iou_oracle_visible"] < 1
    assert report(np.ones_like(ta), tv, ta, tv)["outside_target_expansion_fraction"] > 0.5


def test_unknown_and_unverified_or_truncated_support_cannot_become_full_tree_scores():
    ta = np.zeros((5, 5), bool)
    ta[1:4, 1:4] = True
    valid = np.ones_like(ta)
    valid[:, 4] = False
    pa = ta.copy()
    pa[:, 4] = True
    assert report(pa, ta, ta, ta, valid)["amodal_iou"] == 1
    assert report(ta, ta, ta, ta, frame_truncated=True)["ignored_reason"] == "frame_truncated"
    result = completion_report(pa, ta, ta, ta, valid, full_target_verified=False)
    assert result == {"eligible": False, "ignored_reason": "full_target_not_verified"}


def test_empty_part_or_visible_outside_verified_complete_is_rejected():
    empty = np.zeros((4, 4), bool)
    assert report(empty, empty, empty, empty)["ignored_reason"] == "empty_known_complete_support"
    with pytest.raises(ValueError, match="outside"):
        report(empty, empty, np.eye(4, dtype=bool), np.ones_like(empty))
