import tempfile
import unittest
from pathlib import Path

from treeweaver.datasets.greenlens import iter_depth_points


class GreenLensTests(unittest.TestCase):
    def test_depth_points_are_streamed_and_validated(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "0"
            path.write_text("0,0,2.5,1.0\n1,0,2.6,0.5\n", encoding="utf-8")
            points = list(iter_depth_points(path))
            self.assertEqual((points[1].x, points[1].y), (1, 0))
            self.assertAlmostEqual(points[0].depth_m, 2.5)
            self.assertAlmostEqual(points[1].confidence, 0.5)

    def test_invalid_confidence_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "0"
            path.write_text("0,0,2.5,1.2\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "invalid depth sample"):
                list(iter_depth_points(path))

    def test_zero_depth_and_confidence_represent_missing_measurement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "0"
            path.write_text("0,0,0.0,0.0\n", encoding="utf-8")
            points = list(iter_depth_points(path))
            self.assertEqual(points[0].depth_m, 0.0)
            self.assertEqual(points[0].confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
