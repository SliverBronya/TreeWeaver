import unittest

from treeweaver.evaluation.metrics import Prediction, evaluate_predictions


class EvaluationTests(unittest.TestCase):
    def test_reports_failures_uncertainty_and_selective_risk(self) -> None:
        predictions = (
            Prediction("a", "a1", "test", 10.0, 10.2, 0.2, 0.95),
            Prediction("b", "b1", "test", 20.0, 22.0, 1.0, 0.4),
            Prediction("c", "c1", "test", 15.0, None, None, 0.0),
        )
        result = evaluate_predictions(predictions)
        self.assertAlmostEqual(result.failure_rate, 1 / 3)
        self.assertEqual(result.metrics.count, 2)
        self.assertLess(result.risk_coverage[0].mae, result.metrics.mae)

    def test_rejects_tree_leakage_across_splits(self) -> None:
        predictions = (
            Prediction("same", "s1", "train", 10.0, 10.0, 0.2, 0.8),
            Prediction("same", "s2", "test", 10.0, 10.0, 0.2, 0.8),
        )
        with self.assertRaisesRegex(ValueError, "both"):
            evaluate_predictions(predictions)

    def test_accuracy_without_fabricated_uncertainty(self) -> None:
        predictions = (
            Prediction("a", "a1", "test", 10.0, 11.0, None, 1.0),
            Prediction("b", "b1", "test", 20.0, 19.0, None, 1.0),
        )
        result = evaluate_predictions(predictions)
        self.assertAlmostEqual(result.metrics.mae, 1.0)
        self.assertEqual(result.metrics.uncertainty_count, 0)
        self.assertIsNone(result.metrics.gaussian_nll)
        self.assertIsNone(result.metrics.interval_95_coverage)

    def test_mape_excludes_zero_truths(self) -> None:
        predictions = (
            Prediction("a", "a1", "test", 0.0, 0.1, None, 1.0),
            Prediction("b", "b1", "test", 2.0, 2.2, None, 1.0),
        )
        result = evaluate_predictions(predictions)
        self.assertEqual(result.metrics.percentage_count, 1)
        self.assertAlmostEqual(result.metrics.mean_absolute_percentage_error or 0.0, 0.1)


if __name__ == "__main__":
    unittest.main()
