import json
from pathlib import Path

import cv2
import numpy as np

from treeweaver.reconstruction.rgbd_bundle import fuse_rgbd_tree_bundle


def test_file_bundle_fuses_metric_frames_without_scale_anchor(tmp_path: Path) -> None:
    height, width = 200, 200
    mask = np.zeros((height, width), dtype=np.uint8)
    mask[70:181, 97:104] = 255
    cv2.ellipse(mask, (100, 65), (60, 45), 0, 0, 360, 255, -1)
    depth = np.full((height, width), 5000, dtype=np.uint16)
    confidence = np.full((height, width), 255, dtype=np.uint8)
    rgb = np.full((height, width, 3), 120, dtype=np.uint8)
    identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    frames = []
    mask_frames = []
    for index in range(2):
        stem = f"f{index}"
        cv2.imwrite(str(tmp_path / f"{stem}.png"), rgb)
        cv2.imwrite(str(tmp_path / f"{stem}-depth.png"), depth)
        cv2.imwrite(str(tmp_path / f"{stem}-confidence.png"), confidence)
        cv2.imwrite(str(tmp_path / f"{stem}-mask.png"), mask)
        frames.append(
            {
                "frame_id": stem,
                "timestamp_ns": index + 1,
                "image_path": f"{stem}.png",
                "depth_path": f"{stem}-depth.png",
                "depth_confidence_path": f"{stem}-confidence.png",
                "depth_unit_m": 0.001,
                "camera_to_world": identity,
                "tracking_state": "tracking",
                "intrinsics": {
                    "fx": 100,
                    "fy": 100,
                    "cx": 100,
                    "cy": 100,
                    "width": width,
                    "height": height,
                },
            }
        )
        mask_frames.append({"frame_id": stem, "mask_path": f"{stem}-mask.png"})
    capture = {
        "schema_version": "2.0",
        "session_id": "rgbd-test",
        "device": {
            "device_id": "synthetic",
            "has_imu": True,
            "has_arcore": True,
            "has_metric_depth": True,
            "depth_source": "arcore",
        },
        "gravity_down_world": [0, 1, 0],
        "frames": frames,
    }
    masks = {
        "schema_version": "tree-rgbd-masks-1.0",
        "tree_id": "T1",
        "frames": mask_frames,
    }
    capture_path = tmp_path / "capture.json"
    masks_path = tmp_path / "masks.json"
    capture_path.write_text(json.dumps(capture), encoding="utf-8")
    masks_path.write_text(json.dumps(masks), encoding="utf-8")

    run = fuse_rgbd_tree_bundle(
        capture_path,
        masks_path,
        tmp_path / "output",
        minimum_views=2,
    )

    result = json.loads(run.measurement_path.read_text(encoding="utf-8"))
    assert run.frame_count == 2
    assert run.point_count > 100
    assert result["manual_scale_required"] is False
    assert result["geometry"]["height_m"] > 5
    assert result["quality"]["passed"] is False
    assert result["quality"]["maximum_camera_baseline_m"] == 0
    assert result["quality"]["multi_view_supported_voxel_fraction"] == 1
