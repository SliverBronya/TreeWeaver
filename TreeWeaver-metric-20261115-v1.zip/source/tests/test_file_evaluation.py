import json
import tempfile
import unittest
from pathlib import Path

from treeweaver.evaluation.file_evaluation import evaluate_prediction_file


class FileEvaluationTests(unittest.TestCase):
    def test_writes_overall_and_stratified_metrics(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            predictions = []
            for index in range(6):
                predictions.append(
                    {
                        "tree_id": f"t{index}",
                        "session_id": f"s{index}",
                        "split": "external_test",
                        "parameter": "height_m",
                        "truth": 10 + index,
                        "estimate": 10.2 + index if index < 5 else None,
                        "standard_deviation": 0.3 if index < 5 else None,
                        "confidence": 0.9 if index < 5 else 0.0,
                        "strata": {"phone": "A" if index < 3 else "B"},
                    }
                )
            source = root / "predictions.json"
            source.write_text(
                json.dumps(
                    {"schema_version": "benchmark-predictions-1.0", "predictions": predictions}
                ),
                encoding="utf-8",
            )
            run = evaluate_prediction_file(source, root / "evaluation.json")
            self.assertEqual(run.attempted_count, 6)
            payload = json.loads(run.output_path.read_text(encoding="utf-8"))
            result = payload["parameters"]["height_m"]
            self.assertAlmostEqual(result["overall"]["failure_rate"], 1 / 6)
            self.assertIn("phone=A", result["strata"])


if __name__ == "__main__":
    unittest.main()
