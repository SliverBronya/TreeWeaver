from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

from treeweaver.datasets.real_annotations import rasterize_human_labelme


def annotation():
    return {
        "imageHeight": 20,
        "imageWidth": 20,
        "flags": {"assistant_draft": False},
        "treeweaver_coverage": "partial",
        "treeweaver_provenance": "human_annotation",
        "treeweaver_review": {"state": "approved", "reviewer": "test_fixture"},
        "shapes": [
            {
                "label": "visible",
                "group_id": 1,
                "shape_type": "polygon",
                "points": [[2, 2], [8, 2], [8, 8], [2, 8]],
            }
        ],
    }


def test_unlabelled_pixels_are_unknown_and_not_false_background():
    result = rasterize_human_labelme(annotation())
    assert result["unknown"][0, 0]
    assert result["ownership"][0, 0] == 65535
    assert result["ownership"][4, 4] == 1


@pytest.mark.parametrize("provenance", ["model_prediction", "assistant_visual_draft"])
def test_predictions_cannot_become_gt_by_flipping_review_flag(provenance):
    item = annotation()
    item["treeweaver_provenance"] = provenance
    with pytest.raises(ValueError, match="ground truth"):
        rasterize_human_labelme(item)


def test_overlapping_manual_visible_labels_become_unknown():
    item = annotation()
    other = copy.deepcopy(item["shapes"][0])
    other["group_id"] = 2
    other["points"] = [[6, 6], [12, 6], [12, 12], [6, 12]]
    item["shapes"].append(other)
    result = rasterize_human_labelme(item)
    assert result["ownership"][7, 7] == 65535
    assert result["ownership"][10, 10] == 2


def test_holes_are_kept_and_box_is_marked_as_gt_derived():
    item = annotation()
    item["shapes"].append(
        {
            "label": "visible",
            "group_id": 1,
            "shape_type": "polygon",
            "points": [[4, 4], [6, 4], [6, 6], [4, 6]],
            "flags": {"hole": True},
        }
    )
    result = rasterize_human_labelme(item)
    assert result["unknown"][5, 5]
    assert not result["instances"][0]["visible"][5, 5]
    assert result["instances"][0]["box_source"] == "gt_derived_box_upper_bound"


def test_outside_coordinates_and_unreviewed_annotations_are_rejected():
    item = annotation()
    item["shapes"][0]["points"][0][0] = 100
    with pytest.raises(ValueError, match="outside"):
        rasterize_human_labelme(item)
    item = annotation()
    item["treeweaver_review"]["state"] = "draft"
    with pytest.raises(ValueError, match="approval"):
        rasterize_human_labelme(item)


def test_collinear_polygon_is_not_a_visible_tree():
    item = annotation()
    item["shapes"][0]["points"] = [[2, 2], [8, 8], [14, 14]]
    with pytest.raises(ValueError, match="nonzero area"):
        rasterize_human_labelme(item)


def test_conflicting_background_and_tree_are_unknown():
    item = annotation()
    item["shapes"].append(
        {
            "label": "background",
            "shape_type": "polygon",
            "points": [[6, 6], [12, 6], [12, 12], [6, 12]],
        }
    )
    result = rasterize_human_labelme(item)
    assert result["ownership"][7, 7] == 65535
    assert result["ownership"][10, 10] == 0


def test_labelme_import_preserves_image_hash_unknown_and_rejects_drafts(tmp_path):
    pack = tmp_path / "pack"
    (pack / "images").mkdir(parents=True)
    (pack / "labelme").mkdir()
    image = pack / "images/1.png"
    assert cv2.imwrite(str(image), np.zeros((20, 20, 3), np.uint8))
    digest = hashlib.sha256(image.read_bytes()).hexdigest()
    label = annotation()
    label["source_image_sha256"] = digest
    annotation_path = pack / "labelme/1.json"
    annotation_path.write_text(json.dumps(label), encoding="utf-8")
    (pack / "manifest.json").write_text(
        json.dumps(
            {
                "schema_version": "treeweaver-real-multitree-1.0",
                "records": [
                    {
                        "image_id": "1",
                        "image": "images/1.png",
                        "split": "validation",
                        "image_sha256": digest,
                        "annotation": "labelme/1.json",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    script = Path(__file__).resolve().parents[1] / "scripts/import_real_labelme.py"
    output = tmp_path / "reviewed"
    command = [sys.executable, str(script), "--pack", str(pack), "--output", str(output)]
    subprocess.run(command, capture_output=True, check=True)
    record = json.loads((output / "manifest.json").read_text())["records"][0]
    assert record["image_sha256"] == digest
    assert record["annotation_coverage"] == "partial"
    unknown = cv2.imread(record["unknown_mask"], cv2.IMREAD_UNCHANGED)
    assert unknown[0, 0] == 255
    assert unknown[4, 4] == 0
    assert record["instances"][0]["box_source"] == "gt_derived_box_upper_bound"
    label["treeweaver_review"]["state"] = "draft"
    annotation_path.write_text(json.dumps(label), encoding="utf-8")
    unreviewed = tmp_path / "not-exported"
    command[-1] = str(unreviewed)
    result = subprocess.run(command, capture_output=True)
    assert result.returncode != 0
    assert not unreviewed.exists()
