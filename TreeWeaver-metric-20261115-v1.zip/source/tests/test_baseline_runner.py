from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from treeweaver.evaluation.baseline_runner import (
    BaselineConfig,
    _validate_complete_predictions,
    run_external_baseline,
)
from treeweaver.evaluation.protocol import (
    SampleIdentity,
    SplitAssignment,
    write_frozen_protocol,
)


def _protocol(tmp_path: Path) -> Path:
    samples = (
        SampleIdentity("s1", "t1", "session", "site", "phone", "operator"),
        SampleIdentity("s2", "t2", "session", "site", "phone", "operator"),
    )
    assignments = (
        SplitAssignment("s1", "t1", "train"),
        SplitAssignment("s2", "t2", "external_test"),
    )
    return write_frozen_protocol(
        tmp_path / "protocol.json",
        samples,
        assignments,
        seed="fixed",
        external_test_sites=frozenset(),
    )


def test_complete_baseline_predictions_must_include_failures(tmp_path: Path) -> None:
    protocol = _protocol(tmp_path)
    predictions = tmp_path / "predictions.json"
    predictions.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "predictions": [
                    {
                        "sample_id": "s1",
                        "tree_id": "t1",
                        "session_id": "session",
                        "split": "train",
                        "parameter": "height_m",
                        "truth": 10,
                        "estimate": 10.2,
                    },
                    {
                        "sample_id": "s2",
                        "tree_id": "t2",
                        "session_id": "session",
                        "split": "external_test",
                        "parameter": "height_m",
                        "truth": 12,
                        "estimate": None,
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    assert _validate_complete_predictions(predictions, protocol, ("height_m",)) == (2, 1)


def test_baseline_predictions_cannot_omit_failed_samples(tmp_path: Path) -> None:
    protocol = _protocol(tmp_path)
    predictions = tmp_path / "predictions.json"
    predictions.write_text(
        json.dumps(
            {
                "schema_version": "benchmark-predictions-1.0",
                "predictions": [
                    {
                        "sample_id": "s1",
                        "tree_id": "t1",
                        "session_id": "session",
                        "split": "train",
                        "parameter": "height_m",
                        "truth": 10,
                        "estimate": 10,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="omitted 1 attempts"):
        _validate_complete_predictions(predictions, protocol, ("height_m",))


def test_baseline_config_rejects_duplicate_parameters() -> None:
    with pytest.raises(ValueError, match="unique"):
        BaselineConfig((sys.executable,), "baseline", "v1", ("height_m", "height_m"))


def test_external_baseline_is_run_and_evaluated(tmp_path: Path) -> None:
    protocol = _protocol(tmp_path)
    adapter = tmp_path / "adapter.py"
    adapter.write_text(
        """import argparse, json
p = argparse.ArgumentParser()
p.add_argument('--protocol')
p.add_argument('--output-json')
p.add_argument('--baseline-name')
p.add_argument('--baseline-version')
a = p.parse_args()
protocol = json.load(open(a.protocol, encoding='utf-8'))
samples = {item['sample_id']: item for item in protocol['samples']}
rows = []
for assignment in protocol['assignments']:
    sample = samples[assignment['sample_id']]
    rows.append({
        'sample_id': assignment['sample_id'],
        'tree_id': assignment['tree_id'],
        'session_id': sample['session_id'],
        'split': assignment['split'],
        'parameter': 'height_m',
        'truth': 10.0,
        'estimate': 10.5,
        'standard_deviation': 0.4,
        'confidence': 0.8,
    })
json.dump({'schema_version': 'benchmark-predictions-1.0', 'predictions': rows},
          open(a.output_json, 'w', encoding='utf-8'))
""",
        encoding="utf-8",
    )
    config = BaselineConfig(
        (sys.executable, str(adapter)),
        "fixture-baseline",
        "sha256:fixture",
        ("height_m",),
        30,
    )

    result = run_external_baseline(config, protocol, tmp_path / "run")

    assert result.attempted_count == 2
    assert result.failure_count == 0
    assert result.evaluation.output_path.is_file()
    assert (result.output_directory / "baseline-run.json").is_file()
