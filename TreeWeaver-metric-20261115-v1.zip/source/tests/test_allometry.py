import unittest

from treeweaver.forestry.allometry import AllometricEquation, apply_allometry


class AllometryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.equation = AllometricEquation(
            "fixture-only",
            "Quercus testii",
            "test-region",
            "Synthetic fixture, not for field use",
            -2.0,
            2.0,
            1.0,
            0.15,
            "kg",
        )

    def test_propagates_measurement_and_equation_uncertainty(self) -> None:
        result = apply_allometry(
            self.equation,
            species="Quercus testii",
            region="test-region",
            dbh_cm=30,
            dbh_sd_cm=1,
            height_m=12,
            height_sd_m=0.5,
        )
        self.assertGreater(result.value, 0)
        self.assertGreater(result.standard_deviation, 0)

    def test_refuses_species_mismatch(self) -> None:
        with self.assertRaisesRegex(ValueError, "species"):
            apply_allometry(
                self.equation,
                species="Pinus other",
                region="test-region",
                dbh_cm=30,
                dbh_sd_cm=1,
                height_m=12,
                height_sd_m=0.5,
            )


if __name__ == "__main__":
    unittest.main()
