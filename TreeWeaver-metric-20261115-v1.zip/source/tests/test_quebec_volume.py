import tempfile
import unittest
from pathlib import Path

from treeweaver.datasets.quebec_volume import load_quebec_references


class QuebecVolumeTests(unittest.TestCase):
    def test_rejects_nonrelease_row_count(self) -> None:
        header = (
            "Site,Plot,Tree,Species,DBH_ref_cm,H_felled_ref_m,Vop_ref_m3,Vstem_ref_m3,"
            "Vbranch_ref_m3,Vbutt_ref_m3,Vop_allom_m3,DBH_mls_FieldH_cm,H_mls_m,"
            "Vop_mls_m3,Vstem_mls_m3,Vbranch_mls_m3,Vbutt_mls_m3\n"
        )
        row = "DUC,P1,T1,YB,20,15,0.4,0.3,0.1,0.2,0.35,21,14.8,0.42,0.31,0.11,0.21\n"
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "Tree_attributes.csv"
            path.write_text(header + row, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "expected 98"):
                load_quebec_references(path)


if __name__ == "__main__":
    unittest.main()
