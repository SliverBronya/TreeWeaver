import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402


def test_rgb_points_boxes_and_labels_share_the_same_padding():
    source = np.zeros((40, 80, 3), np.uint8)
    source[10:30, 20:60] = 255
    transform = letterbox(Image.fromarray(source), size=80)
    assert transform.pad_y == 20 and transform.pad_x == 0
    mask = source[..., 0] > 0
    rendered = transform.mask(mask)
    np.testing.assert_array_equal(rendered, np.asarray(transform.image)[..., 0] == 255)
    np.testing.assert_array_equal(transform.boxes([[20, 10, 60, 30]]), [[20, 30, 60, 50]])
    np.testing.assert_array_equal(transform.points([[40, 20]]), [[40, 40]])
    assert transform.normalized_pixels().dtype == np.float32


def test_half_resolution_gt_coordinates_are_explicit_and_correct():
    transform = letterbox(Image.new("RGB", (1536, 1024)), size=768)
    low = np.zeros((512, 768), np.uint16)
    low[128:384, 192:576] = 17
    transformed = transform.mask(low, coordinate_size=(768, 512), fill=65535)
    assert transformed.shape == (768, 768)
    assert transformed[0, 0] == 65535
    assert transformed[384, 384] == 17
    np.testing.assert_array_equal(
        transform.boxes([[192, 128, 576, 384]], coordinate_size=(768, 512)),
        transform.boxes([[384, 256, 1152, 768]]),
    )
    with pytest.raises(ValueError, match="declared native"):
        transform.mask(low)


def test_validity_padding_ignored_and_all_instance_ids_remain_discrete():
    transform = letterbox(Image.new("RGB", (30, 60)), size=60)
    masks = np.ones((2, 60, 30), bool)
    valid = transform.mask(masks, fill=False)
    assert valid.shape == (2, 60, 60)
    assert not valid[:, :, :15].any() and valid[:, :, 15:45].all()
    labels = np.tile(np.arange(30, dtype=np.int32), (60, 1))
    output = transform.mask(labels, output_size=30, fill=-1)
    assert set(np.unique(output)) <= set(range(30)) | {-1}


def test_inverse_logits_recovers_native_geometry_and_survives_multiple_queries():
    transform = letterbox(Image.new("RGB", (80, 40)), size=80)
    logits = np.full((2, 80, 80), -10, np.float32)
    logits[:, 30:50, 20:60] = 10
    native = transform.restore_logits(logits)
    assert native.shape == (2, 40, 80)
    assert (native[:, 10:30, 20:60] > 0).all()
    assert (native[:, :10] < 0).all()
    with pytest.raises(ValueError, match="aspect"):
        transform.mask(np.zeros((40, 40), bool), coordinate_size=(40, 40))


def test_ignore_padding_never_silently_wraps_unsigned_ids():
    transform = letterbox(Image.new("RGB", (30, 60)), size=60)
    with pytest.raises(ValueError, match="padding ID"):
        transform.mask(np.zeros((60, 30), np.uint16), fill=-1)
