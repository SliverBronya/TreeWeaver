import json
from pathlib import Path

import numpy as np

from treeweaver.association.root_bundle import separate_root_bundle


def test_writes_auditable_root_assignment(tmp_path: Path) -> None:
    height = np.arange(0.0, 1.01, 0.2)
    points = np.vstack(
        (
            np.column_stack((np.full_like(height, -0.3), np.zeros_like(height), height)),
            np.column_stack((np.full_like(height, 0.3), np.zeros_like(height), height)),
        )
    )
    cloud = tmp_path / "cloud.npz"
    np.savez_compressed(cloud, points=points)
    roots = tmp_path / "roots.json"
    roots.write_text(
        json.dumps(
            {
                "schema_version": "root-anchors-1.0",
                "up": [0, 0, 1],
                "roots": [
                    {"tree_id": 1, "position": [-0.3, 0, 0]},
                    {"tree_id": 2, "position": [0.3, 0, 0]},
                ],
            }
        ),
        encoding="utf-8",
    )

    result = separate_root_bundle(
        cloud,
        roots,
        tmp_path / "output",
        neighbor_count=3,
        maximum_edge_length=0.3,
    )

    assert result.tree_count == 2
    assert result.assigned_point_count == len(points)
    payload = json.loads((result.output_directory / "root-assignment.json").read_text())
    assert payload["schema_version"] == "root-assignment-1.0"
    with np.load(result.output_directory / "root-assignment.npz") as arrays:
        assert set(np.unique(arrays["labels"])) == {1, 2}


def test_candidate_mask_prevents_ground_from_joining_tree_topology(tmp_path: Path) -> None:
    height = np.arange(0.0, 1.01, 0.2)
    left = np.column_stack((np.full_like(height, -0.6), np.zeros_like(height), height))
    right = np.column_stack((np.full_like(height, 0.6), np.zeros_like(height), height))
    ground_x = np.arange(-0.6, 0.61, 0.1)
    ground = np.column_stack((ground_x, np.zeros_like(ground_x), np.zeros_like(ground_x)))
    points = np.vstack((left, right, ground))
    cloud = tmp_path / "bridged-cloud.npz"
    np.savez_compressed(cloud, points=points)
    roots = tmp_path / "bridged-roots.json"
    roots.write_text(
        json.dumps(
            {
                "schema_version": "root-anchors-1.0",
                "up": [0, 0, 1],
                "roots": [
                    {"tree_id": 1, "position": [-0.6, 0, 0]},
                    {"tree_id": 2, "position": [0.6, 0, 0]},
                ],
            }
        ),
        encoding="utf-8",
    )
    candidates = tmp_path / "tree-candidates.npz"
    np.savez_compressed(candidates, candidate_indices=np.arange(len(left) + len(right)))

    result = separate_root_bundle(
        cloud,
        roots,
        tmp_path / "bridged-output",
        candidate_indices_npz=candidates,
        neighbor_count=3,
        maximum_edge_length=0.3,
    )

    with np.load(result.output_directory / "root-assignment.npz") as arrays:
        assert np.all(arrays["labels"][-len(ground) :] == -1)
        assert np.all(arrays["labels"][: len(left)] == 1)
        assert np.all(arrays["labels"][len(left) : len(left) + len(right)] == 2)


def test_estimates_up_from_semantic_ground_when_anchor_has_no_up(tmp_path: Path) -> None:
    height = np.arange(0.0, 1.01, 0.2)
    trunk = np.column_stack((np.zeros_like(height), np.zeros_like(height), height))
    grid_x, grid_y = np.meshgrid(np.linspace(-1, 1, 5), np.linspace(-1, 1, 5))
    ground = np.column_stack((grid_x.ravel(), grid_y.ravel(), np.zeros(grid_x.size)))
    points = np.vstack((trunk, ground))
    cloud = tmp_path / "auto-up-cloud.npz"
    np.savez_compressed(cloud, points=points)
    roots = tmp_path / "auto-up-roots.json"
    roots.write_text(
        json.dumps(
            {
                "schema_version": "root-anchors-1.0",
                "roots": [{"tree_id": 1, "position": [0, 0, 0]}],
            }
        ),
        encoding="utf-8",
    )
    candidates = tmp_path / "auto-up-candidates.npz"
    np.savez_compressed(candidates, candidate_indices=np.arange(len(trunk)))
    ground_file = tmp_path / "ground.npz"
    np.savez_compressed(
        ground_file, ground_indices=np.arange(len(trunk), len(points), dtype=np.int64)
    )

    result = separate_root_bundle(
        cloud,
        roots,
        tmp_path / "auto-up-output",
        candidate_indices_npz=candidates,
        ground_indices_npz=ground_file,
        maximum_edge_length=0.3,
    )

    payload = json.loads((result.output_directory / "root-assignment.json").read_text())
    assert payload["parameters"]["up_source"] == "robust_ground_plane"
    assert abs(payload["parameters"]["up"][2]) > 0.99
