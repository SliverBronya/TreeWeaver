import numpy as np
import pytest

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.association.root_initialization import initialize_root_from_click
from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose


def _camera() -> ProjectionCamera:
    return ProjectionCamera(
        "frame.jpg",
        CameraPose(1, 1, "frame.jpg", np.eye(3), np.zeros(3)),
        CameraIntrinsics(200, 200, 100, 100, 200, 200),
    )


def test_single_click_selects_front_root_surface_not_background() -> None:
    rng = np.random.default_rng(4)
    root_patch = rng.normal([0.0, 0.0, 5.0], [0.035, 0.035, 0.03], size=(60, 3))
    background = rng.normal([0.0, 0.0, 8.0], [0.05, 0.05, 0.03], size=(60, 3))
    result = initialize_root_from_click(
        np.vstack((root_patch, background)),
        _camera(),
        (100, 100),
    )

    assert abs(result.position[2] - 5.0) < 0.08
    assert np.all(result.support_indices < len(root_patch))
    assert result.confidence > 0.2


def test_single_click_rejects_empty_reconstruction_region() -> None:
    with pytest.raises(ValueError, match="insufficient reconstructed support"):
        initialize_root_from_click(
            np.array([[0.0, 0.0, 5.0], [0.1, 0.0, 5.0]]),
            _camera(),
            (180, 180),
        )
