import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from workers.tree_models.auto_stem import (  # noqa: E402
    AutoStemOwnership,
    center_focal_loss,
    decode_centers,
    gaussian_stems,
)


def test_no_confident_center_returns_background_only():
    assert decode_centers(torch.full((1, 1, 32, 32), -20.0)) == []
    model = AutoStemOwnership(8)
    result = model(torch.randn(1, 8, 16, 16), [])
    assert result["logits"].shape == (1, 1, 16, 16)
    assert torch.isfinite(result["logits"]).all()


def test_decoder_finds_two_separated_peaks_without_supplied_count():
    heatmap = torch.full((1, 1, 32, 32), -20.0)
    heatmap[0, 0, 20, 5] = 8
    heatmap[0, 0, 21, 25] = 7
    assert len(decode_centers(heatmap)) == 2


def test_query_permutation_preserves_instance_identity_mapping():
    torch.manual_seed(42)
    features = torch.randn(1, 8, 16, 16)
    model = AutoStemOwnership(8)
    points = [[0.2, 0.8], [0.8, 0.8]]
    first = model(features, points)["logits"]
    second = model(features, points[::-1])["logits"]
    torch.testing.assert_close(first[:, 1:], second[:, 1:].flip(1))
    assert gaussian_stems(points, 16, 16, features.device).shape == (1, 2, 16, 16)


def test_unknown_neighbor_pixels_have_zero_center_gradient():
    logits = torch.zeros(1, 1, 8, 8, requires_grad=True)
    target = torch.zeros_like(logits)
    target[0, 0, 4, 4] = 1
    known = torch.zeros_like(logits, dtype=torch.bool)
    known[:, :, 3:6, 3:6] = True
    center_focal_loss(logits, target, known).backward()
    assert not logits.grad[~known].any()
    assert logits.grad[0, 0, 4, 4] < 0


def test_invalid_depth_is_rgb_fallback_in_automatic_model():
    model = AutoStemOwnership(8)
    features = torch.randn(1, 8, 16, 16)
    points = [[0.3, 0.8]]
    rgb_only = model(features, points)["logits"]
    depth = torch.full((1, 1, 16, 16), float("nan"))
    with_depth = model(features, points, depth=depth, reliability=torch.ones_like(depth))["logits"]
    torch.testing.assert_close(rgb_only, with_depth, rtol=0, atol=0)
