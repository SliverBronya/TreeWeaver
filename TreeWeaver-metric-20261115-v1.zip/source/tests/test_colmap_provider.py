import tempfile
import unittest
from pathlib import Path

import numpy as np

from treeweaver.providers.colmap_text import load_colmap_text_model


class ColmapTextProviderTests(unittest.TestCase):
    def test_reads_poses_points_and_camera_centres(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "images.txt").write_text(
                "# Image list\n1 1 0 0 0 0 0 0 1 frame_a.jpg\n\n2 1 0 0 0 -2 0 0 1 frame_b.jpg\n\n",
                encoding="utf-8",
            )
            (root / "points3D.txt").write_text(
                "# points\n10 1 2 3 255 0 0 0.4 1 0 2 0\n",
                encoding="utf-8",
            )
            reconstruction = load_colmap_text_model(root)
            self.assertEqual(len(reconstruction.poses), 2)
            np.testing.assert_allclose(reconstruction.poses[0].centre_world, [0, 0, 0])
            np.testing.assert_allclose(reconstruction.poses[1].centre_world, [2, 0, 0])
            self.assertEqual(reconstruction.points[0].track_length, 2)
            np.testing.assert_allclose(reconstruction.xyz(max_error_px=1), [[1, 2, 3]])


if __name__ == "__main__":
    unittest.main()
