"""A tiny CPU optimizer continuation verifies actual weights, RNG and Adam state."""

import copy
import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from experiment_resume import RESUME_SCHEMA, validate_resume_checkpoint  # noqa: E402


def test_atomic_checkpoint_matches_uninterrupted_stochastic_training(tmp_path):
    torch.manual_seed(89)
    model = torch.nn.Sequential(torch.nn.Linear(3, 2), torch.nn.Dropout(0.3))
    initial = copy.deepcopy(model.state_dict())
    inputs = torch.arange(18, dtype=torch.float32).reshape(6, 3) / 18
    recipe = {"order": [[0, i, 0] for i in range(6)], "seed": 89}
    names = [name for name, _ in model.named_parameters()]
    rng = torch.get_rng_state()

    def update(net, optimizer, index):
        optimizer.zero_grad(set_to_none=True)
        loss = net(inputs[index]).square().mean()
        loss.backward()
        optimizer.step()
        return {"step": index + 1, "data": 0, "record": index, "query": 0, "loss": loss.item()}

    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003)
    uninterrupted = [update(model, optimizer, i) for i in range(6)]
    expected = copy.deepcopy(model.state_dict())
    model.load_state_dict(initial)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003)
    torch.set_rng_state(rng)
    history = [update(model, optimizer, i) for i in range(3)]
    path = tmp_path / "progress.pth"
    torch.save(
        {
            "resume_schema": RESUME_SCHEMA,
            "immutable_recipe": recipe,
            "arm": "fixture",
            "trainable_names": names,
            "updated_parameters": model.state_dict(),
            "completed_steps": 3,
            "history": history,
            "optimizer": optimizer.state_dict(),
            "cpu_rng": torch.get_rng_state(),
            "cuda_rng": torch.get_rng_state(),
            "initial_evaluation": {"fixture": True},
        },
        path,
    )
    # Consume RNG and allocate a fresh model/optimizer before restoring the saved run.
    restored = torch.nn.Sequential(torch.nn.Linear(3, 2), torch.nn.Dropout(0.3))
    resumed_optimizer = torch.optim.AdamW(restored.parameters(), lr=0.003)
    saved = torch.load(path, map_location="cpu", weights_only=True)
    completed, history = validate_resume_checkpoint(
        saved, recipe, arm="fixture", trainable_names=names
    )
    restored.load_state_dict(saved["updated_parameters"], strict=True)
    resumed_optimizer.load_state_dict(saved["optimizer"])
    torch.set_rng_state(saved["cpu_rng"])
    history.extend(update(restored, resumed_optimizer, i) for i in range(completed, 6))
    assert history == uninterrupted
    for name, tensor in restored.state_dict().items():
        torch.testing.assert_close(tensor, expected[name], rtol=0, atol=0)
    assert all(state["step"].item() == 6 for state in resumed_optimizer.state.values())
