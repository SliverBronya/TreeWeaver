import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from treeweaver.measurement.bundle import measure_semantic_bundle


class MeasurementBundleTests(unittest.TestCase):
    def test_scales_measures_propagates_uncertainty_and_keeps_failures(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            semantic = root / "semantics"
            semantic.mkdir()
            rng = np.random.default_rng(117)

            heights = np.linspace(0.02, 6.0, 90)
            angles = np.linspace(0, 2 * np.pi, 72, endpoint=False)
            z, angle = np.meshgrid(heights, angles, indexing="ij")
            radius = 0.20 - 0.015 * z / 6.0
            trunk = np.column_stack(
                (
                    (radius * np.cos(angle)).ravel(),
                    (radius * np.sin(angle)).ravel(),
                    z.ravel(),
                )
            )
            direction = rng.normal(size=(5000, 3))
            direction /= np.linalg.norm(direction, axis=1, keepdims=True)
            crown = direction * (rng.random(5000) ** (1 / 3))[:, None] * np.array(
                [2.0, 1.5, 2.0]
            ) + [0, 0, 8]
            gx, gy = np.meshgrid(np.linspace(-3, 3, 25), np.linspace(-3, 3, 25))
            ground = np.column_stack((gx.ravel(), gy.ravel(), np.zeros(gx.size)))
            metric_points = np.vstack((trunk, crown, ground))
            arbitrary_points = metric_points / 0.5
            np.savez(root / "dense.npz", points=arbitrary_points)

            trunk_indices = np.arange(len(trunk), dtype=np.int64)
            crown_indices = np.arange(len(trunk), len(trunk) + len(crown), dtype=np.int64)
            ground_indices = np.arange(len(trunk) + len(crown), len(metric_points), dtype=np.int64)
            np.savez_compressed(
                semantic / "semantic-points.npz",
                trunk_indices=trunk_indices,
                trunk_offsets=np.array([0, len(trunk_indices), len(trunk_indices)]),
                crown_indices=crown_indices,
                crown_offsets=np.array([0, len(crown_indices), len(crown_indices)]),
                ambiguous_indices=np.empty(0, dtype=np.int64),
                ambiguous_offsets=np.array([0, 0, 0]),
                unclassified_indices=np.empty(0, dtype=np.int64),
                unclassified_offsets=np.array([0, 0, 0]),
                ground_indices=ground_indices,
            )
            (semantic / "semantics.json").write_text(
                json.dumps(
                    {
                        "schema_version": "semantic-tracks-1.0",
                        "tracks": [
                            {"track_id": 1, "semantic_confidence": 0.9},
                            {"track_id": 2, "semantic_confidence": 0.1},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            result = measure_semantic_bundle(
                root / "dense.npz",
                semantic,
                root / "measurements.json",
                metres_per_unit=0.5,
                scale_standard_deviation=0.01,
            )
            self.assertEqual(result.successful_trees, 1)
            self.assertEqual(result.failed_trees, 1)
            payload = json.loads(result.output_path.read_text(encoding="utf-8"))
            measured = payload["trees"][0]
            self.assertEqual(measured["status"], "ok")
            self.assertGreater(measured["height"]["value"], 9.5)
            self.assertLess(measured["height"]["value"], 10.1)
            self.assertAlmostEqual(measured["dbh"]["value"], 39.3, delta=1.0)
            self.assertGreater(measured["height"]["scale_uncertainty_component"], 0.19)
            self.assertEqual(payload["trees"][1]["status"], "failed")


if __name__ == "__main__":
    unittest.main()
