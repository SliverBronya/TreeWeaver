import numpy as np
import pytest

from treeweaver.visibility.image_complexity import (
    ImageChallengeCue,
    audit_target_view,
)


def _clear_tree() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    instance = np.zeros((30, 24), dtype=bool)
    trunk = np.zeros_like(instance)
    crown = np.zeros_like(instance)
    ground = np.zeros_like(instance)
    trunk[15:27, 10:13] = True
    crown[4:16, 5:19] = True
    instance |= trunk | crown
    ground[27:30] = True
    return instance, trunk, crown, ground


def test_clear_tree_has_no_complex_scene_cues() -> None:
    instance, trunk, crown, ground = _clear_tree()
    region = np.zeros_like(trunk)
    region[20:24, 10:13] = True
    audit = audit_target_view(
        instance, trunk, crown, ground_mask=ground, dbh_region_mask=region, amodal_trunk_mask=trunk
    )
    assert audit.active == ()


def test_overlap_is_reported_separately_for_stem_and_crown() -> None:
    instance, trunk, crown, ground = _clear_tree()
    competitor = np.zeros_like(instance)
    competitor[10:22, 11:18] = True

    audit = audit_target_view(
        instance,
        trunk,
        crown,
        competing_instance_masks=(competitor,),
        ground_mask=ground,
    )

    assert audit.score(ImageChallengeCue.TARGET_OVERLAP) > 0
    assert audit.score(ImageChallengeCue.STEM_OVERLAP) > 0
    assert audit.score(ImageChallengeCue.CROWN_OVERLAP) > 0


def test_crop_fragmentation_and_missing_ground_are_not_silently_accepted() -> None:
    instance, trunk, crown, ground = _clear_tree()
    crown[:3, 5:19] = True
    trunk[27:30, 10:13] = True
    trunk[20:23] = False
    instance |= trunk | crown
    ground[:] = False

    audit = audit_target_view(instance, trunk, crown, ground_mask=ground)

    assert audit.score(ImageChallengeCue.APEX_TRUNCATED) > 0
    assert audit.score(ImageChallengeCue.ROOT_TRUNCATED) > 0
    assert audit.score(ImageChallengeCue.STEM_FRAGMENTED) > 0
    assert audit.score(ImageChallengeCue.ROOT_GROUND_GAP) == 1.0


def test_rejects_part_mask_outside_instance() -> None:
    instance, trunk, crown, _ = _clear_tree()
    trunk[0, 0] = True
    with pytest.raises(ValueError, match="contained"):
        audit_target_view(instance, trunk, crown)


def test_empty_dbh_region_cannot_claim_localization() -> None:
    instance, trunk, crown, ground = _clear_tree()
    with pytest.raises(ValueError, match="intersect"):
        audit_target_view(
            instance,
            trunk,
            crown,
            ground_mask=ground,
            dbh_region_mask=np.zeros_like(trunk),
            amodal_trunk_mask=trunk,
        )


def test_disjoint_visible_masks_can_still_indicate_hidden_dbh() -> None:
    instance, trunk, crown, ground = _clear_tree()
    amodal_trunk = trunk.copy()
    region = np.zeros_like(trunk)
    region[20:24, 10:13] = True
    occluder = np.zeros_like(trunk)
    occluder[20:24, 10] = True
    trunk[20:24, 10] = False
    instance = trunk | crown

    audit = audit_target_view(
        instance,
        trunk,
        crown,
        competing_instance_masks=(occluder,),
        ground_mask=ground,
        dbh_region_mask=region,
        amodal_trunk_mask=amodal_trunk,
        foreground_occluder_mask=occluder,
    )

    assert audit.score(ImageChallengeCue.STEM_OVERLAP) == 0
    assert audit.score(ImageChallengeCue.DBH_REGION_HIDDEN) == pytest.approx(1 / 3)
    assert audit.score(ImageChallengeCue.DBH_OCCLUDER_SUPPORT) == 1.0


def test_amodal_hypothesis_requires_checked_dbh_region() -> None:
    instance, trunk, crown, _ = _clear_tree()
    with pytest.raises(ValueError, match="supplied together"):
        audit_target_view(instance, trunk, crown, amodal_trunk_mask=trunk)
