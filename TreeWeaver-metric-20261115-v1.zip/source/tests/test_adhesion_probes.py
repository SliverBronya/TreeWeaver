from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pytest

torch = pytest.importorskip("torch")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

SPEC = importlib.util.spec_from_file_location(
    "probe_crop_refine", ROOT / "scripts/probe_crop_refine.py"
)
assert SPEC is not None and SPEC.loader is not None
CROP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CROP)

SPEC = importlib.util.spec_from_file_location(
    "strip_refine", ROOT / "workers/tree_models/strip_refine.py"
)
assert SPEC is not None and SPEC.loader is not None
STRIP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(STRIP)

SPEC = importlib.util.spec_from_file_location(
    "probe_width_error", ROOT / "scripts/probe_width_error.py"
)
assert SPEC is not None and SPEC.loader is not None
WIDTH = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WIDTH)


def test_strip_bounds_applies_margins_in_original_pixels():
    box = np.array([100, 100, 200, 400], np.float32)
    left, top, right, bottom = STRIP.strip_bounds(box, 720, 1280, 0.5, 0.05)
    assert (left, top, right, bottom) == (50, 85, 250, 415)


def test_strip_bounds_clips_to_the_frame_and_keeps_a_minimum_window():
    corner = np.array([0, 0, 10, 10], np.float32)
    left, top, right, bottom = STRIP.strip_bounds(corner, 720, 1280, 1.0, 1.0)
    assert (left, top) == (0, 0)
    assert right >= 20 and bottom >= 20
    edge = np.array([1270, 710, 1280, 720], np.float32)
    left, top, right, bottom = STRIP.strip_bounds(edge, 720, 1280, 1.0, 1.0)
    assert right <= 1280 and bottom <= 720
    assert right - left >= 2 and bottom - top >= 2


def test_width_window_widens_so_a_merged_neighbour_is_visible():
    box = np.array([100, 0, 110, 20], np.float32)
    assert WIDTH.row_window(200, box, 0.5) == (95, 115)
    assert WIDTH.row_window(200, box, 0.0) == (100, 110)
    assert WIDTH.row_window(112, np.array([100, 0, 110, 20], np.float32), 0.5) == (95, 112)


def test_width_error_is_relative_and_counts_pixels_next_to_the_box():
    height, width = 20, 60
    target = np.zeros((height, width), bool)
    target[:, 20:26] = True  # 6 px trunk
    predicted = np.zeros((height, width), bool)
    predicted[:, 20:29] = True  # merged with a neighbour up to the +50% window edge
    box = np.array([20, 0, 26, 20], np.float32)
    rows = WIDTH.width_errors(predicted, target, box, height)
    assert rows
    for row in rows:
        assert row["gt_width_px"] == 6
        # The window is the box widened by 50% of its width on each side: 17..29.
        assert row["pred_width_px"] == 9
        assert row["error_px"] == 3
        assert row["relative_error"] == pytest.approx(3 / 6)


def test_width_error_skips_rows_thinner_than_three_pixels():
    height, width = 20, 60
    thin = np.zeros((height, width), bool)
    thin[:, 20:22] = True  # 2 px: cannot define edges
    predicted = np.zeros((height, width), bool)
    predicted[:, 20:26] = True
    box = np.array([20, 0, 22, 20], np.float32)
    assert WIDTH.width_errors(predicted, thin, box, height) == []
