import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from encoder_prompt_focus import (  # noqa:E402
    EncoderPromptFocus,
    PromptCrossAttention,
    sparse_prompt_validity,
)


def test_zero_initialization_and_padding_identity_even_after_training_output():
    module = PromptCrossAttention(8, 6, 4)
    image = torch.randn(2, 3, 4, 8)
    prompt = torch.randn(2, 4, 6)
    valid = torch.ones(2, 4, dtype=torch.bool)
    torch.testing.assert_close(module(image, prompt, valid), image, rtol=0, atol=0)
    module(image, prompt, valid).square().mean().backward()
    assert module.output.weight.grad.abs().sum() > 0
    module.output.weight.data.normal_()
    valid[1] = False
    result = module(image, prompt, valid)
    torch.testing.assert_close(result[1], image[1], rtol=0, atol=0)
    assert torch.isfinite(result).all()


def test_masked_prompt_values_do_not_change_result_and_query_order_is_equivariant():
    module = PromptCrossAttention(8, 6, 4)
    module.output.weight.data.normal_()
    image = torch.randn(2, 3, 4, 8)
    prompt = torch.randn(2, 4, 6)
    valid = torch.tensor([[1, 1, 0, 0], [1, 0, 1, 0]], dtype=torch.bool)
    changed = prompt.clone()
    changed[~valid] = 1000
    torch.testing.assert_close(module(image, prompt, valid), module(image, changed, valid))
    torch.testing.assert_close(
        module(image.flip(0), prompt.flip(0), valid.flip(0)), module(image, prompt, valid).flip(0)
    )


def test_native_point_padding_and_box_order():
    sparse = torch.randn(1, 2, 5, 256)
    points = torch.randn(1, 2, 3, 2)
    labels = torch.tensor([[[1, 0, -1], [1, -1, -1]]])
    valid = sparse_prompt_validity(sparse, points, labels, torch.zeros(1, 2, 4))
    assert valid.tolist() == [[[True, True, False, True, True], [True, False, False, True, True]]]
    padded = sparse_prompt_validity(sparse[:, :, :4], points, labels, None)
    assert not padded[:, :, -1].any()


def test_only_global_blocks_hook_and_context_clear():
    class Block(torch.nn.Module):
        def __init__(self, window):
            super().__init__()
            self.window_size = window
            self.dim_out = 8

        def forward(self, x):
            return x + 1

    backbone = torch.nn.Module()
    backbone.blocks = torch.nn.ModuleList([Block(4), Block(0)])
    focus = EncoderPromptFocus(backbone, prompt_channels=6, rank=4)
    assert list(focus.adapters) == ["1"]
    focus.adapters["1"].output.weight.data.normal_()
    image = torch.randn(2, 3, 4, 8)
    prompt = torch.randn(2, 4, 6)
    focus.set_context(prompt, torch.ones(2, 4, dtype=torch.bool))
    assert not torch.allclose(backbone.blocks[1](image), image + 1)
    focus.clear_context()
    torch.testing.assert_close(backbone.blocks[1](image), image + 1)


def test_single_prompt_needs_null_alternative_for_spatial_focus_and_query_key_gradients():
    torch.manual_seed(83)
    original = PromptCrossAttention(8, 6, 4)
    gated = PromptCrossAttention(8, 6, 4, include_null_token=True)
    original.output.weight.data.normal_(std=0.1)
    gated.load_state_dict(original.state_dict(), strict=True)
    image = torch.randn(1, 3, 4, 8)
    prompt = torch.randn(1, 1, 6)
    valid = torch.ones(1, 1, dtype=torch.bool)
    original_delta = original(image, prompt, valid) - image
    torch.testing.assert_close(original_delta, original_delta[:, :1, :1].expand_as(image))
    original_delta.square().sum().backward()
    assert original.query.weight.grad.abs().sum() == 0
    assert original.key.weight.grad.abs().sum() == 0
    gated_delta = gated(image, prompt, valid) - image
    assert gated_delta.std(dim=(1, 2)).sum() > 0
    gated_delta.square().sum().backward()
    assert gated.query.weight.grad.abs().sum() > 0
    assert gated.key.weight.grad.abs().sum() > 0


def test_null_alternative_preserves_zero_start_and_all_padding_identity():
    module = PromptCrossAttention(8, 6, 4, include_null_token=True)
    image = torch.randn(2, 3, 4, 8)
    prompt = torch.randn(2, 2, 6)
    valid = torch.tensor([[True, False], [False, False]])
    torch.testing.assert_close(module(image, prompt, valid), image, rtol=0, atol=0)
    module.output.weight.data.normal_()
    torch.testing.assert_close(module(image, prompt, valid)[1], image[1], rtol=0, atol=0)
    altered = prompt.clone()
    altered[~valid] = 1000
    torch.testing.assert_close(module(image, prompt, valid), module(image, altered, valid))


@pytest.mark.parametrize("include_null_token", [False, True])
def test_padding_nan_cannot_poison_spatial_features_or_parameter_gradients(include_null_token):
    module = PromptCrossAttention(8, 6, 4, include_null_token=include_null_token)
    module.output.weight.data.normal_(std=0.1)
    image = torch.randn(2, 3, 4, 8)
    prompt = torch.randn(2, 3, 6)
    valid = torch.tensor([[True, False, False], [False, False, False]])
    expected = module(image, prompt, valid)
    prompt[~valid] = float("nan")
    actual = module(image, prompt, valid)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    actual.square().mean().backward()
    assert all(torch.isfinite(p.grad).all() for p in module.parameters() if p.grad is not None)
