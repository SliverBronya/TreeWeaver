import json
from pathlib import Path

import numpy as np

from treeweaver.semantics.root_refinement import refine_semantic_bundle_by_roots


def test_splits_merged_semantics_and_excludes_shared_points(tmp_path: Path) -> None:
    semantics = tmp_path / "semantics"
    assignment = tmp_path / "assignment"
    semantics.mkdir()
    assignment.mkdir()
    (semantics / "semantics.json").write_text(
        json.dumps(
            {
                "schema_version": "semantic-tracks-1.0",
                "ground_confidence": 0.9,
                "ground_contributing_views": 2,
                "trunk_view_sections": [
                    {"track_id": 1, "view_id": "a.jpg", "reliability": 0.8}
                ],
                "tracks": [{"track_id": 1, "semantic_confidence": 0.8}],
            }
        ),
        encoding="utf-8",
    )
    np.savez_compressed(
        semantics / "semantic-points.npz",
        trunk_indices=np.array([0, 1, 2, 3]),
        trunk_offsets=np.array([0, 4]),
        trunk_reliability=np.array([0.9, 0.8, 0.85, 0.7]),
        crown_indices=np.array([4, 5, 6]),
        crown_offsets=np.array([0, 3]),
        crown_reliability=np.array([0.8, 0.75, 0.5]),
        ambiguous_indices=np.empty(0, dtype=np.int64),
        ambiguous_offsets=np.array([0, 0]),
        unclassified_indices=np.empty(0, dtype=np.int64),
        unclassified_offsets=np.array([0, 0]),
        ground_indices=np.array([7, 8]),
        ground_reliability=np.array([0.9, 0.9]),
        trunk_view_indices=np.array([0, 1, 2, 3]),
        trunk_view_offsets=np.array([0, 4]),
    )
    (assignment / "root-assignment.json").write_text(
        json.dumps(
            {
                "schema_version": "root-assignment-1.0",
                "trees": [{"tree_id": 10}, {"tree_id": 20}],
            }
        ),
        encoding="utf-8",
    )
    np.savez_compressed(
        assignment / "root-assignment.npz",
        labels=np.array([10, 10, 20, 20, 10, 20, 0, -1, -1]),
        confidence=np.array([0.9, 0.8, 0.9, 0.8, 0.7, 0.7, 0.1, 0.0, 0.0]),
    )

    result = refine_semantic_bundle_by_roots(
        semantics, assignment, tmp_path / "refined"
    )

    assert result.tree_count == 2
    assert result.excluded_ambiguous_points == 1
    metadata = json.loads((result.output_directory / "semantics.json").read_text())
    assert [item["track_id"] for item in metadata["tracks"]] == [10, 20]
    with np.load(result.output_directory / "semantic-points.npz") as arrays:
        assert arrays["trunk_offsets"].tolist() == [0, 2, 4]
        assert arrays["crown_offsets"].tolist() == [0, 1, 2]
        assert arrays["root_ambiguous_indices"].tolist() == [6]
        assert arrays["trunk_view_offsets"].tolist() == [0, 2, 4]
