import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from metric_camera import (  # noqa: E402
    depth_from_world_positions,
    unproject_camera_z,
    world_to_cv_from_blender,
)


def test_depth_is_metric_camera_z_and_range_not_display_gray():
    matrix = world_to_cv_from_blender(np.eye(4))
    points = np.array([[[0, 0, -5], [3, 0, -4]], [[0, 0, 0], [0, 0, -2]]], float)
    result = depth_from_world_positions(points, matrix, [[True, True], [False, True]])
    np.testing.assert_allclose(result["depth_z_m"][0], [5, 4])
    np.testing.assert_allclose(result["depth_ray_m"][0], [5, 5])
    assert np.isnan(result["depth_z_m"][1, 0])
    assert result["depth_z_m"].dtype == np.float32


def test_units_and_camera_translation_are_applied_once():
    pose = np.eye(4)
    pose[:3, 3] = [0, 0, 10]
    matrix = world_to_cv_from_blender(pose)
    result = depth_from_world_positions(
        np.array([[[0, 0, 0]]]), matrix, [[True]], meters_per_unit=0.1
    )
    assert result["depth_z_m"][0, 0] == 1
    assert result["valid"][0, 0]  # A world-origin point can be a valid surface.


def test_unprojection_roundtrip_uses_pixel_centres_and_preserves_holes():
    K = np.array([[100, 0, 1], [0, 100, 1], [0, 0, 1]], float)
    depth = np.array([[5, 4], [np.nan, 2]], np.float32)
    xyz, good = unproject_camera_z(depth, K)
    projected = xyz @ K.T
    uv = projected[good, :2] / projected[good, 2:]
    np.testing.assert_allclose(uv, [[0.5, 0.5], [1.5, 0.5], [1.5, 1.5]], atol=1e-6)
    np.testing.assert_allclose(xyz[..., 2][good], depth[good])
    assert np.isnan(xyz[1, 0]).all()


def test_sky_nonfinite_behind_and_scaled_camera_are_rejected():
    p = np.array([[[0, 0, -5], [0, 0, 5], [np.nan, 0, 1]]])
    d = depth_from_world_positions(p, world_to_cv_from_blender(np.eye(4)), [[False, True, True]])
    assert not d["valid"].any()
    pose = np.eye(4)
    pose[0, 0] = 2
    with pytest.raises(ValueError, match="rigid"):
        world_to_cv_from_blender(pose)
    with pytest.raises(ValueError, match="rigid"):
        depth_from_world_positions(p, pose, [[True, True, True]])


def test_clip_planes_use_optical_depth_and_zero_is_not_a_hit():
    points = np.array([[[3, 0, 4], [0, 0, 0]]], float)
    result = depth_from_world_positions(points, np.eye(4), [[True, True]], clip_m=(0, 4.5))
    assert result["depth_z_m"][0, 0] == 4
    assert result["depth_ray_m"][0, 0] == 5
    assert not result["valid"][0, 1]
