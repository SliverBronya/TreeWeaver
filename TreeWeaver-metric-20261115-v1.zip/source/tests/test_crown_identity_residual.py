import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from crown_identity_residual import CrownIdentityResidual, residual_identity_loss  # noqa: E402
from whole_tree_objective import competitive_decode  # noqa: E402


def inputs(count=2):
    torch.manual_seed(4)
    features = torch.randn(count, 8, 4, 4)
    low = torch.randn(count, 4, 4)
    native = torch.nn.functional.interpolate(
        low[:, None], (8, 8), mode="bilinear", align_corners=False
    )[:, 0]
    return features, low, native, torch.rand(count, 2), torch.ones(count, dtype=torch.bool)


def test_zero_initialization_exactly_preserves_existing_segmentation():
    args = inputs()
    for anchor in (False, True):
        model = CrownIdentityResidual(channels=8, anchor=anchor)
        scores, correction = model(*args)
        assert torch.equal(scores, args[2]) and not correction.any()
        owners = torch.cat([scores[:1] * 0, scores])
        assert torch.equal(competitive_decode(args[2], owners), competitive_decode(args[2]))


def test_learned_correction_is_permutation_equivariant_and_cannot_remove_foreground():
    args = inputs(3)
    model = CrownIdentityResidual(channels=8)
    torch.nn.init.normal_(model.refine[-1].weight)
    scores, correction = model(*args)
    active = args[2] > 0
    assert not correction[~active].any()
    assert not correction[:, active.sum(0) < 2].any()
    permutation = torch.tensor([2, 0, 1])
    swapped, _ = model(*(value[permutation] for value in args))
    torch.testing.assert_close(swapped, scores[permutation])
    prediction = competitive_decode(args[2], torch.cat([scores[:1] * 0, scores]))
    assert torch.equal(prediction.any(0), active.any(0))


def test_unknown_pixels_and_inactive_correct_queries_have_no_identity_gradient():
    prior = torch.ones(2, 2, 3)
    target = torch.zeros_like(prior, dtype=torch.bool)
    target[0] = True
    valid = torch.ones_like(target)
    valid[:, 0, 0] = False
    prior[0, 0, 1] = -1  # Correct query is inactive; impossible to recover here.
    scores = prior.clone()
    scores[:, 0, 0] += 0.3
    scores.requires_grad_(True)
    loss, info = residual_identity_loss(
        scores, prior, target, valid, target & False, valid, scores - prior
    )
    loss.backward()
    assert not scores.grad[:, 0, :2].any()
    assert info["supervised_pixels"] == 4


def test_single_tree_is_unchanged_even_after_training():
    args = inputs(1)
    model = CrownIdentityResidual(channels=8)
    torch.nn.init.normal_(model.refine[-1].weight)
    scores, correction = model(*args)
    assert torch.equal(scores, args[2]) and not correction.any()
