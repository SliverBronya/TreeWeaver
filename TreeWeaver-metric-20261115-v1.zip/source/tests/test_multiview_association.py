import unittest

import cv2
import numpy as np

from treeweaver.association.multiview import (
    InstanceObservation,
    ProjectionCamera,
    associate_instances,
    project_visible_support,
)
from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose


def _camera(name: str, translation_x: float = 0.0) -> ProjectionCamera:
    intrinsics = CameraIntrinsics(300, 300, 200, 150, 400, 300)
    pose = CameraPose(
        image_id=1,
        camera_id=1,
        image_name=name,
        rotation_world_to_camera=np.eye(3),
        translation_world_to_camera=np.array([translation_x, 0.0, 0.0]),
    )
    return ProjectionCamera(name, pose, intrinsics)


def _disc_mask(camera: ProjectionCamera, centre_world: np.ndarray, radius: int = 24) -> np.ndarray:
    point = (
        camera.pose.rotation_world_to_camera @ centre_world
        + camera.pose.translation_world_to_camera
    )
    u = round(camera.intrinsics.fx * point[0] / point[2] + camera.intrinsics.cx)
    v = round(camera.intrinsics.fy * point[1] / point[2] + camera.intrinsics.cy)
    mask = np.zeros((camera.intrinsics.height, camera.intrinsics.width), dtype=np.uint8)
    cv2.circle(mask, (u, v), radius, 1, -1)
    return mask.astype(bool)


class MultiviewAssociationTests(unittest.TestCase):
    def test_z_buffer_excludes_occluded_surface(self) -> None:
        camera = _camera("view.jpg")
        points = np.array([[0, 0, 3.0], [0, 0, 5.0], [0.1, 0, 5.0]])
        observation = InstanceObservation("view.jpg", 1, np.ones((300, 400), dtype=bool))
        support = project_visible_support(points, camera, observation)
        self.assertIn(0, support.point_indices)
        self.assertNotIn(1, support.point_indices)
        self.assertIn(2, support.point_indices)

    def test_local_ids_are_linked_by_shared_3d_support(self) -> None:
        rng = np.random.default_rng(31)
        tree_left = rng.normal(scale=[0.12, 0.25, 0.08], size=(500, 3)) + [-1, 0, 5]
        tree_right = rng.normal(scale=[0.12, 0.25, 0.08], size=(500, 3)) + [1, 0, 5]
        points = np.vstack((tree_left, tree_right))
        camera_a = _camera("a.jpg", 0.0)
        camera_b = _camera("b.jpg", -0.35)
        observations = (
            InstanceObservation("a.jpg", 10, _disc_mask(camera_a, np.array([-1, 0, 5]))),
            InstanceObservation("a.jpg", 20, _disc_mask(camera_a, np.array([1, 0, 5]))),
            InstanceObservation("b.jpg", 2, _disc_mask(camera_b, np.array([-1, 0, 5]))),
            InstanceObservation("b.jpg", 1, _disc_mask(camera_b, np.array([1, 0, 5]))),
        )
        tracks = associate_instances(
            points,
            (camera_a, camera_b),
            observations,
            minimum_support_points=30,
            minimum_jaccard=0.10,
        )
        self.assertEqual(len(tracks), 2)
        self.assertTrue(all(len(track.members) == 2 for track in tracks))
        member_sets = [set(track.members) for track in tracks]
        self.assertIn({("a.jpg", 10), ("b.jpg", 2)}, member_sets)
        self.assertIn({("a.jpg", 20), ("b.jpg", 1)}, member_sets)
        median_x = sorted(float(np.median(points[track.point_indices, 0])) for track in tracks)
        self.assertLess(median_x[0], -0.8)
        self.assertGreater(median_x[1], 0.8)


if __name__ == "__main__":
    unittest.main()
