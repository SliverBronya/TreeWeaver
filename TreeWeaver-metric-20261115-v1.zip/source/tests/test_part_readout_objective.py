import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from part_readout_objective import part_loss  # noqa: E402


def test_weighted_loss_increases_thin_positive_gradient_relative_to_background():
    target = torch.zeros(1, 2, 16, 16)
    target[:, :, :, 8] = 1
    valid = torch.ones_like(target, dtype=torch.bool)
    ratios = []
    for weighted in (False, True):
        logits = torch.zeros_like(target, requires_grad=True)
        part_loss(logits, target, valid, foreground_weighted=weighted).backward()
        ratios.append(
            float(
                logits.grad[target.bool()].abs().mean() / logits.grad[~target.bool()].abs().mean()
            )
        )
    assert ratios[1] > ratios[0]


def test_ignored_query_and_unknown_pixels_have_zero_gradient():
    logits = torch.zeros(1, 2, 8, 8, requires_grad=True)
    target = torch.ones_like(logits)
    valid = torch.ones_like(logits, dtype=torch.bool)
    valid[:, 1] = False
    valid[:, 0, :2] = False
    part_loss(logits, target, valid, foreground_weighted=True).backward()
    assert torch.isfinite(logits.grad).all()
    assert logits.grad[~valid].abs().sum() == 0
    assert logits.grad[valid].abs().sum() > 0


def test_no_known_pixels_or_empty_stem_produces_finite_loss():
    logits = torch.zeros(1, 2, 8, 8, requires_grad=True)
    target = torch.zeros_like(logits)
    empty = torch.zeros_like(logits, dtype=torch.bool)
    loss = part_loss(logits, target, empty, foreground_weighted=True)
    loss.backward()
    assert loss == 0 and logits.grad.abs().sum() == 0
    assert torch.isfinite(part_loss(logits, target, ~empty, foreground_weighted=True))


def test_query_permutation_preserves_loss():
    torch.manual_seed(21)
    logits = torch.randn(2, 3, 8, 8)
    target = torch.rand_like(logits) > 0.7
    valid = torch.rand_like(logits) > 0.1
    torch.testing.assert_close(
        part_loss(logits, target, valid, foreground_weighted=True),
        part_loss(logits.flip(1), target.flip(1), valid.flip(1), foreground_weighted=True),
    )
