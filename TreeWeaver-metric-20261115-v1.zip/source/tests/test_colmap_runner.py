import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from treeweaver.providers.colmap_runner import ColmapConfig, ColmapRunner


def _capture(root: Path) -> Path:
    frames = root / "frames"
    frames.mkdir()
    camera = {"fx": 800, "fy": 800, "cx": 320, "cy": 240, "width": 640, "height": 480}
    records = []
    for index in range(2):
        name = f"{index}.jpg"
        (frames / name).write_bytes(b"image")
        records.append(
            {
                "frame_id": str(index),
                "timestamp_ns": index,
                "image_path": f"frames/{name}",
                "intrinsics": camera,
            }
        )
    payload = {
        "schema_version": "1.0",
        "session_id": "runner-test",
        "device": {
            "device_id": "test",
            "has_imu": False,
            "has_arcore": False,
            "has_metric_depth": False,
            "depth_source": "none",
        },
        "frames": records,
        "scale_anchors": [{"kind": "marker", "metric_length_m": 1, "confidence": 1}],
    }
    manifest = root / "capture.json"
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    return manifest


class ColmapRunnerTests(unittest.TestCase):
    def test_missing_executable_fails_before_creating_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = _capture(root)
            output = root / "run"
            runner = ColmapRunner(ColmapConfig(executable="certainly-not-colmap"))
            with self.assertRaisesRegex(FileNotFoundError, "COLMAP executable not found"):
                runner.reconstruct(manifest, output)
            self.assertFalse(output.exists())

    def test_commands_are_argument_lists_and_run_log_is_preserved(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = _capture(root)
            output = root / "run with spaces"

            def fake_run(command, **kwargs):
                if command[1] == "mapper":
                    sparse = Path(command[command.index("--output_path") + 1]) / "0"
                    sparse.mkdir()
                    (sparse / "cameras.bin").write_bytes(b"model")
                elif command[1] == "model_converter":
                    text = Path(command[command.index("--output_path") + 1])
                    (text / "images.txt").write_text(
                        "1 1 0 0 0 0 0 0 1 0.jpg\n\n2 1 0 0 0 -1 0 0 1 1.jpg\n\n",
                        encoding="utf-8",
                    )
                    (text / "points3D.txt").write_text(
                        "1 0 0 1 1 2 3 0.5 1 0 2 0\n", encoding="utf-8"
                    )
                return subprocess.CompletedProcess(command, 0, "ok", "")

            runner = ColmapRunner(ColmapConfig(executable="fake-colmap", use_gpu=False))
            with (
                patch.object(runner, "_executable", return_value="C:/tools/colmap.exe"),
                patch(
                    "treeweaver.providers.colmap_runner.subprocess.run", side_effect=fake_run
                ) as run,
            ):
                reconstruction = runner.reconstruct(manifest, output)

            self.assertEqual(len(reconstruction.poses), 2)
            self.assertEqual(run.call_count, 4)
            self.assertTrue(all(call.kwargs["shell"] is False for call in run.call_args_list))
            log = json.loads((output / "run-log.json").read_text(encoding="utf-8"))
            self.assertEqual(len(log["commands"]), 4)
            self.assertIn("800.0,800.0,320.0,240.0", log["commands"][0]["command"])
            self.assertIn("--FeatureExtraction.use_gpu", log["commands"][0]["command"])
            self.assertIn("--FeatureMatching.use_gpu", log["commands"][1]["command"])


if __name__ == "__main__":
    unittest.main()
