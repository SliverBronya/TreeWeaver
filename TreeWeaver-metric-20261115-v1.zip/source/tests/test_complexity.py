import pytest

from treeweaver.evaluation.complexity import ComplexityAnnotation, SceneChallenge


def test_complexity_strata_preserve_interacting_challenges() -> None:
    annotation = ComplexityAnnotation(
        {
            SceneChallenge.STEM_OCCLUSION: 2,
            SceneChallenge.CROWN_OVERLAP: 2,
            SceneChallenge.UNDERSTORY_CLUTTER: 1,
        }
    )

    assert annotation.stratum == "moderate"
    assert annotation.active_challenge_count == 3
    assert 0 < annotation.score < 1
    assert SceneChallenge.CROWN_OVERLAP in annotation.active


def test_severe_single_failure_mode_is_not_averaged_away() -> None:
    annotation = ComplexityAnnotation({SceneChallenge.TRUNCATED_ROOT_OR_APEX: 3})
    assert annotation.stratum == "severe"


def test_rejects_invalid_severity() -> None:
    with pytest.raises(ValueError, match="0 to 3"):
        ComplexityAnnotation({SceneChallenge.WIND_MOTION: 4})
