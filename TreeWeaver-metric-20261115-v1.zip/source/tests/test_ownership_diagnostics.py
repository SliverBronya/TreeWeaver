import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from ownership_diagnostics import error_partition, oracle_active_decode  # noqa: E402


def cases():
    truth = np.zeros((2, 1, 5), bool)
    truth[0, 0, :4] = True
    truth[1, 0, 4] = True
    active = np.zeros_like(truth)
    active[0, 0, [0, 3]] = True
    active[1, 0, [2, 3, 4]] = True
    decoded = np.zeros_like(truth)
    decoded[0, 0, 0] = True
    decoded[1, 0, [2, 3, 4]] = True
    return active, decoded, truth, np.ones((1, 5), bool)


def test_missing_coverage_and_missing_correct_query_cannot_be_fixed_by_ownership():
    active, decoded, truth, valid = cases()
    row = error_partition(active, decoded, truth, valid)[0]
    assert row == {
        "target_pixels": 4,
        "correct": 1,
        "no_query_predicts_foreground": 1,
        "only_foreign_queries_active": 1,
        "recoverable_assignment_error": 1,
    }
    oracle = oracle_active_decode(active, decoded, truth, valid)
    assert (oracle & truth).sum() == 3  # Only column 3 can be corrected.
    np.testing.assert_array_equal(oracle.any(0), decoded.any(0))
    assert not (oracle & ~active).any()


def test_unknown_areas_do_not_become_either_success_or_failure():
    active, decoded, truth, valid = cases()
    valid[0, 3] = False
    assert error_partition(active, decoded, truth, valid)[0]["recoverable_assignment_error"] == 0
    np.testing.assert_array_equal(oracle_active_decode(active, decoded, truth, valid), decoded)


def test_invalid_decoder_cannot_claim_union_preserving_assignment():
    active, decoded, truth, valid = cases()
    expanded = decoded.copy()
    expanded[0, 0, 1] = True
    with pytest.raises(ValueError, match="active query"):
        error_partition(active, expanded, truth, valid)
    shrunken = decoded.copy()
    shrunken[:, :, 3] = False
    with pytest.raises(ValueError, match="union"):
        error_partition(active, shrunken, truth, valid)


def test_permuting_queries_preserves_the_diagnostic():
    active, decoded, truth, valid = cases()
    before = error_partition(active, decoded, truth, valid)
    assert error_partition(active[::-1], decoded[::-1], truth[::-1], valid) == before[::-1]
