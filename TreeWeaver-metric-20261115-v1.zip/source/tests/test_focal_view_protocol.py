import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from focal_view_protocol import focal_viewport  # noqa:E402


@pytest.mark.parametrize("location", [(250, 600), (10, 30), (500, 900)])
def test_target_stays_complete_and_viewport_stays_inside_image(location):
    mask = np.zeros((1280, 720), bool)
    x, y = location
    mask[y : y + 250, x : x + 80] = 1
    result = focal_viewport(mask)
    x0, y0, x1, y1 = result["roi_xyxy"]
    assert 0 <= x0 < x1 <= 720 and 0 <= y0 < y1 <= 1280
    assert mask[y0:y1, x0:x1].sum() == mask.sum()
    assert (x1 - x0) * 16 == (y1 - y0) * 9
    assert 0.60 < result["height_fraction"] <= 0.65


def test_wide_tree_is_marked_infeasible_for_tall_framing_without_clipping():
    mask = np.zeros((1280, 720), bool)
    mask[400:600, 60:660] = 1
    result = focal_viewport(mask)
    assert result["width_limited"] and result["height_fraction"] < 0.3
    assert not result["focal_truncated"] and not result["mask_resampled"]


def test_translation_uses_same_roi_for_visible_and_complete_masks():
    complete = np.zeros((1280, 720), bool)
    complete[400:800, 280:400] = 1
    visible = complete.copy()
    visible[500:600] = 0
    x0, y0, x1, y1 = focal_viewport(complete)["roi_xyxy"]
    assert (complete[y0:y1, x0:x1] & ~visible[y0:y1, x0:x1]).sum() == (complete & ~visible).sum()


def test_source_boundary_contact_cannot_be_mistaken_for_full_tree_ground_truth():
    mask = np.zeros((1280, 720), bool)
    mask[:400, 280:400] = True
    with pytest.raises(ValueError, match="source target touches"):
        focal_viewport(mask)
    stress = focal_viewport(mask, allow_source_boundary=True)
    assert stress["source_boundary_contact"] and stress["focal_truncated"]


@pytest.mark.parametrize("aspect", [(0, 16), (9, -1), (9.0, 16), (9,)])
def test_invalid_aspect_cannot_create_outside_or_divide_by_zero_crop(aspect):
    mask = np.zeros((1280, 720), bool)
    mask[200:500, 250:400] = True
    with pytest.raises(ValueError, match="aspect"):
        focal_viewport(mask, aspect=aspect)
