"""Tests for differentiable curve consistency."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

torch = pytest.importorskip("torch")

from curve_consistency import (  # noqa: E402
    absolute_crown_curve_loss,
    aligned_width_profile,
    band_observed,
    band_rows,
    curve_profile_loss,
    soft_width_profile,
)


def test_band_rows_are_bottom_up():
    rows = band_rows(12, 4)
    assert rows == [10, 7, 4, 1]


def test_band_observed_ignores_empty_bands():
    mask = torch.zeros(1, 1, 12, 8)
    mask[0, 0, 9:12, 2:6] = 1
    observed = band_observed(mask, 4)
    assert observed.shape == (1, 4)
    assert observed[0, 0].item() is True
    assert observed[0, -1].item() is False


def test_profile_is_one_at_peak():
    mask = torch.zeros(1, 1, 12, 8)
    mask[0, 0, :, 2:6] = 20
    profile = soft_width_profile(mask, 4)
    assert profile.shape == (1, 4)
    assert torch.allclose(profile, torch.ones_like(profile), atol=1e-5)


def test_curve_loss_zero_when_mask_matches_curve():
    mask = torch.full((1, 1, 12, 8), 20.0)
    curve = torch.ones(1, 1, 4)
    observed = torch.ones(1, 1, 4, dtype=torch.bool)
    loss = curve_profile_loss(mask, curve, observed)
    assert loss.item() < 1e-5


def test_narrow_mask_has_higher_loss_and_gradients():
    wide = torch.full((1, 1, 12, 8), 20.0, requires_grad=True)
    narrow = torch.zeros(1, 1, 12, 8, requires_grad=True)
    narrow.data[:, :, :6, :4] = 20.0
    narrow.data[:, :, 6:, :2] = 20.0
    curve = torch.ones(1, 1, 4)
    observed = torch.ones(1, 1, 4, dtype=torch.bool)
    wide_loss = curve_profile_loss(wide, curve, observed)
    narrow_loss = curve_profile_loss(narrow, curve, observed)
    assert narrow_loss.item() > wide_loss.item()
    narrow_loss.backward()
    assert narrow.grad is not None
    assert torch.isfinite(narrow.grad).all()


def test_unobserved_bands_do_not_contribute():
    mask = torch.full((1, 1, 12, 8), 20.0)
    curve = torch.ones(1, 1, 4)
    observed = torch.tensor([[[True, True, False, False]]])
    masked = curve_profile_loss(mask, curve, observed)
    all_observed = curve_profile_loss(mask, curve, torch.ones_like(observed))
    assert masked.item() <= all_observed.item()


def test_every_prompted_tree_contributes_gradient():
    logits = torch.zeros(1, 3, 12, 8, requires_grad=True)
    target = torch.tensor([[[0.2, 0.4, 0.8, 1.0]]]).expand(1, 3, 4)
    loss = curve_profile_loss(logits, target, torch.ones_like(target, dtype=torch.bool))
    loss.backward()
    assert (logits.grad.abs().flatten(2).sum(-1) > 0).all()


def test_instance_order_does_not_change_loss():
    torch.manual_seed(3)
    logits = torch.randn(2, 3, 12, 8)
    curve = torch.rand(2, 3, 4)
    observed = torch.ones_like(curve, dtype=torch.bool)
    before = curve_profile_loss(logits, curve, observed)
    after = curve_profile_loss(logits.flip(1), curve.flip(1), observed.flip(1))
    assert torch.allclose(before, after)


def test_reference_rows_and_gapped_span_match_dataset_curve():
    import numpy as np
    from synthtree_instances import crown_curve

    reference = torch.zeros(1, 2, 36, 20)
    # Two translated silhouettes with holes: occupied pixel counts differ
    # from the first-to-last span used by the data loader.
    for instance, top in enumerate((3, 18)):
        for y in range(top, top + 12):
            half_width = 2 + (y - top) // 3
            reference[0, instance, y, 9 - half_width] = 1
            reference[0, instance, y, 9 + half_width] = 1
    logits = (reference * 2 - 1) * 30
    profile = aligned_width_profile(logits, reference, 4)
    expected = np.stack([crown_curve(mask.numpy(), 4)[0] for mask in reference[0]])
    assert np.allclose(profile[0].numpy(), expected, atol=1e-5)


def test_unobserved_tree_has_zero_gradient():
    logits = torch.zeros(1, 2, 12, 8, requires_grad=True)
    curve = torch.rand(1, 2, 4)
    observed = torch.ones_like(curve, dtype=torch.bool)
    observed[:, 1] = False
    curve_profile_loss(logits, curve, observed).backward()
    assert logits.grad[:, 0].abs().sum() > 0
    assert logits.grad[:, 1].abs().sum() == 0


def test_rejects_silently_dropped_instances():
    with pytest.raises(ValueError, match="matching all mask instances"):
        curve_profile_loss(
            torch.zeros(1, 3, 12, 8), torch.ones(1, 1, 4), torch.ones(1, 1, 4, dtype=torch.bool)
        )


def test_absolute_envelope_penalizes_uniform_shrinkage_and_translation():
    reference = torch.zeros(1, 2, 24, 32)
    reference[:, :, 4:20, 6:26] = 1
    perfect = (reference * 2 - 1) * 25
    smaller = torch.full_like(reference, -25)
    smaller[:, :, 4:20, 11:21] = 25
    shifted = torch.full_like(reference, -25)
    shifted[:, :, 4:20, 9:29] = 25
    assert absolute_crown_curve_loss(perfect, reference).item() < 1e-8
    assert absolute_crown_curve_loss(smaller, reference).item() > 0.02
    assert absolute_crown_curve_loss(shifted, reference).item() > 0.005
    # The legacy shape-only loss cannot detect uniform horizontal shrinkage.
    old_profile = aligned_width_profile(smaller, reference, 4)
    assert torch.allclose(old_profile, torch.ones_like(old_profile), atol=1e-5)


def test_absolute_envelope_preserves_leaf_gaps_and_query_permutation():
    reference = torch.zeros(1, 2, 24, 32)
    reference[0, 0, 3:15, 3:17] = 1
    reference[0, 1, 8:23, 12:28] = 1
    gapped = reference.clone()
    gapped[:, :, :, 14:16] = 0
    logits = ((gapped * 2 - 1) * 25).requires_grad_()
    loss = absolute_crown_curve_loss(logits, reference)
    assert loss.item() < 1e-8
    torch.testing.assert_close(loss, absolute_crown_curve_loss(logits.flip(1), reference.flip(1)))


def test_absolute_envelope_ignores_unknown_rows_and_empty_crowns():
    reference = torch.zeros(1, 3, 24, 32)
    reference[:, :2, 4:20, 6:26] = 1
    valid = torch.ones_like(reference, dtype=torch.bool)
    valid[:, 1, :, 0] = False
    logits = torch.zeros_like(reference, requires_grad=True)
    loss = absolute_crown_curve_loss(logits, reference, valid_pixels=valid)
    loss.backward()
    assert torch.isfinite(logits.grad).all()
    assert logits.grad[:, 0].abs().sum() > 0
    assert logits.grad[:, 1:].abs().sum() == 0
    empty_logits = torch.zeros_like(reference, requires_grad=True)
    empty_loss = absolute_crown_curve_loss(empty_logits, torch.zeros_like(reference))
    empty_loss.backward()
    assert empty_loss.item() == 0
    assert empty_logits.grad.abs().sum() == 0


def test_absolute_envelope_empty_prediction_is_penalized():
    reference = torch.zeros(1, 1, 24, 32)
    reference[:, :, 4:20, 6:26] = 1
    assert absolute_crown_curve_loss(torch.full_like(reference, -25), reference) > 0.5


def test_absolute_envelope_rejects_mismatched_instance_validity():
    with pytest.raises(ValueError, match="every crown instance"):
        absolute_crown_curve_loss(
            torch.zeros(1, 2, 12, 16),
            torch.ones(1, 2, 12, 16),
            valid_pixels=torch.ones(1, 1, 12, 16),
        )
