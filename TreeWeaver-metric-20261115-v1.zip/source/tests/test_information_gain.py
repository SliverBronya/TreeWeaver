import unittest

import numpy as np

from treeweaver.domain.models import (
    CameraIntrinsics,
    FrameObservation,
    Parameter,
    ParameterEstimate,
)
from treeweaver.guidance.factor_view import recommend_factor_view
from treeweaver.guidance.information_gain import CandidateView, select_next_best_view


class InformationGainTests(unittest.TestCase):
    def test_selects_view_that_observes_high_uncertainty_target(self) -> None:
        covariance = np.diag([4.0, 0.25])
        candidates = (
            CandidateView(
                "height-view",
                0,
                30,
                np.array([[1.0, 0.0]]),
                np.array([[0.2]]),
                0.9,
            ),
            CandidateView(
                "dbh-view",
                90,
                0,
                np.array([[0.0, 1.0]]),
                np.array([[0.05]]),
                1.0,
            ),
        )
        selected = select_next_best_view(covariance, candidates)
        self.assertEqual(selected.view.view_id, "height-view")
        self.assertLess(selected.posterior_covariance_if_visible[0, 0], covariance[0, 0])

    def test_visibility_discounts_occluded_view(self) -> None:
        covariance = np.eye(1)
        candidates = (
            CandidateView("occluded", 0, 0, np.ones((1, 1)), np.eye(1) * 0.01, 0.01),
            CandidateView("visible", 180, 0, np.ones((1, 1)), np.eye(1) * 0.2, 1.0),
        )
        self.assertEqual(select_next_best_view(covariance, candidates).view.view_id, "visible")

    def test_factor_guidance_uses_covariance_and_angular_novelty(self) -> None:
        covariance = np.eye(10) * 0.01
        covariance[7, 7] = 0.25
        estimates = {
            Parameter.HEIGHT_M: ParameterEstimate(Parameter.HEIGHT_M, 20, 0.2, 0.9, 20),
            Parameter.DBH_CM: ParameterEstimate(Parameter.DBH_CM, 40, 8, 0.6, 20),
            Parameter.VOLUME_M3: ParameterEstimate(Parameter.VOLUME_M3, 2, 0.1, 0.9, 20),
        }
        intrinsics = CameraIntrinsics(500, 500, 320, 240, 640, 480)
        frames = (
            FrameObservation("a", 1, "a.jpg", intrinsics, azimuth_deg=0),
            FrameObservation("b", 2, "b.jpg", intrinsics, azimuth_deg=30),
        )

        guidance = recommend_factor_view(covariance, estimates, frames)

        self.assertTrue(guidance.required)
        self.assertEqual(guidance.target_parameter, Parameter.DBH_CM)
        self.assertEqual(guidance.selection_method, "treefactor_expected_information_gain")
        self.assertIsNotNone(guidance.expected_variance_reduction)
        self.assertGreater(guidance.expected_variance_reduction or 0.0, 0.0)


if __name__ == "__main__":
    unittest.main()
