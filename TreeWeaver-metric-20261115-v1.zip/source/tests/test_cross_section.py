import unittest

import numpy as np

from treeweaver.geometry.cross_section import fit_trunk_cross_section


class CrossSectionTests(unittest.TestCase):
    def test_recovers_circumference_equivalent_ellipse(self) -> None:
        rng = np.random.default_rng(51)
        angle = np.linspace(0, 2 * np.pi, 240, endpoint=False)
        points = np.column_stack((0.25 * np.cos(angle), 0.15 * np.sin(angle)))
        points += rng.normal(0, 0.001, points.shape)
        result = fit_trunk_cross_section(points)
        self.assertEqual(result.model, "ellipse")
        self.assertAlmostEqual(result.major_radius, 0.25, delta=0.01)
        self.assertAlmostEqual(result.minor_radius, 0.15, delta=0.01)
        self.assertGreater(result.circumference_equivalent_diameter, 0.35)
        self.assertLess(result.circumference_equivalent_diameter, 0.45)

    def test_partial_arc_falls_back_to_circle(self) -> None:
        angle = np.linspace(-0.4, 0.4, 100)
        points = np.column_stack((0.2 * np.cos(angle), 0.2 * np.sin(angle)))
        result = fit_trunk_cross_section(points)
        self.assertEqual(result.model, "circle")


if __name__ == "__main__":
    unittest.main()
