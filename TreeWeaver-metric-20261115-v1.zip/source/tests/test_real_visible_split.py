import importlib.util
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location(
    "prepare_real_visible_split",
    Path(__file__).resolve().parents[1] / "scripts/prepare_real_visible_split.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_all_views_of_reserved_trees_are_excluded_and_split_is_reproducible():
    ids = list(range(1, 252)) * 2
    protected = {193, 24, 30}
    result = MODULE.partition(ids, protected)
    assert result == MODULE.partition(list(reversed(ids)), protected)
    train, val = set(result["train"]), set(result["validation"])
    assert not train & val
    assert not (train | val) & (protected | MODULE.LEGACY_IDS)
    assert train | val == set(ids) - protected - MODULE.LEGACY_IDS


def test_ft_leading_zero_does_not_evade_reserved_identity():
    assert MODULE.identity("FT001_IMG_LEFT_mask") == MODULE.identity("FT1_IMG_LEFT")
    with pytest.raises(ValueError):
        MODULE.identity("not-a-tree")
