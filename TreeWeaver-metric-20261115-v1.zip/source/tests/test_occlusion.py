import numpy as np

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose
from treeweaver.visibility.occlusion import (
    SurfaceState,
    fuse_surface_visibility,
    probe_surface_in_view,
)


def _camera(name: str, centre_x: float = 0.0) -> ProjectionCamera:
    return ProjectionCamera(
        name,
        CameraPose(1, 1, name, np.eye(3), np.array([-centre_x, 0.0, 0.0])),
        CameraIntrinsics(100, 100, 50, 50, 100, 100),
    )


def test_distinguishes_occluded_unobserved_and_outside_surface() -> None:
    camera = _camera("front")
    expected = np.array([[0.0, 0.0, 5.0], [0.5, 0.0, 5.0], [20.0, 0.0, 5.0]])
    scene = np.array([[0.0, 0.0, 3.0]])

    result = probe_surface_in_view(expected, scene, camera, pixel_radius=0)

    assert result.states.tolist() == [
        int(SurfaceState.OCCLUDED),
        int(SurfaceState.UNOBSERVED),
        int(SurfaceState.OUTSIDE_VIEW),
    ]
    assert result.occluder_indices[0] == 0


def test_second_side_view_recovers_surface_hidden_in_front_view() -> None:
    expected = np.array([[0.0, 0.0, 5.0]])
    scene = np.array([[0.0, 0.0, 3.0], [0.0, 0.0, 5.0]])
    result = fuse_surface_visibility(
        expected,
        scene,
        (_camera("front"), _camera("side", 1.5)),
        pixel_radius=0,
    )

    assert result.views[0].states[0] == int(SurfaceState.OCCLUDED)
    assert result.views[1].states[0] == int(SurfaceState.VISIBLE)
    assert result.states[0] == int(SurfaceState.VISIBLE)
    assert result.visible_view_count[0] == 1
    assert result.occluded_view_count[0] == 1
