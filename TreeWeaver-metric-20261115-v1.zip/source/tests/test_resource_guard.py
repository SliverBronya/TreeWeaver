import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
import resource_guard as guard  # noqa: E402


@pytest.fixture(autouse=True)
def isolated_stop_file(monkeypatch, tmp_path):
    monkeypatch.setattr(guard, "SESSION_GPU_STOP", tmp_path / "GPU_DISABLED")


def test_session_stop_file_blocks_gpu_without_probe(monkeypatch):
    guard.SESSION_GPU_STOP.write_text("disabled")
    monkeypatch.setattr(
        guard, "memory_snapshot", lambda: pytest.fail("GPU disabled before any probe")
    )
    with pytest.raises(guard.ResourceLimit, match="disabled"):
        guard.ExperimentGuard().inspect()
    with pytest.raises(guard.ResourceLimit, match="pretrained experiments disabled"):
        guard.assert_pretrained_experiment_allowed()


def test_no_stop_file_keeps_pretrained_entrypoint_available():
    guard.assert_pretrained_experiment_allowed()


def test_other_cuda_job_and_low_commit_are_rejected(monkeypatch):
    monkeypatch.setattr(
        guard,
        "memory_snapshot",
        lambda: {"available_ram_bytes": 5 * 1024**3, "available_commit_bytes": 1024**3},
    )
    with pytest.raises(guard.ResourceLimit, match="commit"):
        guard.ExperimentGuard().inspect()
    monkeypatch.setattr(guard, "memory_snapshot", lambda: {"available_ram_bytes": 5 * 1024**3})
    monkeypatch.setattr(
        guard.subprocess,
        "run",
        lambda command, **kw: SimpleNamespace(
            stdout=str(guard.os.getpid() + 1)
            if "--query-compute-apps=pid" in command
            else "6000, 40"
        ),
    )
    with pytest.raises(guard.ResourceLimit, match="another CUDA"):
        guard.ExperimentGuard().inspect()


def test_low_memory_blocks_before_gpu_probe(monkeypatch):
    monkeypatch.setattr(guard, "memory_snapshot", lambda: {"available_ram_bytes": 2 * 1024**3})
    monkeypatch.setattr(
        guard.subprocess, "run", lambda *a, **k: pytest.fail("must not probe further")
    )
    with pytest.raises(guard.ResourceLimit, match="RAM"):
        guard.ExperimentGuard().inspect()


@pytest.mark.parametrize(
    "reading,allowed", [("6000, 45", True), ("6000, 76", False), ("900, 45", False)]
)
def test_gpu_headroom_and_temperature_limits(monkeypatch, reading, allowed):
    monkeypatch.setattr(guard, "memory_snapshot", lambda: {"available_ram_bytes": 5 * 1024**3})
    monkeypatch.setattr(guard.subprocess, "run", lambda *a, **k: SimpleNamespace(stdout=reading))
    monitor = guard.ExperimentGuard()
    if allowed:
        assert monitor.inspect()["temperature_c"] == 45
    else:
        with pytest.raises(guard.ResourceLimit):
            monitor.inspect()


def test_failed_monitor_does_not_allow_unmonitored_run(monkeypatch):
    def unavailable():
        raise OSError("monitor unavailable")

    monkeypatch.setattr(guard, "memory_snapshot", unavailable)
    with pytest.raises(OSError):
        guard.ExperimentGuard().inspect()
