import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from ownership_features import ownership_logits  # noqa: E402


def fixture():
    torch.manual_seed(35)
    return (torch.randn(2, 3, 4, 8, 8), torch.randn(2, 3, 6),
            torch.nn.Linear(6, 4), torch.nn.Conv2d(4, 4, 1), torch.nn.Conv2d(4, 1, 1))


def test_shared_matches_legacy_equation_exactly():
    features,tokens,projection,pixels,background=fixture()
    shared=features.mean(1)
    expected=torch.cat([background(shared),torch.einsum("bchw,bkc->bkhw",pixels(shared),projection(tokens))],1)
    actual,_=ownership_logits(features,tokens,projection,pixels,background)
    torch.testing.assert_close(actual,expected,rtol=0,atol=0)


def test_query_specific_is_equivariant_and_does_not_change_background():
    features,tokens,*heads=fixture()
    shared,_=ownership_logits(features,tokens,*heads)
    before,_=ownership_logits(features,tokens,*heads,query_specific=True)
    after,_=ownership_logits(features.flip(1),tokens.flip(1),*heads,query_specific=True)
    torch.testing.assert_close(before[:,:1],shared[:,:1],rtol=0,atol=0)
    torch.testing.assert_close(after[:,1:],before[:,1:].flip(1))
    assert not torch.allclose(before[:,1:],shared[:,1:])


def test_one_query_matches_and_all_heads_receive_gradients():
    features,tokens,*heads=fixture()
    shared,_=ownership_logits(features[:,:1],tokens[:,:1],*heads)
    query,_=ownership_logits(features[:,:1],tokens[:,:1],*heads,query_specific=True)
    torch.testing.assert_close(shared,query,rtol=0,atol=0)
    query.square().mean().backward()
    for head in heads:
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in head.parameters())


def test_mismatched_query_counts_rejected():
    features,tokens,*heads=fixture()
    with pytest.raises(ValueError,match="matching"):
        ownership_logits(features,tokens[:,:1],*heads)
