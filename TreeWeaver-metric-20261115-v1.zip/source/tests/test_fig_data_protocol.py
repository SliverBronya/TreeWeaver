"""Regression checks for data leakage and geometric label bookkeeping."""

from __future__ import annotations

import importlib.util
import random
import sys
from pathlib import Path

import numpy as np
import pytest


def test_magnolia_materials_preserve_unknown_cut_caps():
    from fig_data_protocol import material_part

    assert material_part("MagnoliaBark_Mat") == "stem"
    assert material_part("Branches_04_Mat") == "crown_surface"
    assert material_part("MagnoliaLeaf_Mat.001") == "crown_surface"
    assert material_part("Cap_02_Mat") == "part_unknown"
    assert material_part("QualifiedOlive_Leaf") == "crown_surface"
    assert material_part("QualifiedOlive_WoodUnknown") == "part_unknown"
    assert material_part("QualifiedOlive_Unassigned") == "part_unknown"
    with pytest.raises(ValueError, match="unreviewed"):
        material_part("Unreviewed_Magnolia")


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
SPEC = importlib.util.spec_from_file_location("fig_data_protocol", SCRIPTS / "fig_data_protocol.py")
PROTOCOL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROTOCOL)


def test_generation_plan_freezes_disjoint_asset_pools_and_scenes():
    assets = [f"tree-{i}" for i in range(29)]
    plan = PROTOCOL.make_generation_plan(assets, seed=731)
    PROTOCOL.validate_plan(plan)
    assert plan == PROTOCOL.make_generation_plan(list(reversed(assets)), seed=731)
    pools = plan["asset_pools"]
    assert not set(pools["train"]) & set(pools["validation"])
    assert not set(pools["train"]) & set(pools["test"])
    assert not set(pools["validation"]) & set(pools["test"])
    assert len(plan["records"]) == 500
    assert sum(record["split"] == "test" for record in plan["records"]) == 50
    assert all(set(record["trees"]) <= set(pools[record["split"]]) for record in plan["records"])


def test_generation_plan_rejects_too_few_assets_or_asset_leakage():
    with pytest.raises(ValueError, match="at least 12"):
        PROTOCOL.make_generation_plan([f"tree-{i}" for i in range(11)], seed=1)
    plan = PROTOCOL.make_generation_plan([f"tree-{i}" for i in range(12)], seed=1)
    plan["asset_pools"]["test"][0] = plan["asset_pools"]["train"][0]
    with pytest.raises(ValueError, match="leakage"):
        PROTOCOL.validate_plan(plan)


def test_horizontal_order_does_not_encode_depth_order():
    rng = random.Random(831)
    left_is_front = []
    for _ in range(1000):
        depth, horizontal = PROTOCOL.layout_orders(4, rng)
        rank = {tree: i for i, tree in enumerate(depth)}
        for i in range(3):
            left_is_front.append(rank[horizontal[i]] < rank[horizontal[i + 1]])
    assert 0.45 < sum(left_is_front) / len(left_is_front) < 0.55


def test_pair_metrics_includes_non_adjacent_overlapping_objects():
    masks = [np.zeros((8, 8), bool) for _ in range(4)]
    masks[0][1:4, 1:4] = True
    masks[2][1:4, 1:4] = True
    pairs = PROTOCOL.pair_metrics(masks)
    assert len(pairs) == 6
    distant = next(pair for pair in pairs if pair["pair"] == [1, 3])
    assert distant["area_overlap_px"] == 9
    assert distant["ratio_min"] == 1.0


def test_target_id_ownership_resolves_antialias_conflicts_and_background():
    coverage = [np.array([[0.8, 0.2], [0.6, 0.1]]), np.array([[0.7, 0.9], [0.2, 0.1]])]
    np.testing.assert_array_equal(PROTOCOL.ownership_from_coverage(coverage), [[1, 2], [1, 0]])


def test_postprocess_refuses_to_relabel_legacy_data(tmp_path):
    import json

    from postprocess_fig_500 import postprocess

    (tmp_path / "meta").mkdir()
    (tmp_path / "meta" / "000001.json").write_text(json.dumps({"id": 1, "trees": ["a", "b"]}))
    before = {str(path): path.read_bytes() for path in tmp_path.rglob("*") if path.is_file()}
    with pytest.raises(ValueError, match="legacy labels are read-only"):
        postprocess(tmp_path)
    assert before == {
        str(path): path.read_bytes() for path in tmp_path.rglob("*") if path.is_file()
    }


def test_paired_plan_includes_controls_and_keeps_assets_disjoint():
    assets = [f"tree-{i}" for i in range(29)]
    plan = PROTOCOL.make_paired_generation_plan(assets, 17)
    PROTOCOL.validate_plan(plan)
    assert plan == PROTOCOL.make_paired_generation_plan(list(reversed(assets)), 17)
    assert len(plan["records"]) == 30
    for split in ("train", "validation", "test"):
        scenes = [r for r in plan["records"] if r["split"] == split]
        assert {len(r["trees"]) for r in scenes} == {1, 2, 3, 4}
        assert {r["requested_bbox_overlap"] for r in scenes} == {0.0, 0.1, 0.35, 0.65}


def test_part_semantics_reject_unknown_material_and_preserve_unknown_edges():
    assert PROTOCOL.material_part("Ficus_carica_bark.001") == "stem"
    assert PROTOCOL.material_part("Ficus_carica_leaf_01_y2a") == "crown_surface"
    with pytest.raises(ValueError, match="unreviewed"):
        PROTOCOL.material_part("unlabelled_material")
    support = np.ones((1, 4), bool)
    stem, crown, unknown = PROTOCOL.partition_part_coverage(
        support, np.array([[1.0, 0.0, 0.5, 0.0]]), np.array([[0.0, 1.0, 0.5, 0.0]])
    )
    np.testing.assert_array_equal(stem, [[True, False, False, False]])
    np.testing.assert_array_equal(crown, [[False, True, False, False]])
    np.testing.assert_array_equal(unknown, [[False, False, True, True]])


def test_absolute_profile_detects_uniform_shrink_and_does_not_fill_holes():
    mask = np.zeros((20, 30), bool)
    mask[5:15, 3] = True
    mask[5:15, 23] = True
    original = mask.copy()
    wide = PROTOCOL.absolute_crown_profile(mask, 4)
    mask[:, 23] = False
    mask[5:15, 13] = True
    narrow = PROTOCOL.absolute_crown_profile(mask, 4)
    assert wide["bands"][0]["width_px"] == 21
    assert narrow["bands"][0]["width_px"] == 11
    assert original[:, 4:23].sum() == 0


def test_single_tree_does_not_invent_hidden_area_at_alpha_edges():
    coverage = np.array([[0.0, 0.3, 0.49, 0.51, 0.7, 1.0]])
    visible, amodal, unknown = PROTOCOL.paired_support_masks(
        coverage >= 0.5, coverage, coverage, single_tree=True
    )
    np.testing.assert_array_equal(visible, amodal)
    assert not (amodal & ~visible).any()
    assert unknown[0, 2] and unknown[0, 3]
    assert not amodal[0, 1]  # faint fringe is not counted as hidden geometry


def test_real_hidden_pixels_retained_but_raster_inconsistency_ignored():
    scene, isolated = np.array([[0.1, 0.8, 0.8]]), np.array([[0.9, 0.9, 0.1]])
    visible, full, unknown = PROTOCOL.paired_support_masks(scene >= 0.5, scene, isolated)
    assert full[0, 0] and not visible[0, 0]
    assert unknown[0, 2] and not full[0, 2] and not visible[0, 2]


def test_spacing_mix_keeps_matched_trees_and_has_separated_multi_tree_scenes():
    assets = [f"tree-{i}" for i in range(29)]
    original = PROTOCOL.make_paired_generation_plan(assets, 17)
    spaced = PROTOCOL.make_spaced_paired_generation_plan(assets, 17)
    PROTOCOL.validate_plan(spaced)
    for before, after in zip(original["records"], spaced["records"], strict=True):
        assert before["trees"] == after["trees"] and before["scene_seed"] == after["scene_seed"]
    for split in ("train", "validation", "test"):
        scenes = [r for r in spaced["records"] if r["split"] == split]
        assert sum(r["spacing_class"] == "separated" for r in scenes) == 3
        assert sum(r["spacing_class"] == "hard" for r in scenes) == 1


def test_negative_overlap_produces_real_envelope_gaps_with_unequal_widths():
    widths = [8.0, 14.0, 6.0]
    centers = PROTOCOL.crown_layout_centers(widths, -0.25)
    for i in range(2):
        gap = centers[i + 1] - widths[i + 1] / 2 - (centers[i] + widths[i] / 2)
        assert gap == pytest.approx(0.25 * min(widths[i], widths[i + 1]))


def test_depth_separation_protects_origins_without_using_horizontal_order():
    xs, widths, order = [0.0, 0.2, -0.1], [8.0, 6.0, 7.0], [2, 0, 1]
    depths = PROTOCOL.separated_depths(xs, widths, order, 0.8)
    assert depths[2] < depths[0] < depths[1]
    for i in range(3):
        for j in range(i + 1, 3):
            distance = ((xs[i] - xs[j]) ** 2 + (depths[i] - depths[j]) ** 2) ** 0.5
            assert distance >= 0.60 * min(widths[i], widths[j]) - 1e-6
