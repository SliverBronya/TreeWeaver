import numpy as np

from treeweaver.domain.models import Parameter
from treeweaver.measurement.image_readiness import (
    MeasurementReadiness,
    assess_single_image_measurement,
)
from treeweaver.visibility.image_complexity import ImageChallengeCue, audit_target_view


def _masks() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    instance = np.zeros((40, 30), dtype=bool)
    trunk = np.zeros_like(instance)
    crown = np.zeros_like(instance)
    ground = np.zeros_like(instance)
    trunk[20:36, 13:17] = True
    crown[5:21, 5:25] = True
    instance |= trunk | crown
    ground[36:] = True
    return instance, trunk, crown, ground


def _dbh_region(trunk: np.ndarray) -> np.ndarray:
    region = np.zeros_like(trunk)
    region[25:30, 13:17] = True
    return region


def _by_parameter(gates: tuple) -> dict:
    return {gate.parameter: gate for gate in gates}


def test_clear_single_view_releases_only_visible_projection_parameters() -> None:
    instance, trunk, crown, ground = _masks()
    gates = _by_parameter(
        assess_single_image_measurement(
            audit_target_view(
                instance,
                trunk,
                crown,
                ground_mask=ground,
                dbh_region_mask=_dbh_region(trunk),
                amodal_trunk_mask=trunk,
            )
        )
    )

    assert gates[Parameter.HEIGHT_M].readiness is MeasurementReadiness.CANDIDATE
    assert gates[Parameter.DBH_CM].readiness is MeasurementReadiness.CANDIDATE
    assert gates[Parameter.CROWN_WIDTH_M].readiness is MeasurementReadiness.CANDIDATE
    assert gates[Parameter.CROWN_DEPTH_M].readiness is MeasurementReadiness.BLOCKED
    assert gates[Parameter.VOLUME_M3].readiness is MeasurementReadiness.BLOCKED


def test_complex_scene_blocks_only_affected_parameters() -> None:
    instance, trunk, crown, ground = _masks()
    competitor = np.zeros_like(instance)
    competitor[25:33, 13:17] = True
    audit = audit_target_view(
        instance,
        trunk,
        crown,
        competing_instance_masks=(competitor,),
        ground_mask=ground,
        dbh_region_mask=_dbh_region(trunk),
        amodal_trunk_mask=trunk,
    )
    gates = _by_parameter(assess_single_image_measurement(audit))

    assert gates[Parameter.DBH_CM].readiness is MeasurementReadiness.BLOCKED
    assert gates[Parameter.CROWN_WIDTH_M].readiness is MeasurementReadiness.CANDIDATE
    assert gates[Parameter.HEIGHT_M].readiness is MeasurementReadiness.DEGRADED


def test_cropped_apex_blocks_height_without_claiming_missing_geometry() -> None:
    instance, trunk, crown, ground = _masks()
    crown[:3, 5:25] = True
    instance |= crown
    gates = _by_parameter(
        assess_single_image_measurement(
            audit_target_view(instance, trunk, crown, ground_mask=ground)
        )
    )
    assert gates[Parameter.HEIGHT_M].readiness is MeasurementReadiness.BLOCKED
    assert "树梢" in gates[Parameter.HEIGHT_M].reasons[0]


def test_amodal_hidden_dbh_blocks_diameter_without_mask_intersection() -> None:
    instance, trunk, crown, ground = _masks()
    amodal_trunk = trunk.copy()
    region = np.zeros_like(trunk)
    region[25:30, 13:17] = True
    foreground = np.zeros_like(trunk)
    foreground[25:30, 13] = True
    trunk[25:30, 13] = False
    instance = trunk | crown
    audit = audit_target_view(
        instance,
        trunk,
        crown,
        competing_instance_masks=(foreground,),
        ground_mask=ground,
        dbh_region_mask=region,
        amodal_trunk_mask=amodal_trunk,
        foreground_occluder_mask=foreground,
    )
    gates = _by_parameter(assess_single_image_measurement(audit))

    assert audit.score(ImageChallengeCue.STEM_OVERLAP) == 0
    assert gates[Parameter.DBH_CM].readiness is MeasurementReadiness.BLOCKED
    assert gates[Parameter.CROWN_WIDTH_M].readiness is MeasurementReadiness.CANDIDATE


def test_missing_ground_or_dbh_location_is_unknown_not_clear() -> None:
    instance, trunk, crown, ground = _masks()
    without_ground = _by_parameter(
        assess_single_image_measurement(
            audit_target_view(
                instance, trunk, crown, dbh_region_mask=_dbh_region(trunk), amodal_trunk_mask=trunk
            )
        )
    )
    without_dbh = _by_parameter(
        assess_single_image_measurement(
            audit_target_view(instance, trunk, crown, ground_mask=ground)
        )
    )
    assert without_ground[Parameter.HEIGHT_M].readiness is MeasurementReadiness.BLOCKED
    assert without_ground[Parameter.DBH_CM].readiness is MeasurementReadiness.BLOCKED
    assert without_dbh[Parameter.DBH_CM].readiness is MeasurementReadiness.BLOCKED
