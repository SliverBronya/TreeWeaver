import numpy as np
import pytest

from workers.whole_tree_sam2.multi_instance import choose_target_mask, nonmaximum_boxes


def test_root_anchor_selects_target_not_highest_scoring_neighbor() -> None:
    trunk = np.zeros((20, 30), dtype=bool)
    trunk[10:19, 5:8] = True
    neighbor = np.zeros_like(trunk)
    neighbor[2:19, 20:27] = True
    target = trunk.copy()
    target[2:10, 1:15] = True
    index, support = choose_target_mask((neighbor, target), trunk)
    assert index == 1
    assert support == (0.0, 1.0)


def test_ambiguous_shared_stem_blocks_target_identity() -> None:
    trunk = np.zeros((20, 30), dtype=bool)
    trunk[10:19, 5:8] = True
    first = trunk.copy()
    second = trunk.copy()
    second[1:10, 3:20] = True
    index, support = choose_target_mask((first, second), trunk)
    assert index is None
    assert support == (1.0, 1.0)


def test_nms_keeps_distinct_trees() -> None:
    boxes = np.asarray([[0, 0, 10, 10], [1, 1, 11, 11], [20, 0, 30, 10]], dtype=float)
    scores = np.asarray([0.9, 0.8, 0.7])
    assert nonmaximum_boxes(boxes, scores) == [0, 2]


def test_misaligned_masks_are_rejected() -> None:
    with pytest.raises(ValueError, match="aligned"):
        choose_target_mask((np.ones((3, 4), dtype=bool),), np.ones((4, 4), dtype=bool))
