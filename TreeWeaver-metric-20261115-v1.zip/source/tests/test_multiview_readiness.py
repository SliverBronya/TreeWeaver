import numpy as np
import pytest

from treeweaver.domain.models import Parameter
from treeweaver.measurement.image_readiness import MeasurementReadiness
from treeweaver.measurement.multiview_readiness import (
    AssociatedTreeView,
    assess_unordered_views,
)
from treeweaver.visibility.image_complexity import audit_target_view


def _view(
    image_id: str, *, dbh_hidden: bool = False, cropped: bool = False, verified: bool = True
) -> AssociatedTreeView:
    trunk = np.zeros((40, 30), dtype=bool)
    crown = np.zeros_like(trunk)
    ground = np.zeros_like(trunk)
    trunk[20:36, 13:17] = True
    crown[0 if cropped else 5 : 21, 5:25] = True
    ground[36:] = True
    region = np.zeros_like(trunk)
    region[25:30, 13:17] = True
    amodal = trunk.copy()
    foreground = np.zeros_like(trunk)
    if dbh_hidden:
        trunk[25:30, 13] = False
        foreground[25:30, 13] = True
    audit = audit_target_view(
        trunk | crown,
        trunk,
        crown,
        ground_mask=ground,
        dbh_region_mask=region,
        amodal_trunk_mask=amodal,
        foreground_occluder_mask=foreground,
    )
    return AssociatedTreeView(image_id, audit, verified)


def _by_parameter(views: tuple[AssociatedTreeView, ...]) -> dict:
    return {gate.parameter: gate for gate in assess_unordered_views(views)}


def test_second_verified_view_recovers_visible_dbh_evidence_only() -> None:
    gates = _by_parameter((_view("a", dbh_hidden=True), _view("b")))
    assert gates[Parameter.DBH_CM].readiness is MeasurementReadiness.CANDIDATE
    assert gates[Parameter.DBH_CM].supporting_view_ids == ("b",)
    assert gates[Parameter.DBH_CM].blocked_view_ids == ("a",)
    assert gates[Parameter.VOLUME_M3].readiness is MeasurementReadiness.BLOCKED


def test_unverified_other_tree_cannot_rescue_hidden_dbh() -> None:
    gates = _by_parameter((_view("a", dbh_hidden=True), _view("b", verified=False)))
    assert gates[Parameter.DBH_CM].readiness is MeasurementReadiness.BLOCKED
    assert gates[Parameter.DBH_CM].supporting_view_ids == ()
    assert "b" in gates[Parameter.DBH_CM].reasons[-1]


def test_same_view_requirement_prevents_cross_view_apex_invention() -> None:
    gates = _by_parameter((_view("a", cropped=True), _view("b", dbh_hidden=True)))
    assert gates[Parameter.HEIGHT_M].supporting_view_ids == ("b",)
    assert gates[Parameter.DBH_CM].supporting_view_ids == ("a",)


def test_no_verified_view_or_duplicate_id_fails_closed() -> None:
    gates = _by_parameter((_view("a", verified=False),))
    assert all(gate.readiness is MeasurementReadiness.BLOCKED for gate in gates.values())
    with pytest.raises(ValueError, match="unique"):
        assess_unordered_views((_view("a"), _view("a")))


def test_unordered_view_result_is_independent_of_input_order() -> None:
    left = _view("a", dbh_hidden=True)
    right = _view("b")
    assert assess_unordered_views((left, right)) == assess_unordered_views((right, left))
