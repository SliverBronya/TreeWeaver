import json
from pathlib import Path

from treeweaver.domain.models import (
    CameraIntrinsics,
    CaptureSession,
    DeviceCapabilities,
    FrameObservation,
    Parameter,
    ScaleAnchor,
)
from treeweaver.io.session import load_capture_session
from treeweaver.pipeline.input_mode import Identifiability, InputMode, assess_input


def test_single_rgb_with_reference_is_a_valid_capture_but_volume_is_not_identifiable(
    tmp_path: Path,
) -> None:
    (tmp_path / "tree.jpg").write_bytes(b"fixture")
    manifest = {
        "schema_version": "1.0",
        "session_id": "single-tree",
        "device": {
            "device_id": "ordinary-phone",
            "has_imu": False,
            "has_arcore": False,
            "has_metric_depth": False,
            "depth_source": "none",
        },
        "frames": [
            {
                "frame_id": "one",
                "timestamp_ns": 1,
                "image_path": "tree.jpg",
                "intrinsics": {
                    "fx": 800,
                    "fy": 800,
                    "cx": 320,
                    "cy": 240,
                    "width": 640,
                    "height": 480,
                },
            }
        ],
        "scale_anchors": [
            {"kind": "coded_marker", "metric_length_m": 0.2, "confidence": 1.0}
        ],
    }
    path = tmp_path / "capture.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")

    loaded = load_capture_session(path)
    assessment = assess_input(loaded.session)
    by_parameter = {item.parameter: item for item in assessment.parameters}

    assert assessment.mode is InputMode.SINGLE_RGB
    assert not assessment.user_supplied_camera_relationships
    assert by_parameter[Parameter.HEIGHT_M].level is Identifiability.CONDITIONAL
    assert by_parameter[Parameter.VOLUME_M3].level is Identifiability.NOT_IDENTIFIABLE
    assert any("single RGB mode" in warning for warning in loaded.warnings)


def test_unordered_images_do_not_require_user_camera_relationships(tmp_path: Path) -> None:
    del tmp_path
    intrinsics = CameraIntrinsics(800, 800, 320, 240, 640, 480)
    session = CaptureSession(
        "1.0",
        "unordered",
        "phone",
        DeviceCapabilities(),
        frames=(
            FrameObservation("a", 1, "a.jpg", intrinsics),
            FrameObservation("b", 2, "b.jpg", intrinsics),
        ),
        anchors=(ScaleAnchor("coded_marker", 0.2),),
    )
    assessment = assess_input(session)
    assert assessment.mode is InputMode.UNORDERED_RGB
    assert not assessment.user_supplied_camera_relationships
