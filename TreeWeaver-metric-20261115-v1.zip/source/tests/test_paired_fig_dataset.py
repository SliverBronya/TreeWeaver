import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from paired_fig_dataset import PairedFigDataset  # noqa: E402


def test_native_stem_point_survives_coarse_mask_downsampling(tmp_path):
    prepare(tmp_path)
    native = np.zeros((16, 16, 4), np.uint8)
    native[4:12, 7, 3] = 255
    cv2.imwrite(str(tmp_path / "thin.png"), native)
    path = tmp_path / "paired-samples.json"
    manifest = json.loads(path.read_text())
    manifest["records"][0]["instances"][0]["visible_stem"] = "thin.png"
    path.write_text(json.dumps(manifest))
    sample = PairedFigDataset(tmp_path, "train", size=32, mask_size=4).sample(0)
    assert not sample["visible_stem"].any()  # A 1px stem disappears at mask resolution.
    x, y = np.floor(sample["identity_points"][0] * 16 / 32).astype(int)
    assert native[y, x, 3] == 255
    assert sample["identity_labels"].tolist() == [1]
    assert sample["identity_sources"] == ["GT native visible bark pixel"]
    # The native visibility target remains defined although the coarse stem vanished.
    assert sample["visibility_valid"].tolist() == [[True, True]]
    assert sample["visibility_target"][0, 1] == pytest.approx(7 / 31)


def prepare(root):
    def mask(name, pixels):
        rgba = np.zeros((16, 16, 4), np.uint8)
        rgba[pixels, 3] = 255
        path = root / f"{name}.png"
        cv2.imwrite(str(path), rgba)
        return path.name

    foreground = np.zeros((16, 16), bool)
    foreground[4:12, 6:10] = True
    unknown = np.zeros_like(foreground)
    unknown[3, 7] = True
    part_unknown = np.zeros_like(foreground)
    part_unknown[4, 7] = True
    fg = mask("fg", foreground)
    empty = mask("empty", np.zeros_like(foreground))
    uncertainty = mask("unknown", unknown)
    part = mask("part", part_unknown)
    cv2.imwrite(str(root / "rgb.png"), np.zeros((16, 16, 3), np.uint8))
    instance = {key: fg for key in ("visible", "amodal", "visible_stem", "amodal_stem")}
    instance.update(
        {
            "asset": "a",
            "visible_crown": empty,
            "amodal_crown": empty,
            "raster_unknown": uncertainty,
            "visible_part_unknown": part,
            "amodal_part_unknown": part,
        }
    )
    rows = [
        {
            "id": "1-control-1",
            "group_id": 1,
            "split": "train",
            "condition": "isolated",
            "image": "rgb.png",
            "instances": [instance],
        }
    ]
    (root / "paired-samples.json").write_text(
        json.dumps({"schema_version": "treeweaver-paired-1.0", "records": rows})
    )
    (root / "splits.json").write_text(
        json.dumps(
            {
                "splits": {"train": [1], "validation": [2], "test": [3]},
                "asset_pools": {"train": ["a"], "validation": ["b"], "test": ["c"]},
            }
        )
    )


def test_unknown_pixels_remain_explicit_for_whole_and_part_losses(tmp_path):
    prepare(tmp_path)
    sample = PairedFigDataset(tmp_path, "train", size=32, mask_size=16).sample(0)
    assert sample["pixel_values"].shape == (3, 32, 32)
    assert not sample["whole_valid"][0, 3, 7]
    assert sample["whole_valid"][0, 4, 7]
    assert not sample["visible_part_valid"][0, 4, 7]
    assert not sample["hidden"].any()
    np.testing.assert_array_equal(sample["visible"], sample["amodal"])


def test_control_cannot_cross_the_parent_scene_split(tmp_path):
    prepare(tmp_path)
    path = tmp_path / "paired-samples.json"
    manifest = json.loads(path.read_text())
    manifest["records"][0]["split"] = "validation"
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="frozen split"):
        PairedFigDataset(tmp_path, "validation")


def test_unknown_cannot_silently_become_foreground(tmp_path):
    prepare(tmp_path)
    path = tmp_path / "unknown.png"
    rgba = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    rgba[6, 7, 3] = 255
    cv2.imwrite(str(path), rgba)
    with pytest.raises(ValueError, match="unknown pixels"):
        PairedFigDataset(tmp_path, "train", size=32, mask_size=16).sample(0)


@pytest.mark.parametrize(
    "metadata",
    [
        {"frame_truncated": True},
        {"amodal_supervision_allowed": False},
        {"frame_truncated": True, "amodal_supervision_allowed": True},
    ],
)
def test_truncated_tree_keeps_visible_but_never_complete_or_shape_supervision(tmp_path, metadata):
    prepare(tmp_path)
    path = tmp_path / "paired-samples.json"
    manifest = json.loads(path.read_text())
    instance = manifest["records"][0]["instances"][0]
    instance.update(metadata)
    # Add known hidden support: the diagnostic retains it, the loss must ignore it.
    full = cv2.imread(str(tmp_path / "fg.png"), cv2.IMREAD_UNCHANGED)
    full[12:14, 6:10, 3] = 255
    cv2.imwrite(str(tmp_path / "full.png"), full)
    instance["amodal"] = "full.png"
    path.write_text(json.dumps(manifest))
    sample = PairedFigDataset(tmp_path, "train", size=32, mask_size=16).sample(0)
    assert sample["whole_valid"].any() and sample["visible_part_valid"].any()
    assert sample["visible"].any() and sample["identity_labels"].tolist() == [1]
    assert not sample["amodal_valid"].any()
    assert not sample["amodal_part_valid"].any()
    assert not sample["amodal_instance_valid"].any()
    assert not sample["shape_instance_valid"].any()
    assert not sample["visibility_valid"].any()
    assert np.isfinite(sample["visibility_target"]).all()
    assert not sample["hidden"].any()
    assert sample["observed_hidden"].sum() == 8


def test_existing_untruncated_samples_retain_completion_contract(tmp_path):
    prepare(tmp_path)
    sample = PairedFigDataset(tmp_path, "train", size=32, mask_size=16).sample(0)
    np.testing.assert_array_equal(sample["amodal_valid"], sample["whole_valid"])
    np.testing.assert_array_equal(sample["amodal_part_valid"], sample["visible_part_valid"])
    assert sample["amodal_instance_valid"].tolist() == [True]


def test_native_unknown_corruption_cannot_disappear_during_downsampling(tmp_path):
    prepare(tmp_path)
    path = tmp_path / "unknown.png"
    rgba = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    rgba[5, 7, 3] = 255  # This pixel is not sampled by the 16 -> 4 nearest resize.
    cv2.imwrite(str(path), rgba)
    with pytest.raises(ValueError, match="native supervision"):
        PairedFigDataset(tmp_path, "train", size=32, mask_size=4).sample(0)
