import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from anchor_competition import AnchorCompetition, identity_objective  # noqa: E402


def test_zero_initialization_preserves_raw_masks_exactly():
    module = AnchorCompetition(8)
    raw = torch.randn(3, 12, 16)
    output, residual = module(torch.randn(1, 8, 12, 16), raw, torch.rand(3, 2))
    torch.testing.assert_close(output, raw, rtol=0, atol=0)
    assert not residual.any()


def test_joint_predictions_follow_instance_permutation_after_learning():
    torch.manual_seed(3)
    module = AnchorCompetition(8)
    torch.nn.init.normal_(module.refine[-1].weight, std=0.1)
    raw, features, anchors = torch.randn(3, 12, 16), torch.randn(1, 8, 12, 16), torch.rand(3, 2)
    permutation = torch.tensor([2, 0, 1])
    a = module(features, raw, anchors)[0]
    b = module(features, raw[permutation], anchors[permutation])[0]
    torch.testing.assert_close(b, a[permutation])


def test_foreign_tree_logits_receive_negative_supervision_not_unknown_background():
    logits = torch.zeros(2, 8, 8, requires_grad=True)
    target = torch.zeros(2, 8, 8, dtype=torch.bool)
    target[0, 2:6, 1:3], target[1, 2:6, 5:7] = True, True
    residual = torch.zeros_like(logits, requires_grad=True)
    identity_objective(logits, residual, target).backward()
    assert (logits.grad[0, 2:6, 1:3] < 0).all()
    assert (logits.grad[0, 2:6, 5:7] > 0).all()
    assert logits.grad[:, 0].abs().sum() == 0


def test_single_target_has_no_rival_nan():
    model = AnchorCompetition(8)
    assert torch.isfinite(
        model(torch.randn(1, 8, 8, 8), torch.zeros(1, 8, 8), torch.tensor([[0.5, 0.8]]))[0]
    ).all()


def test_exchange_cannot_expand_all_queries_and_keeps_single_tree_unchanged():
    model = AnchorCompetition(8)
    torch.nn.init.normal_(model.refine[-1].weight, std=0.2)
    features, raw, anchors = torch.randn(1, 8, 8, 8), torch.randn(3, 8, 8), torch.rand(3, 2)
    _, residual = model(features, raw, anchors, "exchange")
    torch.testing.assert_close(residual.sum(0), torch.zeros(8, 8), atol=1e-6, rtol=0)
    output, _ = model(features, raw[:1], anchors[:1], "exchange")
    torch.testing.assert_close(output, raw[:1], atol=0, rtol=0)
