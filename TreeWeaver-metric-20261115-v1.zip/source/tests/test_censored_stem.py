import pytest

from treeweaver.geometry.censored_stem import (
    StemRowEvidence,
    WidthBoundStatus,
    bound_projected_stem_width,
)


def test_alternating_hidden_edges_preserve_width_without_inventing_a_contour() -> None:
    rows = (
        StemRowEvidence(0, 10, 22, True, False),
        StemRowEvidence(10, 18, 30, False, True),
        StemRowEvidence(20, 10, 22, True, False),
        StemRowEvidence(30, 18, 30, False, True),
    )
    bounds = bound_projected_stem_width(rows, 15, pixel_tolerance=0.5)
    assert bounds.status == WidthBoundStatus.BOUNDED
    assert bounds.minimum_width_px == pytest.approx(19)
    assert bounds.maximum_width_px == pytest.approx(21)


def test_permanently_hidden_side_does_not_get_a_fabricated_upper_bound() -> None:
    rows = tuple(StemRowEvidence(y, 10, 22, True, False) for y in (0, 10, 20, 30))
    bounds = bound_projected_stem_width(rows, 15, pixel_tolerance=0.5)
    assert bounds.status == WidthBoundStatus.UNBOUNDED
    assert bounds.minimum_width_px == pytest.approx(11)
    assert bounds.maximum_width_px is None


def test_hiding_more_edges_cannot_shrink_feasible_width_interval() -> None:
    full = tuple(StemRowEvidence(y, 10, 30, True, True) for y in (0, 10, 20, 30))
    censored = tuple(StemRowEvidence(y, 14, 25, False, False) for y in (0, 10, 20, 30))
    complete = bound_projected_stem_width(full, 15)
    incomplete = bound_projected_stem_width(censored, 15)
    assert complete.minimum_width_px is not None
    assert incomplete.minimum_width_px is not None
    assert incomplete.minimum_width_px <= complete.minimum_width_px
    assert incomplete.maximum_width_px is None


def test_contradictory_edge_or_wrong_shape_model_returns_inconsistent() -> None:
    rows = tuple(
        StemRowEvidence(y, left, 40, True, True) for y, left in ((0, 10), (10, 20), (20, 10))
    )
    assert (
        bound_projected_stem_width(rows, 10, pixel_tolerance=0.1).status
        == WidthBoundStatus.INCONSISTENT
    )


def test_hidden_root_cannot_be_established_by_extrapolating_visible_stem() -> None:
    rows = (StemRowEvidence(0, 10, 30, True, True), StemRowEvidence(10, 10, 30, True, True))
    assert bound_projected_stem_width(rows, 20).status == WidthBoundStatus.OUTSIDE_SUPPORT


def test_visible_support_at_only_one_row_still_bounds_that_row() -> None:
    rows = (StemRowEvidence(10, 10, 30, True, True),)
    bounds = bound_projected_stem_width(rows, 10, pixel_tolerance=0)
    assert bounds.minimum_width_px == bounds.maximum_width_px == 20
