"""Tiny static GLBs check coordinate transforms, bounds and conservative semantics."""

import copy
import importlib.util
import json
import math
import struct
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "metric_asset_audit", ROOT / "scripts/audit_metric_tree_assets.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def fixture(*, indexed=True, float_indices=False, strided=False, material="Ficus_carica_leaf_01"):
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype="<f4")
    if strided:
        interleaved = np.column_stack((vertices, np.full(3, 999, dtype="<f4"))).astype("<f4")
        binary = b"\0" * 4 + interleaved.tobytes()
        position_view = {"buffer": 0, "byteOffset": 0, "byteLength": len(binary), "byteStride": 16}
        position_offset = 4
    else:
        binary = vertices.tobytes()
        position_view = {"buffer": 0, "byteOffset": 0, "byteLength": len(binary)}
        position_offset = 0
    views = [position_view]
    accessors = [
        {
            "bufferView": 0,
            "byteOffset": position_offset,
            "componentType": 5126,
            "count": 3,
            "type": "VEC3",
        }
    ]
    primitive = {"attributes": {"POSITION": 0}, "mode": 4}
    if indexed:
        index = np.array([0, 1, 2], dtype="<f4" if float_indices else "<u2")
        views.append({"buffer": 0, "byteOffset": len(binary), "byteLength": index.nbytes})
        accessors.append(
            {
                "bufferView": 1,
                "componentType": 5126 if float_indices else 5123,
                "count": 3,
                "type": "SCALAR",
            }
        )
        binary += index.tobytes()
        primitive["indices"] = 1
    materials = []
    if material is not None:
        materials.append({"name": material})
        primitive["material"] = 0
    document = {
        "asset": {"version": "2.0"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"mesh": 0}],
        "meshes": [{"primitives": [primitive]}],
        "materials": materials,
        "accessors": accessors,
        "bufferViews": views,
        "buffers": [{"byteLength": len(binary)}],
    }
    return document, binary


def save_glb(path, document, binary):
    text = json.dumps(document).encode("utf-8")
    text += b" " * (-len(text) % 4)
    binary += b"\0" * (-len(binary) % 4)
    chunks = struct.pack("<I4s", len(text), b"JSON") + text
    chunks += struct.pack("<I4s", len(binary), b"BIN\0") + binary
    path.write_bytes(struct.pack("<4sII", b"glTF", 2, 12 + len(chunks)) + chunks)
    return path


def test_hierarchy_trs_applies_parent_rotation_scale_then_y_up_to_z_up(tmp_path):
    document, binary = fixture()
    document["nodes"] = [
        {
            "translation": [10, 20, 30],
            "rotation": [0, 0, math.sqrt(0.5), math.sqrt(0.5)],
            "scale": [2, 3, 4],
            "children": [1],
        },
        {"mesh": 0, "translation": [1, 2, 3], "scale": [1, 0.5, 1]},
    ]
    path = save_glb(tmp_path / "parent.glb", document, binary)
    name, vertices, faces = next(MODULE.StaticGLB(path).primitives())
    assert name == "Ficus_carica_leaf_01"
    np.testing.assert_allclose(vertices, [[4, -42, 22], [4, -42, 24], [2.5, -42, 22]], atol=1e-12)
    np.testing.assert_array_equal(faces, [[0, 1, 2]])


def test_node_matrix_is_column_major_and_cannot_be_mixed_with_trs(tmp_path):
    document, binary = fixture()
    document["nodes"][0]["matrix"] = [2, 0, 0, 0, 0, 3, 0, 0, 0, 0, 4, 0, 5, 6, 7, 1]
    path = save_glb(tmp_path / "matrix.glb", document, binary)
    vertices = next(MODULE.StaticGLB(path).primitives())[1]
    np.testing.assert_array_equal(vertices, [[5, -7, 6], [7, -7, 6], [5, -7, 9]])
    document["nodes"][0]["translation"] = [0, 0, 0]
    path = save_glb(tmp_path / "mixed.glb", document, binary)
    with pytest.raises(ValueError, match="matrix and TRS"):
        list(MODULE.StaticGLB(path).primitives())


def test_interleaved_accessor_and_offsets_do_not_read_dummy_attributes(tmp_path):
    document, binary = fixture(strided=True)
    path = save_glb(tmp_path / "stride.glb", document, binary)
    vertices = next(MODULE.StaticGLB(path).primitives())[1]
    np.testing.assert_array_equal(vertices, [[0, 0, 0], [1, 0, 0], [0, 0, 1]])


def test_float_indices_cannot_be_silently_truncated_to_triangle_indices(tmp_path):
    document, binary = fixture(float_indices=True)
    path = save_glb(tmp_path / "float-index.glb", document, binary)
    with pytest.raises(ValueError, match="unsigned integer SCALAR"):
        list(MODULE.StaticGLB(path).primitives())


def test_unindexed_default_material_geometry_is_read_but_not_certified_as_crown(tmp_path):
    document, binary = fixture(indexed=False, material=None)
    path = save_glb(tmp_path / "unqualified.glb", document, binary)
    name, _, faces = next(MODULE.StaticGLB(path).primitives())
    assert name == "unknown"
    np.testing.assert_array_equal(faces, [[0, 1, 2]])
    report = MODULE.inspect_asset(path, 9)
    crown = report["measurements"]["mesh_envelope_crown_width"]
    assert not crown["valid"] and crown["width_x_m"] is None
    assert report["measurements"]["source_bark_horizontal_section"]["value"] is None
    assert report["measurements"]["source_bark_enclosed_volume"]["value"] is None


def test_assigned_height_is_explicit_virtual_scale_and_alpha_envelope_only(tmp_path):
    document, binary = fixture()
    path = save_glb(tmp_path / "leaf.glb", document, binary)
    report = MODULE.inspect_asset(path, 9)
    assert report["chosen_synthetic_height_m"] == 9
    assert report["source_to_virtual_meter_scale"] == 9
    height = report["measurements"]["mesh_envelope_height"]
    assert height["value"] == 9 and height["input_vertex_envelope_only"]
    crown = report["measurements"]["mesh_envelope_crown_width"]
    assert crown["width_x_m"] == 9 and crown["input_vertex_envelope_only"]
    assert not report["geometry_coordinates"]["real_source_tree_scale_verified"]
    assert not report["real_field_measurements"] and not report["metric_dataset_ready"]
    with pytest.raises(ValueError, match="positive finite"):
        MODULE.inspect_asset(path, 0)


@pytest.mark.parametrize(
    "damage", ["short_stride", "accessor_overrun", "view_overrun", "zero_count"]
)
def test_accessors_cannot_read_overlapping_elements_or_outside_declared_buffers(tmp_path, damage):
    document, binary = fixture()
    if damage == "short_stride":
        document["bufferViews"][0]["byteStride"] = 8
    if damage == "accessor_overrun":
        document["accessors"][0]["byteOffset"] = 12
    if damage == "view_overrun":
        document["bufferViews"][0]["byteLength"] = len(binary) + 1
    if damage == "zero_count":
        document["accessors"][0]["count"] = 0
    path = save_glb(tmp_path / "bad-accessor.glb", document, binary)
    with pytest.raises(ValueError):
        list(MODULE.StaticGLB(path).primitives())


@pytest.mark.parametrize(
    "damage", ["animation", "node_skin", "instancing", "sparse", "external_buffer"]
)
def test_unsupported_deformation_or_external_geometry_is_rejected(tmp_path, damage):
    document, binary = fixture()
    if damage == "animation":
        document["animations"] = [{"channels": [], "samplers": []}]
    if damage == "node_skin":
        document["nodes"][0]["skin"] = 0
    if damage == "instancing":
        document["nodes"][0]["extensions"] = {"EXT_mesh_gpu_instancing": {}}
    if damage == "sparse":
        document["accessors"][0]["sparse"] = {}
    if damage == "external_buffer":
        document["buffers"][0]["uri"] = "geometry.bin"
    path = save_glb(tmp_path / "unsupported.glb", document, binary)
    with pytest.raises(ValueError):
        list(MODULE.StaticGLB(path).primitives())


def test_chunk_overrun_invalid_quaternion_and_cyclic_or_reused_nodes_fail(tmp_path):
    document, binary = fixture()
    path = save_glb(tmp_path / "truncated.glb", document, binary)
    damaged = bytearray(path.read_bytes())
    struct.pack_into("<I", damaged, 12, len(damaged))
    path.write_bytes(damaged)
    with pytest.raises(ValueError, match="chunk length"):
        MODULE.StaticGLB(path)
    for name, changed in (
        ("bad-quaternion", {"mesh": 0, "rotation": [0, 0, 0, 0]}),
        ("cyclic", {"mesh": 0, "children": [0]}),
    ):
        current = copy.deepcopy(document)
        current["nodes"] = [changed]
        path = save_glb(tmp_path / (name + ".glb"), current, binary)
        with pytest.raises(ValueError):
            list(MODULE.StaticGLB(path).primitives())
    document["scenes"][0]["nodes"] = [0, 0]
    path = save_glb(tmp_path / "reused.glb", document, binary)
    with pytest.raises(ValueError, match="multiple parents"):
        list(MODULE.StaticGLB(path).primitives())
