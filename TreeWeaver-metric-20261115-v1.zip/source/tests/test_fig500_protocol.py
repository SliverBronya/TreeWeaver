"""Frozen split isolation and valid supervision for the local synthetic loader."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers" / "tree_models"))
from fig500_dataset import Fig500Multi  # noqa: E402


def make_data(tmp_path):
    (tmp_path / "meta").mkdir()
    (tmp_path / "images").mkdir()
    records = []
    for i, asset in enumerate(["a", "b", "c"], 1):
        records.append({"id": i})
        meta = {"trees": [asset], "layer_order_front_to_back": [asset]}
        (tmp_path / "meta" / f"{i:06d}.json").write_text(json.dumps(meta))
        cv2.imwrite(str(tmp_path / "images" / f"{i:06d}.png"), np.zeros((32, 48, 3), np.uint8))
        directory = tmp_path / "masks" / f"{i:06d}"
        directory.mkdir(parents=True)
        mask = np.zeros((16, 24), np.uint8)
        mask[4:16, 6:24] = 255
        for kind in ("amodal", "visible"):
            cv2.imwrite(str(directory / f"{kind}_1.png"), mask)
    (tmp_path / "index.json").write_text(json.dumps({"records": records}))
    manifest = {
        "schema_version": "treeweaver-image-splits-1.0",
        "splits": {"train": [1], "validation": [2], "test": [3]},
        "asset_pools": {"train": ["a"], "validation": ["b"], "test": ["c"]},
    }
    return manifest


def test_frozen_test_and_unknown_stem_channel(tmp_path):
    manifest = make_data(tmp_path)
    (tmp_path / "splits.json").write_text(json.dumps(manifest))
    dataset = Fig500Multi(tmp_path, "test", size=64, mask_size=16)
    assert [record["id"] for record in dataset.items] == [3]
    sample = dataset.sample(0)
    assert dataset.split_independence_verified
    assert sample["visibility"].tolist() == [[1.0, 0.0]]
    assert sample["visibility_valid"].tolist() == [[True, False]]
    assert np.max(sample["boxes"]) <= 64
    assert "splits.json" in sample["split_origin"]


@pytest.mark.parametrize(
    "problem", ["duplicate", "unknown", "missing", "asset_overlap", "wrong_asset"]
)
def test_frozen_manifest_rejects_leakage_and_drift(tmp_path, problem):
    manifest = make_data(tmp_path)
    if problem == "duplicate":
        manifest["splits"]["validation"] = [1, 2]
    elif problem == "unknown":
        manifest["splits"]["test"] = [4]
    elif problem == "missing":
        manifest["splits"]["test"] = []
    elif problem == "asset_overlap":
        manifest["asset_pools"]["validation"].append("a")
    else:
        manifest["asset_pools"]["test"] = ["other"]
    (tmp_path / "splits.json").write_text(json.dumps(manifest))
    with pytest.raises(ValueError):
        Fig500Multi(tmp_path, "test")


def test_legacy_never_manufactures_a_test_split(tmp_path):
    make_data(tmp_path)
    with pytest.raises(FileNotFoundError):
        Fig500Multi(tmp_path, "test")
    dataset = Fig500Multi(tmp_path, "validation", val_fraction=0.34)
    assert dataset.split_origin == "legacy_random_image_split_not_independent_test"
    assert not dataset.split_independence_verified


def test_image_ids_only_manifest_does_not_claim_asset_isolation(tmp_path):
    manifest = make_data(tmp_path)
    del manifest["asset_pools"]
    (tmp_path / "splits.json").write_text(json.dumps(manifest))
    dataset = Fig500Multi(tmp_path, "validation")
    assert not dataset.split_independence_verified
