import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from treeweaver.reconstruction.model import CameraPose, Reconstruction, SparsePoint
from treeweaver.reconstruction.quality import assess_reconstruction_quality, write_quality_report


def _pose(index: int) -> CameraPose:
    return CameraPose(index, 1, f"{index}.jpg", np.eye(3), np.array([-index, 0.0, 0.0]))


class ReconstructionQualityTests(unittest.TestCase):
    def test_good_reconstruction_passes(self) -> None:
        rng = np.random.default_rng(21)
        points = tuple(
            SparsePoint(index, rng.normal(size=3), 0.4 + index / 1000, 4) for index in range(150)
        )
        report = assess_reconstruction_quality(
            Reconstruction(tuple(map(_pose, range(4))), points), 4
        )
        self.assertTrue(report.passed)
        self.assertEqual(report.registration_ratio, 1.0)
        self.assertFalse(report.issues)

    def test_weak_reconstruction_lists_all_failed_gates(self) -> None:
        point = SparsePoint(1, np.zeros(3), 5.0, 1)
        report = assess_reconstruction_quality(Reconstruction((_pose(0),), (point,)), 10)
        self.assertFalse(report.passed)
        self.assertGreaterEqual(len(report.issues), 5)

    def test_empty_metrics_are_serialized_as_strict_json_null(self) -> None:
        report = assess_reconstruction_quality(Reconstruction((_pose(0),), ()), 2)
        with tempfile.TemporaryDirectory() as temporary:
            path = write_quality_report(report, Path(temporary) / "quality.json")
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.assertIsNone(payload["median_reprojection_error_px"])


if __name__ == "__main__":
    unittest.main()
