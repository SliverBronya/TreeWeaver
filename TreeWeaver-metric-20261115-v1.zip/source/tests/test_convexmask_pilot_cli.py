"""The pilot must never silently substitute random weights for a missing checkpoint."""

import subprocess
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "pilot_convexmask.py"


def test_missing_checkpoint_fails_before_importing_external_runtime(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "convexmask.py").write_text("# placeholder source", encoding="utf-8")
    output = tmp_path / "output"
    result = subprocess.run(
        [
            sys.executable, str(SCRIPT), "--source", str(source),
            "--extra-packages", str(tmp_path / "packages"),
            "--images", str(tmp_path / "image.jpg"), "--output", str(output),
            "--checkpoint", str(tmp_path / "missing.pth"),
        ], capture_output=True, text=True, check=False,
    )
    assert result.returncode == 2
    assert "no random-weight fallback" in result.stderr
    assert not output.exists()


def test_requires_explicit_smoke_or_trained_mode() -> None:
    result = subprocess.run(
        [sys.executable, str(SCRIPT)], capture_output=True, text=True, check=False,
    )
    assert result.returncode == 2
    assert "required" in result.stderr
