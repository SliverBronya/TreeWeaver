import pytest

from treeweaver.forestry.diameter_position import (
    DiameterCase,
    StemFormEvidence,
    plan_diameter_measurement,
)


def test_standard_and_leaning_tree_use_stem_path() -> None:
    plan = plan_diameter_measurement(StemFormEvidence(leaning=True, sloping_ground=True))
    assert plan.case is DiameterCase.STANDARD
    assert plan.planes[0].height_along_stem_m == 1.3
    assert plan.distance_reference == "along_leaning_stem_axis"
    assert plan.ground_reference == "uphill_ground_contact"


def test_low_and_mid_forks_become_separate_tree_entities() -> None:
    low = plan_diameter_measurement(StemFormEvidence(fork_origin_m=0.2, stem_count_above_fork=3))
    mid = plan_diameter_measurement(StemFormEvidence(fork_origin_m=0.8, stem_count_above_fork=2))
    assert low.case is DiameterCase.LOW_FORK
    assert low.entity_count == 3
    assert [item.height_along_stem_m for item in low.planes] == [1.3, 1.3, 1.3]
    assert mid.case is DiameterCase.MID_FORK
    assert [item.height_along_stem_m for item in mid.planes] == [1.8, 1.8]


def test_fork_at_breast_height_moves_plane_below_swelling() -> None:
    plan = plan_diameter_measurement(
        StemFormEvidence(fork_origin_m=1.36, stem_count_above_fork=2)
    )
    assert plan.case is DiameterCase.FORK_AT_BREAST_HEIGHT
    assert plan.entity_count == 1
    assert plan.planes[0].height_along_stem_m == pytest.approx(1.26)


def test_buttress_aerial_roots_and_irregular_section_move_measurement() -> None:
    buttress = plan_diameter_measurement(StemFormEvidence(buttress_top_m=1.1))
    aerial = plan_diameter_measurement(StemFormEvidence(aerial_root_top_m=0.7))
    irregular = plan_diameter_measurement(
        StemFormEvidence(irregularity_interval_m=(1.15, 1.45))
    )
    assert buttress.case is DiameterCase.BUTTRESS
    assert buttress.planes[0].height_along_stem_m == pytest.approx(1.4)
    assert aerial.case is DiameterCase.AERIAL_ROOTS
    assert aerial.planes[0].height_along_stem_m == pytest.approx(2.0)
    assert irregular.case is DiameterCase.IRREGULAR_AT_BREAST_HEIGHT
    assert irregular.planes[0].height_along_stem_m == pytest.approx(1.55)


def test_conflicting_special_forms_fail_closed() -> None:
    with pytest.raises(ValueError, match="expert review"):
        plan_diameter_measurement(
            StemFormEvidence(fork_origin_m=0.7, stem_count_above_fork=2, buttress_top_m=1.0)
        )
