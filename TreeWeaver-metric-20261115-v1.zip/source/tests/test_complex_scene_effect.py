import json
from pathlib import Path

import numpy as np

from treeweaver.association.root_bundle import separate_root_bundle
from treeweaver.measurement.bundle import measure_semantic_bundle
from treeweaver.semantics.root_refinement import refine_semantic_bundle_by_roots


def _trunk(x_value: float, radius: float) -> np.ndarray:
    angles, heights = np.meshgrid(
        np.linspace(0, 2 * np.pi, 36, endpoint=False),
        np.linspace(0, 3.0, 31),
    )
    return np.column_stack(
        (
            x_value + radius * np.cos(angles).ravel(),
            radius * np.sin(angles).ravel(),
            heights.ravel(),
        )
    )


def _crown(x_value: float) -> np.ndarray:
    azimuth, height = np.meshgrid(
        np.linspace(0, 2 * np.pi, 36, endpoint=False),
        np.linspace(-0.95, 0.95, 17),
    )
    horizontal_radius = 0.8 * np.sqrt(np.maximum(0.0, 1 - height**2))
    return np.column_stack(
        (
            x_value + horizontal_radius.ravel() * np.cos(azimuth).ravel(),
            horizontal_radius.ravel() * np.sin(azimuth).ravel(),
            4.0 + height.ravel(),
        )
    )


def test_touching_tree_pipeline_recovers_separate_dbh(tmp_path: Path) -> None:
    left_trunk = _trunk(-0.7, 0.15)
    right_trunk = _trunk(0.7, 0.23)
    left_crown = _crown(-0.45)
    right_crown = _crown(0.45)
    shared = np.column_stack(
        (
            np.zeros(20),
            np.linspace(-0.3, 0.3, 20),
            np.linspace(3.7, 4.3, 20),
        )
    )
    grid_x, grid_y = np.meshgrid(np.linspace(-2, 2, 15), np.linspace(-2, 2, 15))
    ground = np.column_stack((grid_x.ravel(), grid_y.ravel(), np.zeros(grid_x.size)))
    point_groups = (left_trunk, right_trunk, left_crown, right_crown, shared, ground)
    points = np.vstack(point_groups)
    offsets = np.cumsum([0, *(len(group) for group in point_groups)])
    cloud = tmp_path / "touching-trees.npz"
    np.savez_compressed(cloud, points=points)

    semantics = tmp_path / "merged-semantics"
    semantics.mkdir()
    trunk_indices = np.arange(offsets[0], offsets[2], dtype=np.int64)
    crown_indices = np.arange(offsets[2], offsets[5], dtype=np.int64)
    ground_indices = np.arange(offsets[5], offsets[6], dtype=np.int64)
    np.savez_compressed(
        semantics / "semantic-points.npz",
        trunk_indices=trunk_indices,
        trunk_offsets=np.array([0, len(trunk_indices)]),
        trunk_reliability=np.full(len(trunk_indices), 0.95),
        crown_indices=crown_indices,
        crown_offsets=np.array([0, len(crown_indices)]),
        crown_reliability=np.full(len(crown_indices), 0.85),
        ambiguous_indices=np.empty(0, dtype=np.int64),
        ambiguous_offsets=np.array([0, 0]),
        unclassified_indices=np.empty(0, dtype=np.int64),
        unclassified_offsets=np.array([0, 0]),
        ground_indices=ground_indices,
        ground_reliability=np.full(len(ground_indices), 0.95),
        trunk_view_indices=trunk_indices,
        trunk_view_offsets=np.array([0, len(trunk_indices)]),
    )
    (semantics / "semantics.json").write_text(
        json.dumps(
            {
                "schema_version": "semantic-tracks-1.0",
                "ground_confidence": 0.95,
                "ground_contributing_views": 3,
                "trunk_view_sections": [
                    {"track_id": 1, "view_id": "merged", "reliability": 0.9}
                ],
                "tracks": [{"track_id": 1, "semantic_confidence": 0.9}],
            }
        ),
        encoding="utf-8",
    )
    roots = tmp_path / "roots.json"
    roots.write_text(
        json.dumps(
            {
                "schema_version": "root-anchors-1.0",
                "up": [0, 0, 1],
                "roots": [
                    {"tree_id": 101, "position": [-0.7, 0, 0]},
                    {"tree_id": 202, "position": [0.7, 0, 0]},
                ],
            }
        ),
        encoding="utf-8",
    )
    candidates = tmp_path / "candidates.npz"
    np.savez_compressed(
        candidates,
        candidate_indices=np.arange(offsets[5], dtype=np.int64),
    )

    separated = separate_root_bundle(
        cloud,
        roots,
        tmp_path / "root-assignment",
        trunk_probability_npz=semantics / "semantic-points.npz",
        candidate_indices_npz=candidates,
        maximum_edge_length=0.32,
        maximum_root_distance=0.25,
        neighbor_count=12,
        ambiguity_ratio=0.08,
    )
    refined = refine_semantic_bundle_by_roots(
        semantics, separated.output_directory, tmp_path / "root-semantics"
    )
    measured = measure_semantic_bundle(
        cloud,
        refined.output_directory,
        tmp_path / "measurements.json",
        metres_per_unit=1.0,
        up_hint=(0, 0, 1),
    )

    assert measured.successful_trees == 2
    assert refined.excluded_ambiguous_points > 0
    payload = json.loads(measured.output_path.read_text())
    dbh = {item["track_id"]: item["dbh"]["value"] for item in payload["trees"]}
    assert abs(dbh[101] - 30.0) < 1.0
    assert abs(dbh[202] - 46.0) < 1.0
