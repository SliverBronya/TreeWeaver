import csv
import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from treeweaver.io.raw_capture import (
    RawCameraMetadata,
    effective_video_intrinsics,
    ingest_raw_capture,
)
from treeweaver.io.session import load_capture_session


class RawCaptureTests(unittest.TestCase):
    def test_center_crop_intrinsics(self) -> None:
        camera = RawCameraMetadata(
            source="camera2_calibration",
            intrinsic_calibration=(50, 52, 50, 40, 0),
            focal_length_mm=None,
            active_left=0,
            active_top=0,
            active_width=100,
            active_height=80,
            sensor_width_mm=None,
            sensor_height_mm=None,
        )
        result = effective_video_intrinsics(camera, 100, 50)
        self.assertEqual(result.fx, 50)
        self.assertEqual(result.fy, 52)
        self.assertEqual(result.cx, 50)
        self.assertEqual(result.cy, 25)

    def test_ingests_video_and_synchronizes_imu(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            video = root / "video.mp4"
            writer = cv2.VideoWriter(str(video), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (64, 48))
            self.assertTrue(writer.isOpened())
            for index in range(30):
                image = np.zeros((48, 64, 3), dtype=np.uint8)
                cv2.line(image, (index % 64, 0), (index % 64, 47), (255, 255, 255), 2)
                writer.write(image)
            writer.release()

            start = 1_000_000_000
            with (root / "imu.csv").open("w", newline="", encoding="utf-8") as handle:
                output = csv.writer(handle)
                output.writerow(["timestamp_ns", "sensor", "x", "y", "z"])
                for index in range(60):
                    output.writerow([start + index * 50_000_000, 1, 0, 9.8, 0])

            raw = {
                "schema_version": "raw-1.0",
                "session_id": "phone-session",
                "video_path": "video.mp4",
                "imu_path": "imu.csv",
                "recording_monotonic_start_ns": start,
                "device_manufacturer": "test",
                "device_model": "phone",
                "has_imu": True,
                "camera": {
                    "camera_id": "0",
                    "intrinsics_source": "camera2_calibration",
                    "intrinsic_calibration": [80, 80, 50, 40, 0],
                    "active_width": 100,
                    "active_height": 80,
                },
                "scale_anchor": {"kind": "coded_marker", "metric_length_m": 1.0},
            }
            manifest = root / "capture.json"
            manifest.write_text(json.dumps(raw), encoding="utf-8")
            result = ingest_raw_capture(manifest, root / "processed", sample_hz=2)
            self.assertGreaterEqual(result.frame_count, 5)
            self.assertEqual(result.imu_sample_count, 60)
            loaded = load_capture_session(result.manifest_path)
            self.assertEqual(loaded.session.frames[0].timestamp_ns, start)
            self.assertIsNone(loaded.session.anchors[0].reconstructed_length)


if __name__ == "__main__":
    unittest.main()
