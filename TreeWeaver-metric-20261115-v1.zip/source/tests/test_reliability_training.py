import unittest

from treeweaver.reliability.baseline import ReliabilityFeatures
from treeweaver.reliability.training import (
    ReliabilityTrainingExample,
    fit_monotonic_reliability,
)


class ReliabilityTrainingTests(unittest.TestCase):
    def test_learns_monotonic_residual_reliability(self) -> None:
        examples = []
        for index in range(40):
            quality = index / 39
            features = ReliabilityFeatures(*(quality for _ in range(7)))
            examples.append(
                ReliabilityTrainingExample(
                    f"s{index}",
                    f"t{index}",
                    "train",
                    features,
                    0.2 if quality > 0.5 else 2.0,
                    True,
                )
            )
        model = fit_monotonic_reliability(tuple(examples))
        low = model.predict(ReliabilityFeatures(*(0.1 for _ in range(7))))
        high = model.predict(ReliabilityFeatures(*(0.9 for _ in range(7))))
        self.assertGreater(high, low)
        self.assertTrue(all(weight >= 0 for weight in model.weights))

    def test_rejects_in_sample_residual_labels(self) -> None:
        examples = tuple(
            ReliabilityTrainingExample(
                f"s{index}",
                f"t{index}",
                "train",
                ReliabilityFeatures(*(0.5 for _ in range(7))),
                float(index % 2),
                False,
            )
            for index in range(20)
        )
        with self.assertRaisesRegex(ValueError, "out-of-fold"):
            fit_monotonic_reliability(examples)


if __name__ == "__main__":
    unittest.main()
