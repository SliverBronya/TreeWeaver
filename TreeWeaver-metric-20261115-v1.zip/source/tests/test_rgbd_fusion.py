import numpy as np

from treeweaver.domain.models import CameraIntrinsics
from treeweaver.measurement.rgbd_tree import measure_fused_tree
from treeweaver.reconstruction.rgbd_fusion import (
    MetricRgbdObservation,
    backproject_tree,
    fuse_metric_rgbd,
)


def test_backprojects_metric_depth_and_applies_arcore_pose() -> None:
    intrinsics = CameraIntrinsics(100, 100, 1, 1, 3, 3)
    depth = np.full((3, 3), 2.0)
    mask = np.zeros((3, 3), dtype=bool)
    mask[1, 1] = True
    transform = np.eye(4)
    transform[:3, 3] = (1, 2, 3)
    observation = MetricRgbdObservation("f1", depth, mask, intrinsics, transform)

    points, confidence, _ = backproject_tree(observation)

    np.testing.assert_allclose(points, [[1, 2, 5]])
    np.testing.assert_allclose(confidence, [1])


def test_voxel_fusion_counts_independent_views() -> None:
    intrinsics = CameraIntrinsics(100, 100, 1, 1, 3, 3)
    depth = np.full((3, 3), 2.0)
    mask = np.zeros((3, 3), dtype=bool)
    mask[1, 1] = True
    identity = np.eye(4)
    observations = tuple(
        MetricRgbdObservation(f"f{index}", depth, mask, intrinsics, identity)
        for index in range(2)
    )

    result = fuse_metric_rgbd(observations, voxel_size_m=0.05, minimum_views=2)

    np.testing.assert_allclose(result.points_world, [[0, 0, 2]])
    np.testing.assert_array_equal(result.view_count, [2])


def test_rejects_non_rigid_arcore_pose() -> None:
    intrinsics = CameraIntrinsics(100, 100, 1, 1, 3, 3)
    invalid = np.eye(4)
    invalid[0, 0] = 2
    try:
        MetricRgbdObservation(
            "bad",
            np.ones((3, 3)),
            np.ones((3, 3), dtype=bool),
            intrinsics,
            invalid,
        )
    except ValueError as error:
        assert "orthonormal" in str(error)
    else:
        raise AssertionError("non-rigid pose was accepted")


def test_gravity_aligned_geometry_recovers_synthetic_tree() -> None:
    angles = np.linspace(0, 2 * np.pi, 72, endpoint=False)
    trunk_heights = np.linspace(0, 4.0, 161)
    trunk = np.array(
        [
            [0.15 * np.cos(angle), height, 0.15 * np.sin(angle)]
            for height in trunk_heights
            for angle in angles
        ]
    )
    crown_heights = np.linspace(2.0, 5.0, 61)
    crown = np.array(
        [
            [1.5 * np.cos(angle), height, 1.0 * np.sin(angle)]
            for height in crown_heights
            for angle in angles
        ]
    )

    result = measure_fused_tree(np.vstack((trunk, crown)))

    assert abs(result.height_m - 5.0) < 0.1
    assert abs(result.dbh_cm - 30.0) < 0.5
    assert 2.9 < result.crown_width_m < 3.1
