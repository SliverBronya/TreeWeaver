package org.treeweaver.capture;

import android.content.Context;
import android.os.Build;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.util.UUID;

final class SessionRecorder {
    private final Context context;
    private final SensorRecorder sensors;
    private File directory;
    private long startedUnixMs;

    SessionRecorder(Context context) {
        this.context = context;
        this.sensors = new SensorRecorder(context);
    }

    File begin(String anchorKind, double anchorLengthM, int markerId) throws Exception {
        String id = UUID.randomUUID().toString();
        directory = new File(context.getExternalFilesDir(null), "sessions/" + id);
        if (!directory.mkdirs()) throw new IllegalStateException("Cannot create session directory");
        startedUnixMs = System.currentTimeMillis();
        sensors.start(new File(directory, "imu.csv"));

        JSONObject manifest = new JSONObject();
        manifest.put("schema_version", "raw-1.0");
        manifest.put("session_id", id);
        manifest.put("started_unix_ms", startedUnixMs);
        manifest.put("video_path", "video.mp4");
        manifest.put("imu_path", "imu.csv");
        manifest.put("device_manufacturer", Build.MANUFACTURER);
        manifest.put("device_model", Build.MODEL);
        manifest.put("android_api", Build.VERSION.SDK_INT);
        manifest.put("has_imu", sensors.hasImu());
        manifest.put("has_arcore", false);
        manifest.put("has_metric_depth", false);
        manifest.put("camera", CameraMetadataReader.readBackCamera(context));
        JSONObject anchor = new JSONObject();
        anchor.put("kind", anchorKind);
        anchor.put("metric_length_m", anchorLengthM);
        if (anchorKind.equals("coded_marker")) {
            anchor.put("marker_family", "aruco");
            anchor.put("dictionary", "4x4_50");
            anchor.put("marker_id", markerId);
        }
        manifest.put("scale_anchor", anchor);
        writeJson(new File(directory, "capture.json"), manifest);
        return new File(directory, "video.mp4");
    }

    File finish() throws Exception {
        sensors.stop();
        File manifestFile = new File(directory, "capture.json");
        JSONObject manifest = new JSONObject(
                new String(java.nio.file.Files.readAllBytes(manifestFile.toPath())));
        manifest.put("finished_unix_ms", System.currentTimeMillis());
        manifest.put("duration_ms", System.currentTimeMillis() - startedUnixMs);
        writeJson(manifestFile, manifest);
        return directory;
    }

    void markVideoStarted() throws Exception {
        File manifestFile = new File(directory, "capture.json");
        JSONObject manifest = new JSONObject(
                new String(java.nio.file.Files.readAllBytes(manifestFile.toPath())));
        manifest.put("recording_monotonic_start_ns", SystemClock.elapsedRealtimeNanos());
        writeJson(manifestFile, manifest);
    }

    void abort() {
        sensors.stop();
    }

    private static void writeJson(File file, JSONObject value) throws Exception {
        try (FileWriter writer = new FileWriter(file, false)) {
            writer.write(value.toString(2));
        }
    }
}
