package org.treeweaver.capture;

import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.graphics.Rect;
import android.util.Size;
import android.util.SizeF;

import org.json.JSONArray;
import org.json.JSONObject;

final class CameraMetadataReader {
    private CameraMetadataReader() { }

    static JSONObject readBackCamera(Context context) throws Exception {
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;
            JSONObject result = new JSONObject();
            result.put("camera_id", id);
            float[] intrinsic = c.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION);
            if (intrinsic != null && intrinsic.length >= 5) {
                JSONArray values = new JSONArray();
                for (float value : intrinsic) values.put(value);
                result.put("intrinsic_calibration", values);
            }
            float[] focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            if (focal != null && focal.length > 0) result.put("focal_length_mm", focal[0]);
            Size pixelArray = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
            if (pixelArray != null) {
                result.put("pixel_array_width", pixelArray.getWidth());
                result.put("pixel_array_height", pixelArray.getHeight());
            }
            Rect active = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            if (active != null) {
                result.put("active_left", active.left);
                result.put("active_top", active.top);
                result.put("active_width", active.width());
                result.put("active_height", active.height());
            }
            SizeF physical = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            if (physical != null) {
                result.put("sensor_width_mm", physical.getWidth());
                result.put("sensor_height_mm", physical.getHeight());
            }
            result.put("intrinsics_source", intrinsic == null ? "focal_metadata" : "camera2_calibration");
            return result;
        }
        throw new IllegalStateException("No back-facing camera available");
    }
}
