package org.treeweaver.capture;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;

final class SensorRecorder implements SensorEventListener {
    private final SensorManager manager;
    private BufferedWriter writer;

    SensorRecorder(Context context) {
        manager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    }

    boolean hasImu() {
        return manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
                && manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null;
    }

    void start(File output) throws IOException {
        writer = new BufferedWriter(new FileWriter(output));
        writer.write("timestamp_ns,sensor,x,y,z\n");
        register(Sensor.TYPE_ACCELEROMETER);
        register(Sensor.TYPE_GYROSCOPE);
        register(Sensor.TYPE_ROTATION_VECTOR);
    }

    private void register(int type) {
        Sensor sensor = manager.getDefaultSensor(type);
        if (sensor != null) {
            manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    void stop() {
        manager.unregisterListener(this);
        if (writer != null) {
            try { writer.close(); } catch (IOException ignored) { }
            writer = null;
        }
    }

    @Override public void onSensorChanged(SensorEvent event) {
        BufferedWriter active = writer;
        if (active == null || event.values.length < 3) return;
        try {
            active.write(String.format(Locale.US, "%d,%d,%.8f,%.8f,%.8f\n",
                    event.timestamp, event.sensor.getType(),
                    event.values[0], event.values[1], event.values[2]));
        } catch (IOException ignored) {
            stop();
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}

