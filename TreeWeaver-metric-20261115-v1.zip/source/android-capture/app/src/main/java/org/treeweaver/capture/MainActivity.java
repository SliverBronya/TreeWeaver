package org.treeweaver.capture;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;

public final class MainActivity extends AppCompatActivity {
    private PreviewView previewView;
    private TextView statusText;
    private Button recordButton;
    private EditText anchorLength;
    private EditText markerId;
    private Spinner anchorType;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private SessionRecorder sessionRecorder;

    private final ActivityResultLauncher<String> permission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) bindCamera();
                else statusText.setText("需要相机权限才能采集树木视频。");
            });

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        previewView = findViewById(R.id.preview);
        statusText = findViewById(R.id.statusText);
        recordButton = findViewById(R.id.recordButton);
        anchorLength = findViewById(R.id.anchorLength);
        markerId = findViewById(R.id.markerId);
        anchorType = findViewById(R.id.anchorType);
        sessionRecorder = new SessionRecorder(this);
        recordButton.setOnClickListener(view -> toggleRecording());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) bindCamera();
        else permission.launch(Manifest.permission.CAMERA);
    }

    private void bindCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.HD)).build();
                videoCapture = VideoCapture.withOutput(recorder);
                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture);
                recordButton.setEnabled(true);
            } catch (Exception error) {
                statusText.setText("相机启动失败：" + error.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void toggleRecording() {
        if (recording != null) {
            recording.stop();
            recordButton.setEnabled(false);
            return;
        }
        if (videoCapture == null) return;
        try {
            double length = Double.parseDouble(anchorLength.getText().toString());
            if (length <= 0) throw new NumberFormatException();
            int selectedMarkerId = Integer.parseInt(markerId.getText().toString());
            if (selectedMarkerId < 0) throw new NumberFormatException();
            String kind = anchorType.getSelectedItem().toString();
            File video = sessionRecorder.begin(kind, length, selectedMarkerId);
            PendingRecording pending = videoCapture.getOutput()
                    .prepareRecording(this, new FileOutputOptions.Builder(video).build());
            recording = pending.start(ContextCompat.getMainExecutor(this), event -> {
                if (event instanceof VideoRecordEvent.Start) {
                    try {
                        sessionRecorder.markVideoStarted();
                    } catch (Exception error) {
                        recording.stop();
                        statusText.setText("无法记录同步时间，采集已停止。");
                        return;
                    }
                    statusText.setText("正在采集：缓慢移动，覆盖树根、胸高位置和树梢。");
                    recordButton.setText(R.string.stop_capture);
                } else if (event instanceof VideoRecordEvent.Finalize) {
                    finalizeSession((VideoRecordEvent.Finalize) event);
                }
            });
        } catch (Exception error) {
            sessionRecorder.abort();
            Toast.makeText(this, "无法开始：请检查尺度长度", Toast.LENGTH_LONG).show();
        }
    }

    private void finalizeSession(VideoRecordEvent.Finalize event) {
        recording = null;
        recordButton.setEnabled(true);
        recordButton.setText(R.string.start_capture);
        if (event.hasError()) {
            sessionRecorder.abort();
            statusText.setText("视频保存失败，请重新采集。");
            return;
        }
        try {
            File directory = sessionRecorder.finish();
            statusText.setText("采集完成，已保存可验证的原始观测包。");
            Toast.makeText(this, directory.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            statusText.setText("元数据保存失败：" + error.getMessage());
        }
    }

    @Override protected void onDestroy() {
        if (recording != null) recording.stop();
        sessionRecorder.abort();
        super.onDestroy();
    }
}
