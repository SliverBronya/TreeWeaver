# TreeWeaver Capture for Android

The current CameraX recorder is the RGB-only fallback. It records an ordinary
video, timestamped IMU samples, camera calibration metadata, and an explicit
metric-scale anchor. The new preferred capture contract is
`contracts/capture-session.v2.schema.json`: an ARCore capture implementation
must save aligned RGB, metric depth, confidence, per-frame intrinsics,
camera-to-world pose, gravity, tracking state, and timestamps. In that mode no
manual metric-scale anchor is required.

For automatic metric registration, print a TreeWeaver marker at 100% scale,
select `coded_marker`, enter its outer-edge length in metres and keep marker ID
7 visible from several angles. The raw manifest records the marker family,
dictionary, ID, and physical length so reconstruction can triangulate it.

The output is a private app directory:

```text
sessions/<uuid>/
  capture.json
  video.mp4
  imu.csv
```

`capture.json` uses the `raw-1.0` contract. The backend ingestion stage will
extract quality-controlled key frames, compute their effective intrinsics, and
produce `capture-session.v1`.

Open `android-capture` in Android Studio or run `gradlew assembleDebug` with
JDK 17 and Android SDK 34 available. No signing credentials are stored here.
