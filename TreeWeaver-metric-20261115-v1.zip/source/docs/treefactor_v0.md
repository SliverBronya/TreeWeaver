# TreeFactor v0

TreeFactor is the first project-owned inference component. It does not replace
segmentation or reconstruction networks. It consumes their uncertain 3-D
observations and solves one coupled tree-specific estimation problem.

## Joint state

The optimized state is

`x = [log(scale), root_xyz, trunk_axis_xyz, log(radius_1.3m), taper, log(height)]`.

Log parameters enforce positive scale, radius, and height. The current factor
graph combines:

- explicit metric-anchor factors;
- local ground coplanarity and root-contact factors;
- a tapered-cylinder trunk surface factor;
- trunk-axis and unit-vector priors;
- a robust crown-top height factor;
- below-ground and positive-radius constraints;
- optional view-specific breast-height cross-section factors, each retaining
  its fit error, angular coverage, source view, and semantic reliability.

Metric anchors are treated as Gaussian constraints after robust scale-anchor
screening. No global robust loss is applied to them. Ground and trunk residuals
use a soft-L1 transform individually, followed by observation reliability
weighting. This distinction prevents thousands of uncertain surface points
from voting away the small number of measurements that establish absolute
scale.

## Reproducible command

The input NPZ contains `trunk_points`, `crown_points`, and `ground_points` in
reconstruction coordinates. It may also contain `trunk_reliability` and
`ground_reliability`, with values in `(0, 1]`.

The anchor JSON schema is:

```json
{
  "schema_version": "treefactor-anchors-1.0",
  "anchors": [
    {
      "kind": "one_metre_marker",
      "metric_length_m": 1.0,
      "endpoint_a": [0.0, 0.0, 0.0],
      "endpoint_b": [2.5, 0.0, 0.0],
      "confidence": 1.0
    }
  ]
}
```

Run:

```powershell
treeweaver optimize-treefactor tree.npz anchors.json result.json
```

After multi-view association and semantic fusion, run the same joint optimizer
over every persistent tree track:

```powershell
treeweaver optimize-factor-tracks fused.ply semantics-run anchors.json factor-results.json
```

The batch command derives a local ground neighborhood for each tree using the
robust initial anchor scale. Each track is isolated: invalid or insufficient
geometry is recorded as a failure without discarding measurements for the
other trees. Track-level semantic confidence and ground-fusion confidence enter
the corresponding observation weights.

Semantic fusion also preserves the 3-D trunk points supported by each
individual view. The batch optimizer automatically slices a breast-height
band, projects it into the local plane normal to the initial trunk axis,
robustly fits a circle or ellipse, discounts partial angular coverage, and adds
the resulting radius observation to the joint solve. This prevents a merged
point cloud from hiding disagreement between a clean side view and an occluded
view. Omitting these per-view arrays recovers the merged-surface-only ablation.

The result records the complete 10-by-10 local covariance, convergence
statistics, scale, height, DBH, taper, root, axes, and diagnostics. It also
integrates the fitted linear-radius solid to produce geometric stem volume and
propagates joint covariance into volume uncertainty. That volume is explicitly
labelled as having no species form factor: it is an auditable geometric result,
not yet a forestry merchantable-volume estimate. Existing output files are
never overwritten.

## What is and is not yet evidence

Deterministic synthetic tests currently verify recovery from a reconstruction
scaled by an unknown factor and resistance to low-reliability trunk outliers.
This proves implementation consistency; it does not prove field accuracy or
calibrated uncertainty.

The next scientific tests must compare joint and sequential estimation under:

1. anchor noise and wrong anchors;
2. partial trunk arcs and occlusion;
3. biased segmentation and depth;
4. sloped ground and leaning trunks;
5. different phones, species, sites, and operators.

A publishable claim requires preregistered train/validation/test splits,
laser/tape reference measurements, ablations for every factor, confidence
interval coverage, and external-site validation. The current covariance is a
local Jacobian approximation; bootstrap or sandwich uncertainty and empirical
calibration remain required.
