# Fig synthetic data v3: generation and checks

This pipeline replaces the old Fig500 generator for **new data only**. It does
not overwrite, re-label, or train on historical evaluation-only datasets.
`20260411` and `fig-hard-holdout2-2026-11-01` remain evaluation-only under
`configs/research/dataset-usage-2026-11-01.json`.

## Freeze the split before rendering

```powershell
.venv/Scripts/python.exe scripts/audit_fig_data.py plan `
  --assets tools/assets/sketchfab/fig_trees --seed 20261101 `
  --output reports/fig-v3-frozen-plan-2026-11-01.json
```

The plan has 400 training, 50 validation and 50 test scene specifications.
The 29 current GLB assets are separated into pools of 19 / 5 / 5; each scene
uses assets from only its own pool. The plan contains per-scene seeds and
asset SHA-256 hashes. At least 12 distinct assets are required so every split
can contain four-tree scenes. Reusing one GLB with a different transform does
not create a new asset identity.

The plan is a specification, not a claim that 500 images exist. The smoke run
below renders six selected scenes, and its `splits.json` is marked incomplete.
Future held-out evaluation of models trained on the original Fig500 must still
account for the fact that those old models have already seen all 29 assets.
These new pools are asset-disjoint only for **future training from an appropriate
baseline**, not retroactively unseen by the existing five-hour checkpoint.

## Small end-to-end rendering smoke

Use a new output directory. The generator refuses a nonempty output directory
and refuses `FIG_MASKS_ONLY=1`, which could otherwise attach new labels to old RGB.

```powershell
$env:FIG_PLAN='D:/TreeWeaver/reports/fig-v3-frozen-plan-2026-11-01.json'
$env:FIG_IDS='1,2,401,402,451,452'
$env:FIG_LIMIT='0'
$env:FIG_OUT='D:/TreeWeaver/reports/fig-v3-split-smoke-2026-11-01'
$env:FIG_RES_X='640'; $env:FIG_RES_Y='360'
$env:FIG_MASK_X='320'; $env:FIG_MASK_Y='180'
tools/blender-4.2.3-windows-x64/blender.exe -b --python-exit-code 1 `
  --python scripts/generate_fig_500.py
.venv/Scripts/python.exe scripts/postprocess_fig_500.py `
  --root reports/fig-v3-split-smoke-2026-11-01
.venv/Scripts/python.exe scripts/audit_fig_data.py audit `
  --root reports/fig-v3-split-smoke-2026-11-01 `
  --output reports/fig-v3-split-smoke-2026-11-01/audit.json
```

The existing smoke directory is already populated. Choose a different new
directory to repeat the command. Use `--python-exit-code 1`: Blender otherwise
can return exit code zero after a Python exception.

## What the labels mean

- Horizontal placement and origin-depth order use independent random
  permutations. No input-object index is treated as a depth-order label.
- For each target, a **full-scene target-ID render** sets that target to white
  emission and other trees/ground to black emission. Original material alpha
  nodes and settings are copied to retain leaf-card transparency and holes.
  Non-target geometry remains present, so actual per-pixel rendering decides
  occlusion. This is not subtraction of whole-tree silhouettes by global rank.
- An isolated target-ID render provides the amodal support. This is synthetic
  complete geometry, not observed real-photo amodal truth.
- Premultiplied target contribution is `rendered_white_rgb * rendered_alpha`.
  Visible IDs use majority coverage (`>=0.5`); isolated support conservatively
  includes fractional alpha fringes (`>=1/16` with 16 EEVEE samples). Both
  thresholds and render settings are recorded. Thus visible and amodal support
  have deliberately different alpha rasterization thresholds.
- Full-scene ID contributions are resolved once by maximum contribution into
  mutually exclusive visible IDs; coverage below the threshold is background.
  Boundary ties resolve by object index. Raw `*_coverage_*.png` renders are
  retained for checking this convention.
- `layer_order_front_to_back` is **object-origin depth rank**, not guaranteed
  pairwise pixel order of all branches. Interpenetrating crowns can contain
  mixed foreground/background pixels. Do not train or report this rank as
  complete pixel-wise occlusion understanding.
- Postprocessing reads rendered visible labels and refuses legacy provenance.
  It verifies disjointness and containment, writes `instance_ids.png` and the
  colour ownership visualization, and records **all** unordered object pairs.

The visual domain still uses one fig species and simple ground/HDRI backgrounds.
These changes remove known shortcuts and label assumptions; they do not establish
urban-photo realism or measurement accuracy. Existing asset attribution remains
required (PlantCatalog fig assets, CC BY; environment sources as documented in
the original asset register / Fig500 credits).

## Actual checks completed on 2026-11-01

- Six rendered scenes: train 2 / validation 2 / test 2; 11 assets used, with
  no asset shared between the three rendered splits.
- All 18 unordered object pairs recorded; no duplicate/missing pairs.
- Every visible mask is contained in its recorded isolated support; visible
  ownership is mutually exclusive. `label_checks.json` records per-tree checks.
- Left-is-front shortcut baseline: 9 / 18 pairs (50%) in this smoke. This is
  an interface/data check, not a statistical generalization result.
- Six pure/CPU unit tests and Ruff on the changed generator/protocol scripts
  pass. No long training or full 500-scene generation was run.
- A first failed two-tree render is retained in
  `reports/fig-v3-id-smoke-2026-11-01`: using identical 0.5 thresholds for both
  outputs exposed transparent/antialias edge differences. It is not indexed,
  is not training data, and must not be mixed with the successful smoke.

Audit historical metadata without modifying it:

```powershell
.venv/Scripts/python.exe scripts/audit_fig_data.py audit `
  --root reports/fig-500-v2-2026-10-31 `
  --compare reports/fig-hard-holdout2-2026-11-01 `
  --output reports/new-read-only-audit.json
```

The read-only audit reproduces the legacy 1000 / 1650 recorded pairs and the
1650 / 1650 left-is-front shortcut. Auditing does not grant training permission.
