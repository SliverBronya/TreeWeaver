# Legacy asset register

Legacy root: `D:\SAM3DepthPro` (read-only for the new system).

| Asset | Intended use | Decision |
|---|---|---|
| `20260411` images/depth | exploratory regression fixtures | inspect provenance; do not treat as publication test set |
| `tree_measurement_data.txt` | migrate field labels | schema conversion and manual verification required |
| trained YOLO segmentation weights | M2 baseline | record dataset split, license, training config, and hash first |
| Depth Pro checkout/checkpoints | depth-provider baseline | use upstream API/license; do not copy repository wholesale |
| `tree_measure_core.py` | behavior comparison only | do not copy; fixed intrinsics and single-view heuristics are rejected |
| Android `ar_java` | UX/reference behavior | do not copy signing keys or ARCore-only architecture |
| old paper implementation | formal baseline | preserve unchanged and invoke out-of-process for comparison |

No legacy item is automatically trusted. Admission requires: source, license,
SHA-256, dataset lineage, expected interface, and a regression test.

