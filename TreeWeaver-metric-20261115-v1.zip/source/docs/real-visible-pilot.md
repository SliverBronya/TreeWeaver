# 真实可见轮廓小试验

本轮实际训练200步。基于原版SAM2.1 Hiera tiny，仅微调原mask decoder；不使用
旧5小时定制权重，不训练ownership/amodal，不使用冻结24棵参考树。

## 数据与参数

- TreeStereo v4共251个FT源树，排除旧拼贴6棵和冻结参考24棵。
- 剩余221棵按源树固定划分176训练、45开发验证，seed=20261102。
- 原始RGB和JPEG轮廓掩膜均有SHA256；不宣称场景/地点隔离。
- 轮廓解码max(BGR)>127，不当逐叶alpha或完整amodal。
- 两模型使用相同真值派生框。AdamW，lr=1e-5，200步，仅BCE+Dice可见监督。
- 只在训练前与训练后评价45棵；没有用24棵参考集选模型。

## 实际结果

结果：`reports/real-visible-pilot-2026-11-01/run-200/summary.json`。

- 45棵平均IoU：原版0.851282，新候选0.875831，差值+0.024549。
- Boundary F1：原版0.312392，新候选0.367795，差值+0.055403。
- 44/45棵IoU改善；两模型执行失败均为0。

这是开发验证上的可见轮廓适配信号，不是城市多树、自动检测、补全或尺寸精度。
新权重单独保存为`run-200/final.pth`，字段是`sam2_mask_decoder`；它是原SAM2
解码器权重，不兼容旧多任务`decoder`字段，不能静默混载或覆盖旧基线。

## 城市提示诊断

`reports/stem-prompt-ablation-2026-11-01/` 对7001、7002、10002三图，每图两个固定
目标框，比较box、box+树干正点、box+正点+邻树负点。点由助手查看原图选取，
明确是提示草稿，不是独立人工GT；三个条件保持同一组框。

- 仅框：原版和旧定制模型各保留5/6个预先选定树干探针。
- 加正点：二者raw均保留6/6；旧ownership派生仍仅保留5/6。
- 正负点：原版5/6、旧定制raw6/6、旧ownership派生5/6。

因此点约束与归属后处理须分别检查；点遵循不是分割准确率。
已加入`prompt_constraint_report`：漏正点或包含负点会标记
`blocked_prompt_violation`。满足点也不代表几何测量已经通过。

新visible候选另在相同三图正负点条件做了检查：原版保留5/6个正点、新候选6/6，
两者均未包含提供的邻树负点。可视结果仍不能证明完整实例边界正确。
记录在`reports/real-visible-pilot-2026-11-01/city-prompt-check/`。

## 运行

```powershell
.venv/Scripts/python.exe scripts/prepare_real_visible_split.py `
  --output reports/new-real-visible-split.json
.worker-envs/sam2-shared/Scripts/python.exe scripts/train_real_visible_pilot.py `
  --manifest reports/new-real-visible-split.json `
  --output reports/new-real-visible-run --steps 200 --device cuda
```

新目录规则避免覆盖历史结果。训练脚本会检查图像和标签哈希、源树划分、受保护ID。
本轮没有将24棵参考集重新用于模型选择，未停止其他后台任务。

## 验证与下一步

本轮新增源树排除/提示约束回归；核心275 passed、10 skipped，改动文件Ruff通过。
旧模型CPU测试68 passed为上一轮结果，本轮没有更改其结构。

继续以新候选与原版做相同人工提示对照，优先完成城市多树visible/stem/unknown标注。
只有真实单株边界和树干质量稳定后，再考虑加回ownership；不要因45棵开发验证改善
就替换整个测量系统或宣称完整遮挡已解决。
