# Architecture

## Non-negotiable design decisions

1. **One ordinary RGB photograph is the minimum input.** Additional photographs
   may be unordered and carry no user-supplied pose relationship. Video is only
   a convenient way to obtain such images. ARCore is an optional provider.
2. **Absolute scale is explicit.** A marker, measured camera height, known
   distance, user height, or metric sensor supplies scale. A monocular model is
   not allowed to silently invent metric truth.
3. **Models provide evidence, not final answers.** Segmentation, depth, SfM,
   species recognition, and sensor readings become observations with source,
   uncertainty, and provenance.
4. **Complex-scene reasoning is the primary research problem.** Target-tree
   identity, touching and overlapping trees, visible versus occluded surfaces,
   special stem forms, and parameter-specific measurability are solved before
   a number is allowed to leave the system. A 3-D latent state is used when
   unordered images support it; the single-image path does not invent hidden
   geometry.
5. **Every answer carries uncertainty.** An estimate that cannot meet a target
   error becomes a capture instruction, not a confident-looking number.

## Processing graph

```text
One RGB photo or unordered RGB photos (optional video/IMU/ARCore acquisition)
  -> versioned capture bundle
  -> input identifiability gate
  -> frame quality and key-frame selection
  -> replaceable providers: SfM, masks/tracks, depth, parts, species
  -> root-anchored 3-D identity + explicit ambiguous/occluded geometry
  -> parameter-specific visibility gates
  -> TreeReliability: observation and pixel reliability
  -> TreeFactor: joint scale/pose/structure/parameter optimization
  -> parameter estimates + calibrated uncertainty
  -> active next-best-view guidance if a target is not met
```

## Planned packages

- `capture-android`: CameraX video, sensor timestamps, calibration, upload.
- `treeweaver.domain`: stable types and versioned contracts.
- `treeweaver.providers`: adapters for COLMAP/VGGT, SAM2, metric depth, sensors.
- `treeweaver.reliability`: handcrafted baseline then TreeReliabilityNet.
- `treeweaver.factor`: joint tree-specific optimizer.
- `treeweaver.guidance`: parameter-aware next-best-view policy.
- `treeweaver.association.root_topology`: separates touching trees from root
  anchors without forcing shared crown geometry into a false identity.
- `treeweaver.guidance.visibility`: verifies that the physical surface needed
  by height or DBH was actually observed before measurement is allowed.
- `treeweaver.evaluation`: frozen splits, metrics, ablations, calibration plots.

Provider interfaces are implemented as typed evidence boundaries carrying
model version, source frame, confidence, and uncertainty. The geometry core is
therefore independent of any particular segmentation, depth, reconstruction,
or species model. Concrete learned providers remain replaceable and must pass
the same bundle validation before their evidence can reach TreeFactor.
