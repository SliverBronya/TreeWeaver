# Geometry baseline v1

## Purpose

This baseline isolates metric geometry from recognition. It consumes three
semantic point sets for one tree: trunk, crown, and nearby ground. These may be
manually verified for the geometry-only baseline or produced through the
validated evidence-provider and multiview-fusion path.

## Coordinate assumptions

- Input points are already in metres.
- An optional `up_hint` comes from verified gravity/visual alignment.
- The ground plane is estimated from local ground points.
- Without a verified up vector, the normal is oriented toward the fused tree;
  reconstruction Z is never assumed to be vertical.
- The root is projected onto that plane.
- Tree height is measured along the ground normal after robust outlier removal.
- DBH uses a robust elliptical circumference-equivalent cross-section when
  angular support is sufficient, with a circular fallback for partial arcs.
- Crown width, depth, height, and ellipsoidal envelope volume are reported.

The implementation never derives DBH from a fixed image row or a fraction of
tree height. If the point cloud has no breast-height surface, it refuses to
return DBH.

## Input fixture format

An `.npz` file contains float arrays shaped `(N, 3)`:

- `trunk`
- `crown`
- `ground`

Run:

```powershell
treeweaver measure-geometry semantic_tree.npz result.json
```

The result records values, standard deviations, confidence, observation counts,
diagnostics, ground normal, trunk axis, root point, and angular DBH coverage.

## Current limitations

- Ground fitting is an SVD baseline, not yet reliability-weighted RANSAC.
- Uncertainty is analytic and must be calibrated against field residuals.
- Elliptical DBH remains an idealized cross-section for irregular/buttressed
  stems; coverage, eccentricity, and model choice are retained in diagnostics.
- COLMAP sparse points alone are normally insufficient for dense DBH fitting;
  dense stereo or multiview depth fusion will supply the surface points.

These are explicit experimental baselines, not hidden claims of completeness.
