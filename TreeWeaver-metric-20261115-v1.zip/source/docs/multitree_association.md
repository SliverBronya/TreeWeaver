# Multiview tree identity baseline

## Problem

A detector's local instance number has no meaning across video frames. Tree 2
in one image may be Tree 7 in the next; occlusion can also make background or a
neighbouring trunk appear inside a mask. Using those numbers directly corrupts
per-tree geometry.

## Baseline

For each mask and registered camera:

1. project the dense world point cloud into the image;
2. use a Z-buffer to keep only the nearest visible surface at each pixel;
3. collect the visible 3-D point indices inside the instance mask;
4. compare masks from different views with reliability-weighted 3-D Jaccard;
5. greedily form tracks while enforcing at most one local instance from each
   image in a track;
6. retain both union points and points confirmed by at least two observations.

The output identity is therefore grounded in shared physical surface rather
than detector numbering or 2-D box overlap.

## Command

```powershell
treeweaver associate-instances capture.json text-model fused.ply observations.json tracks-run
```

Inputs and thresholds are preserved in `tracks.json`; compact point-index
arrays are stored in `track-points.npz`. Existing output directories are never
overwritten.

## Current boundary

Masks are manual or supplied by an external provider. This isolates association
quality before SAM2/YOLO errors are introduced. The next learned component will
predict observation reliability and semantic parts, while this 3-D association
remains the explicit baseline for ablation.

