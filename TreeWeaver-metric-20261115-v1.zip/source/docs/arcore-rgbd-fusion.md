# ARCore metric RGB-D fusion

This path removes the manual scale marker for devices that provide ARCore metric depth. It does
not infer a baseline between photographs. ARCore supplies a metric depth image and a metric
camera-to-world pose for every accepted frame; TreeWeaver uses those values directly.

## Required frame data

Every accepted frame in `capture-session.v2` contains:

- an RGB image;
- a depth image in a declared metric unit (normally unsigned 16-bit millimetres);
- an 8-bit depth confidence image;
- intrinsics in the exact pixel coordinate system of the aligned RGB/depth/mask images;
- a row-major 4x4 camera-to-world transform;
- the ARCore tracking state and monotonic timestamp.

Depth, confidence, RGB and masks must be aligned before backend fusion. The backend rejects shape
mismatches instead of silently resizing or rotating calibration data. Only frames in `tracking`
state are fused. A session with metric depth needs no `scale_anchors` entry.

## Fusion

For a depth pixel `(u, v, z)`, the camera point is

`((u-cx)z/fx, (v-cy)z/fy, z)`.

The stored ARCore pose moves that point into the shared world coordinate system. Samples below the
confidence threshold are removed. Remaining samples are fused in metric voxels using confidence as
weight, while retaining the number of independent views that support each voxel. Setting
`--minimum-views 2` or higher provides a strict cross-view consistency gate.

The fused tree is measured along the recorded gravity direction. Height uses robust base/top
quantiles, DBH uses a real 1.3 m world-space slab, and crown width uses the robust major horizontal
extent. No image-height ratio or manually entered object size is used.

The report rejects false confidence through three independent diagnostics: maximum camera
translation baseline, the fraction of voxels supported by at least two views, and leave-one-view-out
standard deviations for height, DBH and crown width. A number can therefore be returned while the
quality gate still marks the capture as unsuitable for scientific measurement.

## Command

```powershell
treeweaver fuse-arcore-rgbd capture-session.json tree-masks.json output `
  --voxel-size-m 0.02 --minimum-depth-confidence 0.35 --minimum-views 2
```

Outputs are `tree-rgbd-cloud.npz` and `tree-rgbd-measurement.json`.

## Current data limitation

The historical `20260411` folder contains RGB, depth and confidence but does not contain a saved
ARCore camera-to-world pose for every image. It therefore supports independent RGB-D measurement,
but cannot support honest multi-view 3-D registration. New captures must use `capture-session.v2`.
