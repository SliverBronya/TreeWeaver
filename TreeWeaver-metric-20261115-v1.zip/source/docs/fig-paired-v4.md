# 本机合成数据改进：paired-parts v4

这轮保留amodal任务，通过可核验的生成过程修正标签和遮挡设计。旧500图、旧权重、
旧60图评估集都不改写，不使用真实照片猜测隐藏轮廓作为GT。

## 生成内容

已完成正式小批：`reports/fig-paired-v4-30-2026-11-01/`，RGB1280×720、标签640×360。
30个场景（单树6、双树9、三树9、四树6），75棵目标，75张移除邻树RGB，共105张
RGB。train/validation/test各35条样本；实际使用25个源资产（15/5/5），池内尚有
4个train资产未在这批抽到。场景与控制图始终留在同一侧。

150组部件分区检查通过；6个单树场景的已知隐藏面积均为0；75张控制图的可见与
完整标签相同。105条样本已全部用PairedFigDataset实际读取，源码快照哈希通过。
这批实际隐藏比例约0%–60.1%，计划的30个场景全部完成。核心283 passed/11 skipped；
新增部分监督的3项Torch测试另已通过。仍未训练新模型。

冻结计划：`reports/fig-paired-v4-plan-2026-11-01.json`。30场景，train/validation/test
各10个，29个fig资产按19/5/5分池。各侧都有1/2/3/4棵树、不同名义框重叠设置。
名义重叠不是实际遮挡率，实际隐藏面积由渲染标签计算并另外记录。

对每棵目标保留：

- 多树场景RGB，以及同树、同相机、同光照参数的移除邻树RGB。地面在两种条件
  下保留；移除邻树会自然改变其投影和阴影，这是渲染对照，不是人工涂抹照片。
- visible/amodal掩膜；amodal是移除其他树后的同一视角、同一画面内支持，不是
  树的所有侧面，也不包含画面外的未知轮廓。
- visible/amodal的stem和crown_surface部件、部件边界unknown、栅格unknown。
- 隐藏区域，以及树冠逐行轮廓的y、左边界、右边界、绝对像素宽度。
- 源资产SHA256、相机/树世界矩阵、场景seed、源代码、Blender版本与渲染参数。

stem按`Ficus_carica_bark`材质定义；其余明确列出的枝、叶、叶柄、果实材质作为
crown_surface。这是源模型部件定义，不声称等同于生物学意义的整套冠体/主干分界。
未知材质会报错；混合边界保留unknown，不靠“底部20%”生成树干真值。

## 本轮发现并修复的具体标签错误

首次把paired样例接入v3渲染器时，visible用0.5阈值，amodal用1/16阈值。单树场景
即使没有邻树，也产生9.625%的伪隐藏面积；它主要反映透明叶缘定义差异。该首批
输出保留在`reports/fig-paired-v4-samples-2026-11-01/`，标记不可训练。

修正后paired分支统一采用0.5阈值；透明度接近阈值及栅格不一致区域显式忽略。
无其他树时检查两次渲染差异，超过1%直接失败，小差异进入unknown。地面也在
“移除邻树”的ID渲染中保留，与对应RGB一致。绝不通过把visible并入amodal来掩盖
不一致。旧v3默认分支保持旧约定，用于历史复现。

修正后的3场景样例在`reports/fig-paired-v4-corrected-2026-11-01/`：1/4/3棵树，
共8个目标与8张移除邻树图。单树已知隐藏面积0%；其余目标覆盖约0%至61.8%的
实际隐藏比例。16组visible/amodal部件分区检查通过，未发现越界或相互覆盖。

## 复现

```powershell
.venv/Scripts/python.exe scripts/audit_fig_data.py plan `
  --assets tools/assets/sketchfab/fig_trees --paired --seed 20261103 `
  --output reports/new-paired-plan.json
$env:FIG_PLAN='D:/TreeWeaver/reports/new-paired-plan.json'
$env:FIG_PAIRED='1'
$env:FIG_IDS=''
$env:FIG_OUT='D:/TreeWeaver/reports/new-paired-data'
$env:FIG_RES_X='1280'; $env:FIG_RES_Y='720'
$env:FIG_MASK_X='640'; $env:FIG_MASK_Y='360'
tools/blender-4.2.3-windows-x64/blender.exe -b -t 4 --python-exit-code 1 `
  --python scripts/generate_fig_500.py
.venv/Scripts/python.exe scripts/postprocess_fig_500.py --root reports/new-paired-data
.venv/Scripts/python.exe scripts/audit_paired_fig_data.py --root reports/new-paired-data
```

渲染与审计输出要求新目录。`FIG_PAIRED=1`必须配套paired计划，避免静默改变旧计划。
仅跑若干ID时，splits.json会明确complete=false，不能把计划数量当成实际样本数。

## 数据读取及训练接入

审计生成`paired-samples.json`：场景和每棵目标的移除邻树图分别成为样本，但具有
相同group_id和split；每个控制图的visible=amodal。控制图引用的可见部件也使用
原目标的amodal部件标签。不能把这些成对样本重新随机按图片划分。

`workers/tree_models/paired_fig_dataset.py`提供`PairedFigDataset(root, split)`。
`sample(i)`返回visible/amodal/stem/crown、boxes、whole_valid、visible_part_valid、
amodal_part_valid。它保留unknown，不将忽略区当背景；框为GT可见范围，完全遮挡时
退回同画面amodal范围，明确只是训练/给定目标的提示，不能冒充自主检测成绩。

训练入口必须实际使用valid掩膜。可使用`partial_supervision.masked_bce_dice`；不能
将此目录直接交给忽略valid标记的旧多任务训练器。完整轮廓和部件损失各按其有效区
计算；树冠绝对曲线再单独接入消融，不能把冠曲线与整树上下界混用。

## 尚未解决的范围

这批仍是单一fig树种、简单地面与同一HDRI环境。随机光照、尺寸和深度只扩大已有
域内变化，未解决城市背景、棕榈/针叶/不同阔叶冠形和非树遮挡物的覆盖。当前29个
资产也已被旧5小时权重看过，新划分不会使旧权重变成未见资产基线。

后续先补形态和背景，再用划分兼容的初始化训练。评价同时报告visible、stem、
隐藏区域IoU和零遮挡多补率，并与visible直接复制、简单包络等基线比较。本轮是
数据生成改进，不宣称已训练出更好的amodal模型。
