# Training data and evaluation roles (2026-11-02)

This note separates **what actually trained current weights** from datasets that are
only evaluated, only planned, or belong to a different model line.

## Current SAM2 weights

### 1. Five-hour multi-task decoder

- Checkpoint: `reports/fig500-long-5h-v2-2026-10-31/best.pth`
- Training data: **only** `reports/fig-500-v2-2026-10-31`
- 500 synthetic images, 1,500 tree instances, 29 GLB assets
- Supervision: visible, synthetic amodal, ownership, layer, visibility, curve
- No real image, no TreeStereo, no 20260411, no human GT
- Limitation: all 29 assets appear in train and validation; layer is a layout shortcut

### 2. Real-visible 200-step decoder candidate

- Checkpoint: `reports/real-visible-pilot-2026-11-01/run-200/final.pth`
- Training data: `data/external/tree-stereo-biophysical-v4`
- 176 train trees, 45 validation trees, 24 protected, 6 excluded
- Supervision: dataset-supplied **visible silhouette only**
- Prompt: GT-derived 5%-padded box
- No ownership, no amodal, no stem, no curve
- Limitation: `scene_disjoint=false`; validation is development-only

## Datasets used for earlier / separate experiments

- `data/external/synthtree43k`: visible and stem-visibility experiments; not used by
  the five-hour fig-500 checkpoint.
- `data/processed/synthtree43k-trunk-v3-2026-10-20`: derived stem supervision for
  earlier stem pilots; not the current multi-task checkpoint.
- `reports/broadleaf-dataset-2026-10-26`: six TreeStereo source trees, cutout
  completion proxy; legacy composite development, not observed amodal.
- `SPREAD`: used in the separate ConvexMask comparison line and audits; not in the
  current SAM2 decoder checkpoints.
- `reports/fig-paired-v4-30-2026-11-01` / `fig-paired-v5-spacing-30-2026-11-01`:
  generated paired data, not yet used for a completed training run.
- `reports/fig-500-v2-2026-10-31`: legacy synthetic baseline; shared assets; keep
  for reproducibility only.

## Evaluation-only, never training

- `data/20260411` (174 photos)
- `reports/fig-hard-holdout2-2026-11-01` (60 synthetic)
- `reports/treestereo-visible-reference-2026-11-01` (24 protected trees)
- `reports/treestereo-trunk-reference-2026-11-01` (90 trunks)
- `reports/real-10-paired-2026-11-01` (10 real photos; human GT count = 0)
- GreenLens / Quebec / UrTrees: measurement or geometry evaluation only

## Important contamination check

The 90-tree trunk reference is **not a clean test set** for the real-visible candidate:

- 64 trees are in its training split
- 13 are in its 45-tree validation split
- 12 are protected reference trees
- 1 is excluded legacy

On clean subsets:

| subset | stock SAM2 IoU | five-hour IoU | real-visible 200 IoU |
|---|---:|---:|---:|
| 13 validation trunks | **0.9007** | 0.8443 | 0.8942 |
| 12 protected trunks | **0.9098** | 0.8250 | 0.9021 |
| 64 training trunks | 0.9151 | 0.8676 | 0.9067 |

Therefore the headline 0.9044 for real-visible 200 is inflated by training overlap.
It has not beaten stock on a clean trunk subset.

## Next protocol rule

1. Report the 13 validation and 12 protected trunks separately; never quote the
   pooled 90-tree average as generalization.
2. Keep 24 protected trees out of all training and model selection.
3. Rebuild the 45-tree split by **source scene**, not only tree ID.
4. Only after that run the staged ablation: stock → visible-only → +ownership →
   +stem (real trunk masks) → +amodal (synthetic/paired only).
