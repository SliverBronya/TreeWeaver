# Model strategy and scientific ownership

TreeWeaver deliberately separates replaceable foundation models from the
project's research contribution. A pretrained network supplies uncertain
evidence; it never directly declares the final height, DBH, species, or volume.

## Geometry stack

- COLMAP is the reproducible sparse/dense baseline.
- A feed-forward SfM model such as VGGT can be added as a reconstruction
  provider and compared under the same quality gates.
- A monocular metric-depth model may add depth evidence, but it cannot silently
  establish absolute scale. Printed-marker triangulation, a measured camera
  baseline, or a metric sensor must anchor scale.

## Tree and part evidence

- A text-guided detector plus a promptable image segmenter is the zero-shot
  bootstrap for tree instances. Temporal propagation is optional when the
  acquisition happens to be video; unordered images do not depend on it.
- A semantic segmentation head is fine-tuned for trunk, crown, ground, and
  occluder evidence when labelled data becomes available.
- Heavy model environments run as isolated workers and must emit the canonical
  `instance-observations-1.0` bundle. The core validates masks and provenance
  before using them.

The exact detector or segmenter is an ablation variable, not novelty. Manual
masks remain a required geometry-only baseline.

The included no-data worker uses Grounding DINO proposals and SAM2 box-prompt
masks through their official Transformers interfaces. It assigns low confidence
to its geometric trunk/crown seed by design. Exact model repository revisions
must be pinned before an experiment.

Official implementation references:

- <https://huggingface.co/docs/transformers/model_doc/grounding-dino>
- <https://huggingface.co/docs/transformers/model_doc/sam2>
- <https://github.com/facebookresearch/sam2>

## Species stack

- A frozen visual foundation encoder produces leaf, bark, crown, fruit, and
  whole-tree embeddings.
- Expert-verified training trees fit organ-specific prototype heads. The
  implementation refuses validation/test examples and refuses taxa with too
  few independent trees.
- The fusion layer caps repeated evidence from one view/organ, combines organs,
  measures entropy, and returns unknown when evidence is insufficient.

This design makes a smaller expert-labelled collection useful without claiming
that an image foundation model has learned forestry taxonomy by itself.

The prototype path is executable and immutable:

```powershell
treeweaver train-species-prototypes training-embeddings.json species-model
treeweaver predict-species-prototypes species-model field-embeddings.json evidence.json
treeweaver fuse-species evidence.json species-results.json
```

`workers/species_dinov2` supplies the preceding frozen-embedding step for bark,
crown, and whole-tree masks while preserving persistent track IDs. It pins the
encoder revision and never turns an embedding directly into a final species.

Training input uses schema `species-embedding-training-1.0`; prediction input
uses `species-embedding-prediction-1.0`. Both must name the same frozen encoder
and exact repository revision. The saved model contains organ-specific
centroids, taxa order, temperature, rejection threshold, embedding dimension,
and training-source path. It refuses validation/test examples, unverified
labels, taxa with fewer than two independent training trees, encoder drift,
and embedding-dimension drift. What remains data-blocked is producing and
validating real organ embeddings—not model persistence or evidence fusion.

## Project-owned research components

1. **TreeFactor** jointly estimates scale and latent tree structure from
   reliability-weighted evidence.
2. **Residual reliability learning** is supervised by out-of-fold downstream
   measurement error, uses monotonic constraints, and cannot train on test
   trees.
3. **Active capture** evaluates candidate views by expected covariance
   reduction discounted by visibility, rather than following a fixed orbit.
4. **Uncertainty calibration** uses independent validation trees and reports
   split-conformal coverage in addition to local optimizer covariance.

These four components—and their controlled ablations—are the defensible
academic contribution. Merely chaining named pretrained models is not.
