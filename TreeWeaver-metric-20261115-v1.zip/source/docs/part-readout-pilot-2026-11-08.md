# 逐阶段推进：空间聚焦修复与冠/干读出训练

2026-11-08，继续执行用户授权，无需逐阶段等待再次确认。

## 实际改动

- PromptFocus改为每查询独立的FPN空间聚焦，输出B×K×C×H×W。处理全部正点、负点和
  padding，负点在框内也能抑制；矛盾同位置正负点相互抵消，点顺序不影响结果。
  正负点必须显式提供标签；坐标必须处于1024提示坐标系，尺寸/查询数失配报错。
- 解码器接收共享特征或每查询特征，三层FPN一起对应查询，不把第0棵树设为特权目标。
  depth在空间聚焦之前应用。零强度下可见、ownership、层次输出与共享路径逐元素一致。
- 该实现是query-spatial-focus-v2，不是SAMBA式编码器全局块交叉注意力PF；后者仍待实现。
  PF checkpoint记录schema，旧共享PF权重即使strict=False也拒绝静默加载，需显式迁移实验。
- 加入可选独立crown token与hypernet，输出本查询的可见crown_surface掩膜；与可选stem
  token兼容。默认关闭，不改变旧默认模型state key集合。打开新token会改变注意力，已单测
  token索引、梯度、查询交换及封装模型的冻结编码器梯度路径。

## 训练做了什么

数据只用已通过标签资格检查的paired v6开发集，未新建或宣称正式多样性语料。
训练10场景25目标，加每目标控制图，共35记录、50次目标出现；验证同样35记录。
划分仍按源资产隔离，但单fig树形家族、简单背景、部分低相机视角的问题仍存在。

初始化：固定SAM2.1 tiny revision，加载真实可见适配的基础decoder（包含特征投影），
再恢复coverage-final自定义decoder；仅允许新crown token/hypernet缺失key。
在共同的crown+stem结构下，冻结所有编码器、token、可见/归属/补全/曲线/层次分支，
**只训练crown_hypernet与stem_hypernet**。使用一次缓存的每查询像素及token特征，保证
前后比较特征完全相同。PF、LoRA关闭；没有对token进行训练。

20epoch×35记录=700步，AdamW lr0.001，seed20261108；最终一步，不按验证挑checkpoint。
两部件均为known区域BCE+Dice，part/raster unknown忽略；缓存和监督都为256×256。
验证使用GT可见框及原生GT正点，是oracle提示的开发检查，不是自动检测结果。

## 结果与边界

10个验证场景（含2个单树）先对每场景实例取均值，再对场景取均值：

- crown IoU：随机读出0.063575 → 训练后0.865893。
- stem IoU：原未训练读出0.005219 → 训练后0.509188。
- 训练总损失0.980569 → 0.330992。
- 完整模型逐张量检查只有两个hypernet的8个state项改变；其余权重完全未变。

这说明新部件读出能学习，**不代表比旧整树模型更准确，也不是反粘连提升**。
部件读出不反馈可见/ownership，训练读出本身不改变这些输出。当前stem仍不足，不晋级。
观察最差差例可见细干偏粗、树干边界或局部像素漏失；256分辨率和冻结SAM特征限制仍需
控制变量验证，不能仅凭此检查断言原因。

另测新token插入的结构影响：同一10场景、256标签、独立掩膜的可见IoU为
0.850355 → 0.850470；总前景符号变化1427像素，单场景均值变化约−0.00174到+0.00267。
所以结构起点不等于旧模型预测，虽均值近似持平也不能省略结构对照。
这些数字的队列/分辨率不同于旧8张多树原生640×360实验，不能直接横向比较涨幅。

当前1seed，仅开发验证，未访问test图像、未使用20260411训练。训练权重promoted=false。
后续需补足细干与争议场景，再做ownership受控实验；不将本轮部件IoU当作完整模型验收。

## 复现与产物

- `scripts/train_part_readouts.py`：完整初始化、数据策略检查、缓存、读出训练、冻结权重检查。
- `scripts/audit_part_readouts.py`：重建时逐张量核对初始读出头、保存可复现decoder、结构影响审计。
- `reports/part-readout-pilot-2026-11-08/protocol.json`：配置、输入及初始化hash。
- `results.json`：35条验证读出结果、损失和变化的state项。
- `architecture-audit.json`：插入token前后的10个场景可见IoU和符号变化。
- `readouts-final.pth`：初始/训练后两部件头；`decoder-final.pth`：核对重建后完整自定义decoder。
- `validation-failures.jpg`：每场景选stem IoU最低的查询，再展示全场最差4例；这是GT辅助
  差例选择，不是随机成功样例。绿=crown_surface，红=stem；图中GT与预测均忽略unknown。
- `source/`：实际训练运行时的源码快照。后续仅修整脚本格式/审计，不重新挑选训练结果。

回归：此前相关61项通过；随后新增旧PF checkpoint迁移防护，编码器/解码器相关22项通过。
