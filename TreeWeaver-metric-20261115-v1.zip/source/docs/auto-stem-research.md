# Automatic stem and multi-instance research: observed failures retained

## Implemented

`workers/tree_models/auto_stem.py` contains a learned weak-center heatmap detector,
variable-count local-peak decoding, anchored instance/background ownership, and
a weak learned horizontal continuity prior. This is not branch tracing or a
demonstrably new method. Current RGB features reuse frozen locally trained
ConvexMask prototypes. An RGB/coordinate center branch was added after the first
prototype failed. Registered depth and reliability can be passed to ownership;
invalid depth retains RGB output. No real ARCore depth experiment is claimed here.

Five automatic-module tests pass, alongside five ownership tests. Tests cover
no-center background output, independent two-peak decoding, query permutation,
zero gradient from unknown center-label pixels, and invalid-depth RGB fallback.

## Controlled training, not real scene accuracy

`scripts/train_auto_stem_pilot.py` generates32 double-tree training composites and
8 development composites from disjoint original tree-ID groups. Existing LabelMe
target outlines are pasted, with visible overlap labels adjusted for paste order.
Those outlines contain non-tree background/sky and synthetic boundaries; these
are major domain artifacts, not realistic instance/branch masks.

Training uses geometry-derived weak center labels and teacher-forced weak center
queries for ownership. Automatic validation never receives GT centers or expected
instance counts. Hungarian assignment is only evaluation matching after prediction.
Real7001/7002 inference receives no annotations. Repeated development images are
not a pristine final test, and training only two-object composites biases counts.

## Three actual runs

Pilot1,400steps, prototype-only stem detection: no reliable centers on real7001 or
7002; synthetic automatic localization also fails. Its center-head architecture
differs from the current RGB/focal version, so its weights cannot be loaded with
the current class unchanged.

Pilot2,800steps, RGB/coordinates and sparse-center focal loss: five of eight
synthetic development composites yield two candidates. Real7001 still produces
an incorrect candidate near a shrub, while7002 produces none. This does not pass
the real-scene objective. RGB resampling affects responses; all preprocessing
must be fixed before comparing models.

Pilot3,800steps, adds22 original training photos with target-only weak centers.
Unannotated neighbor pixels are ignored for center negatives. Neither real test
photo yields a center; synthetic localization also worsens. More weak supervision
did not fix this bottleneck. The working RGB baseline is not replaced.

Artifacts live in `reports/auto-stem-2026-10-12-pilot1`, `pilot2`, `pilot3`.
Weights2/3 are trained pilot weights, not pretrained authors' weights, anatomical
stem detectors or complete measurement models.

## Geometric fallback experiment

`scripts/pilot_auto_stem_hybrid.py` retains baseline detection at512pixels but
extracts ownership features at256pixels, matching the controlled ownership pilot.
Its first256-only coarse-detection run produces no reliable geometric candidates.
The corrected coarse path finds two lower narrow candidates in each real image.
Those candidates can be stems or forks; this does not establish two actual trees.

Visual inspection of corrected7001 shows the ownership head still misses most
of both trees and retains a spurious roof/canopy region. Finding two seed points
has not solved ownership. Outputs are expressly candidate partitions with
`metric_measurement_allowed=false`, not validated instance masks.

## Next research requirement

Stop treating target-envelope-derived lower centers as anatomical truth. Add a
small auditable set of real visible-stem points/regions and tree identity labels;
leave ambiguous crown pixels unknown. Assistant-generated annotations, if used,
must be identified as such and human-reviewed before serving as final evaluation
truth. Preserve tree-group separation when transferring examples into training.

Separate localization quality from ownership quality, and keep original RGB,
ARCore-depth and multi-view routes. Current failures cannot be solved or validated
merely by increasing training iterations. No tree height/DBH/crown/volume accuracy
is established in these runs.
