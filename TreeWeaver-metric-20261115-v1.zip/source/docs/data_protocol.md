# Field data protocol v1

For every tree, collect ground truth before inspecting algorithm error:

- tree ID, site, date, operator, species label source;
- total height with instrument/method and repeated readings;
- circumference at a marked world-coordinate 1.3 m height, then DBH;
- two perpendicular crown diameters when visible;
- stem form notes, lean, fork below breast height, obstruction and slope;
- phone model, resolution, focal metadata, stabilization mode;
- a designated single RGB photograph and an unordered multi-photo set;
- optional video/ARCore capture only as an auxiliary comparison condition;
- explicit complex-scene labels for touching stems, crown overlap, foreground
  occlusion, understory, truncation, lean, forks, buttress, wind, and lighting.

Each measured photo set must include the same explicit fixed-length reference.
Preferred order for controlled comparisons:

1. coded rigid marker or measured staff in the tree plane;
2. measured camera height plus ground constraint;
3. metric depth sensor alignment;
4. user height only as a low-confidence fallback.

Ground truth and raw captures are immutable. Derivatives live in `interim` or
`processed` and are reproducible from scripts. Dataset splits are by tree and
site, never by image.
