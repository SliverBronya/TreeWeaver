# Tree occlusion dataset specification (v0.1)

This document fixes the definitions that were previously implicit. It is a
decision record, not a claim that the data already exists.

## 1. Annotation unit

One annotation unit is **one independently rooted tree instance**.

- Single-stem tree: one instance.
- Palm: one stem is one instance; fronds belong to it.
- Multi-stem tree with a shared root/root plate: one instance, with a shared
  `root_anchor` and one `stem_mask` containing every stem.
- Clump of trees with separate roots: one instance per root system.
- A tree without any visible stem or root anchor is annotated as `unknown` and
  is **not** used as a positive or negative training sample.

Every instance carries:

- `global_tree_id` (stable across views),
- `root_anchor` (image point) or `unknown`,
- `stem_mask` (visible main stem(s)),
- `species` (optional, `unknown` allowed),
- `is_occluded`, `occlusion_rate`, `is_truncated`.

## 2. Mask layers

Four layers, never merged into one “complete mask”:

| Layer | Definition | Use |
|---|---|---|
| `visible` | pixels of the tree visible in this image | primary supervision |
| `observed_amodal` | union of pixels of the same tree observed in **any** registered view / 3D scan | verifiable evidence |
| `amodal_hypothesis` | completed pixels not observed anywhere, produced by a model or annotator | auxiliary, flagged |
| `unknown` | no evidence; neither positive nor negative | ignored in loss |

Rules:

- Holes between branches/leaves are allowed and must not be filled.
- “Complete” means the silhouette of all above-ground woody and leaf geometry,
  not a solid convex blob.
- `observed_amodal` must be a superset of `visible` and may still contain holes.
- `amodal_hypothesis` must never be mixed into `observed_amodal` or `visible`.
- Occluded pixels with no other-view evidence stay `unknown`.

## 3. Prompt API

A prompt is a `TreePrompt`:

- one or more **positive stem points** (label 1),
- zero or more **negative points** on neighbouring trees or non-tree occluders
  (label 0),
- optional target box.

The SAM2 decoder already accepts `input_points`, `input_labels` and
`input_boxes`. The contract is:

```python
prompt = TreePrompt(
    positive_points=((x_stem, y_stem),),
    negative_points=((x_neighbour_stem, y_neighbour_stem),),
    box=(x0, y0, x1, y1),
)
outputs = model(pixel_values, **prompt.to_tensors(device))
```

Rules:

- at least one positive point;
- boxes are prompts, not ground truth;
- negative points must lie on another tree or an occluder, not on background;
- coordinates are in the image frame before the 1024 resize.

## 4. Metrics

Per tree, not per image:

- `visible IoU` and `Boundary F1`;
- `ownership accuracy` on the overlap region;
- `merge` / `split` counts at IoU 0.5;
- `observed amodal recall` on `observed_amodal \ visible`;
- `stem IoU` and, downstream, DBH error;
- abstention coverage and error on the accepted subset.

Global pixel accuracy is explicitly **not** a primary metric.

## 5. Abstention

Return `abstain` when any of:

- target stem is not visible;
- target is truncated by the image border;
- overlap region has no usable depth/3D separation and two instances remain
  ambiguous;
- two candidate masks for the same prompt have IoU in `[0.3, 0.7]`;
- model confidence is below the calibrated threshold.

Abstention is evaluated with a risk-coverage curve: sort by confidence, report
mean error at each coverage level.

## 6. Domain

Primary domain: **urban street trees** (broadleaf and palm, phone camera,
1.4-1.8 m height). Secondary domain: forest/plantation conifers, reported
separately. A model trained on one domain must not be reported as validated on
the other.

## 7. Splits

Split by scene, road, or tree identity, never by random image. All views of the
same tree belong to one side. 20260411 remains a frozen validation set and is
not used for training.
