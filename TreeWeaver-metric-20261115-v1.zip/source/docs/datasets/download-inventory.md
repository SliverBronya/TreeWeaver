# External dataset download inventory

Status date: 2026-10-13. Machine table for the six registered releases lives in
`src/treeweaver/datasets/registry.py`; this note adds the releases that are *not*
registered yet and records measured reachability from this workstation.

## 1. Registered datasets (checksum-verified, `treeweaver download <key>`)

| Key | Size | Source | Local |
|---|---|---|---|
| `greenlens-arcore-v2` | 57.2 MB | https://zenodo.org/records/10776713 | present |
| `quebec-hardwood-volume-98-v1` | 288.1 MB (5 files) | https://zenodo.org/records/21515256 | present |
| `urtrees-evaluation-2025` | 15.7 GiB | https://zenodo.org/records/17780923 | present |
| `tree-stereo-biophysical-v3` | 377 MB | https://data.mendeley.com/datasets/nx3ggv7pxf/3 | present |
| `tree-stereo-biophysical-v4` | 538 MB | https://data.mendeley.com/datasets/nx3ggv7pxf/4 | present |
| `whu-stree-2026` | unknown (request-gated) | https://github.com/WHU-USI3DV/WHU-STree | absent |

Registered total on disk: approximately 18.2 GB.

## 2. Not registered yet

Upstream project: **PercepTreeV1** — https://github.com/norlab-ulaval/PercepTreeV1
(Apache-2.0, Grondin et al. 2022, *Forestry*; preprint arXiv:2210.04104).
SynthTree43k and CanaTree100 are released by that project.

| Item | Size | Link | Reachable from here |
|---|---|---|---|
| SynthTree43k | 84.6 GiB | `http://norlab.s3.valeria.science/SynthTree43k.zip?AWSAccessKeyId=VCI7FLOHYPGLOOOAH0S5&Expires=2274019241&Signature=KfOgwrHX8WHejopspqQ8XMwlMJE%3D` | **no — HTTP 502** |
| SynthTree43k depth images | unknown | `https://ulavaldti-my.sharepoint.com/:u:/g/personal/vigro7_ulaval_ca/EfglPMp555FGvwKGDEp9eRwBn_jXK-7vMPfYxDAVHbzTgg?e=l9HFd4` | yes (HTTP 200) |
| CanaTree100 | 375 MB | `http://norlab.s3.valeria.science/neats/CanaTree100.zip?AWSAccessKeyId=VCI7FLOHYPGLOOOAH0S5&Expires=2339251391&Signature=6beuqoLRQfCTaSpoC7ZKELhJwhY%3D` | **no — HTTP 502** |
| entire-tree annotations (3 files) | small | https://drive.google.com/drive/folders/1sdJtmQ4H8aHzYZ9TWz8xpm06R9mQMd34 | no (no connection) |
| pre-trained Mask R-CNN weights (7) | unknown | Google Drive, links in the PercepTreeV1 README | no (no connection) |
| SynthTree43k mirror | unknown | https://openxlab.org.cn/datasets/OpenDataLab/SynthTree43k | yes (HTTP 200) |
| SPREAD (7 archives, 3 scenes extracted) | approx. 30 GB | already local under `SPREAD/` | n/a |
| SynthTree43k / CanaTree100 survey record | 43 MB `test_set/AllLabels.csv` inside the archive | see `reports/forest-dataset-audit-2026-10-12/audit.json` | n/a |

Approximate additional download needed for SynthTree43k + CanaTree100: 85 GB.

## 3. Reachability measurements (curl, 2026-10-13)

Signed and unsigned variants of the norlab S3 URLs both return HTTP 502 with a
94-byte body; the domain root returns 502 as well. The failure is therefore not
caused by a missing or expired signature. The project audit on 2026-10-12
transferred about 14.8 MB from the same host, so the host worked previously.

| Host | Result |
|---|---|
| `norlab.s3.valeria.science` (signed and unsigned) | 502 |
| Google Drive | 000 (no connection) |
| `ulavaldti-my.sharepoint.com` (OneDrive) | 200 |
| `openxlab.org.cn` | 200 |
| `raw.githubusercontent.com` | 200 |
| `zenodo.org` | 200 |
| `data.mendeley.com` | 200, slow; needs ranged resume (`acquisition.py` supports it) |

## 4. SPREAD label semantics (measured, replaces earlier assumptions)

`scripts`-level check in `city_park`, frames `Tree1000_1720880765` and
`Tree1000_1720938439`:

- per-frame modalities: `rgb/` 540x960 RGBA, `instance_segmentation/` 270x480
  palette RGB, `semantic_segmentation/` 540x960 with only two label values,
  `depth_pfm/` 270x480 float32 with 65504 as the invalid value;
- the mapping file listed 44 and 91 trees; **42 and 75 of them have pixels**,
  so every visible tree instance is annotated, including 2-5 px fragments;
- fully invisible trees are listed but carry zero pixels, which shows the
  instance map records visible pixels only;
- masks are heavily fragmented: `Tree2094` has 503 px in **32 connected
  components**, `Tree4446` has 265 px in 16;
- the target mask covers 0.638 and 0.405 of its own convex hull, and 4010 and
  9350 px inside that hull belong to other tree instances, with depth
  confirming those neighbours are in front in the first frame.

Consequence: the instance map is a one-label-per-pixel partition, so it cannot
encode the shape of an occluded region, and no camera pose is shipped. It does
however link by name to `obj_info_final.xlsx`, which holds per-tree truth:

| Scene | Tree actors | with DBH | with Height | with Crown_Diameter |
|---|---|---|---|---|
| `city_park` | 4626 | 3511 | 4626 | 4626 |
| `birch_forest` | 18582 | 18582 | 18582 | 18582 |
| `broadleaf_forest` | 9355 | 8639 | 9355 | 9355 |

`ActorName_Unreal` matches the instance mapping names, and `StaticMesh` gives a
species proxy (for example `SM_BHF_BirchTreeD`, `SM_BF_TreeOakLarge_C`,
`SM_AmurCork14`). The DBH/Height/Crown values are mesh-template values that must
be combined with `Scale_*`; **the unit and scaling convention is not yet
established and must be resolved before any metric use.**
