# Tree stereo biophysical dataset v3

This is a small, metric-geometry pilot dataset, not the final TreeWeaver video
benchmark.  The immutable release is Mendeley Data v3, DOI
`10.17632/nx3ggv7pxf.3`, licensed CC BY 4.0.

## Verified artifact

- Downloaded archive size: `395220647` bytes.
- SHA-256: `75ad9cbe36eaa3234db0919278df944c3b391cb42f671429e188976cffdf6feb`.
- The downloaded ZIP contains one nested ZIP.  The inner archive contains 359
  files and expands to 415,572,460 bytes.
- Contents: 115 tree stereo pairs, 61 calibration stereo pairs, two OpenCV
  calibration sets, DBH truth for 20 trees, and height/crown-diameter truth for
  10 full trees.

The `calib-v1` translation gives a 129.203 mm physical stereo baseline.  That
provides metric scale without ARCore, but only for this purpose-built stereo
camera—not arbitrary single-camera phones.

## Reproducible pilot

The first checked run used `t01-5m-left-01.png` and
`t01-5m-right-01.png`, with the published `stereo_params_v1.yml`.  The assisted
seed was x=650 and the supplied breast-height row was y=360.  Ground-truth DBH
is 28.49 cm.

```powershell
treeweaver evaluate-stereo-dbh LEFT.png RIGHT.png stereo_params_v1.yml `
  reports\stereo-pilot-v3\t01-5m-predictions.json `
  --truth-cm 28.49 --tree-id t01 --seed-x 650 --breast-height-row 360
treeweaver evaluate reports\stereo-pilot-v3\t01-5m-predictions.json `
  reports\stereo-pilot-v3\t01-5m-evaluation.json
```

Result: 33.44 cm, absolute error 4.95 cm, relative error 17.38%.  All 41
evaluated image rows had valid disparity, so the error is not a missing-depth
failure.  It exposes two unresolved sources of bias: stereo silhouette
expansion and reliable localisation of the physical 1.3 m breast-height plane.

An 8 m view of the same tree, using the correct rectified seed x=650, estimated
31.38 cm (2.89 cm absolute error; 10.14% relative error).  A deliberately
retained failed trial used x=700 selected in the unrectified image; that seed
landed on background after rectification and returned a physically false 85.68
cm.  The real-data failure motivated a fail-closed gate requiring valid support
from at least 80% of the sampled breast-height rows.  With that gate, this bad
seed is rejected rather than reported as a measurement.

This command is intentionally labelled **assisted**.  A person supplies both
the target tree centre and the breast-height row.  It must not be reported as
the end-to-end automatic system.

## Dataset choice

Mendeley v4 is the preferred later training/evaluation acquisition because it
adds 251 full-tree pairs, 90 trunk pairs, and corresponding segmentation masks.
It is not yet registered as immutable here because its archive checksum has not
been downloaded and verified.  UrTrees remains the preferred ordinary-phone
video benchmark for DBH/height and robustness.  Neither dataset supplies the
multi-organ species labels needed for the species branch.
