# Tree stereo biophysical dataset v4

Mendeley Data v4 (`10.17632/nx3ggv7pxf.4`, CC BY 4.0) is the masked-stereo
benchmark used to reproduce the published DBH baseline.

## Verified inputs

- Archive: 563,941,204 bytes.
- SHA-256: `e763dcd5eee579adeeca457f3de530973247ba7bf973f3044f8cc8b97f52cb06`.
- Inner inventory: 1,143 files, including 90 trunk stereo pairs and masks and
  251 full-tree stereo pairs and masks.
- Trunk calibration: upstream TreeVision `configs/test/stereo_trunks.yml`,
  SHA-256 `f9d69e04a6d9d75f297416e2928bde7ecc616dba5f9ace52dfb54ce4aa7431c2`.
- Calibration source: `ElsevierSoftwareX/SOFTX-D-23-00639`, Apache-2.0.

The trunk calibration has focal length 1442.476 px and baseline 130.282 mm.

## Reproduced DBH baseline

The implementation follows the published sequence: rectify the stereo pair and
mask, compute SGBM disparity, retain the disparity histogram peak ±10, infer the
physical 1.3 m breast-height row from the trunk base, and measure the mask width
at that row.

```powershell
treeweaver evaluate-masked-stereo-dataset `
  data\external\tree-stereo-biophysical-v4\extracted `
  data\external\tree-stereo-biophysical-v4\stereo_trunks.yml `
  reports\stereo-pilot-v4\all-90-final2-predictions.json
treeweaver evaluate `
  reports\stereo-pilot-v4\all-90-final2-predictions.json `
  reports\stereo-pilot-v4\all-90-final2-evaluation.json
```

Results over all 90 attempts:

- 82 valid estimates; 8 rejected because the computed breast-height row was
  outside the captured image.
- Failure rate: 8.89%.
- MAE: 1.280 cm.
- RMSE: 1.688 cm.
- MAPE: 4.898%.
- Bias: -0.258 cm.

The associated paper reports DBH MAE 1.41 cm, RMSE 1.70 cm, and MAPE 5.3%.
The reproduced completed-case accuracy is therefore comparable, but the
failure rate is reported explicitly rather than hidden.

## Interpretation

This is an **oracle-segmentation geometry baseline**, because the dataset's
human masks are used. It proves that calibrated stereo plus correct trunk
boundaries can reach roughly 5% DBH error. It does not prove that TreeWeaver's
automatic segmentation reaches that accuracy.

The raw row-to-row uncertainty is under-calibrated: its nominal 95% interval
covered only 32.9% of valid truths. It must be calibrated on a frozen
calibration split before uncertainty claims are made.

The eight rejected captures are scientifically meaningful failures: the image
does not contain the inferred physical breast-height location. A deployable
system should ask the user to step back or reframe rather than fabricate a
measurement from another row.
