# CanaTree100 — what it is and where it falls short

Reviewed 2026-10-13. Rewritten after reading the source papers; the first version
of this note was based on the release fragments alone and got two things wrong
(no depth, no metric reference). Corrections are marked **[corrected]**.

Sources
- Grondin, Fortin, Pomerleau, Giguère, *Tree detection and diameter estimation
  based on deep learning*, Forestry 96(1):105, doi 10.1093/forestry/cpac043.
- Grondin, Pomerleau, Giguère, *Training Deep Learning Algorithms on Synthetic
  Forest Images for Tree Detection*, arXiv:2210.04104 (ICRA 2022 workshop).
- Upstream code and release: https://github.com/norlab-ulaval/PercepTreeV1
- Locally cached fragments: `reports/forest-dataset-audit-2026-10-12/`
  (archive name list, two fold annotation files, one sample image, one
  matching ground-truth overlay).
- Own measurements on the cached annotation files.

## What it is

- **100 RGB images plus 100 depth images** (RGB-D), all 1280x720. **[corrected]**
  The depth comes from the same hand-held **ZED stereo camera**, 60 fps video.
- The 100 frames were hand-picked out of **33 videos**, roughly three per video,
  at a sampling rate below 1%, explicitly to reduce correlation between images.
- Collected in public, private and commercial forests in **Quebec, Canada**,
  between June 2020 and April 2021, 09:00–18:00.
- Species present in the stands: **fir, spruce, pine, birch, maple**.
- **A little over 920 annotated trees.** My measurement on one fold: 4 to 17
  trees per frame, median 8, mean 8.8.
- Annotation protocol: manual, with **COCO-Annotator**. Segmentation covers the
  **trunk only** — branches were deliberately omitted, unlike the synthetic
  release. Bounding boxes are fitted to the masks.
- Five keypoints per tree, capturing the cues a harvesting robot needs:
  1. **felling cut** location, placed approximately **10 cm above ground**;
  2. **left** and **right diameter** points, also approximately **10 cm above
     ground**;
  3. two **inclination** points along the trunk, one mid-trunk and one at the
     top (real data uses mid plus top; the simulator used 90 cm spacing).
- Archive: `CanaTree100.zip`, 375,330,833 bytes, 343 entries. Layout:
  `images/` (100), `images_depth/` (100), `images_depth_neural/` (100),
  `annotations/fold_00` … `fold_04` (7 files each, 30 JSON in total, each fold
  shipping train/val/test plus a `*_depth.json` variant).
- Format: COCO for Detectron2, single category `{id: 0, name: "Tree"}`.

## How diameter is obtained

1. The model predicts keypoints in **pixel space** (keypoint head at 56x56).
2. The pixel coordinates are back-projected through the **ZED depth image** into
   3-D.
3. The distance between the left and right diameter keypoints is the tree
   diameter.

Reported accuracy: **well under 4 cm**; the best model (Cascade Mask R-CNN
DB-Swin-S) reaches **3.6 cm**, and one lighter configuration reports **2.8 cm**.
Felling-cut localisation error is about 7 cm, so the diameter error is roughly
half of it. The paper compares this favourably with lidar-based DBH work
reported at 2.04–3.45 cm.

## Own measurement of the keypoint geometry (176 annotations, two fold files)

| Check | Result |
|---|---|
| y spread among the three lower keypoints | median **5 px**, 99 % within 40 px |
| x ordering of those three | left <= centre <= right in **100 %** |
| row height of that triad | **0.60** of image height |
| mid keypoint (kp3) | 0.31 of image height |
| top keypoint (kp4) | **0.00**; within 20 px of the top edge in **86 %** |

This is consistent with the paper: a low horizontal triad at the felling-cut
height (centre plus left/right edges), two inclination points above it, and the
tree top running out of the top of the frame.

## Problems and shortcomings

1. **The diameter reference is not breast height.** It sits about **10 cm above
   ground** — stump / felling-cut height. Validating DBH against CanaTree100 is
   a category error, and this is the single most important thing to know about
   the dataset for a forest-inventory project. **[corrected]**
2. **The reference is not an independent field measurement.** The "ground truth"
   is a manually placed keypoint pair at about 10 cm read through ZED depth.
   There is no tape or caliper. It therefore constrains annotation consistency
   and depth projection, not absolute field accuracy. **[corrected]**
3. **Only 100 images, drawn from 33 videos**, roughly three frames per video.
   Frames of the same video are strongly correlated, so any random split leaks.
   A usable split must be **video-disjoint**, which reduces the effective sample
   size to 33.
4. **The fold structure is unverified and looks wrong.** The two cached files
   `test_fold_03.json` and `val_fold_02.json` name **the same 20 image files**,
   carry the **same annotation ids** and the **same bounding boxes**, differing
   only in keypoint values by 0.5 px; both were generated on 2021-11-17 within
   0.16 s of each other. If fold 02's validation and fold 03's test really share
   images, cross-validation on this release is leaky. Only 2 of the 30 JSON files
   are on hand; the full archive must be checked.
5. **Annotations are not exhaustive.** The released ground-truth overlay colours
   only the prominent near trunks; dozens of visible background trunks carry no
   label. Consequences: unlabelled pixels cannot be trained as background, a
   correct detection in the background counts as a false positive, and a missed
   background tree does not reduce recall.
6. **No occlusion or truncation truth.** One category only, no visibility flag,
   no amodal mask, no depth-ordering label, `iscrowd` is 0 for every instance.
7. **A documented annotation defect that hits exactly the occluded cases.** The
   paper reports that vertical keypoint error is about **three times** the
   horizontal error, and that when dense understorey blocks the trunk base the
   keypoints are placed **above the vegetation**. So the reference row is least
   reliable precisely where occlusion is worst.
8. **Error grows linearly with camera distance**, because keypoints are estimated
   in pixel space before metric conversion; the intended working range is about
   10 m.
9. **Licence is unstated.** `licenses` is null in the annotation files and the
   repository declares Apache-2.0 for code only.
10. **Domain.** Leafless to early-season Quebec mixed forest, hand-held wide-angle
    stereo, heavy dead-wood clutter. Not urban street trees, not summer canopy,
    not a phone capture protocol.

## Where it is genuinely useful

- The **only real-image release in this family that ships aligned stereo depth**
  alongside the RGB. **[corrected]**
- **Trunk-only masks**, median 32 polygon vertices — clean trunk supervision
  rather than loose boxes.
- **Dense multi-tree frames** (median 8, up to 17) give natural overlap and
  adhesion material, which is otherwise hard to obtain.
- An explicit, published metric target (diameter error under 4 cm) plus seven
  pre-trained Mask R-CNN checkpoints, one of them fine-tuned on fold 01, so an
  off-the-shelf baseline exists.
- Small: 375 MB.

## Conditions before use

1. Obtain the full archive and test **video and fold disjointness** across all 30
   JSON files.
2. Confirm which of `images_depth` (ZED stereo) and `images_depth_neural`
   (predicted) is which, and never mix them in one experiment.
3. Settle the licence question before registering the dataset.
4. Treat it as a **development** set for instance segmentation and adhesion.
   **Never present it as DBH validation** — its diameter row is about 10 cm above
   ground, and its reference is annotation-derived rather than measured.
