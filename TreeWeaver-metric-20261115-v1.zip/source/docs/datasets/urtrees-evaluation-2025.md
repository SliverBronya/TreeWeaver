# UrTrees evaluation dataset (2025)

## Immutable source record

- Registry key: `urtrees-evaluation-2025`
- Zenodo record: <https://zenodo.org/records/17780923>
- DOI: `10.5281/zenodo.17780923`
- License: CC BY 4.0
- Published: 2025-12-02
- Archive: `urtrees_evaluation_datasets.tar.gz`
- Registered size: 16,862,031,782 bytes
- Registered MD5: `cd39e550a664ee1d027b558382213b8b`

The archive is deliberately not stored in Git and has **not been downloaded**.
Acquisition is explicit, resumable, and accepted only after size and checksum
validation.

## Scientific role

This is the primary external smartphone-video benchmark for height and DBH.
The published groups also exercise leaf state, surveyor, environment, and
accessibility. It is not treated as a complete multi-organ species benchmark
or as independent crown-volume ground truth.

No result may be labelled external test if its video, tree identity, or a
derived frame was used for training, threshold selection, or model selection.
Paper-defined groups must be retained rather than randomly splitting frames.

## Staged commands

```powershell
treeweaver dataset-info urtrees-evaluation-2025
treeweaver dataset-download urtrees-evaluation-2025 D:\TreeWeaver\data\external
treeweaver dataset-inventory `
  D:\TreeWeaver\data\external\urtrees-evaluation-2025\urtrees_evaluation_datasets.tar.gz `
  D:\TreeWeaver\data\external\urtrees-evaluation-2025\archive-inventory.json
treeweaver dataset-extract `
  D:\TreeWeaver\data\external\urtrees-evaluation-2025\urtrees_evaluation_datasets.tar.gz `
  D:\TreeWeaver\data\external\urtrees-evaluation-2025\extracted
```

The UrTrees-specific column/layout adapter will be written after inventorying
the real archive. Guessing spreadsheet columns before that would make the
pipeline brittle and scientifically unauditable.
