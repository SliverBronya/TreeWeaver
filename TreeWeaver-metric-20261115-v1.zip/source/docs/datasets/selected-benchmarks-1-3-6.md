# Selected external benchmarks: GreenLens, WHU-STree, and Quebec-98

These three datasets have distinct scientific roles. They must not be merged as
if their labels came from the same sensor or reference procedure.

## GreenLens ARCore v2

- Registry key: `greenlens-arcore-v2`
- RGB: 480 x 360 JPEG images.
- Geometry input: sparse/coarse ARCore depth samples with per-sample confidence.
- Independent target: field DBH.
- Primary use: phone RGB-depth alignment, confidence filtering, trunk segmentation,
  DBH accuracy, and failure stratification.
- Prohibited claim: this dataset does not validate height, crown, species, volume,
  temporal fusion, or camera-pose recovery.

The verified v2 archive contains 378 RGB files, 378 depth grids, and one label
workbook. Every depth grid is 160 x 120 and maps to a 480 x 360 RGB image with an
exact 3x coordinate scale. The frozen file contains three country labels (China 264,
Thailand 99, Canada 15) and DBH values from 1.9 to 155.3 cm. These facts differ from
the Zenodo prose description (four countries and a 4.8 cm minimum), so experiments
use and report the immutable file contents.

## WHU-STree 2026

- Registry key: `whu-stree-2026`
- RGB: trajectory-indexed panoramic images.
- Geometry input: aligned mobile-mapping point clouds and per-image exterior pose.
- Labels: tree instance and species; references include DBH and height.
- Primary use: crowded-scene instance segmentation, RGB/3-D association, species
  recognition, and cross-city generalization.
- Accuracy caveat: DBH and height are point-cloud-derived references, not an
  independent field-measurement endpoint. Results must be labelled agreement with
  WHU-STree reference values, not field accuracy.
- Access: the final NJ/SY release is request-gated. Preserve the received archive and
  record its checksum before extraction.

## Quebec hardwood volume 98 v1

- Registry key: `quebec-hardwood-volume-98-v1`
- Geometry input: 98 individual-tree mobile-laser point clouds and reconstructed QSMs.
- Species: sugar maple and yellow birch.
- Independent targets: field DBH, standing height, felled height, and destructive
  stem/branch/butt/merchantable volumes.
- Primary use: final validation of TreeWeaver's QSM/volume stage and comparison with
  species-specific allometry.
- Prohibited claim: this dataset does not validate phone capture, RGB segmentation,
  pose recovery, crown width, or broad species generalization.

The supplied upstream estimates have been converted into TreeWeaver's common
evaluation schema as a frozen sanity-check baseline. Against all 98 destructive or
field references, supplied MLS/QSM estimates obtain DBH MAE 1.22 cm, felled-height
MAE 0.62 m, and operational-volume MAE 0.14 m3. The supplied allometric operational
volume has MAE 0.16 m3. These are upstream baselines, not TreeWeaver results.

An exploratory TreeWeaver point-cloud baseline reads the original LAZ files, uses
the supplied height-above-ground and wood-probability attributes, selects a connected
breast-height surface, and applies deterministic circle RANSAC followed by the project
cross-section estimator. On all 98 trees it obtains DBH MAE 1.22 cm / RMSE 1.76 cm
and felled-height MAE 0.81 m / RMSE 1.01 m, with no rejected trees. For the 87 trees
whose field DBH was measured at exactly 1.30 m, DBH MAE is 1.08 cm / RMSE 1.43 cm;
the other 11 field measurements used exceptional heights from 0.70 to 1.70 m.

These numbers are exploratory development results, not a pristine held-out claim:
the dataset-level errors were inspected while improving the cross-section outlier
filter. A publication must freeze the method and evaluate it on a separate untouched
test set. The current nominal uncertainty is also under-calibrated, so accuracy must
not be presented as calibrated confidence.

## Evaluation separation

Report three independent result blocks:

1. GreenLens: DBH error and failure rate by capture condition.
2. WHU-STree: segmentation, species, association, and reference-agreement metrics by city.
3. Quebec-98: DBH/height error plus total and compartment-volume error against destructive
   references, split by species and site.

Never calibrate and test on the same tree. Dataset-specific calibration parameters must
be fitted only on a frozen calibration split, and all rejected measurements count toward
the reported failure rate.
