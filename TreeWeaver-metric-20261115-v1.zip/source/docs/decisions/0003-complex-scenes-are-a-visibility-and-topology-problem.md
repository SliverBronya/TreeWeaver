# ADR 0003: Complex scenes are a visibility and topology problem

Status: accepted

## Context

A stronger segmenter alone cannot determine which hidden branch belongs to
which tree, recover a stem surface that was never observed, or distinguish an
occluded root from an absent root.  Forcing a complete mask in these cases
creates precise-looking but untestable measurements.

## Decision

TreeWeaver treats each 2-D model output as view-specific evidence.  Persistent
tree identity is anchored at the root and propagated through reconstructed 3-D
topology.  Touching geometry with similar paths to two roots remains explicitly
ambiguous.  A visibility layer checks the surfaces needed by each parameter:
root and apex for height, angular coverage around the breast-height section for
DBH, and crown boundary coverage for crown dimensions.  Missing evidence
produces a parameter-specific next-view instruction or a refusal, never silent
completion.

A fixed-length coded reference remains the primary scale source.  ARCore depth
and pose are accepted as additional observations on capable phones, but are not
required and do not bypass the same visibility checks.

## Evaluation consequence

Every test tree is labelled independently for stem occlusion, crown overlap,
touching stems, understory, forks, buttress, lean, truncation, wind, lighting,
and reconstruction holes.  Accuracy, failure rate, interval coverage, and
capture burden are reported per challenge and by interaction count.  A single
average over clear and difficult trees is not an acceptable result.
