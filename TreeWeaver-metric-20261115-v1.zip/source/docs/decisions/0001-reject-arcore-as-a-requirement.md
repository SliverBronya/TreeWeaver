# ADR 0001: ARCore is optional evidence, not a platform requirement

Status: accepted

## Context

The legacy application requires ARCore and therefore excludes unsupported or
poorly supported phones. ARCore depth quality also changes by device and scene.
Using it as an unstated source of truth makes cross-device results difficult to
interpret.

## Decision

The minimum capture is one ordinary RGB photograph with camera metadata and a
visible explicit metric-scale anchor. Additional photographs may be unordered;
their relative camera poses are recovered by the system rather than supplied by
the user. Video is an optional acquisition convenience, and IMU is optional.
ARCore, ToF, and LiDAR implement
the same optional evidence-provider interface. Their observations must include
uncertainty and may be rejected by reliability estimation.

## Consequences

- The application can support one photograph and phones without ARCore.
- Scale capture is a visible part of the user workflow.
- Sensor-equipped phones can improve results without creating a separate
  algorithm or data format.
- Cross-device experiments must report results by capability group.
