# ADR 0002: No measurement without uncertainty and provenance

Status: accepted

## Context

A single plausible number hides segmentation failures, scale ambiguity,
occlusion, and disagreement between views. Averaging such numbers does not make
them scientifically defensible.

## Decision

Every geometric observation records its source, view, standard deviation, and
reliability. Every final parameter includes uncertainty, confidence,
observation count, and diagnostics. If an error target is not met, the system
asks for a parameter-specific additional view.

## Consequences

- API and database schemas cannot store only a scalar result.
- Evaluation includes interval coverage and risk-coverage, not only MAE.
- The system can abstain instead of presenting an unreliable result.

