# System readiness before external data

This document separates implemented engineering from claims that require real
field evidence. A green unit test means the mathematics and file contracts are
internally consistent; it does not mean field accuracy has been demonstrated.

## Implemented and testable without field data

- Capture-session contracts accepting one RGB image or unordered RGB images,
  with no user-supplied camera relationships and no ARCore requirement.
- The existing CameraX RGB-video importer remains an optional acquisition
  adapter rather than the scientific input definition.
- Raw-video ingest, frame sampling, intrinsics crop mapping, and clock checks.
- Auditable COLMAP sparse reconstruction and optional dense stereo fusion.
- Multi-tree, multiview instance association through shared 3-D support.
- Single-view complex-scene mask auditing for apex/root/side truncation,
  target/stem/crown overlap, trunk fragmentation, and root-ground gaps.
- Parameter-specific single-image gates: a damaged stem can block DBH without
  automatically discarding an otherwise usable crown-width observation.
- Reliability-weighted trunk, crown, and ground fusion.
- Sequential geometry estimates for height, DBH, crown width/depth/height, and
  ellipsoidal crown volume with uncertainty.
- TreeFactor joint scale, root, ground, axis, taper, height, DBH, and geometric
  stem-volume inference.
- Transparent reliability scoring and explicit evidence rejection.
- Dependence-aware multi-view/multi-organ species probability fusion with an
  open-set rejection result instead of forced classification.
- Species/region/citation-locked allometry; mismatched equations are refused.
- Parameter-specific final quality decisions and covariance-aware next-view
  instructions, with an explicit heuristic fallback when covariance is absent.
- Tree-disjoint frozen splits, failure-aware metrics, uncertainty calibration
  metrics, risk-coverage curves, and tamper-evident run journals.
- Synthetic partial-view/outlier ablations for debugging before field tests.
- Registered, resumable, checksum-verified external dataset acquisition; no
  dataset is downloaded automatically.

## RGB-only complex-scene pilot (2026-09-28)

The optional zero-shot workers now produce a visible whole-tree mask, a
root-seeded SAM2.1 trunk candidate, competing tree masks, and candidate
non-tree object masks. The image audit records prediction conflicts, basal
multi-run topology, and non-tree object proximity to the visible stem base.
These are parameter-specific *risk cues*, not proof of physical occlusion or
metric geometry. The detector/segmenter outputs and thresholds remain frozen
pilot baselines, not learned TreeWeaver novelty.

On six local `20260411` photos and six sampled tree960 photos, the tightened
trunk-prompt criterion accepted 12/12; it selected exactly the same masks as
the previous unconstrained pilot on those 12. This checks regression, not
trunk accuracy: neither sample has independent pixel-level trunk truth. On
`20260411/7001.jpg`, the car-mask-to-visible-stem-end contact fraction was
0.772, whereas the other five sampled photos had zero under this geometric
test. That supports a possible basal occluder warning; a monocular RGB image
alone does not prove which object is in front. The tree960 six-image whole-tree
mask IoU mean from the earlier pilot was 0.917; the new part and occluder
modules do not change those whole-tree masks.

The root-anchored multi-tree pilot retains the original target mask and uses
other proposals only to expose ambiguity and conflicts. Its successful
selection on the six local images is not independent tree-ID accuracy. Photo
grouping by the `00` filename convention is an evaluation oracle, not an
automatic unordered-photo association method. ORB/SIFT and frozen DINOv2
pilot matches were insufficient to separate visually similar trees, so RGB
cross-view identity remains open.

## Intentionally blocked on inspected data or trained weights

1. The automatic instance/part provider needs either verified public weights
   with compatible licences or fine-tuning examples for trunk/crown/ground and
   occluder labels. Manual masks remain the geometry-only baseline.
2. TreeReliabilityNet needs residual/error targets produced by running the
   pipeline against measurement truth. Its leakage-safe out-of-fold training
   path and monotonic residual model are implemented; fitted parameters are
   intentionally absent until truth is available.
3. Species identification needs expert labels and multiple organs. A pinned
   frozen-encoder worker plus immutable organ-prototype training, persistence,
   prediction, and fusion are ready, but they cannot manufacture trustworthy
   taxonomic labels or missing leaf/flower/fruit views.
4. Uncertainty thresholds and covariance calibration must be learned only on
   training/validation trees, then frozen before external testing.
5. Field accuracy, cross-phone generalization, and superiority claims require
   the registered external benchmark plus a small locally measured external
   site. Synthetic tests cannot support those claims.
6. The generic one-command runner still starts from the optional video importer.
   A dedicated one-photo metric geometry runner and an unordered-photo runner
   remain to be connected to the same complex-scene evidence gates.
7. This RGB-only pilot has no validated automatic target identity across
   unordered photos, no independent trunk/occluder truth, and no field
   measurement-error result. Its per-parameter gates must not be presented as
   centimetre-level or metre-level measurement accuracy.

## Required paper comparisons

- Legacy ARCore pipeline.
- Sparse/dense unordered-image SfM sequential baseline.
- TreeFactor without reliability weights.
- TreeFactor with reliability weights.
- Fixed capture path versus parameter-aware guidance.
- Local Jacobian covariance versus empirically calibrated intervals.

Every comparison reports all attempts, failed reconstructions, MAE, RMSE,
bias, interval coverage, Gaussian NLL, and risk-coverage—not just successful
trees or average relative error.
