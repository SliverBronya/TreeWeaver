# Stem 训练审计与修正（2026-11-03）

## 结论

2026-11-02 与 11-03 的两个 stem token 训练违反了当时已写下的数据规则，且缺少
基线、逐树结果与冻结协议。修正后重跑，旧结论全部改变：

- TreeStereo 树干：stem 0.9025 vs 原版 SAM2 0.9007（+0.18 pt，4 胜 9 负，BF1 反而
  低 7.4 pt）。旧的 protected 0.919 来自选模泄漏。
- CanaTree100：stem 0.7123 vs 原版 SAM2 0.8032（−9.1 pt，28 胜 157 负），测试
  0.7201 vs 0.7947。邻树像素占比 0.0757 vs 0.0262，即 stem 头把约 3 倍的预测像素
  放到相邻树干上。

因此“增加专用 stem 头”目前不是粘连问题的解，而是粘连误差的来源之一。

## 违反的具体条款

1. `configs/research/dataset-usage-2026-11-01.json` 把
   `data/external/tree-stereo-biophysical-v4/extracted/trunks` 记为
   `training_allowed: false`（“90 T identities/all views protected”），而
   `scripts/train_stem_treestereo.py` 在该目录的 64 棵训练树上训练。
2. `docs/training-data-2026-11-02.md` 规则 2 要求 protected 树不参与训练与选模，
   而旧脚本用 `val_iou + protected_iou` 选 checkpoint。
3. 两个脚本都未调用 `assert_training_allowed`，也未写 `training_protocol`：没有
   数据/划分/初始权重哈希，也没有逐树结果，只有均值。
4. CanaTree100 未登记进 policy；`fold_02 val` 与 `fold_03 test` 共享 20 张图，
   且 100 帧来自 33 段视频，发布物没有视频标识，图像级划分无法证明视频隔离。

## 已做的修改

- `workers/tree_models/research_protocol.py`
  - 新增 `sha256_file` / `hash_files`；
  - `assert_training_allowed(..., tree_ids=...)` 支持 `tree_scoped_training`：
    目录整体仍只读，只有显式给出、且全部属于冻结划分 train 角色的树身份才放行；
  - 修复“父目录 `training_allowed: true` 遮蔽受保护子目录”的缺陷，改为取最长
    匹配条目。此前 `.../v4`（整树，允许训练）会先命中，使 `.../v4/extracted/trunks`
    的保护形同虚设。这是比单个脚本更早的根因。
- `configs/research/dataset-usage-2026-11-01.json`
  - trunks 条目保留拒绝，增加 `tree_scoped_training`（64 棵、禁止
    validation/protected/excluded）；
  - 新增 `data/external/canatree100` 条目，注明非穷尽标注、无视频标识、
    不可作 DBH 验证。
- `scripts/train_stem_treestereo.py` / `scripts/train_stem_canatree.py` 重写：
  先写 `protocol.json`（划分哈希、逐文件内容哈希、基座 revision、初始权重哈希、
  优化器、选择规则、局限），再训练；只用验证集选模；protected 仅报告；输出
  `per_tree.json`；同提示跑原版 SAM2；CanaTree 必须显式
  `--allow-unverified-video-split`。
- 新增 `scripts/stem_eval_common.py`：逐树指标、邻树泄漏、配对胜负、同提示基线。
- 新增 3 项协议测试；全套 `pytest` 288 passed / 11 skipped。

## 结果

| 数据集 | 角色 | 树 | stem IoU | stock IoU | 差值 | BF1 stem/stock | 邻树占比 stem/stock |
|---|---|---|---:|---:|---:|---|---|
| TreeStereo 树干 | 验证 | 13 | 0.9025 | 0.9007 | +0.0018（4/0/9） | 0.446 / 0.520 | — |
| TreeStereo 树干 | protected（仅报告） | 12 | 0.9127 | 0.9098 | +0.0029（6/0/6） | 0.471 / 0.530 | — |
| CanaTree100 | 验证 | 185 | 0.7123 | 0.8032 | −0.0909（28/157） | 0.553 / 0.694 | 0.076 / 0.026 |
| CanaTree100 | 测试（一次） | 186 | 0.7201 | 0.7947 | −0.0746（26/160） | 0.551 / 0.669 | 0.058 / 0.018 |

产物：`reports/stem-treestereo-clean-2026-11-03/`、
`reports/stem-canatree-clean-2026-11-03/`。旧目录分别标注
`INVALID.md`、`SUPERSEDED.md`。

## 解释与限制

- 两个数据集都只给 GT 派生框，没有树干正点或邻树负点，所以这里测的是
  “同一提示下哪个解码器更稳”，不是提示策略的效果。
- TreeStereo 的 64 棵训练树就在这 90 棵里，验证集是开发集；CanaTree 的
  fold_00 与其它 fold 的训练图重叠，也没有视频隔离。
- 两个跑法都只训练 `stem_token` + `stem_hypernet`（约 300 步，lr 1e-3），
  编码器与其余解码器冻结，因此不能推断“重新训练整个解码器”会怎样。
- 邻树占比按“预测像素落在同图另一棵已标注树干内”定义；CanaTree 的标注非穷尽，
  背景里未标注的树干不计入分母，这是该指标的已知低估。
