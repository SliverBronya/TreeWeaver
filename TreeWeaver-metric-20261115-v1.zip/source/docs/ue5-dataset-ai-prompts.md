# UE5 树木遮挡数据集：AI 提示词包

把下面的 Prompt 0 先发给另一台电脑上的 AI（Claude Code / Codex / Cursor 等），
然后按阶段依次发 Prompt 1–8。每个 Prompt 都要求 AI **实际执行、给出文件证据**，
不接受“我已经完成”的口头声明。

---

## Prompt 0：总控（先发这个）

```text
你是一名 UE5 技术美术 + Python 自动化工程师。请在当前电脑上实际搭建一个可用于训练“树木遮挡/归属/完整掩膜”的 UE5 合成数据集，不要只给方案。

【项目背景】
我们要训练一个树木实例分割/遮挡归属模型。模型输入 RGB（以及可选深度），需要输出：
- 每棵树的可见掩膜；
- 每棵树的完整掩膜（amodal）；
- 每个像素属于哪棵树（ownership）；
- 前后层序；
- 树干掩膜；
- 深度图；
- 相机参数。

【数据要求】
- 场景：城市街景 / 公园 / 林地边缘均可，但必须有 3D 背景（建筑、道路、树木、道具），不能是纯 HDRI 背景。
- 树：常绿或落叶大乔木，树冠密，主干可见；不要盆栽、不要树干扫描。
- 每张图 2–4 棵树，树冠之间有真实遮挡；遮挡率要有变化（约 5%–40%）。
- 500 个场景起步；2 棵 150、3 棵 200、4 棵 150。
- 至少使用 20 种不同树资产；允许同一资产不同缩放/旋转。
- 训练/验证/测试按场景划分，不能随机切图。

【标签定义】
- amodal：把其他树、地面、建筑全部隐藏，只渲染这棵树，透明背景的 alpha。
- visible：完整场景中，这棵树实际可见的像素。
- ownership：每个可见树像素只属于一棵树；重叠区判给前景树。
- layer_order：从相机看，从前到后。
- stem：只渲染主干/树干，叶片不参与。
- depth：与 RGB 对齐的度量深度或归一化深度，必须说明单位。

【硬件约束】
- GPU：RTX 5080 16GB 显存。
- 内存：32GB。
- 目标：1080p，小场景，2–4 棵目标树 + 5–10 棵背景树。
- 不要使用 City Sample、4K/8K 贴图、超大森林、几十棵高模树。
- 页面文件建议 64GB；关闭浏览器等占内存程序。

【工作方式】
1. 先检查本机 UE5 版本、GPU、内存、磁盘，写进 reports/environment.md。
2. 先做 1 个模板场景，渲染 RGB / 深度 / Object ID / 逐树 amodal / stem，人工检查。
3. 通过后做 20 个场景；再通过后扩到 500。
4. 每一步都要给出真实文件路径、文件数量、渲染日志、截图；没有文件证据就视为未完成。
5. 资产许可必须可商用或至少可研究使用；记录到 ASSET_CREDITS.md。不要用来源不明/盗版资产。
6. 不要伪造指标；不确定就停下来问。

【最终交付】
- 数据集目录（images / depth / masks / meta / splits / index.json）
- 生成脚本（Python / UE Python）
- README.md（结构、单位、许可、已知问题）
- 20 张随机预览图
- 一份验收报告（数量、掩膜合法性、遮挡分布、失败案例）

现在先执行第 1 步：检查环境并给出安装/版本建议。不要开始渲染。
```

---

## Prompt 1：环境与项目初始化

```text
继续这个 UE5 数据集项目。请实际完成环境初始化，不要只写步骤。

任务：
1. 检查并记录：
   - UE5 版本（5.4 / 5.5 / 5.7，按资产兼容性选）；
   - GPU 型号/显存、系统内存、磁盘剩余；
   - 是否安装 Fab 插件、Quixel Bridge（如可用）。
2. 创建 UE5 项目：
   - 名称：TreeOcclusionDataset；
   - 模板：空白/第一人称均可，不要 City Sample；
   - 关闭 Starter Content 以外不必要的插件；
   - 开启：Lumen、Nanite、Virtual Shadow Maps、Custom Depth-Stencil；
   - 默认分辨率 1920×1080；
   - 项目放在 SSD 上。
3. 建立目录：
   Content/TreeOcclusion/
     Maps/
     Trees/
     Environment/
     Materials/
     Blueprints/
     Scripts/
   Saved/Renders/
   Dataset/
4. 写 reports/environment.md，包含版本、硬件、项目路径、设置截图。
5. 做一个空场景性能基线：1080p、Lumen、空场景，记录帧率和显存占用。

验收：
- 项目能打开；
- 1080p 能渲染一帧；
- reports/environment.md 存在且内容真实；
- 给出项目绝对路径。
```

---

## Prompt 2：资产获取与许可

```text
继续。请为数据集准备树和环境资产，优先免费/低价、许可清晰。

树资产优先级：
1. Quixel Megaplants（Fab，免费）：English Oak、European Hornbeam、Yoshino Cherry、Goat Willow、Baltic Pine、Bamboo 等。
2. Fab 免费/低价常绿阔叶树（ficus、camphor、magnolia、holly 等）。
3. Sketchfab CC0/CC-BY 扫描树（仅作为主树补充）。

环境资产：
- Fab 免费模块化街区/公园包；
- Quixel Megascans 地面/墙面/路缘/污渍；
- Poly Haven HDRI（只做天空/环境光）；
- Fab 免费道具：车、路灯、护栏、垃圾桶、店招、空调外机。

要求：
- 至少 20 种不同树；不要全是同一棵；
- 树必须整棵、主干可见、树冠密；
- 背景树必须是 3D 资产，不能用 HDRI 里的树；
- 记录每个资产的名称、作者、许可、来源 URL 到 ASSET_CREDITS.md；
- 许可不清晰的资产不要用。

交付：
- Content/Trees/ 下每个树一个文件夹；
- Content/Environment/ 下环境包；
- ASSET_CREDITS.md；
- 一张资产清单表（名称/类型/许可/用途）。
```

---

## Prompt 3：模板场景

```text
继续。请实际搭建一个可复用的模板关卡，不要只描述。

模板要求：
- 地面 200m×200m，有道路/人行道/路缘/树坑；
- 2–4 棵目标树，树冠互相遮挡；
- 5–10 棵背景树，远近分层；
- 2–3 栋模块化建筑；
- 5–10 个街道道具；
- 相机 1.5–1.8m 高，24–35mm，稍微俯视；
- 天空 HDRI，阴天或柔和日光；
- Lumen 开启，1080p。

做三种布局：
A. 左右并排：相邻树冠重叠约 10%–30%；
B. 前后遮挡：前树挡后树，层序明确；
C. 3–4 棵一簇：中间树被夹住。

要求：
- 所有树 actor 命名清晰：Tree_01、Tree_02…；
- 每棵树设置唯一 Custom Stencil ID；
- 树干用单独材质/对象，便于 stem mask；
- 相机固定一个 CineCameraActor；
- 场景保存为 Maps/Template_Street、Template_Park、Template_Cluster。

交付：
- 3 个关卡文件；
- 每个关卡 1 张 1080p 预览；
- 记录每棵树的 ID、层级、位置到 README。
```

---

## Prompt 4：标签与渲染通道

```text
继续。请实现并验证以下渲染通道。每个通道都要有真实输出文件。

每个场景输出：
Dataset/{scene_id}/
  rgb.png                 1920×1080
  depth.exr               与 RGB 对齐
  object_id.png           每棵树唯一颜色/ID
  masks/amodal/tree_01.png ...
  masks/visible/tree_01.png ...
  masks/stem/tree_01.png ...
  masks/ownership.png
  masks/layer_order.json
  meta.json

实现要求：
1. amodal：
   - 隐藏其他树、地面、建筑、道具；
   - 只显示目标树；
   - 透明背景渲染，alpha 即 amodal；
   - 每棵树单独渲染。
2. visible + ownership：
   - 正常渲染整个场景；
   - 输出 Object ID / Custom Stencil pass；
   - ID == i 的像素 = 树 i 的可见掩膜；
   - ID 图即 ownership；
   - 重叠区判给前景树，层序写入 layer_order.json。
3. stem：
   - 只显示树干材质/对象；
   - 隐藏叶片；
   - 透明背景渲染 alpha。
4. depth：
   - 优先 Movie Render Queue 的深度/EXR pass；
   - 若不可用，用 SceneCapture2D + SceneDepth 材质；
   - 必须验证深度与 RGB 对齐，记录单位（cm/m）和近远裁剪。
5. meta.json：
   - scene_id、树列表、资产名、位置、缩放、层序、每对遮挡率、相机位置/旋转/FOV、光照、布局类型。

验收：
- 任选 3 个场景，给出 rgb、depth、object_id、amodal、visible、stem、ownership 的实际文件；
- 检查 visible ⊆ amodal、visible 互斥、ownership 与 visible 一致；
- 检查 depth 不是全 0/全 1。
```

---

## Prompt 5：自动化生成

```text
继续。请写 UE5 Python 自动化，批量生成场景并渲染，不要手工点。

任务：
1. 读取树资产清单；
2. 对每个 scene：
   - 随机选 2–4 棵树；
   - 随机布局（并排/前后/簇）；
   - 随机缩放 0.85–1.15、旋转、间距；
   - 随机相机高度/焦距/朝向；
   - 随机 HDRI/太阳角度；
   - 设置每棵树 Custom Stencil ID；
   - 提交 Movie Render Queue：RGB、Object ID、Depth、逐树 amodal、stem；
3. 每场景写 meta.json；
4. 支持断点续跑：已存在且合法的场景跳过；
5. 输出日志：每个 scene 的开始/结束/耗时/显存/失败原因；
6. 先生成 20 个，检查后再扩到 500。

API 提示（自行验证版本兼容）：
- unreal.EditorActorSubsystem
- unreal.MoviePipelineQueueSubsystem
- unreal.MoviePipelineQueue
- unreal.MoviePipelinePIEExecutor
- unreal.MoviePipelineDeferredPassBase
- unreal.MoviePipelineObjectIdRenderPass
- unreal.MoviePipelineImageSequenceOutput_PNG / EXR
- PrimitiveComponent.set_custom_depth_stencil_value

验收：
- 命令行/编辑器能一键跑 20 个场景；
- 20 个场景的 rgb/masks/depth/meta 都存在；
- 给出耗时统计和失败列表。
```

---

## Prompt 6：质量检查

```text
继续。请对已生成的 20 个场景做自动质检，不要只看图。

检查项：
1. 文件完整性：每个场景 rgb/depth/object_id/amodal/visible/stem/ownership/meta 是否齐全。
2. 掩膜合法性：
   - amodal 非空、非全屏；
   - visible ⊆ amodal；
   - 同一像素的 visible 最多属于一棵树；
   - ownership 与 visible 一致；
   - stem ⊆ amodal。
3. 层序：layer_order 与深度/ID 一致。
4. 深度：无 NaN/Inf，范围合理，和 RGB 对齐。
5. 遮挡分布：统计每对树的 mask 面积重叠率；至少 80% 的相邻对在 5%–40%；全 0 或全 1 的场景标记失败。
6. 画面：树完整、主干可见、没有悬空、没有明显穿插、背景是 3D。
7. 重复：感知哈希/文件哈希检查重复场景。

交付：
- reports/qa_20.json；
- 失败场景列表和原因；
- 随机 10 张预览图；
- 修复计划。
```

---

## Prompt 7：扩到 500 与性能

```text
继续。20 个场景质检通过后，扩到 500 个。

要求：
- 2 棵 150、3 棵 200、4 棵 150；
- 至少 20 种树，记录每种使用次数；
- 按 scene_id 划分 train/val/test = 70/15/15，不能随机切图；
- 每 50 个场景输出一次进度、显存峰值、失败数；
- 失败自动重试 1 次，仍失败写 failures.json；
- 控制 1080p、2K 贴图、小场景，避免 16GB 显存 OOM；
- 如果 OOM：降背景树数量/贴图/采样，不要降标签质量。

交付：
- Dataset/images 500 张；
- Dataset/masks 500 组；
- Dataset/depth 500 张；
- Dataset/meta 500 份；
- Dataset/index.json；
- reports/qa_500.json；
- reports/performance.md。
```

---

## Prompt 8：打包与验收

```text
继续。请把数据集整理成可直接训练的格式，并写验收报告。

目录：
Dataset/
  images/
  depth/
  masks/{scene_id}/amodal|visible|stem|ownership.png
  meta/
  splits/train.txt val.txt test.txt
  index.json
  README.md
  ASSET_CREDITS.md
  previews/

README 必须写：
- 数据来源、合成方式；
- 图像/掩膜/深度分辨率与单位；
- 掩膜层定义；
- 层序/ownership 规则；
- 每类数量、树种数量、遮挡分布；
- 已知问题（同种树、简单背景、无真实域验证等）；
- 许可与署名。

验收报告必须包含：
- 实际文件计数（用命令输出，不要手写）；
- 掩膜合法性统计；
- 遮挡率分布；
- 失败/缺失场景；
- 随机 20 张预览；
- 与真实数据 20260411 的差异说明（只做定性，不训练）。

最后给我：
1. 数据集绝对路径；
2. 总大小；
3. 500 个场景是否齐全；
4. 还缺什么。
```

---

## 通用约束（每次追加）

```text
硬性约束：
- 16GB 显存、32GB 内存；1080p；小场景。
- 不用 City Sample、4K/8K 贴图、超大森林。
- 背景树必须 3D，不能拿 HDRI 里的树凑。
- 标签必须逐树渲染/ID pass 得到，不能手画、不能猜。
- 所有资产许可清晰；记录作者/来源/许可。
- 没有真实文件证据，不得声称完成。
- 不要伪造指标；不确定就停下来问。
```
