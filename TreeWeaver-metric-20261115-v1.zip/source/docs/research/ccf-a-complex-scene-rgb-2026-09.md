# CCF A 论文精读：复杂场景树木 RGB 测量

检索日期：2026-09-28。会议等级按 [CCF 第七版正式目录](https://www.ccf.org.cn/Academic_Evaluation/By_category/)及其[人工智能分表](https://www.ccf.org.cn/Academic_Evaluation/AI/)核对：CVPR、ICCV、ICML 为 A 类；IJCV 为 A 类期刊。只把主会正式长文算作对应类别，Workshop、Findings 不算。以下依据论文原文或官方论文页；“可借鉴”是本项目的推论，不是原论文给出的树木测量结论。

## 第一组：直接触及复杂树木场景

### 1. Tree Instance Segmentation With Temporal Contour Graph — CVPR 2023

[论文与 PDF](https://openaccess.thecvf.com/content/CVPR2023/html/Firoze_Tree_Instance_Segmentation_With_Temporal_Contour_Graph_CVPR_2023_paper.html)

- 输入：无人机俯视的 RGB 图像序列；输出：密集森林的单株树冠实例及计数。
- 方法：先对序列作过分割，再建立含时间与轮廓特征的图，通过图卷积合并相邻树冠碎片；利用视点变化造成的自遮挡线索。
- 与我们的差别：它不是地面手机拍摄，没有树干胸高截面或树高/材积的公制测量；论文明确指出单图不可用，依赖序列和光流。
- 必须吸收的教训：以“树冠相互遮挡时用结构图分株”为笼统创新点已经站不住。若用无序照片，需要设计与拍摄顺序无关的关联机制，并把分株误差对测量值的影响量化。

### 2. ForestFormer3D — ICCV 2025

[论文与 PDF](https://openaccess.thecvf.com/content/ICCV2025/html/Xiang_ForestFormer3D_A_Unified_Framework_for_End-to-End_Segmentation_of_Forest_LiDAR_ICCV_2025_paper.html)

- 输入：高密度森林 LiDAR 点云；输出：单株实例和地面、植被、枝干等语义。
- 方法：实例与语义引导的查询点、块间合并和训练时的一对多关联；针对密集冠层、多尺度和跨场地泛化。
- 与我们的差别：手机 RGB 重建点云的密度、缺口和尺度误差不同；单张 RGB 无点云。因此不能将其结果直接当作手机输入的精度证据。
- 必须吸收的教训：根锚或拓扑图本身也不是自动成立的新颖性。要做相同 RGB 输入下的对照，以及与较强 3D 树木分株方案的条件比较。

## 第二组：遮挡和“看见”与“猜到”的分界

### 3. Deep Occlusion-Aware Instance Segmentation With Overlapping BiLayers — CVPR 2021

[论文与 PDF](https://openaccess.thecvf.com/content/CVPR2021/html/Ke_Deep_Occlusion-Aware_Instance_Segmentation_With_Overlapping_BiLayers_CVPR_2021_paper.html)

- 输入：单张 RGB；输出：遮挡物与被遮挡目标的实例掩膜。
- 方法：分成前后两层，在预测前景遮挡物时辅助预测后景目标的完整形状。论文强调物体真实边缘与遮挡造成的边缘不同。
- 与我们的差别：COCO/KINS 中的物体形状先验不能直接保证树木分叉、细枝、重叠树冠的真实性；隐藏树干的预测不能冒充胸径实测。
- 可借鉴：目标树可见掩膜、前景遮挡掩膜、隐藏部分假设分开保存，并且只让可见证据直接参加尺寸计算。

### 4. Amodal Ground Truth and Completion in the Wild — CVPR 2024

[论文与 PDF](https://openaccess.thecvf.com/content/CVPR2024/html/Zhan_Amodal_Ground_Truth_and_Completion_in_the_Wild_CVPR_2024_paper.html)

- 核心问题：人工在照片上画出“物体被挡住后本应有的轮廓”有主观性。
- 方法：借助已有三维场景生成可见与完整掩膜的可验证标签，再研究遮挡补全。
- 可借鉴：项目数据应分别存“画面可见真值”和“由另一视角或独立三维测量确认的隐藏真值”；不能把单图人工想象的树冠边界当成客观标注。

### 5. MUVA: Multi-View Amodal Instance Segmentation — ICCV 2023

[论文与 PDF](https://openaccess.thecvf.com/content/ICCV2023/html/Li_MUVA_A_New_Large-Scale_Benchmark_for_Multi-View_Amodal_Instance_Segmentation_ICCV_2023_paper.html)

- 输入：多个视角的 RGB；输出：各视角的可见与完整物体实例掩膜。
- 方法：在同一视角的不同实例之间、同一实例的不同视角之间分别聚合特征；跨视角补足遮挡信息。
- 与我们的差别：基准是商店商品等场景，不是树林；系统还需自己识别无序照片中哪棵树对应哪棵树，并恢复尺度。
- 可借鉴：多图模式优先寻找“这一张看不见、另一张真的看见”的证据；另一张仍看不见时保留未知。

## 第三组：无序照片几何与单图尺度

### 6. DUSt3R: Geometric 3D Vision Made Easy — CVPR 2024

[论文与 PDF](https://openaccess.thecvf.com/content/CVPR2024/html/Wang_DUSt3R_Geometric_3D_Vision_Made_Easy_CVPR_2024_paper.html)

- 输入：不提供相机位姿/内参的 RGB 图片；输出：点图、对应关系及可恢复的相机几何。
- 方法：把两张图的稠密三维点图直接回归，并将多对结果全局对齐。论文训练时显式处理尺度歧义。
- 可借鉴：作为无序手机照片重建基线，与 COLMAP 比较注册成功率、胸高处点密度和公制误差；真实尺度仍用画面中的已知长度参照物校准。

### 7. VGGT: Visual Geometry Grounded Transformer — CVPR 2025

[论文与 PDF](https://openaccess.thecvf.com/content/CVPR2025/html/Wang_VGGT_Visual_Geometry_Grounded_Transformer_CVPR_2025_paper.html)

- 输入：一张、数张到大量 RGB 视图；输出：相机、深度、点图和点轨迹。
- 可借鉴：作为强几何提供器，与 COLMAP/DUSt3R 对照；重点测试树叶重复纹理、风动、背光和两图弱视差。单图预测是模型推断，并不消除不可见树冠/背面树干的歧义。
- 新颖性边界：换成 VGGT 不能构成本项目方法贡献。

### 8. Single View Metrology — IJCV 2000

[IJCV 论文页](https://link.springer.com/article/10.1023/A:1026598000963)

- 核心结论：单图中的真实尺寸可在参考平面、消失线和空间方向等几何约束成立时求得。
- 对本项目的限制：仅有标志物长度，并不能证明高处树梢、树冠外缘与标志物在同一深度平面。单图公制树高/冠幅必须报告其几何假设，并在假设不成立时拒绝“精确实测”。

## 第四组：输出可信度，而不只是分割指标

### 9. SelectiveNet: A Deep Neural Network With an Integrated Reject Option — ICML 2019

[PMLR 论文页](https://proceedings.mlr.press/v97/geifman19a.html)

- 核心问题：允许模型拒绝不可靠答案，以“接受多少样本时错误率多少”评估。
- 对本项目的启发：分别校准树高、胸径、冠幅的出数率与误差，而不是用一个全局置信度。论文不证明 TreeWeaver 当前阈值已校准；必须用独立真值实验。

## 对本项目的判断

上述论文中，TreeCoG 最接近“复杂树木 RGB 分株”，BCNet/MUVA 最接近“遮挡证据”，DUSt3R/VGGT 最接近“无序 RGB 几何”。没有一篇可直接作为“给一张或几张地面手机 RGB，在密集树林中可靠输出标准树高、胸径、冠幅和材积”的现成解决方案；但这些子问题都已有强先例。因此，我们只能主张**一个尚待证明的组合研究问题**：针对具体林业参数，联合估计目标树归属、可见性、几何尺度与可测性，并在复杂场景中降低有数值却错得很大的输出。

可证伪实验按三个阶段执行：①同图比较目标树可见/隐藏掩膜与树木身份；②在同一真实尺度参照与同一照片集合下比较几何测量误差；③以同一出数率比较各方法的严重错误比例。按遮挡类型和严重程度拆分结果，并报告拒绝率、手机型号和采集张数。若仅提高掩膜 IoU 而未改善标准参数误差或有用出数率，不能主张完成本项目目标。
