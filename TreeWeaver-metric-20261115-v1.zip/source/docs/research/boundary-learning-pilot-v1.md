# Boundary-learning pilot v1: a positive control and a failed stress test

Date: 2026-09-28. Status: completed synthetic feasibility experiment. No field
DBH, metric accuracy, or publishable novelty claim.

## Question and controlled protocol

Can a learned boundary classifier replace the oracle edge labels used in the
previous censored-width primitive? Does RGB help beyond mask geometry?

Generate 128-by-128 layered RGB images containing a locally straight projected
stem and partial foreground objects. Ground-truth visible masks are supplied
to isolate boundary classification from segmentation error. This is a simple
2-D diagnostic renderer, not photorealistic forestry or 3-D reconstruction.

Use 512 training tree groups, 128 validation groups, and 128 held-out test
groups. Test variants reuse only test-group trees. Underlying geometry and all
variants of one tree stay in the same split. Two models are trained for ten
epochs: mask-only (18,721 parameters), RGB+mask (19,153 parameters). Inputs are
33-by-33 local patches; the right boundary is mirrored to the same orientation.
Hidden masks, true widths, group IDs, and edge labels are excluded from inputs.

The training/validation/test group ranges and hyperparameters were written to
`configs/research/boundary-pilot-v1.json` before training. The best epoch uses
validation loss. Threshold candidates are fixed. Qualification requires at
least 16 bounded validation scenes, at most 5% wrong bounded intervals, and at
most 1% falsely exposed labels among accepted boundary labels. These are
empirical validation requirements, not confidence or coverage guarantees.
Both models selected 0.98. Test data did not choose the threshold.

## Results with unchanged checkpoints and thresholds

On 128 standard held-out scenes:

- Mask-only: 91 bounded intervals, 35 unbounded, 2 inconsistent; none of the
  91 bounded intervals missed the true width. Bounded midpoint MAE was 1.17 px.
- RGB+mask: 37 bounded intervals, 88 unbounded, 3 inconsistent; none of the
  37 bounded intervals missed the true width. Bounded midpoint MAE was 2.48 px.
- Oracle edge types: 103 bounded intervals, 25 unbounded, no inconsistencies.
  The 103 bounded intervals contain the truth; midpoint MAE was 1.02 px.
- Treating every visible endpoint as an exposed edge: 51 bounded intervals,
  of which 25 missed the true width; the other 77 cases were inconsistent.
- Treating every endpoint as censored: all 128 cases were unbounded. Trivial
  all-abstention must not be described as perfect measurement accuracy.

On 128 held-out curved-occluder variants, mask-only produced 80 bounded
intervals with 2 misses; RGB+mask produced 27 with 1 miss. Changing occluder
appearance to bark-like texture did not improve RGB usefulness. Mask-only
results remain identical when only RGB texture changes, as expected.

On shared standard-test outputs, the interval midpoint and a same-label
exposed-edge least-squares baseline had MAE 0.92 versus 1.17 px for mask-only,
and 0.76 versus 0.85 px for RGB+mask. These comparisons use different accepted
subsets between variants and cannot establish that RGB is more accurate. With
oracle labels, the simpler edge-only baseline has essentially the same error
as interval midpoints (1.01 versus 1.02 px). Pixel-center quantization and the
declared one-pixel tolerance also affect midpoint error.

## Exploratory falsification: parallel occlusion

After the initial run, introduce a new geometry where an entire occluder edge
runs parallel to the stem boundary. Use 128 new groups starting at 30000.
Retain model hashes, weights, and thresholds; perform no retraining or tuning.

- Mask-only: 111 bounded intervals, **22 misses** (19.8%); bounded midpoint
  MAE 3.88 px. The increased output rate hides a large increase in error.
- RGB+mask: 31 bounded intervals, **3 misses** (9.7%); midpoint MAE 3.11 px.

The test also constructs 25 pairs with exactly identical RGB and visible-mask
inputs but two different possible hidden widths. In one explanation the
right-side surface is foreground covering a wider trunk; in the other it is
background beside a narrower trunk. A deterministic predictor must return
the same answer for both. Mask-only issued finite intervals for 22 such pairs,
RGB+mask for 3; none of those finite intervals contained both possible widths.

This exposes an identifiability limitation and a classifier shortcut. In this
experiment, high sigmoid confidence was insufficient evidence that a visible
line was the physical stem edge. Generic mask geometry classification and
hard probability thresholds do not resolve unknown depth ordering.

## Research decision

Do not release these weights as a usable measuring model. Preserve them as
baselines. The initial positive result supports running the learning pipeline;
the stress failure rejects a naive classifier-plus-hard-threshold design.

Next iteration should explicitly preserve ambiguous edge interpretations,
train with matched occlusion interventions and depth-order alternatives, and
test how an additional independent view removes ambiguity. Additional images
cannot simply be merged by filename or assume known user-supplied camera
relationships. Perfect-mask experiments must be followed by corrupted-mask
tests and independently checked real boundary examples before metric testing.

Keep the explored parallel-occlusion cases in a development stress suite;
reserve new tree groups and new occluder families for the next untouched test.
Require improved error at matched output coverage and same photo burden,
including the strong same-label exposed-edge baseline. Wider intervals or
more refusals alone do not establish a useful improvement.

## Artifacts and reproducibility

- Config: `configs/research/boundary-pilot-v1.json`.
- Renderer/features: `src/treeweaver/simulation/censored_rgb.py`.
- Training runner: `workers/boundary_evidence/train_pilot.py`.
- Fixed-model stress runner: `workers/boundary_evidence/stress_pilot.py`.
- Local outputs: `reports/boundary-learning/pilot-v1/` and
  `reports/boundary-learning/parallel-stress-v1/`.
- Model checkpoints, all per-scene measurements, training histories, and
  diagnostic images remain in these output directories; reports are ignored
  by Git. The code and protocol are versioned. Commands are in the worker README.
