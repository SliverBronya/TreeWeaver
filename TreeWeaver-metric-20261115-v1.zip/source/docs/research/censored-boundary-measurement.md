# Research decision: measuring stems from censored boundary evidence

Date: 2026-09-28. Status: research hypothesis plus a tested mathematical
primitive. No field-accuracy, novelty-priority, or calibrated-coverage claim.

## Decision and practical scope

Prioritize stem diameter at an independently located breast-height section
under occlusion, with one ordinary RGB image and additional unordered images
only when needed. The already accepted known-length object may appear in the
image. The user does not provide poses or a stereo baseline. An image marker
still requires geometric transfer to the measured section; a global pixels-
per-metre conversion is not valid across arbitrary depths. Without a metric
anchor the geometry stage returns projected or relative dimensions.

The first research output is a usable diameter observation or an evidence-
conditioned range with a specific missing observation, rather than a complete
tree model. Height, crown extent, and stem volume follow only after their own
geometric evidence is established. Species recognition is a separate product
component, not part of the proposed measurement novelty.

## Closest prior work and excluded novelty claims

- SAMEO, *Segment Anything, Even Occluded*, CVPR 2025, already adapts SAM for
  amodal masks and uses large-scale synthetic occlusion data. Merely adapting
  SAM or adding artificial occlusion is not a new contribution.
  https://arxiv.org/abs/2503.06261
- Amodal3R, ICCV 2025, reconstructs plausible complete 3-D objects from partial
  observations using visibility/occlusion-aware conditioning. Merely generating
  a hidden tree surface is not a new contribution or measured ground truth.
  https://arxiv.org/html/2503.13439v1
- Guan, Franco, and Pollefeys, *Multi-view Occlusion Reasoning for Probabilistic
  Silhouette-Based Dynamic Scene Reconstruction*, IJCV 2010, already studies
  probabilistic occlusion reasoning and silhouette reconstruction. Positive
  and negative visibility evidence is established prior work.
  https://www.research-collection.ethz.ch/handle/20.500.11850/23706
- *Robust Single-Image Tree Diameter Estimation with Mobile Phones*, Remote
  Sensing 2023, handles occluded trunks using RGB and depth, including linear
  boundary modelling; its diameter estimate is explicitly distinguished from
  geometrically locating the standard DBH section.
  https://www.mdpi.com/2072-4292/15/3/772
- TreeDGS, Remote Sensing 2026, couples RGB reconstruction, visibility/opacity
  support, and weighted DBH fitting. Reliability-weighted geometry alone is
  therefore not a defensible novelty claim.
  https://www.mdpi.com/2072-4292/18/6/867

This targeted search does not establish that the proposed formulation is the
first of its kind. A full related-work and implementation comparison remains
necessary before any publication claim.

## Failure mechanism

In an occluded row, the visible bark interval [a,b] need not terminate at the
true projected trunk edges L and R. Treating every segmentation endpoint as
an actual edge creates systematic diameter shrinkage, which a robust loss
need not remove: the incorrect endpoints can be the majority of observations.

The observation provides L <= a and R >= b. Only when independent evidence
supports an exposed silhouette edge may we add L approximately equals a or
R approximately equals b. Thus the missing region imposes a one-sided
constraint, rather than a fabricated equality or automatic loss of the whole
photo. Neighbour-tree ownership is another latent variable: uncertain bark
pixels cannot all be pooled into the same trunk.

## Proposed algorithm, beyond the current primitive

1. **Target-conditioned boundary evidence.** Reuse a frozen image encoder and
   instance proposals. Train a compact boundary head on local RGB patches,
   trunk structure, neighbouring instances, and, when available, cross-view
   correspondences. Predict exposed target edge, target interior terminated
   by an occluder, different-tree edge, and unknown, with coordinate error
   estimates. The output is evidence for measurement, not simply an amodal
   binary mask. Pixel uncertainty and class probability need calibration.

2. **Joint ownership, visibility, and geometry.** Maintain competing tree
   assignments and estimated camera hypotheses rather than accepting the
   highest appearance score. Fit a short stem segment and scale/section
   geometry with exposed-edge residuals, censored inequalities, reprojection
   consistency, and bounded shape assumptions. Stable bark and branch junctions
   carry more geometric evidence than moving leaves. Missing roots are never
   inferred merely from the lowest visible trunk pixel. Unknown camera poses
   must be estimated from RGB internally and their uncertainty propagated.

3. **Parameter bounds across plausible hypotheses.** For each plausible
   ownership/pose/visibility hypothesis, find the smallest and largest diameter
   consistent with evidence and declared tolerances. Combine alternatives by
   a union/envelope, not by intersecting contradictory tree identities. Report
   geometry-only bounds separately from bounds tightened by shape priors.
   A single narrow local optimizer covariance is insufficient. In the full
   nonlinear model, approximate optimization bounds must not be advertised as
   certified global bounds.

4. **Select a useful extra observation.** If diameter remains ambiguous, target
   the missing edge or breast-height section. Choose among already uploaded
   images first. A suggested new view should optimize expected reduction of
   parameter ambiguity; issuing a reliable left/right direction itself needs
   sufficient pose/occluder evidence. Generic capture guidance is the fallback.

The candidate contribution is the coupled measurement objective, trained
boundary evidence, and handling of unresolved identity/visibility in diameter
inference under a small capture budget. Each component has related prior work;
the combination is only scientifically useful if experiments demonstrate a
gain against strong alternatives at equal capture burden and output coverage.

## Training with limited manual data

Generate known stem geometries and render varying camera intrinsics, lean,
taper, noncircular sections, branches, neighbouring trees, foliage, objects,
lighting, and blur. Rendering supplies ownership, true depth ordering, and
exposed versus censored boundaries. Include cases outside the simple model.
Preserve tree and scene identity across all views and augmentations for splits.

Use added occlusion as a controlled intervention: hiding more target evidence
should not create unjustified precision. A consistency term can require the
new feasible interval to contain the pre-occlusion interval under matched
geometry and nested evidence. Do not force the predicted point estimate to
remain unchanged when the evidence becomes insufficient. Penalize needless
interval width with an interval scoring loss alongside visibility supervision
and measurement loss, preventing an all-unknown/all-wide trivial solution.

Real photos and checked boundary labels are required for calibration and domain
transfer. Model-produced masks are pseudo-labels, not independent truth. A
small real external set with measured DBH, marked section, actual marker
geometry, and visibility labels remains indispensable; existing public data
can reduce but cannot erase this requirement.

## Implemented primitive and falsification experiment

`src/treeweaver/geometry/censored_stem.py` represents each projected boundary
as a local line, applies the exposed/censored constraints, and solves two
linear programs for minimum and maximum pixel width at a supplied image row.
It returns bounded, unbounded, inconsistent, or outside-support. It does not
predict edge labels, infer camera poses, locate 1.3 m, or output metric DBH.

Reproduce with:

```powershell
.venv\Scripts\python.exe scripts/benchmark_censored_stem.py reports/censored-stem/repeat.json --seeds 60
```

The 300 synthetic trials include ordinary line fitting, Huber fitting, and a
strong exposed-edge-only least-squares baseline using the same edge labels.
Visibility labels are supplied by the generator except in the corruption test.

- Alternating left/right occlusion: all 60 conditional intervals contain the
  true pixel width. Ordinary and Huber MAE are 27.04 and 21.72 px. However,
  exposed-edge-only fitting already achieves 0.084 px MAE. Consequently this
  experiment does **not** establish an accuracy advantage over visibility-aware
  fitting or algorithmic novelty.
- Permanently hidden right edge: all 60 cases have no finite maximum width;
  the primitive does not invent one from a learned average stem shape.
- Curved stems outside the local straight-line model: all 60 cases report
  inconsistent evidence. Ordinary width fitting can still be accurate here;
  this exposes a coverage cost of the restrictive model, not an improvement.
- Incorrectly label the occluded edge as exposed: all 60 cases produce bounded
  intervals that miss the true width. Thus the key unsolved problem is reliable
  boundary type inference and uncertainty, not solving the two linear programs.

These are conditional feasibility intervals, not empirical 95% confidence
intervals. Unbounded intervals containing truth do not count as useful accurate
measurements. The field value of the prototype is currently untested.

## Evidence required before advancing the novelty claim

Compare against visible-mask fitting, robust fitting, visibility-aware edge
fitting, amodal completion followed by measurement, and suitable multi-view
geometry baselines. Keep pretrained backbones, scale information, photo count,
selection protocol, and training data budgets controlled where possible.

Use tree/site-disjoint tests; never split augmented views of one tree across
train and test. Report MAE/RMSE/bias, errors at matched output coverage, interval
coverage and width, gross-error rate, false tree merges, runtime, and photos
per completed measurement. Stratify by side-specific stem occlusion, missing
root/section, touching stems, forks, curvature, and camera/view diversity.

Required ablations remove boundary labels, one-sided constraints, identity
hypotheses, pose uncertainty, and occlusion-intervention training separately.
Oracle-label experiments measure an upper bound and must be reported separately
from predicted-label experiments. If the full system cannot beat strong
visibility-aware baselines at matched user effort, this direction has not yet
earned a research contribution, regardless of its code complexity.
