# Complex-scene RGB tree measurement: literature and first implementation change

Date: 2026-09-28. This note records primary research sources, the limits of
their transfer to ordinary phone RGB input, and a testable next experiment.
It does not claim that TreeWeaver is already more accurate than these methods.

## Findings that change the design

1. **Single-view metric geometry needs scene constraints.** Criminisi, Reid,
   and Zisserman's *Single View Metrology* derives measurements from a
   reference plane and direction/vanishing geometry. A known-size marker alone
   does not establish that a distant crown boundary lies in the marker's depth
   plane. In our setting, the marker geometry, trunk plane/axis, root, and
   endpoint visibility must each be checked before releasing metric height or
   diameter. [Primary paper](https://ora.ox.ac.uk/objects/uuid%3Afba56263-29d9-45ee-9fb2-93631037a127).

2. **Visible and hidden regions are distinct variables.** BCNet explicitly
   separates an occluding object from the partially occluded object. MUVA shows
   why multiple views help resolve single-view amodal ambiguity. Neither paper
   establishes that a completed hidden tree surface is measured ground truth.
   Our masks must therefore distinguish visible support, predicted hidden
   support, conflicting predictions, and unobserved regions.
   [BCNet](https://openaccess.thecvf.com/content/CVPR2021/html/Ke_Deep_Occlusion-Aware_Instance_Segmentation_With_Overlapping_BiLayers_CVPR_2021_paper.html);
   [MUVA](https://openaccess.thecvf.com/content/ICCV2023/html/Li_MUVA_A_New_Large-Scale_Benchmark_for_Multi-View_Amodal_Instance_Segmentation_ICCV_2023_paper.html).

3. **Unordered RGB reconstruction is established prior work.** COLMAP's
   incremental structure from motion explicitly handles unordered image
   collections. Camera pose recovery itself cannot be claimed as TreeWeaver's
   novelty. The open question is whether tree identity and measurement remain
   stable when repeated textures, motion, occlusion, or weak parallax damage
   that reconstruction.
   [COLMAP paper](https://openaccess.thecvf.com/content_cvpr_2016/papers/Schonberger_Structure-From-Motion_Revisited_CVPR_2016_paper.pdf).

4. **Dense forest tree segmentation is already competitive research.**
   TreeLearn studies individual trees in ground-based forest LiDAR; ForAINet
   and ForestFormer3D also target forest instance and semantic segmentation.
   Their point clouds are denser and differently sensed than ordinary phone
   RGB reconstructions. We should compare against their ideas, not claim that
   root-first separation or 3-D tree segmentation is inherently new.
   [TreeLearn](https://arxiv.org/abs/2309.08471);
   [ForAINet](https://arxiv.org/abs/2312.15084);
   [ForestFormer3D](https://openaccess.thecvf.com/content/ICCV2025/html/Xiang_ForestFormer3D_A_Unified_Framework_for_End-to-End_Segmentation_of_Forest_LiDAR_ICCV_2025_paper.html).

5. **Smartphone photogrammetry has already estimated DBH and stem volume.**
   The Forestry study used a large smartphone photo survey and cylinder models
   to estimate stem diameter and volume. A study with RGB plus phone depth
   tested complex conditions, but its input is not RGB-only and its authors
   explicitly distinguish their diameter estimate from a physically located
   breast-height section. TreeWeaver needs to demonstrate added value on
   difficult scenes and on standard-correct DBH, not merely reproduce an
   ordinary SfM-to-cylinder pipeline.
   [Smartphone photogrammetry study](https://academic.oup.com/forestry/article/93/3/411/5688859);
   [RGB-D single-image study](https://www.mdpi.com/2072-4292/15/3/772).

6. **Refusing an unreliable answer is an established statistical idea.**
   Selective prediction evaluates error against the fraction of cases for
   which the system issues an answer. Our contribution, if supported by
   experiments, would be tree-parameter-specific evidence and risk calibration
   under complex scene conditions, not the reject option by itself.
   [Selective classification](https://papers.nips.cc/paper_files/paper/2017/hash/4a8423d5e91fda00bb7e46540e2b0cf1-Abstract.html).

## Implemented in this iteration

The previous image audit counted intersections of two visible tree masks as
"overlap." With exclusive visible masks, the intersection is zero even if a
foreground tree hides the target. The audit now treats visible-mask intersection
as **prediction conflict**. If an internally produced amodal trunk hypothesis
and a geometrically located breast-height image region are available, it also
computes how much of that region is missing from the visible trunk mask and how
much of the missing area is covered by a predicted foreground occluder.

The diameter gate now rejects a candidate with hidden breast-height support.
This is conservative: the amodal mask is a model hypothesis. The gate does not
turn invisible pixels into measured diameter. If the region or amodal evidence
does not exist, this additional diagnostic is unavailable. The image gate now
uses `candidate` rather than `ready` to make explicit that metric scale, camera
geometry, and field accuracy still need separate verification.

## Research hypothesis and falsification plan

Hypothesis: for a fixed capture burden (one RGB image, then two to five unordered
images), a target-conditioned representation that separates visible geometry,
predicted hidden geometry, and ambiguous tree ownership can reduce **false
confident DBH and height outputs** in overlapping forest scenes at useful
measurement coverage.

Compare three frozen variants on tree-disjoint field test trees:

- baseline A: visible masks plus ordinary SfM/cylinder or single-image geometry;
- baseline B: A plus root-conditioned 3-D ownership;
- proposed C: B plus explicit hidden/ambiguous evidence and parameter-specific
  selective gates.

For each attempt, save every tree and every requested parameter, including
failed or withheld results. Report visible-mask and tree-ID quality, DBH/height
MAE and bias on accepted cases, error at fixed coverage, risk-coverage curves,
95% interval coverage, and extra-image burden. Stratify by stem occlusion,
crown overlap, touching stems, understory, forks, buttress, lean, and
root/apex truncation. Compare camera sites and phone models separately.

Independent field truth must include tape/caliper DBH at a marked breast-height
plane, measured height, crown dimensions where possible, and a record of
whether the standard breast-height plane is actually visible in each image.
The current synthetic tests only confirm logic; they cannot establish the
hypothesis. If C fails to improve error at matched coverage or has too many
refusals, the proposed contribution is not supported.
