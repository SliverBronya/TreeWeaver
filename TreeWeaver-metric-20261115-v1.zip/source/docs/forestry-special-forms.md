# Complex stem forms and diameter position

TreeWeaver does not define every trunk section as DBH merely because it is
1.3 m above a reconstructed ground plane. The policy implementation is in
`treeweaver.forestry.diameter_position` and records both the chosen plane and
the rule that selected it.

The initial policy follows FAO field-manual cases:

- height on a leaning tree is measured along the stem;
- sloping-ground height starts at the uphill ground contact;
- forks below 0.3 m produce separate tree entities measured at 1.3 m;
- forks between 0.3 m and 1.3 m produce separate entities measured 1 m above
  the fork origin;
- a fork at breast height is measured on the common bole below its swelling;
- buttress extending above 0.9 m moves the plane to 0.3 m above its end;
- aerial roots move the plane to 1.3 m above the root/stem boundary;
- an irregular breast-height section moves the plane just above the affected
  interval.

`treeweaver.geometry.stem_form` now derives initial evidence from a metric 3-D
trunk profile sampled at 0.1 m intervals. It records robust section radius,
eccentricity, connected-component count, and support count. A fork requires at
least three consecutive multi-component sections; basal enlargement and local
breast-height anomalies are compared with the stable upper-bole radius. Batch
measurement uses this detector automatically and records its confidence and
diagnostics with the chosen plane.

The detector has passed controlled synthetic tests but has not yet demonstrated
field accuracy on labelled forked and buttressed trees. Until that benchmark is
complete, detected low forks fail closed instead of emitting one combined DBH.
Conflicting special forms also fail closed because national inventory protocols
can differ.
