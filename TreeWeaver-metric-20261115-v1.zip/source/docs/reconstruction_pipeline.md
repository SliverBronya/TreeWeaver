# Auditable reconstruction pipeline

## Provider boundary

TreeWeaver does not treat COLMAP as the research contribution. COLMAP is one
replaceable provider that emits the framework-neutral `Reconstruction` model.
VGGT or another SfM/MVS system can implement the same protocol and be compared
without changing metric geometry.

## COLMAP baseline

Run:

```powershell
treeweaver reconstruct-colmap capture.json run-directory --executable C:\tools\COLMAP\colmap.exe
```

Add `--dense` for the point cloud required by multi-tree association and
semantic fusion:

```powershell
treeweaver reconstruct-colmap capture.json run-directory --dense
```

This additionally runs image undistortion, geometrically consistent patch-match
stereo, and stereo fusion, producing `run-directory/fused.ply`. Dense mode is
explicit because it is substantially more expensive and commonly needs a
CUDA-capable COLMAP build.

Use `--cpu` when CUDA is unavailable. The adapter runs feature extraction,
sequential matching, incremental mapping, and text-model conversion. It passes
arguments as an array with `shell=False`, stores stdout/stderr and parameters in
`run-log.json`, rejects an existing output directory, and never silently
continues after a failed process.

The default options follow the current COLMAP 4.x names
`FeatureExtraction.use_gpu` and `FeatureMatching.use_gpu`. Because CLI flags can
change between major releases, experiments must record the actual COLMAP build
and must not mix versions within a benchmark.

Official references:

- https://colmap.github.io/cli.html
- https://colmap.github.io/install.html
- https://github.com/colmap/colmap/blob/main/doc/cli.rst

On Windows, the official bundle exposes `COLMAP.bat` to configure DLL search
paths. TreeWeaver deliberately avoids shell execution; configure a directly
executable `colmap.exe` whose runtime libraries are already on `PATH`, or use a
controlled wrapper installed by the research environment.

## Quality gate

The default gate is deliberately explicit and configurable. It currently
requires:

- at least 70% of input frames registered;
- at least 100 sparse points;
- median reprojection error no greater than 1.5 pixels;
- median track length at least 3 views;
- non-trivial camera baseline.

These are engineering defaults, not validated biological thresholds. They must
be tuned only on training/validation sites and frozen before the external test.
`quality.json` records every metric and all failed conditions. A failed sparse
gate prevents the pipeline from presenting tree measurements as valid.

## Metric registration

SfM reconstruction has arbitrary scale. `AnchorCorrespondence` links the two
reconstructed 3-D endpoints of a visible marker/staff to its known physical
length. Multiple correspondences are fused robustly; inconsistent anchors are
rejected. Applying scale transforms points and camera translations together
and records scale uncertainty. A metric reconstruction cannot be scaled twice.
