# 真实多树验证：当前入口与人工标注

本轮保留原模型权重，不将预测输出当作人工真值。`20260411` 及旧60张
hold-out 禁止进入训练；机器可读约束见
`configs/research/dataset-usage-2026-11-01.json`。

## 已完成的验证

- 旧5小时模型、旧数据和相关源码的冻结快照在
  `reports/baseline-freeze-2026-11-01/`。其中包括best权重、源码、基座revision、
  工作区状态、运行环境、原Fig500全部5004个文件的内容哈希。
- 真实多树结果在 `reports/real-multitree-baseline-2026-11-01/`：
  六张照片，二十个检测候选，全部保留候选同图联合提示。
- 原版SAM2同提示基线、原始visible、amodal hypothesis、ownership和
  ownership-constrained派生结果分开保存。归属后处理令2/20个候选变空；
  候选中有非树错框。没有人工GT，不能由这些结果报告准确率。
- 拼贴数据来源核实为TreeStereo v4的六棵树，不是20260411；但源树共享，
  原200/40图像划分不提供新树泛化证据。孤立可见树的剪贴轮廓是补全代理，
  不能称为真实观测amodal。

## 人工标注包

`reports/real-annotation-pack-2026-11-01/` 有30张原始照片副本、LabelMe空白文件、
contact sheet及validation manifest。当前审核标签数为零，未制造GT。
文件名组仅为抽样提示，不是验证过的跨视图树身份。

使用LabelMe编辑 `labelme/*.json`，保留原图尺寸和图像哈希：

- 一棵独立根系用一个正整数 `group_id`，跨形状一致。
- `visible`：树的确定可见像素，多边形；枝叶孔洞保留。
- `stem`：确定树干，多边形，可缺省。
- `unknown`：不确定区域，多边形；`background`：明确背景，多边形。
- `positive_stem_point`：目标树干点；`negative_point`：该目标的邻树/遮挡物负点。
- `prompt_box`：可选人工框。没有人工框时转换器由GT计算框，明确标为
  `gt_derived_box_upper_bound`，不能解释为自动检测成绩。
- 同一实例多边形的 `flags.hole=true` 用于减去孔洞。

默认 `treeweaver_coverage="partial"`：未标注像素全为unknown，不当背景。
仅当画面目标和背景已充分审查时，才可声明 `exhaustive_visible`，其余树仍需
标为unknown。partial的已知区域IoU与完整全图IoU分开报告，同时查看有效像素比例
和已知背景像素数；只有正例时不能据高IoU推断假阳性少。

人工完成并审查后，元数据应明确为：

```json
{
  "flags": {"assistant_draft": false},
  "treeweaver_provenance": "human_annotation",
  "treeweaver_review": {"state": "approved", "reviewer": "实际审核者"}
}
```

转换只导出明确审核过的照片，重叠/冲突标签保持unknown，不生成不可见区域标签：

```powershell
.venv/Scripts/python.exe scripts/import_real_labelme.py `
  --pack reports/real-annotation-pack-2026-11-01 `
  --output reports/real-human-gt-v1
```

没有审核标签时命令拒绝导出。导出的原图、原LabelMe和全部GT文件内容哈希都由
评估入口核对，内容变化需重新审核和导出。

## 同提示多树推理/评估

人工提示和标签准备好后，用新输出目录运行：

```powershell
.worker-envs/sam2-shared/Scripts/python.exe scripts/evaluate_real_multitree.py `
  --manifest reports/real-human-gt-v1/manifest.json `
  --checkpoint reports/baseline-freeze-2026-11-01/snapshot/reports/fig500-long-5h-v2-2026-10-31/best.pth `
  --output reports/real-human-evaluation-v1 --device cuda
```

也支持 `--images <照片1> <照片2>` 自动检测，但候选未经审核，且没有GT时只输出
诊断。每次记录固定基座revision、权重/图像/manifest哈希、阈值和实际依赖版本。
评估包含每树IoU、Boundary F1、合并/拆分诊断、一对一匹配召回、归属表现和失败。
没有独立重叠区标签时，不伪造重叠区归属准确率。

## 训练边界

新Fig数据说明见 `docs/fig-data-v3.md`。当前只生成6张接口smoke，完整500场景
仅有冻结计划；不要把它写成完成的数据集。已有5小时权重见过全部29个树资产，
不能用于宣称新19/5/5划分下的未见资产泛化。

两条Fig训练脚本默认要求验证过的资产隔离划分；遗留图像随机划分需显式
`--allow-legacy-image-split`，不支持独立测试结论。新划分默认从原版SAM2初始化；
缺少兼容划分历史的微调权重需显式 `--allow-unverified-initialization`，结果仍不
支持未见资产结论。协议锁定RGB/mask/meta内容、划分、基座revision与初始权重哈希。

树干可见率缺标签的通道不再监督。物体原点深度rank和按rank合并的旧遮挡物目标
也默认不监督；`--supervise-origin-rank` / `--supervise-legacy-occluder`仅为显式研究
开关，不把它们称为真实像素遮挡真值。可见度方差仍未校准，不对外提供置信结论。

本轮训练仅为全新6图划分上的接口检查：先从原版SAM2初始化训练1步，再以该临时
权重做保存1步、恢复后再1步的检查，共3步。目录为
`reports/fig-v3-training-interface-smoke-2026-11-01/` 和
`reports/fig-v3-resume-interface-smoke-2026-11-01/`。未启用上述两种辅助监督，未替换
原基线权重；不构成性能实验。GPU RNG恢复和挖难例后的状态保存均实际走通。

## 本地测试

```powershell
.venv/Scripts/python.exe -m pytest -q
.venv/Scripts/python.exe -m ruff check src tests
.venv/Scripts/python.exe -m mypy src
$env:CUDA_VISIBLE_DEVICES=''
.worker-envs/sam2-shared/Scripts/python.exe -m pytest -q `
  tests/test_sam2_occlusion_decoder.py tests/test_encoder_adapters.py `
  tests/test_curve_consistency.py tests/test_synthtree_instances.py `
  tests/test_occlusion_metrics.py tests/test_research_protocol.py
```

本轮新增CPU模型CI配置；远程CI尚未触发。默认pytest仅收集tests，核心环境不安装
torch时保留数值指标测试，并只跳过需要torch的部分。

最终本地检查：核心271 passed / 10 skipped；模型及协议指定测试68 passed。
Ruff（src/tests及本轮模型/脚本）通过；mypy检查112个源码文件通过。模型测试禁用
CUDA；仅第三方SWIG弃用警告。worker未安装核心包时可显式设置
`$env:PYTHONPATH='D:\TreeWeaver\src'` 后运行包含核心模块的检查。
