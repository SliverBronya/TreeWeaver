# Semantic 3-D fusion and metric measurement

## Part fusion

`fuse-parts` projects trunk, crown, and shared ground masks into the dense point
cloud. Reliability-weighted votes must exceed both an absolute score and a
trunk-vs-crown margin. Conflicting points remain ambiguous and are excluded from
geometry. Points already assigned to any tree track are excluded from ground.
For every accepted trunk, crown, and ground point, the bundle also stores a
reliability value derived from vote strength and class margin. TreeFactor uses
these point-level weights; the sequential baseline deliberately does not, so
their effect can be isolated in ablation experiments.

```powershell
treeweaver fuse-parts capture.json text-model fused.ply observations.json tracks-run semantics-run
```

## Measurement

COLMAP coordinates have arbitrary scale and orientation. Measurement requires
an explicit scale. By default the local ground-plane normal is oriented toward
the fused tree points, so no global coordinate-axis assumption is made:

```powershell
treeweaver measure-tracks fused.ply semantics-run measurements.json \
  --metres-per-unit 0.0231 \
  --scale-sd 0.0004
```

Scale standard deviation is propagated into every parameter standard deviation.
The output records the scale contribution separately. Ground points are chosen
locally around each trunk, and failure of one tree is recorded without dropping
the remaining trees.

When a verified visual-inertial alignment is available, `--up x y z` can orient
the ground normal explicitly. It is checked through the same geometry path.
TreeWeaver never assumes reconstruction Z is vertical merely because no IMU is
available.

## Joint TreeFactor alternative

For the project-owned joint estimator, provide reconstructed metric-anchor
endpoints instead of a manually entered scale:

```powershell
treeweaver optimize-factor-tracks fused.ply semantics-run anchors.json factor-results.json
```

This jointly refines scale, root, trunk axis, breast-height radius, taper, and
height for every tree. It is the experimental path for ablation against the
sequential `measure-tracks` baseline; the baseline remains available and must
not be removed from evaluation.
