# Research and development plan

## Scientific hypothesis

Target-conditioned topology, ambiguity-preserving occlusion reasoning, and
parameter-specific visibility gates will lower complex-scene height/DBH error
and false-confident output rates from one RGB image or unordered RGB images.

## Milestones

### M0 — clean foundation (current)

- Repository hygiene, contracts, pure core, tests, and reproducibility rules.
- No claim of accuracy and no reuse of unverified legacy formulas.

### M1 — user-input geometry baselines

- One RGB plus colocated scale reference as the minimum path.
- Unordered RGB plus automatic feature matching/SfM as the stronger path.
- Per-image camera intrinsics from metadata/calibration; never global constants.
- Explicit scale anchors and manual per-tree masks for the geometry ablation.
- Height and DBH from world-coordinate geometry with propagated uncertainty.
- Deliverable: complex-scene trees photographed with at least 3 phone models,
  with independent height/DBH truth and explicit failure-mode labels.

**Gate:** the geometry-only baseline must run end-to-end before adding learned
segmentation. Otherwise geometry and recognition errors cannot be separated.

### M2 — complex scenes (primary contribution)

- Target-conditioned instance/part evidence in each independent image.
- Persistent tree IDs across views.
- Tree-part labels: trunk, crown, root contact, ground, occluder.
- Explicit visible/occluded/shared/unobserved states.
- Root/topology-constrained multi-tree association and parameter-specific
  refusal rather than forced mask completion.

### M3 — TreeFactor v1

- Joint variables: camera corrections, global scale, ground plane, root point,
  trunk axis/taper, crown envelope, height and DBH.
- Factors: reprojection, depth, root-ground contact, trunk continuity, smooth
  taper, multi-view cross-section agreement, and sensor evidence.
- Compare sequential pipeline vs each added factor in an ablation study.

### M4 — TreeReliabilityNet

- Train reliability from residual/error labels, not merely segmentation labels.
- Inputs: RGB/depth edges, temporal consistency, model disagreement, SfM
  reprojection residual, view angle, occlusion, sensor confidence.
- Evaluate uncertainty calibration using NLL, ECE, interval coverage, and risk-
  coverage curves in addition to MAE/RMSE.

### M5 — active capture and extended parameters

- Select next view by expected reduction in height/DBH/crown covariance.
- Add crown volume, species evidence, taper-derived stem volume, biomass only
  when species/site equations and their provenance are known.

## Publication-grade evaluation

- Tree-level train/validation/test split; no frames of one tree cross splits.
- External test site and unseen phone models.
- Stratify by occlusion, illumination, distance, tree form, and device class.
- Baselines: legacy ARCore pipeline, unordered-image SfM baseline, best
  single-view depth,
  unweighted fusion, and fixed capture path.
- Report failure rate and selective accuracy, not only successful samples.
- Freeze protocol and test set before final model tuning.

Every formal baseline is invoked through `treeweaver run-baseline`. Its adapter
must emit one row per frozen sample and parameter, including `estimate: null`
for failures. The runner rejects omitted attempts or changed tree/split
identities, records the exact command/version/protocol checksum and logs, then
computes the same failure-aware metrics. This prevents the legacy or proposed
method from gaining an advantage through different filtering.

## Initial paper boundary

The first paper should focus on height and DBH, uncertainty, and active capture.
Species and biomass are a later paper unless a sufficiently diverse, expertly
verified dataset is available. Broad feature count is not a substitute for a
clear causal research contribution.
