# ConvexMask isolated pilot

The upstream checkout is retained unmodified in `data/external/convexmask-source`.
Run this pilot in a separate process using the existing CUDA worker Python plus
the isolated `convexmask-extra` package overlay. Never import it into the main
project process: upstream relies on a process-wide CUDA tensor default.

Overlay dependencies, installed without changing the worker's existing packages:
`pycocotools==2.0.11`, `albumentations==1.3.1`, `qudida==0.0.4`.
Other scientific and CUDA packages are inherited from the existing worker runtime.

## Engineering smoke test

```powershell
& 'D:\TreeWeaver\.worker-envs\sam2-shared\Scripts\python.exe' `
  D:\TreeWeaver\scripts\pilot_convexmask.py `
  --source D:\TreeWeaver\data\external\convexmask-source `
  --extra-packages D:\TreeWeaver\.worker-envs\convexmask-extra `
  --images D:\SAM3DepthPro\20260411\7001.jpg D:\SAM3DepthPro\20260411\7002.jpg D:\SAM3DepthPro\20260411\10001.jpg `
  --output D:\TreeWeaver\reports\convexmask-pilot-2026-10-04\smoke `
  --smoke
```

This mode constructs a randomly initialized model, suppresses random detections,
and exercises preprocessing and the model forward pass on the RGB samples. A
separate deterministic geometric fixture exercises polygon NMS and non-empty
mask postprocessing: three candidates, including an identical pair, must produce
two masks. Neither result is tree segmentation quality evidence. No tree masks
or original-image overlays are exported in smoke mode.

## Genuine effect test

Replace `--smoke` with `--checkpoint <actual-trained-checkpoint.pth>`, choose the
matching `--config`, and use a separate output directory. No missing-checkpoint
fallback is permitted. State dictionaries are loaded strictly with
`weights_only=True`; mismatched heads/configurations fail instead of being silently
skipped by the upstream loader. Both raw state dictionaries and `model` or
`state_dict` checkpoint containers are supported. Run only trusted author weights.

The pilot exports per-instance binary masks, a 40%-color RGB-background overlay,
scores, boxes, runtime, memory and a checkpoint SHA-256. It accepts RGB images only.
Metric dimensions and accuracy are not computed here. Numerical accuracy requires
inspected ground-truth instance masks; original-image overlays alone establish
only visual quality.

## Remaining reproducibility blocker

No trained ConvexMask checkpoint was found in the official repository, its full
history, release assets, branch, issue comments, or the checked public model hubs.
This is a search result, not proof that the authors have no checkpoint. An author
checkpoint with matching configuration, or a separately trained reproduction,
is required for a defensible real-image effect test.

The author's issue response specifies the entire-tree SynthTree43k annotations:
`train_RGB_entire_tree.json`, `val_RGB_entire_tree.json`, and
`test_RGB_entire_tree.json`. Use these rather than substituting trunk-only labels.
Source: https://github.com/rcondat/convexmask/issues/1#issuecomment-2285098959

No large dataset was downloaded, no training was represented as completed, and
no message was sent to an author in this pilot.
