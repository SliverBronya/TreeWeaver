# SPREAD ConvexMask 有界训练试点（2026-10-13）

## 结论（先说要点）

- 在 SPREAD 三个合成场景上完成了一次**有界的 ConvexMask 训练试点**：birch_forest + broadleaf_forest 训练、city_park **整场景留出**，seed 42，512×512，72 条射线，ImageNet ResNet50 骨干，AdamW 1e-4，仅监督 Tree 实例。
- 直接按"全部 Tree 实例"训练时，mask 分支学不出来（held-out oracle IoU ≈ 0）。根因是**数据特性与方法假设冲突**：SPREAD 这三个场景里绝大多数树是稀疏落叶树干/枝丫，凸包面积约为可见像素的 20 倍，而 ConvexMask 是在一个凸多边形内部预测平滑实心 mask，监督区域被背景淹没。
- 加入"紧凑树冠"过滤（可见像素 / 凸包面积 ≥ 0.5 且面积 ≥ 500 px@512）后，**训练集 oracle mask IoU 达到 0.73**；整场景留出的 city_park 上 **oracle mask IoU 均值 0.109，呈明显双峰**（部分树 0.59–0.94，多数树仍接近 0）。
- 这是一个**管线可行性 + 适用域诊断**的结果：证明方法在 SPREAD 的紧凑树冠上可学习、可跨场景部分迁移，同时明确了它不适用于稀疏树干/枝丫形态。它**不是**检测器精度、不是真实林分精度、不是任何测量精度，也不代表复现原论文。

## 数据与出处

- 数据来源：SPREAD 合成渲染数据集（非真实拍摄）。三个 7z 归档均通过 py7zr CRC 完整性校验后解压：
  - birch_forest：22,432 条目，约 5.23 GB，3,736 帧
  - broadleaf_forest：19,890 条目，约 4.95 GB，3,314 帧
  - city_park：20,148 条目，约 4.85 GB，3,357 帧
- 每帧：`rgb/`（960×540 RGBA PNG）+ `instance_segmentation/`（480×270 调色板编码 PNG，附同名 `.txt` 映射 `<TreeName> <palette_index>`）。训练时 RGB 与实例标签独立 resize 到 512（仅校验宽高比一致，不强行对齐像素分辨率）。
- 实例调色板为通用 256 色，三场景全部命中；白/黑为背景，绿色大块为地形植被（不在映射中，正确忽略）；`.txt` 中列出但画面内不出现的树按 0 像素跳过。调色板转存于 `data/external/spread/color_palette.json`（只读引用并交叉验证）。
- `obj_info_final.xlsx` 中的 DBH/Height/Crown_Diameter 仿真真值**本次完全未使用**。
- clean-room：运行时未 import `D:\SAM3DepthPro` 的任何模块（仅只读对照格式）。

## 关键发现：稀疏树干与凸多边形假设的失配

ConvexMask 在"凸多边形指示域"内部监督 mask，域外不监督；它表达的是凸多边形内的一块平滑 blob。

对 SPREAD 实例直接测量（512 分辨率下）：

| 指标 | birch | broadleaf | city_park |
|---|---|---|---|
| 实例栅格面积中位（px） | 60 | 91 | 30 |
| 栅格面积 / 凸包面积（density）中位 | 0.03 | 0.04 | 0.16 |
| density < 0.15（稀疏）占比 | 84% | 79% | 48% |
| density > 0.5（紧凑）占比 | 5.6% | 5.5% | 14.5% |

典型桦树帧：最大树栅格仅 7,302 px（2.8% 画面），其凸包却有 55,668 px（21% 画面，约 7.6 倍）——因为这是雨/冬季落叶树，可见像素是细树干加枝丫，凸包覆盖大片天空。于是 mask BCE 裁剪区内 GT=0 占约 95%、GT=1 仅约 5%，正样本梯度被稀释，正样本 logit 在 GT=1 像素上始终卡在 sigmoid≈0.50（GT=0 像素被正确压到 0.018）。

诊断证据：`reports/nightly-spread-2026-10-13/logs/diag-mask.png`（RGB｜实例调色板｜红=稀疏 mask、黄=巨大凸包）；诊断脚本 `scripts/debug_spread_{density,mloss,posmask,targets,poly,eval}.py`。

我们**没有**把凸包填充实心作为 mask 目标（不发明 amodal/遮挡轮廓），而是选择不硬闯：用可见像素/凸包面积的紧凑度过滤，把试点限定在方法假设成立的紧凑树冠上。

## 有界适配与实验序列

给 `scripts/train_convexmask_spread.py` 增加 `--min-density`（可见像素/凸包面积）、`--min-area`（@512 px）两个过滤参数，并在 `run.json` 中记录 `train_oracle_mask_iou_mean` 与过滤口径。

| 实验 | 过滤 | 训练规模 | 步数 | train oracle IoU | held-out oracle IoU |
|---|---|---|---|---|---|
| smoke | 无 | 240 帧 | 10 | —（管线通过） | — |
| pilot1 | 无 | 240 帧/5491 实例 | 400 | — | 0.00 |
| pilot2 | 无 | 48 帧 | 400 | — | 0.00 |
| debug3（单帧过拟合） | 无 | 1 帧/24 实例 | 300 | 总 loss→0.20 但 mask IoU 0.018 | — |
| pilot1-dense | density>0.3 | 160 帧/332 实例 | 1000 | 0.08 | 0.014 |
| debug9（小过拟合） | density>0.5, area>800 | 6 帧/6 实例 | 800 | **0.86** | 0.079 |
| **pilot3-dense（正式试点）** | **density>0.5, area>500** | **37 帧/39 实例** | **4000** | **0.73** | **0.109** |

density>0.3 的孔洞叶冠（内部仍有 70% 空洞）单帧过拟合 IoU 天花板约 0.33，恰等于"预测近似实心凸包"时的密度上界——平滑 mask 无法表达带孔洞的叶冠；density>0.5 的紧凑树冠则可达到高 IoU。

## 正式试点结果（pilot3-dense）

- 配置：birch+broadleaf 训练，city_park 整场景留出；37 训练帧/39 个紧凑实例，26 留出帧/50 个紧凑实例；4000 步（约 108 个 epoch）；峰值显存 1.85 GB；单步约 0.067 s。
- 训练集 oracle mask IoU：**0.729**（对比本地 LabelMe 实心标签试点 pilot3 的 0.79，二者口径一致）。
- 留出 city_park oracle mask IoU：**均值 0.109，中位 0.005**，50 个实例分布：
  - IoU ≥ 0.7：3 个（6%）
  - IoU ≥ 0.5：5 个（10%）
  - IoU ≥ 0.3：7 个（14%）
  - IoU ≥ 0.1：10 个（20%）
  - 26 个留出帧中有 5 帧至少出现 1 个 IoU ≥ 0.5 的 mask。
- 评估方式：每帧取置信度最高的前 32 个候选，由 oracle 用真值挑出 IoU 最高的一个。这是**oracle-selected 诊断**，用于判断 mask 分支是否在学，**不是**自动检测结果（自动检测需要先选对候选，不受 oracle 帮助）。
- 双峰现象解读：高分样本多为近距离实心树干或紧凑树冠（例如 0.94/0.88/0.78/0.68/0.59）；低分样本多为训练集（森林/落叶）中少见、留出场景（城市公园）独有的形态，以及小而多目标、遮挡严重的帧。训练实例仅 39 个、森林→城市域差异明显，是泛化弱的主要原因；这是诚实的负向信息。

## 口径与禁用声明（重要）

- SPREAD 是**合成渲染数据**，不是真实林分影像；本试点不代表真实场景的分割精度。
- 本试点**不涉及、也不主张**树高、胸径、冠幅、材积等任何测量精度；`obj_info_final.xlsx` 中的仿真真值未参与训练或评估。
- 报告中的 IoU 均为 **oracle-selected raw-mask diagnostic, NOT detector accuracy**；它不是实例分割 AP、不是召回/精确率、不是端到端检测能力。
- 本试点**不构成场景泛化结论**：留出集上双峰、样本量小、训练/留出场景不同。
- 本试点是**有界可行性实验**，不是 ConvexMask 原论文的训练规模/数据/结果复现，不代表复现原论文。
- 紧凑树冠过滤是对本数据特性的**有界适配**，并非对"稀疏树不可分割"的普遍结论；也没有通过填充凸包来制造 amodal 标签。

## 产物

- 正式试点：`reports/convexmask-spread-2026-10-13-pilot3-dense/`（`manifest.json`、`history.json`、`run.json`、`pilot_checkpoint.pth` 约 122 MB、26 张 city_park oracle overlay）。
- 对照实验：`reports/convexmask-spread-2026-10-13-{smoke,pilot1,pilot2,pilot1-dense,pilot2-dense,debug1..9}/`（均未覆盖历史实验）。
- 诊断图：`reports/nightly-spread-2026-10-13/logs/diag-mask.png`；全部训练日志在同目录 `logs/`。
- 训练脚本：`scripts/train_convexmask_spread.py`；值守脚本：`scripts/nightly_spread_watch.py`。
- 审计：`reports/nightly-spread-2026-10-13/audit.json`；过程记录：`reports/nightly-spread-2026-10-13/state.json`。

## 后续建议（未执行）

1. 若要覆盖稀疏树干/枝丫形态，需要能表达细长/多孔结构的表示（如射线/骨架/非凸掩膜），而非"凸多边形内平滑 blob"。
2. 紧凑树冠方向若要继续提升，需增加紧凑训练样本（当前训练仅 39 个实例），或重新设计训练/留出场景划分以减小域差异。
3. 任何测量用途都必须先建立可见像素→目标包络的标签口径，并在真实影像上验证，不能沿用合成指标。
