# Input modes and what can actually be measured

## User-visible input

The minimum input is one ordinary RGB photograph containing the target tree and
a fixed-length coded reference. A user may instead supply several ordinary
photographs in any order. The user never supplies camera poses, baselines,
depth maps, point clouds, gravity vectors, fork heights, or occlusion labels.

For unordered photographs, feature matching and structure-from-motion recover
the relative cameras internally. Metric scale comes from the visible reference.
ARCore or metric depth can improve the evidence when present but is not required.

## Single RGB limits

One projection can conditionally constrain visible tree height, trunk diameter,
image-plane crown width, and crown height when the reference placement and
critical surfaces are valid. It cannot uniquely observe front-to-back crown
depth, hidden crown boundaries, full crown volume, or stem taper. A learned
depth or shape prior may be recorded as a prior, but cannot turn these quantities
into direct measurements. Such outputs must be rejected or labelled separately
as allometric/prior-based estimates.

In a complex scene, a single view is not forced into a complete tree mask.
Visible target-tree pixels, pixels plausibly belonging to an occluder, shared
boundaries, and unobserved structure remain different evidence states. Height
or DBH is released only if its own critical region is visible; failure of one
parameter does not automatically reject every other parameter.

## Unordered RGB advantages

Multiple photographs need no known positional relationship. Once automatic
pose recovery passes its quality gate, they can constrain 3-D tree identity,
occlusion, trunk sections, crown depth, and taper. Internal modules may consume
cameras, point clouds, or expected surfaces, but these are derived artifacts,
not additional user inputs.

## Complex scenes are the main task

The system is evaluated first on interacting failure modes: touching stems,
overlapping crowns, foreground occluders, understory clutter, root or apex
truncation, lean, forks, buttress, wind, harsh light, and reconstruction holes.
The core comparison is not just one segmenter versus another. It is whether
root/target-conditioned identity, ambiguity preservation, explicit occlusion,
and parameter-specific visibility gates reduce error and false confident
answers under those conditions.
