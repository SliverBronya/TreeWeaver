# 夜间 SPREAD 自动化值班手册（2026-10-13 凌晨建立）

本手册由定时任务触发的 Agent 执行。目标：**检测到 `D:\TreeWeaver\SPREAD` 三个压缩包完整下载后，自动校验、解压、审计，并在 SPREAD 上跑一个有界的 ConvexMask 训练试点**。整个过程必须遵守项目的证据纪律：只产出"可复现的试点"，禁止宣称测量精度、禁止发明真值、禁止下载新数据、禁止从 `D:\SAM3DepthPro` 运行时导入模块。

## 1. 固定路径

- 监控目录：`D:\TreeWeaver\SPREAD`，期望三个文件：`birch_forest.7z(.part)`、`broadleaf_forest.7z(.part)`、`city_park.7z(.part)`。
- 值守脚本：`D:\TreeWeaver\scripts\nightly_spread_watch.py`
- 值守 Python：`D:\TreeWeaver\.worker-envs\sam2-shared\Scripts\python.exe`（含 py7zr 1.1.0、cv2、torch）
- 状态与日志：`D:\TreeWeaver\reports\nightly-spread-2026-10-13\`
  - `state.json`（状态机）、`audit.json`（解压后的结构审计）、`logs\*.log`（各阶段日志）
- 解压目标：`D:\TreeWeaver\data\external\spread\<scene>\`

## 2. 每次触发先跑状态机

```powershell
cd D:\TreeWeaver
& ".\.worker-envs\sam2-shared\Scripts\python.exe" scripts\nightly_spread_watch.py
```

输出为一行 JSON，按下表处理：

| 状态 | 含义 | 动作 |
|---|---|---|
| `WAITING` | 未下载完或文件还在增长 | 什么都不做，结束本轮（保持安静，不要重复启动） |
| `VERIFYING` / `EXTRACTING` / `AUDITING` | 分离进程在跑 | 看 `logs\` 和 `state.json`，正常则结束本轮；卡住超过 2 小时按失败处理 |
| `CORRUPT` | 已稳定的 `.7z` 完整性校验失败 | **停止并向用户报告**，写 `reports\nightly-spread-2026-10-13\CORRUPT.md`，不要重试下载、不要解压 |
| `ERROR` | 阶段异常 | 读对应日志；路径/权限类问题可修复后重跑值守脚本；同一错误失败两次后写 `FAILED.md` 并停止 |
| `READY` | 三个场景均已解压并完成审计 | 进入第 3 节训练 |
| `TRAINING` | 训练已启动 | 监控训练日志与进程，见第 4 节 |
| `DONE` | 全部完成 | 禁用本定时任务（见第 5 节） |

值守脚本自身完成"稳定 15 分钟判定 → py7zr 完整性测试 → 解压 → 结构审计"。`.part` 文件仍在增长时不会被误判；完整性测试失败的 `.part` 会回到 `WAITING`。**不要绕过这些门禁。**

## 3. READY 后：SPREAD ConvexMask 训练试点

### 3.1 先核实数据

1. 读 `reports\nightly-spread-2026-10-13\audit.json`，确认每个场景 `rgb_image_count > 0` 且 `instance_png_count > 0`。
2. 打开 1-2 个 `sample_mapping_txt`：SPREAD 映射文件每行是 `<TreeName> <palette_index>`（如 `Tree732 67`）；实例 PNG 按颜色调色板区分实例（可能是索引 PNG，也可能是 RGB 调色板 PNG，以实际 `sample_instance_png` 为准）。同目录或上级有 `color_palette.xlsx` 时用它解析 index→RGB；不确定就用 PIL/cv2 直接读取 PNG 的调色板并做两种编码的兼容解析。
3. 只把 `Tree` 开头的对象当树实例；车辆、行人、灯杆等非树对象一律不生成标签。

### 3.2 写训练脚本

新建 `scripts\train_convexmask_spread.py`，**以 `scripts\train_convexmask_local.py` 为模板**，差异只允许：

- 数据来源改为解压后的 SPREAD；记录由 RGB + 实例 PNG + 映射 txt 现场构造：
  - 每棵树的实例掩码 → `cv2.findContours`（外轮廓）→ `cv2.convexHull`，与本地试点保持同一凸包口径；
  - 每帧可含多个树实例（沿用 local 脚本已支持的多 box/mask/hull 列表）；
  - 掩码有效像素少于 10 或越界的实例跳过并计数；
  - 正方形 resize 512（`cfg.fixed_size=True`、`cfg.max_size=(512,512)`），与 pilot3 一致。
- **切分按场景隔离**（强泄漏防护）：`birch_forest` + `broadleaf_forest` 训练，`city_park` 整体留出做 held-out；记录里写明 tree identity 是 `(scene, TreeName)`。固定 seed 42。
- 有界试点：训练场景最多抽 240 帧、held-out 最多 30 帧（确定性抽样，帧名清单写进 manifest）；400 步；AdamW 1e-4；batch 1；冻结 BN；ImageNet ResNet50 骨干 `C:\Users\Mendel\.cache\torch\hub\checkpoints\resnet50-0676ba61.pth`；72 rays；无作者权重。
- 输出契约与 local 试点一致：`manifest.json`（含出处、帧清单、tree ID、局限性）、`history.json`、`pilot_checkpoint.pth`、`run.json`、held-out `*_oracle_overlay.png`；评估明确标注为"oracle-selected diagnostic, NOT detector accuracy"。
- 输出目录必须不存在，禁止覆盖：
  - smoke：`reports\convexmask-spread-2026-10-13-smoke`（10 步，先验证管线）
  - 正式：`reports\convexmask-spread-2026-10-13-pilot1`（400 步）

### 3.3 运行（分离进程，跨轮次监控）

```powershell
cd D:\TreeWeaver
& ".\.worker-envs\sam2-shared\Scripts\python.exe" scripts\train_convexmask_spread.py `
  --data-root data\external\spread `
  --source data\external\convexmask-source `
  --extra-packages .worker-envs\convexmask-extra `
  --backbone "$env:USERPROFILE\.cache\torch\hub\checkpoints\resnet50-0676ba61.pth" `
  --output reports\convexmask-spread-2026-10-13-smoke --steps 10 --size 512
```

用 Start-Process 分离启动并把 stdout/stderr 写到 `reports\nightly-spread-2026-10-13\logs\train-smoke.log`；启动后执行：

```powershell
& ".\.worker-envs\sam2-shared\Scripts\python.exe" scripts\nightly_spread_watch.py --mark training --message "smoke started"
```

smoke 成功后以同样方式启动 400 步正式运行（日志 `train-pilot1.log`）。每轮触发只检查日志与进程，不要重复启动。

## 4. 失败与完成

- CUDA OOM：先把每帧实例上限降到 12、训练帧降到 120，重跑（新目录名，不覆盖）；仍失败则停止并写 `FAILED.md`。
- 脚本缺陷：修复后重跑同一 smoke 目录前必须先删除该 smoke 目录；正式 pilot 目录一旦写入不得覆盖，换 `pilot2`。
- 训练结束：核对 `run.json` 与 checkpoint 存在；写 `docs\spread-training-pilot.md`（参照 `docs\convexmask-pilot.md` 与 `docs\stem-anchored-model-research.md` 的口径：合成数据、非真实场景精度、不构成测量精度声明、无场景泛化结论、不代表复现原论文）。
- 全部完成后：

```powershell
& ".\.worker-envs\sam2-shared\Scripts\python.exe" scripts\nightly_spread_watch.py --mark done --message "spread pilot1 complete"
```

然后用 `list_cron_jobs` 找到标题为「夜间 SPREAD 下载值守与训练」的任务，用 `update_cron_job` 将其 `enable` 置为 false。

## 5. 硬约束

- 不修改、不删除、不移动 `SPREAD\` 下的下载文件；不把部分文件当完整归档。
- 不运行时 import `D:\SAM3DepthPro` 任何模块（clean-room 规则）；那里的 SPREAD 旧副本只可只读对照格式。
- 不下载任何新数据、不发邮件/消息、不做 git commit（改动留给用户审阅）。
- 不把 SPREAD（合成渲染数据）的指标表述为真实林分精度；树高/胸径/冠幅/材积在本试点中完全不涉及。
- 不发明 amodal/遮挡后轮廓：实例 PNG 给什么就监督什么，遮挡区域保持未知。
- 任何与本手册假设不符的实际目录结构（如归档密码、层级变化、缺映射文件），先记录到审计报告，再按最小改动适配；无法确定时停止并留给用户。
