# ConvexMask 原作者数据接入记录（2026-10-14）

主数据切换为 SynthTree43k 的整树标注；SPREAD 不替代原论文基准。
来源确认：https://github.com/rcondat/convexmask/issues/1#issuecomment-2285098959

## 已实际完成

- 原始验证标注 `val_RGB_entire_tree.json` 完整下载并成功解析：1000 图片、3353 实例，17,509,240 字节。
- SHA256：9f5d92f8c9f3e071313da39822ea2ebfd6678b542329bd92bd75dd06a3500f52。
- 类别为 `id=0,name=tree`。接入器显式设置标签映射并使用单元素类别元组。
- 用作者的 `GeneratePolygons` 实际处理三张图片共十个实例：掩膜、凸多边形有效，掩膜未被凸包替代。
- 四项数据契约测试通过：零起始类别、缺失图片、重复文件名、缺失掩膜。

原代码在 `utils/augmentations.py` 在线从掩膜提取凸包，不要求另造隐藏轮廓或手动重标多边形。配置文件中的 `_convex.json` 文件名不是证明另有一套必须下载的真值。

## 未完成及网络限制

训练标注总长 667,097,261 字节，目前部分文件 27,200,768 字节；测试标注总长 38,739,998 字节，目前部分文件 34,582,272 字节。`.part` 不能当成正式标注。下载端出现超时和 TLS 连接失败，已有文件保留用于断点继续。

约 90.8 GB 原始图片包只计划范围读取少量训练/验证 RGB，不擅自整包下载。此次 RGB 请求失败，不能宣称图片读取链路或模型训练已通过。以前保存的掩膜示例不是对应 RGB 的替代品。

## 可继续执行的入口

- `scripts/fetch_synthtree_author_labels.py`：获取或续传作者整树标签，失败保留部分文件及状态。
- `scripts/validate_synthtree_author_splits.py`：完整标签到齐后检查文件名划分；不把文件名无重叠冒充树木身份无重叠。
- `scripts/prepare_synthtree_author_pilot.py`：取原训练划分八张、验证划分两张 RGB；`--validation-only` 仅作读取检查，不能用验证集训练。
- `scripts/check_convexmask_author_data.py`：通过原始 COCO 读取器和掩膜生成流程检查，训练模式仅使用原训练子集；`--data-only` 只读验证子集。
- `scripts/inspect_author_label_geometry.py`：已运行的原始标注与凸多边形检查。

训练入口暂为小规模、降分辨率诊断，列明 AdamW、无随机增强等偏差，不宣称完整论文复现。等 RGB 与训练标签齐备再跑训练，不拿 SPREAD 或验证图片充当训练数据。
