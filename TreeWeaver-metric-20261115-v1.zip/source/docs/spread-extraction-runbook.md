# SPREAD 剩余场景解压 runbook

状态（2026-10-13）：`birch_forest` / `broadleaf_forest` / `city_park` 三个场景已完整解压并校验，
`rgb` / `instance_segmentation` / `depth_pfm` 三者数量一致（3,736 / 3,314 / 3,357 帧）。

剩余的 6 个场景**需要在你自己的终端里手动跑一次**，原因见下。

## 为什么不能让 Agent 代跑

在本机环境里用后台方式启动解压，进程会在 **45–50 分钟**后被回收，三次实测都是这样：

| 开始 | 最后写入 | 存活 | 净进度 |
|---|---|---|---|
| 11:06 | 11:51 | 45 min | 部分 |
| 12:56 | ~13:20 | 24 min | 0（分批 targets 方案，见下） |
| 13:03 | 13:53 | 50 min | 0（原地重写） |

而 **SPREAD 的 `.7z` 是固实压缩**，py7zr 无法跳读：即使只想补解缺失的成员，也必须把数据流
从头部解压到目标位置。所以单次遍历必须连续跑满约 **55–60 分钟**才可能完成一个场景，
而可用窗口只有 45–50 分钟 —— 每次重试都在重做同样的前缀，**永远到不了终点**。

在你自己打开的终端里运行则没有这个限制。

## 手动执行

用 worker 环境的 Python（含 py7zr 1.1.0）：

```powershell
cd D:\TreeWeaver
& ".\.worker-envs\sam2-shared\Scripts\python.exe" `
  scripts\extract_spread_scenes.py --workers 3
```

- 3 个场景并行，**跑满约 1 小时**，中途不要关闭窗口。
- 脚本会跳过已完成的场景；已解压的成员也不会重复写入最终目录。
- 第一波（`!meadow_forest` / `downtown_europe` / `plantation`）结束后会自动接着做
  `rainforest` / `redwood_forest` / `suburb_us`，所以总共约 2 小时。
- 想只推进第一波就加 `--scenes !meadow_forest downtown_europe plantation`。

进度查看（另开一个窗口）：

```powershell
Get-Content D:\TreeWeaver\reports\spread-extract-2026-10-13\logs\!meadow_forest.log -Tail 5
```

## 约束与安全设计（脚本已内置）

- **原子落盘**：先解到 `data/external/spread/.inprogress/<scene>`，全部成员齐了才 `os.replace`
  到最终目录。所以失败或中断的场景**不会被误判成已完成**。
- **不覆盖**：最终目录已存在就跳过。
- **空间下限**：每个场景启动前检查剩余空间，低于 10 GiB 就停止派发新场景。
- **完整性**：py7zr 解压时逐成员校验 CRC，异常即标记 FAILED 并保留 staging 供检查。
- **内存**：每个 worker 占 1–2 GB，本机总内存 15.2 GiB → **3 个 worker 已是上限**，不要加。

## 待解压的 8 个场景（11 个归档全部已下载完整）

| 归档 | 大小 | 状态 |
|---|---|---|
| `!meadow_forest.7z` | 4.01 GiB | staging 中（约 7,800 成员） |
| `downtown_europe.7z` | 3.23 GiB | staging 中（约 7,000 成员） |
| `plantation.7z` | 3.75 GiB | staging 中（约 7,800 成员） |
| `rainforest.7z` | 4.49 GiB | 未开始 |
| `redwood_forest.7z` | 4.08 GiB | 未开始 |
| `suburb_us.7z` | 2.81 GiB | 未开始 |
| `burned_forest.7z` | 3.68 GiB | 未开始（最近才下载完） |
| `downtown_west.7z` | 3.73 GiB | 未开始（最近才下载完） |

已完整解压：`birch_forest`（3,736 帧）、`broadleaf_forest`（3,314 帧）、`city_park`（3,357 帧）。

## 关于 `.inprogress` 里的 6.76 GiB

`data/external/spread/.inprogress/` 下有三个场景的部分解压结果（约 22,566 个文件、6.76 GiB）。
**保留它们不会有坏处**，但也**不会省时间**：因为 `.7z` 是固实压缩，脚本每次都必须从头解压，
已存在的成员会被重写一遍。最终完整性检查通过后，整个目录会被原子移动到正式位置。
如果想省这 6.76 GiB，可以手动删除该目录 —— 但删之前请确认没有解压任务正在运行。

## 这也说明一件事

**额外 6 个场景不是必需品。** 已完整解压的 3 个场景共 **10,407 帧**，
足以支撑遮挡序标签、实例分离与压力集构建。剩余场景只是扩大规模，
可以在方便的时候用上面的命令补，不必阻塞其它工作。
