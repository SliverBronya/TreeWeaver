# Raw capture ingestion

## Clock model

Android sensor timestamps and `recording_monotonic_start_ns` use the same
monotonic time base (`elapsedRealtimeNanos`). A sampled video frame at index
`i` receives timestamp:

```text
recording_monotonic_start_ns + i / video_fps * 1e9
```

The importer rejects missing synchronization metadata and warns when IMU
samples do not overlap the video interval.

## Intrinsics model

Camera2 calibration is expressed in active-array pixel coordinates. CameraX
can center-crop that array to fill the encoded video aspect ratio. The importer
applies the same scale-and-center-crop transform to `fx`, `fy`, `cx`, and `cy`.

When the device does not expose calibrated intrinsics, focal length and sensor
physical size provide a lower-confidence fallback. A focal length without
sensor size is insufficient and is rejected.

This mapping is a baseline assumption that must be checked with calibration
targets on each evaluation phone. Later capture versions should record CameraX
transformation metadata directly when the API exposes it reliably.

## Scale lifecycle

The raw manifest stores the known physical length. The ingested manifest keeps
`reconstructed_length` absent until marker/staff detection or manual annotation
measures that object in the reconstructed coordinate system. Only then may
metric scale be estimated. This prevents circular or fabricated calibration.

## Generated files

```text
data/interim/<session-id>/
  capture.json
  frames/
    frame_000000.jpg
    ...
```

Raw captures remain immutable and outside Git. Re-ingestion into an existing
session directory is rejected rather than silently overwriting research data.

