# Visible-stem anchored model: first implementation

## Implemented, not yet validated on real stem labels

`workers/tree_models/stem_ownership.py` implements a learnable ownership head.
It projects RGB features into embeddings, pools each independently supplied
visible-stem mask into a tree anchor, and compares image pixels with those anchors.
The output includes background and one mutually exclusive ownership channel per
valid stem. Cross-entropy supervision ignores unknown pixels instead of assigning
invented hidden contours or unannotated neighboring trees to background.

This is a research prototype based on feature/prototype pooling and similarity,
not a claim of a new published method or proven innovation. Similarity alone may
fail for same-species crowns; structural constraints and real multi-instance
evaluation remain necessary.

An optional aligned depth branch penalizes relative depth disagreement only when
both the pixel and anchor have usable positive finite depth and reliability.
Missing/invalid depth yields the same RGB-only logits. This is a weak cue, not a
claim that a trunk and all of its branches share one depth plane. Depth reliability
must be externally justified; the head does not infer ARCore accuracy, camera pose,
metric scale, or unknown inter-image registration.

Current tests verify anchor-permutation consistency, invalid-depth RGB fallback,
missing-anchor rejection, and finite learning gradients with unknown pixels ignored.
They are implementation checks, not real-image accuracy evidence.

## Actual initial ConvexMask training

The separate `scripts/train_convexmask_local.py` uses 25 existing LabelMe target
tree polygon annotations and the corresponding 20260411 RGB photographs. A fixed
seed groups photographs by tree number before splitting: 22 training photos and
3 held-out photos, with held-out tree IDs 19, 27, 29. No depth is used here.

The original YOLO YAML in the older project lists the same path for training and
validation. This pilot does not reuse that split. The local labels are target-tree
labels, not exhaustive neighboring-tree or separate visible-stem annotations.
Consequently they cannot establish crowded-scene instance accuracy and cannot
legitimately supervise the new stem head yet.

ConvexMask uses its original mask, polygon, confidence and centerness losses,
a cached ImageNet ResNet50 backbone, and 72 rays. No author-trained ConvexMask
weights are used. Pilot input is square resized (320 or 512 pixels); inference
must use the same square preprocessing and the matching R50 config. The run
manifest, losses and state dictionary are saved. This is not the paper's full
dataset, resolution, optimizer/schedule or training reproduction.

The training script's `oracle_mask_iou` checks whether any of the strongest 32 raw
mask candidates can match a known target; ground truth selects the candidate.
These overlays and scores are explicitly diagnostic, NOT autonomous segmentation
accuracy. Use the separate inference pilot for ordinary confidence-selected
outputs and original-size translucent overlays.

## Next real-data work

Audit target polygon interpretation and annotate visible stems plus exhaustive
neighboring instances on a small subset. Keep unseen tree IDs separate. Compare
RGB baseline, stem-anchor head, and RGB plus independently checked ARCore depth
using the same split. Report instance merge/split failures, stem boundary error,
target IoU and eventually measured parameter errors. No amodal ground truth should
be invented from a single ambiguous RGB photograph.

Multi-view RGB/depth remains in scope, but requires explicit matching/registration
and quality checks; this initial head does not implement it.

## Follow-up: trained weak-proxy experiment

`scripts/train_ownership_pilot.py` now trains the ownership head on frozen
ConvexMask prototype features. It does NOT train an anatomical stem detector:
`lower_mask_proxy` takes a narrow lower region of the automatic predicted mask
as a weak hint. Ground-truth masks supervise target membership but do not create
anchors or choose detections. All22 training photos yielded hints in this pilot.

Three300-step runs use initialization seeds42,7,123 and the same three development
images. No seed/model is selected as a winner; seed42 remains the first fixed
demonstration checkpoint. A comparable no-anchor pixel head is trained with the
same data, steps, optimizer and support constraint. Both heads improve this small
development target-mask comparison relative to the baseline. Their difference
is tiny, so these results do not establish a useful advantage from stem anchoring.
The initial three test images have now been reused during development and must
not be presented as an untouched final publication test.

Artifacts: `reports/ownership-train-2026-10-12-pilot1`,
`reports/ownership-train-2026-10-12-seed7`, and
`reports/ownership-train-2026-10-12-seed123`.

`scripts/predict_ownership_pilot.py` accepts fresh RGB paths without annotations,
produces masks/overlays, and records missing-hint/baseline fallbacks. Multiple RGB
inputs are processed independently; no multi-view fusion or registration is
claimed. Aligned reliable depth remains supported by the head API, but it is not
used or trained in these RGB-only runs.

Actual new-image checks on7001 and7002 reveal merged neighboring trees and
background spill. The added `lower_mask_proxies` diagnostic finds two persistent
narrow lower candidates in each prediction and flags possible merge or fork.
This is NOT proof of two distinct trees and NOT correct instance separation.
The flags are diagnostic output; they have not been wired into the project's
measurement rejection gate. No metric dimensions are produced by this pilot.

Next priority: real multi-instance/visible-stem labels or clearly marked controlled
multi-instance training, a learned automatic anchor predictor, and robust ownership
under similar appearance. Binary outline refinement is insufficient for the main
complex-scene objective. Do not promote this pilot as the finished measurement model.
