# End-to-end research workflow

The scientific target is complex-scene measurement from one RGB photograph or
several unordered RGB photographs. The current one-command runner below is the
implemented multi-image/video compatibility path; it is not the definition of
the required user input. The single-image path and the unordered-image path
share the same masks, target-tree identity, visibility, uncertainty, and
fail-closed reporting contracts.

The normal path is now one fail-closed command. Copy and edit
`configs/full-run.example.json`, then run:

```powershell
treeweaver run-full configs\full-run.local.json
```

It starts from the Android raw-capture manifest and executes ingestion, dense
COLMAP reconstruction, reconstruction quality control, coded-marker scale
registration, external vision evidence, multi-tree association, semantic 3-D
fusion, sequential crown measurement, TreeFactor optimization, optional species
fusion, and final quality-gated reporting. Every accepted stage and artifact
checksum is written to `run-journal.json`. `run-status.json` is `complete` only
when the final report exists. A failed reconstruction or missing metric anchor
halts the run instead of emitting measurements.

The output directory must not already exist. This deliberately makes a run
immutable; use a new run ID and output directory after changing input or model
configuration. The commands below expose the individual stages for debugging
and ablation experiments.

## 1. Prepare metric scale and capture

```powershell
treeweaver generate-marker D:\TreeWeaver\marker-7-200mm.svg `
  --marker-id 7 --edge-length-mm 200
```

Print at 100% scale and verify the outer black edge is 200 mm. Mount it on a
flat, rigid backing; do not bend it around the trunk. In the Android
capture app choose `coded_marker`, enter `0.2` m and marker ID 7. For one
photograph, place it close to the target trunk and in approximately the same
depth plane. For several photographs, keep it visible whenever practical; the
photographs may be supplied in any order and the system recovers their relative
cameras internally.

In a multi-tree scene, the user also taps the target tree near its ground
contact. The reconstructed root anchor is the persistent identity of that tree;
shared crown points are allowed to remain ambiguous. Before a number is shown,
the visibility gate verifies the required surfaces. For example, an incomplete
breast-height circumference triggers a direction-specific side view instead of
an extrapolated DBH.

## 2. Ingest and reconstruct

```powershell
treeweaver ingest-raw D:\captures\session\capture.json D:\TreeWeaver\data\interim
treeweaver reconstruct-colmap `
  D:\TreeWeaver\data\interim\session\capture.json `
  D:\TreeWeaver\data\processed\session\reconstruction --dense
treeweaver register-marker `
  D:\TreeWeaver\data\interim\session\capture.json `
  D:\TreeWeaver\data\processed\session\reconstruction\text-model `
  D:\TreeWeaver\data\processed\session\anchors.json `
  --marker-id 7 --edge-length-m 0.2
treeweaver estimate-scale `
  D:\TreeWeaver\data\processed\session\anchors.json `
  D:\TreeWeaver\data\processed\session\scale.json
```

The sparse quality report must pass. Marker registration also fails closed if
reprojection error is excessive.

## 3. Produce and validate learned evidence

Heavy vision environments are isolated from the scientific core. A worker
configuration is a committed JSON file:

```json
{
  "schema_version": "external-vision-worker-1.0",
  "command": ["python", "path/to/worker.py"],
  "provider_name": "tree-instance-and-parts",
  "model_version": "record-an-exact-checkpoint-id",
  "timeout_seconds": 3600
}
```

Run it with:

```powershell
treeweaver run-vision-worker worker.json capture.json evidence-run
```

The worker must accept the appended `--capture-manifest`, `--output-directory`,
`--provider-name`, and `--model-version` arguments. It writes
`observations.json` plus masks through the canonical provider bundle. TreeWeaver
then validates schema, provenance, duplicate IDs, paths, and readable masks.

## 4. Associate, fuse, and estimate

```powershell
treeweaver associate-instances capture.json text-model fused.ply `
  evidence-run\observations.json tracks-run
treeweaver triangulate-roots capture.json text-model root-clicks.json root-anchors.json
treeweaver separate-roots fused.ply root-anchors.json root-assignment `
  --trunk-probability-npz trunk-evidence.npz `
  --candidate-indices-npz tracks-run\track-points.npz `
  --ground-indices-npz semantics-run\semantic-points.npz
treeweaver refine-semantics-by-roots semantics-run root-assignment root-semantics-run
treeweaver fuse-parts capture.json text-model fused.ply `
  evidence-run\observations.json tracks-run semantics-run
treeweaver measure-tracks fused.ply semantics-run crown-results.json `
  --metres-per-unit <registered-scale> --scale-sd <registered-scale-sd>
treeweaver optimize-factor-tracks fused.ply semantics-run anchors.json factor-results.json
treeweaver fuse-species species-evidence.json species-results.json
```

The sequential measurement remains an ablation baseline and supplies current
crown-envelope measurements. TreeFactor supplies the joint scale/height/DBH/
taper/stem-volume result.

`root-clicks.json` identifies the target tree rather than asking the user to
label every occlusion. With a reconstructed dense cloud, one click can initialize
the front coherent surface near the selected root. Repeated clicks in separated
views remain an optional robust mode; triangulation rejects inconsistent clicks
and weak parallax. These cameras and the dense cloud are internally recovered
artifacts, not user inputs.
`root-anchors.json` uses schema `root-anchors-1.0` and contains one 3-D root
position per selected tree. Gravity-up is estimated from fused ground when it
is not already registered in reconstruction coordinates. The separate
command writes point labels `>0` for a tree, `0` for shared/ambiguous geometry,
and `-1` for disconnected evidence. The command is currently an explicit
research stage and is also activated automatically by `root_clicks_json` in a
full-run configuration.
Candidate indices are mandatory in field experiments so ground and background
points cannot create a false topological bridge between neighboring trees.
The versioned input and output schemas are
`contracts/root-clicks.v1.schema.json` and
`contracts/root-anchors.v1.schema.json`.

## 5. Build only quality-gated reports

```powershell
treeweaver build-report capture.json quality.json factor-results.json final-report.json `
  --crown-results-json crown-results.json `
  --species-results-json species-results.json
```

This is the only output intended for display. It retains failed trees and
reasons, accepts parameters separately, returns unknown species when required,
and requests another view when uncertainty is too high.

## 6. Frozen external evaluation

After tree-disjoint split freezing, map all attempts—including failures—into
`benchmark-predictions-1.0` and run:

```powershell
treeweaver evaluate predictions.json evaluation.json
```

The output contains MAE, RMSE, bias, MAPE, Gaussian NLL, 95% interval coverage,
failure rate, risk-coverage points, and any provided phone/site/condition
strata. The external test remains untouched until every threshold and ablation
is frozen.
