@echo off
REM ============================================================
REM  ConvexMask author-recipe training, keep-alive launcher
REM
REM  Double-click this file (or run it from a terminal) ONCE.
REM  It starts a watchdog that runs the training and automatically
REM  restarts it if it stops, until all 29 epochs are finished.
REM  The training resumes from latest.pth, so a restart costs at
REM  most one checkpoint interval (500 steps, about 7 minutes).
REM
REM  You do NOT need to watch it. Minimise the window if you like,
REM  but leave it open.
REM
REM  To stop early: create an empty file named STOP_REQUESTED in
REM  reports\convexmask-author-2026-10-16\ - the watchdog will then
REM  let the training finish its current checkpoint and exit.
REM ============================================================
setlocal
title ConvexMask author-recipe training (keep-alive watchdog)

set ROOT=D:\TreeWeaver
set PY=%ROOT%\.worker-envs\sam2-shared\Scripts\python.exe
set OUT=%ROOT%\reports\convexmask-author-2026-10-16

set PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

cd /d "%ROOT%"

"%PY%" "%ROOT%\scripts\watch_convexmask_training.py" ^
  --output "%OUT%" ^
  --python "%PY%" ^
  --train-script "%ROOT%\scripts\train_convexmask_synthtree_continuous.py" ^
  --backoff 20 ^
  -- ^
  --data-root "%ROOT%\data\external\synthtree43k" ^
  --source "%ROOT%\data\external\convexmask-source" ^
  --extra-packages "%ROOT%\.worker-envs\convexmask-extra" ^
  --backbone "C:/Users/Mendel/.cache/torch/hub/checkpoints/resnet50-0676ba61.pth" ^
  --output "%OUT%" ^
  --epochs 29 ^
  --recipe author ^
  --loader-threads 4 ^
  --loader-timeout 120 ^
  --checkpoint-every 200 ^
  --eval-size 640,360 ^
  --validate-every 5000 ^
  --full-validate-every 5

echo.
echo ============================================================
echo  Watchdog exited. See the log for the reason:
echo    %OUT%\watchdog.log
echo ============================================================
pause
