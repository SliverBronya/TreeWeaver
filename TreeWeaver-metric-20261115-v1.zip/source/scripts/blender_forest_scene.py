"""Layered forest scene with fig trees, understory, path, rocks and mist."""

from __future__ import annotations

import math
import random
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRI = "autumn_field_puresky_2k.hdr"
OUT = Path(r"D:\TreeWeaver\reports\blender-forest-scene\sample.png")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 64
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.3


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(v * scale for v in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def load_tree(path, height=TARGET_HEIGHT):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [obj for obj in bpy.data.objects if obj not in before]
    meshes = [
        obj
        for obj in new
        if obj.type == "MESH" and obj.name not in {"Cube", "Camera", "Light"}
    ]
    if not meshes:
        raise RuntimeError(f"no meshes in {path}")
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    normalize(tree, height)
    return tree


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def material(name, colour, roughness=0.9):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*colour, 1)
    bsdf.inputs["Roughness"].default_value = roughness
    return mat


def ground():
    bpy.ops.mesh.primitive_plane_add(size=300, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (20, 20, 20)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)


def path():
    return


def rocks(rng):
    mat = material("rock", (0.18, 0.17, 0.15), 0.95)
    for _ in range(18):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=rng.uniform(0.15, 0.65))
        obj = bpy.context.object
        obj.scale.z = rng.uniform(0.35, 0.65)
        obj.location = (rng.uniform(-12, 12), rng.uniform(0, 28), 0)
        obj.rotation_euler = (0, 0, rng.uniform(0, 6.28))
        obj.data.materials.append(mat)


def log(x, y, length, rng):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=0.22, depth=length, location=(x, y, 0.22))
    obj = bpy.context.object
    obj.rotation_euler = (0, math.radians(90), math.radians(rng.uniform(-20, 20)))
    obj.data.materials.append(material("log", (0.20, 0.14, 0.09), 0.95))


def world(rng):
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / HDRI))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 6.28))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.0
    bpy.context.scene.world = w


def mist():
    bpy.ops.mesh.primitive_cube_add(size=60, location=(0, 15, 8))
    cube = bpy.context.object
    mat = bpy.data.materials.new("mist")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    vol = nodes.new("ShaderNodeVolumeScatter")
    vol.inputs["Density"].default_value = 0.0015
    vol.inputs["Anisotropy"].default_value = 0.25
    links.new(vol.outputs["Volume"], out.inputs["Volume"])
    cube.data.materials.append(mat)


def camera(target, lens=35.0):
    bpy.ops.object.camera_add()
    cam = bpy.context.object
    cam.data.lens = lens
    cam.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = (TARGET_HEIGHT / 0.82) / (2 * math.tan(vfov / 2))
    cam.location = (target.location.x + 0.4, -distance, 1.55)
    look = Vector((target.location.x, 0, TARGET_HEIGHT * 0.48))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.dof.use_dof = True
    cam.data.dof.focus_object = target
    cam.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = cam


def main():
    rng = random.Random(123)
    clean()
    target = load_tree(ROOT / "realistic_hd_common_fig_tree_3030.glb")
    target.location = (-4.0, 0, 0)
    target.rotation_euler = (0, 0, math.radians(25))

    neighbour = load_tree(ROOT / "realistic_hd_common_fig_tree_1330.glb", TARGET_HEIGHT * 0.95)
    neighbour.location = (8.0, 4.0, 0)
    neighbour.rotation_euler = (0, 0, math.radians(150))

    left = load_tree(ROOT / "realistic_hd_common_fig_tree_530.glb", TARGET_HEIGHT * 0.9)
    left.location = (-14.0, 7.0, 0)
    left.rotation_euler = (0, 0, math.radians(60))

    all_paths = [
        candidate
        for candidate in sorted(ROOT.glob("*.glb"))
        if candidate.name
        not in {
            "realistic_hd_common_fig_tree_3030.glb",
            "realistic_hd_common_fig_tree_1330.glb",
            "realistic_hd_common_fig_tree_530.glb",
        }
    ]
    rng.shuffle(all_paths)
    for index, tree_path in enumerate(all_paths[:22]):
        if index < 10:
            x = rng.uniform(-14, 14)
            y = rng.uniform(7, 16)
        else:
            x = rng.uniform(-30, 30)
            y = rng.uniform(20, 40)
        tree = load_tree(tree_path, TARGET_HEIGHT * rng.uniform(0.75, 1.05))
        tree.location = (x, y, 0)
        tree.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

    # understory: small dense fig clones read as shrubs at mid distance
    for _ in range(16):
        bush = duplicate(target)
        bush.scale = tuple(v * rng.uniform(0.14, 0.24) for v in target.scale)
        bush.location = (rng.uniform(-13, 13), rng.uniform(-2, 12), 0)
        bush.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

    ground()
    path()
    rocks(rng)
    log(-7, 2, 4.0, rng)
    log(8, 3, 3.0, rng)
    world(rng)
    mist()
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = 1.8
    sun.data.angle = math.radians(10)
    sun.rotation_euler = (math.radians(50), 0, math.radians(30))
    camera(target, 35.0)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    bpy.context.scene.render.filepath = str(OUT)
    bpy.ops.render.render(write_still=True)
    print(f"saved {OUT}")


if __name__ == "__main__":
    main()


