"""Run draft-trained visible-stem localization on RGB only, without annotations."""

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--images", type=Path, nargs="+", required=True)
    parser.add_argument("--baseline-run", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--threshold", type=float, default=0.65)
    args = parser.parse_args()
    if args.output.exists() or not 0 < args.threshold < 1:
        parser.error("Use a fresh output directory and a threshold between zero and one")
    for path in [*args.images, args.checkpoint, args.baseline_run / "pilot_checkpoint.pth"]:
        if not path.is_file():
            parser.error(f"Missing input: {path}")
    root = Path(__file__).resolve().parents[1]
    for path in [root, args.extra_packages.resolve(), args.source.resolve()]:
        sys.path.insert(0, str(path))
    import cv2
    import numpy as np
    import torch
    from torch.nn import functional as F

    from data import cfg, set_cfg
    from workers.tree_models.sparse_stem import SparseStemLocator
    from workers.tree_models.stem_diagnostics import compare_support

    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (512, 512)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    baseline = ConvexMask().cuda()
    baseline.load_state_dict(
        torch.load(
            args.baseline_run / "pilot_checkpoint.pth", weights_only=True, map_location="cuda"
        ),
        strict=True,
    )
    baseline.requires_grad_(False)
    baseline.train()  # Frozen BN; raw prototype interface, not optimization.
    weights = torch.load(args.checkpoint, weights_only=True, map_location="cuda")
    if weights.get("architecture") != "SparseStemLocator_v1":
        raise ValueError("Unsupported stem checkpoint architecture")
    locator = SparseStemLocator().cuda().eval()
    locator.load_state_dict(weights["model"], strict=True)
    transform = FastBaseTransform()
    args.output.mkdir(parents=True)
    rows = []
    with torch.inference_mode():
        for index, path in enumerate(args.images):
            started = time.perf_counter()
            original = cv2.imread(str(path))
            if original is None:
                raise ValueError(f"Cannot decode image: {path}")
            h, w = original.shape[:2]
            square = cv2.resize(original, (512, 512))
            tensor = torch.as_tensor(square).float()[None]
            raw = baseline(transform(tensor))
            features = raw["proto"].permute(0, 3, 1, 2)
            rgb = tensor.permute(0, 3, 1, 2) / 127.5 - 1
            logits = locator(features, rgb)
            grid = logits.sigmoid()[0, 0].cpu().numpy() > args.threshold
            raw["conf"], raw["center"] = raw["conf"].sigmoid(), raw["center"].sigmoid()
            result = postprocess(baseline.detect(raw, baseline), 512, 512, score_threshold=0.3)
            support = np.zeros((512, 512), np.uint8)
            if result[0].numel():
                support = result[4].bool().any(0).cpu().numpy().astype(np.uint8)
            support = cv2.dilate(support, np.ones((9, 9), np.uint8)) > 0
            support_grid = (
                cv2.resize(
                    support.astype(np.uint8),
                    (grid.shape[1], grid.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                )
                > 0
            )
            _, diagnostics = compare_support(grid, support_grid)
            probability = (
                F.interpolate(logits.sigmoid(), (h, w), mode="bilinear", align_corners=False)[0, 0]
                .cpu()
                .numpy()
            )
            raw_full = probability > args.threshold
            kept = raw_full & (
                cv2.resize(support.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST) > 0
            )
            prefix = f"{index:03d}_{path.stem}"
            outputs = {}
            for name, mask in [("raw", raw_full), ("constrained", kept)]:
                overlay = original.copy()
                overlay[mask] = (0.6 * overlay[mask] + 0.4 * np.array([255, 80, 0])).astype(
                    np.uint8
                )
                candidates = diagnostics[f"{'raw' if name == 'raw' else 'constrained'}_candidates"]
                for candidate in candidates:
                    x, y = candidate["xy_normalized"]
                    cv2.circle(
                        overlay, (round(x * (w - 1)), round(y * (h - 1))), 12, (0, 180, 255), 3
                    )
                overlay_path = args.output / f"{prefix}_{name}_overlay.png"
                cv2.imwrite(str(overlay_path), overlay)
                cv2.imwrite(
                    str(args.output / f"{prefix}_{name}_mask.png"), mask.astype(np.uint8) * 255
                )
                outputs[name] = str(overlay_path.resolve())
            rows.append(
                {
                    "image": str(path.resolve()),
                    "outputs": outputs,
                    "diagnostics": diagnostics,
                    "elapsed_seconds": time.perf_counter() - started,
                }
            )
            print(json.dumps(rows[-1]), flush=True)
    report = {
        "annotation_inputs_used": False,
        "depth_used": False,
        "multi_view_fusion": False,
        "formal_accuracy_evaluated": False,
        "draft_supervision": bool(weights.get("draft_supervision", True)),
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "threshold": args.threshold,
        "rows": rows,
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
