"""Frozen-feature crown/stem readout pilot; no identity/completion gain claim."""

from __future__ import annotations

import copy
import json
import random
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from paired_fig_dataset import PairedFigDataset  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from train_paired_whole_tree import INITIAL, REVISION, tensors  # noqa: E402


def write(path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def predict(head, tokens, features):
    coefficients = head(tokens)
    return torch.einsum("bkc,bkchw->bkhw", coefficients, features)


def main():
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    rng = random.Random(20261108)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = ROOT / "reports/part-readout-pilot-2026-11-08"
    out.mkdir(exist_ok=False)
    data = ROOT / "reports/fig-paired-v6-framing-30-2026-11-08"
    scope = assert_training_allowed(data)
    audit = json.loads((data / "paired-audit.json").read_text())
    if not audit.get("planned_dataset_complete"):
        raise ValueError("paired data incomplete")
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    protocol = {
        "purpose": "development part readout only; not anti-adhesion efficacy",
        "seed": 20261108,
        "epochs": 20,
        "learning_rate": 0.001,
        "data": str(data),
        "policy_scope": scope,
        "data_manifest_sha256": sha256_file(data / "paired-samples.json"),
        "split_sha256": sha256_file(data / "splits.json"),
        "real_initial_sha256": sha256_file(INITIAL),
        "coverage_initial_sha256": sha256_file(prior),
        "frozen": "all encoders, all tokens, visible/ownership/amodal/curve/layer decoders",
        "trainable": ["crown_hypernet", "stem_hypernet"],
        "PF": False,
        "LoRA": False,
        "test_images_accessed": False,
        "common_architecture_control": "same crown+stem tokens before/after readout training",
        "validation_used_for_checkpoint_selection": False,
        "promoted": False,
    }
    write(out / "protocol.json", protocol)
    source = out / "source"
    source.mkdir()
    for path in (
        Path(__file__),
        ROOT / "workers/tree_models/sam2_occlusion.py",
        ROOT / "workers/tree_models/paired_fig_dataset.py",
    ):
        (source / path.name).write_bytes(path.read_bytes())
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"], strict=True
    )
    model = (
        Sam2OcclusionModel(base, enable_stem=True, enable_crown=True, expose_query_features=True)
        .to(device)
        .eval()
    )
    payload = torch.load(prior, map_location="cpu", weights_only=True)
    state = payload["decoder"]
    report = model.decoder.load_state_dict(state, strict=False)
    if report.unexpected_keys or set(report.missing_keys) != {
        key
        for key in model.decoder.state_dict()
        if key.startswith(("crown_token.", "crown_hypernet."))
    }:
        raise ValueError(f"unexpected checkpoint mismatch: {report}")
    frozen_before = {key: value.cpu().clone() for key, value in model.state_dict().items()}
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    cache = {}
    with torch.no_grad():
        for split in ("train", "validation"):
            dataset = PairedFigDataset(data, split)
            cache[split] = []
            for index, record in enumerate(dataset.items):
                sample = dataset.sample(index)
                inputs, _ = tensors(sample, device)
                result = model(**inputs)
                cache[split].append(
                    {
                        "id": record["id"],
                        "condition": record["condition"],
                        "features": result["query_pixel_embeddings"].cpu(),
                        "crown_tokens": result["crown_token_features"].cpu(),
                        "stem_tokens": result["stem_token_features"].cpu(),
                        "valid": torch.from_numpy(sample["visible_part_valid"])[None],
                        "crown": torch.from_numpy(sample["visible_crown"])[None],
                        "stem": torch.from_numpy(sample["visible_stem"])[None],
                    }
                )
                if index % 10 == 0:
                    print(f"cached {split} {index + 1}/{len(dataset)}", flush=True)
    heads = {name: getattr(model.decoder, f"{name}_hypernet") for name in ("crown", "stem")}
    initial_heads = {key: copy.deepcopy(head.state_dict()) for key, head in heads.items()}
    for head in heads.values():
        head.requires_grad_(True)
    optimizer = torch.optim.AdamW([p for h in heads.values() for p in h.parameters()], lr=0.001)

    def loss_on(row):
        features, valid = row["features"].to(device), row["valid"].to(device)
        total = features.new_zeros(())
        for name, head in heads.items():
            logits = predict(head, row[f"{name}_tokens"].to(device), features)
            target = row[name].to(device).float()
            bce = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
            probability = logits.sigmoid() * valid
            dice = 1 - (2 * (probability * target).sum((-2, -1)) + 1) / (
                probability.sum((-2, -1)) + (target * valid).sum((-2, -1)) + 1
            )
            total = total + (bce * valid).sum() / valid.sum().clamp_min(1) + dice.mean()
        return total

    @torch.no_grad()
    def evaluate():
        rows = []
        for row in cache["validation"]:
            features, valid = row["features"].to(device), row["valid"].to(device)
            metrics = {"id": row["id"], "condition": row["condition"]}
            for name, head in heads.items():
                predicted = (predict(head, row[f"{name}_tokens"].to(device), features) > 0) & valid
                target = row[name].to(device) & valid
                intersection = (predicted & target).sum((-2, -1)).float()
                union = (predicted | target).sum((-2, -1)).clamp_min(1)
                metrics[f"{name}_iou"] = float((intersection / union).mean())
            rows.append(metrics)
        scenes = [row for row in rows if row["condition"] == "scene"]
        return {
            "scene_macro_iou": {
                name: sum(r[f"{name}_iou"] for r in scenes) / len(scenes) for name in heads
            },
            "records": rows,
        }

    before = evaluate()
    history = []
    for epoch in range(20):
        order = list(range(len(cache["train"])))
        rng.shuffle(order)
        losses = []
        for index in order:
            optimizer.zero_grad(set_to_none=True)
            loss = loss_on(cache["train"][index])
            if not torch.isfinite(loss):
                raise ValueError("nonfinite part loss")
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        history.append(sum(losses) / len(losses))
        print(f"epoch {epoch + 1}/20 train_loss={history[-1]:.6f}", flush=True)
    after = evaluate()
    changed = [
        key
        for key, value in model.state_dict().items()
        if not torch.equal(value.cpu(), frozen_before[key])
    ]
    if not changed or any(
        not key.startswith(("decoder.crown_hypernet.", "decoder.stem_hypernet.")) for key in changed
    ):
        raise ValueError(f"unexpected changed weights: {changed}")
    write(
        out / "results.json",
        {
            "before": before,
            "after": after,
            "train_loss": history,
            "changed_keys": changed,
            "all_other_weights_bitwise_unchanged": True,
            "promoted": False,
            "test_images_accessed": False,
        },
    )
    torch.save(
        {
            "initial": initial_heads,
            "trained": {k: h.state_dict() for k, h in heads.items()},
            "protocol": protocol,
        },
        out / "readouts-final.pth",
    )
    print(
        json.dumps({"before": before["scene_macro_iou"], "after": after["scene_macro_iou"]}),
        flush=True,
    )


if __name__ == "__main__":
    main()
