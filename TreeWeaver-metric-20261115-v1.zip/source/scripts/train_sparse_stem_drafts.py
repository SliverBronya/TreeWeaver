"""Real RGB sparse-stem experiment. Assistant drafts are not reviewed truth."""

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--baseline-run", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--allow-assistant-drafts", action="store_true")
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--constrain-to-tree-support", action="store_true")
    args = parser.parse_args()
    if not args.allow_assistant_drafts:
        parser.error(
            "This pilot requires explicit --allow-assistant-drafts; no reviewed GT claimed"
        )
    if args.output.exists() or not 1 <= args.steps <= 1000:
        parser.error("Use a fresh output and1..1000 steps")
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "src"))
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from torch.nn import functional as F

    from data import cfg, set_cfg
    from treeweaver.datasets.partial_labels import (
        content_fingerprint,
        sparse_stem_map,
        validate_group_split,
    )
    from workers.tree_models.sparse_stem import SparseStemLocator, sparse_stem_loss

    torch.manual_seed(42)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (512, 512)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    baseline = ConvexMask().cuda()
    baseline.load_state_dict(
        torch.load(
            args.baseline_run / "pilot_checkpoint.pth", weights_only=True, map_location="cuda"
        ),
        strict=True,
    )
    baseline.requires_grad_(False)
    baseline.train()  # Frozen BN, raw features only, no optimization of baseline.
    transform = FastBaseTransform()
    pack = json.loads((args.labels / "manifest.json").read_text())
    documents = [json.loads(Path(frame["annotation"]).read_text()) for frame in pack["frames"]]
    validate_group_split(documents)
    samples = []
    with torch.no_grad():
        for document in documents:
            if document["role"] == "protected_test" or not document["instances"]:
                continue
            path = Path(document["image"]["path"])
            if hashlib.sha256(path.read_bytes()).hexdigest() != document["image"]["sha256"]:
                raise ValueError("RGB content changed after draft creation")
            original = cv2.imread(str(path))
            labels = sparse_stem_map(document, assistant_experiment=True)
            rgb = cv2.resize(original, (512, 512))
            raw = baseline(transform(torch.as_tensor(rgb).float()[None]))
            features = raw["proto"].permute(0, 3, 1, 2).detach()
            support = None
            if args.constrain_to_tree_support:
                raw["conf"], raw["center"] = raw["conf"].sigmoid(), raw["center"].sigmoid()
                result = postprocess(baseline.detect(raw, baseline), 512, 512, score_threshold=0.3)
                support = np.zeros((512, 512), np.uint8)
                if result[0].numel():
                    support = result[4].bool().any(0).cpu().numpy().astype(np.uint8)
                support = cv2.dilate(support, np.ones((9, 9), np.uint8)) > 0
            h, w = features.shape[-2:]
            label_grid = cv2.resize(labels, (w, h), interpolation=cv2.INTER_NEAREST)
            if not (label_grid == 1).any() or not (label_grid == 0).any():
                raise ValueError(f"Need explicit positive and negative regions: {path}")
            samples.append(
                {
                    "document": document,
                    "original": original,
                    "features": features,
                    "rgb": torch.as_tensor(rgb).permute(2, 0, 1)[None].float() / 127.5 - 1,
                    "target": torch.as_tensor(label_grid, dtype=torch.long)[None],
                    "tree_support": support,
                }
            )
    train = [sample for sample in samples if sample["document"]["role"] == "train"]
    if not train:
        raise ValueError("No experimental training drafts")
    model = SparseStemLocator().cuda()
    initial = copy.deepcopy(model).eval()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    args.output.mkdir(parents=True)
    history = []
    for step in range(args.steps):
        sample = train[step % len(train)]
        features, rgb, target = sample["features"], sample["rgb"], sample["target"]
        if step % 2:
            features, rgb, target = features.flip(-1), rgb.flip(-1), target.flip(-1)
        optimizer.zero_grad(set_to_none=True)
        logits = model(features, rgb)
        loss = sparse_stem_loss(logits, target)
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite sparse loss")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
        optimizer.step()
        history.append({"step": step + 1, "loss": float(loss.detach())})
        if (step + 1) % 50 == 0:
            print(json.dumps(history[-1]), flush=True)
    torch.save(
        {
            "model": model.state_dict(),
            "steps": args.steps,
            "architecture": "SparseStemLocator_v1",
            "draft_supervision": True,
        },
        args.output / "sparse_stem_checkpoint.pth",
    )
    model.eval()
    rows = []
    with torch.no_grad():
        for sample in samples:
            document = sample["document"]
            row = {
                "image": document["image"]["path"],
                "role": document["role"],
                "source_group": document["source_group"],
                "draft_sha256": content_fingerprint(document),
                "evaluation_truth_verified": False,
                "sparse_diagnostics": {},
            }
            for name, locator in (("untrained", initial), ("trained", model)):
                logits = locator(sample["features"], sample["rgb"])
                positive = logits[:, 0].sigmoid() > 0.65
                target = sample["target"]
                row["sparse_diagnostics"][name] = {
                    "draft_positive_detected_fraction": float(positive[target == 1].float().mean()),
                    "draft_negative_false_positive_fraction": float(
                        positive[target == 0].float().mean()
                    ),
                    "unknown_pixels_scored": False,
                }
                if name != "trained":
                    continue
                h, w = sample["original"].shape[:2]
                probability = (
                    F.interpolate(logits.sigmoid(), (h, w), mode="bilinear", align_corners=False)[
                        0, 0
                    ]
                    .cpu()
                    .numpy()
                )
                stem_mask = probability > 0.65
                cv2.imwrite(
                    str(args.output / f"{Path(row['image']).stem}_raw_stem_mask.png"),
                    stem_mask.astype(np.uint8) * 255,
                )
                grid_prediction = positive[0].cpu().numpy()
                if sample["tree_support"] is not None:
                    support_full = (
                        cv2.resize(
                            sample["tree_support"].astype(np.uint8),
                            (w, h),
                            interpolation=cv2.INTER_NEAREST,
                        )
                        > 0
                    )
                    stem_mask &= support_full
                    support_grid = (
                        cv2.resize(
                            sample["tree_support"].astype(np.uint8),
                            (grid_prediction.shape[1], grid_prediction.shape[0]),
                            interpolation=cv2.INTER_NEAREST,
                        )
                        > 0
                    )
                    grid_prediction &= support_grid
                    row["tree_support_available"] = bool(support_full.any())
                overlay = sample["original"].copy()
                overlay[stem_mask] = (
                    0.6 * overlay[stem_mask] + 0.4 * np.array([255, 80, 0])
                ).astype(np.uint8)
                coarse_mask = grid_prediction.astype(np.uint8)
                count, components, stats, centers = cv2.connectedComponentsWithStats(coarse_mask, 8)
                candidates = []
                for component in range(1, count):
                    x, y, ww, hh, area = stats[component]
                    if hh >= 6 and hh >= 2 * ww and area >= 10:
                        candidates.append(
                            [
                                float(centers[component, 0] / (coarse_mask.shape[1] - 1)),
                                float(centers[component, 1] / (coarse_mask.shape[0] - 1)),
                            ]
                        )
                row["stem_candidates_xy"] = candidates
                row["metric_measurement_allowed"] = False
                for x, y in candidates:
                    cv2.circle(
                        overlay, (round(x * (w - 1)), round(y * (h - 1))), 12, (0, 180, 255), 3
                    )
                destination = args.output / f"{Path(row['image']).stem}_predicted_stems.png"
                cv2.imwrite(str(destination), overlay)
                cv2.imwrite(
                    str(args.output / f"{Path(row['image']).stem}_stem_mask.png"),
                    stem_mask.astype(np.uint8) * 255,
                )
                row["overlay"] = str(destination)
            rows.append(row)
    report = {
        "mode": "assistant-draft-supervised real RGB exploratory training",
        "train_frames": len(train),
        "development_frames": len(samples) - len(train),
        "steps": args.steps,
        "threshold": 0.65,
        "rows": rows,
        "formal_accuracy_evaluated": False,
        "protected_test_used": False,
        "depth_used": False,
        "baseline_frozen": True,
        "tree_support_constraint": args.constrain_to_tree_support,
        "limitations": [
            "Sparse unreviewed interior regions, not full stem boundaries",
            "Development diagnostic fractions compare to assistant drafts only",
            "Unknown regions ignored, full-image false alarms need human inspection",
            "Geometric candidate filtering is not reliable tree counting",
            "No DBH location, crown ownership or metric accuracy established",
        ],
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
