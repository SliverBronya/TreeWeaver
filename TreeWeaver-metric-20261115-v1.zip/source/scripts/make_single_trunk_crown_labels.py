"""Create single-trunk stem labels and crown labels from focused stems."""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver\reports\focused-composite-v3-60-2026-11-10")


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def largest(mask):
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    if count <= 1:
        return mask, 0
    areas = stats[1:, cv2.CC_STAT_AREA]
    keep = 1 + int(areas.argmax())
    return labels == keep, count - 1


def main():
    rows = json.loads((ROOT / "index.json").read_text(encoding="utf-8"))
    components = []
    for row in rows:
        scene = ROOT / row["scene"]
        visible = alpha(scene / "visible_target.png")
        stem = alpha(scene / "amodal_stem_target.png")
        single, count = largest(stem)
        crown = visible & ~single
        components.append(count)
        for name, mask in (("stem_single_target.png", single), ("crown_target.png", crown)):
            out = np.zeros((*mask.shape, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene / name)
    print("scenes", len(rows), "components_before", sorted(set(components)), "mean", sum(components) / max(len(components), 1))


if __name__ == "__main__":
    main()

