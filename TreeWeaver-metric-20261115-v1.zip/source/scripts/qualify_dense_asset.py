"""Select one actual dense tree, excluding its helpers, collider and simulators."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from fig_data_protocol import material_part, sha256_file, validate_plan  # noqa: E402


def main():
    original = ROOT / "tools/assets/blenderkit/broadleaf_dense_1k.blend"
    if sha256_file(original) != "0605e20901fe0df498eb9a1853c99e98393f1fa3aa3e20622dfb7dad22027954":
        raise ValueError("source hash differs")
    output = ROOT / "tools/assets/qualified-extra/broadleaf_dense_qualification_v1.glb"
    if output.exists():
        raise FileExistsError(output)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    source_name = "Broadleaf Dense Tree Adult"
    with bpy.data.libraries.load(str(original), link=False) as (available, requested):
        if source_name not in available.objects:
            raise ValueError("named actual tree missing")
        requested.objects = [source_name]
    tree = requested.objects[0]
    bpy.context.collection.objects.link(tree)
    transform = tree.matrix_world.copy()
    tree.parent = None
    tree.matrix_world = transform
    tree.hide_render = tree.hide_viewport = False
    tree.hide_set(False)
    for mat in tree.data.materials:
        if mat.name == "M Broadleaf Dense Tree Bark":
            mat.name = "QualifiedDense_WoodUnknown"
        elif mat.name == "M Broadleaf Dense Tree Leaf":
            mat.name = "QualifiedDense_Leaf"
        material_part(mat.name)
    tree.select_set(True)
    bpy.context.view_layer.objects.active = tree
    bpy.context.view_layer.update()
    bpy.ops.export_scene.gltf(
        filepath=str(output), export_format="GLB", use_selection=True, export_apply=True
    )
    if output.stat().st_size < 1000000:
        raise ValueError("suspiciously small export")
    plan = json.loads((ROOT / "reports/mixed-tree-grounded-plan-2026-11-08.json").read_text())
    name = output.stem
    plan["asset_pools"]["train"].append(name)
    plan["asset_manifest"][name] = {
        "path": str(output),
        "sha256": sha256_file(output),
        "source_family": "broadleaf_dense",
        "source_blend": str(original),
        "source_blend_sha256": sha256_file(original),
        "source_meshes": [source_name],
        "stem_truth_available": False,
        "wood_semantics": "all woody geometry part_unknown",
        "license_provenance_status": "pending; qualification only",
    }
    magnolia = "southern_magnolia_qualified_v3"
    for number, trees, overlap in (
        (37, [name], 0),
        (38, [name, magnolia], 0.15),
        (39, [magnolia, name, plan["asset_pools"]["train"][0]], 0.30),
    ):
        plan["records"].append(
            {
                "id": number,
                "split": "train",
                "trees": trees,
                "scene_seed": 20261108 + number,
                "requested_bbox_overlap": overlap,
                "spacing_class": "single" if number == 37 else "mixed_qualification",
                "minimum_origin_separation_ratio": 0.6,
            }
        )
    plan["qualification_only"] = True
    plan["qualification_note"] = (
        "Selected37..39 only; partial source/label qualification, no training."
    )
    validate_plan(plan)
    with (ROOT / "reports/dense-mixed-qualification-plan-2026-11-08.json").open("x") as stream:
        json.dump(plan, stream, indent=2)
    print(json.dumps({"asset": str(output), "bytes": output.stat().st_size}))


if __name__ == "__main__":
    main()
