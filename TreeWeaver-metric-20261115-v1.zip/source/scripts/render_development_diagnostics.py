"""Static research figures from saved CPU audits; no inference or recomputation."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main():
    ownership = json.loads(
        (ROOT / "reports/ownership-recoverability-2026-11-09/results.json").read_text()
    )
    completion = json.loads(
        (
            ROOT / "reports/two-hour-development-2026-11-09/completion-baseline-audit.json"
        ).read_text()
    )
    figure, axes = plt.subplots(1, 2, figsize=(12, 4.7), constrained_layout=True)
    colors = ["#627785", "#afbbc3", "#cb863b"]
    keys = [
        "no_query_predicts_foreground",
        "only_foreign_queries_active",
        "recoverable_assignment_error",
    ]
    names = ["No query covers pixel", "Correct query inactive", "Recoverable assignment error"]
    offsets = np.zeros(3)
    for key, name, color in zip(keys, names, colors, strict=True):
        values = []
        for part in ("whole", "crown", "stem"):
            row = ownership["micro_pixel_partitions"][part]["mask_winner"]
            values.append(100 * row[key] / (row["target_pixels"] - row["correct"]))
        axes[0].barh(
            ["Whole tree", "Crown surface", "Stem"], values, left=offsets, label=name, color=color
        )
        for index, value in enumerate(values):
            if value >= 5:
                axes[0].text(
                    offsets[index] + value / 2,
                    index,
                    f"{value:.1f}%",
                    ha="center",
                    va="center",
                    fontsize=9,
                )
        offsets += values
    axes[0].set(
        xlim=(0, 100),
        xlabel="Share of missed GT pixels (%)",
        title="A. Most missed pixels need visible-query repair",
    )
    axes[0].legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), frameon=False, fontsize=9)
    values = []
    for name in (
        "fig-paired-v6-framing-30-2026-11-08",
        "mixed-identity-layout-qualification-2026-11-08",
    ):
        values.append(
            completion["cohorts"][name]["summary"]["whole"]["copy_GT_visible"]["all"]["amodal_iou"]
            * 100
        )
    x = np.arange(2)
    axes[1].bar(x - 0.18, values, width=0.36, color=colors[0], label="Full-mask IoU")
    axes[1].bar(x + 0.18, [0, 0], width=0.36, color=colors[2], label="Hidden-region recall")
    for index, value in enumerate(values):
        axes[1].text(index - 0.18, value + 1.6, f"{value:.2f}%", ha="center", fontsize=10)
        axes[1].text(index + 0.18, 2, "0%", ha="center", fontsize=10)
    axes[1].set(
        xticks=x,
        xticklabels=["v6 train (25 trees)", "Mixed train (30 trees)"],
        ylim=(0, 108),
        ylabel="Macro-instance score (%)",
        title="B. Copying GT visible gives misleading full IoU",
    )
    axes[1].legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), frameon=False, fontsize=9)
    for axis in axes:
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="x" if axis == axes[0] else "y", alpha=0.15)
        axis.set_axisbelow(True)
    figure.suptitle("Development diagnostics — no new model training or inference", fontsize=12)
    out = ROOT / "reports/two-hour-development-2026-11-09"
    figure.savefig(out / "diagnostic-findings.png", dpi=180, bbox_inches="tight")
    figure.savefig(out / "diagnostic-findings.pdf", bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
