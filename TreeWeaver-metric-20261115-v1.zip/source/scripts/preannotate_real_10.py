"""Pre-annotate the 10 real images with detector boxes + SAM2 masks.

Writes assistant drafts only. They are not human GT and must be reviewed.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "reports" / "real-10-paired-2026-11-01"
WORK = PACK / "work"
MAX_CANDIDATES = 3


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def polygonize(mask: np.ndarray) -> list[list[list[float]]]:
    contours = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
    contours = [c for c in contours if cv2.contourArea(c) >= 32]
    contours.sort(key=cv2.contourArea, reverse=True)
    polygons = []
    for contour in contours[:4]:
        epsilon = max(1.0, 0.002 * cv2.arcLength(contour, True))
        approx = cv2.approxPolyDP(contour, epsilon, True).reshape(-1, 2)
        if len(approx) >= 3:
            polygons.append([[float(x), float(y)] for x, y in approx])
    return polygons


def main() -> int:
    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    sam_processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).eval()
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = AutoModelForZeroShotObjectDetection.from_pretrained(
        detector_path, local_files_only=True
    ).eval()

    manifest = json.loads((PACK / "manifest.json").read_text(encoding="utf-8"))
    by_id = {str(record["image_id"]): record for record in manifest["records"]}
    done = 0
    for image_path in sorted((WORK).glob("*.jpg")):
        image_id = image_path.stem
        json_path = WORK / f"{image_id}.json"
        document = json.loads(json_path.read_text(encoding="utf-8"))
        if document.get("shapes"):
            print(f"{image_id}: skip existing shapes")
            continue
        image_bgr = cv2.imread(str(image_path))
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(images=image, text="tree.", return_tensors="pt")
        with torch.no_grad():
            outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            threshold=0.25,
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        if len(boxes) == 0:
            print(f"{image_id}: no detector box")
            continue
        areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
        order = np.argsort(scores * np.sqrt(np.maximum(areas, 1.0)))[::-1][:MAX_CANDIDATES]
        shapes = []
        for rank, box_index in enumerate(order, start=1):
            box = boxes[box_index]
            scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
            scaled = torch.as_tensor(box * scale)[None, None]
            sam_inputs = sam_processor(images=image, return_tensors="pt")
            with torch.no_grad():
                base = sam2(
                    pixel_values=sam_inputs["pixel_values"],
                    input_boxes=scaled,
                    multimask_output=True,
                )
            selected = int(torch.argmax(base.iou_scores[0, 0]))
            mask = (base.pred_masks[0, 0, selected] > 0).cpu().numpy()
            polygons = polygonize(mask)
            if not polygons:
                continue
            for polygon in polygons:
                shapes.append(
                    {
                        "label": "visible",
                        "points": polygon,
                        "group_id": rank,
                        "shape_type": "polygon",
                        "flags": {"assistant_candidate": True},
                    }
                )
            print(f"{image_id}: candidate {rank} box={box.round(1).tolist()} polygons={len(polygons)}")
        if not shapes:
            print(f"{image_id}: no usable mask")
            continue
        document["shapes"] = shapes
        document["flags"] = {"assistant_draft": True}
        document["treeweaver_provenance"] = "assistant_prediction"
        document["treeweaver_coverage"] = "partial"
        document["treeweaver_review"] = {"state": "draft", "reviewer": ""}
        document["source_image_sha256"] = by_id[image_id]["image_sha256"]
        json_path.write_text(json.dumps(document, indent=2, ensure_ascii=False), encoding="utf-8")
        done += 1
    print(f"preannotated {done} images")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
