"""Joint prompted-tree inference with separate raw predictions and reviewed GT.

All prompt coordinates are in the original image frame. Without verified human
labels this writes diagnostics only; stock SAM2 is always a comparison model,
never ground truth. The original model masks are retained alongside explicitly
named ownership-constrained postprocessing.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import re
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import transformers
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
from instance_metrics import (  # noqa: E402
    instance_report,
    mask_iou,
    ownership_report,
    prompt_constraint_report,
    verified_annotation,
)
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

SAM_REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
DINO_REVISION = "a2bb814dd30d776dcf7e30523b00659f4f141c71"
COLOURS = [
    (60, 140, 245),
    (80, 195, 80),
    (230, 140, 60),
    (180, 80, 205),
    (80, 210, 210),
    (190, 190, 70),
]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def cached_snapshot(repo, revision):
    if not re.fullmatch(r"[a-fA-F0-9]{40}", revision):
        raise ValueError("model revision must be an explicit 40-character commit SHA")
    path = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "hub"
        / f"models--{repo.replace('/', '--')}"
        / "snapshots"
        / revision
    )
    if not path.is_dir():
        raise FileNotFoundError(f"Pinned model is not cached; downloads disabled: {path}")
    return path


def resolve(base, value):
    path = Path(value)
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def read_mask(path, shape):
    mask = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if mask is None or mask.ndim != 2 or mask.shape != shape:
        raise ValueError(f"GT must be single-channel original-resolution mask: {path}")
    return mask


def select_boxes(boxes, scores, maximum, nms_iou):
    order = sorted(range(len(scores)), key=lambda i: (-float(scores[i]), i))
    keep = []
    for i in order:
        box = boxes[i]
        discard = False
        for j in keep:
            other = boxes[j]
            inter = max(0, min(box[2], other[2]) - max(box[0], other[0])) * max(
                0, min(box[3], other[3]) - max(box[1], other[1])
            )
            union = (
                (box[2] - box[0]) * (box[3] - box[1])
                + (other[2] - other[0]) * (other[3] - other[1])
                - inter
            )
            if inter / max(union, 1) > nms_iou:
                discard = True
                break
        if not discard:
            keep.append(i)
        if len(keep) >= maximum:
            break
    return keep


def prompt_tensors(instances, width, height, device):
    if not instances:
        raise ValueError("at least one instance prompt is required")
    scale = np.asarray([1024 / width, 1024 / height], np.float32)
    boxes, points, labels = [], [], []
    box_presence = [bool(item.get("box")) for item in instances]
    if any(box_presence) and not all(box_presence):
        raise ValueError("joint prompts must all have boxes, or all use points only")
    for item in instances:
        if item.get("box"):
            box = np.asarray(item["box"], np.float32)
            if (
                box.shape != (4,)
                or not np.isfinite(box).all()
                or box[2] <= box[0]
                or box[3] <= box[1]
                or (box < 0).any()
                or box[2] > width
                or box[3] > height
            ):
                raise ValueError(f"invalid original-frame box: {item.get('id')}")
            boxes.append(box * np.tile(scale, 2))
        positive = item.get("positive_points", [])
        negative = item.get("negative_points", [])
        if not positive and not item.get("box"):
            raise ValueError("point-only prompts need a positive point per tree")
        coords = np.asarray(positive + negative, np.float32).reshape(-1, 2)
        if (
            not np.isfinite(coords).all()
            or (coords < 0).any()
            or (len(coords) and ((coords[:, 0] >= width).any() or (coords[:, 1] >= height).any()))
        ):
            raise ValueError("point coordinates must be inside original image")
        points.append(coords * scale)
        labels.append([1] * len(positive) + [0] * len(negative))
    result = {
        "input_boxes": torch.as_tensor(np.asarray(boxes), device=device)[None] if boxes else None
    }
    count = max(map(len, points))
    if count:
        coordinates = np.zeros((len(instances), count, 2), np.float32)
        padded_labels = np.full((len(instances), count), -1, np.int64)
        for i, point in enumerate(points):
            coordinates[i, : len(point)] = point
            padded_labels[i, : len(point)] = labels[i]
        result["input_points"] = torch.as_tensor(coordinates, device=device)[None]
        result["input_labels"] = torch.as_tensor(padded_labels, device=device)[None]
    return result


def write_mask(path, mask):
    if not cv2.imwrite(str(path), mask.astype(np.uint8) * 255):
        raise OSError(f"could not save {path}")


def overlay(image, masks, title, instances=None):
    panel = image.copy()
    for i, mask in enumerate(masks):
        colour = np.asarray(COLOURS[i % len(COLOURS)], float)
        panel[mask] = (0.55 * panel[mask] + 0.45 * colour).astype(np.uint8)
        if instances and instances[i].get("box"):
            x0, y0, x1, y1 = map(int, instances[i]["box"])
            cv2.rectangle(panel, (x0, y0), (x1, y1), tuple(map(int, colour)), 3)
            cv2.putText(
                panel,
                str(instances[i]["id"]),
                (x0, max(25, y0)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                tuple(map(int, colour)),
                2,
            )
    panel = cv2.resize(panel, (640, 360))
    cv2.rectangle(panel, (0, 0), (640, 30), (245, 245, 245), -1)
    cv2.putText(panel, title, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (20, 20, 20), 1)
    return panel


def evaluate_annotations(record, base, predictions, ownership, shape, tolerance):
    if not verified_annotation(record, base):
        if record.get("review", {}).get("status") == "human_verified":
            raise ValueError("reviewed source or mask content changed or review is invalid")
        return {"status": "unreviewed_or_absent", "metrics": None}
    source = record["review"].get("source_annotation")
    if not source:
        raise ValueError("human review requires source_annotation and a matching content hash")
    annotation_path = resolve(base, source)
    if sha256(annotation_path) != record["review"]["annotation_sha256"].lower():
        raise ValueError("reviewed source annotation has changed; review again before evaluation")
    instances = record["instances"]
    if not all(item.get("visible_mask") for item in instances):
        raise ValueError("verified record requires human visible masks for all prompted instances")
    hashes = {}
    masks = []
    for item in instances:
        path = resolve(base, item["visible_mask"])
        masks.append(read_mask(path, shape) > 0)
        hashes[str(path)] = sha256(path)
    targets = np.stack(masks)
    valid = np.ones(shape, bool)
    if record.get("unknown_mask"):
        path = resolve(base, record["unknown_mask"])
        valid &= read_mask(path, shape) == 0
        hashes[str(path)] = sha256(path)
    if record.get("ownership_mask"):
        path = resolve(base, record["ownership_mask"])
        target_owner = read_mask(path, shape)
        if not np.isin(target_owner, list(range(len(instances) + 1)) + [65535]).all():
            raise ValueError("ownership GT labels must be 0..K or 65535 unknown")
        hashes[str(path)] = sha256(path)
    else:
        if ((targets.sum(axis=0) > 1) & valid).any():
            raise ValueError("human visible masks conflict; explicit reviewed ownership is needed")
        target_owner = np.zeros(shape, np.uint16)
        for i, mask in enumerate(targets):
            target_owner[mask] = i + 1
    valid &= target_owner != 65535
    source_document = json.loads(annotation_path.read_text(encoding="utf-8"))
    coverage = source_document["treeweaver_coverage"]
    if record.get("annotation_coverage", coverage) != coverage:
        raise ValueError("record coverage differs from reviewed source annotation")
    metrics = {}
    for name, value in predictions.items():
        report = instance_report(value, targets, valid, tolerance)
        report["iou_metric_name"] = (
            "partial_known_region_iou" if coverage == "partial" else "exhaustive_visible_iou"
        )
        metrics[name] = report
    overlap = None
    if record.get("overlap_mask"):
        path = resolve(base, record["overlap_mask"])
        overlap = read_mask(path, shape) > 0
        hashes[str(path)] = sha256(path)
    metrics["ownership"] = ownership_report(ownership, target_owner, valid, overlap)
    return {
        "status": "human_verified",
        "review": record["review"],
        "annotation_coverage": coverage,
        "valid_pixel_fraction": float(valid.mean()),
        "known_background_pixels": int(((target_owner == 0) & valid).sum()),
        "metric_scope_note": (
            "partial labels ignore unknown pixels; IoU can be recall-like when no "
            "background is labelled; never pool with exhaustive-visible IoU"
        )
        if coverage == "partial"
        else "all declared known pixels; unknown pixels still excluded",
        "ground_truth_sha256": hashes,
        "metrics": metrics,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--images", type=Path, nargs="+")
    parser.add_argument("--max-objects", type=int, default=4)
    parser.add_argument("--box-threshold", type=float, default=0.25)
    parser.add_argument("--text-threshold", type=float, default=0.22)
    parser.add_argument("--nms-iou", type=float, default=0.5)
    parser.add_argument("--boundary-tolerance", type=int, default=2)
    parser.add_argument("--sam-revision", default=SAM_REVISION)
    parser.add_argument("--detector-revision", default=DINO_REVISION)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if bool(args.manifest) == bool(args.images):
        parser.error("provide exactly one of --manifest or --images")
    if not 1 <= args.max_objects <= 6 or not 0 < args.nms_iou <= 1:
        parser.error("max-objects must be 1..6, nms-iou in (0,1]")
    if args.output.exists():
        raise FileExistsError("output already exists; use a new run directory")
    if args.manifest:
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        if manifest.get("schema_version") != "treeweaver-real-multitree-1.0":
            raise ValueError("unsupported manifest schema")
        records, base = manifest["records"], args.manifest.resolve().parent
    else:
        base = Path.cwd()
        records = [
            {
                "image_id": path.stem,
                "image": str(path.resolve()),
                "split": "validation",
                "instances": [],
                "prompt_source": "detector",
            }
            for path in args.images
        ]
    ids = [str(record["image_id"]) for record in records]
    if len(set(ids)) != len(ids) or any(not re.fullmatch(r"[\w-]+", key) for key in ids):
        raise ValueError("image ids must be unique filename-safe identifiers")
    for record in records:
        if record.get("review", {}).get("status") == "human_verified" and not verified_annotation(
            record, base
        ):
            raise ValueError("human GT review/source/mask hashes are invalid or incomplete")
    sam_path = cached_snapshot("facebook/sam2.1-hiera-tiny", args.sam_revision)
    processor = Sam2Processor.from_pretrained(sam_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    detector = detector_processor = None
    if any(not record.get("instances") for record in records):
        dino_path = cached_snapshot("IDEA-Research/grounding-dino-tiny", args.detector_revision)
        detector_processor = AutoProcessor.from_pretrained(dino_path, local_files_only=True)
        detector = (
            AutoModelForZeroShotObjectDetection.from_pretrained(dino_path, local_files_only=True)
            .to(args.device)
            .eval()
        )
    args.output.mkdir(parents=True)
    metadata = {
        "schema_version": "treeweaver-real-multitree-run-1.0",
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": sha256(args.checkpoint),
        "sam_revision": args.sam_revision,
        "detector_revision": args.detector_revision if detector else None,
        "manifest_sha256": sha256(args.manifest) if args.manifest else None,
        "device": args.device,
        "max_objects": args.max_objects,
        "selection": "score-descending box NMS, capped; all retained objects jointly prompted",
        "box_threshold": args.box_threshold,
        "text_threshold": args.text_threshold,
        "nms_iou": args.nms_iou,
        "stock_mode": "multimask_output=False, same prompts as current model",
        "versions": {
            "torch": torch.__version__,
            "transformers": transformers.__version__,
            "numpy": np.__version__,
            "opencv": cv2.__version__,
        },
        "notes": [
            "amodal is a hypothesis, not observed geometry",
            "ownership-constrained masks are postprocessing",
            "ownership argmax is exclusive by definition; zero argmax conflict is not accuracy",
            "visibility variance is uncalibrated; stem channel is not validated",
            "no human GT means diagnostics only; stock SAM2 is never GT",
        ],
    }
    (args.output / "run.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    rows, resolved = [], []
    for original_record in records:
        record = dict(original_record)
        path = resolve(base, record["image"])
        if record.get("image_sha256") and sha256(path) != record["image_sha256"]:
            raise ValueError("source image content changed since annotation")
        image = cv2.imread(str(path))
        if image is None:
            raise FileNotFoundError(path)
        height, width = image.shape[:2]
        pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        instances = record.get("instances", [])
        candidate_count = None
        if not instances:
            detector_inputs = detector_processor(images=pil, text="tree.", return_tensors="pt").to(
                args.device
            )
            with torch.inference_mode():
                detected_out = detector(**detector_inputs)
            params = inspect.signature(
                detector_processor.post_process_grounded_object_detection
            ).parameters
            threshold_name = "threshold" if "threshold" in params else "box_threshold"
            detected = detector_processor.post_process_grounded_object_detection(
                detected_out,
                detector_inputs.input_ids,
                text_threshold=args.text_threshold,
                target_sizes=[(height, width)],
                **{threshold_name: args.box_threshold},
            )[0]
            boxes = detected["boxes"].detach().cpu().numpy()
            scores = detected["scores"].detach().cpu().numpy()
            boxes[:, [0, 2]] = np.clip(boxes[:, [0, 2]], 0, width)
            boxes[:, [1, 3]] = np.clip(boxes[:, [1, 3]], 0, height)
            candidate_count = len(boxes)
            selected = select_boxes(boxes, scores, args.max_objects, args.nms_iou)
            instances = [
                {
                    "id": f"tree-{i + 1}",
                    "box": boxes[j].tolist(),
                    "detector_score": float(scores[j]),
                }
                for i, j in enumerate(selected)
            ]
            record["prompt_source"] = "detector_proposal_not_reviewed"
        if len(instances) > args.max_objects:
            raise ValueError(
                "manual manifest exceeds max-objects; refusing silent target truncation"
            )
        record["instances"] = instances
        record["image"] = str(path)
        resolved.append(record)
        if not instances:
            rows.append(
                {"image_id": record["image_id"], "status": "no_prompts", "gt_metrics": None}
            )
            continue
        if len(set(str(item["id"]) for item in instances)) != len(instances):
            raise ValueError("instance ids must be unique within each image")
        prompts = prompt_tensors(instances, width, height, args.device)
        inputs = processor(images=pil, return_tensors="pt")
        with torch.inference_mode():
            base_out = sam2(
                pixel_values=inputs["pixel_values"].to(args.device),
                multimask_output=False,
                **prompts,
            )
            output = model(inputs["pixel_values"].to(args.device), **prompts)
            stock = (
                processor.post_process_masks(base_out.pred_masks, original_sizes=[[height, width]])[
                    0
                ][:, 0]
                .cpu()
                .numpy()
                > 0
            )
            raw = (
                processor.post_process_masks(output["masks"], original_sizes=[[height, width]])[0][
                    :, 0
                ]
                .cpu()
                .numpy()
                > 0
            )
            amodal = (
                processor.post_process_masks(
                    output["amodal_masks"], original_sizes=[[height, width]]
                )[0][:, 0]
                .cpu()
                .numpy()
                > 0
            )
        owner_small = output["ownership_logits"][0].argmax(0).cpu().numpy().astype(np.uint16)
        owner = cv2.resize(owner_small, (width, height), interpolation=cv2.INTER_NEAREST)
        constrained = np.stack([raw[i] & (owner == i + 1) for i in range(len(instances))])
        ownership_masks = np.stack([owner == i + 1 for i in range(len(instances))])
        item_root = args.output / str(record["image_id"])
        raw_dir, derived_dir = item_root / "raw_predictions", item_root / "derived_predictions"
        raw_dir.mkdir(parents=True)
        derived_dir.mkdir()
        for i in range(len(instances)):
            write_mask(raw_dir / f"visible_{i + 1}.png", raw[i])
            write_mask(raw_dir / f"amodal_hypothesis_{i + 1}.png", amodal[i])
            write_mask(raw_dir / f"stock_sam2_visible_{i + 1}.png", stock[i])
            write_mask(derived_dir / f"visible_ownership_constrained_{i + 1}.png", constrained[i])
        cv2.imwrite(str(raw_dir / "ownership_argmax.png"), owner)
        raw_conflict = raw.sum(axis=0) > 1
        write_mask(raw_dir / "visible_conflicts.png", raw_conflict)
        np.savez_compressed(
            raw_dir / "low_resolution_outputs.npz",
            visible_logits=output["masks"][0].cpu().numpy(),
            amodal_hypothesis_logits=output["amodal_masks"][0].cpu().numpy(),
            ownership_logits=output["ownership_logits"][0].cpu().numpy(),
            layer_logits=output["layer_logits"][0].cpu().numpy(),
            visibility=output["visibility"][0].cpu().numpy(),
        )
        gt = evaluate_annotations(
            record,
            base,
            {"stock_sam2": stock, "current_raw": raw, "current_ownership_constrained": constrained},
            owner,
            (height, width),
            args.boundary_tolerance,
        )
        row = {
            "image_id": record["image_id"],
            "image": str(path),
            "image_sha256": sha256(path),
            "status": "ok",
            "prompt_source": record.get("prompt_source", "manual_manifest"),
            "detector_candidates": candidate_count,
            "objects": len(instances),
            "raw_conflict_pixels": int(raw_conflict.sum()),
            "raw_conflict_fraction_of_union": float(
                raw_conflict.sum() / max(raw.any(axis=0).sum(), 1)
            ),
            "raw_mask_pixels": raw.sum(axis=(1, 2)).tolist(),
            "ownership_pixels": ownership_masks.sum(axis=(1, 2)).tolist(),
            "constrained_mask_pixels": constrained.sum(axis=(1, 2)).tolist(),
            "empty_raw_instances": int((~raw.any(axis=(1, 2))).sum()),
            "empty_constrained_instances": int((~constrained.any(axis=(1, 2))).sum()),
            "prompt_constraints": {
                name: prompt_constraint_report(masks, instances)
                for name, masks in {
                    "stock_sam2": stock,
                    "current_raw": raw,
                    "current_ownership_constrained": constrained,
                }.items()
            },
            "agreement_with_stock_sam2_not_accuracy": [
                mask_iou(raw[i], stock[i]) for i in range(len(instances))
            ],
            "layer_logits": output["layer_logits"][0].cpu().tolist(),
            "ground_truth": gt,
        }
        (item_root / "diagnostics.json").write_text(
            json.dumps(row, indent=2, allow_nan=False), encoding="utf-8"
        )
        panels = [
            overlay(image, np.zeros_like(raw), "Original + all retained prompts", instances),
            overlay(image, stock, "Stock SAM2: same prompts"),
            overlay(image, raw, "Current raw visible masks (may overlap)"),
            overlay(image, ownership_masks, "Ownership argmax (exclusive by definition)"),
            overlay(image, constrained, "Derived: visible AND ownership"),
            overlay(image, amodal, "Amodal hypotheses (NOT observed GT)"),
        ]
        sheet = np.concatenate(
            [np.concatenate(panels[:3], axis=1), np.concatenate(panels[3:], axis=1)], axis=0
        )
        cv2.imwrite(str(item_root / "comparison.png"), sheet)
        rows.append(row)
        print(
            json.dumps(
                {
                    k: row[k]
                    for k in [
                        "image_id",
                        "objects",
                        "raw_conflict_fraction_of_union",
                        "empty_raw_instances",
                        "empty_constrained_instances",
                    ]
                }
            ),
            flush=True,
        )
    (args.output / "resolved_prompts.json").write_text(
        json.dumps(
            {"schema_version": "treeweaver-real-multitree-1.0", "records": resolved}, indent=2
        ),
        encoding="utf-8",
    )
    summary = {
        "images_attempted": len(records),
        "images_ok": sum(r["status"] == "ok" for r in rows),
        "human_verified_images": sum(
            r.get("ground_truth", {}).get("status") == "human_verified" for r in rows
        ),
        "rows": rows,
    }
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
