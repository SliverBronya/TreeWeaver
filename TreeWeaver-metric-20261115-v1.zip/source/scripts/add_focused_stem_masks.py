"""Add source stem masks to focused composites for stem-head training."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver\reports\focused-composite-v3-60-2026-11-10")
V6 = Path(r"D:\TreeWeaver\reports\fig-paired-v6-framing-30-2026-11-08")


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def main():
    rows = json.loads((ROOT / "index.json").read_text(encoding="utf-8"))
    source = json.loads((V6 / "paired-samples.json").read_text(encoding="utf-8"))
    by_asset = {}
    for record in source["records"]:
        if record["condition"] != "scene" or record["split"] != "train":
            continue
        for item in record["instances"]:
            by_asset.setdefault(item["asset"], item)
    written = 0
    for row in rows:
        item = by_asset.get(row["target_asset"])
        if item is None:
            print(row["scene"], "no source", row["target_asset"])
            continue
        scene = ROOT / row["scene"]
        target = alpha(scene / "amodal_target.png")
        ys, xs = np.where(target)
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        stem = alpha(V6 / item["amodal_stem"])
        if stem.shape != target.shape:
            stem = np.asarray(
                Image.fromarray(stem.astype(np.uint8) * 255).resize(
                    (target.shape[1], target.shape[0]), Image.NEAREST
                )
            ) > 127
        stem_crop = np.asarray(
            Image.fromarray(stem[y0:y1, x0:x1].astype(np.uint8) * 255).resize(
                (x1 - x0, y1 - y0), Image.NEAREST
            )
        ) > 127
        full_stem = np.zeros_like(target)
        full_stem[y0:y1, x0:x1] = stem_crop
        full_stem &= target
        visible = alpha(scene / "visible_target.png")
        for name, mask in (("amodal_stem_target.png", full_stem), ("visible_stem_target.png", full_stem & visible)):
            out = np.zeros((*mask.shape, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene / name)
        written += 1
    print("written", written)


if __name__ == "__main__":
    main()
