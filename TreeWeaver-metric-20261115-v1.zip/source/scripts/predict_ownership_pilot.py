"""Automatic RGB target-refinement pilot; no labels, depth or camera poses required.

Processes images independently, not as registered multi-view reconstruction.
"""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-run", type=Path, required=True)
    parser.add_argument("--refiner", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--images", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("anchor", "control"), required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a fresh output directory")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from torch import nn
    from torch.nn import functional as F

    from data import cfg, set_cfg

    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    size = json.loads((args.baseline_run / "run.json").read_text())["image_size"]
    cfg.max_size = (size, size)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    from workers.tree_models.stem_ownership import StemOwnershipHead
    from workers.tree_models.stem_proxy import lower_mask_proxies, lower_mask_proxy

    model = ConvexMask().cuda()
    model.load_state_dict(
        torch.load(
            args.baseline_run / "pilot_checkpoint.pth", weights_only=True, map_location="cuda"
        ),
        strict=True,
    )
    model.requires_grad_(False)
    model.train()  # Raw prototype features, BN frozen; no optimization occurs.
    weights = torch.load(args.refiner, weights_only=True, map_location="cuda")
    channels = weights["channels"]
    refiner = (
        StemOwnershipHead(channels)
        if args.mode == "anchor"
        else nn.Sequential(nn.Conv2d(channels, 32, 1), nn.ReLU(), nn.Conv2d(32, 2, 1))
    )
    refiner.load_state_dict(weights[args.mode], strict=True)
    refiner.eval()
    transform = FastBaseTransform()
    args.output.mkdir(parents=True)
    rows = []
    with torch.inference_mode():
        for index, path in enumerate(args.images):
            original = cv2.imread(str(path))
            if original is None:
                raise ValueError(f"Cannot read RGB image: {path}")
            h, w = original.shape[:2]
            square = cv2.resize(original, (size, size))
            raw = model(transform(torch.as_tensor(square).float()[None]))
            features = raw["proto"].permute(0, 3, 1, 2)
            raw["conf"] = raw["conf"].sigmoid()
            raw["center"] = raw["center"].sigmoid()
            detections = postprocess(model.detect(raw, model), size, size, score_threshold=0.3)
            coarse = np.zeros((size, size), bool)
            if detections[0].numel():
                coarse = detections[4][int(detections[1].argmax())].bool().cpu().numpy()
            proxy = lower_mask_proxy(coarse)
            candidates = lower_mask_proxies(coarse)
            fallback = None
            if not coarse.any():
                fallback = "no_confident_target_detection"
                predicted = coarse
            elif not proxy.any():
                fallback = "no_lower_narrow_proxy; retained baseline"
                predicted = coarse
            else:
                fh, fw = features.shape[-2:]
                stems = torch.as_tensor(cv2.resize(proxy.astype(np.float32), (fw, fh)))[None, None]
                logits = (
                    refiner(features, stems)["logits"]
                    if args.mode == "anchor"
                    else refiner(features)
                )
                probability = F.interpolate(
                    logits.softmax(1)[:, 1:2], (size, size), mode="bilinear", align_corners=False
                )[0, 0]
                support = cv2.dilate(coarse.astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
                predicted = (probability.cpu().numpy() > 0.5) & support
            full_mask = (
                cv2.resize(predicted.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST) > 0
            )
            overlay = original.copy()
            overlay[full_mask] = (0.6 * overlay[full_mask] + 0.4 * np.array([255, 80, 0])).astype(
                np.uint8
            )
            name = f"{index:03d}_{path.stem}"
            mask_path = args.output / f"{name}_mask.png"
            overlay_path = args.output / f"{name}_overlay.png"
            cv2.imwrite(str(mask_path), full_mask.astype(np.uint8) * 255)
            cv2.imwrite(str(overlay_path), overlay)
            rows.append(
                {
                    "image": str(path.resolve()),
                    "mask": str(mask_path),
                    "overlay": str(overlay_path),
                    "fallback": fallback,
                    "proxy_pixels": int(proxy.sum()),
                    "possible_lower_stems": len(candidates),
                    "possible_merge_or_fork": len(candidates) > 1,
                    "instance_identity_validated": False,
                    "ground_truth_used": False,
                    "touches_image_top": bool(full_mask[0].any()),
                    "touches_image_bottom": bool(full_mask[-1].any()),
                }
            )
    result = {
        "mode": args.mode,
        "images": rows,
        "depth_used": False,
        "multi_view_registration": False,
        "metric_measurements_produced": False,
        "scope": "Highest-confidence target only, not exhaustive tree instances",
        "warning": "Unvalidated weak proxy; boundary contact can indicate truncation",
    }
    (args.output / "run.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
