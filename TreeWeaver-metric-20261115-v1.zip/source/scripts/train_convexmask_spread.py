"""Bounded RGB-only ConvexMask pilot on synthetic SPREAD instance labels.

This is a bounded learning diagnostic on the synthetic SPREAD forest
scenes, not a reproduction of the paper and not a measurement-accuracy
claim. SPREAD labels are rendered instance masks; tree height / DBH /
crown width / volume are never used here.

Split is scene-disjoint (birch_forest + broadleaf_forest train,
city_park held-out); tree identity is (scene, TreeName).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path


def parse_mapping(path: Path) -> list[tuple[str, int]]:
    entries = []
    for line in path.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) != 2:
            continue
        name, raw_index = parts
        try:
            index = int(raw_index)
        except ValueError:
            continue
        entries.append((name, index))
    return entries


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--palette", type=Path, required=True)
    parser.add_argument("--train-scenes", nargs="+", default=["birch_forest", "broadleaf_forest"])
    parser.add_argument("--test-scenes", nargs="+", default=["city_park"])
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--backbone", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument("--size", type=int, default=512)
    parser.add_argument("--max-train-frames", type=int, default=240)
    parser.add_argument("--max-test-frames", type=int, default=30)
    parser.add_argument("--max-instances", type=int, default=24)
    # Keep only dense (compact-canopy) instances. ConvexMask learns a mask inside
    # a convex polygon; leafless SPREAD trees are sparse trunks whose convex hull
    # is ~20x the visible pixels, which leaves the mask branch with no compact
    # target. density = raster_area / convex_hull_area. 0 disables the filter.
    parser.add_argument("--min-density", type=float, default=0.0)
    parser.add_argument("--min-area", type=int, default=0,
                        help="minimum raster area at training size (pixels)")
    args = parser.parse_args()
    # Bounded pilot cap: 5000 steps (~5 min on this GPU). The compact-canopy
    # subset is small (tens of frames), so the mask branch needs more epochs
    # than the nominal 400 to converge.
    if not 0 < args.steps <= 5000 or args.size < 128 or args.size % 32:
        parser.error("Pilot requires 1..5000 steps and an image size divisible by 32")
    if args.output.exists():
        parser.error("Use a new output directory; existing runs will not be overwritten")
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    import torch.nn.functional as functional

    from data import cfg, set_cfg

    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (args.size, args.size)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    from convexmask import ConvexMask
    from layers.modules.multibox_loss import MultiBoxLoss

    palette = {int(k): tuple(v) for k, v in
               json.loads(args.palette.read_text(encoding="utf-8"))["palette"].items()}

    def build_records(scenes: list[str], cap: int) -> list[dict]:
        rng = random.Random(42)
        records: list[dict] = []
        per_scene = cap // len(scenes)
        for scene in scenes:
            rgb_dir = args.data_root / scene / "rgb"
            inst_dir = args.data_root / scene / "instance_segmentation"
            frames = sorted(p.stem for p in rgb_dir.glob("*.png"))
            rng.shuffle(frames)
            scene_cap = per_scene if len(scenes) > 1 else cap
            selected = frames[:scene_cap]
            for stem in selected:
                rgb_path = rgb_dir / f"{stem}.png"
                inst_path = inst_dir / f"{stem}.png"
                map_path = inst_dir / f"{stem}.txt"
                if not inst_path.is_file() or not map_path.is_file():
                    continue
                image = cv2.imread(str(rgb_path))
                instance = cv2.cvtColor(cv2.imread(str(inst_path)), cv2.COLOR_BGR2RGB)
                if image is None or instance is None:
                    raise FileNotFoundError(stem)
                # SPREAD labels are rendered at half RGB resolution
                # (960x540 RGB vs 480x270 instance); both are resized to the
                # square training size independently. Only aspect ratio must match.
                rgb_ar = image.shape[1] / image.shape[0]
                inst_ar = instance.shape[1] / instance.shape[0]
                if abs(rgb_ar - inst_ar) > 0.01:
                    raise ValueError(f"RGB/instance aspect mismatch: {stem}")
                h, w = image.shape[:2]
                instances: list[dict] = []
                for name, index in parse_mapping(map_path):
                    if not name.startswith("Tree") or index not in palette:
                        continue
                    color = palette[index]
                    mask = cv2.inRange(instance, np.array(color), np.array(color))
                    area = int(mask.sum() // 255)
                    if area < 10:
                        continue  # Off-screen / sub-pixel instances.
                    instances.append(
                        {"tree": name, "index": index, "full_area": area, "mask": mask}
                    )
                if not instances:
                    continue
                # Resize every candidate and compute hull, then optionally keep
                # only compact-canopy instances (see --min-density rationale).
                kept: list[dict] = []
                for item in instances:
                    mask = cv2.resize(item["mask"], (args.size, args.size),
                                      interpolation=cv2.INTER_NEAREST)
                    mask = (mask > 0).astype(np.uint8)
                    ys, xs = np.nonzero(mask)
                    if len(xs) < 10:
                        continue
                    raster_area = int(mask.sum())
                    if raster_area < args.min_area:
                        continue
                    contours = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                                cv2.CHAIN_APPROX_SIMPLE)[0]
                    if not contours:
                        continue
                    hull = cv2.convexHull(np.concatenate(contours))[:, 0]
                    hull_area = float(cv2.contourArea(
                        cv2.convexHull(np.concatenate(contours))))
                    density = raster_area / hull_area if hull_area > 0 else 0.0
                    if args.min_density > 0 and density < args.min_density:
                        continue
                    kept.append({
                        "tree": item["tree"], "mask": mask, "hull": hull,
                        "raster_area": raster_area, "density": density,
                    })
                if not kept:
                    continue
                kept.sort(key=lambda it: it["raster_area"], reverse=True)
                kept = kept[: args.max_instances]
                masks, boxes, hulls = [], [], []
                for item in kept:
                    mask = item["mask"]
                    hull = item["hull"]
                    ys, xs = np.nonzero(mask)
                    masks.append(mask)
                    hulls.append(hull.astype(np.float32) / args.size)
                    boxes.append([
                        xs.min() / args.size,
                        ys.min() / args.size,
                        (xs.max() + 1) / args.size,
                        (ys.max() + 1) / args.size,
                        0,
                    ])
                resized = cv2.resize(image, (args.size, args.size)).astype(np.float32)
                resized = (
                    (resized - np.array([103.94, 116.78, 123.68]))
                    / np.array([57.38, 57.12, 58.40])
                )[:, :, ::-1].copy()
                image_tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)
                polygons = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
                for i, hull in enumerate(hulls):
                    polygons[i, : len(hull)] = hull
                records.append({
                    "scene": scene,
                    "frame": stem,
                    "focus_tree": stem.split("_", 1)[0],
                    "tree_identities": [f"{scene}/{item['tree']}" for item in kept],
                    "instance_count": len(masks),
                    "image": str(rgb_path),
                    "tensor": image_tensor,
                    "boxes": torch.tensor(boxes, dtype=torch.float32),
                    "masks": torch.tensor(np.stack(masks), dtype=torch.uint8),
                    "polygons": torch.tensor(polygons),
                })
        if not records:
            raise ValueError(f"No usable frames for scenes {scenes}")
        return records

    train = build_records(args.train_scenes, args.max_train_frames)
    test = build_records(args.test_scenes, args.max_test_frames)
    args.output.mkdir(parents=True)
    manifest = {
        "label_scope": "synthetic SPREAD rendered instance masks; Tree objects only",
        "depth_used": False,
        "seed": 42,
        "split": "scene-disjoint; identity = (scene, TreeName)",
        "train_scenes": args.train_scenes,
        "test_scenes": args.test_scenes,
        "max_instances_per_frame": args.max_instances,
        "instance_filter": {"min_density": args.min_density, "min_area": args.min_area},
        "filter_rationale": "ConvexMask predicts a mask inside a convex polygon; only "
                           "compact-canopy (dense) Tree instances have a learnable target. "
                           "Leafless SPREAD trees are sparse trunks with hull ~20x visible "
                           "pixels and are excluded from this bounded pilot.",
        "train_frames": len(train),
        "test_frames": len(test),
        "train_instances": sum(r["instance_count"] for r in train),
        "test_instances": sum(r["instance_count"] for r in test),
        "train": [{k: v for k, v in r.items() if k in
                   ("scene", "frame", "focus_tree", "tree_identities", "instance_count")}
                  for r in train],
        "test": [{k: v for k, v in r.items() if k in
                  ("scene", "frame", "focus_tree", "tree_identities", "instance_count")}
                 for r in test],
        "limitations": [
            "Synthetic rendered images and labels; no real-forest accuracy claim",
            "No scene generalization claim beyond the held-out city_park scene",
            "Not detector accuracy: held-out numbers are oracle-selected raw-mask diagnostics",
            "No tree height / DBH / crown width / volume supervision or evaluation",
            "Labels are visible-region masks; occluded (amodal) regions stay unknown",
            "Frames are capped and multi-instance counts are capped per frame",
        ],
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    model = ConvexMask().cuda()
    backbone = torch.load(args.backbone, map_location="cuda", weights_only=True)
    remapped = {}
    for key, value in backbone.items():
        if key.startswith("fc."):
            continue
        if key.startswith("layer"):
            key = "layers." + str(int(key[5]) - 1) + key[6:]
        remapped[key] = value
    model.backbone.load_state_dict(remapped, strict=True)
    criterion = MultiBoxLoss(2, cfg.num_rays, cfg.ohem_negpos_ratio)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    model.train()
    history = []
    torch.cuda.reset_peak_memory_stats()
    for step in range(args.steps):
        record = train[step % len(train)]
        image = record["tensor"][None].cuda()
        boxes = record["boxes"].cuda()
        masks = record["masks"].float().cuda()
        polygons = record["polygons"].cuda()
        torch.cuda.synchronize()
        started = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        predictions = model(image)
        losses = criterion(
            model, predictions, [boxes.clone()], [masks.clone()], [polygons.clone()],
            [0]
        )
        total = sum(losses.values())
        if not torch.isfinite(total):
            raise FloatingPointError(f"Non-finite loss at step {step}: {losses}")
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0, error_if_nonfinite=True)
        optimizer.step()
        torch.cuda.synchronize()
        entry = {
            "step": step + 1,
            "scene": record["scene"],
            "frame": record["frame"],
            "instances": record["instance_count"],
            "loss": float(total.detach()),
            "seconds": time.perf_counter() - started,
            "components": {key: float(value.detach()) for key, value in losses.items()},
        }
        history.append(entry)
        if step == 0 or (step + 1) % 10 == 0:
            print(json.dumps(entry), flush=True)
        (args.output / "history.json").write_text(json.dumps(history, indent=2),
                                                  encoding="utf-8")
    checkpoint_path = args.output / "pilot_checkpoint.pth"
    torch.save(model.state_dict(), checkpoint_path)
    # Oracle-selected prediction evaluation diagnoses mask learning, not autonomous detection.
    model.train()  # Raw prototype outputs are needed; BN remains frozen by configuration.

    def evaluate(records: list[dict], save_overlay: bool) -> list[dict]:
        evaluations = []
        with torch.no_grad():
            for record in records:
                image = record["tensor"][None].cuda()
                predictions = model(image)
                probs = (predictions["proto"][0] @ predictions["mask"][0].T).sigmoid()
                scores = predictions["conf"][0, :, 1].sigmoid()
                indices = scores.topk(min(32, scores.numel())).indices
                candidate_masks = (
                    functional.interpolate(
                        probs[:, :, indices].permute(2, 0, 1)[None],
                        (args.size, args.size),
                        mode="bilinear",
                        align_corners=False,
                    )[0] > 0.5
                )
                overlay = cv2.resize(cv2.imread(record["image"]), (args.size, args.size))
                ious = []
                for target_index in range(record["instance_count"]):
                    target = record["masks"][target_index].bool().cuda()
                    intersections = (candidate_masks & target).sum((1, 2))
                    unions = (candidate_masks | target).sum((1, 2)).clamp_min(1)
                    iou = (intersections / unions)
                    best = int(iou.argmax())
                    ious.append(float(iou[best]))
                    if target_index < 3:
                        predicted = candidate_masks[best].cpu().numpy()
                        overlay[predicted] = (
                            0.6 * overlay[predicted] + 0.4 * np.array([0, 80, 255])
                        ).astype(np.uint8)
                evaluations.append({
                    "scene": record["scene"],
                    "frame": record["frame"],
                    "tree_identities": record["tree_identities"],
                    "oracle_mask_ious": ious,
                    "mean_oracle_mask_iou": float(sum(ious) / len(ious)),
                })
                if save_overlay:
                    cv2.imwrite(
                        str(args.output / f"{record['scene']}_{record['frame']}_oracle_overlay.png"),
                        overlay)
        return evaluations

    evaluations = evaluate(test, True)
    train_evaluations = evaluate(train, False)
    all_ious = [iou for item in evaluations for iou in item["oracle_mask_ious"]]
    train_iou = [iou for item in train_evaluations for iou in item["oracle_mask_ious"]]
    report = {
        "completed_steps": args.steps,
        "architecture": "ConvexMask ResNet50 / 72 rays",
        "image_size": args.size,
        "train_scenes": args.train_scenes,
        "test_scenes": args.test_scenes,
        "training_frames": len(train),
        "held_out_frames": len(test),
        "training_instances": manifest["train_instances"],
        "held_out_instances": manifest["test_instances"],
        "checkpoint": str(checkpoint_path),
        "evaluations": evaluations,
        "evaluation_type": "oracle-selected raw mask diagnostic, NOT detector accuracy",
        "held_out_oracle_mask_iou_mean": float(sum(all_ious) / len(all_ious)),
        "train_oracle_mask_iou_mean": float(sum(train_iou) / len(train_iou)),
        "instance_filter": {"min_density": args.min_density, "min_area": args.min_area},
        "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
        "backbone_sha256": hashlib.sha256(args.backbone.read_bytes()).hexdigest(),
        "median_step_seconds": float(np.median([row["seconds"] for row in history[1:]])),
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "evaluations"},
                     indent=2), flush=True)


if __name__ == "__main__":
    main()
