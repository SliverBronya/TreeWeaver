"""Reference: positive-anchor mask probs on the LOCAL pilot3 checkpoint (throwaway)."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, r".worker-envs\convexmask-extra")
sys.path.insert(0, r"data/external/convexmask-source")
import cv2
import numpy as np
import torch
import torch.nn.functional as functional
from data import cfg, set_cfg
torch.set_default_tensor_type(torch.cuda.FloatTensor)
set_cfg("convex_synthtree_focal")
cfg.max_size = (512, 512)
cfg.fixed_size = True
cfg.freeze_bn = True
cfg.mask_proto_debug = False
cfg.dataset.class_names = ("tree",)
from convexmask import ConvexMask
from layers.polar_utils import polar_target

size = 512
man = json.loads(Path("reports/convexmask-train-2026-10-12-pilot3/manifest.json").read_text(encoding="utf-8"))
r = man["train"][0]
label = json.loads(Path(r["annotation"]).read_text(encoding="utf-8"))
image = cv2.imread(r["image"])
masks, boxes, hulls = [], [], []
for shape in [s for s in label["shapes"] if s["label"] == "tree"]:
    pts = np.asarray(shape["points"], dtype=np.float32)
    mm = np.zeros((label["imageHeight"], label["imageWidth"]), np.uint8)
    cv2.fillPoly(mm, [np.round(pts).astype(np.int32)], 1)
    mm = cv2.resize(mm, (size, size), interpolation=cv2.INTER_NEAREST)
    ys, xs = np.nonzero(mm)
    if len(xs) < 10:
        continue
    cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
    hulls.append(cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32) / size)
    masks.append(mm)
    boxes.append([xs.min()/size, ys.min()/size, (xs.max()+1)/size, (ys.max()+1)/size, 0])
resized = cv2.resize(image, (size, size)).astype(np.float32)
resized = ((resized - np.array([103.94, 116.78, 123.68])) / np.array([57.38, 57.12, 58.40]))[:, :, ::-1].copy()
tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)
polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
for i, h in enumerate(hulls):
    polys[i, :len(h)] = h

model = ConvexMask().cuda()
model.load_state_dict(torch.load("reports/convexmask-train-2026-10-12-pilot3/pilot_checkpoint.pth",
                                 map_location="cuda"))
model.train()
with torch.no_grad():
    pred = model(tensor[None].cuda())
    lab, bbt, pt, idxt, cent = polar_target(
        torch.tensor(boxes, dtype=torch.float32)[:, :-1].cuda(),
        torch.tensor(polys, dtype=torch.float32).cuda(),
        torch.zeros(len(boxes), dtype=torch.long).cuda(),
        pred["points"], pred["regress_ranges"], cfg.num_rays, pred["img_size"],
        None, cfg.radius, cfg.force_gt_attribute)
    pos = lab > 0
    mh, mw = pred["proto"].shape[1:3]
    probs = (pred["proto"][0] @ pred["mask"][0].T).sigmoid()
    gt = functional.interpolate(
        torch.tensor(np.stack(masks), dtype=torch.float32).cuda()[None], (mh, mw),
        mode="nearest")[0]
    pos_anchors = pos.nonzero()[:, 0]
    gt_idx = idxt[pos]
    print("LOCAL frame", Path(r["image"]).name, "pos:", len(pos_anchors))
    for pi in range(min(10, len(pos_anchors))):
        ai = int(pos_anchors[pi]); gi = int(gt_idx[pi])
        pmap = probs[:, :, ai]
        t = gt[gi].bool()
        print(f"  pos {pi} anchor {ai} gt{gi}: INSIDE={float(pmap[t].mean()):.3f} outside={float(pmap[~t].mean()):.3f}")
