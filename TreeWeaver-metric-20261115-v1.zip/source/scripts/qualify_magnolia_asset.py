"""Export the explicitly audited single magnolia mesh and freeze a paired pilot plan."""

from __future__ import annotations

import hashlib
import json
import struct
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from fig_data_protocol import material_part, validate_plan  # noqa: E402


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    audit = json.loads((ROOT / "reports/nonfig-asset-audit-2026-11-08.json").read_text())
    source = next(row for row in audit["candidates"] if "southern_magnolia" in row["path"])
    origin = ROOT / source["path"]
    if sha(origin) != source["sha256"] or len(source["meshes"]) != 1:
        raise ValueError("magnolia source differs from audited single-mesh candidate")
    output = ROOT / "tools/assets/qualified-extra/southern_magnolia_qualified_v3.glb"
    if output.exists():
        raise FileExistsError(output)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    name = source["meshes"][0]["name"]
    with bpy.data.libraries.load(str(origin), link=False) as (available, requested):
        if name not in available.objects:
            raise ValueError("audited source mesh missing")
        requested.objects = [name]
    tree = requested.objects[0]
    bpy.context.collection.objects.link(tree)
    # An appended mesh may retain a parent outside the scene. Detach while
    # preserving its transform, otherwise glTF can silently export no roots.
    transform = tree.matrix_world.copy()
    tree.parent = None
    tree.matrix_world = transform
    bpy.context.view_layer.update()
    semantics = {m.name: material_part(m.name) for m in tree.data.materials if m}
    for image in bpy.data.images:
        if image.source == "FILE" and not image.packed_file:
            path = Path(bpy.path.abspath(image.filepath))
            if not path.is_file():
                raise ValueError(f"unresolved source image: {image.name}")
    tree.hide_render = False
    tree.hide_viewport = False
    tree.hide_set(False)
    bpy.context.view_layer.update()
    tree.select_set(True)
    bpy.context.view_layer.objects.active = tree
    if not tree.visible_get() or not tree.select_get() or tree.type != "MESH":
        raise ValueError("source mesh is not visible and selected for export")
    if not tree.data.polygons:
        raise ValueError("audited tree mesh has no renderable faces")
    output.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.export_scene.gltf(
        filepath=str(output), export_format="GLB", use_selection=True, export_apply=True
    )
    payload = output.read_bytes()
    json_length = struct.unpack("<I", payload[12:16])[0]
    gltf = json.loads(payload[20 : 20 + json_length])
    if not gltf.get("meshes") or len(payload) < 1_000_000:
        raise ValueError("export did not contain the audited tree geometry")
    plan = json.loads((ROOT / "reports/fig-paired-v6-framing-plan-2026-11-08.json").read_text())
    identity = output.stem
    plan["asset_pools"]["train"].append(identity)
    plan["asset_manifest"][identity] = {
        "path": str(output),
        "sha256": sha(output),
        "source_family": "southern_magnolia",
        "source_blend": str(origin),
        "source_blend_sha256": source["sha256"],
        "source_meshes": [name],
        "part_materials": semantics,
        "status": "paired-label qualification candidate, not a formal training corpus",
    }
    fig1, fig2 = plan["asset_pools"]["train"][:2]
    for number, trees, overlap in (
        (31, [identity], 0.0),
        (32, [identity, fig1], 0.30),
        (33, [fig2, identity, fig1], 0.50),
    ):
        plan["records"].append(
            {
                "id": number,
                "split": "train",
                "trees": trees,
                "scene_seed": 20261108 + number,
                "requested_bbox_overlap": overlap,
                "spacing_class": "single" if len(trees) == 1 else "mixed_family_overlap",
                "minimum_origin_separation_ratio": 0.6,
            }
        )
    plan["qualification_only"] = True
    plan["qualification_note"] = (
        "Render selected IDs31..33 only; incomplete pilot, never main training."
    )
    validate_plan(plan)
    destination = ROOT / "reports/mixed-tree-qualification-v3-plan-2026-11-08.json"
    with destination.open("x", encoding="utf-8") as handle:
        json.dump(plan, handle, indent=2)
    print(json.dumps({"export": str(output), "plan": str(destination), "materials": semantics}))


if __name__ == "__main__":
    main()
