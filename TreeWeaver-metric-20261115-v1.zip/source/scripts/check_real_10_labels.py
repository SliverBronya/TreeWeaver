"""Check the 10-image LabelMe work files without modifying them."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = {
    "visible": "polygon",
    "occluded": "polygon",
    "stem": "polygon",
    "stem_occluded": "polygon",
    "unknown": "polygon",
    "background": "polygon",
    "positive_stem_point": "point",
    "negative_point": "point",
    "prompt_box": "rectangle",
}


def check(document: dict) -> list[str]:
    errors: list[str] = []
    shapes = document.get("shapes", [])
    if not shapes:
        return ["no shapes"]
    visible_ids = set()
    for shape in shapes:
        label = shape.get("label")
        if label not in ALLOWED:
            errors.append(f"unknown label {label!r}")
            continue
        if shape.get("shape_type") != ALLOWED[label]:
            errors.append(f"{label} should be {ALLOWED[label]}")
        if label not in {"unknown", "background"}:
            group = shape.get("group_id")
            if not isinstance(group, int) or group < 1:
                errors.append(f"{label} needs positive group_id")
            if label == "visible" and not shape.get("flags", {}).get("hole", False):
                visible_ids.add(group)
    if not visible_ids:
        errors.append("no visible polygon")
    for shape in shapes:
        label = shape.get("label")
        if label in {"unknown", "background"}:
            continue
        group = shape.get("group_id")
        if group not in visible_ids:
            errors.append(f"{label} group {group} has no visible polygon")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, default=ROOT / "reports" / "real-10-paired-2026-11-01" / "work")
    args = parser.parse_args()
    files = sorted(args.work.glob("*.json"))
    ready = 0
    for path in files:
        document = json.loads(path.read_text(encoding="utf-8"))
        errors = check(document)
        status = "OK" if not errors else "PENDING"
        if not errors:
            ready += 1
        print(f"{path.stem}: {status} shapes={len(document.get('shapes', []))}")
        for error in errors:
            print(f"  - {error}")
    print(json.dumps({"files": len(files), "ready": ready, "pending": len(files) - ready}, indent=2))
    return 0 if ready == len(files) and files else 1


if __name__ == "__main__":
    raise SystemExit(main())
