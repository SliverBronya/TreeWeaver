"""Real-photo qualitative/pairwise comparison; no GT masks exist."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

REAL = ROOT / "data/20260411"
READOUT = ROOT / "reports/frozen-visible-readout-300-viz-2026-11-09/checkpoint.pth"
LORA = ROOT / "reports/frozen-visible-lora-300-seed20261110-2026-11-09/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/real-20260411-readout-vs-lora-2026-11-09"
SIZE = 640
PROMPTS = {
    "10001": [300, 80, 780, 1830],
    "10002": [390, 60, 870, 1850],
    "10003": [250, 120, 760, 1850],
}


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def box_tensor(box, width, height):
    x0, y0, x1, y1 = box
    return torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )


def build_ours():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model.cuda().eval()


def ours_mask(model, image, box):
    with torch.no_grad():
        output = model(image.cuda(), input_boxes=box.cuda())
    return output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5


def overlay(rgb, mask, color, alpha=0.5):
    image = rgb.copy()
    layer = np.zeros_like(image)
    layer[mask] = color
    image[mask] = (image[mask] * (1 - alpha) + layer[mask] * alpha).astype(np.uint8)
    return image


def pairwise(a, b):
    inter = (a & b).sum()
    union = (a | b).sum()
    return float(inter / union) if union else 1.0


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True).cuda().eval()
    model = build_ours()
    readout_state = torch.load(READOUT, map_location="cpu", weights_only=True)["state"]
    lora_state = torch.load(LORA, map_location="cpu", weights_only=True)["lora"]
    model.load_state_dict(readout_state, strict=False)
    rows = []
    panels = []
    per_image = OUT / "per-image"
    per_image.mkdir(exist_ok=True)
    for name, box in PROMPTS.items():
        rgb_image = Image.open(REAL / f"{name}.jpg").convert("RGB")
        width, height = rgb_image.size
        image = image_tensor(REAL / f"{name}.jpg")
        box = box_tensor(box, width, height)
        with torch.no_grad():
            stock = base(pixel_values=image.cuda(), input_boxes=box.cuda())
        scores = stock["iou_scores"][0, 0]
        stock_mask = stock["pred_masks"][0, 0, int(scores.argmax())].sigmoid().cpu().numpy() > 0.5
        readout_mask = ours_mask(model, image, box)
        model.load_state_dict(lora_state, strict=False)
        lora_mask = ours_mask(model, image, box)
        model.load_state_dict(readout_state, strict=False)
        rgb = np.asarray(rgb_image.resize((SIZE, SIZE), Image.BILINEAR)).copy()
        stock_mask = np.asarray(Image.fromarray(stock_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127
        readout_mask = np.asarray(Image.fromarray(readout_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127
        lora_mask = np.asarray(Image.fromarray(lora_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127
        row = {
            "image": name,
            "prompt_box_native": [int(v) for v in box[0, 0].tolist()],
            "stock_readout_iou": pairwise(stock_mask, readout_mask),
            "stock_lora_iou": pairwise(stock_mask, lora_mask),
            "readout_lora_iou": pairwise(readout_mask, lora_mask),
            "stock_area": float(stock_mask.mean()),
            "readout_area": float(readout_mask.mean()),
            "lora_area": float(lora_mask.mean()),
            "note": "no GT mask; these are pairwise agreements, not accuracy",
        }
        rows.append(row)
        labels = ["RGB", "stock SAM", "readout", "LoRA", "LoRA overlay"]
        images = [
            rgb,
            overlay(rgb, stock_mask, [0, 220, 120]),
            overlay(rgb, readout_mask, [0, 140, 255]),
            overlay(rgb, lora_mask, [255, 120, 0]),
            overlay(rgb, lora_mask, [255, 120, 0], 0.35),
        ]
        tile = Image.new("RGB", (SIZE * 5, SIZE + 36), "white")
        draw = ImageDraw.Draw(tile)
        for i, (label, img) in enumerate(zip(labels, images, strict=True)):
            tile.paste(Image.fromarray(img), (i * SIZE, 36))
            draw.text((i * SIZE + 8, 10), label, fill="black")
        draw.text((8, SIZE + 8), f"{name}  stock/readout={row['stock_readout_iou']:.3f}  stock/LoRA={row['stock_lora_iou']:.3f}  readout/LoRA={row['readout_lora_iou']:.3f}", fill="black")
        panels.append(tile)
        tile.save(per_image / f"{name}.jpg", quality=95)
    sheet = Image.new("RGB", (SIZE * 5, (SIZE + 36) * len(panels)), "white")
    for i, panel in enumerate(panels):
        sheet.paste(panel, (0, i * (SIZE + 36)))
    sheet.save(OUT / "real-readout-vs-lora-sheet.jpg", quality=92)
    (OUT / "metrics.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()

