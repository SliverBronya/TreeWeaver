"""Freeze the final 60-target qualification cohort and split."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(r"D:\TreeWeaver\reports\data-qualification-2026-11-09")
OUT = ROOT / "frozen"
MANIFEST = ROOT / "cohort_manifest_final_v3.json"
AUDIT = ROOT / "qualification.json"
DESIRED = {"clear": 32, "contact": 12, "overlap": 16}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    train = manifest["records"]
    val = [r for r in audit["records"]["v6"] if r["split"] == "validation"]
    test = [r for r in audit["records"]["v6"] if r["split"] == "test"]
    counts = Counter(r["relation"] for r in train)
    assert counts == Counter(DESIRED), (counts, DESIRED)
    assert len(train) == 60
    assert len(val) == 25 and len(test) == 25

    def keys(rows):
        return {r["group"] for r in rows}, {r["asset"] for r in rows}

    tg, ta = keys(train)
    vg, va = keys(val)
    sg, sa = keys(test)
    overlaps = {
        "group_train_val": len(tg & vg),
        "group_train_test": len(tg & sg),
        "group_val_test": len(vg & sg),
        "asset_train_val": len(ta & va),
        "asset_train_test": len(ta & sa),
        "asset_val_test": len(va & sa),
    }
    assert all(value == 0 for value in overlaps.values()), overlaps

    split = {
        "schema_version": "treeweaver-frozen-qualification-1.0",
        "manifest": "cohort_manifest_final_v3.json",
        "train": train,
        "validation": val,
        "test": test,
        "counts": {
            "train": len(train),
            "validation": len(val),
            "test": len(test),
            "relations": dict(counts),
        },
        "hidden": {
            "positive": sum(r["hidden_fraction"] > 0 for r in train),
            "ge_1pct": sum(r["hidden_fraction"] >= 0.01 for r in train),
            "max": max(r["hidden_fraction"] for r in train),
        },
        "isolation": overlaps,
        "training_allowed": False,
        "reason_training_blocked": (
            "stability/control audits not yet accepted; no ownership/amodal training"
        ),
        "test_accessed": False,
    }
    (OUT / "splits.json").write_text(json.dumps(split, indent=2), encoding="utf-8")

    hashes = {}
    for path in (
        MANIFEST,
        ROOT / "split_audit_final_v3.json",
        ROOT / "supplement_controls_audit.json",
        ROOT / "hidden_v3_controls_audit.json",
        ROOT / "hidden_v3_target_audit.json",
        OUT / "splits.json",
    ):
        hashes[path.name] = sha(path)
    freeze = {
        "schema_version": "treeweaver-frozen-cohort-1.0",
        "frozen_at": "2026-11-09",
        "status": "frozen_qualification_only",
        "manifest": str(MANIFEST),
        "split": str(OUT / "splits.json"),
        "counts": split["counts"],
        "hidden": split["hidden"],
        "isolation": overlaps,
        "hashes": hashes,
    }
    (OUT / "freeze.json").write_text(json.dumps(freeze, indent=2), encoding="utf-8")
    (OUT / "FROZEN").write_text(
        "Frozen qualification cohort. Training not allowed until stability/control acceptance.\n",
        encoding="utf-8",
    )
    print(json.dumps(freeze, indent=2))


if __name__ == "__main__":
    main()

