"""Cross-dataset check: does the strip window transfer from CanaTree to TreeStereo?

Everything here was selected on CanaTree (real winter forest, dense trunks). The
TreeStereo trunk reference is a different camera, season and framing (near trees,
one annotated trunk per frame, no neighbour labels), so it is a genuine
out-of-dataset check for the window recipe.

Conditions mirror step 3/4: full frame, strip crop, strip crop plus a base point.
An optional checkpoint trained on CanaTree is evaluated alongside stock SAM2.
No weights are updated here.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from evaluate_treestereo_visible import decode_reference, reference_box  # noqa: E402
from probe_crop_refine import run_full, run_strip  # noqa: E402
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from stem_eval_common import mask_row, mean_of, write_json  # noqa: E402

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
TRUNKS = ROOT / "data/external/tree-stereo-biophysical-v4/extracted/trunks"
CONDITIONS = ("full", "strip", "strip+pos")


def records():
    rows = []
    for mask_path in sorted(TRUNKS.glob("*_LEFT_mask.jpg")):
        image_path = mask_path.with_name(mask_path.name.replace("_mask.jpg", ".jpg"))
        rows.append(
            {"tree_id": mask_path.name.split("_")[0], "image": image_path, "mask": mask_path}
        )
    return rows


def base_point(mask, box):
    x0, y0, x1, y1 = box
    band_start = max(0, int(round(y1 - max(2.0, 0.1 * (y1 - y0)))))
    band = mask[band_start : int(round(y1)), int(round(x0)) : int(round(x1))]
    ys, xs = np.nonzero(band)
    if len(xs):
        return np.asarray([xs.mean() + x0, ys.mean() + y0], np.float32)
    ys, xs = np.nonzero(mask)
    return np.asarray([xs.mean(), ys.mean()], np.float32)


def evaluate(model, processor, device, condition, x_margin, y_margin):
    rows = []
    for record in records():
        image_bgr = cv2.imread(str(record["image"]))
        mask = decode_reference(cv2.imread(str(record["mask"])))
        if image_bgr is None or image_bgr.shape[:2] != mask.shape:
            raise ValueError(f"bad pair {record['image']}")
        height, width = mask.shape
        box = np.asarray(reference_box(mask), np.float32)
        point = base_point(mask, box)
        if condition == "full":
            pixels = processor(
                images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)),
                return_tensors="pt",
            )["pixel_values"].to(device)
            predicted = run_full(model, pixels, box[None], height, width)[0]
        else:
            predicted = run_strip(
                model,
                processor,
                image_bgr,
                box,
                point if condition == "strip+pos" else None,
                device,
                x_margin,
                y_margin,
            )
        rows.append(
            {
                "tree_id": record["tree_id"],
                "condition": condition,
                "metrics": mask_row(record["tree_id"], predicted, mask),
            }
        )
    return rows


def block(rows):
    metrics = [row["metrics"] for row in rows]
    return {
        "trees": len(rows),
        "mean_iou": mean_of(metrics, "iou"),
        "mean_boundary_f1": mean_of(metrics, "boundary_f1"),
        "mean_recall": mean_of(metrics, "recall"),
        "mean_precision": mean_of(metrics, "precision"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, default=None)
    parser.add_argument("--x-margin", type=float, default=5.0)
    parser.add_argument("--y-margin", type=float, default=0.05)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    protocol = {
        "schema_version": "treeweaver-window-transfer-1.0",
        "purpose": "out-of-dataset check of the CanaTree-selected strip window",
        "conditions": list(CONDITIONS),
        "crop": {"x_margin": args.x_margin, "y_margin": args.y_margin},
        "dataset": {
            "root": str(TRUNKS),
            "reference": "dataset-supplied filled visible trunk silhouettes (max(BGR)>127)",
            "trees": len(records()),
            "note": "one LEFT view per tree; no neighbour labels, so no neighbour metric",
        },
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "checkpoint": str(args.checkpoint) if args.checkpoint else None,
            "checkpoint_sha256": sha256_file(args.checkpoint) if args.checkpoint else None,
        },
        "frozen": "no weight update; same GT-derived 5% padded box in every condition",
        "limitations": [
            "TreeStereo is near-view and single-tree per frame, so the resolution "
            "argument is weaker here",
            "no neighbour truth, so adhesion cannot be measured on this dataset",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    models = {"stock_sam2": sam2}
    if args.checkpoint is not None:
        tuned = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
        payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
        tuned.mask_decoder.load_state_dict(payload["decoder"])
        models["canatree_strip_tuned"] = tuned

    summary = {
        "conditions": list(CONDITIONS),
        "results": {},
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
    }
    for model_name, model in models.items():
        for condition in CONDITIONS:
            rows = evaluate(model, processor, args.device, condition, args.x_margin, args.y_margin)
            summary["results"].setdefault(model_name, {})[condition] = block(rows)
            print(
                json.dumps(
                    {
                        "model": model_name,
                        "condition": condition,
                        **summary["results"][model_name][condition],
                    }
                ),
                flush=True,
            )
            write_json(
                args.output / f"per_tree_{model_name}_{condition.replace('+', '_')}.json", rows
            )
        write_json(args.output / "summary.json", summary)
    write_json(args.output / "summary.json", summary)
    print("DONE", json.dumps(summary["results"]))


if __name__ == "__main__":
    main()
