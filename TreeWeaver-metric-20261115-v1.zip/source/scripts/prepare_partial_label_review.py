"""Make auditable assistant drafts/LabelMe files; never mark drafts reviewed."""

import argparse
import hashlib
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--drafts", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a fresh output directory")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    import cv2
    import numpy as np

    from treeweaver.datasets.partial_labels import (
        content_fingerprint,
        sparse_instance_map,
        validate_group_split,
    )

    config = json.loads(args.drafts.read_text(encoding="utf-8"))
    queue = list(config["drafts"])
    for group in config["queue"]:
        queue.extend(
            {
                "image": filename,
                "role": group["role"],
                "conditions": [],
                "instances": [],
                "unknown_regions": [],
                "queued": True,
            }
            for filename in group["images"]
        )
    args.output.mkdir(parents=True)
    documents, rows, thumbnails = [], [], []
    for item in queue:
        path = args.source / item["image"]
        original = cv2.imread(str(path))
        if original is None:
            raise ValueError(f"Missing RGB image: {path}")
        h, w = original.shape[:2]
        document = {
            "schema_version": "partial-tree-rgb.v1",
            "source_group": int(path.stem) // 1000,
            "role": item["role"],
            "coverage": "partial_positive_only",
            "provenance": "unannotated_queue" if item.get("queued") else config["provenance"],
            "image": {
                "path": str(path.resolve()),
                "width": w,
                "height": h,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            },
            "conditions": item["conditions"],
            "known_nonstem_regions": config.get("nonstem_drafts", {}).get(item["image"], []),
            "instances": [],
            "unknown_regions": item["unknown_regions"],
            "known_background_regions": []
            if item.get("queued")
            else [[[920, 20], [1040, 20], [1040, 90], [920, 90]]],
            "identity_scope": "within_image_only; cross-view identities not established",
            "review": {"state": "draft", "reviewer": None, "content_sha256": None},
            "depth_references": {
                kind: str(args.source / f"{path.stem}_{kind}.txt")
                for kind in ("depthdata", "rawdepthdata", "confidencedata")
                if (args.source / f"{path.stem}_{kind}.txt").is_file()
            },
            "depth_alignment_verified": False,
        }
        for instance in item["instances"]:
            document["instances"].append(
                {**instance, "certain_branch_regions": [], "certain_crown_regions": []}
            )
        labels = sparse_instance_map(document, preview_only=True)
        shapes = []
        for instance in document["instances"]:
            identity = instance["local_id"]
            for point in instance["visible_stem_points"]:
                shapes.append(
                    {
                        "label": "visible_stem_point",
                        "points": [point],
                        "group_id": identity,
                        "shape_type": "point",
                        "flags": {},
                    }
                )
            for polygon in instance["visible_stem_positive_regions"]:
                shapes.append(
                    {
                        "label": "visible_stem_positive",
                        "points": polygon,
                        "group_id": identity,
                        "shape_type": "polygon",
                        "flags": {},
                    }
                )
        for key in ("unknown_regions", "known_background_regions", "known_nonstem_regions"):
            for polygon in document[key]:
                shapes.append(
                    {
                        "label": {
                            "unknown_regions": "unknown",
                            "known_background_regions": "background",
                            "known_nonstem_regions": "nonstem",
                        }[key],
                        "points": polygon,
                        "group_id": None,
                        "shape_type": "polygon",
                        "flags": {},
                    }
                )
        labelme = {
            "version": "6.3.1",
            "flags": {"assistant_draft": True},
            "shapes": shapes,
            "imagePath": str(path.resolve()),
            "imageData": None,
            "imageHeight": h,
            "imageWidth": w,
            "treeweaver_review_state": "draft",
        }
        destination = args.output / f"{path.stem}.partial.json"
        destination.write_text(json.dumps(document, indent=2), encoding="utf-8")
        if not item.get("queued"):
            (args.output / f"{path.stem}.labelme.json").write_text(
                json.dumps(labelme, indent=2), encoding="utf-8"
            )
            overlay = original.copy()
            colors = ([255, 100, 0], [0, 180, 255], [100, 220, 70])
            for i, instance in enumerate(document["instances"]):
                region = labels == instance["local_id"]
                overlay[region] = (0.5 * overlay[region] + 0.5 * np.array(colors[i])).astype(
                    np.uint8
                )
                for x, y in instance["visible_stem_points"]:
                    cv2.circle(overlay, (round(x), round(y)), 14, colors[i], 3)
                    cv2.putText(
                        overlay,
                        str(instance["local_id"]),
                        (round(x) + 18, round(y)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        colors[i],
                        2,
                    )
            for polygon in document["unknown_regions"]:
                cv2.polylines(
                    overlay, [np.round(polygon).astype(np.int32)], True, (160, 160, 160), 3
                )
            for polygon in document["known_nonstem_regions"] + document["known_background_regions"]:
                cv2.polylines(overlay, [np.round(polygon).astype(np.int32)], True, (40, 180, 40), 3)
            cv2.putText(
                overlay,
                "ASSISTANT DRAFT - NOT VERIFIED GT",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (0, 0, 255),
                2,
            )
            preview_path = args.output / f"{path.stem}_review.png"
            cv2.imwrite(str(preview_path), overlay)
            thumbnail = cv2.resize(overlay, (270, 480))
            cv2.putText(
                thumbnail, path.name, (8, 473), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2
            )
            thumbnails.append(thumbnail)
        documents.append(document)
        rows.append(
            {
                "image": str(path),
                "source_group": document["source_group"],
                "role": document["role"],
                "annotation": str(destination),
                "state": "queued" if item.get("queued") else "assistant_draft",
                "content_sha256": content_fingerprint(document),
                "reviewed_training_eligible": False,
                "evaluation_truth_eligible": False,
            }
        )
    validate_group_split(documents)
    if thumbnails:
        cv2.imwrite(
            str(args.output / "review_contact_sheet.png"),
            np.vstack([np.hstack(thumbnails[:4]), np.hstack(thumbnails[4:8])]),
        )
    manifest = {
        "frames": rows,
        "reviewed_count": 0,
        "frame_count": len(rows),
        "warning": config["warning"],
        "unknown_pixel_default": -1,
        "protected_test_scope": "Disjoint from the recorded local pilot training IDs",
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "frames": len(rows),
                "drafts": len(thumbnails),
                "reviewed": 0,
                "directory": str(args.output),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
