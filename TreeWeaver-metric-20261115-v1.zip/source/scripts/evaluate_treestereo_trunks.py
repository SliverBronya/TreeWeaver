"""Evaluate existing decoder candidates against all 90 supplied trunk references.

This is a dataset-supplied visible-reference diagnostic with GT-derived boxes,
not an autonomous detector, anatomical crown benchmark or an amodal benchmark.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from compare_synthetic_checkpoints import MODELS, REVISION, scores  # noqa: E402
from evaluate_treestereo_visible import decode_reference, digest, reference_box  # noqa: E402
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    source = ROOT / "data/external/tree-stereo-biophysical-v4/extracted/trunks"
    records = []
    for mask in sorted(source.glob("*_LEFT_mask.jpg")):
        image = mask.with_name(mask.name.replace("_mask.jpg", ".jpg"))
        records.append(
            {
                "id": mask.name.split("_")[0],
                "image": str(image),
                "mask": str(mask),
                "image_sha256": digest(image),
                "mask_sha256": digest(mask),
            }
        )
    if len(records) != 90:
        raise ValueError("expected all 90 paired trunk references")
    args.output.mkdir(parents=True)
    selected_models = [
        model for model in MODELS if model[0] in {"sam2", "five_hour", "real_visible_200"}
    ]
    protocol = {
        "profile": "dataset_supplied_visible_trunk_reference",
        "evaluation_role": "development diagnostic; not a registered blind test",
        "source_url": "https://data.mendeley.com/datasets/nx3ggv7pxf/4",
        "records": records,
        "sam_revision": REVISION,
        "seed": 1729,
        "prompt": "same GT-derived 5%-padded box, multimask_output=False",
        "mask_decode": "JPEG max(BGR)>127; no morphological edits",
        "metric_resolution": "original image; boundary tolerance 2 pixels",
        "models": [],
        "reference_count": len(records),
        "limitations": [
            "filled visible silhouette reference",
            "GT-derived target selection",
            "near-view trunks are not distant whole-tree stems",
            "not proof of scene-disjointness or amodal correctness",
        ],
    }
    # Freeze records/hashes before inference. All attempts remain in the denominator.
    (args.output / "selection.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    source_copy = args.output / "source"
    source_copy.mkdir()
    for file in (
        Path(__file__),
        ROOT / "workers/tree_models/sam2_occlusion.py",
        ROOT / "scripts/compare_synthetic_checkpoints.py",
    ):
        (source_copy / file.name).write_bytes(file.read_bytes())
    torch.manual_seed(1729)
    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    rows = []
    for name, relative, kind in selected_models:
        sam = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
        model = Sam2OcclusionModel(sam, knots=12, experts=3) if kind == "custom" else sam
        missing = []
        if relative:
            checkpoint = ROOT / "reports" / relative
            payload = torch.load(checkpoint, map_location=args.device, weights_only=True)
            if kind == "custom":
                result = model.decoder.load_state_dict(payload["decoder"], strict=False)
                missing = list(result.missing_keys)
                if result.unexpected_keys or any(
                    not key.startswith(("stem_token.", "stem_hypernet.")) for key in missing
                ):
                    raise ValueError(f"incompatible checkpoint: {result}")
            else:
                model.mask_decoder.load_state_dict(payload["sam2_mask_decoder"], strict=True)
            protocol["models"].append(
                {
                    "name": name,
                    "checkpoint": str(checkpoint),
                    "sha256": digest(checkpoint),
                    "unused_heads": missing,
                }
            )
        model.to(args.device).eval()
        folder = args.output / name
        folder.mkdir()
        for record in records:
            target = decode_reference(cv2.imread(record["mask"]))
            try:
                image = cv2.imread(record["image"])
                h, w = target.shape
                pixels = processor(
                    images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)),
                    return_tensors="pt",
                )["pixel_values"].to(args.device)
                box = torch.tensor(reference_box(target), device=args.device) * torch.tensor(
                    [1024 / w, 1024 / h, 1024 / w, 1024 / h], device=args.device
                )
                with torch.inference_mode():
                    output = model(
                        pixel_values=pixels, input_boxes=box[None, None], multimask_output=False
                    )
                    logits = output["masks"] if kind == "custom" else output.pred_masks
                    prediction = (
                        processor.post_process_masks(logits, original_sizes=[list(target.shape)])[
                            0
                        ][0, 0]
                        .cpu()
                        .numpy()
                        > 0
                    )
                cv2.imwrite(str(folder / f"{record['id']}.png"), prediction.astype(np.uint8) * 255)
                rows.append(
                    {
                        "model": name,
                        "id": record["id"],
                        "failed": False,
                        **scores(prediction, target),
                    }
                )
            except Exception as error:
                rows.append(
                    {
                        "model": name,
                        "id": record["id"],
                        "failed": True,
                        "error": repr(error),
                        "iou": 0.0,
                        "recall": 0.0,
                        "precision": 0.0,
                        "boundary_f1": 0.0,
                        "miss_rate": 1.0,
                    }
                )
        del model, sam
        torch.cuda.empty_cache()
        print(f"completed {name}: {len(records)} trunks", flush=True)
    summary = {}
    for name, _, _ in selected_models:
        selected = [row for row in rows if row["model"] == name]
        summary[name] = {
            key: float(np.mean([r[key] for r in selected]))
            for key in ("iou", "recall", "precision", "boundary_f1", "miss_rate")
        }
        summary[name]["failed"] = sum(row["failed"] for row in selected)
        summary[name]["attempts"] = len(selected)
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    (args.output / "per_tree.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    render(args.output, records, rows)
    print(json.dumps(summary, indent=2), flush=True)


def render(output, records, rows):
    custom = [row for row in rows if row["model"] == "five_hour"]
    worst = min(custom, key=lambda row: row["iou"])["id"]
    selected = [records[0], next(r for r in records if r["id"] == worst)]
    width, height = 384, 216
    names = ["RGB", "GT trunk", "sam2", "five_hour", "real_visible_200"]
    sheet = Image.new("RGB", (width * len(names), 2 * (height + 65)), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 16)
    for y, record in enumerate(selected):
        image = cv2.cvtColor(cv2.imread(record["image"]), cv2.COLOR_BGR2RGB)
        for x, name in enumerate(names):
            rgb = cv2.resize(image, (width, height))
            label = name
            if x:
                path = record["mask"] if x == 1 else output / name / f"{record['id']}.png"
                mask = (
                    decode_reference(cv2.imread(str(path)))
                    if x == 1
                    else cv2.imread(str(path), cv2.IMREAD_GRAYSCALE) > 0
                )
                keep = (
                    cv2.resize(
                        mask.astype(np.uint8), (width, height), interpolation=cv2.INTER_NEAREST
                    )
                    > 0
                )
                rgb[keep] = (0.55 * rgb[keep] + 0.45 * np.array([40, 180, 240])).astype(np.uint8)
                if x > 1:
                    row = next(r for r in rows if r["id"] == record["id"] and r["model"] == name)
                    label += f" IoU {row['iou']:.3f} recall {row['recall']:.3f}"
            draw.text((x * width + 5, y * (height + 65) + 5), label, fill="black", font=font)
            sheet.paste(Image.fromarray(rgb), (x * width, y * (height + 65) + 30))
        reason = "first fixed reference" if y == 0 else "lowest five_hour trunk IoU among all 90"
        draw.text(
            (5, y * (height + 65) + height + 35),
            f"{record['id']} | {reason}",
            fill="black",
            font=font,
        )
    sheet.save(output / "trunk-comparison.jpg", quality=94)


if __name__ == "__main__":
    main()
