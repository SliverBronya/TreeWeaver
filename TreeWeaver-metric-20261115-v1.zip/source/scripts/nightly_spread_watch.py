"""Night watcher for the SPREAD download: verify -> extract -> audit -> ready.

State machine (all state under reports/nightly-spread-2026-10-13/):

    WAITING  -> downloads incomplete or files still growing
    VERIFYING-> detached worker running py7zr integrity tests
    EXTRACTING-> detached worker extracting verified archives
    AUDITING -> detached worker auditing extracted layout
    READY    -> extraction/audit complete; the training stage may start
    TRAINING -> training pilot launched (marker set by the agent)
    DONE     -> finished
    CORRUPT  -> integrity test failed on a stable archive; needs the user
    ERROR    -> a stage failed unexpectedly; see logs

The watcher never starts a download and never deletes archives. It is safe to
run repeatedly; every stage is idempotent behind marker files.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("D:/TreeWeaver")
SPREAD_DIR = ROOT / "SPREAD"
EXTRACT_ROOT = ROOT / "data" / "external" / "spread"
STATE_DIR = ROOT / "reports" / "nightly-spread-2026-10-13"
STATE_FILE = STATE_DIR / "state.json"
LOG_DIR = STATE_DIR / "logs"
WORKER_PY = ROOT / ".worker-envs" / "sam2-shared" / "Scripts" / "python.exe"
WATCHER = ROOT / "scripts" / "nightly_spread_watch.py"

EXPECTED = ("birch_forest", "broadleaf_forest", "city_park")
STABLE_SECONDS = 15 * 60
TICK_LOCK_SECONDS = 30 * 60


def now() -> float:
    return time.time()


def load_state() -> dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    return {
        "stage": "WAITING",
        "updated": now(),
        "probes": {},
        "verified": {},
        "archives": {},
        "notes": [],
    }


def save_state(state: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    state["updated"] = now()
    tmp = STATE_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(STATE_FILE)


def note(state: dict, text: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {text}"
    state.setdefault("notes", []).append(line)
    print(line, flush=True)


def find_archives() -> dict[str, Path]:
    """Map expected scene stem to its best available archive path."""

    found: dict[str, Path] = {}
    if not SPREAD_DIR.is_dir():
        return found
    for stem in EXPECTED:
        finished = SPREAD_DIR / f"{stem}.7z"
        partial = SPREAD_DIR / f"{stem}.7z.part"
        if finished.is_file():
            found[stem] = finished
        elif partial.is_file():
            found[stem] = partial
    return found


def probe() -> dict:
    archives = find_archives()
    result = {
        "time": now(),
        "all_three_present": len(archives) == 3,
        "part_extensions_present": [
            p.name for p in SPREAD_DIR.glob("*.part")
        ] if SPREAD_DIR.is_dir() else [],
        "files": {
            stem: {
                "path": str(path),
                "bytes": path.stat().st_size,
                "mtime": path.stat().st_mtime,
                "extension": path.suffix,
            }
            for stem, path in sorted(archives.items())
        },
    }
    return result


def stable_and_testable(state: dict, current: dict) -> tuple[bool, list[str]]:
    """Return (ready_to_test, reasons). Files must be present, non-trivial, and
    either renamed to .7z or byte-stable for STABLE_SECONDS."""

    ready: list[str] = []
    reasons: list[str] = []
    probes = state.setdefault("probes", {})
    for stem, info in current["files"].items():
        size = info["bytes"]
        if size < 100_000_000:
            reasons.append(f"{stem}: only {size} bytes")
            continue
        prior = probes.get(stem)
        if info["extension"] == ".7z":
            ready.append(stem)
            continue
        if prior and prior["bytes"] == size and now() - prior["time"] >= STABLE_SECONDS:
            ready.append(stem)
        else:
            reasons.append(
                f"{stem}: still a .part"
                + (f", stable {int(now() - prior['time'])}s < {STABLE_SECONDS}s"
                   if prior and prior["bytes"] == size else ", size changing")
            )
        probes[stem] = {"bytes": size, "time": now()}
    return (len(ready) == 3 and current["all_three_present"], ready or reasons)


def launch_worker(stage: str, state: dict) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log = open(LOG_DIR / f"{stage}.log", "ab", buffering=0)
    flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    proc = subprocess.Popen(
        [
            str(WORKER_PY), str(WATCHER), "--worker", stage,
            "--launch-time", str(now()),
        ],
        cwd=str(ROOT),
        stdout=log,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        creationflags=flags,
        close_fds=True,
    )
    state["stage"] = {"verify": "VERIFYING", "extract": "EXTRACTING",
                      "audit": "AUDITING"}[stage]
    state["worker"] = {"stage": stage, "pid": proc.pid,
                       "started": now(), "log": str(log.name)}
    note(state, f"launched detached {stage} worker pid={proc.pid}")


def tick_locked(stage: str) -> bool:
    """True if a worker for this stage appears to still be running."""

    state = load_state()
    worker = state.get("worker")
    if not worker or worker["stage"] != stage:
        return False
    pid = worker["pid"]
    try:
        proc = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True, text=True, timeout=30,
        )
        if str(pid) in proc.stdout:
            return True
    except Exception:
        pass
    return False


def cmd_tick() -> None:
    state = load_state()
    stage = state["stage"]
    if stage in ("VERIFYING", "EXTRACTING", "AUDITING"):
        expected = {"VERIFYING": "verify", "EXTRACTING": "extract",
                    "AUDITING": "audit"}[stage]
        if tick_locked(expected):
            print(json.dumps({"state": stage, "status": "worker_running"}))
            return
        marker = STATE_DIR / f"{expected}.done"
        if marker.exists():
            advance = {"VERIFYING": "EXTRACTING", "EXTRACTING": "AUDITING",
                       "AUDITING": "READY"}
            state["stage"] = advance[stage]
            state.pop("worker", None)
            note(state, f"{stage} worker finished -> {state['stage']}")
            save_state(state)
            print(json.dumps({"state": state["stage"], "status": "stage_finished"}))
            return
        state["stage"] = "ERROR"
        note(state, f"{stage} worker exited without completion marker")
        save_state(state)
        print(json.dumps({"state": "ERROR", "status": "worker_missing_marker"}))
        return

    if stage in ("DONE", "CORRUPT", "READY", "TRAINING", "ERROR"):
        print(json.dumps({"state": stage, "status": "awaiting_agent_or_user"}))
        return

    # WAITING
    current = probe()
    state["archives"] = current
    ready, detail = stable_and_testable(state, current)
    save_state(state)
    if not ready:
        print(json.dumps({"state": "WAITING", "detail": detail,
                          "probe": current["files"]}, ensure_ascii=False))
        return
    launch_worker("verify", state)
    save_state(state)
    print(json.dumps({"state": "VERIFYING", "status": "launched"}))


def worker_verify(launch_time: float) -> None:
    import py7zr

    state = load_state()
    note(state, "verify worker: integrity testing each archive")
    archives = find_archives()
    verified = state.setdefault("verified", {})
    for stem in EXPECTED:
        path = archives.get(stem)
        if path is None:
            note(state, f"verify worker: {stem} missing, aborting")
            return
        if verified.get(stem, {}).get("ok"):
            continue
        note(state, f"verify worker: testing {path.name} ({path.stat().st_size} bytes)")
        try:
            with py7zr.SevenZipFile(path, mode="r") as archive:
                ok = archive.test()
                names = archive.getnames()
            if ok is False:
                raise RuntimeError("py7zr test() returned False")
            verified[stem] = {
                "ok": True,
                "path": str(path),
                "bytes": path.stat().st_size,
                "entry_count": len(names),
                "sample_entries": names[:25],
            }
            state["stage"] = "VERIFYING"
            save_state(state)
            note(state, f"verify worker: {stem} OK, {len(names)} entries")
        except Exception as exc:
            # If the file is still being written it can legitimately fail once;
            # only a stable, renamed .7z that fails is a hard corruption gate.
            if path.suffix == ".7z":
                state["stage"] = "CORRUPT"
                verified[stem] = {"ok": False, "error": str(exc)}
                save_state(state)
                note(state, f"verify worker: CORRUPT {stem}: {exc}")
                return
            verified[stem] = {"ok": False, "error": str(exc)}
            state["stage"] = "WAITING"
            state["probes"] = {}
            save_state(state)
            note(state, f"verify worker: {stem} failed while still .part; back to WAITING")
            return
    state["stage"] = "VERIFYING"
    save_state(state)
    (STATE_DIR / "verify.done").write_text(json.dumps(verified, indent=2), encoding="utf-8")
    note(state, "verify worker: all archives verified")
    launch_worker("extract", state)
    save_state(state)


def worker_extract(launch_time: float) -> None:
    import py7zr

    state = load_state()
    note(state, "extract worker: extracting archives")
    EXTRACT_ROOT.mkdir(parents=True, exist_ok=True)
    archives = find_archives()
    manifest = state.setdefault("extracted", {})
    for stem in EXPECTED:
        target = EXTRACT_ROOT / stem
        done_marker = STATE_DIR / f"extract-{stem}.done"
        if done_marker.exists():
            continue
        path = archives.get(stem)
        if path is None:
            state["stage"] = "ERROR"
            note(state, f"extract worker: {stem} archive missing")
            save_state(state)
            return
        note(state, f"extract worker: {path.name} -> {target}")
        tmp_target = EXTRACT_ROOT / f"{stem}.partial"
        with py7zr.SevenZipFile(path, mode="r") as archive:
            archive.extractall(path=tmp_target)
        if target.exists():
            state["stage"] = "ERROR"
            note(state, f"extract worker: refusing to overwrite {target}")
            save_state(state)
            return
        tmp_target.rename(target)
        file_count = sum(1 for p in target.rglob("*") if p.is_file())
        manifest[stem] = {"path": str(target), "file_count": file_count}
        done_marker.write_text(json.dumps(manifest[stem]), encoding="utf-8")
        save_state(state)
        note(state, f"extract worker: {stem} extracted, {file_count} files")
    (STATE_DIR / "extract.done").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    note(state, "extract worker: complete")
    launch_worker("audit", state)
    save_state(state)


def worker_audit(launch_time: float) -> None:
    import cv2  # provided by the worker environment

    state = load_state()
    note(state, "audit worker: scanning extracted layout")
    report = {"scenes": {}}
    for stem in EXPECTED:
        root = EXTRACT_ROOT / stem
        if not root.is_dir():
            state["stage"] = "ERROR"
            note(state, f"audit worker: missing {root}")
            save_state(state)
            return
        all_files = [p for p in root.rglob("*") if p.is_file()]
        exts: dict[str, int] = {}
        for p in all_files:
            exts[p.suffix.lower()] = exts.get(p.suffix.lower(), 0) + 1
        rgb = [p for p in all_files if p.suffix.lower() in (".png", ".jpg", ".jpeg")
               and "rgb" in p.parts]
        inst = [p for p in all_files if "instance_segmentation" in p.parts
                and p.suffix.lower() == ".png"]
        mappings = [p for p in all_files if p.name.endswith(".txt")
                    and "instance_segmentation" in p.parts]
        sample_image = None
        if rgb:
            img = cv2.imread(str(rgb[0]))
            sample_image = {"path": str(rgb[0]),
                            "shape": list(img.shape) if img is not None else None}
        sample_mapping = None
        if mappings:
            sample_mapping = {
                "path": str(mappings[0]),
                "content": mappings[0].read_text(encoding="utf-8", errors="replace")[:2000],
            }
        sample_inst = None
        if inst:
            m = cv2.imread(str(inst[0]), cv2.IMREAD_UNCHANGED)
            sample_inst = {"path": str(inst[0]),
                           "shape": list(m.shape) if m is not None else None,
                           "unique_values": None if m is None else
                           sorted({int(v) for v in m.flatten().tolist()})[:30]}
        report["scenes"][stem] = {
            "root": str(root),
            "extensions": exts,
            "rgb_image_count": len(rgb),
            "instance_png_count": len(inst),
            "instance_mapping_txt_count": len(mappings),
            "sample_image": sample_image,
            "sample_instance_png": sample_inst,
            "sample_mapping_txt": sample_mapping,
            "top_level": sorted(p.name for p in root.iterdir())[:50],
        }
    report["extract_root"] = str(EXTRACT_ROOT)
    out = STATE_DIR / "audit.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    (STATE_DIR / "audit.done").write_text("ok", encoding="utf-8")
    state["stage"] = "READY"
    state["audit_report"] = str(out)
    state.pop("worker", None)
    note(state, "audit worker: READY; audit.json written")
    save_state(state)


def cmd_status() -> None:
    state = load_state()
    print(json.dumps(state, indent=2, ensure_ascii=False))


def cmd_mark(kind: str, message: str) -> None:
    state = load_state()
    if kind == "training":
        state["stage"] = "TRAINING"
        state["training_started"] = now()
    elif kind == "done":
        state["stage"] = "DONE"
        state["training_finished"] = now()
    elif kind == "failed":
        state["stage"] = "ERROR"
    state["training_note"] = message
    note(state, f"manual mark {kind}: {message}")
    save_state(state)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", choices=["verify", "extract", "audit"])
    parser.add_argument("--launch-time", type=float, default=0.0)
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--mark", choices=["training", "done", "failed"])
    parser.add_argument("--message", default="")
    args = parser.parse_args()
    if args.status:
        cmd_status()
    elif args.mark:
        cmd_mark(args.mark, args.message)
    elif args.worker == "verify":
        worker_verify(args.launch_time)
    elif args.worker == "extract":
        worker_extract(args.launch_time)
    elif args.worker == "audit":
        worker_audit(args.launch_time)
    else:
        cmd_tick()


if __name__ == "__main__":
    main()
