"""One hand-composited three-tree example for visual inspection.

Three SynthTree instances are cut out and pasted side by side onto a synthetic
sky/ground background: the two outer trees stand in front of the central one, so
the central tree is occluded from both sides. Ground truth (amodal/visible masks,
ownership, overlap) is recorded by construction.

This is a demonstration of manual compositing, not a natural-forest dataset.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from synthtree_instances import load_instance_rows  # noqa: E402

WIDTH, HEIGHT = 1600, 900
HORIZON = 600
TREES = [
    # image_id, row_index, centre_x, target_height, colour (BGR)
    ("001313", 0, 650, 700, (60, 80, 240)),
    ("000753", 1, 800, 620, (80, 200, 80)),
    ("001455", 3, 950, 700, (240, 160, 60)),
]
FRONT_ORDER = [0, 2, 1]  # outer trees in front of the central one


def background() -> np.ndarray:
    canvas = np.zeros((HEIGHT, WIDTH, 3), np.uint8)
    sky_top = np.array([235, 220, 200], np.float32)
    sky_bottom = np.array([220, 205, 185], np.float32)
    for y in range(HORIZON):
        t = y / max(HORIZON - 1, 1)
        canvas[y, :] = (sky_top * (1 - t) + sky_bottom * t).astype(np.uint8)
    ground_top = np.array([70, 85, 70], np.float32)
    ground_bottom = np.array([45, 55, 45], np.float32)
    for y in range(HORIZON, HEIGHT):
        t = (y - HORIZON) / max(HEIGHT - HORIZON - 1, 1)
        canvas[y, :] = (ground_top * (1 - t) + ground_bottom * t).astype(np.uint8)
    noise = np.random.default_rng(3).normal(0, 4, canvas.shape).astype(np.int16)
    return np.clip(canvas.astype(np.int16) + noise, 0, 255).astype(np.uint8)


def cutout(root: Path, rows, image_id: str, row_index: int):
    image = cv2.imread(str(root / f"{image_id}_img.png"))
    mask_image = cv2.imread(str(root / f"{image_id}_mask.png"))
    if image is None or mask_image is None:
        raise FileNotFoundError(image_id)
    red, green, blue = rows[image_id][row_index]["color"]
    mask = (
        (mask_image[:, :, 2] == red)
        & (mask_image[:, :, 1] == green)
        & (mask_image[:, :, 0] == blue)
    )
    ys, xs = np.nonzero(mask)
    if len(xs) < 100:
        raise ValueError(image_id)
    crop = image[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
    alpha = mask[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
    return crop, alpha


def main() -> int:
    root = ROOT / "data" / "external" / "synthtree43k" / "test_set"
    rows = load_instance_rows(root / "AllLabels.csv")
    canvas = background()
    amodal = []
    layers = []
    for image_id, row_index, centre_x, target_height, colour in TREES:
        patch, alpha = cutout(root, rows, image_id, row_index)
        scale = target_height / patch.shape[0]
        resized = cv2.resize(patch, (max(1, int(round(patch.shape[1] * scale))), target_height))
        alpha_resized = (
            cv2.resize(alpha.astype(np.uint8), (resized.shape[1], resized.shape[0]),
                       interpolation=cv2.INTER_NEAREST) > 0
        )
        x0 = min(max(centre_x - resized.shape[1] // 2, 0), WIDTH - resized.shape[1])
        y0 = HEIGHT - target_height - 20
        shadow = canvas.copy()
        cv2.ellipse(
            shadow,
            (x0 + resized.shape[1] // 2, y0 + target_height - 4),
            (max(20, resized.shape[1] // 2), 14),
            0,
            0,
            360,
            (30, 40, 35),
            -1,
        )
        canvas = cv2.addWeighted(shadow, 0.35, canvas, 0.65, 0)
        mask = np.zeros((HEIGHT, WIDTH), bool)
        mask[y0 : y0 + target_height, x0 : x0 + resized.shape[1]] = alpha_resized
        amodal.append(mask)
        layers.append((x0, y0, resized, alpha_resized, colour))

    # Paste back-to-front: central tree first, then the outer two.
    for index in sorted(range(len(TREES)), key=lambda i: FRONT_ORDER.index(i), reverse=True):
        x0, y0, patch, alpha, _ = layers[index]
        region = canvas[y0 : y0 + patch.shape[0], x0 : x0 + patch.shape[1]]
        region[alpha] = patch[alpha]

    visible = []
    for index, mask in enumerate(amodal):
        blockers = np.zeros_like(mask)
        for other, other_mask in enumerate(amodal):
            if FRONT_ORDER.index(other) < FRONT_ORDER.index(index):
                blockers |= other_mask
        visible.append(mask & ~blockers)

    ownership = np.zeros((HEIGHT, WIDTH), np.uint8)
    for index, mask in enumerate(visible):
        ownership[mask] = index + 1

    overlap_count = np.zeros((HEIGHT, WIDTH), np.uint8)
    for mask in amodal:
        overlap_count += mask.astype(np.uint8)
    overlap = overlap_count >= 2
    front_owner = np.zeros((HEIGHT, WIDTH), np.uint8)
    for index in reversed(FRONT_ORDER):
        front_owner[overlap & amodal[index]] = index + 1

    panels = []
    panels.append(("composited input", canvas.copy()))
    amodal_panel = np.full_like(canvas, 250)
    for index, mask in enumerate(amodal):
        colour = np.array(TREES[index][4], np.float32)
        amodal_panel[mask] = (0.55 * amodal_panel[mask] + 0.45 * colour).astype(np.uint8)
    panels.append(("amodal GT", amodal_panel))
    visible_panel = np.full_like(canvas, 250)
    for index, mask in enumerate(visible):
        colour = np.array(TREES[index][4], np.float32)
        visible_panel[mask] = (0.55 * visible_panel[mask] + 0.45 * colour).astype(np.uint8)
    panels.append(("visible GT", visible_panel))
    ownership_panel = np.zeros_like(canvas)
    for index in range(len(TREES)):
        ownership_panel[ownership == index + 1] = TREES[index][4]
    panels.append(("ownership labels", ownership_panel))
    overlap_panel = np.zeros_like(canvas)
    for index in range(len(TREES)):
        overlap_panel[front_owner == index + 1] = TREES[index][4]
    panels.append(("occlusion zones (front owner)", overlap_panel))
    diagram = np.full_like(canvas, 250)
    for rank, index in enumerate(FRONT_ORDER):
        cv2.putText(
            diagram,
            f"layer {rank + 1} (front): tree {index + 1}",
            (20, 60 + rank * 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (30, 30, 30),
            2,
        )
    panels.append(("layer order", diagram))

    panel_w, panel_h = 500, 281
    gap = 10
    cols, rows_n = 3, 2
    sheet = np.full((56 + rows_n * (panel_h + 28), cols * (panel_w + gap), 3), 245, np.uint8)
    for index, (title, panel) in enumerate(panels):
        row, col = divmod(index, cols)
        x0 = col * (panel_w + gap)
        y0 = 56 + row * (panel_h + 28)
        cv2.putText(sheet, title, (x0 + 6, y0 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (25, 25, 25), 1)
        sheet[y0 : y0 + panel_h, x0 : x0 + panel_w] = cv2.resize(panel, (panel_w, panel_h))
    cv2.putText(
        sheet,
        "manual compositing demo: two outer trees in front of the central tree",
        (10, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (25, 25, 25),
        1,
    )

    output = ROOT / "reports" / "manual-pair-example-2026-10-26"
    output.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output / "example.png"), sheet)
    cv2.imwrite(str(output / "composite.png"), canvas)
    boxes = []
    for mask in amodal:
        ys, xs = np.nonzero(mask)
        boxes.append([int(xs.min()), int(ys.min()), int(xs.max() + 1), int(ys.max() + 1)])
    np.savez_compressed(
        output / "gt.npz",
        amodal=np.stack(amodal),
        visible=np.stack(visible),
        boxes=np.asarray(boxes, np.int32),
        layers=np.asarray([FRONT_ORDER.index(i) + 1 for i in range(len(TREES))], np.int32),
    )
    stats = []
    for index, (image_id, row_index, *_rest) in enumerate(TREES):
        amodal_pixels = int(amodal[index].sum())
        visible_pixels = int(visible[index].sum())
        stats.append(
            {
                "tree": index + 1,
                "image_id": image_id,
                "row_index": row_index,
                "amodal_pixels": amodal_pixels,
                "visible_pixels": visible_pixels,
                "occlusion_rate": 1.0 - visible_pixels / max(amodal_pixels, 1),
                "layer": FRONT_ORDER.index(index) + 1,
            }
        )
    (output / "ground_truth.json").write_text(
        json.dumps({"trees": stats, "overlap_pixels": int(overlap.sum())}, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(stats, indent=2))
    print(f"saved {output / 'example.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
