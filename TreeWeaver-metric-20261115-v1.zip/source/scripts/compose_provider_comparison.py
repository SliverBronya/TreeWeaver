"""Compose a per-image comparison panel: input | SAM2 bundle | ConvexMask overlay.

Diagnostic only: it visualizes two provider outputs and their recorded scores. It
computes no accuracy metric and does not modify either provider's artifacts.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

SAM_PALETTE = [(230, 90, 30), (60, 200, 90), (40, 90, 240), (200, 60, 200), (20, 200, 220)]
CM_PALETTE = [(255, 120, 40), (70, 200, 120), (60, 110, 255), (230, 70, 190), (40, 210, 210)]


def draw_sam(image: np.ndarray, bundle: Path) -> tuple[np.ndarray, list[str]]:
    payload = json.loads(bundle.read_text(encoding="utf-8"))
    view = payload["views"][0]
    overlay = image.copy()
    labels: list[str] = []
    for item in view["instances"]:
        mask = cv2.imread(str(bundle.parent / item["mask_path"]), cv2.IMREAD_GRAYSCALE) > 127
        if not mask.any():
            continue
        color = np.array(SAM_PALETTE[(item["local_instance_id"] - 1) % len(SAM_PALETTE)], np.float32)
        overlay[mask] = (0.55 * overlay[mask] + 0.45 * color).astype(np.uint8)
        contours = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(overlay, contours, -1, tuple(int(v) for v in color), 2)
        trunk_path = item.get("parts", {}).get("trunk")
        if trunk_path:
            trunk = cv2.imread(str(bundle.parent / trunk_path), cv2.IMREAD_GRAYSCALE) > 127
            trunk_contours = cv2.findContours(
                trunk.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )[0]
            cv2.drawContours(overlay, trunk_contours, -1, (0, 255, 255), 1)
        ys, xs = np.nonzero(mask)
        labels.append(f"S{item['local_instance_id']} r={item['reliability']:.2f}")
        cv2.putText(
            overlay,
            labels[-1],
            (int(xs.min()), max(int(ys.min()) - 6, 14)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            overlay,
            labels[-1],
            (int(xs.min()), max(int(ys.min()) - 6, 14)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (0, 0, 0),
            1,
            cv2.LINE_AA,
        )
    return overlay, labels


def header(canvas: np.ndarray, text: str, x: int, y: int) -> None:
    cv2.putText(canvas, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (245, 245, 245), 4, cv2.LINE_AA)
    cv2.putText(canvas, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (25, 25, 25), 1, cv2.LINE_AA)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--sam-bundle", type=Path, required=True)
    parser.add_argument("--convexmask-overlay", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--height", type=int, default=720)
    args = parser.parse_args()

    original = cv2.imread(str(args.image))
    if original is None:
        raise SystemExit(f"cannot read {args.image}")
    sam_overlay, sam_labels = draw_sam(original, args.sam_bundle)
    cm_overlay = cv2.imread(str(args.convexmask_overlay))
    if cm_overlay is None:
        raise SystemExit(f"cannot read {args.convexmask_overlay}")
    cm_run = json.loads((args.convexmask_overlay.parent / "run.json").read_text(encoding="utf-8"))
    cm_entry = next(
        item for item in cm_run["images"] if Path(item["image"]).name == args.image.name
    )
    cm_scores = [item["score"] for item in cm_entry["instances"]]

    panels = [
        ("input", original),
        (f"SAM2 + DINO: {len(sam_labels)} instances", sam_overlay),
        (
            f"ConvexMask: {len(cm_scores)} inst., max {max(cm_scores, default=0):.2f}",
            cm_overlay,
        ),
    ]
    resized = []
    for title, panel in panels:
        h, w = panel.shape[:2]
        width = int(round(w * args.height / h))
        resized.append((title, cv2.resize(panel, (width, args.height))))

    gap = 8
    total_width = sum(panel.shape[1] for _, panel in resized) + gap * (len(resized) - 1)
    canvas = np.full((args.height + 46, total_width, 3), 250, np.uint8)
    x = 0
    for title, panel in resized:
        canvas[46 : 46 + args.height, x : x + panel.shape[1]] = panel
        header(canvas, title, x + 8, 30)
        x += panel.shape[1] + gap
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(args.output), canvas):
        raise SystemExit(f"cannot write {args.output}")
    print(f"{args.output}  ({total_width}x{canvas.shape[0]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
