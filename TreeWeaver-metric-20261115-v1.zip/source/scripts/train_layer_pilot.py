"""Depth-aware layer training on the 100-scene Cycles pilot."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = Path(r"D:\TreeWeaver\reports\stem-depth-100-2026-11-06")
CKPT = ROOT / "reports" / "professional-stage4-coupling-2026-11-06" / "best.pth"
RES, MASK, MASK_W, MASK_H = 1024, 256, 480, 270


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def rgb(path, mean, std):
    image = Image.open(path).convert("RGB").resize((RES, RES), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.asarray(mean)) / np.asarray(std)
    return torch.from_numpy(array).permute(2, 0, 1)


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def resize_mask(mask):
    t = torch.from_numpy(mask.astype(np.float32))[None, None]
    return F.interpolate(t, size=(MASK, MASK), mode="nearest")[0, 0] > 0.5


def load_depth(path):
    image = Image.open(path)
    array = np.asarray(image, dtype=np.float32) / 65535.0
    return torch.from_numpy(array)[None, :, :]


class PilotLayer(Dataset):
    def __init__(self, scenes, mean, std):
        self.scenes = scenes
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.scenes)

    def __getitem__(self, index):
        scene = self.scenes[index]
        meta = json.loads((scene / "meta.json").read_text(encoding="utf-8"))
        count = meta["count"]
        boxes = torch.tensor(meta["boxes_xyxy"], dtype=torch.float32)
        boxes[:, [0, 2]] *= RES / MASK_W
        boxes[:, [1, 3]] *= RES / MASK_H
        boxes[:, [0, 2]] = boxes[:, [0, 2]].clamp(0, RES - 1)
        boxes[:, [1, 3]] = boxes[:, [1, 3]].clamp(0, RES - 1)
        names = meta["trees"]
        order = [names.index(name) for name in meta["layer_order_front_to_back"]]
        rank = {tree: position for position, tree in enumerate(order)}
        amodal = [
            alpha(scene / f"amodal_{i}.png") for i in range(1, count + 1)
        ]
        visible = []
        for i, mask in enumerate(amodal):
            current = mask.copy()
            for front in order:
                if front == i:
                    break
                current &= ~amodal[front]
            visible.append(current)
        layer = torch.zeros((count, count), dtype=torch.float32)
        for i in range(count):
            for j in range(count):
                layer[i, j] = 1.0 if rank[i] < rank[j] else 0.0
        visible = torch.stack([resize_mask(mask) for mask in visible])
        depth = load_depth(scene / "depth_tree_16.png")
        depth = F.interpolate(depth[None], size=(MASK, MASK), mode="bilinear")[0]
        return {
            "image": rgb(scene / "rgb.png", self.mean, self.std),
            "boxes": boxes,
            "layer": layer,
            "visible": visible,
            "depth": depth,
            "scene": scene.name,
        }


def build(device):
    path = snapshot()
    processor = Sam2Processor.from_pretrained(path, local_files_only=True)
    mean = processor.image_processor.image_mean
    std = processor.image_processor.image_std
    sam2 = Sam2Model.from_pretrained(path, local_files_only=True).to(device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(device)
    payload = torch.load(CKPT, map_location="cpu")
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in model.decoder.layer_head.parameters():
        parameter.data.zero_()
    for name, parameter in model.decoder.named_parameters():
        if name.startswith(("layer_evidence", "layer_depth")):
            parameter.requires_grad_(True)
    return model, mean, std


def accuracy(logits, target):
    count = logits.shape[0]
    mask = ~torch.eye(count, dtype=torch.bool)
    return float(((logits > 0) == target.bool())[mask].float().mean())


def evaluate(model, loader, device):
    model.eval()
    values = []
    with torch.no_grad():
        for batch in loader:
            output = model(
                batch["image"].to(device),
                input_boxes=batch["boxes"].to(device),
                depth=batch["depth"].to(device),
            )
            values.append(accuracy(output["layer_logits"][0].cpu(), batch["layer"][0]))
    return float(np.mean(values)) if values else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"exists: {args.output}")
    args.output.mkdir(parents=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, mean, std = build(device)
    scenes = sorted(p for p in DATA.iterdir() if p.is_dir())
    train = scenes[:70]
    val = scenes[70:85]
    test = scenes[85:100]
    train_loader = DataLoader(PilotLayer(train, mean, std), batch_size=1, shuffle=True)
    val_loader = DataLoader(PilotLayer(val, mean, std), batch_size=1)
    test_loader = DataLoader(PilotLayer(test, mean, std), batch_size=1)
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(
        json.dumps(
            {
                "trainable": sum(p.numel() for p in parameters),
                "train": len(train),
                "val": len(val),
                "test": len(test),
            }
        ),
        flush=True,
    )
    optimizer = torch.optim.AdamW(parameters, lr=1e-3, weight_decay=1e-4)
    iterator = iter(train_loader)
    best = -1.0
    for step in range(1, args.steps + 1):
        optimizer.zero_grad(set_to_none=True)
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(train_loader)
            batch = next(iterator)
        output = model(
            batch["image"].to(device),
            input_boxes=batch["boxes"].to(device),
            depth=batch["depth"].to(device),
        )
        target = batch["layer"].to(device)
        count = target.shape[1]
        mask = ~torch.eye(count, dtype=torch.bool, device=device)
        loss = F.binary_cross_entropy_with_logits(
            output["layer_logits"][:, mask],
            target[:, mask],
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        if step % 20 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 25 == 0 or step == args.steps:
            score = evaluate(model, val_loader, device)
            print(json.dumps({"eval_step": step, "layer_accuracy": score}), flush=True)
            if score > best:
                best = score
                torch.save(
                    {"decoder": model.decoder.state_dict(), "step": step, "layer_accuracy": score},
                    args.output / "best.pth",
                )
    test_score = evaluate(model, test_loader, device)
    metrics = {"best_val_layer_accuracy": best, "test_layer_accuracy": test_score}
    (args.output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics), flush=True)


if __name__ == "__main__":
    main()
