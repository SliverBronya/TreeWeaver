"""Experimental geometric fallback + trained multi-query ownership on real RGB.

No ground truth is used. Geometric candidates are not validated anatomical stems;
their colored partitions must not be used as metric tree measurements.
"""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-run", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--images", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a fresh output directory")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from torch.nn import functional as F

    from data import cfg, set_cfg

    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (256, 256)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    from workers.tree_models.auto_stem import AutoStemOwnership
    from workers.tree_models.stem_proxy import lower_mask_proxies

    baseline = ConvexMask().cuda()
    baseline.load_state_dict(
        torch.load(
            args.baseline_run / "pilot_checkpoint.pth", weights_only=True, map_location="cuda"
        ),
        strict=True,
    )
    baseline.train()
    model = AutoStemOwnership().cuda()
    model.load_state_dict(
        torch.load(args.checkpoint, weights_only=True, map_location="cuda"), strict=True
    )
    model.eval()
    transform = FastBaseTransform()
    args.output.mkdir(parents=True)
    results = []
    with torch.inference_mode():
        for index, path in enumerate(args.images):
            original = cv2.imread(str(path))
            if original is None:
                raise ValueError(path)
            square = cv2.resize(original, (256, 256))
            raw = baseline(transform(torch.as_tensor(square).float()[None]))
            features = raw["proto"].permute(0, 3, 1, 2)
            rgb = torch.as_tensor(square).permute(2, 0, 1)[None].float() / 127.5 - 1
            automatic = model(features, rgb=rgb)
            # Keep coarse detection at the512 training resolution. Ownership features
            # remain256 as in this synthetic pilot; the two paths are explicit.
            cfg.max_size = (512, 512)
            high_rgb = cv2.resize(original, (512, 512))
            raw = baseline(transform(torch.as_tensor(high_rgb).float()[None]))
            raw["conf"] = raw["conf"].sigmoid()
            raw["center"] = raw["center"].sigmoid()
            detected = postprocess(baseline.detect(raw, baseline), 512, 512, score_threshold=0.3)
            cfg.max_size = (256, 256)
            coarse = np.zeros((256, 256), bool)
            if detected[0].numel():
                mask = detected[4][int(detected[1].argmax())].bool().cpu().numpy()
                coarse = (
                    cv2.resize(mask.astype(np.uint8), (256, 256), interpolation=cv2.INTER_NEAREST)
                    > 0
                )
            candidates = lower_mask_proxies(coarse)
            points = []
            for candidate in candidates[:4]:
                ys, xs = np.nonzero(candidate)
                points.append([float(xs.mean() / 255), float(ys.mean() / 255)])
            # Conservative experiment uses geometric candidates, not unverified learned peaks.
            output = model(features, points=points, rgb=rgb)
            probability = F.interpolate(
                output["logits"].softmax(1), (256, 256), mode="bilinear", align_corners=False
            )[0]
            labels = probability.argmax(0).cpu().numpy().astype(np.uint8)
            labels[~coarse] = 0
            h, w = original.shape[:2]
            labels = cv2.resize(labels, (w, h), interpolation=cv2.INTER_NEAREST)
            overlay = original.copy()
            colors = ([255, 80, 0], [0, 180, 255], [80, 220, 80], [220, 50, 190])
            for identity, (x, y) in enumerate(points):
                mask = labels == identity + 1
                overlay[mask] = (0.6 * overlay[mask] + 0.4 * np.array(colors[identity])).astype(
                    np.uint8
                )
                cv2.circle(
                    overlay, (round(x * (w - 1)), round(y * (h - 1))), 12, colors[identity], 3
                )
            output_path = args.output / f"{index:03d}_{path.stem}_candidate_overlay.png"
            cv2.imwrite(str(output_path), overlay)
            cv2.imwrite(str(args.output / f"{index:03d}_{path.stem}_candidate_ids.png"), labels)
            results.append(
                {
                    "image": str(path.resolve()),
                    "overlay": str(output_path),
                    "geometric_candidate_count": len(points),
                    "candidate_points_xy": points,
                    "learned_candidate_count": len(automatic["points"]),
                    "assigned_candidate_pixels": [
                        int((labels == i + 1).sum()) for i in range(len(points))
                    ],
                    "partition_incomplete": not points
                    or any(not (labels == i + 1).any() for i in range(len(points))),
                    "anchor_source": "automatic geometric fallback, not validated stems",
                    "instance_assignment_validated": False,
                    "metric_measurement_allowed": False,
                    "ground_truth_used": False,
                }
            )
    report = {
        "mode": "experimental candidate partitions, not final tree instances",
        "depth_used": False,
        "images": results,
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
