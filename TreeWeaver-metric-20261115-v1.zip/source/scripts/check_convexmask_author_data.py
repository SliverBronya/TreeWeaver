"""Bounded original-data training check using upstream mask-to-polygon transform."""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--backbone", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=10)
    parser.add_argument("--data-only", action="store_true")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 100:
        parser.error("Fresh output required, 1..100 diagnostic steps")
    pilot = args.data_root / "pilot"
    split = "val" if args.data_only else "train"
    annotation = pilot / "annotations" / f"{split}_RGB_entire_tree.json"
    if not annotation.exists():
        parser.error("Original-data pilot not prepared yet; no substitute labels accepted")
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import torch

    from data import cfg, set_cfg

    torch.manual_seed(42)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (512, 288)  # Keep original 16:9; reduced resolution diagnostic only.
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    document = json.loads(annotation.read_text())
    cfg.dataset.label_map = {category["id"]: 1 for category in document["categories"]}
    from convexmask import ConvexMask
    from data.coco import COCODetection
    from layers.modules.multibox_loss import MultiBoxLoss
    from utils.augmentations import BaseTransform

    dataset = COCODetection(
        str(pilot / f"{split}_set"), str(annotation), transform=BaseTransform(resize_gt=True)
    )
    if args.data_only:
        import cv2
        import numpy as np

        args.output.mkdir(parents=True)
        rows = []
        for index in range(len(dataset)):
            image, (target, masks, polygons, crowds), image_id = dataset[index]
            if polygons is None or len(target) != len(masks) or len(target) != len(polygons):
                raise ValueError("Mask/target/polygon count mismatch")
            original = dataset.pull_image(index)
            overlay = cv2.resize(original, (512, 288))
            for instance, mask in enumerate(masks):
                color = np.array(
                    [
                        (instance * 73 + 70) % 256,
                        (instance * 43 + 120) % 256,
                        (instance * 91 + 180) % 256,
                    ]
                )
                selected = mask > 0
                overlay[selected] = (0.6 * overlay[selected] + 0.4 * color).astype(np.uint8)
            cv2.imwrite(str(args.output / f"{image_id}_GT_overlay.png"), overlay)
            rows.append(
                {
                    "image_id": image_id,
                    "instances": len(target),
                    "tensor_shape": list(image.shape),
                    "mask_shape": list(masks.shape),
                    "polygon_shape": list(polygons.shape),
                    "crowds": int(crowds),
                }
            )
        report = {
            "mode": "original validation data loading only",
            "rows": rows,
            "gradients_run": False,
            "accuracy_evaluated": False,
            "paper_reproduction_completed": False,
        }
        (args.output / "run.json").write_text(json.dumps(report, indent=2))
        print(json.dumps(report), flush=True)
        return
    model = ConvexMask().cuda().train()
    backbone = torch.load(args.backbone, map_location="cuda", weights_only=True)
    remapped = {}
    for key, value in backbone.items():
        if key.startswith("fc."):
            continue
        if key.startswith("layer"):
            key = "layers." + str(int(key[5]) - 1) + key[6:]
        remapped[key] = value
    model.backbone.load_state_dict(remapped, strict=True)
    criterion = MultiBoxLoss(2, cfg.num_rays, cfg.ohem_negpos_ratio)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    args.output.mkdir(parents=True)
    history = []
    for step in range(args.steps):
        image, (target, masks, polygons, crowds), image_id = dataset[step % len(dataset)]
        if polygons is None or len(target) == 0:
            raise ValueError("Upstream transform failed to produce instance polygons")
        optimizer.zero_grad(set_to_none=True)
        losses = criterion(
            model,
            model(image.float().cuda()[None]),
            [torch.as_tensor(target, dtype=torch.float32, device="cuda")],
            [torch.as_tensor(masks, dtype=torch.float32, device="cuda")],
            [torch.as_tensor(polygons, dtype=torch.float32, device="cuda")],
            [crowds],
        )
        total = sum(losses.values())
        if not torch.isfinite(total):
            raise FloatingPointError("Non-finite loss")
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
        optimizer.step()
        row = {
            "step": step + 1,
            "image_id": image_id,
            "instances": len(target),
            "loss": float(total.detach()),
            "components": {k: float(v.detach()) for k, v in losses.items()},
        }
        history.append(row)
        print(json.dumps(row), flush=True)
    torch.save(model.state_dict(), args.output / "diagnostic_checkpoint.pth")
    (args.output / "run.json").write_text(
        json.dumps(
            {
                "dataset": "SynthTree43k author-linked whole-tree labels",
                "steps": args.steps,
                "training_images": len(dataset),
                "history": history,
                "polygon_generation": "upstream GeneratePolygons via BaseTransform",
                "validation_or_test_used_for_gradients": False,
                "paper_reproduction_completed": False,
                "accuracy_evaluated": False,
                "deviations": [
                    "small subset",
                    "512x288",
                    "AdamW",
                    "no random augmentation",
                    "ImageNet R50 initialization, no author checkpoint",
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
