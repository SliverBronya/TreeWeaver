"""Isolated ConvexMask smoke test or strict trained-checkpoint RGB inference.

Smoke output is engineering evidence only, never a segmentation benchmark.
The author's checkout and existing project environments remain unchanged.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import sys
import time
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--images", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", default="convex_synthtree_prediction_101")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--smoke", action="store_true")
    mode.add_argument("--checkpoint", type=Path)
    parser.add_argument("--score-threshold", type=float, default=0.3)
    parser.add_argument(
        "--size", type=int, help="Square input size matching a local pilot training run"
    )
    args = parser.parse_args()
    if not 0 < args.score_threshold <= 1:
        parser.error("Score threshold must be in (0, 1]")
    if args.size is not None and (args.size < 128 or args.size % 32):
        parser.error("Input size must be at least 128 and divisible by 32")
    source = args.source.resolve()
    if not (source / "convexmask.py").is_file():
        parser.error("Missing official ConvexMask source directory")
    if args.checkpoint and not args.checkpoint.is_file():
        parser.error("Trained checkpoint does not exist; no random-weight fallback is allowed")
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(source))

    import cv2
    import numpy as np
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("Upstream ConvexMask currently requires CUDA")
    # Upstream helpers create tensors without specifying a device.
    # torch.Tensor(...) in legacy upstream does not honor set_default_device.
    # Match its own eval.py CUDA default rather than altering model source.
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    torch.manual_seed(42)
    from data import cfg, set_cfg

    allowed_configs = {
        "convex_synthtree_focal", "convex_synthtree_focal_101",
        "convex_synthtree_prediction", "convex_synthtree_prediction_101",
    }
    if args.config not in allowed_configs:
        parser.error("Select a known tree configuration, not an arbitrary expression")
    set_cfg(args.config)
    if args.size is not None:
        cfg.max_size = (args.size, args.size)
        cfg.fixed_size = True
    cfg.mask_proto_debug = False  # Populated by upstream eval.py rather than config.py.
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    net = ConvexMask().cuda()
    checkpoint_hash = None
    if args.checkpoint:
        # Strict matching avoids upstream load_weights silently skipping mismatched heads.
        checkpoint = torch.load(args.checkpoint, map_location="cuda", weights_only=True)
        state = checkpoint.get("model", checkpoint.get("state_dict", checkpoint))
        net.load_state_dict(state, strict=True)
        with args.checkpoint.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256")
        checkpoint_hash = digest.hexdigest()
    net.eval()
    if args.smoke:
        # Suppress random detections. Test non-empty postprocessing separately below.
        net.detect.conf_thresh = 0.999999
    transform = FastBaseTransform()
    args.output.mkdir(parents=True, exist_ok=True)
    report = {
        "mode": "untrained_engineering_smoke" if args.smoke else "trained_inference",
        "quality_assessment_valid": not args.smoke,
        "accuracy_measured": False,
        "configuration": args.config,
        "max_size": list(cfg.max_size),
        "input_policy": "square_local_pilot" if args.size else "upstream_aspect_preserving",
        "checkpoint_sha256": checkpoint_hash,
        "torch": torch.__version__,
        "python_executable": sys.executable,
        "dependencies": {
            name: importlib.metadata.version(name)
            for name in ("torchvision", "albumentations", "pycocotools", "qudida")
        },
        "gpu": torch.cuda.get_device_name(0),
        "source": str(source),
        "model_source_sha256": hashlib.sha256((source / "convexmask.py").read_bytes()).hexdigest(),
        "images": [],
    }
    palette = [(255, 100, 30), (30, 200, 70), (40, 80, 255), (220, 40, 190)]
    with torch.inference_mode():
        for path in args.images:
            original = cv2.imread(str(path.resolve()))
            if original is None:
                raise ValueError(f"Cannot read RGB image: {path}")
            h, w = original.shape[:2]
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            start = time.perf_counter()
            network_image = original
            if args.size is not None:
                # Local training uses square resizing; match it exactly at inference.
                network_image = cv2.resize(original, (args.size, args.size))
            batch = transform(torch.as_tensor(network_image, device="cuda").float()[None])
            predictions = net(batch)
            result = postprocess(predictions, w, h, score_threshold=args.score_threshold)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
            classes, scores, centers, boxes, masks, polygons = result
            entry = {
                "image": str(path.resolve()), "original_size_wh": [w, h],
                "network_shape": list(batch.shape), "elapsed_seconds": elapsed,
                "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
                "detections": int(classes.numel()),
            }
            if not args.smoke:
                overlay = original.copy()
                detections = []
                for index in range(classes.numel()):
                    mask = masks[index].bool().cpu().numpy()
                    color = np.array(palette[index % len(palette)], dtype=np.float32)
                    overlay[mask] = (0.6 * overlay[mask] + 0.4 * color).astype(np.uint8)
                    mask_path = args.output / f"{path.stem}_instance_{index + 1:03d}.png"
                    if not cv2.imwrite(str(mask_path), mask.astype(np.uint8) * 255):
                        raise OSError(f"Cannot write mask: {mask_path}")
                    detections.append({
                        "instance": index + 1, "class": int(classes[index]),
                        "score": float(scores[index]), "centerness": float(centers[index]),
                        "bbox_xyxy": boxes[index].cpu().tolist(), "mask": str(mask_path),
                    })
                overlay_path = args.output / f"{path.stem}_overlay.png"
                if not cv2.imwrite(str(overlay_path), overlay):
                    raise OSError(f"Cannot write overlay: {overlay_path}")
                entry.update({"overlay": str(overlay_path), "instances": detections})
            report["images"].append(entry)
            print(json.dumps(entry, ensure_ascii=False), flush=True)

        if args.smoke:
            # Known geometric fixture; not a tree detection or a learned-model result.
            rays = cfg.num_rays
            # Two identical polygons plus one separate polygon must yield two instances.
            previous_threshold = net.detect.conf_thresh
            net.detect.conf_thresh = 0.05
            fixture = net.detect({
                "conf": torch.tensor([[[0.01, 0.99], [0.02, 0.98], [0.03, 0.97]]]),
                "center": torch.ones((1, 3, 1)),
                "polygon": torch.full((1, 3, rays), 0.08),
                "mask": torch.full((1, 3, 1), 10.0),
                "points": torch.tensor([[0.5, 0.5], [0.5, 0.5], [0.15, 0.15]]),
                "proto": torch.ones((1, 32, 32, 1)),
            }, net)
            net.detect.conf_thresh = previous_threshold
            fixture_result = postprocess(fixture, 160, 90, score_threshold=0.3)
            fixture_mask = fixture_result[4]
            assert fixture_mask.shape == (2, 90, 160)
            assert 0 < fixture_mask.sum() < 90 * 160
            assert fixture_result[5].shape == (2, rays, 2)
            report["synthetic_postprocess_fixture"] = {
                "passed": True, "mask_shape": list(fixture_mask.shape),
                "foreground_pixels": int(fixture_mask.sum()),
                "meaning": "Checks polygon NMS, crop and mask upsampling, not tree segmentation",
            }
    destination = args.output / "run.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Saved engineering/inference report: {destination}", flush=True)


if __name__ == "__main__":
    main()
