"""Prepare a validation-only LabelMe queue, never model-generated ground truth."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import cv2
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("data/20260411"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--count", type=int, default=30)
    args = parser.parse_args()
    if args.count < 1 or args.output.exists():
        parser.error("Use a positive count and a fresh output directory")
    paths = sorted(args.source.glob("*.jpg"))
    if not paths:
        parser.error("No source JPG images")
    by_name = {p.name: p for p in paths}
    selected = [
        by_name[n]
        for n in ("7001.jpg", "7002.jpg", "10002.jpg", "22003.jpg", "56003.jpg", "57003.jpg")
        if n in by_name
    ]
    seen = {int(p.stem) // 1000 for p in selected if p.stem.isdigit()}
    for path in paths:
        group = int(path.stem) // 1000 if path.stem.isdigit() else path.stem
        if group not in seen:
            selected.append(path)
            seen.add(group)
    selected.extend(p for p in paths if p not in selected)
    selected = selected[: args.count]
    output = args.output.resolve()
    (output / "images").mkdir(parents=True)
    (output / "labelme").mkdir()
    records, tiles = [], []
    for path in selected:
        image = cv2.imread(str(path))
        if image is None:
            raise ValueError(f"Cannot read image {path}")
        height, width = image.shape[:2]
        shutil.copy2(path, output / "images" / path.name)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        label = {
            "version": "5.0.1",
            "flags": {"assistant_draft": True},
            "shapes": [],
            "imagePath": f"../images/{path.name}",
            "imageData": None,
            "imageHeight": height,
            "imageWidth": width,
            "treeweaver_provenance": "unannotated_queue",
            "treeweaver_coverage": "partial",
            "treeweaver_review": {"state": "draft", "reviewer": ""},
            "source_image_sha256": digest,
        }
        (output / "labelme" / f"{path.stem}.json").write_text(
            json.dumps(label, indent=2), encoding="utf-8"
        )
        records.append(
            {
                "image_id": path.stem,
                "image": f"images/{path.name}",
                "image_sha256": digest,
                "split": "validation",
                "prompt_source": "unannotated_queue",
                "instances": [],
                "review": {"status": "unreviewed"},
                "annotation": f"labelme/{path.stem}.json",
                "source_group_hint": str(int(path.stem) // 1000)
                if path.stem.isdigit()
                else path.stem,
            }
        )
        tile = np.full((280, 220, 3), 245, np.uint8)
        scale = min(212 / width, 245 / height)
        thumb = cv2.resize(image, (max(1, round(width * scale)), max(1, round(height * scale))))
        y, x = 4, (220 - thumb.shape[1]) // 2
        tile[y : y + thumb.shape[0], x : x + thumb.shape[1]] = thumb
        cv2.putText(tile, path.name, (6, 270), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (30, 30, 30), 1)
        tiles.append(tile)
    while len(tiles) % 5:
        tiles.append(np.full_like(tiles[0], 245))
    cv2.imwrite(
        str(output / "contact-sheet.jpg"),
        np.vstack([np.hstack(tiles[i : i + 5]) for i in range(0, len(tiles), 5)]),
    )
    manifest = {
        "schema_version": "treeweaver-real-multitree-1.0",
        "records": records,
        "role": "development_validation_only",
        "reviewed_images": 0,
        "notes": (
            "No polygons or GT invented. Filename groups are hints, not verified identities. "
            "No independent test claim."
        ),
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"images": len(records), "reviewed": 0, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
