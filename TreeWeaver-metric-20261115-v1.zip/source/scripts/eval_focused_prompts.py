"""Box / +positive / +negative prompt probe on focused validation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
CKPT = ROOT / "reports/focused-visible-arms-2026-11-10/lora_only/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-prompt-probe-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def m(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def point(mask):
    ys, xs = np.where(mask)
    if not len(xs):
        return None
    k = np.argmin((xs - xs.mean()) ** 2 + (ys - ys.mean()) ** 2)
    return float(xs[k]), float(ys[k])


def prep(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = m(DATA / row["scene"] / "visible_target.png")
    neighbour = m(DATA / row["scene"] / "visible_neighbour.png")
    ys, xs = np.where(visible)
    box = np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32)
    box = lb.boxes(box)
    pos = point(visible)
    neg = point(neighbour)
    def transform(p):
        if p is None:
            return None
        return [p[0] * lb.scale + lb.pad_x, p[1] * lb.scale + lb.pad_y]
    pos, neg = transform(pos), transform(neg)
    return array, box, visible, pos, neg


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    state = torch.load(CKPT, map_location="cpu", weights_only=True)["state"]
    model.load_state_dict(state, strict=False)
    return model.cuda().eval()


def run(model, array, box, pos, neg, condition):
    image = torch.from_numpy(array).permute(2, 0, 1)[None].cuda()
    b = torch.tensor(box, dtype=torch.float32)[None].cuda()
    kwargs = {"input_boxes": b}
    if condition in {"box_pos", "box_pos_neg"} and pos is not None:
        points = [pos]
        labels = [1]
        if condition == "box_pos_neg" and neg is not None:
            points.append(neg)
            labels.append(0)
        kwargs["input_points"] = torch.tensor(points, dtype=torch.float32)[None, None].cuda()
        kwargs["input_labels"] = torch.tensor(labels, dtype=torch.int64)[None, None].cuda()
    with torch.no_grad():
        output = model(image, **kwargs)
    return output["masks"][0, 0, 0].sigmoid().cpu() > 0.5


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = [r for r in json.loads((DATA / "index.json").read_text()) if r["split"] == "validation"]
    model = build()
    results = {}
    for condition in ("box", "box_pos", "box_pos_neg"):
        values = []
        for row in rows:
            array, box, visible, pos, neg = prep(row)
            pred = run(model, array, box, pos, neg, condition)
            target = torch.from_numpy(visible.astype(np.float32))
            target = torch.nn.functional.interpolate(target[None, None], size=(256, 256), mode="nearest")[0, 0] > 0.5
            inter = (pred & target).sum().item()
            union = (pred | target).sum().item()
            values.append(inter / union if union else 1.0)
        results[condition] = {"mean_iou": float(np.mean(values)), "trees": len(values), "values": values}
    (OUT / "summary.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps({k: v["mean_iou"] for k, v in results.items()}, indent=2))


if __name__ == "__main__":
    main()
