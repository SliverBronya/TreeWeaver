"""Paired frame resampling of saved development metrics; no model execution."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import sha256_file  # noqa: E402


def main():
    source = ROOT / "reports/point-budget-synthtree-2026-11-09/results.json"
    data = json.loads(source.read_text(encoding="utf-8"))
    rows = {}
    for row in data["records"]:
        key = row["image"], row["mode"]
        if key in rows:
            raise ValueError("duplicate image/mode metric row")
        rows[key] = row
    images = sorted({key[0] for key in rows})
    draws = np.random.default_rng(20261109).integers(0, len(images), (20000, len(images)))
    query_modes = [f"single_positive/query_order_seed_{seed}" for seed in (108, 109, 110)]
    contrasts = [
        (
            "signed_negatives_vs_single_positive",
            "single_positive/independent",
            ["positive_neighbour_negatives/independent"],
        ),
        (
            "additional_positive_clicks_vs_single_positive",
            "single_positive/independent",
            ["matched_positives/independent"],
        ),
        ("query_order_mean_vs_mask_competition", "single_positive/mask_winner", query_modes),
        (
            "query_order_mean_vs_independent_recall_guard",
            "single_positive/independent",
            query_modes,
        ),
    ]
    metrics = (
        "annotated_foreground_iou",
        "annotation_recall",
        "neighbour_fraction_within_annotated_foreground",
    )
    results = []
    for name, control, candidates in contrasts:
        result = {
            "contrast": name,
            "control": control,
            "candidate_modes": candidates,
            "metrics": {},
        }
        for metric in metrics:
            reference = np.asarray([rows[image, control][metric] for image in images])
            candidate = np.asarray(
                [np.mean([rows[image, mode][metric] for mode in candidates]) for image in images]
            )
            delta = candidate - reference
            bootstrap = delta[draws].mean(-1)
            leave_one_out = (delta.sum() - delta) / (len(delta) - 1)
            result["metrics"][metric] = {
                "control_mean": float(reference.mean()),
                "candidate_mean": float(candidate.mean()),
                "candidate_minus_control_pp": float(100 * delta.mean()),
                "paired_frame_percentile_95_interval_pp": (
                    100 * np.quantile(bootstrap, [0.025, 0.975])
                ).tolist(),
                "leave_one_frame_out_delta_range_pp": [
                    float(100 * leave_one_out.min()),
                    float(100 * leave_one_out.max()),
                ],
                "frames_positive_delta": int((delta > 1e-12).sum()),
                "frames_zero_delta": int((abs(delta) <= 1e-12).sum()),
                "frames_negative_delta": int((delta < -1e-12).sum()),
            }
        results.append(result)
    report = {
        "source_sha256": sha256_file(source),
        "frame_count": len(images),
        "bootstrap_draws": 20000,
        "bootstrap_seed": 20261109,
        "training": False,
        "inference": False,
        "promoted": False,
        "analysis_status": "exploratory paired frame uncertainty, not a confirmatory test",
        "unit": "candidate minus control in percentage points; lower neighbour fraction is better",
        "aggregation": (
            "within-image instance mean, then image mean; average order-seeds per frame first"
        ),
        "not_a_prediction_ensemble": True,
        "limits": [
            "all 50 selected images are author val; this does not evaluate official test",
            "virtual-scene/asset dependence unresolved; frame intervals do not cover it",
            "three order-seeds share initialization; no initialization uncertainty measured",
            "outside annotated foreground ignored; no unlabelled-tree/background FP assessment",
            "given-target GT boxes and points are oracle prompts; not autonomous detection",
            "single/signed reuse K physical scene anchors; matched positives use K*K; boxes fixed",
            "candidate seed-mean performance is not a deployable ensembled predictor",
        ],
        "contrasts": results,
    }
    out = ROOT / "reports/point-budget-synthtree-2026-11-09/paired-frame-uncertainty.json"
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    for result in results:
        print(
            result["contrast"],
            {
                key: round(value["candidate_minus_control_pp"], 4)
                for key, value in result["metrics"].items()
            },
        )


if __name__ == "__main__":
    main()
