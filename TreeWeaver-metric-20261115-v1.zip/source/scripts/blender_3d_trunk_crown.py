"""Render 3D trunk/crown labels on the focused 3D pilot."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from blender_focused_3d import CASES, OUT, fit_camera, ground, look_at, setup  # noqa: E402
from blender_stem_pilot import load  # noqa: E402

ASSETS = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")


def save_mask(path, mask):
    height, width = mask.shape
    image = bpy.data.images.new("mask", width=width, height=height, alpha=True)
    pixels = np.zeros((height, width, 4), np.float32)
    pixels[..., 3] = mask.astype(np.float32)
    image.pixels = pixels.ravel()
    image.filepath_raw = str(path)
    image.file_format = "PNG"
    image.save()
    bpy.data.images.remove(image)


def main():
    for number, names in enumerate(CASES, start=1):
        setup()
        trees, stems = [], []
        for index, name in enumerate(names):
            tree, stem = load(ASSETS / f"{name}.glb", [9.0, 8.0, 7.2][index], trunk_only=True)
            tree.location.y = index * 2.2
            trees.append(tree)
            stems.append(stem)
        ground()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.2
        sun.rotation_euler = (math.radians(45), 0, math.radians(30))
        bpy.ops.object.camera_add(location=(0, -20, 2.5))
        camera = bpy.context.object
        camera.data.lens = 50
        bpy.context.scene.camera = camera
        fit_camera(camera, trees[0])
        trees[1].location.x, trees[2].location.x = 7.5, -7.5
        trees[1].location.y, trees[2].location.y = 4.0, 6.0
        for stem, tree in zip(stems, trees, strict=True):
            stem.location = tree.location
            stem.rotation_euler = tree.rotation_euler
            stem.scale = tree.scale
        scene_dir = OUT / f"{number:06d}"
        scene_dir.mkdir(exist_ok=True)
        scene = bpy.context.scene
        scene.render.filepath = str(scene_dir / "rgb.png")
        bpy.ops.render.render(write_still=True)
        scene.render.film_transparent = True
        scene.render.resolution_x, scene.render.resolution_y = 768, 512
        for obj in scene.objects:
            if obj.type in {"MESH", "CURVE"}:
                obj.hide_render = True
        amodal, stem_masks = [], []
        for index, (tree, stem) in enumerate(zip(trees, stems, strict=True), start=1):
            tree.hide_render = False
            scene.render.filepath = str(scene_dir / f"amodal_{index}.png")
            bpy.ops.render.render(write_still=True)
            tree.hide_render = True
            stem.hide_render = False
            scene.render.filepath = str(scene_dir / f"stem_{index}.png")
            bpy.ops.render.render(write_still=True)
            stem.hide_render = True
        # Load masks.
        for index in range(1, 4):
            for kind in ("amodal", "stem"):
                image = bpy.data.images.load(str(scene_dir / f"{kind}_{index}.png"))
                width, height = image.size
                array = np.array(image.pixels[:], dtype=np.float32).reshape(height, width, 4)
                mask = array[..., 3] > 0.5
                (amodal if kind == "amodal" else stem_masks).append(mask)
                bpy.data.images.remove(image)
        visible, visible_stems = [], []
        for index in range(3):
            current = amodal[index].copy()
            current_stem = stem_masks[index].copy()
            for front in range(index):
                current &= ~amodal[front]
                current_stem &= ~amodal[front]
            visible.append(current)
            visible_stems.append(current_stem)
            save_mask(scene_dir / f"visible_{index + 1}.png", current)
            save_mask(scene_dir / f"visible_stem_{index + 1}.png", current_stem)
            save_mask(scene_dir / f"crown_{index + 1}.png", current & ~current_stem)
            save_mask(scene_dir / f"visible_crown_{index + 1}.png", current & ~current_stem)
        ys, xs = np.where(visible[0])
        meta = {
            "scene": f"{number:06d}",
            "trees": names,
            "target_height_fraction": float((ys.max() - ys.min() + 1) / visible[0].shape[0]),
            "target_center": [float((xs.min() + xs.max()) / 2 / visible[0].shape[1]), float((ys.min() + ys.max()) / 2 / visible[0].shape[0])],
            "overlap_target_neighbour": float((amodal[0] & amodal[1]).sum()) / max(min(amodal[0].sum(), amodal[1].sum()), 1),
            "target_hidden_fraction": float(1 - visible[0].sum() / max(amodal[0].sum(), 1)),
            "trunk_pixels": int(stem_masks[0].sum()),
            "crown_pixels": int((amodal[0] & ~stem_masks[0]).sum()),
        }
        (scene_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("SCENE", number, meta["target_height_fraction"], meta["overlap_target_neighbour"], meta["trunk_pixels"], flush=True)


if __name__ == "__main__":
    main()
