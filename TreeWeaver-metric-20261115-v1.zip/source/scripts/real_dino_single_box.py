"""One Grounding DINO box per real photo -> SAM2 / readout / LoRA."""

from __future__ import annotations

import inspect
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

REAL = ROOT / "data/20260411"
OUT = ROOT / "reports/real-20260411-single-box-2026-11-10"
READOUT = ROOT / "reports/frozen-visible-readout-300-viz-2026-11-09/checkpoint.pth"
LORA = ROOT / "reports/frozen-visible-lora-300-seed20261110-2026-11-09/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
NAMES = ["10001", "10002", "10003"]
PANEL_W, PANEL_H = 480, 853


def snapshot(repo):
    base = Path.home() / ".cache/huggingface/hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def detect(image):
    path = snapshot("IDEA-Research/grounding-dino-tiny")
    processor = AutoProcessor.from_pretrained(path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(path, local_files_only=True)
        .cuda()
        .eval()
    )
    inputs = processor(images=image, text="tree.", return_tensors="pt").to("cuda")
    with torch.no_grad():
        outputs = detector(**inputs)
    kwargs = {
        "threshold"
        if "threshold"
        in inspect.signature(processor.post_process_grounded_object_detection).parameters
        else "box_threshold": 0.28
    }
    result = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        text_threshold=0.22,
        target_sizes=[image.size[::-1]],
        **kwargs,
    )[0]
    boxes = result["boxes"].detach().cpu().numpy()
    scores = result["scores"].detach().cpu().numpy()
    best = int(scores.argmax())
    return boxes[best], float(scores[best])


def tensor(image):
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def native_mask(mask, lb):
    mask = np.asarray(
        Image.fromarray(mask.astype(np.uint8) * 255).resize((1024, 1024), Image.NEAREST)
    ) > 127
    width, height = lb.source_size
    new_w, new_h = round(width * lb.scale), round(height * lb.scale)
    mask = mask[lb.pad_y : lb.pad_y + new_h, lb.pad_x : lb.pad_x + new_w]
    return np.asarray(
        Image.fromarray(mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)
    ) > 127


def overlay(rgb, mask, color, alpha=0.5):
    out = rgb.copy()
    out[mask] = (out[mask] * (1 - alpha) + np.array(color) * alpha).astype(np.uint8)
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    per_image = OUT / "per-image"
    per_image.mkdir(exist_ok=True)
    base = Sam2Model.from_pretrained(
        snapshot("facebook/sam2.1-hiera-tiny"), local_files_only=True
    ).cuda().eval()
    ours = Sam2OcclusionModel(base, encoder_lora_rank=4).cuda().eval()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    ours.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in ours.parameters():
        parameter.requires_grad_(False)
    readout = torch.load(READOUT, map_location="cpu", weights_only=True)["state"]
    lora = torch.load(LORA, map_location="cpu", weights_only=True)["lora"]
    rows = []
    for name in NAMES:
        image = Image.open(REAL / f"{name}.jpg").convert("RGB")
        width, height = image.size
        image_box, score = detect(image)
        lb = letterbox(image)
        box = torch.tensor(lb.boxes(image_box[None])[0], dtype=torch.float32)[None, None].cuda()
        inputs = tensor(lb.image).cuda()
        with torch.no_grad():
            stock = base(pixel_values=inputs, input_boxes=box)
        index = int(stock["iou_scores"][0, 0].argmax())
        stock_mask = native_mask(
            stock["pred_masks"][0, 0, index].sigmoid().cpu().numpy() > 0.5, lb
        )
        ours.load_state_dict(readout, strict=False)
        with torch.no_grad():
            output = ours(inputs, input_boxes=box)
        readout_mask = native_mask(output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5, lb)
        ours.load_state_dict(lora, strict=False)
        with torch.no_grad():
            output = ours(inputs, input_boxes=box)
        lora_mask = native_mask(output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5, lb)
        ours.load_state_dict(readout, strict=False)

        display = np.asarray(image.resize((PANEL_W, PANEL_H), Image.BILINEAR)).copy()
        sx, sy = PANEL_W / width, PANEL_H / height
        x0, y0, x1, y1 = image_box
        box_draw = (x0 * sx, y0 * sy, x1 * sx, y1 * sy)
        def panel(mask, color):
            mask_display = np.asarray(
                Image.fromarray(mask.astype(np.uint8) * 255).resize(
                    (PANEL_W, PANEL_H), Image.NEAREST
                )
            ) > 127
            out = overlay(display, mask_display, color)
            canvas = Image.fromarray(out)
            draw = ImageDraw.Draw(canvas)
            draw.rectangle(box_draw, outline=(255, 220, 0), width=3)
            return np.asarray(canvas)
        panels = [
            ("DINO box", panel(np.zeros((height, width), bool), [0, 0, 0])),
            ("stock SAM", panel(stock_mask, [0, 220, 120])),
            ("readout", panel(readout_mask, [0, 140, 255])),
            ("LoRA", panel(lora_mask, [255, 120, 0])),
        ]
        tile = Image.new("RGB", (PANEL_W * 4, PANEL_H + 34), "white")
        draw = ImageDraw.Draw(tile)
        for i, (label, img) in enumerate(panels):
            tile.paste(Image.fromarray(img), (i * PANEL_W, 34))
            draw.text((i * PANEL_W + 8, 10), label, fill="black")
        draw.text((8, PANEL_H + 8), f"{name} box={[round(float(v),1) for v in image_box]} score={score:.3f}", fill="black")
        tile.save(per_image / f"{name}.jpg", quality=95)
        rows.append(
            {
                "image": name,
                "box": [float(v) for v in image_box],
                "score": score,
                "stock_area": float(stock_mask.mean()),
                "readout_area": float(readout_mask.mean()),
                "lora_area": float(lora_mask.mean()),
                "stock_readout_iou": float((stock_mask & readout_mask).sum() / max((stock_mask | readout_mask).sum(), 1)),
                "stock_lora_iou": float((stock_mask & lora_mask).sum() / max((stock_mask | lora_mask).sum(), 1)),
                "readout_lora_iou": float((readout_mask & lora_mask).sum() / max((readout_mask | lora_mask).sum(), 1)),
            }
        )
    (OUT / "metrics.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
