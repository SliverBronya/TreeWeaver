"""Qualitative ownership check on 20260411: two DINO boxes, one model pass."""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL_W, PANEL_H = 520, 292


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def overlay(image, mask, colour, title):
    panel = image.copy()
    if mask is not None:
        panel[mask] = (0.55 * panel[mask] + 0.45 * np.array(colour, np.float32)).astype(np.uint8)
        contours = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(panel, contours, -1, colour, 2)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    return panel


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--images",
        type=Path,
        nargs="+",
        default=[
            ROOT / "data" / "20260411" / "7001.jpg",
            ROOT / "data" / "20260411" / "7002.jpg",
            ROOT / "data" / "20260411" / "10002.jpg",
        ],
    )
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--encoder-lora-rank", type=int, default=8)
    parser.add_argument("--principal-focus", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(
        sam2,
        knots=12,
        encoder_lora_rank=args.encoder_lora_rank,
        principal_focus=args.principal_focus,
    ).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    if payload.get("adapters"):
        model.load_state_dict(payload["adapters"], strict=False)

    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    parameters = inspect.signature(
        detector_processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"

    rows, report = [], []
    for path in args.images:
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(
            images=image, text="tree.", return_tensors="pt"
        ).to(args.device)
        with torch.no_grad():
            detector_outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            detector_outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **{threshold_keyword: 0.25},
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        if len(boxes) < 2:
            continue
        order = np.argsort(scores)[::-1][:2]
        selected = boxes[order]
        scale = np.array([1024 / width, 1024 / height], np.float32)
        scaled_boxes = torch.as_tensor(
            selected * np.array([*scale, *scale]), device=args.device
        )[None]
        points = np.stack(
            [[0.5 * (box[0] + box[2]), box[1] + 0.88 * (box[3] - box[1])] for box in selected]
        )
        inputs = processor(images=image, return_tensors="pt")
        with torch.no_grad():
            output = model(
                inputs["pixel_values"].to(args.device),
                input_boxes=scaled_boxes,
                input_points=torch.as_tensor(points * scale, device=args.device)[None, :, None, :],
                input_labels=torch.ones((1, 2, 1), dtype=torch.long, device=args.device),
            )
        ownership = output["ownership_logits"][0].argmax(dim=0).cpu().numpy().astype(np.uint8)
        ownership = cv2.resize(ownership, (width, height), interpolation=cv2.INTER_NEAREST)
        A = np.zeros((height, width, 3), np.uint8)
        A[ownership == 1] = (60, 80, 240)
        A[ownership == 2] = (80, 200, 80)
        target = ownership == 1
        neighbour = ownership == 2
        overlap = int((target & neighbour).sum())
        rows.append(
            [
                overlay(image_bgr, None, (0, 0, 0), f"{path.name} two boxes"),
                overlay(image_bgr, target, (60, 80, 240), "target (box A)"),
                overlay(image_bgr, neighbour, (80, 200, 80), "neighbour (box B)"),
                A,
            ]
        )
        report.append(
            {
                "image": path.name,
                "boxes": selected.round(1).tolist(),
                "scores": scores[order].round(3).tolist(),
                "target_pixels": int(target.sum()),
                "neighbour_pixels": int(neighbour.sum()),
                "overlap_pixels": overlap,
            }
        )
        print(json.dumps(report[-1]), flush=True)

    if not rows:
        raise SystemExit("no samples")
    gap = 8
    sheet = np.full((40 + len(rows) * (PANEL_H + 30), 4 * (PANEL_W + gap), 3), 245, np.uint8)
    for column, title in enumerate(["photo + boxes", "target", "neighbour", "ownership"]):
        cv2.putText(
            sheet, title, (column * (PANEL_W + gap) + 8, 26),
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (25, 25, 25), 1,
        )
    for row_index, panels in enumerate(rows):
        y0 = 40 + row_index * (PANEL_H + 30)
        for column, panel in enumerate(panels):
            x0 = column * (PANEL_W + gap)
            sheet[y0 : y0 + PANEL_H, x0 : x0 + PANEL_W] = cv2.resize(
                panel, (PANEL_W, PANEL_H)
            )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(args.output), sheet)
    (args.output.parent / "ownership_real.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
