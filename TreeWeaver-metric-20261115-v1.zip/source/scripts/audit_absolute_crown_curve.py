"""Probe a curve loss with perturbed TRAIN GT masks, never model predictions."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers/tree_models"))
from curve_consistency import absolute_crown_curve_loss  # noqa: E402
from fig_data_protocol import absolute_crown_profile  # noqa: E402


def read_mask(path):
    value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if value is None:
        raise FileNotFoundError(path)
    if value.ndim == 3:
        value = value[..., 3] if value.shape[-1] == 4 else value[..., 0]
    return value > 16


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("reports/fig-paired-v6-framing-30-2026-11-08"),
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("reports/real-occlusion-reference-2026-11-08/curve-contract-audit.json"),
    )
    args = parser.parse_args()
    torch.set_num_threads(2)
    manifest = json.loads((args.data / "paired-samples.json").read_text(encoding="utf-8"))
    results = []
    for row in manifest["records"]:
        if row["split"] != "train" or row["condition"] != "scene":
            continue
        for instance in row["instances"]:
            crown = read_mask(args.data / instance["amodal_crown"])
            valid = ~read_mask(args.data / instance["raster_unknown"])
            valid &= ~read_mask(args.data / instance["amodal_part_unknown"])
            _, xs = np.nonzero(crown & valid)
            if not len(xs):
                raise ValueError("empty known train crown")
            profile = absolute_crown_profile(crown & valid)
            eligible_bands = sum(
                band["observed"] and bool(valid[band["y_px"]].all()) for band in profile["bands"]
            )
            center = (xs.min() + xs.max()) / 2
            height, width = crown.shape
            variants = {"matching_gt": crown}
            for name, scale, translation in (
                ("horizontal_scale_075", 0.75, 0.25 * center),
                ("horizontal_shift_10px", 1.0, 10.0),
            ):
                variants[name] = cv2.warpAffine(
                    crown.astype(np.uint8),
                    np.array([[scale, 0, translation], [0, 1, 0]], np.float32),
                    (width, height),
                    flags=cv2.INTER_NEAREST,
                ).astype(bool)
            losses = {}
            for name, value in variants.items():
                logits = torch.from_numpy(np.where(value, 25.0, -25.0).astype(np.float32))[None]
                losses[name] = float(
                    absolute_crown_curve_loss(
                        logits,
                        torch.from_numpy(crown)[None],
                        valid_pixels=torch.from_numpy(valid)[None],
                    )
                )
            results.append(
                {
                    "record": row["id"],
                    "target": instance["source_tree_index"],
                    "eligible_bands": eligible_bands,
                    "losses": losses,
                }
            )
    if not results:
        raise ValueError("no train scene crowns")
    eligible = [x for x in results if x["eligible_bands"] > 0]
    checks = {
        "has_eligible_train_crowns": bool(eligible),
        "matching_gt_near_zero": all(x["losses"]["matching_gt"] < 1e-8 for x in results),
        "all_eligible_shrunk_crowns_penalized": all(
            x["losses"]["horizontal_scale_075"] > x["losses"]["matching_gt"] + 1e-8
            for x in eligible
        ),
        "all_eligible_shifted_crowns_penalized": all(
            x["losses"]["horizontal_shift_10px"] > x["losses"]["matching_gt"] + 1e-8
            for x in eligible
        ),
        "unobserved_crowns_have_zero_loss": all(
            all(value == 0 for value in x["losses"].values())
            for x in results
            if x["eligible_bands"] == 0
        ),
    }
    report = {
        "purpose": "GT perturbation loss contract; NOT segmentation progress",
        "data": args.data.as_posix(),
        "split": "train_only",
        "crowns": len(results),
        "eligible_crowns": len(eligible),
        "skipped_no_reliable_bands": len(results) - len(eligible),
        "native_mask_size": [width, height],
        "checks": checks,
        "records": results,
        "model_inference_or_training": False,
        "test_images_accessed": False,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"crowns": len(results), "checks": checks}))
    if not all(checks.values()):
        raise SystemExit("curve contract failed; do not enable this loss")


if __name__ == "__main__":
    main()
