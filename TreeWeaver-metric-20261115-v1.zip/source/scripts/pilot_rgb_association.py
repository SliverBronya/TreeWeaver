"""Evaluate RGB-only mask matching; filename identities are scoring labels only."""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict
from itertools import combinations
from pathlib import Path

import cv2
import numpy as np

from treeweaver.association.rgb_matching import RgbTreeView, compare_rgb_tree_views


def _tree_label(filename: str) -> str | None:
    match = re.fullmatch(r"(\d+)00(\d+)", Path(filename).stem)
    return match.group(1) if match else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("segmentation_report")
    parser.add_argument("image_directory")
    parser.add_argument("output_json")
    parser.add_argument("--feature-method", choices=("orb", "sift"), default="sift")
    parser.add_argument("--feature-region", choices=("tree", "scene"), default="tree")
    parser.add_argument("--ratio-threshold", type=float, default=0.75)
    parser.add_argument("--minimum-inliers", type=int, default=15)
    args = parser.parse_args()
    source = Path(args.segmentation_report).resolve()
    output = Path(args.output_json).resolve()
    if output.exists():
        raise FileExistsError(output)
    report = json.loads(source.read_text(encoding="utf-8"))
    if report.get("schema_version") != "whole-tree-zero-shot-experiment-1.0":
        raise ValueError("unsupported segmentation report")
    image_directory = Path(args.image_directory).resolve()
    views: list[RgbTreeView] = []
    for item in report["records"]:
        if "failure" in item:
            continue
        filename = str(item["filename"])
        image = cv2.imread(str(image_directory / filename), cv2.IMREAD_COLOR)
        mask = cv2.imread(str(item["mask_path"]), cv2.IMREAD_GRAYSCALE)
        if image is None or mask is None:
            raise FileNotFoundError(filename)
        feature_mask = (
            mask > 0 if args.feature_region == "tree" else np.ones(mask.shape, dtype=bool)
        )
        views.append(RgbTreeView(filename, image, feature_mask))
    rows: list[dict[str, object]] = []
    for left, right in combinations(views, 2):
        evidence = compare_rgb_tree_views(
            left,
            right,
            feature_method=args.feature_method,
            ratio_threshold=args.ratio_threshold,
            minimum_inliers=args.minimum_inliers,
        )
        left_label = _tree_label(left.image_id)
        right_label = _tree_label(right.image_id)
        expected_same = (
            left_label == right_label
            if left_label is not None and right_label is not None
            else None
        )
        row: dict[str, object] = {**asdict(evidence), "filename_expected_same": expected_same}
        rows.append(row)
        print(
            f"{left.image_id} / {right.image_id}: "
            f"{evidence.geometric_inliers} inliers, accepted={evidence.accepted}, "
            f"expected_same={expected_same}",
            flush=True,
        )
    payload = {
        "schema_version": "rgb-mask-association-pilot-1.0",
        "algorithm_uses_filenames_for_matching": False,
        "filename_labels_are_evaluation_only": True,
        "feature_method": args.feature_method,
        "feature_region": args.feature_region,
        "ratio_threshold": args.ratio_threshold,
        "minimum_inliers": args.minimum_inliers,
        "source_report": str(source),
        "pairs": rows,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
