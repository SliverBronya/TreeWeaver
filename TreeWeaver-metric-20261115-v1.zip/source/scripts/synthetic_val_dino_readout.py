"""Synthetic validation, one method: Grounding DINO box -> readout SAM2.

No GT box is used as input. GT visible mask is used only for scoring.
"""

from __future__ import annotations

import inspect
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
READOUT = ROOT / "reports/frozen-visible-readout-300-viz-2026-11-09/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/synthetic-val-dino-readout-2026-11-10"
PANEL = 560


def snapshot(repo):
    base = Path.home() / ".cache/huggingface/hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def tensor(image):
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask_native(path):
    image = np.asarray(Image.open(path).convert("RGBA"))
    return image[..., 3] > 16


def native_from_letterbox(mask, lb):
    mask = np.asarray(
        Image.fromarray(mask.astype(np.uint8) * 255).resize((1024, 1024), Image.NEAREST)
    ) > 127
    width, height = lb.source_size
    new_w, new_h = round(width * lb.scale), round(height * lb.scale)
    mask = mask[lb.pad_y : lb.pad_y + new_h, lb.pad_x : lb.pad_x + new_w]
    return np.asarray(
        Image.fromarray(mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)
    ) > 127


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    per_image = OUT / "per-image"
    per_image.mkdir(exist_ok=True)
    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .cuda()
        .eval()
    )
    base = Sam2Model.from_pretrained(
        snapshot("facebook/sam2.1-hiera-tiny"), local_files_only=True
    ).cuda().eval()
    model = Sam2OcclusionModel(base, encoder_lora_rank=0).cuda().eval()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    model.load_state_dict(torch.load(READOUT, map_location="cpu", weights_only=True)["state"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    rows = []
    for number, row in enumerate(index["validation"]["records"], start=1):
        image = Image.open(row["paths"]["image"]).convert("RGB")
        width, height = image.size
        inputs = processor(images=image, text="tree.", return_tensors="pt").to("cuda")
        with torch.no_grad():
            outputs = detector(**inputs)
        kwargs = {
            "threshold"
            if "threshold"
            in inspect.signature(processor.post_process_grounded_object_detection).parameters
            else "box_threshold": 0.28
        }
        result = processor.post_process_grounded_object_detection(
            outputs,
            inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **kwargs,
        )[0]
        boxes = result["boxes"].detach().cpu().numpy()
        scores = result["scores"].detach().cpu().numpy()
        if len(boxes) == 0:
            rows.append({"scene": row["scene"], "status": "no_tree_box"})
            continue
        best = int(scores.argmax())
        box_native, score = boxes[best], float(scores[best])
        lb = letterbox(image)
        box = torch.tensor(lb.boxes(box_native[None])[0], dtype=torch.float32)[None, None].cuda()
        with torch.no_grad():
            output = model(tensor(lb.image).cuda(), input_boxes=box)
        prediction = native_from_letterbox(
            output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5, lb
        )
        target = mask_native(row["paths"]["visible"])
        target = np.asarray(
            Image.fromarray(target.astype(np.uint8) * 255).resize(
                (width, height), Image.NEAREST
            )
        ) > 127
        intersection = (prediction & target).sum()
        union = (prediction | target).sum()
        iou = float(intersection / union) if union else 1.0
        rgb = np.asarray(image.resize((PANEL, PANEL), Image.BILINEAR)).copy()
        target_small = np.asarray(
            Image.fromarray(target.astype(np.uint8) * 255).resize((PANEL, PANEL), Image.NEAREST)
        ) > 127
        pred_small = np.asarray(
            Image.fromarray(prediction.astype(np.uint8) * 255).resize((PANEL, PANEL), Image.NEAREST)
        ) > 127
        error = (rgb * 0.45).astype(np.uint8)
        error[target_small & pred_small] = [40, 220, 80]
        error[pred_small & ~target_small] = [240, 50, 50]
        error[target_small & ~pred_small] = [50, 110, 255]
        sx, sy = PANEL / width, PANEL / height
        x0, y0, x1, y1 = box_native
        panels = []
        for label, image_panel in (
            ("DINO box", rgb.copy()),
            ("GT visible", rgb.copy()),
            ("readout", rgb.copy()),
            ("error", error),
        ):
            canvas = Image.fromarray(image_panel)
            draw = ImageDraw.Draw(canvas)
            if label == "GT visible":
                out = canvas.copy()
                arr = np.asarray(out).copy()
                arr[target_small] = (arr[target_small] * 0.5 + np.array([0, 220, 120]) * 0.5).astype(np.uint8)
                canvas = Image.fromarray(arr)
            if label == "readout":
                arr = np.asarray(canvas).copy()
                arr[pred_small] = (arr[pred_small] * 0.5 + np.array([0, 140, 255]) * 0.5).astype(np.uint8)
                canvas = Image.fromarray(arr)
            draw = ImageDraw.Draw(canvas)
            draw.rectangle([x0 * sx, y0 * sy, x1 * sx, y1 * sy], outline=(255, 220, 0), width=3)
            draw.text((8, 8), label, fill=(255, 255, 0))
            panels.append(canvas)
        tile = Image.new("RGB", (PANEL * 4, PANEL + 34), "white")
        draw = ImageDraw.Draw(tile)
        for i, panel in enumerate(panels):
            tile.paste(panel, (i * PANEL, 34))
        draw.text((8, 10), f"{row['scene']} {row['relation']} hidden={row['hidden_fraction']:.3f} DINOscore={score:.3f} IoU={iou:.3f}", fill="black")
        tile.save(per_image / f"{number:02d}_{row['scene']}.jpg", quality=94)
        rows.append(
            {
                "scene": row["scene"],
                "status": "ok",
                "relation": row["relation"],
                "hidden": row["hidden_fraction"],
                "dino_score": score,
                "box": [float(v) for v in box_native],
                "iou": iou,
                "prediction_area": float(prediction.mean()),
                "gt_area": float(target.mean()),
            }
        )
        print(number, row["scene"], f"IoU={iou:.3f}", flush=True)
    valid = [r for r in rows if r["status"] == "ok"]
    summary = {
        "validation_targets": len(rows),
        "with_box": len(valid),
        "no_box": len(rows) - len(valid),
        "mean_iou": float(np.mean([r["iou"] for r in valid])) if valid else 0.0,
        "median_iou": float(np.median([r["iou"] for r in valid])) if valid else 0.0,
        "input": "Grounding DINO top-1 box; letterbox; no GT box",
        "gt_used_as_input": False,
        "gt_used_for_scoring": True,
        "rows": rows,
    }
    (OUT / "metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: summary[k] for k in ("validation_targets", "with_box", "no_box", "mean_iou", "median_iou")}, indent=2))


if __name__ == "__main__":
    main()
