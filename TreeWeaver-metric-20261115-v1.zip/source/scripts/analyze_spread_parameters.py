"""Analyse SPREAD per-tree parameter table and semantic label meaning.

Read-only. Light CPU: reads obj_info_final.xlsx and a handful of small PNGs only.
"""

from __future__ import annotations

import collections
import json
import os

import cv2
import numpy as np

BASE = r"D:\TreeWeaver\data\external\spread"
OUT = r"D:\TreeWeaver\reports\spread-labels-2026-10-13"
os.makedirs(OUT, exist_ok=True)

report: dict = {}


def analyse_parameters(scene: str) -> None:
    import openpyxl

    path = os.path.join(BASE, scene, "obj_info_final.xlsx")
    if not os.path.exists(path):
        return
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    hdr = {name: i for i, name in enumerate(rows[0])}

    per_mesh: dict[str, list] = collections.defaultdict(list)
    for r in rows[1:]:
        name = str(r[hdr["ActorName_Unreal"]] or "")
        if not name.startswith("Tree"):
            continue
        per_mesh[str(r[hdr["StaticMesh"]] or "")].append(
            (
                r[hdr["DBH"]],
                r[hdr["Height"]],
                r[hdr["Crown_Diameter"]],
                r[hdr["Scale_X"]],
                r[hdr["Scale_Y"]],
                r[hdr["Scale_Z"]],
            )
        )

    print(f"\n===== {scene}: {sum(len(v) for v in per_mesh.values())} tree actors, {len(per_mesh)} distinct meshes")
    print(f"{'mesh':34s} {'n':>5s} {'#DBH':>5s} {'#Height':>7s} {'#Crown':>6s} {'#Scale':>6s}  example")
    template_constant = 0
    for mesh, items in sorted(per_mesh.items(), key=lambda kv: -len(kv[1]))[:8]:
        dbh = {i[0] for i in items}
        hgt = {i[1] for i in items}
        crw = {i[2] for i in items}
        scl = {(i[3], i[4], i[5]) for i in items}
        if len(dbh) == 1 and len(hgt) == 1:
            template_constant += 1
        ex = items[0]
        print(
            f"{mesh[:34]:34s} {len(items):5d} {len(dbh):5d} {len(hgt):7d} {len(crw):6d} {len(scl):6d}"
            f"  DBH={ex[0]} H={ex[1]} Crown={ex[2]} Scale=({ex[3]},{ex[4]},{ex[5]})"
        )
    print(f"meshes with a single DBH+Height value (template constant): "
          f"{template_constant}/{len(per_mesh)}")

    heights = sorted(
        r[hdr["Height"]] for r in rows[1:]
        if str(r[hdr["ActorName_Unreal"]] or "").startswith("Tree") and isinstance(r[hdr["Height"]], (int, float))
    )
    if heights:
        print(
            "Height raw: min=%.2f p25=%.2f median=%.2f p75=%.2f max=%.2f"
            % (
                heights[0],
                heights[len(heights) // 4],
                heights[len(heights) // 2],
                heights[3 * len(heights) // 4],
                heights[-1],
            )
        )
        print("  if the unit were cm -> metres: median=%.2f m, max=%.2f m"
              % (heights[len(heights) // 2] / 100, heights[-1] / 100))
        print("  if the unit were mm -> metres: median=%.2f m, max=%.2f m"
              % (heights[len(heights) // 2] / 1000, heights[-1] / 1000))

    report.setdefault("parameters", {})[scene] = {
        "tree_actors": sum(len(v) for v in per_mesh.values()),
        "distinct_meshes": len(per_mesh),
        "meshes_with_single_dbh_and_height": template_constant,
        "height_median": heights[len(heights) // 2] if heights else None,
        "height_max": heights[-1] if heights else None,
    }


def analyse_semantic(scene: str, frames: int = 6) -> None:
    inst_dir = os.path.join(BASE, scene, "instance_segmentation")
    sem_dir = os.path.join(BASE, scene, "semantic_segmentation")
    pal_raw = json.load(open(os.path.join(BASE, "color_palette.json"), encoding="utf-8"))
    PAL = {int(k): tuple(reversed([int(x) for x in v])) for k, v in pal_raw["palette"].items()}

    names = sorted(f for f in os.listdir(inst_dir) if f.endswith(".png"))[:frames]
    print(f"\n===== {scene}: semantic vs instance on {len(names)} frames")
    print(f"{'frame':26s} {'sem values (px)':34s} {'sem1/target':>11s} {'sem1/treeU':>10s} {'sem1/terrain':>12s}")
    for n in names:
        stem = n[:-4]
        inst = cv2.imread(os.path.join(inst_dir, n), cv2.IMREAD_UNCHANGED)
        sem = cv2.imread(os.path.join(sem_dir, n), cv2.IMREAD_UNCHANGED)
        if inst is None or sem is None:
            continue
        sv, sc = np.unique(sem, return_counts=True)
        sem_info = ", ".join(f"{int(a)}:{int(b)}" for a, b in zip(sv, sc))

        sem_small = cv2.resize(sem, (inst.shape[1], inst.shape[0]), interpolation=cv2.INTER_NEAREST)
        listed = {}
        t = os.path.join(inst_dir, stem + ".txt")
        if os.path.exists(t):
            for line in open(t, encoding="utf-8"):
                p = line.split()
                if len(p) >= 2:
                    listed[p[0]] = int(p[1])
        target = stem.split("_")[0]

        def mask_of_index(idx: int) -> np.ndarray:
            c = PAL.get(idx)
            if c is None:
                return np.zeros(inst.shape[:2], bool)
            return np.all(inst[:, :, :3] == np.array(c, dtype=np.uint8), axis=2)

        target_mask = mask_of_index(listed.get(target, -1))
        tree_union = np.zeros(inst.shape[:2], bool)
        for idx in listed.values():
            tree_union |= mask_of_index(idx)
        terrain = ~tree_union

        sem1 = sem_small == 1
        def frac(a, b):
            d = b.sum()
            return float((a & b).sum()) / float(d) if d else 0.0

        print(
            f"{stem[:26]:26s} {sem_info[:34]:34s} {frac(sem1, target_mask):11.3f}"
            f" {frac(sem1, tree_union):10.3f} {frac(sem1, terrain):12.3f}"
        )

    report.setdefault("semantic", {})[scene] = {"frames_checked": len(names)}


for scene in ("city_park", "birch_forest", "broadleaf_forest"):
    analyse_parameters(scene)
for scene in ("city_park", "birch_forest"):
    analyse_semantic(scene)

with open(os.path.join(OUT, "labels-report.json"), "w", encoding="utf-8") as fh:
    json.dump(report, fh, indent=2)
print("\nsem1/target = 命中目标树掩膜的比例；sem1/treeU = 命中所有树实例并集的比例；sem1/terrain = 命中非树区域的比例")
