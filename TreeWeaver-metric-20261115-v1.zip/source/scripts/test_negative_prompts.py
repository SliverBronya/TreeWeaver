"""Compare a box prompt with a stem-positive + neighbour-negative point prompt."""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from prompt_api import TreePrompt, stem_point_from_box  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL_W, PANEL_H = 520, 292


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def panel(image, masks, title):
    out = image.copy()
    for mask, colour in masks:
        out[mask] = (0.55 * out[mask] + 0.45 * np.array(colour, np.float32)).astype(np.uint8)
        contours = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(out, contours, -1, colour, 2)
    cv2.putText(out, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(out, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--images",
        type=Path,
        nargs="+",
        default=[
            ROOT / "data" / "20260411" / "7001.jpg",
            ROOT / "data" / "20260411" / "7002.jpg",
            ROOT / "data" / "20260411" / "10002.jpg",
        ],
    )
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    parameters = inspect.signature(
        detector_processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"

    rows, report = [], []
    for path in args.images:
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(
            images=image, text="tree.", return_tensors="pt"
        ).to(args.device)
        with torch.no_grad():
            detector_outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            detector_outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **{threshold_keyword: 0.25},
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        if len(boxes) < 2:
            continue
        order = np.argsort(scores)[::-1]
        target_box = boxes[order[0]]
        neighbour_box = boxes[order[1]]
        positive = stem_point_from_box(target_box, (width, height))
        negative = stem_point_from_box(neighbour_box, (width, height))
        scale = np.array([1024 / width, 1024 / height], np.float32)
        prompt = TreePrompt(
            positive_points=(positive,),
            negative_points=(negative,),
            box=None,
        )
        tensors = prompt.to_tensors(args.device)
        tensors["input_points"][..., 0] *= scale[0]
        tensors["input_points"][..., 1] *= scale[1]
        inputs = processor(images=image, return_tensors="pt")
        box_tensor = torch.as_tensor(
            target_box * np.array([1024 / width, 1024 / height] * 2), device=args.device
        )[None, None]
        with torch.no_grad():
            box_output = model(
                inputs["pixel_values"].to(args.device), input_boxes=box_tensor
            )
            point_output = model(
                inputs["pixel_values"].to(args.device),
                input_boxes=box_tensor,
                input_points=tensors["input_points"],
                input_labels=tensors["input_labels"],
            )
            box_mask = processor.post_process_masks(
                box_output["masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
            point_mask = processor.post_process_masks(
                point_output["masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
        rows.append(
            [
                panel(image_bgr, [(box_mask, (240, 120, 40))], "box only"),
                panel(image_bgr, [(point_mask, (60, 200, 90))], "box + stem/negative point"),
            ]
        )
        report.append(
            {
                "image": path.name,
                "box_area": int(box_mask.sum()),
                "point_area": int(point_mask.sum()),
                "area_ratio": round(float(point_mask.sum()) / max(int(box_mask.sum()), 1), 4),
                "iou": round(iou(point_mask, box_mask), 4),
                "positive": [round(float(v), 2) for v in positive],
                "negative": [round(float(v), 2) for v in negative],
            }
        )
        print(json.dumps(report[-1]), flush=True)

    if not rows:
        raise SystemExit("no samples")
    gap = 8
    sheet = np.full((44 + len(rows) * (PANEL_H + 30), 2 * (PANEL_W + gap), 3), 245, np.uint8)
    for column, title in enumerate(["box prompt", "box + stem/negative point"]):
        cv2.putText(
            sheet, title, (column * (PANEL_W + gap) + 8, 26),
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (25, 25, 25), 1,
        )
    for row_index, panels in enumerate(rows):
        y0 = 44 + row_index * (PANEL_H + 30)
        for column, image in enumerate(panels):
            x0 = column * (PANEL_W + gap)
            sheet[y0 : y0 + PANEL_H, x0 : x0 + PANEL_W] = cv2.resize(
                image, (PANEL_W, PANEL_H)
            )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(args.output), sheet)
    (args.output.parent / "negative_prompt_test.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
