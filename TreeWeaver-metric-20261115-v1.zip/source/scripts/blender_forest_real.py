"""Forest scene with real ground cover, dead wood, boulders and layered fig trees."""

from __future__ import annotations

import math
import random
from pathlib import Path

import bpy
from mathutils import Vector

TREE_ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ASSETS = Path(r"D:\TreeWeaver\tools\assets\polyhaven")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRI = "autumn_field_puresky_2k.hdr"
OUT = Path(r"D:\TreeWeaver\reports\blender-forest-real\sample.png")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 64
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.25


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(v * scale for v in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def load_tree(path, height=TARGET_HEIGHT):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [obj for obj in bpy.data.objects if obj not in before]
    meshes = [
        obj
        for obj in new
        if obj.type == "MESH" and obj.name not in {"Cube", "Camera", "Light"}
    ]
    if not meshes:
        raise RuntimeError(f"no meshes in {path}")
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    normalize(tree, height)
    return tree


def load_library(path, names):
    with bpy.data.libraries.load(str(path), link=False) as (src, dst):
        dst.objects = [name for name in src.objects if names(name)]
    objects = []
    for obj in dst.objects:
        if obj is not None:
            bpy.context.collection.objects.link(obj)
            objects.append(obj)
    return objects


def copy_at(obj, location, scale, rotation, z=0.0):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    copy.location = (location[0], location[1], z)
    copy.rotation_euler = (0, 0, rotation)
    copy.scale = tuple(v * scale for v in obj.scale)
    return copy


def ground():
    bpy.ops.mesh.primitive_plane_add(size=300, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (24, 24, 24)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)


def path():
    return


def world(rng):
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / HDRI))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 6.28))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 0.9
    bpy.context.scene.world = w


def mist():
    bpy.ops.mesh.primitive_cube_add(size=80, location=(0, 18, 10))
    cube = bpy.context.object
    mat = bpy.data.materials.new("mist")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    vol = nodes.new("ShaderNodeVolumeScatter")
    vol.inputs["Density"].default_value = 0.0018
    vol.inputs["Anisotropy"].default_value = 0.3
    links.new(vol.outputs["Volume"], out.inputs["Volume"])
    cube.data.materials.append(mat)


def camera(target, lens=35.0):
    bpy.ops.object.camera_add()
    cam = bpy.context.object
    cam.data.lens = lens
    cam.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = (TARGET_HEIGHT / 0.82) / (2 * math.tan(vfov / 2))
    cam.location = (target.location.x + 0.4, -distance, 1.55)
    look = Vector((target.location.x, 0, TARGET_HEIGHT * 0.50))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.dof.use_dof = True
    cam.data.dof.focus_object = target
    cam.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = cam


def main():
    rng = random.Random(321)
    clean()
    target = load_tree(TREE_ROOT / "realistic_hd_common_fig_tree_3030.glb")
    target.location = (-3.0, 0, 0)
    target.rotation_euler = (0, 0, math.radians(25))

    neighbour = load_tree(TREE_ROOT / "realistic_hd_common_fig_tree_1330.glb", TARGET_HEIGHT * 0.95)
    neighbour.location = (7.5, 3.0, 0)
    neighbour.rotation_euler = (0, 0, math.radians(150))

    left = load_tree(TREE_ROOT / "realistic_hd_common_fig_tree_530.glb", TARGET_HEIGHT * 0.9)
    left.location = (-14.0, 6.0, 0)
    left.rotation_euler = (0, 0, math.radians(60))

    excluded = {
        "realistic_hd_common_fig_tree_3030.glb",
        "realistic_hd_common_fig_tree_1330.glb",
        "realistic_hd_common_fig_tree_530.glb",
    }
    candidates = [p for p in sorted(TREE_ROOT.glob("*.glb")) if p.name not in excluded]
    rng.shuffle(candidates)
    for index, tree_path in enumerate(candidates[:22]):
        if index < 10:
            x, y = rng.uniform(-15, 15), rng.uniform(8, 18)
        else:
            x, y = rng.uniform(-32, 32), rng.uniform(22, 42)
        tree = load_tree(tree_path, TARGET_HEIGHT * rng.uniform(0.75, 1.05))
        tree.location = (x, y, 0)
        tree.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

    ground()
    path()

    fern_templates = load_library(ASSETS / "fern_02" / "fern_02_2k.blend", lambda n: n.startswith("fern_02_"))
    for _ in range(60):
        template = rng.choice(fern_templates)
        copy_at(
            template,
            (rng.uniform(-14, 14), rng.uniform(-4, 18)),
            rng.uniform(0.8, 1.5),
            math.radians(rng.uniform(0, 360)),
        )

    grass_templates = load_library(
        ASSETS / "grass_medium_02" / "grass_medium_02_2k.blend",
        lambda n: n.startswith("grass_medium_02_") and not n.endswith("_geo"),
    )
    for _ in range(80):
        template = rng.choice(grass_templates)
        copy_at(
            template,
            (rng.uniform(-16, 16), rng.uniform(-6, 20)),
            rng.uniform(0.45, 0.9),
            math.radians(rng.uniform(0, 360)),
        )

    moss_templates = load_library(
        ASSETS / "moss_01" / "moss_01_2k.blend",
        lambda n: n.endswith("_LOD0"),
    )
    for _ in range(40):
        template = rng.choice(moss_templates)
        copy_at(
            template,
            (rng.uniform(-12, 12), rng.uniform(-3, 16)),
            rng.uniform(1.0, 2.0),
            math.radians(rng.uniform(0, 360)),
            z=0.02,
        )

    trunks = load_library(
        ASSETS / "dead_tree_trunk" / "dead_tree_trunk_1k.blend",
        lambda n: n == "dead_tree_trunk",
    )
    for x, y, rot in [(-7, 2, 80), (9, 5, 100), (-2, 12, 60)]:
        copy_at(trunks[0], (x, y), 1.1, math.radians(rot), z=0.25)

    boulders = load_library(
        ASSETS / "boulder_01" / "boulder_01_1k.blend",
        lambda n: n == "boulder_01_LOD0",
    )
    for _ in range(8):
        copy_at(
            boulders[0],
            (rng.uniform(-12, 12), rng.uniform(0, 18)),
            rng.uniform(0.5, 1.4),
            math.radians(rng.uniform(0, 360)),
        )

    world(rng)
    mist()
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = 1.7
    sun.data.angle = math.radians(12)
    sun.rotation_euler = (math.radians(48), 0, math.radians(35))
    camera(target, 35.0)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    bpy.context.scene.render.filepath = str(OUT)
    bpy.ops.render.render(write_still=True)
    print(f"saved {OUT}")


if __name__ == "__main__":
    main()

