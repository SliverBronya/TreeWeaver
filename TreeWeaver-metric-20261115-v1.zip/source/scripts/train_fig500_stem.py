"""Train only the new stem-mask token on geometric lower-mask proxies."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2, 3))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + 1.0
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=ROOT / "reports" / "fig-500-v2-2026-10-31")
    parser.add_argument("--checkpoint", type=Path, default=ROOT / "reports" / "fig500-improve-300-2026-11-01" / "decoder_best.pth")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--eval-images", type=int, default=20)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    from fig500_dataset import Fig500Multi
    from sam2_occlusion import Sam2OcclusionModel
    from stem_proxy import lower_mask_proxy

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    train = Fig500Multi(args.data_root, "train", mean=tuple(processor.image_processor.image_mean), std=tuple(processor.image_processor.image_std))
    val = Fig500Multi(args.data_root, "val", mean=tuple(processor.image_processor.image_mean), std=tuple(processor.image_processor.image_std))
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3, enable_stem=True).to(args.device)
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad = False
    for name, parameter in model.decoder.named_parameters():
        if name.startswith("stem_token") or name.startswith("stem_hypernet"):
            parameter.requires_grad = True
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-3, weight_decay=1e-4)

    def targets(sample):
        masks = []
        for mask in sample["visible"]:
            proxy = lower_mask_proxy(mask > 0.5)
            masks.append(torch.as_tensor(proxy).to(args.device).float())
        return torch.stack(masks)[None]

    history = []
    for step in range(1, args.steps + 1):
        sample = train.sample(np.random.randint(len(train)))
        target = targets(sample)
        output = model(
            torch.as_tensor(sample["pixel_values"])[None].to(args.device),
            input_boxes=torch.as_tensor(sample["boxes"])[None].to(args.device),
        )
        logits = output["stem_masks"][:, :, 0]
        loss = F.binary_cross_entropy_with_logits(logits, target, pos_weight=torch.tensor(20.0, device=args.device)) + dice_loss(logits, target).mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step % 20 == 0:
            print(f"step {step}/{args.steps} stem_loss {float(loss.detach()):.4f}", flush=True)
        if step % 50 == 0:
            ious = []
            for index in range(min(args.eval_images, len(val))):
                sample = val.sample(index)
                target = targets(sample)
                with torch.no_grad():
                    output = model(
                        torch.as_tensor(sample["pixel_values"])[None].to(args.device),
                        input_boxes=torch.as_tensor(sample["boxes"])[None].to(args.device),
                    )
                pred = output["stem_masks"][0, :, 0] > 0
                gt = target[0] > 0.5
                for k in range(pred.shape[0]):
                    ious.append(float((pred[k] & gt[k]).sum()) / max(float((pred[k] | gt[k]).sum()), 1.0))
            history.append({"step": step, "stem_iou_proxy": float(np.mean(ious)), "loss": float(loss.detach())})
            print("EVAL", json.dumps(history[-1]), flush=True)
    torch.save({"decoder": model.decoder.state_dict(), "step": args.steps}, args.output / "stem_best.pth")
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    print("DONE", args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
