"""Bounded worker restarts with logs; never starts duplicate workers."""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    import msvcrt

    supervisor_lock = (output / "supervisor.lock").open("a+b")
    supervisor_lock.seek(0)
    if not supervisor_lock.read(1):
        supervisor_lock.write(b"0")
        supervisor_lock.flush()
    supervisor_lock.seek(0)
    msvcrt.locking(supervisor_lock.fileno(), msvcrt.LK_NBLCK, 1)
    (output / "supervisor_pid.json").write_text(
        json.dumps({"pid": os.getpid(), "started": datetime.now(UTC).isoformat()})
    )
    command = [
        sys.executable,
        str(root / "scripts/train_convexmask_synthtree_continuous.py"),
        "--data-root",
        str(root / "data/external/synthtree43k"),
        "--source",
        str(root / "data/external/convexmask-source"),
        "--extra-packages",
        str(root / ".worker-envs/convexmask-extra"),
        "--backbone",
        "C:/Users/Mendel/.cache/torch/hub/checkpoints/resnet50-0676ba61.pth",
        "--output",
        str(output),
        "--epochs",
        "29",
        "--recipe",
        "legacy",
        "--no-amp",
        "--full-validate-every",
        "1",
    ]
    for attempt in range(4):
        with (output / f"worker-{attempt}.log").open("a", encoding="utf-8") as log:
            result = subprocess.run(
                command, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=False
            )
        status = {
            "updated": datetime.now(UTC).isoformat(),
            "attempt": attempt,
            "worker_exit_code": result.returncode,
            "command": command,
        }
        (output / "supervisor.json").write_text(json.dumps(status, indent=2))
        if result.returncode == 0:
            return
        time.sleep(10)
    (output / "NEEDS_ATTENTION.txt").write_text(
        "Worker failed after bounded retries. Inspect logs and status before restarting."
    )


if __name__ == "__main__":
    main()
