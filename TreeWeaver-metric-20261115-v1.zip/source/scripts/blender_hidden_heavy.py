"""Five hidden-heavy overlap targets: target behind neighbour, with pole/background."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from blender_qualification_supplement import (  # noqa: E402
    camera,
    ground,
    load,
    setup_scene,
    world,
)

ASSETS = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
OUT = Path(r"D:\TreeWeaver\reports\hidden-heavy-v3-2026-11-09")
CASES = [
    ("realistic_hd_common_fig_tree_2030", "realistic_hd_common_fig_tree_2830"),
    ("realistic_hd_common_fig_tree_2130", "realistic_hd_common_fig_tree_2930"),
    ("realistic_hd_common_fig_tree_230", "realistic_hd_common_fig_tree_1030"),
    ("realistic_hd_common_fig_tree_2330", "realistic_hd_common_fig_tree_130"),
    ("realistic_hd_common_fig_tree_2530", "realistic_hd_common_fig_tree_1730"),
]


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points), max(p.x for p in points),
        min(p.y for p in points), max(p.y for p in points),
        min(p.z for p in points), max(p.z for p in points),
    )


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for index, (target_name, neighbour_name) in enumerate(CASES, start=1):
        scene = setup_scene()
        target, target_stem = load(ASSETS / f"{target_name}.glb", 9.0)
        neighbour, neighbour_stem = load(ASSETS / f"{neighbour_name}.glb", 9.0)
        # Neighbour is in front; target is behind and partially hidden.
        neighbour.location = (0, 0, 0)
        target.location.y = 1.5
        bpy.context.view_layer.update()
        x0, x1, _, _, _, _ = bbox(target)
        target_width = x1 - x0
        x0, x1, _, _, _, _ = bbox(neighbour)
        neighbour_width = x1 - x0
        neighbour.location.x = 0.52 * (target_width + neighbour_width) / 2
        target_stem.location = target.location
        target_stem.rotation_euler = target.rotation_euler
        target_stem.scale = target.scale
        neighbour_stem.location = neighbour.location
        neighbour_stem.rotation_euler = neighbour.rotation_euler
        neighbour_stem.scale = neighbour.scale
        bpy.context.view_layer.update()

        ground_obj = ground()
        world()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.2
        sun.rotation_euler = (math.radians(50), 0, math.radians(25))

        # A simple support/pole behind the target adds background structure.
        bpy.ops.mesh.primitive_cylinder_add(
            vertices=16,
            radius=0.12,
            depth=2.6,
            location=(target.location.x + 0.45 * target_width, 3.2, 1.3),
        )
        pole = bpy.context.object
        material = bpy.data.materials.new("pole")
        material.use_nodes = True
        material.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (
            0.12, 0.10, 0.08, 1
        )
        pole.data.materials.append(material)

        # A simple back wall/rubble barrier; it must not occlude the target.
        bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 7.0, 1.4))
        wall = bpy.context.object
        wall.scale = (10, 1.8, 2.8)
        wall.rotation_euler = (math.radians(90), 0, 0)
        wall_mat = bpy.data.materials.new("wall")
        wall_mat.use_nodes = True
        wall_mat.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (
            0.28, 0.27, 0.24, 1
        )
        wall.data.materials.append(wall_mat)

        center = (target.location.x + neighbour.location.x) / 2
        span = abs(target.location.x - neighbour.location.x) + target_width + neighbour_width
        camera(center, span)

        scene_dir = OUT / f"{index:06d}"
        scene_dir.mkdir()
        bpy.context.scene.render.filepath = str(scene_dir / "full.png")
        bpy.ops.render.render(write_still=True)

        neighbour.hide_render = True
        neighbour_stem.hide_render = True
        bpy.context.scene.render.filepath = str(scene_dir / "control_target.png")
        bpy.ops.render.render(write_still=True)
        neighbour.hide_render = False
        neighbour_stem.hide_render = True

        scene.render.film_transparent = True
        scene.render.resolution_x, scene.render.resolution_y = 480, 270
        ground_obj.hide_render = True
        pole.hide_render = True
        for name, tree, stem in (
            ("target", target, target_stem),
            ("neighbour", neighbour, neighbour_stem),
        ):
            for other_tree, other_stem in (
                (target, target_stem),
                (neighbour, neighbour_stem),
            ):
                other_tree.hide_render = True
                other_stem.hide_render = True
            tree.hide_render = False
            scene.render.filepath = str(scene_dir / f"amodal_{name}.png")
            bpy.ops.render.render(write_still=True)
            tree.hide_render = True
            stem.hide_render = False
            scene.render.filepath = str(scene_dir / f"stem_{name}.png")
            bpy.ops.render.render(write_still=True)
        for tree, stem in ((target, target_stem), (neighbour, neighbour_stem)):
            tree.hide_render = False
            stem.hide_render = True
        ground_obj.hide_render = False
        pole.hide_render = False
        scene.render.film_transparent = False
        scene.render.resolution_x, scene.render.resolution_y = 960, 540

        meta = {
            "scene_id": index,
            "relation": "overlap",
            "target": target_name,
            "neighbour": neighbour_name,
            "group_id": 400 + index,
            "split": "train",
            "target_occluded": True,
            "support_pole": True,
        }
        (scene_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("SCENE", index, flush=True)


if __name__ == "__main__":
    main()


