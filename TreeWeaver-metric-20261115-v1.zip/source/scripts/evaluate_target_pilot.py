"""Evaluate highest-confidence mask against target-only labels; not forest instance AP."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--inference", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    inference = json.loads(args.inference.read_text(encoding="utf-8"))
    by_image = {item["image"]: item for item in inference["images"]}
    rows = []
    for record in manifest["test"]:
        prediction = by_image[record["image"]]
        annotation = json.loads(Path(record["annotation"]).read_text(encoding="utf-8"))
        shape = (annotation["imageHeight"], annotation["imageWidth"])
        ground_truth = np.zeros(shape, np.uint8)
        for target in annotation["shapes"]:
            if target["label"] == "tree":
                points = np.round(np.asarray(target["points"])).astype(np.int32)
                cv2.fillPoly(ground_truth, [points], 1)
        # Select by score only. Never use GT to choose the best predicted candidate.
        instances = prediction["instances"]
        if instances:
            chosen = max(instances, key=lambda item: item["score"])
            image_mask = cv2.imread(chosen["mask"], cv2.IMREAD_GRAYSCALE)
            if image_mask is None or image_mask.shape != shape:
                raise ValueError("Predicted mask must have original RGB dimensions")
            predicted = image_mask > 0
        else:
            chosen = None
            predicted = np.zeros(shape, bool)
        gt = ground_truth > 0
        intersection = int((predicted & gt).sum())
        union = int((predicted | gt).sum())
        rows.append(
            {
                "image": record["image"],
                "tree_id": record["tree_id"],
                "prediction_count": len(instances),
                "selected_by": "highest confidence, not ground truth",
                "target_iou": intersection / max(union, 1),
                "foreground_precision": intersection / max(int(predicted.sum()), 1),
                "foreground_recall": intersection / max(int(gt.sum()), 1),
                "overlay": prediction["overlay"],
            }
        )
    result = {
        "evaluation": "highest-confidence target-mask comparison",
        "mean_target_iou": float(np.mean([row["target_iou"] for row in rows])),
        "images": rows,
        "limitations": manifest["limitations"],
        "metric_tree_measurement_evaluated": False,
        "exhaustive_multi_instance_accuracy_evaluated": False,
    }
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
