"""Evaluate a stage checkpoint on the held-out 75 test scenes."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from train_stage12 import DATA, FigDataset, build_model, evaluate  # noqa: E402


def main():
    checkpoint = Path(sys.argv[1])
    output = Path(sys.argv[2])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, mean, std = build_model(device, checkpoint)
    ids = sorted(int(p.stem) for p in (DATA / "meta").glob("*.json"))
    test_ids = ids[425:]
    loader = DataLoader(FigDataset(test_ids, mean, std), batch_size=1)
    result = evaluate(model, loader, device, len(test_ids))
    majority = []
    for batch in loader:
        target = batch["ownership"][0]
        counts = np.bincount(target.ravel(), minlength=5)[1:]
        if counts.sum():
            majority.append(float(counts.max() / counts.sum()))
    result["majority_baseline"] = float(np.mean(majority))
    result["test_scenes"] = len(test_ids)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
