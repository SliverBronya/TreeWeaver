"""Paired synthetic development-set audit, including omissions and regressions.

No model selection or training. All models receive identical GT-derived boxes.
The historical Fig500 image split is not an independent unseen-asset test.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from fig500_dataset import Fig500Multi  # noqa: E402
from instance_metrics import boundary_f1  # noqa: E402
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
MODELS = [
    ("sam2", None, "stock"),
    ("stageB", "fig500-stageB-2026-10-31/decoder_best.pth", "custom"),
    ("five_hour", "fig500-long-5h-v2-2026-10-31/best.pth", "custom"),
    ("short_improve", "fig500-improve-300-2026-11-01/decoder_best.pth", "custom"),
    ("real_visible_200", "real-visible-pilot-2026-11-01/run-200/final.pth", "stock"),
]


def scores(pred, gt):
    tp = int((pred & gt).sum())
    fp = int((pred & ~gt).sum())
    fn = int((~pred & gt).sum())
    return {
        "iou": tp / max(tp + fp + fn, 1),
        "precision": tp / max(tp + fp, 1),
        "recall": tp / max(tp + fn, 1),
        "miss_rate": fn / max(tp + fn, 1),
        "area_ratio": int(pred.sum()) / max(int(gt.sum()), 1),
        "boundary_f1": boundary_f1(pred, gt, tolerance=2),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=ROOT / "reports/fig-500-v2-2026-10-31")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists() or args.limit < 1:
        parser.error("positive limit and fresh output directory required")
    args.output.mkdir(parents=True)
    torch.manual_seed(1729)
    np.random.seed(1729)
    source_dir = args.output / "source"
    source_dir.mkdir()
    source_hashes = {}
    for source in (
        Path(__file__),
        ROOT / "workers/tree_models/sam2_occlusion.py",
        ROOT / "workers/tree_models/fig500_dataset.py",
    ):
        content = source.read_bytes()
        (source_dir / source.name).write_bytes(content)
        source_hashes[str(source)] = hashlib.sha256(content).hexdigest()
    dataset = Fig500Multi(args.data_root, "validation")
    items = [dataset.sample(i) for i in range(min(args.limit, len(dataset)))]
    path = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    rows, protocol = [], []
    for name, relative, kind in MODELS:
        sam = Sam2Model.from_pretrained(path, local_files_only=True).to(args.device).eval()
        model = Sam2OcclusionModel(sam, knots=12, experts=3) if kind == "custom" else sam
        checkpoint = ROOT / "reports" / relative if relative else None
        missing = []
        if checkpoint:
            payload = torch.load(checkpoint, map_location=args.device, weights_only=True)
            if kind == "custom":
                loaded = model.decoder.load_state_dict(payload["decoder"], strict=False)
                missing = list(loaded.missing_keys)
                if loaded.unexpected_keys or any(
                    not key.startswith(("stem_token.", "stem_hypernet.")) for key in missing
                ):
                    raise ValueError(f"incompatible checkpoint: {loaded}")
            else:
                model.mask_decoder.load_state_dict(payload["sam2_mask_decoder"], strict=True)
        model.to(args.device).eval()
        protocol.append(
            {
                "model": name,
                "checkpoint": str(checkpoint) if checkpoint else None,
                "sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest()
                if checkpoint
                else None,
                "unused_initialized_heads": missing,
            }
        )
        folder = args.output / name
        folder.mkdir()
        for sample in items:
            with torch.inference_mode():
                result = model(
                    pixel_values=torch.as_tensor(sample["pixel_values"])[None].to(args.device),
                    input_boxes=torch.as_tensor(sample["boxes"])[None].to(args.device),
                    multimask_output=False,
                )
            pred = (
                ((result["masks"] if kind == "custom" else result.pred_masks)[0, :, 0] > 0)
                .cpu()
                .numpy()
            )
            target = sample["visible"] > 0.5
            amodal_gt = sample["amodal"] > 0.5
            masks = {"visible": pred}
            if kind == "custom":
                masks["amodal"] = (result["amodal_masks"][0, :, 0] > 0).cpu().numpy()
                owner = result["ownership_logits"][0].argmax(0).cpu().numpy()
                masks["owner_visible"] = pred & (
                    owner[None] == np.arange(1, len(pred) + 1)[:, None, None]
                )
            np.savez_compressed(folder / f"{sample['image_id']:06d}.npz", **masks)
            for tree, (prediction, truth) in enumerate(zip(pred, target, strict=True)):
                hidden = amodal_gt[tree] & ~truth
                row = {
                    "model": name,
                    "image_id": sample["image_id"],
                    "tree": tree + 1,
                    "occluded_fraction": int(hidden.sum()) / max(int(amodal_gt[tree].sum()), 1),
                    **scores(prediction, truth),
                }
                if kind == "custom":
                    row["amodal_iou"] = scores(masks["amodal"][tree], amodal_gt[tree])["iou"]
                    row["owner_recall"] = scores(masks["owner_visible"][tree], truth)["recall"]
                    if hidden.any():
                        row["hidden_recall"] = float(masks["amodal"][tree][hidden].mean())
                rows.append(row)
        del model, sam, result
        torch.cuda.empty_cache()
        print(f"completed {name}: {len(items)} images", flush=True)
    summary = {}
    keys = (
        "iou",
        "precision",
        "recall",
        "miss_rate",
        "area_ratio",
        "boundary_f1",
        "amodal_iou",
        "owner_recall",
        "hidden_recall",
    )
    for name, _, _ in MODELS:
        selected = [r for r in rows if r["model"] == name]
        summary[name] = {
            key: float(np.mean([r[key] for r in selected if key in r]))
            for key in keys
            if any(key in r for r in selected)
        }
        low = [r for r in selected if r["occluded_fraction"] <= 0.01]
        summary[name]["low_occlusion_count"] = len(low)
        if low:
            summary[name]["low_occlusion_recall"] = float(np.mean([r["recall"] for r in low]))
        summary[name]["trees"] = len(selected)
    protocol = {
        "profile": "historical_synthetic_development_audit_not_independent_test",
        "sam_revision": REVISION,
        "models": protocol,
        "images": [s["image_id"] for s in items],
        "dataset": str(args.data_root.resolve()),
        "split": dataset.split_origin,
        "prompt": "identical GT-visible-derived padded boxes, multimask_output=False",
        "metrics": "macro per prompted tree; 256x256 nearest-neighbor GT; BF1 tolerance 2 pixels",
        "low_occlusion": "GT amodal minus visible area <=1% of amodal area; not no-crown-overlap",
        "limitations": [
            "legacy train/validation share 29 assets",
            "validation reused for selection",
            "no anatomical stem labels",
            "no stem accuracy or real-domain claim",
        ],
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_snapshot_sha256": source_hashes,
        "seed": 1729,
        "legacy_stem_token_enabled": False,
    }
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    (args.output / "per_tree.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    make_sheet(args, items, rows)
    print(json.dumps(summary, indent=2), flush=True)


def make_sheet(args, items, rows):
    # Show the best and worst paired image changes as well as the first fixed image.
    def mean_iou(name, image_id):
        return np.mean([r["iou"] for r in rows if r["model"] == name and r["image_id"] == image_id])

    ranked = sorted(
        items,
        key=lambda s: mean_iou("five_hour", s["image_id"]) - mean_iou("stageB", s["image_id"]),
    )
    selected = [items[0], ranked[-1], ranked[0]]
    labels = [
        "fixed first validation image",
        "largest 5h gain vs Stage B",
        "smallest 5h gain vs Stage B",
    ]
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 16)
    except OSError:
        font = ImageFont.load_default()
    width, height = 384, 216
    names = ["GT visible", "stageB", "five_hour", "short_improve", "real_visible_200"]
    sheet = Image.new("RGB", (width * len(names), (height + 60) * 3 + 38), "white")
    draw = ImageDraw.Draw(sheet)
    colors = np.array([[255, 90, 60], [30, 160, 240], [130, 210, 50], [210, 90, 220]])
    draw.text(
        (8, 6),
        "Historical Fig500 development split: same boxes; reused assets; not an independent test",
        fill="black",
        font=font,
    )
    for row, (sample, reason) in enumerate(zip(selected, labels, strict=True)):
        y = 38 + row * (height + 60)
        image = cv2.cvtColor(
            cv2.imread(str(args.data_root / "images" / f"{sample['image_id']:06d}.png")),
            cv2.COLOR_BGR2RGB,
        )
        for col, name in enumerate(names):
            masks = (
                sample["visible"] > 0.5
                if col == 0
                else np.load(args.output / name / f"{sample['image_id']:06d}.npz")["visible"]
            )
            panel = cv2.resize(image, (width, height))
            for k, mask in enumerate(masks):
                keep = (
                    cv2.resize(
                        mask.astype(np.uint8), (width, height), interpolation=cv2.INTER_NEAREST
                    )
                    > 0
                )
                panel[keep] = (0.55 * panel[keep] + 0.45 * colors[k % 4]).astype(np.uint8)
            label = name if col == 0 else f"{name} IoU {mean_iou(name, sample['image_id']):.3f}"
            draw.text((col * width + 5, y), label, fill="black", font=font)
            sheet.paste(Image.fromarray(panel), (col * width, y + 25))
        draw.text(
            (5, y + height + 30), f"Image {sample['image_id']} | {reason}", fill="black", font=font
        )
    sheet.save(args.output / "visible-comparison.jpg", quality=94)


if __name__ == "__main__":
    main()
