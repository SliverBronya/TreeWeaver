"""Train the occlusion-aware SAM2 decoder on SynthTree43k (scale-free).

Phase 1 trains only the extended mask decoder: modal mask, tree/stem visibility,
containment and routing balance. The amodal weight is zero until the synthetic
occlusion pipeline exists. The image encoder and prompt encoder stay frozen.

No metric scale is involved: targets are masks, boxes and visibility fractions.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
SYNTHTREE_ROOT = ROOT / "data" / "external" / "synthtree43k" / "test_set"
TRAIN_JSON = SYNTHTREE_ROOT.parent / "annotations" / "train_RGB_entire_tree.json"
VAL_JSON = SYNTHTREE_ROOT.parent / "annotations" / "val_RGB_entire_tree.json"
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    revisions = sorted((base / "snapshots").iterdir())
    if not revisions:
        raise FileNotFoundError(f"no cached snapshot for {repo}")
    return revisions[-1]


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum()
    return 1.0 - (2.0 * intersection + 1.0) / (probability.sum() + target.sum() + 1.0)


def build_model(
    sam2_path: Path,
    device: str,
    knots: int,
    encoder_lora_rank: int = 0,
    principal_focus: bool = False,
    enable_stem: bool = False,
):
    from sam2_occlusion import Sam2OcclusionModel

    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(device).eval()
    model = Sam2OcclusionModel(
        sam2,
        knots=knots,
        experts=3,
        encoder_lora_rank=encoder_lora_rank,
        principal_focus=principal_focus,
        enable_stem=enable_stem,
    ).to(device)
    return model


def trainable_groups(model):
    new_prefixes = (
        "amodal_token",
        "visibility_token",
        "curve_token",
        "occluder_token",
        "amodal_hypernets",
        "occluder_hypernet",
        "router",
        "visibility_mean",
        "visibility_log_variance",
        "curve_head",
        "amodal_scale",
        "ownership_projection",
        "ownership_conv",
        "ownership_bg",
        "layer_head",
        "sam2.vision_encoder",
        "prompt_focus",
    )
    new, base = [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if not name.startswith("decoder."):
            new.append(parameter)
            continue
        local_name = name[len("decoder.") :]
        (new if local_name.startswith(new_prefixes) else base).append(parameter)
    return new, base


def evaluate(model, val_dataset, items, device):
    model.eval()
    modal_intersections = []
    modal_unions = []
    amodal_ious = []
    hull_ious = []
    visibility_error = []
    targets = []
    bands = {"0-30": [], "30-60": [], "60-90": []}
    with torch.no_grad():
        for index in range(min(items, len(val_dataset))):
            sample = val_dataset.sample(index, deterministic=True)
            pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
            box = torch.as_tensor(sample["box"])[None, None].to(device)
            output = model(pixel_values, input_boxes=box)
            modal_prediction = output["masks"][:, :, 0] > 0
            modal_target = torch.as_tensor(sample["mask"])[None].to(device) > 0.5
            amodal_prediction = output["amodal_masks"][:, :, 0] > 0
            amodal_target = torch.as_tensor(sample["amodal_mask"])[None].to(device) > 0.5
            modal_intersections.append(float((modal_prediction & modal_target).sum()))
            modal_unions.append(float((modal_prediction | modal_target).sum()))
            amodal_iou = float((amodal_prediction & amodal_target).sum()) / max(
                float((amodal_prediction | amodal_target).sum()), 1.0
            )
            amodal_ious.append(amodal_iou)
            visible_np = modal_target[0, 0].cpu().numpy().astype(np.uint8)
            contours = cv2.findContours(
                visible_np, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )[0]
            hull = np.zeros_like(visible_np)
            if contours:
                cv2.fillPoly(hull, [cv2.convexHull(np.vstack(contours))], 1)
            hull_tensor = torch.as_tensor(hull, device=device)[None, None] > 0
            hull_ious.append(
                float((hull_tensor & amodal_target).sum())
                / max(float((hull_tensor | amodal_target).sum()), 1.0)
            )
            rate = float(sample["occlusion_rate"])
            band = "0-30" if rate < 0.3 else ("30-60" if rate < 0.6 else "60-90")
            bands[band].append(amodal_iou)
            visibility = output["visibility"][0, 0].cpu().numpy()
            target_visibility = np.asarray(sample["visibility"], dtype=np.float64)
            visibility_error.append(float(np.abs(visibility - target_visibility).mean()))
            targets.append(target_visibility)
    modal_iou = float(np.sum(modal_intersections) / max(np.sum(modal_unions), 1.0))
    amodal_iou = float(np.mean(amodal_ious))
    stacked = np.stack(targets)
    median = np.median(stacked, axis=0)
    baseline = float(np.mean(np.abs(stacked - median)))
    band_means = {
        key: (float(np.mean(values)) if values else float("nan"))
        for key, values in bands.items()
    }
    return (
        modal_iou,
        amodal_iou,
        float(np.mean(hull_ious)),
        float(np.mean(visibility_error)),
        baseline,
        band_means,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=SYNTHTREE_ROOT)
    parser.add_argument("--split-json", type=Path, default=TRAIN_JSON)
    parser.add_argument("--val-split-json", type=Path, default=VAL_JSON)
    parser.add_argument("--composite-root", type=Path, default=None)
    parser.add_argument("--val-max-images", type=int, default=200)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--max-images", type=int, default=500)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--knots", type=int, default=12)
    parser.add_argument("--lr-new", type=float, default=3e-4)
    parser.add_argument("--lr-base", type=float, default=1e-5)
    parser.add_argument("--eval-every", type=int, default=10)
    parser.add_argument("--eval-items", type=int, default=10)
    parser.add_argument("--amodal-weight", type=float, default=1.0)
    parser.add_argument("--curve-weight", type=float, default=0.1)
    parser.add_argument("--curve-consistency-weight", type=float, default=0.0)
    parser.add_argument("--encoder-lora-rank", type=int, default=0)
    parser.add_argument("--principal-focus", action="store_true")
    parser.add_argument("--enable-stem", action="store_true")
    parser.add_argument(
        "--synthetic-occlusion",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="paste a second instance over the target to create modal/amodal pairs",
    )
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    if args.output.exists():
        raise SystemExit(f"output directory already exists: {args.output}")
    args.output.mkdir(parents=True)

    from curve_consistency import band_observed, curve_profile_loss
    from occlusion_aware import (
        amodal_bce,
        amodal_containment_loss,
        routing_balance_loss,
    )
    from synthtree_instances import SynthTreeInstances

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)

    if args.composite_root is not None:
        from broadleaf_composites import BroadleafComposites

        dataset = BroadleafComposites(args.composite_root, "train", mean=mean, std=std)
        val_dataset = BroadleafComposites(args.composite_root, "val", mean=mean, std=std)
    else:
        dataset = SynthTreeInstances(
            args.data_root,
            args.split_json,
            mean=mean,
            std=std,
            max_images=args.max_images,
            synthetic_occlusion=args.synthetic_occlusion,
        )
        val_dataset = SynthTreeInstances(
            args.data_root,
            args.val_split_json,
            mean=mean,
            std=std,
            max_images=args.val_max_images,
            seed=1,
            synthetic_occlusion=args.synthetic_occlusion,
        )
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
    model = build_model(
        sam2_path,
        args.device,
        args.knots,
        encoder_lora_rank=args.encoder_lora_rank,
        principal_focus=args.principal_focus,
        enable_stem=args.enable_stem,
    )
    model.train()
    # The occluder branch has no supervision yet; keep it at initial behaviour.
    for parameter in model.decoder.occluder_hypernet.parameters():
        parameter.requires_grad_(False)
    model.decoder.occluder_token.requires_grad_(False)
    if args.amodal_weight <= 0:
        # Phase 1 does not supervise amodal either; keep the near-zero residual.
        for parameter in model.decoder.amodal_hypernets.parameters():
            parameter.requires_grad_(False)
        model.decoder.amodal_scale.requires_grad_(False)

    new_parameters, base_parameters = trainable_groups(model)
    optimizer = torch.optim.AdamW(
        [
            {"params": new_parameters, "lr": args.lr_new},
            {"params": base_parameters, "lr": args.lr_base},
        ],
        weight_decay=1e-4,
    )
    trainable = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    frozen = sum(
        parameter.numel() for parameter in model.parameters() if not parameter.requires_grad
    )
    if args.composite_root is not None:
        targets = np.array(
            [
                [1.0 - item["occlusion_rate"], 1.0 - item["occlusion_rate"]]
                for item in dataset.items
            ],
            dtype=np.float32,
        )
    else:
        targets = np.array(
            [
                [row["visibility"], row["grasp_visibility"]]
                for rows in dataset.rows.values()
                for row in rows
            ],
            dtype=np.float32,
        )
    targets = targets[np.isfinite(targets).all(axis=1)]
    median = np.median(targets, axis=0)
    baseline_mae = float(np.mean(np.abs(targets - median)))
    print(json.dumps({
        "dataset_images": len(dataset),
        "val_images": len(val_dataset),
        "trainable_parameters": trainable,
        "frozen_parameters": frozen,
        "new_tensor_parameters": sum(p.numel() for p in new_parameters),
        "base_decoder_parameters": sum(p.numel() for p in base_parameters),
        "constant_visibility_baseline_mae": baseline_mae,
    }), flush=True)

    history = []
    best_amodal = -1.0
    initial = evaluate(model, val_dataset, args.eval_items, args.device)
    initial_modal, initial_amodal, initial_hull, initial_mae, initial_baseline, initial_bands = (
        initial
    )
    print(
        json.dumps(
            {
                "val_initial_mask_iou": initial_modal,
                "val_initial_amodal_iou": initial_amodal,
                "val_initial_amodal_hull_iou": initial_hull,
                "val_initial_amodal_iou_bands": initial_bands,
                "val_initial_visibility_mae": initial_mae,
                "val_initial_visibility_baseline_mae": initial_baseline,
            }
        ),
        flush=True,
    )
    model.train()
    iterator = iter(loader)
    started = time.perf_counter()
    for step in range(1, args.steps + 1):
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(loader)
            batch = next(iterator)
        pixel_values = batch["pixel_values"].to(args.device)
        boxes = batch["box"].to(args.device)[:, None, :]
        target = batch["mask"].to(args.device)
        amodal_target = batch["amodal_mask"].to(args.device)
        visibility_target = batch["visibility"].to(args.device)[:, None, :]

        output = model(pixel_values, input_boxes=boxes)
        logits = output["masks"][:, :, 0]
        mask_loss = F.binary_cross_entropy_with_logits(logits, target) + dice_loss(logits, target)
        # Phase 1 uses a stable MSE for visibility; the log-variance output is
        # kept for later calibration instead of being trained by an NLL that can
        # collapse to huge variance early in training.
        visibility_loss = F.mse_loss(output["visibility"], visibility_target)
        containment = amodal_containment_loss(output["amodal_masks"][:, :, 0], target)
        routing = routing_balance_loss(output["routing"])
        curve_target = batch["curve"].to(args.device)[:, None, :]
        curve_observed = batch["curve_observed"].to(args.device)[:, None, :]
        curve_error = (output["curve"] - curve_target) ** 2 * curve_observed
        curve_loss = curve_error.sum() / curve_observed.sum().clamp_min(1.0)
        if args.knots >= 3:
            second = (
                output["curve"][..., 2:]
                - 2.0 * output["curve"][..., 1:-1]
                + output["curve"][..., :-2]
            )
            curve_loss = curve_loss + 0.05 * (second**2).mean()
        amodal_loss = amodal_bce(
            output["amodal_masks"][:, :, 0], amodal_target, target, occluded_weight=3.0
        )
        visible_bands = band_observed(target, args.knots)[:, None].to(curve_observed.dtype)
        curve_consistency = curve_profile_loss(
            logits,
            output["curve"],
            curve_observed * visible_bands,
            output["curve_log_sigma"],
        )
        total = (
            mask_loss
            + 0.5 * visibility_loss
            + 0.1 * containment
            + 0.01 * routing
            + args.curve_weight * curve_loss
            + args.curve_consistency_weight * curve_consistency
            + args.amodal_weight * amodal_loss
        )
        if not torch.isfinite(total):
            raise FloatingPointError(f"non-finite loss at step {step}")
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        torch.nn.utils.clip_grad_norm_(
            [p for p in model.parameters() if p.requires_grad], 1.0, error_if_nonfinite=True
        )
        optimizer.step()
        entry = {
            "step": step,
            "mask": float(mask_loss.detach()),
            "visibility": float(visibility_loss.detach()),
            "containment": float(containment.detach()),
            "routing": float(routing.detach()),
            "curve": float(curve_loss.detach()),
            "curve_consistency": float(curve_consistency.detach()),
            "amodal": float(amodal_loss.detach()),
            "total": float(total.detach()),
            "seconds": time.perf_counter() - started,
        }
        history.append(entry)
        print(json.dumps(entry), flush=True)
        if step % args.eval_every == 0 or step == args.steps:
            modal_iou, amodal_iou, hull_iou, visibility_mae, val_baseline, bands = evaluate(
                model, val_dataset, args.eval_items, args.device
            )
            model.train()
            print(
                json.dumps(
                    {
                        "eval_step": step,
                        "val_mask_iou": modal_iou,
                        "val_amodal_iou": amodal_iou,
                        "val_amodal_hull_iou": hull_iou,
                        "val_amodal_iou_bands": bands,
                        "val_visibility_mae": visibility_mae,
                        "val_visibility_baseline_mae": val_baseline,
                    }
                ),
                flush=True,
            )
            if amodal_iou > best_amodal:
                best_amodal = amodal_iou
                torch.save(
                    {
                        "decoder": model.decoder.state_dict(),
                        "knots": args.knots,
                        "step": step,
                        "modal_iou": modal_iou,
                        "amodal_iou": amodal_iou,
                        "visibility_mae": visibility_mae,
                    },
                    args.output / "decoder_best.pth",
                )

    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (args.output / "run.json").write_text(
        json.dumps(
            {
                "split_json": str(args.split_json),
                "val_split_json": str(args.val_split_json),
                "max_images": args.max_images,
                "val_images": len(val_dataset),
                "steps": args.steps,
                "trainable_parameters": trainable,
                "frozen_parameters": frozen,
                "best_amodal_iou": best_amodal,
                "amodal_weight": args.amodal_weight,
                "synthetic_occlusion": bool(args.synthetic_occlusion),
                "note": (
                    "phase-2 training: modal + amodal + visibility + crown curve "
                    "with synthetic rectangular occlusions"
                ),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"saved {args.output / 'decoder_best.pth'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
