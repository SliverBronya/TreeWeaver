"""Native-grid metric data passes for Blender 4.2 Cycles qualification renders."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import bpy
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from metric_camera import depth_from_world_positions, world_to_cv_from_blender  # noqa: E402
from metric_dataset_contract import depth_products  # noqa: E402


def configure(scene, output):
    """Attach lossless numeric passes before the full-scene beauty render."""
    view = scene.view_layers[0]
    view.use_pass_z = True
    view.use_pass_position = True
    view.use_pass_object_index = True
    view.pass_alpha_threshold = 0.5
    scene.use_nodes = True
    tree = scene.node_tree
    tree.nodes.clear()
    layers = tree.nodes.new("CompositorNodeRLayers")
    composite = tree.nodes.new("CompositorNodeComposite")
    tree.links.new(layers.outputs["Image"], composite.inputs["Image"])
    folder = Path(output) / "metric_raw"
    folder.mkdir()
    for socket, filename, mode in (
        ("Depth", "camera_z_", "RGB"),
        ("Position", "world_position_", "RGB"),
        ("IndexOB", "object_id_", "RGB"),
    ):
        node = tree.nodes.new("CompositorNodeOutputFile")
        node.base_path = str(folder)
        node.format.file_format = "OPEN_EXR"
        node.format.color_depth = "32"
        node.format.color_mode = mode
        node.format.exr_codec = "ZIP"
        node.file_slots[0].path = filename
        tree.links.new(layers.outputs[socket], node.inputs[0])
    return folder


def _read_exr(path):
    image = bpy.data.images.load(str(path), check_existing=False)
    try:
        image.colorspace_settings.name = "Non-Color"
        width, height = image.size
        values = np.empty(width * height * image.channels, np.float32)
        image.pixels.foreach_get(values)
        # Blender image buffers are bottom-up; saved PNG/NPZ use top-left rows.
        return np.flipud(values.reshape(height, width, image.channels)).copy()
    finally:
        bpy.data.images.remove(image)


def export(scene, output, raw_folder):
    """Validate Z against independently exported world positions and project K."""
    camera = scene.camera
    if camera.data.type != "PERSP" or camera.data.sensor_fit != "HORIZONTAL":
        raise ValueError("exporter requires declared horizontal-fit pinhole camera")
    if camera.data.shift_x or camera.data.shift_y or scene.render.resolution_percentage != 100:
        raise ValueError("shifted/scaled camera export is not implemented")
    if scene.render.pixel_aspect_x != scene.render.pixel_aspect_y:
        raise ValueError("non-square pixels require a different K")
    width, height = scene.render.resolution_x, scene.render.resolution_y
    focal = camera.data.lens / camera.data.sensor_width * width
    k = np.array([[focal, 0, width / 2], [0, focal, height / 2], [0, 0, 1]], np.float64)
    pose = np.array(camera.matrix_world, np.float64)
    world_to_cv = world_to_cv_from_blender(pose)
    raw_folder = Path(raw_folder)
    z = _read_exr(next(raw_folder.glob("camera_z_*.exr")))[..., 0]
    positions = _read_exr(next(raw_folder.glob("world_position_*.exr")))[..., :3]
    owner = np.rint(_read_exr(next(raw_folder.glob("object_id_*.exr")))[..., 0]).astype(np.int32)
    if z.shape != (height, width) or positions.shape != (height, width, 3):
        raise ValueError("native metric pass resolution mismatch")
    hit = np.isfinite(z) & (z >= camera.data.clip_start) & (z <= camera.data.clip_end)
    projected = depth_from_world_positions(
        positions,
        world_to_cv,
        hit,
        clip_m=(camera.data.clip_start, camera.data.clip_end),
    )
    valid = hit & projected["valid"]
    if not valid.any():
        raise ValueError("no finite metric surface pixels")
    error = np.abs(z[valid] - projected["depth_z_m"][valid])
    if np.max(error) > 0.002:
        raise ValueError("Depth pass and world-Position camera-Z disagree by >2mm")
    products = depth_products(z, valid, k, convention="camera_z_m")
    cv = positions @ world_to_cv[:3, :3].T + world_to_cv[:3, 3]
    pixels = cv @ k.T
    pixels = pixels[..., :2] / np.where(valid, pixels[..., 2], 1)[..., None]
    yy, xx = np.indices(z.shape)
    pixel_error = np.linalg.norm(pixels - np.stack((xx + 0.5, yy + 0.5), -1), axis=-1)
    # Data passes contain the first subpixel sample, rather than an AA average.
    p99 = float(np.quantile(pixel_error[valid], 0.99))
    if p99 > 1.25:
        raise ValueError("Position reprojection is not aligned with native raster/K")
    np.savez_compressed(
        Path(output) / "metric_depth.npz",
        depth_z_m=products["camera_z_m"],
        depth_ray_m=products["ray_distance_m"],
        valid=valid,
        object_id=owner,
        world_position_m=positions,
        K=k,
        T_world_from_blender_camera=pose,
        T_cv_from_world=world_to_cv,
    )
    record = {
        "unit": "m",
        "truth_domain": "synthetic_metric_geometry",
        "native_image_wh": [width, height],
        "K": k.tolist(),
        "T_cv_from_world": world_to_cv.tolist(),
        "T_world_from_cv": np.linalg.inv(world_to_cv).tolist(),
        "pixel_centres": "u+0.5,v+0.5",
        "raster_rows": "top_to_bottom",
        "raw_cycles_depth_convention": "camera_z_m",
        "depth_range_m": [float(z[valid].min()), float(z[valid].max())],
        "valid_pixels": int(valid.sum()),
        "invalid_pixels": int((~valid).sum()),
        "world_position_z_max_error_m": float(error.max()),
        "world_position_reprojection_p99_px": p99,
        "depth_pass_sample": "first subpixel sample; no antialias averaging",
        "alpha_threshold": 0.5,
        "ambiguity_edges_require_additional_validity_mask": True,
        "background_tree_object_ids": sorted(int(i) for i in np.unique(owner) if i >= 100),
        "rendered_geometric_consistency_passed": True,
        "dataset_training_admission": False,
        "sky_has_finite_depth": False,
    }
    (Path(output) / "metric-camera.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    scene.use_nodes = False  # Counterfactual/ID passes must not overwrite full-scene EXRs.
    return record, owner
