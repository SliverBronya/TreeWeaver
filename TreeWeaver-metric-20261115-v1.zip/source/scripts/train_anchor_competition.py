"""Development step 1: isolate learned anchor/neighbor competition on real trunks.

Fixed final budget, validation reporting only, no access to the test split.
All ablations share source frames, prompts, losses, initialization and ordering.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from torch.nn import functional as F
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from anchor_competition import AnchorCompetition, identity_objective  # noqa: E402
from probe_canatree_adhesion import (  # noqa: E402
    BASE,
    REVISION,
    base_point,
    decode_image,
    load_fold,
)
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from stem_eval_common import mask_row  # noqa: E402


def safe_anchor(mask, box):
    point = np.asarray(base_point(mask, box), np.float32)
    x, y = np.rint(point).astype(int)
    if mask[min(y, mask.shape[0] - 1), min(x, mask.shape[1] - 1)]:
        return point
    ys, xs = np.nonzero(mask)
    chosen = ((xs - point[0]) ** 2 + (ys - point[1]) ** 2).argmin()
    return np.array([xs[chosen], ys[chosen]], np.float32)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    parser.add_argument(
        "--modes",
        nargs="+",
        default=["local", "anchor", "joint"],
        choices=["local", "anchor", "joint", "exchange"],
    )
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 300:
        parser.error("fresh output and steps=1..300 required")
    assert_training_allowed(BASE)
    documents = {role: load_fold(role) for role in ("train", "val")}
    file_sets = [{v["file_name"] for v in document[0].values()} for document in documents.values()]
    if file_sets[0] & file_sets[1]:
        raise ValueError("train/validation image overlap")
    args.output.mkdir(parents=True)
    protocol = {
        "profile": "learned_stem_anchor_competition_development_v1",
        "seed": 20261108,
        "steps_per_arm": args.steps,
        "lr": 0.001,
        "foundation": "frozen facebook/sam2.1-hiera-tiny",
        "revision": REVISION,
        "arms": args.modes,
        "selection": "fixed final step; no checkpoint selection",
        "prompt": "identical GT boxes and one valid positive trunk-base pixel per object",
        "labels": (
            "only unambiguous annotated foreground; preserve residual outside annotation union"
        ),
        "test_split_accessed": False,
        "video_disjoint_verified": False,
        "acceptance_vs_first_arm": {
            "neighbour_fraction_relative_reduction_at_least": 0.10,
            "iou_drop_at_most": 0.005,
            "recall_drop_at_most": 0.01,
            "also_require_frozen_iou_and_recall_noninferiority": True,
        },
        "scope": "real visible trunk separation only; not canopy completion or publication novelty",
        "source_sha256": {},
        "input_sha256": {},
    }
    source = args.output / "source"
    source.mkdir()
    for path in (
        Path(__file__),
        ROOT / "workers/tree_models/anchor_competition.py",
        ROOT / "scripts/probe_canatree_adhesion.py",
        ROOT / "scripts/stem_eval_common.py",
    ):
        (source / path.name).write_bytes(path.read_bytes())
        protocol["source_sha256"][str(path)] = sha256_file(path)
    for _role, (images, _, annotation_path) in documents.items():
        protocol["input_sha256"][str(annotation_path)] = sha256_file(annotation_path)
        for image in images.values():
            path = BASE / "images" / image["file_name"]
            protocol["input_sha256"][str(path)] = sha256_file(path)
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    foundation = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    frames = {role: [] for role in documents}
    for role, (images, grouped, _) in documents.items():
        for number, (image_id, image) in enumerate(images.items(), 1):
            bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
            anchors = np.stack(
                [safe_anchor(mask, box) for mask, box in zip(masks, boxes, strict=True)]
            )
            pixels = processor(
                images=Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)), return_tensors="pt"
            )["pixel_values"].to(args.device)
            points = torch.tensor(
                anchors * [1024 / width, 1024 / height], dtype=torch.float32, device=args.device
            )[None, :, None]
            prompt_boxes = torch.tensor(
                boxes * ([1024 / width, 1024 / height] * 2), dtype=torch.float32, device=args.device
            )[None]
            with torch.no_grad():
                result = foundation(
                    pixel_values=pixels,
                    input_boxes=prompt_boxes,
                    input_points=points,
                    input_labels=torch.ones(1, len(boxes), 1, dtype=torch.long, device=args.device),
                    multimask_output=False,
                )
                raw = result.pred_masks[0, :, 0]
                output = foundation.get_image_features(pixels)
                feature = (
                    output.fpn_hidden_states[0]
                    .permute(1, 2, 0)
                    .reshape(1, -1, *foundation.backbone_feature_sizes[0])
                )
                targets = F.interpolate(
                    torch.tensor(masks.astype(np.float32), device=args.device)[:, None],
                    size=raw.shape[-2:],
                    mode="nearest",
                )[:, 0].bool()
            frames[role].append(
                {
                    "name": image["file_name"],
                    "bgr": bgr,
                    "masks": masks,
                    "raw": raw.cpu(),
                    "features": feature.cpu(),
                    "targets": targets.cpu(),
                    "anchors": torch.tensor(anchors / [width, height], dtype=torch.float32),
                }
            )
            if number % 10 == 0:
                print(f"prepared {role}: {number}/{len(images)}", flush=True)
    del foundation, result, output, pixels
    torch.cuda.empty_cache()
    summary, evaluation_rows = {}, {}

    def evaluate(name, model=None):
        if model is not None:
            model.eval()
        rows = []
        folder = args.output / name
        folder.mkdir(exist_ok=True)
        for frame in frames["val"]:
            raw = frame["raw"].to(args.device)
            with torch.no_grad():
                logits = (
                    raw
                    if model is None
                    else model(
                        frame["features"].to(args.device),
                        raw,
                        frame["anchors"].to(args.device),
                        name,
                    )[0]
                )
                prediction = (
                    (
                        F.interpolate(
                            logits[:, None],
                            frame["masks"].shape[-2:],
                            mode="bilinear",
                            align_corners=False,
                        )[:, 0]
                        > 0
                    )
                    .cpu()
                    .numpy()
                )
            for index, (pred, gt) in enumerate(zip(prediction, frame["masks"], strict=True)):
                others = [mask for j, mask in enumerate(frame["masks"]) if j != index]
                metrics = mask_row(f"{frame['name']}:{index}", pred, gt, others=others)
                metrics["image"], metrics["tree_index"] = frame["name"], index
                rows.append(metrics)
            np.savez_compressed(folder / (Path(frame["name"]).stem + ".npz"), masks=prediction)
        evaluation_rows[name] = rows
        summary[name] = {
            key: float(np.mean([row[key] for row in rows]))
            for key in ("iou", "boundary_f1", "recall", "precision", "neighbour_fraction")
        }
        summary[name].update(
            {"trees": len(rows), "empty": sum(row["empty_prediction"] for row in rows)}
        )
        (folder / "per_tree.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
        (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(name, json.dumps(summary[name]), flush=True)

    evaluate("frozen")
    order = random.Random(20261108).choices(range(len(frames["train"])), k=args.steps)
    for mode in args.modes:
        torch.manual_seed(20261108)
        model = AnchorCompetition(frames["train"][0]["features"].shape[1]).to(args.device)
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.0001)
        history = []
        for step, index in enumerate(order, 1):
            model.train()
            frame = frames["train"][index]
            logits, residual = model(
                frame["features"].to(args.device),
                frame["raw"].to(args.device),
                frame["anchors"].to(args.device),
                mode,
            )
            loss = identity_objective(logits, residual, frame["targets"].to(args.device))
            if not torch.isfinite(loss):
                raise FloatingPointError("nonfinite loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            history.append({"step": step, "image": frame["name"], "loss": float(loss.detach())})
            if step % 25 == 0:
                print(mode, json.dumps(history[-1]), flush=True)
        folder = args.output / mode
        folder.mkdir()
        torch.save(
            {"refiner": model.state_dict(), "mode": mode, "protocol": protocol},
            folder / "final.pth",
        )
        (folder / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        evaluate(mode, model)
        del model, optimizer
        torch.cuda.empty_cache()
    control, joint = summary[args.modes[0]], summary[args.modes[-1]]
    passed = (
        joint["neighbour_fraction"] <= 0.9 * control["neighbour_fraction"]
        and joint["iou"] >= control["iou"] - 0.005
        and joint["recall"] >= control["recall"] - 0.01
        and joint["iou"] >= summary["frozen"]["iou"] - 0.005
        and joint["recall"] >= summary["frozen"]["recall"] - 0.01
    )
    (args.output / "decision.json").write_text(
        json.dumps(
            {
                "gate_passed": passed,
                "compared": f"{args.modes[-1]} versus same-budget {args.modes[0]}",
                "test_accessed": False,
            },
            indent=2,
        )
    )
    render(args.output, frames["val"], evaluation_rows)
    print("Development gate:", passed, flush=True)


def render(root, frames, rows):
    # Fixed rule: most frozen neighbour leakage, rather than best model gain.
    target = max(rows["frozen"], key=lambda row: row["neighbour_fraction"])
    frame = next(frame for frame in frames if frame["name"] == target["image"])
    tree = target["tree_index"]
    names = ["GT", *rows]
    sheet = Image.new("RGB", (384 * len(names), 280), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 16)
    for column, name in enumerate(names):
        mask = (
            frame["masks"][tree]
            if name == "GT"
            else np.load(root / name / (Path(frame["name"]).stem + ".npz"))["masks"][tree]
        )
        panel = frame["bgr"].copy()
        panel[mask] = (0.5 * panel[mask] + 0.5 * np.array([240, 170, 20])).astype(np.uint8)
        draw.text((column * 384 + 5, 8), name, fill="black", font=font)
        sheet.paste(
            Image.fromarray(cv2.cvtColor(cv2.resize(panel, (384, 216)), cv2.COLOR_BGR2RGB)),
            (column * 384, 35),
        )
    draw.text(
        (5, 256),
        f"{target['id']} | largest frozen neighbour fraction; GT-derived prompts",
        fill="black",
        font=font,
    )
    sheet.save(root / "comparison.jpg", quality=94)


if __name__ == "__main__":
    main()
