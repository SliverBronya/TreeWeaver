"""Run the focused visible+stem checkpoints through the real RGB-D measurement flow."""

from __future__ import annotations

import inspect
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
sys.path.insert(0, str(ROOT / "workers/arcore_rgbd_benchmark"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from evaluate import load_depth, measure  # noqa: E402

DATA = ROOT / "data/20260411"
TRUTH = ROOT / "reports/20260411-rgbd-benchmark/per_image.json"
VISIBLE = ROOT / "reports/focused-visible-arms-2026-11-10/lora_only/checkpoint.pth"
STEM = ROOT / "reports/focused-stem-2026-11-10/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/new-model-rgbd-2026-11-10"


def snapshot(repo):
    base = Path.home() / ".cache/huggingface/hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def image_tensor(image):
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def native(mask, lb):
    mask = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((1024, 1024), Image.NEAREST)) > 127
    width, height = lb.source_size
    nw, nh = round(width * lb.scale), round(height * lb.scale)
    mask = mask[lb.pad_y : lb.pad_y + nh, lb.pad_x : lb.pad_x + nw]
    return np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)) > 127


def build():
    base = Sam2Model.from_pretrained(snapshot("facebook/sam2.1-hiera-tiny"), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4, enable_stem=True).cuda().eval()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)["decoder"]
    own = model.decoder.state_dict()
    model.decoder.load_state_dict({k: v for k, v in payload.items() if k in own and v.shape == own[k].shape}, strict=False)
    model.load_state_dict(torch.load(VISIBLE, map_location="cpu", weights_only=True)["state"], strict=False)
    model.load_state_dict(torch.load(STEM, map_location="cpu", weights_only=True)["state"], strict=False)
    for p in model.parameters():
        p.requires_grad_(False)
    return model


def main():
    OUT.mkdir(exist_ok=True)
    processor = AutoProcessor.from_pretrained(snapshot("IDEA-Research/grounding-dino-tiny"), local_files_only=True)
    detector = AutoModelForZeroShotObjectDetection.from_pretrained(
        snapshot("IDEA-Research/grounding-dino-tiny"), local_files_only=True
    ).cuda().eval()
    model = build()
    truth = json.loads(TRUTH.read_text(encoding="utf-8"))
    rows = []
    for record in truth:
        name = record["filename"]
        path = DATA / name
        image = Image.open(path).convert("RGB")
        width, height = image.size
        inputs = processor(images=image, text="tree.", return_tensors="pt").to("cuda")
        with torch.no_grad():
            outputs = detector(**inputs)
        kwargs = {
            "threshold"
            if "threshold" in inspect.signature(processor.post_process_grounded_object_detection).parameters
            else "box_threshold": 0.28
        }
        result = processor.post_process_grounded_object_detection(
            outputs, inputs.input_ids, text_threshold=0.22, target_sizes=[image.size[::-1]], **kwargs
        )[0]
        boxes = result["boxes"].detach().cpu().numpy()
        scores = result["scores"].detach().cpu().numpy()
        if len(boxes) == 0:
            rows.append({"filename": name, "tree_id": record["tree_id"], "status": "no_box"})
            continue
        best = int(scores.argmax())
        lb = letterbox(image)
        box = torch.tensor(lb.boxes(boxes[best][None])[0], dtype=torch.float32)[None, None].cuda()
        with torch.no_grad():
            output = model(image_tensor(lb.image).cuda(), input_boxes=box)
        whole = native(output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5, lb)
        trunk = native(output["stem_masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5, lb)
        depth = load_depth(DATA / f"{Path(name).stem}_depthdata.txt", (width, height))
        try:
            row = measure(whole, trunk, depth)
            row.update({"filename": name, "tree_id": record["tree_id"], "status": "ok", "detector_score": float(scores[best])})
            for key in ("height_truth_m", "dbh_truth_cm"):
                row[key] = record.get(key)
            rows.append(row)
        except Exception as exc:
            rows.append({"filename": name, "tree_id": record["tree_id"], "status": "measure_failed", "error": str(exc)})
        print(name, rows[-1].get("status"), flush=True)
    (OUT / "per_image.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    # tree-level median fusion
    grouped = defaultdict(list)
    for row in rows:
        if row.get("status") == "ok" and row.get("height_truth_m") is not None:
            grouped[row["tree_id"]].append(row)
    tree_rows = []
    for tree_id, values in sorted(grouped.items()):
        def med(key):
            vals = [v[key] for v in values if isinstance(v.get(key), (int, float)) and np.isfinite(v[key])]
            return float(np.median(vals)) if vals else float("nan")
        tree_rows.append({
            "tree_id": tree_id,
            "views": len(values),
            "height_pred_m": med("height_pred_m"),
            "height_truth_m": med("height_truth_m"),
            "dbh_pred_cm": med("dbh_pred_cm"),
            "dbh_truth_cm": med("dbh_truth_cm"),
        })
    def metrics(values, pred_key, truth_key):
        pairs = [(v[pred_key] - v[truth_key], v[pred_key], v[truth_key]) for v in values if np.isfinite(v[pred_key]) and np.isfinite(v[truth_key])]
        if not pairs:
            return None
        errors = np.array([p[0] for p in pairs]); abs_err = np.abs(errors)
        ape = np.abs(errors) / np.array([p[2] for p in pairs]) * 100
        return {"n": len(pairs), "mae": float(abs_err.mean()), "rmse": float(np.sqrt((errors**2).mean())), "mape_percent": float(ape.mean()), "median_ape_percent": float(np.median(ape)), "within_10_percent": float((ape <= 10).mean() * 100), "within_20_percent": float((ape <= 20).mean() * 100), "bias": float(errors.mean())}
    summary = {
        "images": len(rows),
        "ok": sum(r.get("status") == "ok" for r in rows),
        "trees": len(tree_rows),
        "image_level": {
            "height": metrics([r for r in rows if r.get("status") == "ok"], "height_pred_m", "height_truth_m"),
            "dbh": metrics([r for r in rows if r.get("status") == "ok"], "dbh_pred_cm", "dbh_truth_cm"),
        },
        "tree_level_median": {
            "height": metrics(tree_rows, "height_pred_m", "height_truth_m"),
            "dbh": metrics(tree_rows, "dbh_pred_cm", "dbh_truth_cm"),
        },
        "truth_used_for_inference": False,
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (OUT / "per_tree.json").write_text(json.dumps(tree_rows, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
