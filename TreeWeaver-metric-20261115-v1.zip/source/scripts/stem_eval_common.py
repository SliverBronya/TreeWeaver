"""Shared plumbing for stem-token runs on real trunk references.

Rules enforced here, after the 2026-11-03 audit of the first stem runs:

* a frozen protocol is written before any optimizer step;
* every tree gets its own row, not only a mean;
* the stock SAM2 decoder is evaluated on exactly the same prompts, in the same
  run, so a stem number is never quoted in isolation;
* train/validation/protected roles must be disjoint, and protected trees are
  reported but never used for checkpoint selection.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from instance_metrics import boundary_f1  # noqa: E402


def assert_disjoint_roles(roles: dict[str, set]) -> None:
    """Refuse a split file whose roles share a tree identity."""
    names = [name for name, values in roles.items() if values]
    for index, left in enumerate(names):
        for right in names[index + 1 :]:
            shared = roles[left] & roles[right]
            if shared:
                raise ValueError(
                    f"split leak between {left} and {right}: {sorted(shared)[:8]}"
                )


def mask_row(identifier, prediction, target, tolerance: int = 2, others=None) -> dict:
    """Per-tree metrics, including how much prediction lands on a neighbouring tree."""
    prediction = np.asarray(prediction, dtype=bool)
    target = np.asarray(target, dtype=bool)
    intersection = int(np.logical_and(prediction, target).sum())
    union = int(np.logical_or(prediction, target).sum())
    row = {
        "id": str(identifier),
        "iou": float(intersection / union) if union else 0.0,
        "boundary_f1": float(boundary_f1(prediction, target, tolerance=tolerance)),
        "recall": float(intersection / target.sum()) if target.sum() else 0.0,
        "precision": float(intersection / prediction.sum()) if prediction.sum() else 0.0,
        "predicted_pixels": int(prediction.sum()),
        "target_pixels": int(target.sum()),
        "empty_prediction": not bool(prediction.any()),
    }
    if others is not None:
        foreign = np.zeros_like(prediction)
        for other in others:
            foreign |= np.asarray(other, dtype=bool)
        foreign &= ~target
        leaked = int(np.logical_and(prediction, foreign).sum())
        row["neighbour_pixels"] = leaked
        row["neighbour_fraction"] = float(leaked / max(int(prediction.sum()), 1))
    return row


def _binarize(logits, height: int, width: int) -> np.ndarray:
    upscaled = F.interpolate(
        logits[:, None], (height, width), mode="bilinear", align_corners=False
    )[:, 0]
    return (upscaled > 0).cpu().numpy()


def stem_masks(model, pixels, boxes, height: int, width: int) -> np.ndarray:
    with torch.inference_mode():
        output = model(pixel_values=pixels, input_boxes=boxes, multimask_output=False)
        logits = output["stem_masks"][0, :, 0]
    return _binarize(logits, height, width)


def stock_masks(sam2, pixels, boxes, height: int, width: int) -> np.ndarray:
    with torch.inference_mode():
        output = sam2(pixel_values=pixels, input_boxes=boxes, multimask_output=False)
        logits = output.pred_masks[0, :, 0]
    return _binarize(logits, height, width)


def mean_of(rows, key: str) -> float:
    values = [float(row[key]) for row in rows]
    return float(np.mean(values)) if values else 0.0


def paired(rows: list[dict], left="stock_sam2", right="stem") -> dict:
    """Paired per-tree comparison; ties are their own count, not wins."""
    deltas = [
        float(row[right]["iou"]) - float(row[left]["iou"])
        for row in rows
        if left in row and right in row
    ]
    return {
        "compared": len(deltas),
        "mean_delta_iou": float(np.mean(deltas)) if deltas else 0.0,
        "wins": sum(delta > 1e-6 for delta in deltas),
        "ties": sum(abs(delta) <= 1e-6 for delta in deltas),
        "losses": sum(delta < -1e-6 for delta in deltas),
    }


def write_json(path: Path, document) -> None:
    Path(path).write_text(
        json.dumps(document, indent=2, allow_nan=False, default=str), encoding="utf-8"
    )
