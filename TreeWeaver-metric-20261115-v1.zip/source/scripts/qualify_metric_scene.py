"""Qualify a saved metric scene on CPU; never render, train or invent labels.

Required labels.npz arrays: visible/amodal (K,H,W bool), known (H,W or
K,H,W bool), owner (H,W integer), stem/crown/part_unknown (K,H,W bool),
depth (H,W floating metres), depth_valid (H,W bool). Optional other_visible
uses J,H,W bool; optional instance_ids must match scene.json instance order.
Depth convention and native image dimensions come from the scene metadata.

A passing result validates the supplied raster/metadata contracts only. It
does not independently establish correct rendering or physical geometry.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from metric_dataset_contract import (  # noqa: E402
    depth_products,
    derive_scene_labels,
    qualify_focal_target,
    validate_scene_metadata,
    validate_visible_parts,
)

REQUIRED_ARRAYS = (
    "visible",
    "amodal",
    "known",
    "owner",
    "stem",
    "crown",
    "part_unknown",
    "depth",
    "depth_valid",
)
OPTIONAL_ARRAYS = ("other_visible", "instance_ids")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def _reject_json_constant(value):
    raise ValueError("scene JSON must not contain nonfinite constants: " + value)


def qualify_scene(
    scene_path,
    labels_path,
    output_path,
    *,
    focal_id=None,
    cohort="occluded_primary",
    occlusion_scope="tree",
    require_complete_metrics=True,
    rgb_path=None,
):
    """Write a fresh qualification report and derived diagnostic arrays.

    Malformed input is rejected before creating the output directory. Valid
    contracts that fail a qualification gate produce a completed failed report.
    A partial write has no report.json and is never silently overwritten.
    """
    source = Path(scene_path).resolve(strict=True)
    archive_path = Path(labels_path).resolve(strict=True)
    output = Path(output_path).resolve()
    if output.exists() or Path(output_path).is_symlink():
        raise FileExistsError("output exists; refusing to overwrite: " + str(output))
    if not source.is_file() or not archive_path.is_file():
        raise ValueError("scene and labels must be files")
    if archive_path.suffix.lower() != ".npz":
        raise ValueError("labels must be a saved .npz archive")
    paths = {"scene": source, "labels": archive_path}
    if rgb_path is not None:
        paths["rgb"] = Path(rgb_path).resolve(strict=True)
    hashes = {name: sha256_file(path) for name, path in paths.items()}
    document = json.loads(source.read_text(encoding="utf-8"), parse_constant=_reject_json_constant)
    if not isinstance(document, dict):
        raise ValueError("scene JSON must contain an object")
    metadata = validate_scene_metadata(document)
    with np.load(archive_path, allow_pickle=False) as archive:
        missing = sorted(set(REQUIRED_ARRAYS) - set(archive.files))
        if missing:
            raise ValueError("missing NPZ arrays: " + ", ".join(missing))
        arrays = {
            name: archive[name]
            for name in (*REQUIRED_ARRAYS, *OPTIONAL_ARRAYS)
            if name in archive.files
        }
        ignored = sorted(set(archive.files) - set(arrays))
    identities = [item["instance_id"] for item in document["instances"]]
    width, height = document["camera"]["image_wh"]
    shape = (len(identities), height, width)
    if arrays["visible"].shape != shape:
        raise ValueError("visible raster must match metadata instance order and native RGB grid")
    if "instance_ids" in arrays:
        declared = arrays["instance_ids"]
        if (
            declared.dtype.kind not in "iu"
            or declared.shape != (len(identities),)
            or declared.tolist() != identities
        ):
            raise ValueError("NPZ instance_ids disagree with metadata query order")
    if arrays["depth"].shape != (height, width):
        raise ValueError("depth raster must match the native RGB grid")
    if "rgb" in paths:
        with Image.open(paths["rgb"]) as image:
            if image.size != (width, height):
                raise ValueError("RGB pixels disagree with declared native image size")
            image.verify()
    labels = derive_scene_labels(
        arrays["visible"],
        arrays["amodal"],
        arrays["known"],
        instance_ids=identities,
        owner=arrays["owner"],
        other_visible=arrays.get("other_visible"),
    )
    if (arrays["owner"][~labels["known"]] != -1).any():
        raise ValueError("unknown owner pixels must use ignore ID -1")
    known = np.broadcast_to(labels["known"], shape)
    parts = validate_visible_parts(
        arrays["visible"],
        arrays["stem"],
        arrays["crown"],
        arrays["part_unknown"],
        known,
    )
    depth = depth_products(
        arrays["depth"],
        arrays["depth_valid"],
        document["camera"]["K"],
        convention=document["depth"]["convention"],
    )
    if focal_id is None:
        focal_id = document.get("focal_instance_id")
    if type(focal_id) is not int:
        raise ValueError("provide --focal-id or integer focal_instance_id in scene metadata")
    focal_items = [item for item in document["instances"] if item["instance_id"] == focal_id]
    if len(focal_items) != 1:
        raise ValueError("focal ID not uniquely present in metadata")
    truncated = focal_items[0].get("frame_truncated", False)
    if type(truncated) is not bool:
        raise ValueError("frame_truncated must be boolean when provided")
    focal = qualify_focal_target(
        labels,
        focal_id,
        cohort=cohort,
        occlusion_scope=occlusion_scope,
        frame_truncated=truncated,
    )
    tree_support = arrays["visible"].any(0) & labels["known"]
    missing_tree_depth = tree_support & ~depth["valid"]
    issues = list(focal["issues"])
    if missing_tree_depth.any():
        issues.append("known_visible_tree_pixels_missing_metric_depth")
    if require_complete_metrics and not metadata["metric_labels_complete"]:
        issues.append("requested_full_metric_labels_incomplete")
    for name, path in paths.items():
        if sha256_file(path) != hashes[name]:
            raise ValueError("input changed during qualification: " + name)
    report = _jsonable(
        {
            "schema_version": "treeweaver-metric-scene-qualification-1.0",
            "status": "complete",
            "checked_at_utc": datetime.now(UTC).isoformat(),
            "input_sha256": hashes,
            "source_sha256": {
                "qualifier": sha256_file(Path(__file__)),
                "contract": sha256_file(ROOT / "workers/tree_models/metric_dataset_contract.py"),
            },
            "qualification_passed": not issues,
            "issues": issues,
            "requested_profile": "full_metric"
            if require_complete_metrics
            else "segmentation_contracts",
            "native_image_wh": [width, height],
            "instance_order": identities,
            "rgb_file_dimensions_verified": "rgb" in paths,
            "ignored_npz_keys": ignored,
            "focal": focal,
            "instances": labels["instances"],
            "parts": parts,
            "depth": {
                "source_convention": document["depth"]["convention"],
                "unit": "m",
                "pixel_centers": depth["pixel_centers"],
                "valid_pixels": int(depth["valid"].sum()),
                "known_visible_tree_pixels": int(tree_support.sum()),
                "known_tree_pixels_missing_depth": int(missing_tree_depth.sum()),
            },
            "metadata_validation": metadata,
            "directional_occlusion_pixels": labels["directional_occlusion_pixels"],
            "bidirectional_pairs": labels["bidirectional_pairs"],
            "training_allowed": False,
            "geometric_truth_independently_verified": False,
            "renderer_source_declarations_independently_verified": False,
            "notes": [
                "Checks supplied raster/metadata contracts, not actual rendering correctness.",
                "Measured virtual geometry declarations require separate asset qualification.",
                "Source splits, visual realism and complete dataset admission remain unverified.",
                "No rendering, model execution, training or GPU work is performed.",
            ],
            "derived_arrays": "qualification.npz",
        }
    )
    output.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(
        output / "qualification.npz",
        owner=labels["owner"],
        hidden=labels["hidden"],
        known=labels["known"],
        tree_occluder=labels["tree_occluder"],
        other_occluder=labels["other_occluder"],
        occluder_valid=labels["occluder_valid"],
        camera_z_m=depth["camera_z_m"],
        ray_distance_m=depth["ray_distance_m"],
        depth_valid=depth["valid"],
        instance_ids=np.asarray(identities),
    )
    (output / "report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8",
    )
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scene", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rgb", type=Path)
    parser.add_argument("--focal-id", type=int)
    parser.add_argument(
        "--cohort",
        choices=("occluded_primary", "clear_control", "stress"),
        default="occluded_primary",
    )
    parser.add_argument("--occlusion-scope", choices=("tree", "total"), default="tree")
    parser.add_argument(
        "--allow-incomplete-metrics",
        action="store_true",
        help="Check segmentation contracts only; no full-metric or training admission.",
    )
    args = parser.parse_args(argv)
    try:
        report = qualify_scene(
            args.scene,
            args.labels,
            args.output,
            rgb_path=args.rgb,
            focal_id=args.focal_id,
            cohort=args.cohort,
            occlusion_scope=args.occlusion_scope,
            require_complete_metrics=not args.allow_incomplete_metrics,
        )
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.error(str(error))
    print(
        json.dumps(
            {
                "report": str(args.output.resolve() / "report.json"),
                "qualification_passed": report["qualification_passed"],
                "issues": report["issues"],
                "training_allowed": False,
            },
            ensure_ascii=False,
        )
    )
    return 0 if report["qualification_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
