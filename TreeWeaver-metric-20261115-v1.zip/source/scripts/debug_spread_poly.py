"""Diagnose predicted polygon vs GT on a training frame (throwaway)."""
from __future__ import annotations
import argparse, json, random, sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--checkpoint", type=Path, required=True)
parser.add_argument("--data-root", type=Path, default=Path("data/external/spread"))
parser.add_argument("--palette", type=Path, default=Path("data/external/spread/color_palette.json"))
parser.add_argument("--source", type=Path, default=Path("data/external/convexmask-source"))
parser.add_argument("--extra-packages", type=Path, default=Path(".worker-envs/convexmask-extra"))
parser.add_argument("--frames", type=int, default=48)
args = parser.parse_args()
sys.path.insert(0, str(args.extra_packages.resolve()))
sys.path.insert(0, str(args.source.resolve()))
import cv2
import numpy as np
import torch
import torch.nn.functional as functional
from data import cfg, set_cfg
torch.set_default_tensor_type(torch.cuda.FloatTensor)
set_cfg("convex_synthtree_focal")
cfg.max_size = (512, 512)
cfg.fixed_size = True
cfg.freeze_bn = True
cfg.mask_proto_debug = False
cfg.dataset.class_names = ("tree",)
from convexmask import ConvexMask
from layers.polar_utils import polar_target, polar2mask, detect_convex_indices

pal = {int(k): tuple(v) for k, v in json.loads(args.palette.read_text(encoding="utf-8"))["palette"].items()}

def build_frame(scene, stem):
    rgb_dir = args.data_root / scene / "rgb"
    idir = args.data_root / scene / "instance_segmentation"
    image = cv2.imread(str(rgb_dir / f"{stem}.png"))
    inst = cv2.cvtColor(cv2.imread(str(idir / f"{stem}.png")), cv2.COLOR_BGR2RGB)
    cands = []
    for line in (idir / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
        pr = line.split()
        if len(pr) == 2 and pr[0].startswith("Tree") and int(pr[1]) in pal:
            c = pal[int(pr[1])]
            mm = cv2.inRange(inst, np.array(c), np.array(c))
            a = int(mm.sum() // 255)
            if a >= 10:
                cands.append((a, mm, pr[0]))
    cands.sort(key=lambda x: x[0], reverse=True)
    cands = cands[:24]
    masks, boxes, hulls = [], [], []
    for _, mm, name in cands:
        mm = (cv2.resize(mm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
        ys, xs = np.nonzero(mm)
        if len(xs) < 10:
            continue
        cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        h = cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32) / 512
        masks.append(mm)
        hulls.append(h)
        boxes.append([xs.min()/512, ys.min()/512, (xs.max()+1)/512, (ys.max()+1)/512, 0])
    resized = cv2.resize(image, (512, 512)).astype(np.float32)
    resized = ((resized - np.array([103.94, 116.78, 123.68])) / np.array([57.38, 57.12, 58.40]))[:, :, ::-1].copy()
    tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)
    polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
    for i, h in enumerate(hulls):
        polys[i, :len(h)] = h
    return tensor, torch.tensor(boxes, dtype=torch.float32), torch.tensor(np.stack(masks), dtype=torch.float32), torch.tensor(polys, dtype=torch.float32)

model = ConvexMask().cuda()
model.load_state_dict(torch.load(args.checkpoint, map_location="cuda"))
model.train()

rng = random.Random(42)
frames = sorted(p.stem for p in (args.data_root / "birch_forest" / "rgb").glob("*.png"))
rng.shuffle(frames)
stems = frames[:2]

with torch.no_grad():
    for stem in stems:
        image, boxes, masks, polys = build_frame("birch_forest", stem)
        pred = model(image[None].cuda())
        points = pred["points"]
        rr = pred["regress_ranges"]
        img_size = pred["img_size"]
        lab, bbt, pt, idxt, cent = polar_target(
            boxes[:, :-1].cuda(), polys.cuda(),
            torch.zeros(len(boxes), dtype=torch.long).cuda(),
            points, rr, cfg.num_rays, img_size, None, cfg.radius, cfg.force_gt_attribute)
        pos = lab > 0
        print(f"=== {stem} objects={len(boxes)} pos_points={int(pos.sum())}")
        gt_poly = pt[pos]
        pred_poly = pred["polygon"][0][pos]
        # GT polygon masks
        gt_m = polar2mask(points[pos], gt_poly, (138, 138)) > 0.5
        pr_m = polar2mask(points[pos], pred_poly * (1 + cfg.extend_factor), (138, 138)) > 0.5
        gt_area = gt_m.sum((1, 2)).float()
        pr_area = pr_m.sum((1, 2)).float()
        inter = (gt_m & pr_m).sum((1, 2)).float()
        iou = inter / (gt_area + pr_area - inter).clamp_min(1)
        print(f"  GT poly area px mean={float(gt_area.mean()):.0f}  "
              f"pred poly area mean={float(pr_area.mean()):.0f}  "
              f"poly IoU mean={float(iou.mean()):.3f} max={float(iou.max()):.3f}")
        print(f"  pred ray sample {np.round(pred_poly[0].cpu().numpy()[::12], 3)}")
        print(f"  gt   ray sample {np.round(gt_poly[0].cpu().numpy()[::12], 3)}")
