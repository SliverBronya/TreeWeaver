"""Five-minute original-dataset diagnostic, never resume SPREAD checkpoints."""

import argparse
import copy
import hashlib
import json
import random
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--backbone", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=300)
    parser.add_argument("--evaluate-only", action="store_true")
    args = parser.parse_args()
    if (args.output.exists() and not args.evaluate_only) or not 1 <= args.seconds <= 300:
        parser.error("Fresh output required; diagnostic budget is 1..300 seconds")
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from pycocotools import mask as mask_utils
    from pycocotools.cocoeval import COCOeval

    from data import cfg, set_cfg

    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (512, 288)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    cfg.dataset.label_map = {0: 1}
    from convexmask import ConvexMask
    from data.coco import COCODetection
    from layers.modules.multibox_loss import MultiBoxLoss
    from layers.output_utils import postprocess
    from utils.augmentations import BaseTransform, FastBaseTransform

    args.output.mkdir(parents=True, exist_ok=args.evaluate_only)
    root = args.data_root.resolve()
    rgb_root = root / "test_set"  # Archive folder name does not define membership.
    label_root = root / "annotations"
    datasets = {}
    inventory = {}
    filename_sets = {}
    for split in ("train", "val", "test"):
        label_path = label_root / f"{split}_RGB_entire_tree.json"
        if split == "test":
            # Check presence/split only. No test inference or model selection.
            document = json.loads(label_path.read_text())
            filenames = {image["file_name"] for image in document["images"]}
            instances = len(document["annotations"])
            del document
        else:
            dataset = COCODetection(
                str(rgb_root), str(label_path), transform=BaseTransform(resize_gt=True)
            )
            datasets[split] = dataset
            filenames = {image["file_name"] for image in dataset.coco.imgs.values()}
            instances = len(dataset.coco.anns)
        missing = [name for name in filenames if not (rgb_root / name).is_file()]
        if missing:
            raise FileNotFoundError(
                f"{split}: {len(missing)} missing RGB files, e.g. {missing[:3]}"
            )
        filename_sets[split] = filenames
        inventory[split] = {
            "images": len(filenames),
            "instances": instances,
            "missing_rgb": len(missing),
            "annotation_sha256": hashlib.sha256(label_path.read_bytes()).hexdigest(),
        }
    if any(
        filename_sets[a] & filename_sets[b]
        for a, b in [("train", "val"), ("train", "test"), ("val", "test")]
    ):
        raise ValueError("Source splits overlap by filename")
    manifest = {
        "dataset": "SynthTree43k author whole-tree annotations",
        "inventory": inventory,
        "source_root": str(args.source.resolve()),
        "image_size": [512, 288],
        "initialization": "ImageNet ResNet50 only; all detector heads initialized anew",
        "backbone_sha256": hashlib.sha256(args.backbone.read_bytes()).hexdigest(),
        "spread_weights_loaded": False,
        "old_experiments_deleted": False,
        "budget_seconds": args.seconds,
        "seed": 42,
        "optimizer": "AdamW lr=1e-4 weight_decay=1e-4",
        "batch_size": 1,
        "augmentation": "upstream deterministic BaseTransform; no random augmentation",
        "paper_reproduction_completed": False,
        "test_images_used_for_inference_or_training": False,
    }
    if args.evaluate_only:
        previous = json.loads((args.output / "manifest.json").read_text())
        if previous != manifest:
            raise ValueError("Evaluation-only configuration differs from saved training manifest")
    else:
        (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps({"inventory": inventory}), flush=True)
    model = ConvexMask().cuda()
    model.train()  # Upstream override returns None, unlike torch's usual train().
    pretrained = torch.load(args.backbone, weights_only=True, map_location="cuda")
    remapped = {}
    for key, value in pretrained.items():
        if key.startswith("fc."):
            continue
        if key.startswith("layer"):
            key = "layers." + str(int(key[5]) - 1) + key[6:]
        remapped[key] = value
    model.backbone.load_state_dict(remapped, strict=True)
    del pretrained, remapped
    if args.evaluate_only:
        model.load_state_dict(
            torch.load(
                args.output / "pilot_checkpoint.pth", weights_only=True, map_location="cuda"
            ),
            strict=True,
        )
    criterion = MultiBoxLoss(2, cfg.num_rays, cfg.ohem_negpos_ratio)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    train = datasets["train"]
    indices = list(range(len(train)))
    random.shuffle(indices)
    history = json.loads((args.output / "history.json").read_text()) if args.evaluate_only else []
    seen_ids = {row["image_id"] for row in history}
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    while not args.evaluate_only and time.perf_counter() - started < args.seconds:
        step = len(history)
        image, (target, masks, polygons, crowds), image_id = train[indices[step % len(indices)]]
        optimizer.zero_grad(set_to_none=True)
        losses = criterion(
            model,
            model(image.cuda().float()[None]),
            [torch.as_tensor(target, dtype=torch.float32, device="cuda")],
            [torch.as_tensor(masks, dtype=torch.float32, device="cuda")],
            [torch.as_tensor(polygons, dtype=torch.float32, device="cuda")],
            [int(crowds)],
        )
        total = sum(losses.values())
        if not torch.isfinite(total):
            raise FloatingPointError("Non-finite loss")
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
        optimizer.step()
        torch.cuda.synchronize()
        seen_ids.add(image_id)
        row = {
            "step": step + 1,
            "image_id": image_id,
            "instances": len(target),
            "elapsed_seconds": time.perf_counter() - started,
            "loss": float(total.detach()),
            "components": {key: float(value.detach()) for key, value in losses.items()},
        }
        history.append(row)
        if step % 50 == 0:
            print(json.dumps(row), flush=True)
            (args.output / "history.json").write_text(json.dumps(history))
    elapsed = (
        history[-1]["elapsed_seconds"] if args.evaluate_only else time.perf_counter() - started
    )
    if not args.evaluate_only:
        torch.save(model.state_dict(), args.output / "pilot_checkpoint.pth")
        (args.output / "history.json").write_text(json.dumps(history, indent=2))
    # Predicted scores/masks are produced without GT; GT is used only by COCO evaluation.
    validation = datasets["val"]
    val_ids = sorted(validation.coco.imgs)[:20]
    transform = FastBaseTransform()
    predictions, image_rows = [], []
    with torch.inference_mode():
        for image_id in val_ids:
            info = validation.coco.imgs[image_id]
            original = cv2.imread(str(rgb_root / info["file_name"]))
            if original is None or original.shape[:2] != (info["height"], info["width"]):
                raise ValueError("RGB decode/dimension mismatch")
            height, width = original.shape[:2]
            raw = model(transform(torch.as_tensor(original).float()[None]))
            raw["conf"], raw["center"] = raw["conf"].sigmoid(), raw["center"].sigmoid()
            detected = postprocess(model.detect(raw, model), width, height, score_threshold=0.05)
            overlay = original.copy()
            for index in range(detected[0].numel()):
                mask = detected[4][index].bool().cpu().numpy()
                encoded = mask_utils.encode(np.asfortranarray(mask.astype(np.uint8)))
                encoded["counts"] = encoded["counts"].decode("ascii")
                score = float(detected[1][index])
                predictions.append(
                    {
                        "image_id": image_id,
                        "category_id": 0,
                        "score": score,
                        "segmentation": encoded,
                    }
                )
                if score >= 0.3:
                    color = np.array(
                        [
                            (index * 73 + 70) % 256,
                            (index * 43 + 120) % 256,
                            (index * 91 + 180) % 256,
                        ]
                    )
                    overlay[mask] = (0.6 * overlay[mask] + 0.4 * color).astype(np.uint8)
            cv2.imwrite(
                str(args.output / f"{Path(info['file_name']).stem}_prediction.png"), overlay
            )
            image_rows.append(
                {
                    "image_id": image_id,
                    "filename": info["file_name"],
                    "detections_above_005": int(detected[0].numel()),
                }
            )
    stats = None
    if predictions:
        validation.coco.dataset.setdefault("info", {})
        result = validation.coco.loadRes(copy.deepcopy(predictions))
        evaluation = COCOeval(validation.coco, result, "segm")
        evaluation.params.imgIds = val_ids
        evaluation.evaluate()
        evaluation.accumulate()
        evaluation.summarize()
        stats = evaluation.stats.tolist()
    (args.output / "validation_predictions.json").write_text(json.dumps(predictions))
    report = {
        **manifest,
        "completed_steps": len(history),
        "unique_train_images_seen": len(seen_ids),
        "actual_training_seconds": elapsed,
        "peak_gpu_allocated_mb": None
        if args.evaluate_only
        else torch.cuda.max_memory_allocated() / 1024**2,
        "mean_first_50_loss": float(np.mean([r["loss"] for r in history[:50]])),
        "mean_last_50_loss": float(np.mean([r["loss"] for r in history[-50:]])),
        "validation": {
            "images": image_rows,
            "coco_segm_stats": stats,
            "no_detections": not predictions,
            "score_floor": 0.05,
            "overlay_score_floor": 0.3,
            "scope": "20-image validation diagnostic, not full benchmark",
        },
        "metric_measurement_accuracy_evaluated": False,
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2))
    print(
        json.dumps(
            {
                "completed_steps": len(history),
                "training_seconds": elapsed,
                "validation_coco_stats": stats,
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
