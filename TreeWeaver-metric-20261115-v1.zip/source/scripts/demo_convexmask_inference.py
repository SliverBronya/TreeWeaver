"""Diagnostic ConvexMask inference with the preprocessing a checkpoint was trained with.

This is a visual diagnostic, not an accuracy benchmark: no ground truth is read here.
Masks, convex polygons, scores and mask/polygon density are exported per image so the
result can be inspected and compared with a provider run.

The upstream checkout must stay in a separate process (it sets a process-wide CUDA
default tensor type), so this script is run with the isolated worker Python plus the
``convexmask-extra`` package overlay.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np


def _parse_size(text: str) -> tuple[int, int]:
    try:
        width, height = (int(part) for part in text.lower().split("x"))
    except ValueError as exc:
        raise SystemExit("--max-size must look like 512x288") from exc
    if width < 128 or height < 128 or width % 8 or height % 8:
        raise SystemExit("--max-size sides must be >= 128 and divisible by 8")
    return width, height


def _polygon_area(points: np.ndarray) -> float:
    x, y = points[:, 0], points[:, 1]
    return float(abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1))) / 2.0)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--images", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", default="convex_synthtree_focal")
    parser.add_argument("--max-size", default="512x288")
    parser.add_argument("--score-threshold", type=float, default=0.3)
    parser.add_argument("--amp", action="store_true")
    parser.add_argument(
        "--inference-mode",
        choices=("eval", "train"),
        default="eval",
        help=(
            "eval is the standard path; train reproduces the trainer's validation path for "
            "checkpoints whose BatchNorm running statistics were never updated (freeze_bn)"
        ),
    )
    parser.add_argument("--label", default="", help="short human-readable run label")
    args = parser.parse_args()

    width, height = _parse_size(args.max_size)
    if not 0 < args.score_threshold <= 1:
        raise SystemExit("--score-threshold must be in (0, 1]")
    if not args.checkpoint.is_file():
        raise SystemExit(f"missing checkpoint: {args.checkpoint}")
    if args.output.exists():
        raise SystemExit(f"output directory already exists: {args.output}")
    source = args.source.resolve()
    if not (source / "convexmask.py").is_file():
        raise SystemExit(f"not a ConvexMask checkout: {source}")

    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(source))

    import cv2
    import torch

    if not torch.cuda.is_available():
        raise SystemExit("upstream ConvexMask currently requires CUDA")
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    torch.manual_seed(42)

    from data import cfg, set_cfg

    set_cfg(args.config)
    cfg.max_size = (width, height)
    cfg.fixed_size = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)

    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    net = ConvexMask().cuda()
    checkpoint = torch.load(args.checkpoint, map_location="cuda", weights_only=True)
    state = checkpoint.get("model", checkpoint.get("state_dict", checkpoint))
    known = net.state_dict()
    dropped = sorted(key for key in state if key not in known)
    state = {key: value for key, value in state.items() if key in known}
    net.load_state_dict(state, strict=True)
    net.eval()
    transform = FastBaseTransform()
    if args.inference_mode == "train":
        net.train()

    args.output.mkdir(parents=True)
    palette = [(255, 100, 30), (30, 200, 70), (40, 80, 255), (220, 40, 190), (0, 220, 220)]
    report: dict[str, object] = {
        "mode": "diagnostic_inference",
        "accuracy_measured": False,
        "ground_truth_used": False,
        "label": args.label,
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "configuration": args.config,
        "max_size_wh": [width, height],
        "score_threshold": args.score_threshold,
        "inference_mode": args.inference_mode,
        "amp": bool(args.amp),
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0),
        "dropped_checkpoint_keys": dropped,
        "images": [],
    }

    with torch.inference_mode():
        for path in args.images:
            original = cv2.imread(str(path.resolve()))
            if original is None:
                raise SystemExit(f"cannot read image: {path}")
            h, w = original.shape[:2]
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            started = time.perf_counter()
            batch = transform(torch.as_tensor(original, device="cuda").float()[None])
            with torch.autocast("cuda", dtype=torch.bfloat16, enabled=args.amp):
                if args.inference_mode == "train":
                    raw = net(batch)
                    raw["conf"] = raw["conf"].sigmoid()
                    raw["center"] = raw["center"].sigmoid()
                    predictions = net.detect(raw, net)
                else:
                    predictions = net(batch)
                result = postprocess(predictions, w, h, score_threshold=args.score_threshold)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - started
            classes, scores, centers, boxes, masks, polygons = result
            masks_np = masks.detach().float().cpu().numpy() > 0.5
            polygons_np = polygons.detach().float().cpu().numpy()
            overlay = original.copy()
            instances = []
            for index in range(classes.shape[0]):
                mask = masks_np[index]
                polygon = polygons_np[index]
                area = int(mask.sum())
                polygon_area = _polygon_area(polygon)
                color = np.array(palette[index % len(palette)], dtype=np.float32)
                overlay[mask] = (0.55 * overlay[mask] + 0.45 * color).astype(np.uint8)
                cv2.polylines(
                    overlay,
                    [np.round(polygon).astype(np.int32)],
                    isClosed=True,
                    color=tuple(int(value) for value in color[::-1]),
                    thickness=2,
                )
                mask_name = f"{path.stem}_instance_{index + 1:03d}_mask.png"
                if not cv2.imwrite(str(args.output / mask_name), mask.astype(np.uint8) * 255):
                    raise SystemExit(f"cannot write mask: {args.output / mask_name}")
                instances.append(
                    {
                        "instance": index + 1,
                        "class": int(classes[index]),
                        "score": float(scores[index]),
                        "centerness": float(centers[index]),
                        "bbox_xyxy": [float(value) for value in boxes[index].tolist()],
                        "mask_path": mask_name,
                        "mask_area_px": area,
                        "polygon_area_px": polygon_area,
                        "visible_over_polygon": area / max(polygon_area, 1.0),
                        "polygon_xy": [[round(float(x), 1), round(float(y), 1)] for x, y in polygon],
                    }
                )
            overlay_name = f"{path.stem}_overlay.png"
            if not cv2.imwrite(str(args.output / overlay_name), overlay):
                raise SystemExit(f"cannot write overlay: {args.output / overlay_name}")
            entry = {
                "image": str(path.resolve()),
                "original_wh": [w, h],
                "network_input_shape": [int(value) for value in batch.shape[1:]],
                "elapsed_seconds": elapsed,
                "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
                "detections": int(classes.shape[0]),
                "overlay": overlay_name,
                "instances": instances,
            }
            report["images"].append(entry)
            print(
                json.dumps(
                    {
                        "image": path.name,
                        "network_input_shape": entry["network_input_shape"],
                        "detections": entry["detections"],
                        "scores": [round(item["score"], 3) for item in instances],
                        "visible_over_polygon": [
                            round(item["visible_over_polygon"], 3) for item in instances
                        ],
                        "elapsed_seconds": round(elapsed, 3),
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )

    (args.output / "run.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"saved: {args.output / 'run.json'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
