"""Convert explicitly reviewed human polygons to an evaluation-only manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from treeweaver.datasets.real_annotations import rasterize_human_labelme  # noqa: E402


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a fresh GT output directory")
    source = args.pack.resolve()
    manifest = json.loads((source / "manifest.json").read_text(encoding="utf-8"))
    prepared = []
    for record in manifest["records"]:
        if not re.fullmatch(r"[A-Za-z0-9_-]+", str(record["image_id"])):
            raise ValueError("Image IDs must be filename-safe")
        annotation = source / record["annotation"]
        label = json.loads(annotation.read_text(encoding="utf-8"))
        if label.get("treeweaver_review", {}).get("state") != "approved":
            continue
        if record["split"] != "validation":
            raise ValueError("This existing-photo pack is development validation only")
        image = source / record["image"]
        if (
            digest(image) != record["image_sha256"]
            or label.get("source_image_sha256") != record["image_sha256"]
        ):
            raise ValueError("Source image changed after queue creation")
        rgb = cv2.imread(str(image))
        if rgb is None or rgb.shape[:2] != (label["imageHeight"], label["imageWidth"]):
            raise ValueError("Annotation dimensions do not match original RGB")
        prepared.append((record, annotation, label, rasterize_human_labelme(label)))
    if not prepared:
        raise ValueError("No explicitly approved human annotations; no GT exported")
    output = args.output.resolve()
    records = []
    for record, annotation, label, masks in prepared:
        folder = output / "ground_truth" / record["image_id"]
        folder.mkdir(parents=True)
        copy = folder / "source.labelme.json"
        shutil.copy2(annotation, copy)
        instances = []
        hashes = {}
        for index, item in enumerate(masks["instances"], 1):
            mask_keys = {"visible", "occluded", "complete", "stem", "stem_occluded"}
            entry = {k: v for k, v in item.items() if k not in mask_keys}
            for key in ("visible", "occluded", "complete", "stem", "stem_occluded"):
                if item.get(key) is not None:
                    dest = folder / f"{key}_{index}.png"
                    if not cv2.imwrite(str(dest), item[key].astype("uint8") * 255):
                        raise OSError(f"Cannot write {dest}")
                    entry[f"{key}_mask"] = str(dest)
                    hashes[str(dest)] = digest(dest)
            instances.append(entry)
        for name, data in (
            ("unknown", masks["unknown"].astype("uint8") * 255),
            ("ownership", masks["ownership"]),
        ):
            dest = folder / f"{name}.png"
            if not cv2.imwrite(str(dest), data):
                raise OSError(f"Cannot write {dest}")
            hashes[str(dest)] = digest(dest)
        records.append(
            {
                "image_id": record["image_id"],
                "image": str(source / record["image"]),
                "image_sha256": record["image_sha256"],
                "split": "validation",
                "annotation_coverage": label["treeweaver_coverage"],
                "prompt_source": "human_annotation_with_box_provenance",
                "instances": instances,
                "unknown_mask": str(folder / "unknown.png"),
                "ownership_mask": str(folder / "ownership.png"),
                "review": {
                    "status": "human_verified",
                    "reviewer": label["treeweaver_review"]["reviewer"],
                    "source": "human_annotation",
                    "source_annotation": str(copy),
                    "annotation_sha256": digest(copy),
                    "mask_sha256": hashes,
                },
            }
        )
    (output / "manifest.json").write_text(
        json.dumps(
            {"schema_version": "treeweaver-real-multitree-1.0", "records": records}, indent=2
        ),
        encoding="utf-8",
    )
    print(json.dumps({"reviewed_images": len(records), "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
