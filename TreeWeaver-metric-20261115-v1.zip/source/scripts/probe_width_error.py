"""Measurement-relevant probe: horizontal trunk width error, not just IoU.

IoU rewards covering everything the annotator filled. What a diameter estimate
needs is the two trunk edges at a row. This probe compares predicted and GT trunk
widths at fixed relative rows of each trunk box, for the same three observation
windows as the ladder:

* ``full``      - whole frame;
* ``strip``     - vertical strip crop (larger effective resolution);
* ``strip+pos`` - strip crop plus a base-of-trunk point.

An optional checkpoint (e.g. the strip-trained decoder) is evaluated on all three
windows, which separates "the model improved" from "the model only works inside
the window".

Reported per condition: relative width error (mean/median), signed bias, and the
share of rows where the width error exceeds 10%.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from probe_canatree_adhesion import REVISION, base_point, decode_image, load_fold  # noqa: E402
from probe_crop_refine import run_full, run_strip  # noqa: E402
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from stem_eval_common import write_json  # noqa: E402

CONDITIONS = ("full", "strip", "strip+pos")
RELATIVE_ROWS = (0.45, 0.55, 0.65, 0.75, 0.85)


def row_window(mask_width: int, box, x_expansion: float = 0.5) -> tuple[int, int]:
    """Column window around the trunk box, widened so a merged neighbour shows up."""
    x0, _, x1, _ = [int(round(value)) for value in box]
    margin = int(round(x_expansion * max(1, x1 - x0)))
    return max(0, x0 - margin), min(mask_width, x1 + margin)


def row_profile(mask: np.ndarray, box, height: int, x_expansion: float = 0.5) -> dict:
    x0, y0, x1, y1 = [int(round(value)) for value in box]
    box_height = max(1, y1 - y0)
    left, right = row_window(mask.shape[1], box, x_expansion)
    profile = {}
    for fraction in RELATIVE_ROWS:
        row = int(min(height - 1, max(0, y0 + fraction * box_height)))
        profile[fraction] = float(mask[row, left:right].sum())
    return profile


def width_errors(predicted: np.ndarray, target: np.ndarray, box, height: int) -> list[dict]:
    pred_profile = row_profile(predicted, box, height)
    gt_profile = row_profile(target, box, height)
    rows = []
    for fraction in RELATIVE_ROWS:
        gt_width = gt_profile[fraction]
        if gt_width < 3:  # too thin to define edges; excluded and counted
            continue
        pred_width = pred_profile[fraction]
        rows.append(
            {
                "relative_row": fraction,
                "gt_width_px": gt_width,
                "pred_width_px": pred_width,
                "error_px": pred_width - gt_width,
                "relative_error": abs(pred_width - gt_width) / gt_width,
            }
        )
    return rows


def summarise(rows: list[dict]) -> dict:
    if not rows:
        return {"rows": 0}
    errors = np.array([row["relative_error"] for row in rows])
    signed = np.array([row["error_px"] for row in rows])
    widths = np.array([row["gt_width_px"] for row in rows])
    return {
        "rows": len(rows),
        "mean_relative_error": float(errors.mean()),
        "median_relative_error": float(np.median(errors)),
        "mean_signed_error_px": float(signed.mean()),
        "mean_abs_error_px": float(np.abs(signed).mean()),
        "rows_over_10pct": float((errors > 0.10).mean()),
        "mean_gt_width_px": float(widths.mean()),
        "relative_error_by_width_quintile": [
            {
                "mean_gt_width_px": float(widths[chunk].mean()),
                "mean_relative_error": float(errors[chunk].mean()),
            }
            for chunk in np.array_split(np.argsort(widths), 5)
            if len(chunk)
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--splits", nargs="+", default=["val", "test"])
    parser.add_argument("--checkpoint", type=Path, default=None)
    parser.add_argument("--x-margin", type=float, default=5.0)
    parser.add_argument("--y-margin", type=float, default=0.05)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    documents = {split: load_fold(split) for split in args.splits}
    protocol = {
        "schema_version": "treeweaver-width-probe-1.0",
        "purpose": "measure trunk-width error, the quantity a diameter estimate needs",
        "ladder_step": 6,
        "conditions": list(CONDITIONS),
        "rows": {
            "relative_height_from_box_top": list(RELATIVE_ROWS),
            "width_px": "count of mask pixels in the row inside the GT box columns",
            "exclusion": "GT rows narrower than 3 px are dropped and counted separately",
        },
        "crop": {"x_margin": args.x_margin, "y_margin": args.y_margin},
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "checkpoint": str(args.checkpoint) if args.checkpoint else None,
            "checkpoint_sha256": sha256_file(args.checkpoint) if args.checkpoint else None,
        },
        "question": (
            "does the checkpoint improve width error on the full frame too, or only "
            "inside the window it was trained on?"
        ),
        "splits": {
            split: {"fold_file_sha256": sha256_file(document[2]), "images": len(document[0])}
            for split, document in documents.items()
        },
        "limitations": [
            "row width is a diameter proxy, not a calibrated breast-height diameter",
            "GT fill convention (polygon across occluders) is inherited from the release",
            "GT-derived box prompts; development split only",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    models = {"stock_sam2": sam2}
    if args.checkpoint is not None:
        tuned = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
        payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
        tuned.mask_decoder.load_state_dict(payload["decoder"])
        models["finetuned"] = tuned

    prepared_by_split = {}
    for split, (by_image, grouped, _) in documents.items():
        prepared = []
        for image_id, image in by_image.items():
            image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
            pixels = processor(
                images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)),
                return_tensors="pt",
            )["pixel_values"].to(args.device)
            prepared.append(
                {
                    "name": image["file_name"],
                    "image_bgr": image_bgr,
                    "boxes": boxes,
                    "masks": masks,
                    "height": height,
                    "width": width,
                    "pixels": pixels,
                    "points": np.stack(
                        [
                            np.asarray(base_point(masks[index], boxes[index]), np.float32)
                            for index in range(len(boxes))
                        ]
                    ),
                }
            )
        prepared_by_split[split] = prepared

    summary = {
        "conditions": list(CONDITIONS),
        "results": {},
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
    }
    for model_name, model in models.items():
        summary["results"][model_name] = {}
        for split, prepared in prepared_by_split.items():
            for condition in CONDITIONS:
                rows = []
                for frame in prepared:
                    if condition == "full":
                        predicted = run_full(
                            model, frame["pixels"], frame["boxes"], frame["height"], frame["width"]
                        )
                    else:
                        predicted = np.stack(
                            [
                                run_strip(
                                    model,
                                    processor,
                                    frame["image_bgr"],
                                    frame["boxes"][index],
                                    frame["points"][index] if condition == "strip+pos" else None,
                                    args.device,
                                    args.x_margin,
                                    args.y_margin,
                                )
                                for index in range(len(frame["masks"]))
                            ]
                        )
                    for index in range(len(frame["masks"])):
                        for row in width_errors(
                            predicted[index],
                            frame["masks"][index],
                            frame["boxes"][index],
                            frame["height"],
                        ):
                            rows.append({"image": frame["name"], "tree_index": index, **row})
                summary["results"][model_name].setdefault(split, {})[condition] = summarise(rows)
                print(
                    json.dumps(
                        {
                            "model": model_name,
                            "split": split,
                            "condition": condition,
                            **summary["results"][model_name][split][condition],
                        }
                    ),
                    flush=True,
                )
                write_json(
                    args.output
                    / f"width_rows_{model_name}_{split}_{condition.replace('+', '_')}.json",
                    rows,
                )
                write_json(args.output / "summary.json", summary)

    print(
        "DONE",
        json.dumps(
            {
                model_name: {
                    f"{split}/{condition}": summary["results"][model_name][split][condition].get(
                        "mean_relative_error"
                    )
                    for split in summary["results"][model_name]
                    for condition in CONDITIONS
                }
                for model_name in summary["results"]
            }
        ),
    )


if __name__ == "__main__":
    main()
