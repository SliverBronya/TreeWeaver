"""Verify encoder LoRA/PromptFocus are actually in the optimizer and get gradients."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from train_stage12 import DATA, FigDataset, snapshot, visible_loss  # noqa: E402


def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    path = snapshot()
    processor = Sam2Processor.from_pretrained(path, local_files_only=True)
    mean = processor.image_processor.image_mean
    std = processor.image_processor.image_std
    sam2 = Sam2Model.from_pretrained(path, local_files_only=True).to(device).eval()
    model = Sam2OcclusionModel(
        sam2,
        knots=12,
        experts=3,
        encoder_lora_rank=4,
        principal_focus=True,
    ).to(device)
    checkpoint = torch.load(
        ROOT / "reports" / "professional-stage2-ownership-2026-11-06" / "best.pth",
        map_location="cpu",
    )
    model.decoder.load_state_dict(checkpoint["decoder"], strict=False)

    parameters = []
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(False)
        if "lora" in name or name.startswith("prompt_focus"):
            parameter.requires_grad_(True)
            parameters.append((name, parameter))

    ids = sorted(int(p.stem) for p in (DATA / "meta").glob("*.json"))[:1]
    batch = next(iter(DataLoader(FigDataset(ids, mean, std), batch_size=1)))
    optimizer = torch.optim.AdamW([p for _, p in parameters], lr=1e-3)
    optimizer.zero_grad(set_to_none=True)
    output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
    loss = visible_loss(output["masks"], batch["visible"].to(device))
    loss.backward()
    grad_norms = {name: float(p.grad.norm()) for name, p in parameters if p.grad is not None}
    nonzero = {name: value for name, value in grad_norms.items() if value > 0}
    optimizer.step()
    result = {
        "trainable_tensors": len(parameters),
        "trainable_parameters": sum(p.numel() for _, p in parameters),
        "tensors_with_grad": len(nonzero),
        "loss": float(loss.detach()),
        "sample_grads": dict(list(nonzero.items())[:5]),
    }
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
