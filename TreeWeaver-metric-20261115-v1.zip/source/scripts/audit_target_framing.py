"""Train-only native mask geometry for framing design, no model inference."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]


def main():
    report={}
    for name in ['fig-paired-v6-framing-30-2026-11-08','mixed-tree-grounded-qualification-2026-11-08',
                 'dense-mixed-portrait-qualification-2026-11-08','mixed-identity-layout-qualification-2026-11-08']:
        root=ROOT/'reports'/name;rows=[]
        for path in sorted((root/'meta').glob('*.json')):
            meta=json.loads(path.read_text())
            if meta['split']!='train':continue
            for query in range(1,meta['count']+1):
                with Image.open(root/'masks'/f"{meta['id']:06d}"/f'amodal_{query}.png') as im:
                    mask=np.asarray(im.getchannel('A'))>16
                ys,xs=np.nonzero(mask)
                rows.append({'scene':meta['id'],'tree':query,'height_fraction':float((ys.max()-ys.min()+1)/mask.shape[0]),
                             'width_fraction':float((xs.max()-xs.min()+1)/mask.shape[1]),'area_fraction':float(mask.mean())})
        values=[r['height_fraction'] for r in rows]
        report[name]={'train_target_appearances':len(rows),'height_fraction_quantiles':np.quantile(values,[0,.25,.5,.75,1]).tolist(),
                      'below_045':sum(v<.45 for v in values),'records':rows}
    out=ROOT/'reports/two-hour-development-2026-11-09/target-framing-train-only.json'
    out.write_text(json.dumps({'scope':'train role only; repeated assets/scene variants are not independent trees',
                              'model_inference':False,'test_masks_read':False,'datasets':report},indent=2),encoding='utf-8')
    print({k:{q:v for q,v in r.items() if q!='records'} for k,r in report.items()})


if __name__=='__main__':main()
