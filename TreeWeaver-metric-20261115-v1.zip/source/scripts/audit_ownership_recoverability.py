"""CPU-only error attribution from existing validation predictions, no inference."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from ownership_diagnostics import error_partition, oracle_active_decode  # noqa: E402
from research_protocol import sha256_file  # noqa: E402


def read_mask(root, relative):
    with Image.open(root / relative) as image:
        return np.asarray(image.getchannel("A")) > 16


def metrics(prediction, target, known):
    rows = []
    target = target & known
    for q, (p, t) in enumerate(zip(prediction & known, target, strict=True)):
        foreign = np.delete(target, q, 0).any(0)
        rows.append(
            {
                "iou": float((p & t).sum() / max((p | t).sum(), 1)),
                "recall": float((p & t).sum() / max(t.sum(), 1)),
                "neighbour_fraction": float((p & foreign).sum() / max(p.sum(), 1)),
            }
        )
    return rows


def main():
    data = ROOT / "reports/fig-paired-v6-framing-30-2026-11-08"
    raw_root = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage"
    candidate_root = (
        ROOT / "reports/ownership-query-feature-ablation-2026-11-08/predictions-seed108"
    )
    out = ROOT / "reports/ownership-recoverability-2026-11-09"
    out.mkdir(exist_ok=True)
    records = json.loads((data / "paired-samples.json").read_text(encoding="utf-8"))["records"]
    rows, summary_rows, hashes = [], {}, {}
    for record in records:
        if (
            record["split"] != "validation"
            or record["condition"] != "scene"
            or len(record["instances"]) < 2
        ):
            continue
        identifier = record["id"]
        raw_path, candidate_path = (
            raw_root / (identifier + ".npz"),
            candidate_root / (identifier + ".npz"),
        )
        hashes[str(raw_path.relative_to(ROOT))] = sha256_file(raw_path)
        hashes[str(candidate_path.relative_to(ROOT))] = sha256_file(candidate_path)
        with np.load(raw_path) as payload:
            raw = payload["logits"]
        target = np.stack([read_mask(data, item["visible"]) for item in record["instances"]])
        known = ~np.stack(
            [read_mask(data, item["raster_unknown"]) for item in record["instances"]]
        ).any(0)
        active = (raw > 0) & known
        winner = raw.argmax(0)
        baseline = (np.arange(len(raw))[:, None, None] == winner) & active.any(0)
        with np.load(candidate_path) as payload:
            if not np.array_equal(payload["known"], known) or not np.array_equal(
                payload["baseline"], baseline
            ):
                raise ValueError("saved comparison does not match the existing frozen raw masks")
            candidate = payload["candidate"]
        oracle = oracle_active_decode(active, baseline, target, known)
        for variant, prediction in (
            ("independent", active),
            ("mask_winner", baseline),
            ("query_seed108", candidate),
            ("GT_active_query_upper_bound", oracle),
        ):
            summary_rows.setdefault(variant, []).extend(metrics(prediction, target, known))
        for part in ("whole", "crown", "stem"):
            truth = (
                target
                if part == "whole"
                else np.stack(
                    [
                        read_mask(data, item["visible_" + part])
                        & ~read_mask(data, item["visible_part_unknown"])
                        for item in record["instances"]
                    ]
                )
            )
            for variant, prediction in (("mask_winner", baseline), ("query_seed108", candidate)):
                partition = error_partition(active, prediction, truth, known)
                rows.extend(
                    {"scene": identifier, "query": q + 1, "part": part, "variant": variant, **value}
                    for q, value in enumerate(partition)
                )
    summary = {
        name: {key: float(np.mean([r[key] for r in values])) for key in values[0]}
        for name, values in summary_rows.items()
    }
    partitions = {}
    for part in ("whole", "crown", "stem"):
        partitions[part] = {}
        for variant in ("mask_winner", "query_seed108"):
            selected = [row for row in rows if row["part"] == part and row["variant"] == variant]
            sums = {
                key: sum(row[key] for row in selected)
                for key in (
                    "target_pixels",
                    "correct",
                    "no_query_predicts_foreground",
                    "only_foreign_queries_active",
                    "recoverable_assignment_error",
                )
            }
            fn = sums["target_pixels"] - sums["correct"]
            partitions[part][variant] = {
                **sums,
                "fraction_of_FN_recoverable_by_active_query_ownership": sums[
                    "recoverable_assignment_error"
                ]
                / max(fn, 1),
                "micro_recall": sums["correct"] / max(sums["target_pixels"], 1),
            }
    # The later standalone prediction archive matches the raw archive bitwise.
    # Its macro scores need not be bitwise identical to the earlier cached pass.
    reference = json.loads((candidate_root.parent / "results.json").read_text())["controls"][
        "mask_winner"
    ]
    delta = {
        key: summary["mask_winner"][key] - reference[key]
        for key in ("iou", "recall", "neighbour_fraction")
    }
    result = {
        "scope": "8 pre-existing v6 multi-tree development-validation scenes, 23 instances",
        "new_inference": False,
        "new_training": False,
        "test_accessed": False,
        "source_prediction_sha256": hashes,
        "archive_consistency": {
            "raw_archive_vs_later_review_baseline_bitwise_equal": True,
            "delta_vs_original_cached_evaluation": delta,
            "original_cached_evaluation_reproduced_exactly": all(x == 0 for x in delta.values()),
            "difference_cause_verified": False,
            "primary_experiment_metrics_overwritten": False,
        },
        "macro_instance_metrics": summary,
        "micro_pixel_partitions": partitions,
        "records": rows,
        "interpretation": {
            "upper_bound_uses_GT": True,
            "upper_bound_is_deployable_model": False,
            "no_query_predicts_foreground": (
                "visible coverage missing; ownership preserving the union cannot create it"
            ),
            "only_foreign_queries_active": (
                "correct query never proposed the pixel; active-query ownership cannot fix it"
            ),
            "recoverable_assignment_error": (
                "correct query is active, but ownership assigned a different query"
            ),
            "background_false_positives": (
                "all variants keep foreground union, so this diagnostic cannot remove them"
            ),
            "macro_vs_micro": (
                "experiment metrics average instances; partitions sum pixels; these differ"
            ),
        },
    }
    (out / "results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"metrics": summary, "whole_partition": partitions["whole"]}))


if __name__ == "__main__":
    main()
