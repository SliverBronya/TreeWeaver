"""Download author's linked whole-tree labels; never substitute trunk labels."""

import hashlib
import json
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path("D:/TreeWeaver/data/external/synthtree43k")
FILES = {
    "val": "1doTRoLvQ1pGaNb75mx-SOr5aEVBLNnZe",
    "test": "1ZMYqFylSrx2KDHR-2TSoXFq-_uoyb6Qp",
    "train": "1AZUtdrNJGPWgqEwUrRin6OKwE_KGavZq",
}


def fetch(item):
    split, identifier = item
    destination = ROOT / "annotations" / f"{split}_RGB_entire_tree.json"
    partial = destination.with_suffix(".json.part")
    url = f"https://drive.usercontent.google.com/download?id={identifier}&export=download&confirm=t"
    if not destination.exists():
        print(f"Downloading {split} labels", flush=True)
        common = [
            "curl.exe",
            "--fail",
            "--location",
            "--silent",
            "--show-error",
            "--connect-timeout",
            "10",
            "--max-time",
            "35",
            "--retry",
            "3",
            "--retry-all-errors",
            "--retry-delay",
            "1",
        ]
        headers = subprocess.run([*common, "--head", url], capture_output=True, check=True)
        lengths = re.findall(rb"Content-Length:\s*(\d+)", headers.stdout, re.IGNORECASE)
        if not lengths:
            raise ValueError("Cannot determine download size")
        length = int(lengths[-1])
        if length > 2_000_000_000:
            raise ValueError("Annotation transfer budget exceeded")
        start = partial.stat().st_size if partial.exists() else 0
        chunks_dir = ROOT / "annotations" / f"{split}_chunks"
        chunks_dir.mkdir(exist_ok=True)

        def download_range(bounds):
            begin, end = bounds
            chunk_path = chunks_dir / f"{begin}-{end}.bin"
            header_path = chunk_path.with_suffix(".headers")
            if chunk_path.exists() and chunk_path.stat().st_size == end - begin + 1:
                return chunk_path
            subprocess.run(
                [
                    *common,
                    "--range",
                    f"{begin}-{end}",
                    "--output",
                    str(chunk_path),
                    "--dump-header",
                    str(header_path),
                    url,
                ],
                capture_output=True,
                check=True,
            )
            ranges = re.findall(
                rb"Content-Range:\s*bytes\s+(\d+)-(\d+)/(\d+)",
                header_path.read_bytes(),
                re.IGNORECASE,
            )
            if not ranges or tuple(map(int, ranges[-1])) != (begin, end, length):
                raise ValueError("Incorrect Content-Range; chunk not appended")
            if chunk_path.stat().st_size != end - begin + 1:
                raise ValueError("Range response length mismatch; partial file preserved")
            return chunk_path

        ranges = [
            (begin, min(begin + 4_000_000, length) - 1) for begin in range(start, length, 4_000_000)
        ]
        with partial.open("ab") as stream:
            # Ordered append, bounded four concurrent requests, reusable verified chunks.
            with ThreadPoolExecutor(max_workers=4) as chunks_pool:
                futures = {}
                for index, bounds in enumerate(ranges):
                    if index == 0:
                        for next_index in range(min(4, len(ranges))):
                            futures[next_index] = chunks_pool.submit(
                                download_range, ranges[next_index]
                            )
                    chunk_path = futures.pop(index).result()
                    stream.write(chunk_path.read_bytes())
                    stream.flush()
                    start = bounds[1] + 1
                    print(f"{split}: {start}/{length} bytes", flush=True)
                    next_index = index + 4
                    if next_index < len(ranges):
                        futures[next_index] = chunks_pool.submit(download_range, ranges[next_index])
        document = json.loads(partial.read_text(encoding="utf-8"))
        if not all(k in document for k in ("images", "annotations", "categories")):
            raise ValueError(f"Not COCO annotations: {split}")
        partial.rename(destination)
    else:
        document = json.loads(destination.read_text(encoding="utf-8"))
    record = {
        "split": split,
        "path": str(destination),
        "source_url": url,
        "bytes": destination.stat().st_size,
        "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
        "image_count": len(document["images"]),
        "instance_count": len(document["annotations"]),
        "categories": document["categories"],
        "annotation_fields": list(document["annotations"][0]) if document["annotations"] else [],
        "image_examples": document["images"][:2],
    }
    print(json.dumps(record), flush=True)
    (ROOT / "annotations" / f"{split}_provenance.json").write_text(json.dumps(record, indent=2))
    return record


def main():
    (ROOT / "annotations").mkdir(parents=True, exist_ok=True)

    def bounded_fetch(item):
        try:
            return fetch(item)
        except Exception as error:
            split = item[0]
            partial = ROOT / "annotations" / f"{split}_RGB_entire_tree.json.part"
            record = {
                "split": split,
                "completed": False,
                "error": str(error),
                "partial_bytes": partial.stat().st_size if partial.exists() else 0,
            }
            print(json.dumps(record), flush=True)
            return record

    with ThreadPoolExecutor(max_workers=3) as pool:
        records = list(pool.map(bounded_fetch, FILES.items()))
    (ROOT / "labels_manifest.json").write_text(
        json.dumps(
            {
                "author_confirmation": "https://github.com/rcondat/convexmask/issues/1#issuecomment-2285098959",
                "records": records,
                "original_split_preserved": True,
                "paper_reproduction_completed": False,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
