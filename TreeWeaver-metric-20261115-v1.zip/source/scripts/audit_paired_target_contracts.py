"""Train-only CPU audit of completion eligibility and local occlusion labels."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from paired_target_contract import local_occlusion_targets, visibility_targets  # noqa: E402
from research_protocol import sha256_file  # noqa: E402


def read_mask(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("mask path outside source")
    value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if value is None:
        raise FileNotFoundError(path)
    value = value[..., 3] if value.ndim == 3 and value.shape[-1] == 4 else value
    if value.ndim != 2:
        raise ValueError("expected a mask or RGBA alpha")
    return value > 16


def curve_eligible_bands(crown, valid, complete, knots=12):
    # Match the fixed-reference-row convention of absolute_crown_curve_loss.
    if not complete:
        return 0
    ys = np.flatnonzero((crown & valid).any(-1))
    if not len(ys):
        return 0
    top, bottom = int(ys.min()), int(ys.max())
    rows = [max(top, bottom - int((i + 0.5) * (bottom - top + 1) / knots)) for i in range(knots)]
    return sum(bool((crown[y] & valid[y]).any() and valid[y].all()) for y in rows)


def audit(root):
    root = root.resolve()
    path = root / "paired-samples.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    records = []
    for row in manifest["records"]:
        if row["split"] != "train":
            continue
        masks = {
            key: np.stack([read_mask(root, item[key]) for item in row["instances"]])
            for key in (
                "visible",
                "amodal",
                "visible_stem",
                "amodal_stem",
                "amodal_crown",
                "raster_unknown",
                "visible_part_unknown",
                "amodal_part_unknown",
            )
        }
        complete = np.asarray(
            [
                not item.get("frame_truncated", False)
                and item.get("amodal_supervision_allowed", True)
                for item in row["instances"]
            ],
            bool,
        )
        known = ~masks["raster_unknown"]
        tree = visibility_targets(
            masks["visible"], masks["amodal"], known, complete_instance=complete
        )
        stem_known = known & ~masks["visible_part_unknown"] & ~masks["amodal_part_unknown"]
        stem = visibility_targets(
            masks["visible_stem"], masks["amodal_stem"], stem_known, complete_instance=complete
        )
        local = local_occlusion_targets(masks["visible"], masks["amodal"], known)
        if row["condition"] == "isolated" and local["hidden"].any():
            raise AssertionError("isolated control has hidden pixels")
        queries = []
        for q, item in enumerate(row["instances"]):
            bands = curve_eligible_bands(
                masks["amodal_crown"][q], known[q] & ~masks["amodal_part_unknown"][q], complete[q]
            )
            queries.append(
                {
                    "asset": item["asset"],
                    "complete_instance": bool(complete[q]),
                    "tree_visibility": float(tree["target"][q]) if tree["eligible"][q] else None,
                    "stem_visibility": float(stem["target"][q]) if stem["eligible"][q] else None,
                    "tree_denominator": int(tree["known_complete_area"][q]),
                    "stem_denominator": int(stem["known_complete_area"][q]),
                    "eligible_curve_bands": bands,
                    "hidden_pixels_common_known": int(local["hidden"][q].sum()),
                    "unexplained_hidden_pixels_common_known": int(
                        local["unexplained_hidden"][q].sum()
                    ),
                }
            )
        records.append(
            {
                "id": row["id"],
                "group_id": row["group_id"],
                "condition": row["condition"],
                "native_wh": list(masks["visible"].shape[-2:][::-1]),
                "queries": queries,
                "directional_occlusion_pixels": local["directional_pixels"].tolist(),
                "bidirectional_pair_count": int(np.triu(local["bidirectional_pairs"], 1).sum()),
            }
        )
    if not records:
        raise ValueError("no train records")
    queries = [q for record in records for q in record["queries"]]
    scenes = [record for record in records if record["condition"] == "scene"]
    return {
        "source": str(root),
        "manifest_sha256": sha256_file(path),
        "train_only": True,
        "uses_model_predictions": False,
        "test_labels_accessed_by_this_audit": False,
        "records": records,
        "summary": {
            "records": len(records),
            "scenes": len(scenes),
            "independent_source_groups_at_most": len({r["group_id"] for r in records}),
            "queries_including_repeated_controls": len(queries),
            "completion_eligible_queries": sum(q["complete_instance"] for q in queries),
            "tree_visibility_eligible": sum(q["tree_visibility"] is not None for q in queries),
            "stem_visibility_eligible": sum(q["stem_visibility"] is not None for q in queries),
            "curve_eligible_queries": sum(q["eligible_curve_bands"] > 0 for q in queries),
            "scenes_with_bidirectional_evidence": sum(
                r["bidirectional_pair_count"] > 0 for r in scenes
            ),
            "hidden_pixels": sum(q["hidden_pixels_common_known"] for q in queries),
            "unexplained_hidden_pixels": sum(
                q["unexplained_hidden_pixels_common_known"] for q in queries
            ),
        },
        "label_semantics": {
            "visibility": "tree and stem use separate V/A counts on their own common known pixels",
            "cropped_tree": "full-tree completion, visibility and curve supervision ineligible",
            "local_direction": "row target is hidden by column visible tree: A_i intersect V_j",
            "bidirectional": "allowed; counts are not antisymmetric global depth ranks",
            "unexplained_hidden": (
                "known A minus V without a labelled visible tree ID; investigate before training"
            ),
            "curve": (
                "native amodal crown surface; whole sampled row known; not model performance"
            ),
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.data)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result["summary"]))


if __name__ == "__main__":
    main()
