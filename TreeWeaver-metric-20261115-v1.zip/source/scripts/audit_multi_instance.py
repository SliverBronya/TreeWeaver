"""Connect multi-tree RGB masks to parameter-specific complex-scene gates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from treeweaver.measurement.image_readiness import assess_single_image_measurement
from treeweaver.visibility.image_complexity import audit_target_view


def _mask(path: str) -> np.ndarray:
    image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(path)
    return image > 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("multi_instance_report")
    parser.add_argument("trunk_refinement_report")
    parser.add_argument("output_json")
    args = parser.parse_args()
    output = Path(args.output_json).resolve()
    if output.exists():
        raise FileExistsError(output)
    multi = json.loads(Path(args.multi_instance_report).read_text(encoding="utf-8"))
    refined = json.loads(Path(args.trunk_refinement_report).read_text(encoding="utf-8"))
    if (
        multi.get("schema_version") != "multi-tree-root-anchor-pilot-1.0"
        or refined.get("schema_version") != "root-seeded-sam2-trunk-pilot-1.0"
    ):
        raise ValueError("unsupported segmentation reports")
    trunk_by_name = {str(item["filename"]): item for item in refined["records"]}
    rows: list[dict[str, object]] = []
    for item in multi["records"]:
        row: dict[str, object] = {"filename": item["filename"]}
        index = item.get("target_index")
        if index is None or "failure" in item:
            row.update({"status": "identity_ambiguous", "parameter_gates": {}})
        else:
            paths = list(item["mask_paths"])
            masks = tuple(_mask(str(path)) for path in paths)
            target = _mask(str(item.get("target_mask_path", paths[int(index)])))
            trunk = _mask(str(trunk_by_name[str(item["filename"])]["mask_path"]))
            trunk &= target
            crown = target & ~trunk
            if not np.any(trunk) or not np.any(crown):
                row.update({"status": "parts_invalid", "parameter_gates": {}})
            else:
                competitors = tuple(mask for i, mask in enumerate(masks) if i != int(index))
                non_tree_objects = tuple(
                    _mask(str(path)) for path in item.get("non_tree_mask_paths", ())
                )
                audit = audit_target_view(
                    target,
                    trunk,
                    crown,
                    competing_instance_masks=competitors,
                    non_tree_object_masks=non_tree_objects,
                )
                gates = assess_single_image_measurement(audit)
                row.update(
                    {
                        "status": "audited",
                        "target_index": index,
                        "non_tree_labels": item.get("non_tree_labels", []),
                        "challenges": {e.cue.value: e.score for e in audit.evidence},
                        "parameter_gates": {
                            gate.parameter.value: {
                                "readiness": gate.readiness.value,
                                "reasons": list(gate.reasons),
                            }
                            for gate in gates
                        },
                    }
                )
        rows.append(row)
    payload = {"schema_version": "multi-tree-image-audit-1.0", "records": rows}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"audited": sum(r["status"] == "audited" for r in rows)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
