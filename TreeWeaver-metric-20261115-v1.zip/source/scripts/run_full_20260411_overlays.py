"""Run all 20260411 photos and save photo+mask comparisons for the main tree.

Each output is a 2x2 panel:
  original | stock SAM2 overlay
  current overlay | both contours (stock blue, current red)
"""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL_W, PANEL_H = 800, 450


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def overlay(image, mask, colour, title):
    panel = image.copy()
    colour_array = np.array(colour, np.float32)
    panel[mask] = (0.55 * panel[mask] + 0.45 * colour_array).astype(np.uint8)
    contours = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )[0]
    cv2.drawContours(panel, contours, -1, colour, 2)
    cv2.putText(panel, title, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
    cv2.putText(panel, title, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 0), 1)
    return panel


def contours(image, stock, ours, title):
    panel = image.copy()
    for mask, colour in ((stock, (240, 120, 40)), (ours, (60, 80, 240))):
        found = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(panel, found, -1, colour, 2)
    cv2.putText(panel, title, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
    cv2.putText(panel, title, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 0), 1)
    return panel


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--images", type=Path, default=ROOT / "data" / "20260411")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    parameters = inspect.signature(
        detector_processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"

    args.output.mkdir(parents=True, exist_ok=True)
    paths = sorted(args.images.glob("*.jpg"))
    if args.limit:
        paths = paths[: args.limit]
    rows = []
    for number, path in enumerate(paths, start=1):
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(
            images=image, text="tree.", return_tensors="pt"
        ).to(args.device)
        with torch.no_grad():
            detector_outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            detector_outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **{threshold_keyword: 0.25},
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        if len(boxes) == 0:
            rows.append({"image": path.name, "status": "no_box"})
            continue
        areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
        prominence = scores * np.sqrt(np.maximum(areas, 1.0))
        rank = int(np.argmax(prominence))
        box = boxes[rank]
        scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
        scaled = torch.as_tensor(box * scale, device=args.device)[None, None]
        inputs = processor(images=image, return_tensors="pt")
        with torch.no_grad():
            base = sam2(
                pixel_values=inputs["pixel_values"].to(args.device),
                input_boxes=scaled,
                multimask_output=True,
            )
            selected = int(torch.argmax(base.iou_scores[0, 0]))
            stock = processor.post_process_masks(
                base.pred_masks[:, :, selected : selected + 1],
                original_sizes=[[height, width]],
            )[0][0, 0].cpu().numpy() > 0
            output = model(inputs["pixel_values"].to(args.device), input_boxes=scaled)
            ours = processor.post_process_masks(
                output["masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
        if stock.sum() < 1000 or ours.sum() < 1000:
            rows.append({"image": path.name, "status": "tiny_mask"})
            continue
        stock_only = int((stock & ~ours).sum())
        ours_only = int((ours & ~stock).sum())
        row = {
            "image": path.name,
            "status": "ok",
            "score": round(float(scores[rank]), 4),
            "iou": round(iou(ours, stock), 4),
            "stock_area": int(stock.sum()),
            "ours_area": int(ours.sum()),
            "stock_only": stock_only,
            "ours_only": ours_only,
            "area_ratio": round(float(ours.sum()) / max(int(stock.sum()), 1), 4),
        }
        rows.append(row)

        panels = [
            ("original", image_bgr),
            ("stock SAM2", overlay(image_bgr, stock, (240, 120, 40), "stock SAM2")),
            ("current model", overlay(image_bgr, ours, (60, 200, 90), "current model")),
            (
                "contours: stock blue / current red",
                contours(image_bgr, stock, ours, "stock blue / current red"),
            ),
        ]
        gap = 8
        figure = np.full((52 + 2 * (PANEL_H + 28), 2 * (PANEL_W + gap), 3), 245, np.uint8)
        cv2.putText(
            figure,
            f"{path.name}  score={scores[rank]:.2f}  IoU={row['iou']:.2f}  "
            f"area ratio={row['area_ratio']:.2f}  ours-only={ours_only}  stock-only={stock_only}",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (25, 25, 25),
            1,
        )
        for index, (title, panel) in enumerate(panels):
            row_index, column = divmod(index, 2)
            x0 = column * (PANEL_W + gap)
            y0 = 52 + row_index * (PANEL_H + 28)
            cv2.putText(
                figure, title, (x0 + 6, y0 - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 1,
            )
            figure[y0 : y0 + PANEL_H, x0 : x0 + PANEL_W] = cv2.resize(
                panel, (PANEL_W, PANEL_H)
            )
        cv2.imwrite(str(args.output / f"{path.stem}.png"), figure)
        if number % 20 == 0:
            print(f"processed {number}/{len(paths)}", flush=True)

    (args.output / "summary.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    ok = [row for row in rows if row.get("status") == "ok"]
    print(json.dumps({
        "images": len(paths),
        "ok": len(ok),
        "mean_iou": float(np.mean([row["iou"] for row in ok])) if ok else None,
        "median_iou": float(np.median([row["iou"] for row in ok])) if ok else None,
        "mean_area_ratio": float(np.mean([row["area_ratio"] for row in ok])) if ok else None,
    }, indent=2))
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
