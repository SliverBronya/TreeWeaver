"""Reconstruct a readout pilot, audit token insertion and show validation failures."""

from __future__ import annotations

import json
import sys

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def main():
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = ROOT / "reports/part-readout-pilot-2026-11-08"
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    saved = torch.load(out / "readouts-final.pth", map_location="cpu", weights_only=True)
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = (
        Sam2OcclusionModel(base, enable_stem=True, enable_crown=True, expose_query_features=True)
        .to(device)
        .eval()
    )
    mismatch = model.decoder.load_state_dict(
        torch.load(prior, map_location="cpu", weights_only=True)["decoder"], strict=False
    )
    if mismatch.unexpected_keys or any(
        not k.startswith(("crown_token.", "crown_hypernet.")) for k in mismatch.missing_keys
    ):
        raise ValueError(mismatch)
    for name in ("crown", "stem"):
        head = getattr(model.decoder, f"{name}_hypernet")
        for key, value in head.state_dict().items():
            if not torch.equal(value.cpu(), saved["initial"][name][key]):
                raise ValueError("initialization reconstruction differs")
        head.load_state_dict(saved["trained"][name], strict=True)
    torch.save(
        {
            "decoder": model.decoder.state_dict(),
            "protocol": saved["protocol"],
            "initialization_reconstruction_verified": True,
        },
        out / "decoder-final.pth",
    )
    dataset = PairedFigDataset(ROOT / "reports/fig-paired-v6-framing-30-2026-11-08", "validation")
    rows, pictures = [], []
    with torch.no_grad():
        for i, record in enumerate(dataset.items):
            if record["condition"] != "scene":
                continue
            sample = dataset.sample(i)
            inputs, _ = tensors(sample, device)
            result = model(**inputs)
            model.decoder.enable_crown = model.decoder.enable_stem = False
            legacy = model(**inputs)
            model.decoder.enable_crown = model.decoder.enable_stem = True
            known = torch.from_numpy(sample["whole_valid"])[None].to(device)
            gt = torch.from_numpy(sample["visible"])[None].to(device)

            def ious(logits, known=known, gt=gt):
                pred = (logits[:, :, 0] > 0) & known
                target = gt & known
                return (
                    ((pred & target).sum((-2, -1)) / (pred | target).sum((-2, -1)).clamp_min(1))
                    .cpu()
                    .tolist()[0]
                )

            before, after = ious(legacy["masks"]), ious(result["masks"])
            rows.append(
                {
                    "id": record["id"],
                    "legacy_visible_iou": before,
                    "added_tokens_visible_iou": after,
                    "visible_sign_changes": int(
                        ((legacy["masks"] > 0) != (result["masks"] > 0)).sum()
                    ),
                }
            )
            rgb = cv2.cvtColor(cv2.imread(str(dataset._path(record["image"]))), cv2.COLOR_BGR2RGB)
            scores = []
            for q in range(len(record["instances"])):
                valid = sample["visible_part_valid"][q]
                target = sample["visible_stem"][q] & valid
                pred = (result["stem_masks"][0, q, 0].cpu().numpy() > 0) & valid
                scores.append(
                    np.count_nonzero(target & pred) / max(np.count_nonzero(target | pred), 1)
                )
            q = int(np.argmin(scores))
            panels = [Image.fromarray(rgb).resize((384, 216))]
            for truth in (True, False):
                canvas = np.asarray(panels[0]).copy()
                for part, color in (("crown", (40, 200, 80)), ("stem", (240, 60, 60))):
                    mask = (
                        sample[f"visible_{part}"][q]
                        if truth
                        else result[f"{part}_masks"][0, q, 0].cpu().numpy() > 0
                    )
                    mask &= sample["visible_part_valid"][q]
                    mask = (
                        cv2.resize(
                            mask.astype(np.uint8), (384, 216), interpolation=cv2.INTER_NEAREST
                        )
                        > 0
                    )
                    canvas[mask] = (canvas[mask] * 0.4 + np.array(color) * 0.6).astype(np.uint8)
                panels.append(Image.fromarray(canvas))
            pictures.append((scores[q], record["id"], q, panels))
    macro = {
        key: float(np.mean([np.mean(row[key]) for row in rows]))
        for key in ("legacy_visible_iou", "added_tokens_visible_iou")
    }
    report = {
        "scope": "10 development validation scenes, GT prompts, 256x256 masks, one seed",
        "token_insertion_impact": macro,
        "records": rows,
        "readout_updates_feed_visible_or_ownership": False,
        "promoted": False,
        "test_images_accessed": False,
    }
    (out / "architecture-audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    sheet = Image.new("RGB", (1152, 1020), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)
    draw.text(
        (8, 5),
        "Validation failures / RGB | target GT parts | predicted parts / green crown, red stem",
        font=font,
        fill="black",
    )
    for ri, (score, name, q, panels) in enumerate(sorted(pictures, key=lambda row: row[0])[:4]):
        y = 35 + ri * 245
        draw.text((8, y), f"{name}, query {q + 1}, stem IoU {score:.3f}", font=font, fill="black")
        for ci, panel in enumerate(panels):
            sheet.paste(panel, (ci * 384, y + 24))
    sheet.save(out / "validation-failures.jpg", quality=94)
    print(json.dumps(report["token_insertion_impact"]))


if __name__ == "__main__":
    main()
