"""Inspect existing local SPREAD derivatives; do not infer missing raw labels."""

import json
from pathlib import Path

import cv2
import numpy as np
from audit_forest_dataset_samples import OUTPUT, xlsx_rows


def main():
    source = Path("D:/SAM3DepthPro/TreeHeight_backend/datasets/spread_occlusion_yolo")
    images = [p for p in (source / "images").rglob("*") if p.is_file()]
    labels = list((source / "labels").rglob("*.txt"))
    entry = next(p for p in images if p.stem.startswith("city_park_"))
    label = next(p for p in labels if p.stem == entry.stem)
    original = cv2.imread(str(entry))
    overlay = original.copy()
    h, w = original.shape[:2]
    polygons = label.read_text().splitlines()
    for index, line in enumerate(polygons):
        values = list(map(float, line.split()))
        points = np.round(np.array(values[1:]).reshape(-1, 2) * [w, h]).astype(np.int32)
        mask = np.zeros((h, w), np.uint8)
        cv2.fillPoly(mask, [points], 1)
        color = np.array(
            [(index * 83 + 60) % 256, (index * 57 + 100) % 256, (index * 113 + 180) % 256]
        )
        overlay[mask > 0] = (0.6 * overlay[mask > 0] + 0.4 * color).astype(np.uint8)
    cv2.imwrite(str(OUTPUT / "SPREAD_local_YOLO_label_overlay.png"), overlay)
    spread = Path("D:/SAM3DepthPro/SPREAD_labels")
    scenes = []
    for scene in sorted(spread.iterdir()):
        if not scene.is_dir():
            continue
        table = scene / "obj_info_final.xlsx"
        scenes.append(
            {
                "scene": scene.name,
                "rgb_png_count": len(list((scene / "rgb").glob("*.png"))),
                "instance_png_count": len(list((scene / "instance_segmentation").glob("*.png"))),
                "tree_parameter_examples": xlsx_rows(table, tree_only=True)
                if table.exists()
                else None,
            }
        )
    train_ids = {
        p.stem.split("_Tree", 1)[0] + "_Tree" + p.stem.split("_Tree", 1)[1].split("_")[0]
        for p in images
        if "_Tree" in p.stem and "train" in p.parts
    }
    val_ids = {
        p.stem.split("_Tree", 1)[0] + "_Tree" + p.stem.split("_Tree", 1)[1].split("_")[0]
        for p in images
        if "_Tree" in p.stem and "val" in p.parts
    }
    report = {
        "image_count": len(images),
        "label_count": len(labels),
        "sample_image": str(entry),
        "sample_label": str(label),
        "sample_polygon_count": len(polygons),
        "sample_classes": sorted({line.split()[0] for line in polygons}),
        "train_val_central_tree_ids_overlap": sorted(train_ids & val_ids),
        "split_check_limit": "central tree filename only; does not check neighboring trees",
        "scenes": scenes,
    }
    (OUTPUT / "SPREAD_local_audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report)[:2000], flush=True)


if __name__ == "__main__":
    main()
