"""Verify every derived crop against pinned source pixels and native labels."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from focal_view_protocol import focal_viewport
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from paired_fig_dataset import MASK_KEYS, PairedFigDataset  # noqa: E402
from research_protocol import assert_training_allowed, sha256_file  # noqa: E402


def pixels(path):
    with Image.open(path) as image:
        return np.array(image)


def main():
    root = ROOT / "reports/focal-view-qualification-2026-11-09"
    audit = json.loads((root / "viewport-audit.json").read_text(encoding="utf-8"))
    source = Path(audit["source"])
    original_manifest = json.loads((source / "paired-samples.json").read_text(encoding="utf-8"))
    manifest = json.loads((root / "paired-samples.json").read_text(encoding="utf-8"))
    original = {r["id"]: r for r in original_manifest["records"]}
    current = {r["id"]: r for r in manifest["records"]}
    for relative, expected_hash in audit["source_file_sha256"].items():
        if sha256_file(source / relative) != expected_hash:
            raise AssertionError("source pixel file changed: " + relative)
    checked_rgb, checked_masks, checked_ids, truncated, eligible = 0, 0, 0, 0, 0
    comparisons = []
    for view in audit["views"]:
        base = original[view["source_scene"]]
        scene = current[view["view"] + "-scene"]
        if scene["split"] != base["split"] or scene["group_id"] != base["group_id"]:
            raise AssertionError("source group or role changed")
        if scene["split"] != "train":
            raise AssertionError("non-train source entered focal crops")
        x0, y0, x1, y1 = view["roi_xyxy"]
        roi = np.s_[y0:y1, x0:x1]
        if not np.array_equal(pixels(root / scene["image"]), pixels(source / base["image"])[roi]):
            raise AssertionError("RGB crop mismatch")
        checked_rgb += 1
        visible = []
        for q, item in enumerate(scene["instances"], 1):
            prior = base["instances"][item["original_tree_index"] - 1]
            if item["asset"] != prior["asset"]:
                raise AssertionError("tree identity changed")
            for key in MASK_KEYS:
                if not np.array_equal(pixels(root / item[key]), pixels(source / prior[key])[roi]):
                    raise AssertionError("mask crop mismatch: " + key)
                checked_masks += 1
            old_a, new_a = (
                pixels(folder / entry["amodal"])[..., 3] > 16
                for folder, entry in ((source, prior), (root, item))
            )
            cut = old_a.sum() != new_a.sum()
            if (
                bool(item["frame_truncated"]) != cut
                or bool(item["amodal_supervision_allowed"]) == cut
            ):
                raise AssertionError("completion eligibility disagrees with original pixel support")
            if item["focal_target"]:
                old_v = pixels(source / prior["visible"])[..., 3] > 16
                new_v = pixels(root / item["visible"])[..., 3] > 16
                if cut or old_v.sum() != new_v.sum():
                    raise AssertionError("focal visible or complete support lost")
                if focal_viewport(old_a)["roi_xyxy"] != view["roi_xyxy"]:
                    raise AssertionError(
                        "current viewport implementation cannot reproduce the crop"
                    )
                ys = np.flatnonzero(old_a.any(-1))
                comparisons.append(
                    {
                        "view": view["view"],
                        "asset": item["asset"],
                        "source_group": base["group_id"],
                        "source_height_fraction": float((ys.max() - ys.min() + 1) / old_a.shape[0]),
                        "crop_height_fraction": view["height_fraction"],
                        "native_visible_and_complete_counts_unchanged": True,
                        "hidden_fraction": float((old_a & ~old_v).sum() / old_a.sum()),
                    }
                )
            visible.append(pixels(root / item["visible"])[..., 3] > 16)
            control = current[view["view"] + f"-control-{q}"]
            old_control = next(
                r
                for r in original_manifest["records"]
                if r["condition"] == "isolated"
                and r["group_id"] == base["group_id"]
                and r["instances"][0]["source_tree_index"] == prior["source_tree_index"]
            )
            if not np.array_equal(
                pixels(root / control["image"]), pixels(source / old_control["image"])[roi]
            ):
                raise AssertionError("control RGB crop mismatch")
            checked_rgb += 1
        owner = (np.stack(visible) * np.arange(1, len(visible) + 1)[:, None, None]).sum(0)
        if not np.array_equal(owner, pixels(root / "masks" / view["view"] / "instance_ids.png")):
            raise AssertionError("compact ownership IDs disagree")
        checked_ids += 1
    # Exercise the real loader, including native part visibility and completion gates.
    dataset = PairedFigDataset(root, "train", size=128, mask_size=64)
    visibility_eligible, stem_eligible, conflicts = 0, 0, 0
    for index in range(len(dataset)):
        sample = dataset.sample(index)
        complete = sample["amodal_instance_valid"]
        if sample["amodal_valid"][~complete].any() or sample["visibility_valid"][~complete].any():
            raise AssertionError("cropped neighbour entered completion/visibility loss")
        truncated += int((~complete).sum())
        eligible += int(complete.sum())
        visibility_eligible += int(sample["visibility_valid"][:, 0].sum())
        stem_eligible += int(sample["visibility_valid"][:, 1].sum())
        conflicts += int(sample["native_part_correspondence_conflict_pixels"].sum())
    try:
        assert_training_allowed(root)
    except ValueError:
        blocked = True
    else:
        raise AssertionError("qualification crops unexpectedly allowed for training")
    result = {
        "passed": True,
        "train_only": True,
        "inference_or_training": False,
        "source_pixel_hashes_verified": len(audit["source_file_sha256"]),
        "source_manifest_current_sha256": sha256_file(source / "paired-samples.json"),
        "derived_manifest_sha256": sha256_file(root / "paired-samples.json"),
        "RGB_exact_crops_verified": checked_rgb,
        "mask_exact_crops_verified": checked_masks,
        "ownership_maps_verified": checked_ids,
        "records_loaded": len(dataset),
        "ineligible_completion_queries_including_controls": truncated,
        "eligible_completion_queries_including_controls": eligible,
        "eligible_tree_visibility_queries": visibility_eligible,
        "eligible_stem_visibility_queries": stem_eligible,
        "native_part_conflicts": conflicts,
        "training_policy_blocks": blocked,
        "focal_visibility_and_hidden_fraction_unchanged": True,
        "focal_view_crops_create_harder_occlusion": False,
        "median_source_height_fraction": float(
            np.median([r["source_height_fraction"] for r in comparisons])
        ),
        "median_crop_height_fraction": float(
            np.median([r["crop_height_fraction"] for r in comparisons])
        ),
        "width_limited_views": sum(v["width_limited"] for v in audit["views"]),
        "views_meeting_portrait_height_045": sum(
            v["height_fraction"] >= 0.45 for v in audit["views"]
        ),
        "scale_flag_is_not_an_asset_exclusion_rule": True,
        "focal_comparisons": comparisons,
    }
    (root / "roundtrip-audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "focal_comparisons"}))


if __name__ == "__main__":
    main()
