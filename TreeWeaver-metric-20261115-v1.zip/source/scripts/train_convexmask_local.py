"""Bounded RGB-only ConvexMask pilot on existing target-tree LabelMe annotations.

This is not a reproduction of the paper or an exhaustive forest instance dataset.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--annotations", type=Path, required=True)
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--backbone", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--size", type=int, default=320)
    args = parser.parse_args()
    if not 0 < args.steps <= 1000 or args.size < 128 or args.size % 32:
        parser.error("Pilot requires 1..1000 steps and an image size divisible by 32")
    if args.output.exists():
        parser.error("Use a new output directory; existing runs will not be overwritten")
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    import torch.nn.functional as functional

    from data import cfg, set_cfg

    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (args.size, args.size)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    from convexmask import ConvexMask
    from layers.modules.multibox_loss import MultiBoxLoss

    records = []
    for annotation in sorted(args.annotations.glob("*.json")):
        label = json.loads(annotation.read_text(encoding="utf-8"))
        image_path = args.images / Path(label["imagePath"]).name
        if not image_path.is_file():
            raise FileNotFoundError(image_path)
        shapes = [shape for shape in label["shapes"] if shape["label"] == "tree"]
        if not shapes or any(shape.get("shape_type", "polygon") != "polygon" for shape in shapes):
            raise ValueError(f"Expected target-tree polygons: {annotation}")
        records.append(
            {
                "annotation": str(annotation),
                "image": str(image_path),
                "tree_id": int(annotation.stem) // 1000,
                "shapes": shapes,
                "width": label["imageWidth"],
                "height": label["imageHeight"],
            }
        )
    groups = sorted({record["tree_id"] for record in records})
    random.Random(42).shuffle(groups)
    test_groups = set(groups[: max(1, len(groups) // 5)])
    train = [record for record in records if record["tree_id"] not in test_groups]
    test = [record for record in records if record["tree_id"] in test_groups]
    if not train or not test:
        raise ValueError("Both tree-disjoint training and test data are required")
    args.output.mkdir(parents=True)
    manifest = {
        "label_scope": "target tree only; other trees may be unannotated",
        "depth_used": False,
        "seed": 42,
        "test_tree_ids": sorted(test_groups),
        "train": [{k: v for k, v in record.items() if k != "shapes"} for record in train],
        "test": [{k: v for k, v in record.items() if k != "shapes"} for record in test],
        "limitations": [
            "Small exploratory local split, not a publication benchmark",
            "No independent stem labels; no stem ownership supervision",
            "Other trees are not exhaustively annotated",
        ],
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    def sample(record):
        image = cv2.imread(record["image"])
        if image is None or image.shape[:2] != (record["height"], record["width"]):
            raise ValueError(f"RGB/annotation dimension mismatch: {record['image']}")
        h, w = image.shape[:2]
        masks, boxes, hulls = [], [], []
        for shape in record["shapes"]:
            points = np.asarray(shape["points"], dtype=np.float32)
            mask = np.zeros((h, w), dtype=np.uint8)
            cv2.fillPoly(mask, [np.round(points).astype(np.int32)], 1)
            mask = cv2.resize(mask, (args.size, args.size), interpolation=cv2.INTER_NEAREST)
            ys, xs = np.nonzero(mask)
            if len(xs) < 10:
                raise ValueError("Empty/small target mask")
            masks.append(mask)
            boxes.append(
                [
                    xs.min() / args.size,
                    ys.min() / args.size,
                    (xs.max() + 1) / args.size,
                    (ys.max() + 1) / args.size,
                    0,
                ]
            )
            contours = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
            hulls.append(
                cv2.convexHull(np.concatenate(contours))[:, 0].astype(np.float32) / args.size
            )
        polygons = np.full((len(hulls), max(len(hull) for hull in hulls), 2), -1, np.float32)
        for i, hull in enumerate(hulls):
            polygons[i, : len(hull)] = hull
        resized = cv2.resize(image, (args.size, args.size)).astype(np.float32)
        resized = (
            (resized - np.array([103.94, 116.78, 123.68])) / np.array([57.38, 57.12, 58.40])
        )[:, :, ::-1].copy()
        tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)[None]
        return (
            tensor,
            torch.tensor(boxes, dtype=torch.float32),
            torch.tensor(np.stack(masks), dtype=torch.float32),
            torch.tensor(polygons),
        )

    cache = {record["image"]: sample(record) for record in records}
    model = ConvexMask().cuda()
    backbone = torch.load(args.backbone, map_location="cuda", weights_only=True)
    remapped = {}
    for key, value in backbone.items():
        if key.startswith("fc."):
            continue
        if key.startswith("layer"):
            key = "layers." + str(int(key[5]) - 1) + key[6:]
        remapped[key] = value
    model.backbone.load_state_dict(remapped, strict=True)
    criterion = MultiBoxLoss(2, cfg.num_rays, cfg.ohem_negpos_ratio)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    model.train()
    history = []
    torch.cuda.reset_peak_memory_stats()
    for step in range(args.steps):
        record = train[step % len(train)]
        image, boxes, masks, polygons = cache[record["image"]]
        torch.cuda.synchronize()
        started = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        predictions = model(image)
        losses = criterion(
            model, predictions, [boxes.clone()], [masks.clone()], [polygons.clone()], [0]
        )
        total = sum(losses.values())
        if not torch.isfinite(total):
            raise FloatingPointError(f"Non-finite loss at step {step}: {losses}")
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0, error_if_nonfinite=True)
        optimizer.step()
        torch.cuda.synchronize()
        entry = {
            "step": step + 1,
            "image": Path(record["image"]).name,
            "loss": float(total.detach()),
            "seconds": time.perf_counter() - started,
            "components": {key: float(value.detach()) for key, value in losses.items()},
        }
        history.append(entry)
        if step == 0 or (step + 1) % 10 == 0:
            print(json.dumps(entry), flush=True)
        (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    checkpoint_path = args.output / "pilot_checkpoint.pth"
    torch.save(model.state_dict(), checkpoint_path)
    # Oracle-selected prediction evaluation diagnoses mask learning, not autonomous detection.
    model.train()  # Raw prototype outputs are needed; BN remains frozen by configuration.
    evaluations = []
    with torch.no_grad():
        for record in test:
            image, boxes, masks, polygons = cache[record["image"]]
            predictions = model(image)
            probs = (predictions["proto"][0] @ predictions["mask"][0].T).sigmoid()
            target = masks[0].bool()
            # Restrict diagnostic computation to strongest 32 foreground proposals.
            scores = predictions["conf"][0, :, 1].sigmoid()
            indices = scores.topk(min(32, scores.numel())).indices
            candidate_masks = (
                functional.interpolate(
                    probs[:, :, indices].permute(2, 0, 1)[None],
                    (args.size, args.size),
                    mode="bilinear",
                    align_corners=False,
                )[0]
                > 0.5
            )
            intersections = (candidate_masks & target).sum((1, 2))
            unions = (candidate_masks | target).sum((1, 2)).clamp_min(1)
            ious = intersections / unions
            best = int(ious.argmax())
            evaluations.append({"image": record["image"], "oracle_mask_iou": float(ious[best])})
            overlay = cv2.resize(cv2.imread(record["image"]), (args.size, args.size))
            predicted = candidate_masks[best].cpu().numpy()
            overlay[predicted] = (0.6 * overlay[predicted] + 0.4 * np.array([0, 80, 255])).astype(
                np.uint8
            )
            cv2.imwrite(
                str(args.output / f"{Path(record['image']).stem}_oracle_overlay.png"), overlay
            )
    report = {
        "completed_steps": args.steps,
        "architecture": "ConvexMask ResNet50 / 72 rays",
        "image_size": args.size,
        "training_images": len(train),
        "test_images": len(test),
        "checkpoint": str(checkpoint_path),
        "evaluations": evaluations,
        "evaluation_type": "oracle-selected raw mask diagnostic, NOT detector accuracy",
        "peak_allocated_mib": torch.cuda.max_memory_allocated() / 1024**2,
        "backbone_sha256": hashlib.sha256(args.backbone.read_bytes()).hexdigest(),
        "median_step_seconds": float(np.median([row["seconds"] for row in history[1:]])),
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
