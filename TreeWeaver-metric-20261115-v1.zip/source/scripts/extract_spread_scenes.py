"""Extract downloaded SPREAD scene archives into data/external/spread.

Design notes
------------
* Archives are read-only inputs. Nothing under SPREAD/ is modified or removed.
* Several scenes run in parallel child processes (LZMA decompression is CPU bound).
* **Resumable, but not cheaply.** On start each scene's staging directory is
  compared member by member against the archive index, so an interrupted run
  keeps finished files and only writes the remainder. These archives are
  *solid* 7z, so py7zr still has to decompress the stream up to the missing
  members: batching the missing set into many ``extract(targets=...)`` calls
  re-decompresses the prefix once per batch and is roughly quadratic. The
  extraction therefore runs as a **single pass per scene**, with a callback for
  progress, and a run should be given as much wall time as possible.
* A scene is extracted into ``<data-root>/.inprogress/<scene>`` and moved to its
  final ``<data-root>/<scene>`` only once every member is present. A partial
  scene can never look finished, and an existing final directory is never
  overwritten.
* py7zr verifies each member's CRC while decompressing, so extraction is itself
  the integrity check: corruption raises and the scene is marked FAILED.
* A free-space floor is enforced before each scene starts.
* ``--max-seconds`` is checked *between* scenes only; it cannot interrupt a
  decompression pass, and is useful solely to stop launching new scenes.

Usage::

    <worker-python> scripts/extract_spread_scenes.py --workers 3
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

DEFAULT_SCENES = (
    "!meadow_forest",
    "downtown_europe",
    "plantation",
    "rainforest",
    "redwood_forest",
    "suburb_us",
    "burned_forest",
    "downtown_west",
)

FREE_SPACE_FLOOR_BYTES = 10 * 1024**3


def free_bytes(path: Path) -> int:
    return shutil.disk_usage(str(path)).free


def count_tree(path: Path) -> dict[str, int]:
    if not path.is_dir():
        return {}
    counts: dict[str, int] = {}
    for child in sorted(path.iterdir()):
        if child.is_dir():
            counts[child.name] = sum(1 for _ in child.iterdir())
        else:
            counts[child.name] = 1
    return counts


def missing_members(archive, staging: Path) -> tuple[list[str], int]:
    """Return (member names still to extract, total member count)."""
    todo: list[str] = []
    total = 0
    for info in archive.list():
        name = info.filename
        if info.is_directory or name.endswith("/"):
            continue
        total += 1
        target = staging / name.replace("/", os.sep)
        try:
            if target.is_file() and target.stat().st_size == info.uncompressed:
                continue
        except OSError:
            pass
        todo.append(name)
    return todo, total


def extract_one(
    scene: str, archive_dir: Path, data_root: Path, log_dir: Path, max_seconds: float
) -> str:
    import py7zr
    from py7zr.callbacks import ExtractCallback

    class Progress(ExtractCallback):
        def __init__(self, total: int, already: int, say) -> None:
            self.total = total
            self.seen = already
            self.say = say

        def report_start_preparation(self) -> None:
            pass

        def report_start(self, processing_file_path: str, processing_bytes: str) -> None:
            self.seen += 1
            if self.seen % 2000 == 0:
                self.say(f"progress {self.seen}/{self.total} members")

        def report_update(self, decompressed_bytes: str) -> None:
            pass

        def report_end(self, processing_file_path: str, wrote_bytes: str) -> None:
            pass

        def report_postprocess(self) -> None:
            pass

        def report_warning(self, message: str) -> None:
            self.say(f"WARN {message}")

    log_path = log_dir / f"{scene}.log"
    log = open(log_path, "a", encoding="utf-8", buffering=1)

    def say(message: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        log.write(f"{stamp} {message}\n")

    final = data_root / scene
    staging_root = data_root / ".inprogress"
    staging = staging_root / scene

    if final.is_dir() and any(final.iterdir()):
        say(f"SKIP already extracted -> {final}")
        log.close()
        return "already"
    combined = archive_dir / f"{scene}.7z"
    if not combined.is_file():
        say(f"SKIP no complete archive at {combined}")
        log.close()
        return "no_archive"

    staging_root.mkdir(parents=True, exist_ok=True)
    staging.mkdir(parents=True, exist_ok=True)

    started = time.time()

    try:
        with py7zr.SevenZipFile(combined, mode="r") as archive:
            todo, total = missing_members(archive, staging)
            have = total - len(todo)
            say(
                f"{scene}: {total} members, {have} already present, {len(todo)} to extract"
                f"  archive={combined.stat().st_size / 1024**3:.2f} GiB"
                f"  free={free_bytes(data_root) / 1024**3:.1f} GiB"
            )
            archive.extractall(path=str(staging), callback=Progress(total, have, say))
    except Exception as exc:  # noqa: BLE001 - reported, not swallowed
        say(f"FAILED {scene}: {type(exc).__name__}: {exc}")
        say(f"partial output kept at {staging}")
        log.close()
        return "failed"

    with py7zr.SevenZipFile(combined, mode="r") as archive:
        todo, total = missing_members(archive, staging)
    if todo:
        say(f"INCOMPLETE after run: {len(todo)}/{total} members still missing; kept in staging")
        log.close()
        return "partial"

    counts = count_tree(staging)
    say(f"all {total} members present in {(time.time() - started) / 60:.1f} min; moving into place")
    try:
        os.replace(staging, final)
    except OSError as exc:
        say(f"FAILED to move staging into place: {exc}")
        log.close()
        return "failed"
    say(f"DONE {scene} {json.dumps(counts)}")
    log.close()
    return "done"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive-dir", default="SPREAD")
    parser.add_argument("--data-root", default="data/external/spread")
    parser.add_argument("--report-dir", default="reports/spread-extract-2026-10-13")
    parser.add_argument("--scenes", nargs="*", default=list(DEFAULT_SCENES))
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--max-seconds", type=float, default=0.0)
    parser.add_argument("--scene", help=argparse.SUPPRESS)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    archive_dir = Path(args.archive_dir).resolve()
    data_root = Path(args.data_root).resolve()
    report_dir = Path(args.report_dir).resolve()
    log_dir = report_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    if args.worker and args.scene:
        outcome = extract_one(args.scene, archive_dir, data_root, log_dir, args.max_seconds)
        return 0 if outcome in {"done", "already", "partial"} else 1

    data_root.mkdir(parents=True, exist_ok=True)
    status_path = report_dir / "status.json"
    status: dict[str, str] = {}
    if status_path.is_file():
        status = json.loads(status_path.read_text(encoding="utf-8")).get("scenes", {})
    for scene in args.scenes:
        status.setdefault(scene, "pending")

    def save() -> None:
        status_path.write_text(
            json.dumps(
                {
                    "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "free_bytes": free_bytes(data_root),
                    "scenes": status,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    save()
    remaining = [s for s in args.scenes if status.get(s) not in {"done", "already"}]

    def pick() -> str | None:
        for scene in list(remaining):
            free = free_bytes(data_root)
            if free < FREE_SPACE_FLOOR_BYTES:
                status[scene] = "blocked_no_space"
                print(f"[coord] free {free / 1024**3:.1f} GiB below floor; not starting {scene}", flush=True)
                continue
            return scene
        return None

    def launch(scene: str) -> subprocess.Popen:
        status[scene] = "running"
        save()
        cmd = [
            sys.executable,
            str(Path(__file__).resolve()),
            "--scene",
            scene,
            "--worker",
            "--max-seconds",
            str(args.max_seconds),
            "--archive-dir",
            str(archive_dir),
            "--data-root",
            str(data_root),
            "--report-dir",
            str(report_dir),
        ]
        print(f"[coord] launching {scene}", flush=True)
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

    active: dict[str, subprocess.Popen] = {}
    while remaining or active:
        while len(active) < max(1, args.workers) and remaining:
            choice = pick()
            if choice is None:
                break
            remaining.remove(choice)
            active[choice] = launch(choice)
        if not active:
            break
        time.sleep(3)
        for scene, proc in list(active.items()):
            code = proc.poll()
            if code is None:
                continue
            status[scene] = "done" if code == 0 else "failed"
            print(f"[coord] {scene} -> {status[scene]} (exit {code})", flush=True)
            del active[scene]
            save()

    save()
    summary = {
        "scenes": status,
        "free_bytes": free_bytes(data_root),
        "counts": {s: count_tree(data_root / s) for s in args.scenes if (data_root / s).is_dir()},
        "staging_leftovers": sorted(p.name for p in (data_root / ".inprogress").iterdir())
        if (data_root / ".inprogress").is_dir()
        else [],
    }
    (report_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("[coord] summary:", json.dumps(status), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
