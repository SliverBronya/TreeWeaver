"""Controlled double-tree compositing pilot, not real complex-forest accuracy.

Source masks are target envelopes. Pasted sky/background and synthetic edges are
known artifacts. Train sources and development sources have disjoint tree IDs.
"""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-run", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument("--include-real", action="store_true")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 1000:
        parser.error("Require fresh output and1..1000 steps")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from scipy.optimize import linear_sum_assignment
    from torch.nn import functional as F

    from data import cfg, set_cfg

    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    torch.manual_seed(42)
    rng = np.random.default_rng(42)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (256, 256)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from utils.augmentations import FastBaseTransform

    from workers.tree_models.auto_stem import AutoStemOwnership, center_focal_loss, gaussian_stems
    from workers.tree_models.stem_ownership import ownership_loss
    from workers.tree_models.stem_proxy import lower_mask_proxy

    manifest = json.loads((args.baseline_run / "manifest.json").read_text())
    baseline = ConvexMask().cuda()
    baseline.load_state_dict(
        torch.load(
            args.baseline_run / "pilot_checkpoint.pth", map_location="cuda", weights_only=True
        ),
        strict=True,
    )
    baseline.requires_grad_(False)
    baseline.train()
    transform = FastBaseTransform()
    args.output.mkdir(parents=True)
    sources = {}
    for record in manifest["train"] + manifest["test"]:
        image = cv2.imread(record["image"])
        annotation = json.loads(Path(record["annotation"]).read_text(encoding="utf-8"))
        mask = np.zeros(image.shape[:2], np.uint8)
        for shape in annotation["shapes"]:
            if shape["label"] == "tree":
                cv2.fillPoly(mask, [np.round(np.asarray(shape["points"])).astype(np.int32)], 1)
        ys, xs = np.nonzero(mask)
        crop = np.s_[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
        sources[record["image"]] = (image[crop], mask[crop])

    def composite(records, serial):
        for _ in range(100):
            first, second = rng.choice(len(records), 2, replace=False)
            if records[first]["tree_id"] != records[second]["tree_id"]:
                break
        chosen = [records[first], records[second]]
        canvas = np.full((256, 256, 3), rng.integers(140, 220), np.uint8)
        labels = np.zeros((256, 256), np.uint8)
        layers = []
        positions = [int(rng.integers(0, 45)), int(rng.integers(80, 115))]
        for identity, (record, left) in enumerate(zip(chosen, positions, strict=True), 1):
            image, mask = sources[record["image"]]
            height = int(rng.integers(195, 238))
            width = int(rng.integers(125, 170))
            width = min(width, 256 - left)
            top = int(rng.integers(0, 256 - height))
            warped = np.zeros_like(canvas)
            region = np.zeros(labels.shape, np.uint8)
            warped[top : top + height, left : left + width] = cv2.resize(image, (width, height))
            region[top : top + height, left : left + width] = cv2.resize(
                mask, (width, height), interpolation=cv2.INTER_NEAREST
            )
            layers.append((identity, warped, region > 0))
        if rng.random() < 0.5:
            layers.reverse()
        for identity, image, mask in layers:
            canvas[mask] = image[mask]
            labels[mask] = identity
        points = []
        for identity in (1, 2):
            proxy = lower_mask_proxy(labels == identity)
            ys, xs = np.nonzero(proxy)
            if len(xs) < 3:
                return None
            points.append([float(xs.mean() / 255), float(ys.mean() / 255)])
        with torch.no_grad():
            raw = baseline(transform(torch.as_tensor(canvas).float()[None]))
            features = raw["proto"].permute(0, 3, 1, 2).detach()
        h, w = features.shape[-2:]
        target = torch.as_tensor(
            cv2.resize(labels, (w, h), interpolation=cv2.INTER_NEAREST), dtype=torch.long
        )[None]
        center_target = gaussian_stems(points, h, w, features.device).amax(1, keepdim=True)
        for x, y in points:
            center_target[0, 0, round(y * (h - 1)), round(x * (w - 1))] = 1
        return {
            "rgb": canvas,
            "labels": labels,
            "target": target,
            "points": points,
            "features": features,
            "center_target": center_target,
            "rgb_tensor": torch.as_tensor(canvas).permute(2, 0, 1)[None].float() / 127.5 - 1,
            "serial": serial,
            "source_tree_ids": [record["tree_id"] for record in chosen],
        }

    datasets = {}
    for split, records, count in (
        ("train", manifest["train"], 32),
        ("validation", manifest["test"], 8),
    ):
        samples = []
        for attempt in range(count * 20):
            sample = composite(records, attempt)
            if sample is not None:
                samples.append(sample)
            if len(samples) == count:
                break
        if len(samples) < count:
            raise ValueError("Unable to form two visible weak-stem proxies; no invented centers")
        datasets[split] = samples
    real_training_samples = []
    if args.include_real:
        for record in manifest["train"]:
            original = cv2.imread(record["image"])
            annotation = json.loads(Path(record["annotation"]).read_text(encoding="utf-8"))
            mask = np.zeros(original.shape[:2], np.uint8)
            for shape in annotation["shapes"]:
                if shape["label"] == "tree":
                    cv2.fillPoly(mask, [np.round(np.asarray(shape["points"])).astype(np.int32)], 1)
            labels = cv2.resize(mask, (256, 256), interpolation=cv2.INTER_NEAREST)
            proxy = lower_mask_proxy(labels)
            ys, xs = np.nonzero(proxy)
            if len(xs) < 3:
                continue
            points = [[float(xs.mean() / 255), float(ys.mean() / 255)]]
            image = cv2.resize(original, (256, 256))
            with torch.no_grad():
                raw = baseline(transform(torch.as_tensor(image).float()[None]))
                features = raw["proto"].permute(0, 3, 1, 2).detach()
            h, w = features.shape[-2:]
            target = torch.as_tensor(
                cv2.resize(labels, (w, h), interpolation=cv2.INTER_NEAREST), dtype=torch.long
            )[None]
            center_target = gaussian_stems(points, h, w, features.device)
            x, y = points[0]
            center_target[0, 0, round(y * (h - 1)), round(x * (w - 1))] = 1
            # Unannotated neighboring trees are not valid negative stem-center examples.
            known = (target[:, None] > 0) | (center_target > 0.05)
            real_training_samples.append(
                {
                    "features": features,
                    "points": points,
                    "target": target,
                    "center_target": center_target,
                    "center_known": known,
                    "rgb_tensor": torch.as_tensor(image).permute(2, 0, 1)[None].float() / 127.5 - 1,
                }
            )
        datasets["train"].extend(real_training_samples)
    model = AutoStemOwnership().cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    history = []
    for step in range(args.steps):
        sample = datasets["train"][step % len(datasets["train"])]
        output = model(sample["features"], sample["points"], sample["rgb_tensor"])
        # Teacher weak centers only during training, never validation/inference.
        center_loss = center_focal_loss(
            output["heatmap"], sample["center_target"], sample.get("center_known")
        )
        mask_loss = ownership_loss(output["logits"], sample["target"])
        loss = center_loss + mask_loss
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
        optimizer.step()
        history.append(
            {
                "step": step + 1,
                "center_loss": float(center_loss.detach()),
                "ownership_loss": float(mask_loss.detach()),
            }
        )
        if (step + 1) % 100 == 0:
            print(json.dumps(history[-1]), flush=True)
    torch.save(model.state_dict(), args.output / "auto_stem_checkpoint.pth")
    model.eval()
    results = []
    with torch.no_grad():
        for i, sample in enumerate(datasets["validation"]):
            output = model(sample["features"], rgb=sample["rgb_tensor"])
            prediction = (
                F.interpolate(output["logits"], (256, 256), mode="bilinear", align_corners=False)
                .argmax(1)[0]
                .cpu()
                .numpy()
            )
            count = len(output["points"])
            matrix = np.zeros((2, count))
            for target in range(2):
                for predicted in range(count):
                    gt, mask = sample["labels"] == target + 1, prediction == predicted + 1
                    matrix[target, predicted] = (gt & mask).sum() / max((gt | mask).sum(), 1)
            score = 0.0
            if count:
                rows, cols = linear_sum_assignment(-matrix)
                score = float(matrix[rows, cols].sum() / 2)
            overlay = sample["rgb"].copy()
            colors = ([255, 70, 0], [0, 180, 255], [100, 255, 80], [220, 50, 190])
            for identity in range(count):
                mask = prediction == identity + 1
                overlay[mask] = (0.6 * overlay[mask] + 0.4 * np.array(colors[identity])).astype(
                    np.uint8
                )
            cv2.imwrite(str(args.output / f"synthetic_{i:02d}_rgb.png"), sample["rgb"])
            cv2.imwrite(str(args.output / f"synthetic_{i:02d}_overlay.png"), overlay)
            results.append(
                {
                    "sample": i,
                    "predicted_centers": count,
                    "matched_visible_envelope_iou": score,
                    "source_tree_ids": sample["source_tree_ids"],
                }
            )
        for filename in ("7001.jpg", "7002.jpg"):
            path = Path(manifest["train"][0]["image"]).parent / filename
            original = cv2.imread(str(path))
            raw = baseline(
                transform(torch.as_tensor(cv2.resize(original, (256, 256))).float()[None])
            )
            rgb = torch.as_tensor(original).permute(2, 0, 1)[None].float() / 127.5 - 1
            output = model(raw["proto"].permute(0, 3, 1, 2), rgb=rgb)
            prediction = (
                F.interpolate(
                    output["logits"], original.shape[:2], mode="bilinear", align_corners=False
                )
                .argmax(1)[0]
                .cpu()
                .numpy()
            )
            overlay = original.copy()
            for identity in range(len(output["points"])):
                mask = prediction == identity + 1
                overlay[mask] = (0.6 * overlay[mask] + 0.4 * np.array(colors[identity])).astype(
                    np.uint8
                )
            for x, y in output["points"]:
                cv2.circle(
                    overlay,
                    (round(x * (original.shape[1] - 1)), round(y * (original.shape[0] - 1))),
                    12,
                    (0, 0, 255),
                    3,
                )
            cv2.imwrite(str(args.output / f"real_{path.stem}_overlay.png"), overlay)
            results.append(
                {
                    "real_image": str(path),
                    "predicted_centers": len(output["points"]),
                    "center_points_normalized_xy": output["points"],
                    "accuracy_unknown": True,
                }
            )
    report = {
        "steps": args.steps,
        "mode": "synthetic visible-envelope pilot",
        "train_samples": 32,
        "real_target_training_samples": len(real_training_samples),
        "validation_samples": 8,
        "results": results,
        "real_accuracy_validated": False,
        "depth_used": False,
        "limitations": [
            "Pasted envelope backgrounds create artificial shortcuts",
            "Centers are weak geometric proxies, not anatomical labels",
            "Trains only two-instance synthetic examples",
            "Teacher-forced weak centers used in ownership training only",
            "No metric tree measurements or hidden-geometry validation",
        ],
    }
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
