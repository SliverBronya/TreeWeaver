"""Train the stem token on the TreeStereo trunk trees the policy actually allows.

History: the first version of this script (2026-11-02, reports/stem-treestereo-300-2026-11-02)
trained on all 64 train-role trunks *and* selected its checkpoint with
``val_iou + protected_iou``. That made the 12 protected trees part of model
selection and turned the pooled 90-tree trunk reference into a contaminated
number. This version:

* asks the dataset-usage policy for permission with the exact tree identities
  (train role only, 64 trees);
* refuses a split file whose roles share identities;
* writes a frozen protocol with file hashes before the first optimizer step;
* selects on validation only and reports protected separately;
* records every tree, and runs stock SAM2 on the same prompts.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from evaluate_treestereo_visible import decode_reference, reference_box  # noqa: E402
from research_protocol import (  # noqa: E402
    assert_training_allowed,
    hash_files,
    pinned_snapshot,
    sha256_file,
)
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import (  # noqa: E402
    assert_disjoint_roles,
    mask_row,
    mean_of,
    paired,
    stem_masks,
    stock_masks,
    write_json,
)

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
TRUNKS = ROOT / "data/external/tree-stereo-biophysical-v4/extracted/trunks"
SPLITS = ROOT / "reports/real-visible-pilot-2026-11-01/splits.json"
CHECKPOINT = ROOT / "reports/fig500-long-5h-v2-2026-10-31/best.pth"
SEED = 1729


def records():
    split = json.loads(SPLITS.read_text(encoding="utf-8"))
    train = set(split["splits"]["train"])
    val = set(split["splits"]["validation"])
    protected = set(split["protected_reference_tree_ids"])
    excluded = set(split["excluded_legacy_tree_ids"])
    assert_disjoint_roles(
        {"train": train, "validation": val, "protected": protected, "excluded": excluded}
    )
    rows = []
    for mask_path in sorted(TRUNKS.glob("*_LEFT_mask.jpg")):
        tree_id = int(mask_path.name.split("_")[0].lstrip("T"))
        image_path = mask_path.with_name(mask_path.name.replace("_mask.jpg", ".jpg"))
        if tree_id in excluded:
            role = "excluded"
        elif tree_id in protected:
            role = "protected"
        elif tree_id in val:
            role = "validation"
        elif tree_id in train:
            role = "train"
        else:
            role = "unassigned"
        rows.append(
            {"tree_id": tree_id, "role": role, "image": image_path, "mask": mask_path}
        )
    return rows


def load_pair(record, processor, device):
    image = cv2.imread(str(record["image"]))
    mask = decode_reference(cv2.imread(str(record["mask"])))
    if image is None or image.shape[:2] != mask.shape:
        raise ValueError(f"bad pair {record['image']}")
    height, width = mask.shape
    pixels = processor(
        images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), return_tensors="pt"
    )["pixel_values"].to(device)
    box = torch.tensor(reference_box(mask), device=device) * torch.tensor(
        [1024 / width, 1024 / height, 1024 / width, 1024 / height], device=device
    )
    return pixels, box[None, None], mask


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2)) + target.sum(dim=(1, 2)) + 1.0
    )


def evaluate(model, sam2, rows, processor, device):
    """Per-tree rows for the stem decoder and stock SAM2 on identical boxes."""
    model.eval()
    output = []
    for record in rows:
        pixels, box, target = load_pair(record, processor, device)
        height, width = target.shape
        stem = stem_masks(model, pixels, box, height, width)[0]
        stock = stock_masks(sam2, pixels, box, height, width)[0]
        output.append(
            {
                "tree_id": record["tree_id"],
                "role": record["role"],
                "stem": mask_row(record["tree_id"], stem, target),
                "stock_sam2": mask_row(record["tree_id"], stock, target),
            }
        )
    model.train()
    return output


def build_protocol(rows, args, scope):
    by_role = {}
    for row in rows:
        by_role.setdefault(row["role"], set()).add(row["tree_id"])
    files = {}
    paths = []
    for row in rows:
        if row["role"] in ("train", "validation", "protected"):
            for key in ("image", "mask"):
                path = Path(row[key])
                paths.append(path)
                files[path.relative_to(TRUNKS).as_posix()] = sha256_file(path)
    return {
        "schema_version": "treeweaver-stem-training-1.0",
        "profile": "dataset_supplied_visible_trunk_reference",
        "role": "development",
        "dataset": {
            "root": str(TRUNKS.resolve()),
            "reference_semantics": (
                "dataset-supplied filled visible trunk silhouettes (max(BGR)>127); "
                "no fill, morphology, convex hull or model-assisted editing"
            ),
            "one_LEFT_view_per_tree": True,
        },
        "policy_scope": scope,
        "tree_ids_by_role": {name: sorted(values) for name, values in by_role.items()},
        "supervision": ["dataset_supplied_visible_stem"],
        "prompt": "GT-derived 5%-padded box; no stem point, no neighbour negative point",
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "trainable": ["stem_token", "stem_hypernet"],
            "frozen": "encoder, prompt encoder, all other decoder parameters",
            "init_checkpoint": str(CHECKPOINT),
            "init_checkpoint_sha256": sha256_file(CHECKPOINT),
            "init_checkpoint_note": (
                "fig-500 five-hour decoder; its stem token was never trained, so this run "
                "reports stem-head adaptation rather than a new encoder"
            ),
        },
        "optimizer": {"name": "AdamW", "lr": args.lr, "weight_decay": args.weight_decay},
        "seed": SEED,
        "steps": args.steps,
        "eval_every": args.eval_every,
        "selection": "validation mean IoU only; protected trees never select a checkpoint",
        "data_sha256": {
            "files": files,
            "combined": hash_files(paths, base=TRUNKS),
        },
        "split": {
            "path": str(SPLITS),
            "sha256": sha256_file(SPLITS),
            "tree_disjoint": True,
            "scene_disjoint": False,
        },
        "limitations": [
            "one LEFT view per tree; not all views",
            "GT-derived box is an upper-bound prompt, not autonomous detection",
            "no stem point and no neighbour negative point, so adhesion is not tested here",
            "the 64 training trunks were visible to this weight, so validation is development-only",
            "protected 12 were contaminated by checkpoint selection in the 2026-11-02 run",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    rows = records()
    train = [row for row in rows if row["role"] == "train"]
    validation = [row for row in rows if row["role"] == "validation"]
    protected = [row for row in rows if row["role"] == "protected"]
    if not train or not validation:
        raise ValueError("Training needs non-empty train and validation roles")
    scope = assert_training_allowed(TRUNKS, tree_ids=[row["tree_id"] for row in train])
    protocol = build_protocol(rows, args, scope)
    write_json(args.output / "protocol.json", protocol)
    print(
        json.dumps(
            {
                "train": len(train),
                "validation": len(validation),
                "protected": len(protected),
                "policy": scope["policy_entry"],
            }
        ),
        flush=True,
    )

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3, enable_stem=True).to(args.device)
    payload = torch.load(CHECKPOINT, map_location=args.device, weights_only=True)
    result = model.decoder.load_state_dict(payload["decoder"], strict=False)
    missing = [
        key for key in result.missing_keys if not key.startswith(("stem_token.", "stem_hypernet."))
    ]
    if missing or result.unexpected_keys:
        raise ValueError(f"unexpected checkpoint mismatch: {missing} {result.unexpected_keys}")
    for parameter in model.parameters():
        parameter.requires_grad = False
    for name, parameter in model.decoder.named_parameters():
        if name.startswith(("stem_token", "stem_hypernet")):
            parameter.requires_grad = True
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    history = []
    best = {"score": -1.0, "step": 0}
    for step in range(1, args.steps + 1):
        record = random.choice(train)
        pixels, box, target = load_pair(record, processor, args.device)
        output = model(pixel_values=pixels, input_boxes=box, multimask_output=False)
        logits = output["stem_masks"][0, 0, 0]
        ground_truth = F.interpolate(
            torch.as_tensor(target, device=args.device)[None, None].float(),
            logits.shape[-2:],
            mode="nearest",
        )[0, 0]
        loss = F.binary_cross_entropy_with_logits(logits, ground_truth) + dice_loss(
            logits[None, None], ground_truth[None, None]
        ).mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step % 20 == 0:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % args.eval_every == 0 or step == args.steps:
            scored = evaluate(model, sam2, validation, processor, args.device)
            guarded = evaluate(model, sam2, protected, processor, args.device)
            row = {
                "step": step,
                "val_iou": mean_of([item["stem"] for item in scored], "iou"),
                "val_stock_iou": mean_of([item["stock_sam2"] for item in scored], "iou"),
                # Reported only: protected trees must never select a checkpoint.
                "protected_iou_reported_only": mean_of([item["stem"] for item in guarded], "iou"),
                "protected_stock_iou_reported_only": mean_of(
                    [item["stock_sam2"] for item in guarded], "iou"
                ),
                "loss": float(loss.detach()),
            }
            history.append(row)
            print("EVAL", json.dumps(row), flush=True)
            if row["val_iou"] > best["score"]:
                best = {"score": row["val_iou"], "step": step}
                torch.save(
                    {"decoder": model.decoder.state_dict(), "step": step, **row},
                    args.output / "stem_best.pth",
                )
                write_json(args.output / "history.json", history)

    checkpoint = torch.load(
        args.output / "stem_best.pth", map_location=args.device, weights_only=True
    )
    model.decoder.load_state_dict(checkpoint["decoder"])
    per_tree = evaluate(model, sam2, validation, processor, args.device) + evaluate(
        model, sam2, protected, processor, args.device
    )
    write_json(args.output / "per_tree.json", per_tree)

    def block(items):
        stem_rows = [item["stem"] for item in items]
        stock_rows = [item["stock_sam2"] for item in items]
        return {
            "trees": len(items),
            "stem": {
                "mean_iou": mean_of(stem_rows, "iou"),
                "mean_boundary_f1": mean_of(stem_rows, "boundary_f1"),
            },
            "stock_sam2": {
                "mean_iou": mean_of(stock_rows, "iou"),
                "mean_boundary_f1": mean_of(stock_rows, "boundary_f1"),
            },
            "paired": paired(items),
        }

    summary = {
        "schema_version": protocol["schema_version"],
        "selected_step": checkpoint["step"],
        "selection_metric": "validation mean IoU",
        "validation": block([item for item in per_tree if item["role"] == "validation"]),
        "protected_reported_only": block(
            [item for item in per_tree if item["role"] == "protected"]
        ),
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "clean_holdout": False,
        "notes": [
            "Protected trees were reported, not used for selection, in this run.",
            "The earlier reports/stem-treestereo-300-2026-11-02 run used them for selection, "
            "so its protected number is not comparable.",
            "Training trees appear in the training set; validation is development, not test.",
        ],
    }
    write_json(args.output / "summary.json", summary)
    write_json(args.output / "history.json", history)
    print("DONE", json.dumps(summary))


if __name__ == "__main__":
    main()
