"""Package native saved render products for the strict CPU scene qualifier."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def mask(path):
    with Image.open(path) as image:
        pixels = np.array(image.convert("RGBA"))
    return (pixels[..., 0] > 127) & (pixels[..., 3] > 127)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--render", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--joint-depth", action="store_true")
    args = parser.parse_args()
    folder = args.render.resolve()
    destination = args.output.resolve() if args.output else folder
    if args.joint_depth and args.output is None:
        parser.error("joint-depth packaging requires a separate --output directory")
    if args.output:
        destination.mkdir(parents=True, exist_ok=False)
    for name in ("scene.json", "labels.npz", "asset_manifest.json"):
        if (destination / name).exists():
            parser.error("packaged output already exists: " + name)
    result = json.loads((folder / "result.json").read_text(encoding="utf-8"))
    camera = json.loads((folder / "metric-camera.json").read_text(encoding="utf-8"))
    masks = folder / "masks/000001"
    count = len(result["assets"])

    def stack(prefix):
        return np.stack([mask(masks / f"{prefix}_{i + 1}.png") for i in range(count)])

    visible, full = stack("visible"), stack("amodal")
    known = ~stack("raster_unknown").any(0)
    with np.load(folder / "metric_depth.npz", allow_pickle=False) as data:
        z, depth_valid, surface_ids = data["depth_z_m"], data["valid"], data["object_id"]
    known &= surface_ids < 100
    owner = np.zeros(known.shape, np.int32)
    for i, support in enumerate(visible):
        owner[support] = i + 1
    segmentation_known = known.copy()
    coverage = {
        "mode": "original_segmentation_support",
        "original_known_visible_tree_pixels": int((visible & known).sum()),
    }
    if args.joint_depth:
        # Preserve V/A and RGB-only validity. Joint RGB-D supervision requires
        # the same sampled surface identity, not invented depths at AA fringes.
        identity_agrees = owner == surface_ids
        known = known & depth_valid & identity_agrees
        coverage.update(
            {
                "mode": "joint_depth_and_surface_identity_valid_subset",
                "joint_known_visible_tree_pixels": int((visible & known).sum()),
                "RGB_only_validity_preserved": True,
                "depth_interpolation_or_fill": False,
            }
        )
    owner[~known] = -1
    arrays = {
        "visible": visible,
        "amodal": full,
        "known": known,
        "owner": owner,
        "stem": stack("visible_stem"),
        "crown": stack("visible_crown_surface"),
        "part_unknown": stack("visible_part_unknown"),
        "segmentation_known": segmentation_known,
        "depth": z,
        "depth_valid": depth_valid,
        "instance_ids": np.arange(1, count + 1, dtype=np.int32),
    }
    assets, instances = [], []
    for i, name in enumerate(result["assets"]):
        path = ROOT / "tools/assets/sketchfab/fig_trees" / name
        assets.append({"asset": name, "sha256": digest(path)})
        metrics = {
            key: {
                "value": None,
                "unit": unit,
                "status": "unavailable",
                "provenance": "rendered_asset_qualification_pending",
                "reason": "unqualified main stem, wood solid or opacity-resolved crown geometry",
            }
            for key, unit in (
                ("tree_height_m", "m"),
                ("crown_width_x_m", "m"),
                ("crown_width_y_m", "m"),
                ("dbh_m", "m"),
                ("wood_volume_m3", "m3"),
            )
        }
        metrics["tree_height_m"] = {
            "value": 9,
            "unit": "m",
            "status": "estimated_virtual_geometry",
            "provenance": "nominal assigned source vertex-envelope height; alpha cards unresolved",
        }
        instances.append(
            {
                "instance_id": i + 1,
                "asset_id": name,
                "source_group_id": name,
                "frame_truncated": i > 0,
                "geometry_metrics": metrics,
            }
        )
    manifest = json.dumps(assets, sort_keys=True, indent=2).encode("utf-8")
    document = {
        "schema_version": "treeweaver-metric-scene-1.0",
        "world": {
            "unit": "m",
            "blender_unit_in_meters": 1.0,
            "truth_domain": "synthetic_metric_geometry",
        },
        "camera": {
            "model": "pinhole",
            "axes": "opencv_x_right_y_down_z_forward",
            "image_wh": camera["native_image_wh"],
            "K": camera["K"],
            "T_world_from_camera": camera["T_world_from_cv"],
        },
        "depth": {"unit": "m", "convention": "camera_z_m", "image_wh": camera["native_image_wh"]},
        "label_provenance": {
            "visible": "full_scene_instance_id_render",
            "amodal": "same_camera_remove_declared_external_occluders",
            "visible_parts": "full_scene_frontmost_part_id_render",
        },
        "generator_sha256": digest(ROOT / "scripts/render_cuda_tree_scene.py"),
        "asset_manifest_sha256": hashlib.sha256(manifest).hexdigest(),
        "instances": instances,
        "training_allowed": False,
        "visible_part_definition": "source bark versus crown surface; main stem not certified",
        "parts_training_allowed": False,
        "source_family_split_verified": False,
        "background_tree_pixels_excluded": True,
        "known_domain": coverage,
    }
    (destination / "asset_manifest.json").write_bytes(manifest)
    (destination / "scene.json").write_text(json.dumps(document, indent=2), encoding="utf-8")
    np.savez_compressed(destination / "labels.npz", **arrays)
    print(
        json.dumps(
            {
                "scene": str(destination / "scene.json"),
                "coverage": coverage,
                "training_allowed": False,
            }
        )
    )


if __name__ == "__main__":
    main()
