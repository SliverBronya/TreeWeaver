"""Targeted fine-tune: Tversky + curve-profile consistency from the 5h model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2, 3))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + 1.0
    )


def tversky_loss(logits, target, alpha=0.3, beta=0.7, eps=1e-6):
    probability = logits.sigmoid()
    dims = (1, 2, 3)
    tp = (probability * target).sum(dim=dims)
    fp = (probability * (1.0 - target)).sum(dim=dims)
    fn = ((1.0 - probability) * target).sum(dim=dims)
    return 1.0 - (tp + eps) / (tp + alpha * fp + beta * fn + eps)


def boundary_loss(logits, target, eps=1e-4):
    probability = logits.sigmoid()
    with torch.no_grad():
        dilated = F.max_pool2d(target, 3, 1, 1)
        eroded = -F.max_pool2d(-target, 3, 1, 1)
        edge = (dilated - eroded).clamp(0, 1)
    pred_edge = (F.max_pool2d(probability, 3, 1, 1) + F.max_pool2d(-probability, 3, 1, 1)).clamp(
        0, 1
    )
    return F.binary_cross_entropy(pred_edge.clamp(eps, 1 - eps), edge)


def trainable_groups(model):
    new_prefixes = (
        "amodal_token",
        "visibility_token",
        "curve_token",
        "occluder_token",
        "stem_token",
        "amodal_hypernets",
        "occluder_hypernet",
        "stem_hypernet",
        "router",
        "visibility_mean",
        "visibility_log_variance",
        "curve_head",
        "amodal_scale",
        "ownership_projection",
        "ownership_conv",
        "ownership_bg",
        "layer_head",
    )
    new, base = [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if not name.startswith("decoder."):
            new.append(parameter)
            continue
        local = name[len("decoder.") :]
        (new if local.startswith(new_prefixes) else base).append(parameter)
    return new, base


def iou(pred, gt):
    return float((pred & gt).sum()) / max(float((pred | gt).sum()), 1.0)


def evaluate(model, dataset, limit, device):
    model.eval()
    visible, amodal, ownership, visibility = [], [], [], []
    for index in range(min(limit, len(dataset))):
        sample = dataset.sample(index)
        with torch.no_grad():
            output = model(
                torch.as_tensor(sample["pixel_values"])[None].to(device),
                input_boxes=torch.as_tensor(sample["boxes"])[None].to(device),
            )
        count = int(sample["num_objects"])
        pred_v = output["masks"][0, :, 0] > 0
        pred_a = output["amodal_masks"][0, :, 0] > 0
        gt_v = torch.as_tensor(sample["visible"]).to(device) > 0.5
        gt_a = torch.as_tensor(sample["amodal"]).to(device) > 0.5
        for i in range(count):
            visible.append(iou(pred_v[i], gt_v[i]))
            amodal.append(iou(pred_a[i], gt_a[i]))
        own = output["ownership_logits"][0].argmax(0)
        gt_own = torch.as_tensor(sample["ownership"]).to(device)
        fg = gt_own > 0
        ownership.append(float((own[fg] == gt_own[fg]).float().mean()) if fg.any() else 1.0)
        visibility.append(
            float(np.abs(output["visibility"][0].cpu().numpy() - sample["visibility"]).mean())
        )
    model.train()
    return {
        "visible": float(np.mean(visible)),
        "amodal": float(np.mean(amodal)),
        "ownership_fg": float(np.mean(ownership)),
        "visibility": float(np.mean(visibility)),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-root", type=Path, default=ROOT / "reports" / "fig-500-v2-2026-10-31"
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=ROOT / "reports" / "fig500-long-5h-v2-2026-10-31" / "best.pth",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--eval-images", type=int, default=10)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    from curve_consistency import curve_profile_loss
    from fig500_dataset import Fig500Multi
    from occlusion_aware import amodal_bce, amodal_containment_loss, curve_nll
    from sam2_occlusion import Sam2OcclusionModel
    from stem_proxy import lower_mask_proxy

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    train = Fig500Multi(args.data_root, "train", mean=mean, std=std)
    val = Fig500Multi(args.data_root, "val", mean=mean, std=std)

    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3, enable_stem=True).to(args.device)
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    model.train()

    new, base = trainable_groups(model)
    optimizer = torch.optim.AdamW(
        [{"params": new, "lr": 5e-5}, {"params": base, "lr": 1e-6}], weight_decay=1e-4
    )
    history = []
    best = -1.0
    for step in range(1, args.steps + 1):
        sample = train.sample(np.random.randint(len(train)))
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(args.device)
        boxes = torch.as_tensor(sample["boxes"])[None].to(args.device)
        visible = torch.as_tensor(sample["visible"])[None].to(args.device)
        amodal = torch.as_tensor(sample["amodal"])[None].to(args.device)
        ownership = torch.as_tensor(sample["ownership"])[None].to(args.device)
        layer = torch.as_tensor(sample["layer"])[None].to(args.device)
        curve = torch.as_tensor(sample["curve"])[None].to(args.device)
        observed = torch.as_tensor(sample["curve_observed"])[None].to(args.device)
        stem_target = torch.stack(
            [
                torch.as_tensor(lower_mask_proxy(mask > 0.5)).to(args.device).float()
                for mask in sample["visible"]
            ]
        )[None]
        stem_valid = stem_target.sum() > 0

        output = model(pixel_values, input_boxes=boxes)
        v_logits = output["masks"][:, :, 0]
        a_logits = output["amodal_masks"][:, :, 0]
        mask_loss = (
            F.binary_cross_entropy_with_logits(v_logits, visible)
            + dice_loss(v_logits, visible).mean()
            + 0.5 * tversky_loss(v_logits, visible).mean()
            + 0.2 * boundary_loss(v_logits, visible)
        )
        count = int(sample["num_objects"])
        own_weight = torch.tensor([0.2] + [1.0] * count, device=args.device)
        own_loss = F.cross_entropy(output["ownership_logits"], ownership, weight=own_weight)
        upper = torch.triu_indices(count, count, 1, device=args.device)
        layer_loss = F.binary_cross_entropy_with_logits(
            output["layer_logits"][0, upper[0], upper[1]],
            (layer[0, upper[0], upper[1]] > 0).float(),
        )
        curve_loss = curve_nll(output["curve"], output["curve_log_sigma"], curve, observed)
        # Targets are full-tree profiles: align with amodal masks, not visible
        # rows whose widths legitimately shrink behind an occluder.
        profile_loss = curve_profile_loss(a_logits, curve, observed, reference_mask=amodal)
        stem_logits = output["stem_masks"][:, :, 0]
        stem_loss = (
            F.binary_cross_entropy_with_logits(stem_logits, stem_target)
            + dice_loss(stem_logits, stem_target).mean()
            if stem_valid
            else stem_logits.sum() * 0
        )
        loss = (
            mask_loss
            + 0.25 * own_loss
            + 0.1 * layer_loss
            + 0.3 * amodal_bce(a_logits, amodal, visible, 3.0)
            + 0.1 * amodal_containment_loss(a_logits, visible)
            + 0.05 * curve_loss
            + 0.3 * profile_loss
            + 0.5 * stem_loss
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        if step % 10 == 0:
            print(
                f"step {step}/{args.steps} loss {float(loss.detach()):.4f} "
                f"mask {float(mask_loss.detach()):.4f} "
                f"profile {float(profile_loss.detach()):.4f} stem {float(stem_loss.detach()):.4f}",
                flush=True,
            )
        if step % args.eval_every == 0 or step == args.steps:
            metrics = evaluate(model, val, args.eval_images, args.device)
            row = {"step": step, **metrics, "loss": float(loss.detach())}
            history.append(row)
            print("EVAL", json.dumps(row), flush=True)
            score = metrics["visible"] + 0.5 * metrics["amodal"] + metrics["ownership_fg"]
            if score > best:
                best = score
                torch.save(
                    {"decoder": model.decoder.state_dict(), "step": step, **metrics},
                    args.output / "decoder_best.pth",
                )
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (args.output / "run.json").write_text(
        json.dumps(
            {"steps": args.steps, "best": best, "checkpoint": str(args.checkpoint)}, indent=2
        ),
        encoding="utf-8",
    )
    print("DONE", args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
