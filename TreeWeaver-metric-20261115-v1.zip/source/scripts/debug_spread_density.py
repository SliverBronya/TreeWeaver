"""Quantify mask sparsity (hull/raster) across SPREAD scenes (throwaway)."""
from __future__ import annotations
import json, random, sys
from pathlib import Path
import cv2
import numpy as np

pal = {int(k): tuple(v) for k, v in json.loads(
    Path("data/external/spread/color_palette.json").read_text(encoding="utf-8"))["palette"].items()}
root = Path("data/external/spread")
rng = random.Random(42)

def frame_stats(scene, stem):
    idir = root / scene / "instance_segmentation"
    inst = cv2.cvtColor(cv2.imread(str(idir / f"{stem}.png")), cv2.COLOR_BGR2RGB)
    H, W = inst.shape[:2]
    ratios, areas, cov = [], [], 0
    for line in (idir / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
        pr = line.split()
        if len(pr) != 2 or not pr[0].startswith("Tree") or int(pr[1]) not in pal:
            continue
        mm = cv2.inRange(inst, np.array(pal[int(pr[1])]), np.array(pal[int(pr[1])]))
        a = int(mm.sum())
        if a < 10:
            continue
        mm = (cv2.resize(mm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
        cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        if not cs:
            continue
        hull = cv2.convexHull(np.concatenate(cs))
        ha = cv2.contourArea(hull)
        ra = int(mm.sum())
        cov += a
        areas.append(ra)
        if ha > 0:
            ratios.append(ra / ha)  # density = raster/hull (1 = compact)
    return ratios, areas, cov / (H * W)

for scene in ["birch_forest", "broadleaf_forest", "city_park"]:
    frames = sorted(p.stem for p in (root / scene / "rgb").glob("*.png"))
    rng.shuffle(frames)
    sample = frames[:30]
    all_ratios, all_areas, covs = [], [], []
    for s in sample:
        r, a, c = frame_stats(scene, s)
        all_ratios += r
        all_areas += a
        covs.append(c)
    r = np.array(all_ratios)
    print(f"=== {scene} (30 frames)")
    print(f"  coverage mean={np.mean(covs):.1%} median={np.median(covs):.1%}")
    print(f"  raster area @512 mean={np.mean(all_areas):.0f} median={np.median(all_areas):.0f}")
    print(f"  density raster/hull: mean={r.mean():.2f} median={np.median(r):.2f} "
          f"p10={np.percentile(r,10):.2f} | share density>0.5 (compact)={np.mean(r>0.5):.1%} "
          f"share density<0.15 (sparse)={np.mean(r<0.15):.1%}")
