"""Inspect matching RGB/labels without extracting whole datasets."""

import argparse
import json
import re
import urllib.request
import zipfile
from pathlib import Path

import cv2
import numpy as np
from audit_forest_dataset_samples import OUTPUT, RemoteZip


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", choices=["CanaTree100", "SynthTree43k"])
    args = parser.parse_args()
    report = json.loads((OUTPUT / "audit.json").read_text())
    try:
        text = (
            urllib.request.urlopen(
                "https://raw.githubusercontent.com/norlab-ulaval/PercepTreeV1/main/README.md",
                timeout=25,
            )
            .read()
            .decode()
        )
    except Exception:
        # Public download link already inspected in the author's README this run.
        text = (
            "http://norlab.s3.valeria.science/neats/CanaTree100.zip?"
            "AWSAccessKeyId=VCI7FLOHYPGLOOOAH0S5&Expires=2339251391&"
            "Signature=6beuqoLRQfCTaSpoC7ZKELhJwhY%3D"
        )
    for url in re.findall(r'http://norlab[^"\s]+', text):
        name = "CanaTree100" if "CanaTree100" in url else "SynthTree43k"
        if args.only and name != args.only:
            continue
        print(name, flush=True)
        remote = RemoteZip(url.replace("http://", "https://"))
        try:
            with zipfile.ZipFile(remote) as archive:
                if name == "CanaTree100":
                    document = json.loads((OUTPUT / "CanaTree100_test_fold_03.json").read_text())
                    image = document["images"][0]
                    entry = next(
                        e
                        for e in archive.namelist()
                        if Path(e).name == Path(image["file_name"]).name
                    )
                    rgb = cv2.imdecode(
                        np.frombuffer(archive.read(entry), np.uint8), cv2.IMREAD_COLOR
                    )
                    overlay = rgb.copy()
                    annotations = [
                        a for a in document["annotations"] if a["image_id"] == image["id"]
                    ]
                    for index, annotation in enumerate(annotations):
                        mask = np.zeros(rgb.shape[:2], np.uint8)
                        for polygon in annotation["segmentation"]:
                            points = np.round(np.array(polygon).reshape(-1, 2)).astype(np.int32)
                            cv2.fillPoly(mask, [points], 1)
                        color = np.array(
                            [
                                (index * 83 + 60) % 256,
                                (index * 57 + 100) % 256,
                                (index * 113 + 180) % 256,
                            ]
                        )
                        overlay[mask > 0] = (0.6 * overlay[mask > 0] + 0.4 * color).astype(np.uint8)
                    cv2.imwrite(str(OUTPUT / "CanaTree100_matching_GT_overlay.png"), overlay)
                    report[name]["matching_image"] = image
                    report[name]["matching_instance_count"] = len(annotations)
                    report[name]["annotation_fields"] = sorted(
                        set().union(*(a.keys() for a in annotations))
                    )
                    report[name]["licenses"] = document.get("licenses")
                else:
                    names = archive.namelist()
                    mask_entry = report[name]["sample_image"]
                    prefix = mask_entry.removesuffix("_mask.png")
                    report[name]["sample_related_files"] = [
                        n for n in names if n.startswith(prefix)
                    ]
                    for entry in report[name]["sample_related_files"]:
                        if "RGB" in entry or "rgb" in entry or "_img.png" in entry:
                            (OUTPUT / "SynthTree43k_matching_RGB.png").write_bytes(
                                archive.read(entry)
                            )
                    with archive.open("test_set/AllLabels.csv") as stream:
                        report[name]["csv_header_and_sample"] = stream.read(4096).decode(
                            errors="replace"
                        )
                    mask = cv2.imread(str(OUTPUT / "SynthTree43k_sample.png"), cv2.IMREAD_UNCHANGED)
                    report[name]["mask_shape"] = list(mask.shape)
                    report[name]["mask_unique_values_sample"] = (
                        np.unique(mask.reshape(-1, mask.shape[2]), axis=0).tolist()[:35]
                        if mask.ndim == 3
                        else np.unique(mask).tolist()[:35]
                    )
            report[name]["extra_range_bytes_transferred"] = remote.transferred
        except Exception as error:
            report[name]["extra_inspection_error"] = str(error)
        (OUTPUT / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    source = Path("D:/SAM3DepthPro/TreeHeight_backend/datasets/spread_occlusion_yolo")
    labels = sorted((source / "labels").rglob("*.txt"))
    images = [p for p in (source / "images").rglob("*") if p.is_file()]
    report["SPREAD_local_converted"] = {
        "image_count": len(images),
        "label_count": len(labels),
        "annotation_first_lines": labels[0].read_text().splitlines()[:2] if labels else [],
        "note": "Converted YOLO polygons do not preserve source tree IDs or separate anatomical parts automatically",
    }
    for scene in report["SPREAD_local"]:
        directory = Path("D:/SAM3DepthPro/SPREAD_labels") / scene["scene"]
        scene["has_rgb_png"] = bool(list((directory / "rgb").glob("*.png")))
        scene["has_instance_png"] = bool(list((directory / "instance_segmentation").glob("*.png")))
    (OUTPUT / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Finished matching samples", flush=True)


if __name__ == "__main__":
    main()
