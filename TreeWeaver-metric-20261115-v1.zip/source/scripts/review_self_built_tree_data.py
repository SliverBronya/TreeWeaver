"""Show existing synthetic RGB and same-camera truth; no rendering or training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "reports/fig-500-v2-2026-10-31"
PAIRED = ROOT / "reports/fig-paired-v6-framing-30-2026-11-08"
MIXED = ROOT / "reports/mixed-tree-grounded-qualification-2026-11-08"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def mask(path):
    array = np.asarray(Image.open(path).convert("RGBA"))
    return array[..., 3] > 16


def panel(image, size, background="white", *, nearest=False):
    result = Image.new("RGB", size, background)
    fitted = ImageOps.contain(
        image, size, Image.Resampling.NEAREST if nearest else Image.Resampling.LANCZOS
    )
    result.paste(fitted, ((size[0] - fitted.width) // 2, (size[1] - fitted.height) // 2))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    small = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 15)
    examples = [
        (OLD, 1, "旧500图：fig单树种，树冠密集交叠示例"),
        (PAIRED, 2, "新版疏密布局：分离的两棵树"),
        (PAIRED, 10, "新版疏密布局：三棵树交叠"),
        (MIXED, 33, "新增树形：Magnolia资产与两棵fig混合"),
    ]
    sheet = Image.new("RGB", (1280, 880), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text(
        (10, 8),
        "自建数据现状：已有训练侧样例；不同场景，不能视为同场景前后改进对照",
        font=font,
        fill="black",
    )
    selected = []
    for index, (root, number, title) in enumerate(examples):
        x, y = (index % 2) * 640, 45 + (index // 2) * 410
        meta = read(root / "meta" / f"{number:06d}.json")
        image = Image.open(root / "images" / f"{number:06d}.png").convert("RGB")
        draw.text((x + 8, y), title, font=font, fill="black")
        sheet.paste(image.resize((640, 360)), (x, y + 29))
        draw.text((x + 8, y + 391), f"{root.name} / {number:06d}", font=small, fill="black")
        selected.append({"dataset": str(root), "scene": number, "trees": meta["trees"]})
    sheet.save(args.output / "existing-datasets-overview.jpg", quality=94)

    # One target, one camera and one common crop across every panel.
    scene, target = 33, 2
    folder = MIXED / "masks" / f"{scene:06d}"
    visible = mask(folder / f"visible_{target}.png")
    amodal = mask(folder / f"amodal_{target}.png")
    unknown = mask(folder / f"raster_unknown_{target}.png")
    hidden = amodal & ~visible
    assert not (visible & ~amodal).any()
    yy, xx = np.nonzero(amodal | unknown)
    height, width = amodal.shape
    roi = (
        max(0, int(xx.min()) - 15),
        max(0, int(yy.min()) - 15),
        min(width, int(xx.max()) + 16),
        min(height, int(yy.max()) + 16),
    )
    rgb = Image.open(MIXED / "images" / f"{scene:06d}.png").convert("RGB")
    control = Image.open(
        MIXED / "counterfactuals" / f"{scene:06d}" / f"target_{target}_rgb.png"
    ).convert("RGB")
    rgb_roi = tuple(
        int(value * (rgb.width / width if i % 2 == 0 else rgb.height / height))
        for i, value in enumerate(roi)
    )
    panels = [rgb.crop(rgb_roi), control.crop(rgb_roi)]
    for support, color in (
        (visible, (255, 255, 255)),
        (amodal, (255, 255, 255)),
        (hidden, (205, 120, 245)),
    ):
        colored = np.zeros((height, width, 3), np.uint8)
        colored[support] = color
        colored[unknown] = (80, 80, 80)
        panels.append(Image.fromarray(colored).crop(roi))
    proof = Image.new("RGB", (1500, 490), "white")
    draw = ImageDraw.Draw(proof)
    draw.text(
        (10, 7),
        "补全标签如何得到：场景33 / Magnolia目标2；各图采用同一局部裁剪",
        font=font,
        fill="black",
    )
    titles = ("有邻树的RGB", "同相机移除邻树RGB", "可见真值 V", "同视角完整真值 A", "隐藏区域 A−V")
    for i, (im, title) in enumerate(zip(panels, titles, strict=True)):
        draw.text((i * 300 + 8, 40), title, font=font, fill="black")
        proof.paste(
            panel(im, (300, 360), "white" if i < 2 else "black", nearest=i >= 2), (i * 300, 70)
        )
    v, a, h = int(visible.sum()), int(amodal.sum()), int(hidden.sum())
    draw.text(
        (10, 440),
        f"标签原分辨率640×360：V={v}px，A={a}px，隐藏={h}px，隐藏比例={h / a:.1%}；灰色=忽略边缘",
        font=small,
        fill="black",
    )
    draw.text(
        (10, 466),
        "完整真值来自已知三维树的对照渲染；范围为同一相机视野内，不包含画面外未知轮廓。",
        font=small,
        fill="black",
    )
    proof.save(args.output / "same-camera-label-proof.jpg", quality=95)

    old_assets = {}
    for role, low, high in (("train", 1, 350), ("validation", 351, 425), ("test", 426, 500)):
        old_assets[role] = {
            tree
            for number in range(low, high + 1)
            for tree in read(OLD / "meta" / f"{number:06d}.json")["trees"]
        }
    shared = {
        f"{left}/{right}": len(old_assets[left] & old_assets[right])
        for left, right in (("train", "validation"), ("train", "test"), ("validation", "test"))
    }
    summary = {
        "selected_examples": selected,
        "legacy_stage12_asset_overlap": shared,
        "paired": {},
        "label_proof": {
            "scene": scene,
            "target": target,
            "roi_xyxy": roi,
            "visible_px": v,
            "amodal_px": a,
            "hidden_px": h,
            "hidden_fraction": h / a,
        },
    }
    for root in (PAIRED, MIXED):
        audit = read(root / "paired-audit.json")
        metas = [read(p) for p in (root / "meta").glob("*.json")]
        camera_heights = [meta["camera_world_matrix"][2][3] for meta in metas]
        summary["paired"][root.name] = {
            **{
                k: audit[k]
                for k in (
                    "scenes",
                    "targets_and_controls",
                    "training_sample_records",
                    "partitions_checked",
                    "planned_dataset_complete",
                )
            },
            "truncated_targets": sum(row["frame_truncated"] for row in audit["records"]),
            "camera_height_min": min(camera_heights),
            "camera_height_max": max(camera_heights),
            "camera_height_below_1m_scenes": sum(z < 1 for z in camera_heights),
        }
    (args.output / "review-summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps({"old_split_shared_assets": shared, "label_proof": summary["label_proof"]}))


if __name__ == "__main__":
    main()
