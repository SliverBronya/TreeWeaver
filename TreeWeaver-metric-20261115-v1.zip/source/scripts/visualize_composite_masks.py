"""Mask-only visualization: GT masks vs model-predicted masks on the composite.

No photo overlays. Each row is one tree:
    GT visible | pred visible | GT amodal | pred amodal | visible errors | amodal errors

White = mask, red = false positive, blue = false negative.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL = 360


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def crop_square(mask, box, height, width, margin=0.2):
    x0, y0, x1, y1 = [int(value) for value in box]
    pad_x = int(margin * (x1 - x0))
    pad_y = int(margin * (y1 - y0))
    left = max(0, x0 - pad_x)
    top = max(0, y0 - pad_y)
    right = min(width, x1 + pad_x)
    bottom = min(height, y1 + pad_y)
    side = max(right - left, bottom - top)
    left = max(0, min(left, width - side))
    top = max(0, min(top, height - side))
    right, bottom = min(width, left + side), min(height, top + side)
    crop = mask[top:bottom, left:right].astype(np.uint8)
    return cv2.resize(crop, (PANEL, PANEL), interpolation=cv2.INTER_NEAREST) > 0


def mask_panel(mask, title, colour=(255, 255, 255)):
    panel = np.zeros((PANEL, PANEL, 3), np.uint8)
    panel[mask] = colour
    cv2.putText(panel, title, (6, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
    return panel


def error_panel(gt, pred, title):
    panel = np.zeros((PANEL, PANEL, 3), np.uint8)
    panel[gt & pred] = (255, 255, 255)
    panel[pred & ~gt] = (0, 0, 255)
    panel[gt & ~pred] = (255, 0, 0)
    cv2.putText(panel, title, (6, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
    return panel


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--composite", type=Path, required=True)
    parser.add_argument("--gt", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    image = cv2.imread(str(args.composite))
    height, width = image.shape[:2]
    gt = np.load(args.gt)
    amodal_gt, visible_gt, boxes, layers = (
        gt["amodal"],
        gt["visible"],
        gt["boxes"],
        gt["layers"],
    )

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    inputs = processor(
        images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), return_tensors="pt"
    )
    scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)

    titles = [
        "GT visible",
        "pred visible",
        "GT amodal",
        "pred amodal",
        "visible errors",
        "amodal errors",
    ]
    rows, headers, report = [], [], []
    for index in range(amodal_gt.shape[0]):
        padded = boxes[index].astype(np.float32)
        deltas = 0.05 * np.array([padded[2] - padded[0], padded[3] - padded[1]] * 2)
        padded = np.array(
            [
                padded[0] - deltas[0],
                padded[1] - deltas[1],
                padded[2] + deltas[0],
                padded[3] + deltas[1],
            ],
            np.float32,
        )
        scaled = torch.as_tensor(padded * scale, device=args.device)[None, None]
        with torch.no_grad():
            output = model(inputs["pixel_values"].to(args.device), input_boxes=scaled)
            pred_visible = processor.post_process_masks(
                output["masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
            pred_amodal = processor.post_process_masks(
                output["amodal_masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0

        box = boxes[index]
        visible_iou = iou(pred_visible, visible_gt[index])
        amodal_iou = iou(pred_amodal, amodal_gt[index])
        rows.append(
            [
                mask_panel(crop_square(visible_gt[index], box, height, width), titles[0]),
                mask_panel(crop_square(pred_visible, box, height, width), titles[1]),
                mask_panel(crop_square(amodal_gt[index], box, height, width), titles[2]),
                mask_panel(crop_square(pred_amodal, box, height, width), titles[3]),
                error_panel(
                    crop_square(visible_gt[index], box, height, width),
                    crop_square(pred_visible, box, height, width),
                    titles[4],
                ),
                error_panel(
                    crop_square(amodal_gt[index], box, height, width),
                    crop_square(pred_amodal, box, height, width),
                    titles[5],
                ),
            ]
        )
        headers.append(
            f"tree {index + 1} (layer {int(layers[index])}): "
            f"visibleIoU={visible_iou:.2f}  amodalIoU={amodal_iou:.2f}"
        )
        report.append(
            {
                "tree": index + 1,
                "layer": int(layers[index]),
                "visible_iou": visible_iou,
                "amodal_iou": amodal_iou,
            }
        )

    gap = 6
    row_height = PANEL + 30
    sheet = np.full((46 + len(rows) * row_height, len(titles) * (PANEL + gap), 3), 30, np.uint8)
    for column, title in enumerate(titles):
        cv2.putText(
            sheet, title, (column * (PANEL + gap) + 8, 26),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (220, 220, 220), 1,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = 46 + row_index * row_height
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1)
        for column, item in enumerate(panels):
            x0 = column * (PANEL + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL, x0 : x0 + PANEL] = item

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(args.output), sheet):
        raise SystemExit(f"cannot write {args.output}")
    (args.output.parent / "masks_only.json").write_text(
        json.dumps(
            {
                "rows": report,
                "legend": "white=correct, red=false positive, blue=false negative",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    print(f"saved {args.output} ({sheet.shape[1]}x{sheet.shape[0]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
