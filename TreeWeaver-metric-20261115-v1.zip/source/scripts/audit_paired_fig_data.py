"""Verify paired RGB/part labels and export grouped training sample references.

This command does not train. Existing v2 data is never edited or re-labelled.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from fig_data_protocol import absolute_crown_profile, sha256_file
from PIL import Image, ImageDraw, ImageFont


def read_mask(path):
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None or image.ndim != 3 or image.shape[-1] != 4:
        raise ValueError(f"missing RGBA target mask: {path}")
    return image[..., 3] > 16


def audit(root):
    if (root / "paired-audit.json").exists():
        raise FileExistsError("paired audit already exists")
    splits = json.loads((root / "splits.json").read_text(encoding="utf-8"))
    pools = splits["asset_pools"]
    if any(
        set(pools[left]) & set(pools[right])
        for left, right in (("train", "validation"), ("train", "test"), ("validation", "test"))
    ):
        raise ValueError("asset leakage")
    records, samples, profiles, file_hashes = [], [], {}, {}
    for meta_path in sorted((root / "meta").glob("*.json")):
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if meta.get("profile") != "paired-parts-v1":
            raise ValueError("not a new paired dataset")
        image_id, split = meta["id"], meta["split"]
        if not set(meta["trees"]) <= set(pools[split]):
            raise ValueError("scene asset outside its frozen split")
        if image_id not in splits["splits"][split]:
            raise ValueError("scene ID outside its frozen split")
        image_path = root / "images" / f"{image_id:06d}.png"
        rgb = cv2.imread(str(image_path))
        if rgb is None or len(meta["counterfactuals"]) != meta["count"]:
            raise ValueError("missing source RGB or controls")
        folder = root / "masks" / f"{image_id:06d}"
        profiles[str(image_id)] = []
        instances = []
        for index, control in enumerate(meta["counterfactuals"], 1):
            if control["target"] != index or control["group_id"] != image_id:
                raise ValueError("counterfactual grouping mismatch")
            control_path = root / control["image"]
            control_rgb = cv2.imread(str(control_path))
            if control_rgb is None or control_rgb.shape != rgb.shape:
                raise ValueError("counterfactual image dimensions mismatch")
            visible = read_mask(folder / f"visible_{index}.png")
            amodal = read_mask(folder / f"amodal_{index}.png")
            if not amodal.any():
                raise ValueError(
                    "empty isolated whole-tree support; check camera/ground/asset geometry"
                )
            if (visible & ~amodal).any():
                raise ValueError("visible support outside amodal")
            hidden = read_mask(folder / f"hidden_{index}.png")
            if not np.array_equal(hidden, amodal & ~visible):
                raise ValueError("hidden support inconsistent")
            raster_unknown = read_mask(folder / f"raster_unknown_{index}.png")
            if ((visible | amodal) & raster_unknown).any():
                raise ValueError("raster uncertainty must be excluded from supervised support")
            if meta["count"] == 1 and hidden.any():
                raise ValueError("single-tree control must have zero known hidden pixels")
            part_counts = {}
            for mode, support in (("visible", visible), ("amodal", amodal)):
                parts = [
                    read_mask(folder / f"{mode}_{part}_{index}.png")
                    for part in ("stem", "crown_surface", "part_unknown")
                ]
                if not np.array_equal(np.stack(parts).sum(0), support.astype(int)):
                    raise ValueError("part masks must partition target support without overlap")
                profiles[str(image_id)].append(
                    {"tree": index, "mode": mode, **absolute_crown_profile(parts[1])}
                )
                part_counts[mode] = dict(
                    zip(
                        ("stem", "crown_surface", "unknown"),
                        [int(part.sum()) for part in parts],
                        strict=True,
                    )
                )
            if control["visible_mask"] != control["amodal_mask"]:
                raise ValueError("zero-occlusion control labels must be identical")
            instance = {
                "source_tree_index": index,
                "asset": meta["trees"][index - 1],
                "visible": f"masks/{image_id:06d}/visible_{index}.png",
                "amodal": f"masks/{image_id:06d}/amodal_{index}.png",
                "visible_stem": f"masks/{image_id:06d}/visible_stem_{index}.png",
                "amodal_stem": f"masks/{image_id:06d}/amodal_stem_{index}.png",
                "visible_crown": f"masks/{image_id:06d}/visible_crown_surface_{index}.png",
                "amodal_crown": f"masks/{image_id:06d}/amodal_crown_surface_{index}.png",
                "raster_unknown": f"masks/{image_id:06d}/raster_unknown_{index}.png",
                "visible_part_unknown": f"masks/{image_id:06d}/visible_part_unknown_{index}.png",
                "amodal_part_unknown": f"masks/{image_id:06d}/amodal_part_unknown_{index}.png",
            }
            instances.append(instance)
            samples.append(
                {
                    "id": f"{image_id:06d}-control-{index}",
                    "group_id": image_id,
                    "split": split,
                    "image": control["image"],
                    "condition": "isolated",
                    "instances": [
                        {
                            **instance,
                            "visible": instance["amodal"],
                            "visible_stem": instance["amodal_stem"],
                            "visible_crown": instance["amodal_crown"],
                            "visible_part_unknown": instance["amodal_part_unknown"],
                        }
                    ],
                }
            )
            records.append(
                {
                    "image_id": image_id,
                    "tree": index,
                    "split": split,
                    "hidden_fraction": float(hidden.sum() / max(amodal.sum(), 1)),
                    "visible_px": int(visible.sum()),
                    "amodal_px": int(amodal.sum()),
                    "raster_unknown_px": int(raster_unknown.sum()),
                    "part_px": part_counts,
                    "frame_truncated": bool(
                        amodal[0].any()
                        or amodal[-1].any()
                        or amodal[:, 0].any()
                        or amodal[:, -1].any()
                    ),
                }
            )
        samples.append(
            {
                "id": f"{image_id:06d}-scene",
                "group_id": image_id,
                "split": split,
                "condition": "scene",
                "image": f"images/{image_id:06d}.png",
                "instances": instances,
            }
        )
    if not records:
        raise ValueError("no completed paired scenes")
    for path in sorted(root.rglob("*")):
        if path.is_file():
            file_hashes[path.relative_to(root).as_posix()] = sha256_file(path)
    result = {
        "profile": "paired-part-label-qualification",
        "scenes": len(profiles),
        "targets_and_controls": len(records),
        "training_sample_records": len(samples),
        "partitions_checked": 2 * len(records),
        "records": records,
        "planned_dataset_complete": splits["complete"],
        "limitations": [
            "simple ground/environment; source families must be checked in asset_manifest.json",
            "stem uses explicitly qualified material only; ambiguous wood is part_unknown",
            "amodal removes external tree occlusion in this camera frame",
            "soft alpha conventions remain explicit; not real-photo truth",
            "old 5h model has already seen all 29 assets",
        ],
        "file_sha256": file_hashes,
    }
    (root / "paired-samples.json").write_text(
        json.dumps(
            {
                "schema_version": "treeweaver-paired-1.0",
                "root": str(root.resolve()),
                "records": samples,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    (root / "crown-profiles.json").write_text(json.dumps(profiles, indent=2), encoding="utf-8")
    (root / "paired-audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    render_sheet(root, records)
    return result


def render_sheet(root, records):
    # The largest actual hidden fraction in each split, declared selection rule.
    selected = [
        max(
            [row for row in records if row["split"] == split],
            key=lambda row: row["hidden_fraction"],
        )
        for split in ("train", "validation", "test")
        if any(row["split"] == split for row in records)
    ]
    first_rgb = cv2.imread(str(root / "images" / f"{selected[0]['image_id']:06d}.png"))
    if first_rgb.shape[0] > first_rgb.shape[1]:
        width = 240
        height = round(width * first_rgb.shape[0] / first_rgb.shape[1])
    else:
        width = 384
        height = round(width * first_rgb.shape[0] / first_rgb.shape[1])
    sheet = Image.new("RGB", (width * 5, len(selected) * (height + 60) + 40), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 16)
    draw.text(
        (8, 7),
        "新合成样例：同树同相机的遮挡/无遮挡对照；部件来自源模型材质",
        fill="black",
        font=font,
    )
    for row_index, row in enumerate(selected):
        image_id, tree = row["image_id"], row["tree"]
        rgb = cv2.cvtColor(
            cv2.imread(str(root / "images" / f"{image_id:06d}.png")), cv2.COLOR_BGR2RGB
        )
        isolated = cv2.cvtColor(
            cv2.imread(
                str(root / "counterfactuals" / f"{image_id:06d}" / f"target_{tree}_rgb.png")
            ),
            cv2.COLOR_BGR2RGB,
        )
        folder = root / "masks" / f"{image_id:06d}"
        visible, full = (
            read_mask(folder / f"visible_{tree}.png"),
            read_mask(folder / f"amodal_{tree}.png"),
        )
        stem = read_mask(folder / f"amodal_stem_{tree}.png")
        crown = read_mask(folder / f"amodal_crown_surface_{tree}.png")
        unknown_part = read_mask(folder / f"amodal_part_unknown_{tree}.png")
        panels = [rgb, isolated]
        for mask in (visible, full):
            panel = rgb.copy()
            keep = (
                cv2.resize(
                    mask.astype(np.uint8),
                    (rgb.shape[1], rgb.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                )
                > 0
            )
            panel[keep] = (0.4 * panel[keep] + 0.6 * np.array([20, 180, 240])).astype(np.uint8)
            panels.append(panel)
        panel = np.zeros_like(rgb)
        for mask, color in (
            (stem, (240, 130, 30)),
            (crown, (40, 200, 100)),
            (unknown_part, (150, 150, 150)),
        ):
            keep = (
                cv2.resize(
                    mask.astype(np.uint8),
                    (rgb.shape[1], rgb.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                )
                > 0
            )
            panel[keep] = color
        panels.append(panel)
        y = 40 + row_index * (height + 60)
        for col, (panel, title) in enumerate(
            zip(
                panels,
                ("场景RGB", "只移除邻树的RGB", "目标可见真值", "目标完整真值", "树干/树冠表面真值"),
                strict=True,
            )
        ):
            draw.text((col * width + 5, y), title, fill="black", font=font)
            sheet.paste(Image.fromarray(cv2.resize(panel, (width, height))), (col * width, y + 25))
        draw.text(
            (6, y + height + 30),
            f"{row['split']} / 场景{image_id} 目标{tree} / "
            f"实际隐藏面积 {row['hidden_fraction']:.1%} / 橙=树干，绿=冠表面，灰=部件未知",
            fill="black",
            font=font,
        )
    sheet.save(root / "paired-preview.jpg", quality=94)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.root)
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "scenes",
                    "targets_and_controls",
                    "partitions_checked",
                    "planned_dataset_complete",
                )
            }
        )
    )


if __name__ == "__main__":
    main()
