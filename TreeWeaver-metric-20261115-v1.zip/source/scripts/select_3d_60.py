"""Select 60 eligible 3D scenes and freeze a pilot split."""

from __future__ import annotations

import json
import shutil
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver\reports\focused-3d-candidates-2026-11-10")
OUT = Path(r"D:\TreeWeaver\reports\focused-3d-60-2026-11-10")


def main():
    rows = []
    for scene in sorted(path for path in ROOT.iterdir() if path.is_dir()):
        meta = json.loads((scene / "meta.json").read_text(encoding="utf-8"))
        stem = np.asarray(Image.open(scene / "stem_1.png").convert("RGBA"))[..., 3] > 16
        meta["stem_px"] = int(stem.sum())
        meta["source_scene"] = scene.name
        rows.append(meta)
    eligible = [
        row
        for row in rows
        if 0.85 <= row["target_height_fraction"] <= 0.95
        and 0.05 <= row["overlap_target_neighbour"] <= 0.30
        and row["stem_px"] > 0
    ]
    two = [row for row in eligible if row["count"] == 2][:20]
    three = [row for row in eligible if row["count"] == 3][:40]
    selected = two + three
    assets = sorted({row["trees"][0] for row in selected})
    train_assets = set(assets[: max(1, round(len(assets) * 0.7))])
    remaining = [asset for asset in assets if asset not in train_assets]
    val_assets = set(remaining[: max(1, len(remaining) // 2)])
    test_assets = set(remaining) - val_assets
    for row in selected:
        row["split"] = "train" if row["trees"][0] in train_assets else ("validation" if row["trees"][0] in val_assets else "test")
    # Ensure all splits exist.
    if not any(row["split"] == "validation" for row in selected):
        selected[0]["split"] = "validation"
    if not any(row["split"] == "test" for row in selected):
        selected[1]["split"] = "test"
    OUT.mkdir(exist_ok=True)
    for row in selected:
        source = ROOT / row["source_scene"]
        target = OUT / row["source_scene"]
        if not target.exists():
            shutil.copytree(source, target)
    (OUT / "index.json").write_text(json.dumps(selected, indent=2), encoding="utf-8")
    summary = {
        "targets": len(selected),
        "splits": dict(Counter(row["split"] for row in selected)),
        "tree_counts": dict(Counter(row["count"] for row in selected)),
        "height_mean": float(np.mean([row["target_height_fraction"] for row in selected])),
        "height_min": min(row["target_height_fraction"] for row in selected),
        "height_max": max(row["target_height_fraction"] for row in selected),
        "overlap_mean": float(np.mean([row["overlap_target_neighbour"] for row in selected])),
        "overlap_min": min(row["overlap_target_neighbour"] for row in selected),
        "overlap_max": max(row["overlap_target_neighbour"] for row in selected),
        "stem_all_nonempty": all(row["stem_px"] > 0 for row in selected),
        "target_assets": len(assets),
        "split_assets": {"train": len(train_assets), "validation": len(val_assets), "test": len(test_assets)},
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
