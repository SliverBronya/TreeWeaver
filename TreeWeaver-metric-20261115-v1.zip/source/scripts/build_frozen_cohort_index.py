"""Resolve frozen 60-target cohort into a file-level index (CPU only)."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver")
FROZEN = ROOT / "reports/data-qualification-2026-11-09/frozen/splits.json"
ROOTS = {
    "v6": ROOT / "reports/fig-paired-v6-framing-30-2026-11-08",
    "mixed": ROOT / "reports/mixed-identity-layout-qualification-2026-11-08",
    "supplement": ROOT / "reports/qualification-supplement-v2-2026-11-09",
    "hidden-heavy": ROOT / "reports/hidden-heavy-supplement-2026-11-09",
    "hidden-heavy-v2": ROOT / "reports/hidden-heavy-v2-2026-11-09",
    "hidden-heavy-v3": ROOT / "reports/hidden-heavy-v3-2026-11-09",
}


def mask(path: Path) -> np.ndarray:
    image = np.asarray(Image.open(path).convert("RGBA"))
    return image[..., 3] > 16


def resolve(row):
    root = ROOTS[row["root"]]
    scene = root / row["scene"].replace("-scene", "")
    if row["root"] in {"v6", "mixed"}:
        manifest = json.loads((root / "paired-samples.json").read_text(encoding="utf-8"))
        samples = [r for r in manifest["records"] if r["id"] == row["scene"]]
        if not samples:
            raise FileNotFoundError(row["scene"])
        sample = samples[0]
        index = int(row.get("tree_index", 1)) - 1
        instance = sample["instances"][index]
        return {
            "image": root / sample["image"],
            "visible": root / instance["visible"],
            "amodal": root / instance["amodal"],
            "stem": root / instance["visible_stem"],
            "crown": root / instance["visible_crown"],
            "unknown": root / instance["visible_part_unknown"],
        }
    if row["root"] == "hidden-heavy-v3" or row["root"] == "hidden-heavy-v2" or row["root"] == "hidden-heavy":
        return {
            "image": scene / "full.png",
            "visible": scene / "visible_target.png",
            "amodal": scene / "amodal_target.png",
            "stem": scene / "stem_target.png",
            "crown": None,
            "unknown": None,
        }
    return {
        "image": scene / "full.png",
        "visible": scene / "visible_target.png",
        "amodal": scene / "amodal_target.png",
        "stem": scene / "stem_target.png",
        "crown": None,
        "unknown": None,
    }


def build(rows, split):
    records = []
    for row in rows:
        paths = resolve(row)
        visible = mask(paths["visible"])
        amodal = mask(paths["amodal"])
        assert visible.shape == amodal.shape
        assert not (visible & ~amodal).any(), row
        stem = mask(paths["stem"]) if paths["stem"] and paths["stem"].exists() else np.zeros_like(visible)
        crown = mask(paths["crown"]) if paths["crown"] and paths["crown"].exists() else (visible & ~stem)
        unknown = mask(paths["unknown"]) if paths["unknown"] and paths["unknown"].exists() else np.zeros_like(visible)
        ys, xs = np.where(visible if visible.any() else amodal)
        box = [int(xs.min()), int(ys.min()), int(xs.max() + 1), int(ys.max() + 1)] if len(xs) else [0, 0, 1, 1]
        records.append(
            {
                **row,
                "paths": {key: str(value) if value else None for key, value in paths.items()},
                "box_xyxy": box,
                "mask_wh": [int(visible.shape[1]), int(visible.shape[0])],
                "visible_pixels": int(visible.sum()),
                "amodal_pixels": int(amodal.sum()),
                "stem_pixels": int(stem.sum()),
                "crown_pixels": int(crown.sum()),
                "unknown_pixels": int(unknown.sum()),
            }
        )
    return {"split": split, "records": records}


def main():
    split = json.loads(FROZEN.read_text(encoding="utf-8"))
    result = {
        "schema_version": "treeweaver-frozen-index-1.0",
        "train": build(split["train"], "train"),
        "validation": build(split["validation"], "validation"),
        "test": {
            "split": "test",
            "records": [],
            "note": "test paths intentionally not resolved; no test image or label read",
            "count": len(split["test"]),
        },
        "test_images_read": False,
    }
    out = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "train": len(result["train"]["records"]),
                "validation": len(result["validation"]["records"]),
                "test": len(result["test"]["records"]),
                "train_visible_pixels": sum(r["visible_pixels"] for r in result["train"]["records"]),
                "train_stem_pixels": sum(r["stem_pixels"] for r in result["train"]["records"]),
                "out": str(out),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
