"""Old vs improved current-model masks for the worst 20260411 cases."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

OLD = Path(r"D:\TreeWeaver\reports\real-20260411-full-2026-11-01")
NEW = Path(r"D:\TreeWeaver\reports\real-20260411-improve-2026-11-01")
OUT = Path(r"D:\TreeWeaver\reports\real-20260411-improvement-sheet-2026-11-01")
IDS = ["22003", "56003", "59003", "2002", "57003", "56001"]


def font(size=18):
    try:
        return ImageFont.truetype("C:/Windows/Fonts/arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


def crop_current(path):
    image = Image.open(path).convert("RGB")
    w, h = image.size
    return image.crop((0, h // 2 + 48, w // 2, h))


def metric(root, image_id):
    rows = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    for row in rows:
        if row.get("image") == f"{image_id}.jpg":
            return row["iou"], row["area_ratio"], row.get("stock_area", 0), row.get("ours_area", 0)
    return 0, 0, 0, 0


def main():
    OUT.mkdir(exist_ok=True)
    cells = []
    for image_id in IDS:
        old = crop_current(OLD / f"{image_id}.png")
        new = crop_current(NEW / f"{image_id}.png")
        size = (560, 315)
        old = old.resize(size)
        new = new.resize(size)
        oi, oa, _, _ = metric(OLD, image_id)
        ni, na, _, _ = metric(NEW, image_id)
        canvas = Image.new("RGB", (size[0] * 2, size[1] + 34), "white")
        canvas.paste(old, (0, 34))
        canvas.paste(new, (size[0], 34))
        draw = ImageDraw.Draw(canvas)
        draw.text((6, 6), f"{image_id}.jpg", fill="black", font=font())
        draw.text((8, 34 + 4), f"old  IoU {oi:.3f}  area {oa:.2f}", fill="white", font=font(15), stroke_width=2, stroke_fill="black")
        draw.text((size[0] + 8, 34 + 4), f"new  IoU {ni:.3f}  area {na:.2f}", fill="white", font=font(15), stroke_width=2, stroke_fill="black")
        cells.append(canvas)
    width = cells[0].width
    height = cells[0].height
    sheet = Image.new("RGB", (width, height * len(cells)), "white")
    for index, cell in enumerate(cells):
        sheet.paste(cell, (0, index * height))
    sheet.save(OUT / "old_vs_new_worst.jpg", quality=92)
    print(OUT / "old_vs_new_worst.jpg")


if __name__ == "__main__":
    main()
