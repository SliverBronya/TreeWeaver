"""Fine-tune the stock SAM2 mask decoder on real trunks, with or without a stem point.

Step 2 of the adhesion ladder. Step 1 (reports/canatree-adhesion-probe-2026-11-03)
showed that a base-of-trunk positive point helps a frozen decoder, while three
neighbour negative points hurt. This script asks the training question: does the
same point prompt help *after* fine-tuning on real trunk masks, and does
fine-tuning close the gap between the drifted synthetic decoder and stock SAM2?

Deliberately minimal: stock SAM2.1 tiny, only ``mask_decoder`` trainable, BCE+Dice
on trunk masks, checkpoint chosen on fold_00 validation IoU only.

Two prompt modes keep the comparison single-factor:

* ``box`` - the current training prompt;
* ``pos`` - box plus one positive point at the base of the target trunk.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from probe_canatree_adhesion import (  # noqa: E402
    BASE,
    REVISION,
    base_point,
    decode_image,
    load_fold,
)
from probe_crop_refine import run_strip, strip_bounds  # noqa: E402
from research_protocol import (  # noqa: E402
    assert_training_allowed,
    hash_files,
    pinned_snapshot,
    sha256_file,
)
from stem_eval_common import mask_row, mean_of, paired, write_json  # noqa: E402

SEED = 20261103


def prepare(by_image, grouped, processor, device):
    """Decode each frame once; either prompt mode only changes the tensors."""
    prepared = []
    for image_id, image in by_image.items():
        image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
        pixels = processor(
            images=Image.fromarray(np.asarray(image_bgr)[:, :, ::-1].copy()), return_tensors="pt"
        )["pixel_values"].to(device)
        prepared.append(
            {
                "name": image["file_name"],
                "image_bgr": image_bgr,
                "boxes": boxes,
                "masks": masks,
                "height": height,
                "width": width,
                "pixels": pixels,
                "points": np.stack(
                    [
                        np.asarray(base_point(masks[index], boxes[index]), np.float32)
                        for index in range(len(boxes))
                    ]
                ),
            }
        )
    return prepared


def prompts(frame, mode):
    height, width = frame["height"], frame["width"]
    box_scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
    point_scale = np.asarray([1024 / width, 1024 / height], np.float32)
    boxes = (frame["boxes"] * box_scale).astype(np.float32)
    count = len(boxes)
    points = np.zeros((count, 1, 2), np.float32)
    labels = np.full((count, 1), -1, np.int64)
    if mode == "pos":
        points[:, 0, :] = frame["points"] * point_scale
        labels[:, 0] = 1
    return boxes, points, labels


def forward_logits(model, frame, mode):
    """Raw mask logits (1,K,256,256); keeps the graph when training."""
    device = frame["pixels"].device
    boxes, points, labels = prompts(frame, mode)
    arguments = {
        "pixel_values": frame["pixels"],
        "input_boxes": torch.as_tensor(boxes, device=device)[None],
        "multimask_output": False,
    }
    if mode == "pos":
        arguments["input_points"] = torch.as_tensor(points, device=device)[None]
        arguments["input_labels"] = torch.as_tensor(labels, device=device)[None]
    return model(**arguments).pred_masks[:, :, 0]


def strip_sample(processor, frame, index, mode, x_margin, y_margin):
    """One trunk as a strip crop: pixels, box, point and GT mask in crop space."""
    image_bgr = frame["image_bgr"]
    height, width = image_bgr.shape[:2]
    box = frame["boxes"][index]
    left, top, right, bottom = strip_bounds(box, height, width, x_margin, y_margin)
    crop = image_bgr[top:bottom, left:right]
    crop_height, crop_width = crop.shape[:2]
    pixels = processor(
        images=Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)), return_tensors="pt"
    )["pixel_values"]
    box_scale = np.asarray([1024 / crop_width, 1024 / crop_height] * 2, np.float32)
    local_box = (box - np.asarray([left, top, left, top], np.float32)) * box_scale
    point = (frame["points"][index] - np.asarray([left, top], np.float32)) * np.asarray(
        [1024 / crop_width, 1024 / crop_height], np.float32
    )
    target = frame["masks"][index][top:bottom, left:right]
    return {
        "pixels": pixels,
        "box": local_box,
        "point": point,
        "target": target,
    }


def forward_masks(model, frame, mode):
    with torch.inference_mode():
        logits = forward_logits(model, frame, mode)[0]
    upscaled = F.interpolate(
        logits[:, None], (frame["height"], frame["width"]), mode="bilinear", align_corners=False
    )[:, 0]
    return (upscaled > 0).cpu().numpy()


def evaluate(model, prepared, mode, window="full", processor=None, x_margin=5.0, y_margin=0.05):
    rows = []
    for frame in prepared:
        if window == "full":
            predicted = forward_masks(model, frame, mode)
        else:
            predicted = np.stack(
                [
                    run_strip(
                        model,
                        processor,
                        frame["image_bgr"],
                        frame["boxes"][index],
                        frame["points"][index] if mode == "pos" else None,
                        frame["pixels"].device,
                        x_margin,
                        y_margin,
                    )
                    for index in range(len(frame["masks"]))
                ]
            )
        masks = frame["masks"]
        for index in range(len(masks)):
            others = [masks[other] for other in range(len(masks)) if other != index]
            rows.append(
                {
                    "image": frame["name"],
                    "tree_index": index,
                    "role": frame["role"],
                    "metrics": mask_row(
                        f"{frame['name']}:{index}", predicted[index], masks[index], others=others
                    ),
                }
            )
    return rows


def block(rows):
    metrics = [row["metrics"] for row in rows]
    return {
        "trees": len(rows),
        "mean_iou": mean_of(metrics, "iou"),
        "mean_boundary_f1": mean_of(metrics, "boundary_f1"),
        "mean_recall": mean_of(metrics, "recall"),
        "mean_precision": mean_of(metrics, "precision"),
        "mean_neighbour_fraction": mean_of(metrics, "neighbour_fraction"),
    }


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2)) + target.sum(dim=(1, 2)) + 1.0
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prompts", choices=("box", "pos"), required=True)
    parser.add_argument("--window", choices=("full", "strip"), default="full")
    parser.add_argument("--x-margin", type=float, default=5.0)
    parser.add_argument("--y-margin", type=float, default=0.05)
    parser.add_argument("--seed", type=int, default=20261103)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--allow-unverified-video-split", action="store_true")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if not args.allow_unverified_video_split:
        parser.error("fold_00 has no provable video isolation; pass --allow-unverified-video-split")
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    train_images, train_groups, _ = load_fold("train")
    val_images, val_groups, _ = load_fold("val")
    test_images, test_groups, _ = load_fold("test")
    scope = assert_training_allowed(BASE)

    image_files = []
    for split in ("train", "val", "test"):
        document = load_fold(split)[0]
        image_files.extend(BASE / "images" / image["file_name"] for image in document.values())
    protocol = {
        "schema_version": "treeweaver-visible-training-1.0",
        "profile": "dataset_supplied_visible_trunk",
        "role": "development",
        "ladder_step": 4 if args.window == "strip" else 2,
        "question": (
            "does training inside the high-resolution strip window help where "
            "full-frame fine-tuning overfit?"
            if args.window == "strip"
            else (
                "does a base-of-trunk positive point help after fine-tuning, and does "
                "fine-tuning close the synthetic-to-real gap?"
            )
        ),
        "window": {"mode": args.window, "x_margin": args.x_margin, "y_margin": args.y_margin},
        "policy_scope": scope,
        "prompt_mode": args.prompts,
        "prompt": (
            "GT-derived trunk box; positive point at the centre of the lowest 10% of the "
            "target trunk mask"
            if args.prompts == "pos"
            else "GT-derived trunk box only"
        ),
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "trainable": ["mask_decoder"],
            "frozen": "image encoder, prompt encoder, memory attention",
            "initialisation": "stock SAM2.1 tiny; no synthetic fine-tuned weights",
        },
        "optimizer": {
            "name": "AdamW",
            "lr": args.lr,
            "weight_decay": args.weight_decay,
            "steps": args.steps,
            "batch": "one frame with all its labelled trunks",
            "seed": args.seed,
        },
        "loss": "BCE + Dice on trunk masks at 256x256",
        "selection": "fold_00 validation mean IoU only",
        "data_sha256": {
            "images": hash_files(image_files, base=BASE),
            "fold_files": {
                str(load_fold(split)[2].relative_to(BASE)): sha256_file(load_fold(split)[2])
                for split in ("train", "val", "test")
            },
        },
        "split": {
            "origin": "official CanaTree100 fold_00",
            "train_val_test_disjoint": True,
            "video_disjoint": False,
            "acknowledged_by_flag": args.allow_unverified_video_split,
        },
        "limitations": [
            "no neighbour negative points: step 1 showed they hurt zero-shot",
            "trunk annotations are non-exhaustive, so unlabelled background trunks count as "
            "false positives during training and as neighbours nowhere in evaluation",
            "fold_00 images reappear in other folds' train files; development-only",
            "one seed, one 300-step budget: a signal, not a converged result",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device)
    for parameter in sam2.parameters():
        parameter.requires_grad = False
    for parameter in sam2.mask_decoder.parameters():
        parameter.requires_grad = True

    prepared = {
        "train": prepare(train_images, train_groups, processor, args.device),
        "val": prepare(val_images, val_groups, processor, args.device),
        "test": prepare(test_images, test_groups, processor, args.device),
    }
    for split in prepared:
        for frame in prepared[split]:
            frame["role"] = split

    # Stock baseline first, with the same prompts, so every later number has a reference.
    sam2.eval()
    stock_rows = {
        split: evaluate(
            sam2,
            prepared[split],
            args.prompts,
            args.window,
            processor,
            args.x_margin,
            args.y_margin,
        )
        for split in ("val", "test")
    }
    for split, rows in stock_rows.items():
        print(json.dumps({"model": "stock_sam2", "split": split, **block(rows)}), flush=True)

    optimizer = torch.optim.AdamW(
        [p for p in sam2.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    history = []
    best = {"score": -1.0, "step": 0}
    for step in range(1, args.steps + 1):
        sam2.train()
        sam2.vision_encoder.eval()
        frame = random.choice(prepared["train"])
        if args.window == "strip":
            index = random.randrange(len(frame["boxes"]))
            sample = strip_sample(
                processor, frame, index, args.prompts, args.x_margin, args.y_margin
            )
            pixels = sample["pixels"].to(args.device)
            arguments = {
                "pixel_values": pixels,
                "input_boxes": torch.as_tensor(sample["box"], device=args.device)[None, None],
                "multimask_output": False,
            }
            if args.prompts == "pos":
                arguments["input_points"] = torch.as_tensor(
                    sample["point"], device=args.device
                )[None, None, None]
                arguments["input_labels"] = torch.as_tensor([[[1]]], device=args.device)
            logits = sam2(**arguments).pred_masks[0, 0, 0]
            ground_truth = F.interpolate(
                torch.as_tensor(sample["target"], device=args.device)[None, None].float(),
                logits.shape[-2:],
                mode="nearest",
            )[0, 0]
        else:
            logits = forward_logits(sam2, frame, args.prompts)[0]
            ground_truth = F.interpolate(
                torch.as_tensor(frame["masks"], device=args.device)[:, None].float(),
                (logits.shape[-2], logits.shape[-1]),
                mode="nearest",
            )[:, 0]
        loss = F.binary_cross_entropy_with_logits(logits, ground_truth) + dice_loss(
            logits[None] if logits.ndim == 2 else logits,
            ground_truth[None] if ground_truth.ndim == 2 else ground_truth,
        ).mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_([p for p in sam2.parameters() if p.requires_grad], 1.0)
        optimizer.step()
        if step % 20 == 0:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % args.eval_every == 0 or step == args.steps:
            sam2.eval()
            rows = evaluate(
                sam2,
                prepared["val"],
                args.prompts,
                args.window,
                processor,
                args.x_margin,
                args.y_margin,
            )
            scored = block(rows)
            row = {"step": step, "val_iou": scored["mean_iou"], "loss": float(loss.detach())}
            history.append(row)
            print("EVAL", json.dumps(row), flush=True)
            if row["val_iou"] > best["score"]:
                best = {"score": row["val_iou"], "step": step}
                torch.save(
                    {"decoder": sam2.mask_decoder.state_dict(), "step": step, **row},
                    args.output / "best.pth",
                )
                write_json(args.output / "history.json", history)

    payload = torch.load(args.output / "best.pth", map_location=args.device, weights_only=True)
    sam2.mask_decoder.load_state_dict(payload["decoder"])
    sam2.eval()
    per_tree = []
    summary = {
        "schema_version": protocol["schema_version"],
        "ladder_step": 2,
        "prompt_mode": args.prompts,
        "selected_step": payload["step"],
        "splits": {},
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "clean_holdout": False,
    }
    for split in ("val", "test"):
        tuned_rows = evaluate(
            sam2,
            prepared[split],
            args.prompts,
            args.window,
            processor,
            args.x_margin,
            args.y_margin,
        )
        combined = []
        stock_by_id = {f"{row['image']}:{row['tree_index']}": row for row in stock_rows[split]}
        for row in tuned_rows:
            key = f"{row['image']}:{row['tree_index']}"
            combined.append(
                {"image": row["image"], "tree_index": row["tree_index"],
                 "role": split, "finetuned": row["metrics"],
                 "stock_sam2": stock_by_id[key]["metrics"]}
            )
        per_tree.extend(combined)
        summary["splits"][split] = {
            "stock_sam2": block(stock_rows[split]),
            "finetuned": block(tuned_rows),
            "paired": paired(combined, left="stock_sam2", right="finetuned"),
        }
    write_json(args.output / "per_tree.json", per_tree)
    write_json(args.output / "summary.json", summary)
    write_json(args.output / "history.json", history)
    print("DONE", json.dumps(summary["splits"]))


if __name__ == "__main__":
    main()
