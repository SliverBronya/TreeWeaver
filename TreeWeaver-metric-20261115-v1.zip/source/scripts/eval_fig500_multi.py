"""Evaluate the multi-object fig500 checkpoint and save overlays."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))


def snapshot(repo: str, revision: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    path = base / "snapshots" / revision
    if not path.is_dir():
        raise FileNotFoundError(f"explicit cached revision is required: {path}")
    return path


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-root", type=Path, default=ROOT / "reports" / "fig-500-v2-2026-10-31"
    )
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--samples", type=int, default=4)
    parser.add_argument("--hard-only", action="store_true")
    parser.add_argument("--all", action="store_true")
    parser.add_argument(
        "--split", choices=("train", "validation", "test", "all"), default="validation"
    )
    parser.add_argument("--split-manifest", type=Path)
    parser.add_argument("--sam-revision", default="de431c4043854a71d8101e17995dfe596bf101a5")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.limit < 1 or args.samples < 0:
        parser.error("limit must be positive and samples nonnegative")
    if args.output.exists():
        raise FileExistsError("use a new evaluation directory; historical results are immutable")
    args.output.mkdir(parents=True)

    from fig500_dataset import Fig500Multi
    from instance_metrics import instance_report
    from sam2_occlusion import Sam2OcclusionModel

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny", args.sam_revision)
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    dataset = Fig500Multi(
        args.data_root,
        "all" if args.all else args.split,
        mean=mean,
        std=std,
        split_manifest=args.split_manifest,
    )
    if args.hard_only:
        keep = []
        for record in dataset.items:
            meta = json.loads(
                (args.data_root / "meta" / f"{int(record['id']):06d}.json").read_text(
                    encoding="utf-8"
                )
            )
            masks = [
                dataset._mask(
                    args.data_root / "masks" / f"{int(record['id']):06d}", "amodal", i + 1
                )
                for i in range(len(meta["trees"]))
            ]
            # Old metadata only lists adjacent indices. Recompute all object pairs.
            ratios = [
                float((masks[i] & masks[j]).sum())
                / max(min(int(masks[i].sum()), int(masks[j].sum())), 1)
                for i in range(len(masks))
                for j in range(i + 1, len(masks))
            ]
            if ratios and 0.02 <= min(ratios) <= 0.30:
                keep.append(record)
        dataset.items = keep
        print("hard-only images", len(dataset.items))
    if not dataset.items:
        raise ValueError("No images matched the requested evaluation subset")
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    visible_all, amodal_all, own_all, own_fg, own_bg, layer_all, visibility_all = (
        [],
        [],
        [],
        [],
        [],
        [],
        [],
    )
    per_image, overlap_ownership = [], []
    coordinate_correct = coordinate_total = intersecting_correct = intersecting_total = 0
    for index in range(min(args.limit, len(dataset))):
        sample = dataset.sample(index)
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(args.device)
        boxes = torch.as_tensor(sample["boxes"])[None].to(args.device)
        with torch.no_grad():
            output = model(pixel_values, input_boxes=boxes)
        count = int(sample["num_objects"])
        pred_visible = (output["masks"][0, :, 0] > 0).cpu().numpy()
        pred_amodal = (output["amodal_masks"][0, :, 0] > 0).cpu().numpy()
        gt_visible = sample["visible"] > 0.5
        gt_amodal = sample["amodal"] > 0.5
        for i in range(count):
            visible_all.append(iou(pred_visible[i], gt_visible[i]))
            amodal_all.append(iou(pred_amodal[i], gt_amodal[i]))
        ownership_pred = output["ownership_logits"][0].argmax(0).cpu().numpy()
        ownership_gt = np.asarray(sample["ownership"])
        correct = ownership_pred == ownership_gt
        own_all.append(float(correct.mean()))
        foreground = ownership_gt > 0
        if foreground.any():
            own_fg.append(float(correct[foreground].mean()))
        if (~foreground).any():
            own_bg.append(float(correct[~foreground].mean()))
        overlap = gt_amodal.sum(axis=0) > 1
        overlap_foreground = overlap & foreground
        if overlap_foreground.any():
            overlap_ownership.append(float(correct[overlap_foreground].mean()))
        layer_pred = output["layer_logits"][0].cpu().numpy()
        layer_gt = sample["layer"]
        correct = 0
        total = 0
        for i in range(count):
            for j in range(i + 1, count):
                if layer_gt[i, j] != 0:
                    total += 1
                    correct += int((layer_pred[i, j] > 0) == (layer_gt[i, j] > 0))
                    left_i = (sample["boxes"][i, 0] + sample["boxes"][i, 2]) < (
                        sample["boxes"][j, 0] + sample["boxes"][j, 2]
                    )
                    coordinate_correct += int(left_i == (layer_gt[i, j] > 0))
                    coordinate_total += 1
                    if (gt_amodal[i] & gt_amodal[j]).any():
                        intersecting_total += 1
                        intersecting_correct += int((layer_pred[i, j] > 0) == (layer_gt[i, j] > 0))
        if total:
            layer_all.append(correct / total)
        visibility_error = np.abs(output["visibility"][0].cpu().numpy() - sample["visibility"])
        visibility_all.append(float(visibility_error[sample["visibility_valid"]].mean()))
        constrained = np.stack([pred_visible[i] & (ownership_pred == i + 1) for i in range(count)])
        per_image.append(
            {
                "image_id": sample["image_id"],
                "layer_semantics": sample["layer_semantics"],
                "raw": instance_report(pred_visible, gt_visible),
                "ownership_constrained": instance_report(constrained, gt_visible),
                "raw_conflict_pixels": int((pred_visible.sum(axis=0) > 1).sum()),
            }
        )

        if index < args.samples:
            image = cv2.imread(str(args.data_root / "images" / f"{sample['image_id']:06d}.png"))
            h, w = image.shape[:2]
            panel = image.copy()
            colors = [(60, 130, 255), (255, 150, 40), (80, 210, 100), (220, 80, 160)]
            for i in range(count):
                mask = cv2.resize(
                    pred_visible[i].astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST
                )
                panel[mask > 0] = (
                    0.55 * panel[mask > 0] + 0.45 * np.array(colors[i], np.float32)
                ).astype(np.uint8)
                x0, y0, x1, y1 = sample["boxes"][i]
                x0, x1 = int(x0 * w / 1024), int(x1 * w / 1024)
                y0, y1 = int(y0 * h / 1024), int(y1 * h / 1024)
                cv2.rectangle(panel, (x0, y0), (x1, y1), colors[i], 2)
            cv2.imwrite(str(args.output / f"pred_{sample['image_id']:06d}.png"), panel)

    metrics = {
        "images": min(args.limit, len(dataset)),
        "visible_iou": float(np.mean(visible_all)),
        "amodal_iou": float(np.mean(amodal_all)),
        "ownership_accuracy": float(np.mean(own_all)),
        "ownership_foreground_accuracy": float(np.mean(own_fg)),
        "ownership_background_accuracy": float(np.mean(own_bg)),
        "layer_accuracy": float(np.mean(layer_all)) if layer_all else None,
        "layer_metric_name": "object_origin_rank_accuracy_not_physical_pixel_occlusion_accuracy",
        "layer_metric_note": sorted({row["layer_semantics"] for row in per_image}),
        "tree_visibility_mae": float(np.mean(visibility_all)) if visibility_all else None,
        "visibility_metric_note": "tree channel only; stem channel has no independent labels",
        "ownership_overlap_foreground_accuracy": float(np.mean(overlap_ownership))
        if overlap_ownership
        else None,
        "layer_intersecting_pair_accuracy": intersecting_correct / intersecting_total
        if intersecting_total
        else None,
        "layer_intersecting_pair_count": intersecting_total,
        "left_to_right_coordinate_baseline_accuracy": coordinate_correct / coordinate_total
        if coordinate_total
        else None,
        "split_origin": dataset.split_origin,
        "split_independence_verified": dataset.split_independence_verified,
        "split_verification_scope": (
            "disjoint asset pools within this dataset; not a checkpoint unseen-asset claim"
        ),
        "split": "all" if args.all else args.split,
        "prompt_source": "ground_truth_visible_mask_boxes; not automatic detection",
        "metric_contract": "v2-valid-visibility-all-pairs-instance-diagnostics",
        "sam_revision": args.sam_revision,
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "checkpoint": str(args.checkpoint),
    }
    (args.output / "per_image.json").write_text(json.dumps(per_image, indent=2), encoding="utf-8")
    (args.output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
