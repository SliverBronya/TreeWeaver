"""For every image: detect ALL objects, segment ALL of them, one overlay JPG each.

Unlike experiment.py (which picks a single central tree), this keeps every box the
detector returns and segments each of them, so the overlay shows all objects.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np

DETECTOR_MODEL = "IDEA-Research/grounding-dino-tiny"
DETECTOR_REVISION = "a2bb814dd30d776dcf7e30523b00659f4f141c71"
SEGMENTER_MODEL = "facebook/sam2.1-hiera-tiny"
SEGMENTER_REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"

PALETTE = [
    (60, 220, 60), (60, 120, 255), (255, 160, 40), (200, 60, 255),
    (40, 220, 220), (255, 220, 40), (255, 80, 140), (140, 255, 200),
    (200, 200, 80), (120, 140, 255), (255, 120, 80), (80, 255, 160),
]


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    p.add_argument("--image-directory", required=True)
    p.add_argument("--output-directory", required=True)
    p.add_argument("--prompt", default="tree.")
    p.add_argument("--box-threshold", type=float, default=0.18)
    p.add_argument("--text-threshold", type=float, default=0.18)
    p.add_argument("--min-mask-pixels", type=int, default=200)
    p.add_argument("--dedupe-iou", type=float, default=0.90)
    return p


def main() -> int:
    args = parser().parse_args()
    import torch
    from PIL import Image
    from transformers import (
        AutoModelForZeroShotObjectDetection,
        AutoProcessor,
        Sam2Model,
        Sam2Processor,
    )

    src = Path(args.image_directory).resolve()
    out = Path(args.output_directory).resolve()
    out.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    det_proc = AutoProcessor.from_pretrained(DETECTOR_MODEL, revision=DETECTOR_REVISION, use_fast=False)
    det = AutoModelForZeroShotObjectDetection.from_pretrained(
        DETECTOR_MODEL, revision=DETECTOR_REVISION
    ).to(device).eval()
    seg_proc = Sam2Processor.from_pretrained(SEGMENTER_MODEL, revision=SEGMENTER_REVISION)
    seg = Sam2Model.from_pretrained(SEGMENTER_MODEL, revision=SEGMENTER_REVISION).to(device).eval()

    files = sorted(p for p in src.iterdir() if p.suffix.lower() in {".jpg", ".jpeg"})
    print(f"{len(files)} images -> {out}", flush=True)
    manifest = []
    started = time.perf_counter()

    for index, path in enumerate(files, 1):
        image = Image.open(path).convert("RGB")
        bgr = cv2.imread(str(path))
        h, w = bgr.shape[:2]

        inputs = det_proc(images=image, text=args.prompt, return_tensors="pt").to(det.device)
        with torch.inference_mode():
            outputs = det(**inputs)
        det_res = det_proc.post_process_grounded_object_detection(
            outputs, inputs.input_ids,
            threshold=args.box_threshold, text_threshold=args.text_threshold,
            target_sizes=[(image.height, image.width)],
        )[0]
        boxes = det_res["boxes"].detach().float().cpu().numpy()
        scores = det_res["scores"].detach().float().cpu().numpy()
        order = np.argsort(-scores)
        boxes, scores = boxes[order], scores[order]

        masks_kept, scores_kept, boxes_kept = [], [], []
        if len(boxes):
            payload = [[[float(v) for v in b] for b in boxes]]
            seg_in = seg_proc(images=image, input_boxes=payload, return_tensors="pt").to(seg.device)
            with torch.inference_mode():
                seg_out = seg(**seg_in)
            masks = seg_proc.post_process_masks(
                seg_out.pred_masks.cpu(), seg_in["original_sizes"]
            )[0].numpy()
            quality = seg_out.iou_scores.detach().float().cpu().numpy()[0]
            for bi in range(len(boxes)):
                best = int(np.argmax(quality[bi]))
                m = masks[bi, best].astype(bool)
                if int(m.sum()) < args.min_mask_pixels:
                    continue
                dup = False
                for prev in masks_kept:
                    inter = int(np.logical_and(m, prev).sum())
                    union = int(np.logical_or(m, prev).sum())
                    if union and inter / union > args.dedupe_iou:
                        dup = True
                        break
                if dup:
                    continue
                masks_kept.append(m)
                scores_kept.append(float(scores[bi]))
                boxes_kept.append(boxes[bi])

        canvas = bgr.copy()
        for i, (m, s, b) in enumerate(zip(masks_kept, scores_kept, boxes_kept)):
            colour = PALETTE[i % len(PALETTE)]
            tint = canvas.copy()
            tint[m] = colour
            # keep the fill faint so the photo shows through, and rely on the
            # 2-px contour below to keep each object readable
            canvas = cv2.addWeighted(canvas, 0.80, tint, 0.20, 0)
            cs, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(canvas, cs, -1, colour, 2)
            x0, y0 = int(b[0]), int(b[1])
            cv2.rectangle(canvas, (x0, y0), (int(b[2]), int(b[3])), colour, 1)
            label = f"{i} {s:.2f}"
            cv2.putText(canvas, label, (x0 + 2, max(12, y0 + 14)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 3)
            cv2.putText(canvas, label, (x0 + 2, max(12, y0 + 14)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        head = f"{path.name}  objects={len(masks_kept)}  boxes={len(boxes)}"
        cv2.putText(canvas, head, (10, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 4)
        cv2.putText(canvas, head, (10, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imwrite(str(out / f"{path.stem}_objects.jpg"), canvas)
        manifest.append({"image": path.name, "boxes": int(len(boxes)),
                         "objects": len(masks_kept),
                         "scores": [round(x, 3) for x in scores_kept]})
        if index % 20 == 0 or index == len(files):
            rate = index / max(1e-9, time.perf_counter() - started)
            print(f"  {index}/{len(files)}  {rate:.1f} img/s", flush=True)

    (out / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    total = sum(m["objects"] for m in manifest)
    print(f"\ndone: {len(files)} images, {total} objects total, "
          f"{time.perf_counter()-started:.0f}s -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
