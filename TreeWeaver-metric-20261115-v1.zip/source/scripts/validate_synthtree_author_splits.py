"""Audit original COCO splits by RGB filename, preserving source JSON files."""

import argparse
import hashlib
import json
from pathlib import Path


def validate_document(document):
    images = document["images"]
    ids = [image["id"] for image in images]
    names = [image["file_name"] for image in images]
    if len(ids) != len(set(ids)) or len(names) != len(set(names)):
        raise ValueError("Duplicate image ID or filename within split")
    image_ids = set(ids)
    category_ids = {category["id"] for category in document["categories"]}
    for annotation in document["annotations"]:
        if annotation["image_id"] not in image_ids:
            raise ValueError("Annotation refers to missing image")
        if annotation["category_id"] not in category_ids:
            raise ValueError("Annotation refers to missing category")
        if not annotation.get("segmentation"):
            raise ValueError("Missing whole-tree segmentation")
    return set(names)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    args = parser.parse_args()
    names, records = {}, {}
    for split in ["train", "val", "test"]:
        path = args.data_root / "annotations" / f"{split}_RGB_entire_tree.json"
        document = json.loads(path.read_text())
        names[split] = validate_document(document)
        records[split] = {
            "images": len(document["images"]),
            "instances": len(document["annotations"]),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    overlaps = {
        f"{a}/{b}": len(names[a] & names[b])
        for a, b in [("train", "val"), ("train", "test"), ("val", "test")]
    }
    if any(overlaps.values()):
        raise ValueError(f"Source split filename overlap: {overlaps}")
    report = {
        "records": records,
        "filename_overlap": overlaps,
        "tree_identity_or_scene_disjointness_verified": False,
        "note": "Filename disjointness does not establish distinct physical/virtual trees",
    }
    (args.data_root / "split_audit.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
