"""CPU-only viewport design preserving every known focal amodal pixel."""

from __future__ import annotations

import math

import numpy as np


def focal_viewport(
    mask, desired_height=0.65, margin=0.04, aspect=(9, 16), *, allow_source_boundary=False
):
    mask = np.asarray(mask, bool)
    if mask.ndim != 2 or not mask.any():
        raise ValueError("need a nonempty 2D focal mask")
    if not 0 < desired_height < 1 or not 0 <= margin < 0.25:
        raise ValueError("invalid viewport parameters")
    height, width = mask.shape
    if len(aspect) != 2 or any(type(value) is not int or value <= 0 for value in aspect):
        raise ValueError("aspect must contain two positive integer dimensions")
    source_boundary = bool(mask[0].any() or mask[-1].any() or mask[:, 0].any() or mask[:, -1].any())
    if source_boundary and not allow_source_boundary:
        raise ValueError("source target touches frame boundary; full-tree completion unverified")
    ys, xs = np.nonzero(mask)
    x0, x1 = int(xs.min()), int(xs.max() + 1)
    y0, y1 = int(ys.min()), int(ys.max() + 1)
    aw, ah = aspect
    height_required = (y1 - y0) / desired_height
    width_required = (x1 - x0) / (aw / ah * (1 - 2 * margin))
    required = max(height_required, width_required)
    crop_h = math.ceil(required / ah) * ah
    max_h = min((height // ah) * ah, (width // aw) * ah)
    crop_h = min(crop_h, max_h)
    crop_w = crop_h * aw // ah
    if crop_h < y1 - y0 or crop_w < x1 - x0:
        raise ValueError("cannot preserve focal tree in requested aspect")
    left = round((x0 + x1 - crop_w) / 2)
    top = round(y1 - 0.90 * crop_h)
    left = max(0, min(left, width - crop_w))
    top = max(0, min(top, height - crop_h))
    # Clamp within the interval that contains the full focal box.
    left = max(x1 - crop_w, min(left, x0))
    top = max(y1 - crop_h, min(top, y0))
    roi = [int(left), int(top), int(left + crop_w), int(top + crop_h)]
    selected = mask[roi[1] : roi[3], roi[0] : roi[2]]
    if selected.sum() != mask.sum():
        raise AssertionError("focal support lost")
    actual_margins = [
        (x0 - left) / crop_w,
        (left + crop_w - x1) / crop_w,
        (y0 - top) / crop_h,
        (top + crop_h - y1) / crop_h,
    ]
    return {
        "roi_xyxy": roi,
        "native_mask_wh": [crop_w, crop_h],
        "height_fraction": (y1 - y0) / crop_h,
        "width_fraction": (x1 - x0) / crop_w,
        "desired_height_fraction": desired_height,
        "width_limited": width_required > height_required,
        "source_boundary_contact": source_boundary,
        "actual_margins_left_right_top_bottom": actual_margins,
        "requested_margin_met": all(value >= margin for value in actual_margins),
        "focal_truncated": source_boundary,
        "mask_resampled": False,
    }
