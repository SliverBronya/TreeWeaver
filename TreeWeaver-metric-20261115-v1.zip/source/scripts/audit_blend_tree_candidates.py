"""Read local non-fig Blender candidates; do not admit them as training assets yet.

Run using Blender --background --python. Source .blend files remain read-only.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = (
    "tools/assets/agrarsense_birch.blend",
    "tools/assets/blenderkit/southern_magnolia_1k.blend",
    "tools/assets/blenderkit/olive_tree.blend",
    "tools/assets/blenderkit/broadleaf_dense_1k.blend",
    "tools/assets/jacaranda_tree/jacaranda_tree_1k.blend",
    "tools/assets/tree_small_02/tree_small_02_1k.blend",
    "tools/assets/island_tree_01/island_tree_01_1k.blend",
    "tools/assets/island_tree_02/island_tree_02_1k.blend",
    "tools/assets/island_tree_03/island_tree_03_1k.blend",
)


def main():
    rows = []
    for relative in CANDIDATES:
        path = ROOT / relative
        if not path.is_file():
            rows.append({"path": relative, "missing": True})
            continue
        bpy.ops.wm.read_factory_settings(use_empty=True)
        with bpy.data.libraries.load(str(path), link=False) as (source, destination):
            destination.objects = source.objects
        meshes = [obj for obj in destination.objects if obj and obj.type == "MESH"]
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        rows.append(
            {
                "path": relative,
                "bytes": path.stat().st_size,
                "sha256": digest.hexdigest(),
                "meshes": [
                    {
                        "name": obj.name,
                        "vertices": len(obj.data.vertices),
                        "materials": [
                            material.name if material else None for material in obj.data.materials
                        ],
                    }
                    for obj in meshes
                ],
                "images": [
                    {
                        "name": image.name,
                        "packed": bool(image.packed_file),
                        "filepath": image.filepath,
                    }
                    for image in bpy.data.images
                ],
                "training_admitted": False,
                "pending": [
                    "license/provenance",
                    "whole tree visual check",
                    "explicit part semantics",
                ],
            }
        )
    by_hash = {}
    for row in rows:
        if "sha256" in row:
            by_hash.setdefault(row["sha256"], []).append(row["path"])
    result = {
        "candidates": rows,
        "exact_duplicate_files": [paths for paths in by_hash.values() if len(paths) > 1],
        "note": "Filenames do not establish species or independent source identity.",
    }
    output = ROOT / "reports/nonfig-asset-audit-2026-11-08.json"
    with output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(
        json.dumps(
            {"candidates": len(rows), "exact_duplicate_files": result["exact_duplicate_files"]}
        )
    )


if __name__ == "__main__":
    main()
