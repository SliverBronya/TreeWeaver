"""Pilot trunk/crown head training on the 3D pilot labels."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-3d-pilot-2026-11-10"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-3d-trunk-crown-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def sample(scene):
    image = Image.open(scene / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = mask(scene / "visible_1.png")
    amodal = mask(scene / "amodal_1.png")
    stem = mask(scene / "stem_1.png")
    crown = visible & ~mask(scene / "visible_stem_1.png")
    ys, xs = np.where(visible)
    box = lb.boxes(np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32))
    def resize(m):
        return np.asarray(Image.fromarray(m.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)) > 127
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        torch.from_numpy(resize(stem).astype(np.float32))[None, None],
        torch.from_numpy(resize(crown).astype(np.float32))[None, None],
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, enable_stem=True, enable_crown=True).cuda()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)["decoder"]
    own = model.decoder.state_dict()
    model.decoder.load_state_dict({k: v for k, v in payload.items() if k in own and v.shape == own[k].shape}, strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.startswith(("decoder.stem_token", "decoder.stem_hypernet", "decoder.crown_token", "decoder.crown_hypernet")):
            parameter.requires_grad_(True)
    return model


def evaluate(model, scenes):
    model.eval()
    stem_values, crown_values = [], []
    with torch.no_grad():
        for scene in scenes:
            image, box, stem, crown = sample(scene)
            output = model(image.cuda(), input_boxes=box.cuda())
            for key, target, values in (("stem_masks", stem, stem_values), ("crown_masks", crown, crown_values)):
                pred = output[key][0, 0, 0].sigmoid().cpu() > 0.5
                t = target[0, 0] > 0.5
                inter, union = (pred & t).sum().item(), (pred | t).sum().item()
                values.append(inter / union if union else 1.0)
    return {"stem_iou": float(np.mean(stem_values)), "crown_iou": float(np.mean(crown_values))}


def main():
    OUT.mkdir(exist_ok=True)
    scenes = sorted(p for p in DATA.iterdir() if p.is_dir())
    train, val = scenes[:4], scenes[4:]
    model = build()
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(json.dumps({"train": len(train), "val": len(val), "trainable": sum(p.numel() for p in parameters)}), flush=True)
    before = evaluate(model, val)
    print(json.dumps({"before": before}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=1e-3, weight_decay=1e-4)
    model.train()
    for step in range(1, 301):
        scene = train[(step - 1) % len(train)]
        image, box, stem, crown = sample(scene)
        optimizer.zero_grad(set_to_none=True)
        output = model(image.cuda(), input_boxes=box.cuda())
        loss = 0
        for key, target in (("stem_masks", stem), ("crown_masks", crown)):
            logits = output[key][:, 0, 0]
            t = target.cuda()[:, 0]
            bce = F.binary_cross_entropy_with_logits(logits, t)
            p = logits.sigmoid()
            dice = 1 - (2 * (p * t).sum() + 1) / (p.sum() + t.sum() + 1)
            loss = loss + bce + dice
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        if step % 25 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 50 == 0 or step == 300:
            print(json.dumps({"eval_step": step, **evaluate(model, val)}), flush=True)
            torch.save({"state": {k: v.detach().cpu() for k, v in model.named_parameters() if v.requires_grad}}, OUT / "checkpoint.pth")
    after = evaluate(model, val)
    result = {"before": before, "after": after, "train": len(train), "val": len(val)}
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
