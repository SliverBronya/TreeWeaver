"""Ten varied single-image Blender scenes with free Poly Haven assets."""

from __future__ import annotations

import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ASSETS = [
    (Path(r"D:\TreeWeaver\tools\assets\tree_small_02\tree_small_02_1k.blend"), "tree_small_02_LOD1"),
    (Path(r"D:\TreeWeaver\tools\assets\jacaranda_tree\jacaranda_tree_1k.blend"), "jacaranda_tree_LOD1"),
    (Path(r"D:\TreeWeaver\tools\assets\island_tree_01\island_tree_01_1k.blend"), "island_tree_01_LOD0"),
]
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRIS = ["forest_slope_2k.hdr", "autumn_forest_03_2k.hdr", "epping_forest_01_2k.hdr"]
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    out = Path(argv[0]) if argv else Path(r"D:\TreeWeaver\reports\blender-tree-variants")
    count = int(argv[1]) if len(argv) > 1 else 10
    seed = int(argv[2]) if len(argv) > 2 else 31
    return out, count, seed


def clean_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.eevee.taa_render_samples = 48
    return scene


def append_tree(asset: Path, object_name: str):
    bpy.ops.wm.append(directory=str(asset) + "/Object/", filename=object_name)
    obj = bpy.data.objects[object_name]
    for other in list(bpy.data.objects):
        if other is not obj:
            bpy.data.objects.remove(other, do_unlink=True)
    return obj


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points),
        max(p.x for p in points),
        min(p.y for p in points),
        max(p.y for p in points),
        min(p.z for p in points),
        max(p.z for p in points),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(value * scale for value in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def add_ground(rng):
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    ground = bpy.context.object
    material = bpy.data.materials.new("ground")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    normal = nodes.new("ShaderNodeTexImage")
    normal.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    normal.image.colorspace_settings.name = "Non-Color"
    normal_map = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    scale = rng.uniform(14, 34)
    mapping.inputs["Scale"].default_value = (scale, scale, scale)
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 2 * math.pi))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], texture.inputs["Vector"])
    links.new(mapping.outputs["Vector"], normal.inputs["Vector"])
    links.new(normal.outputs["Color"], normal_map.inputs["Color"])
    links.new(texture.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    ground.data.materials.append(material)
    return ground


def add_world(environment: str, rng):
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    background = nodes.get("Background")
    environment_node = nodes.new("ShaderNodeTexEnvironment")
    environment_node.image = bpy.data.images.load(str(ENV / environment))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 2 * math.pi))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], environment_node.inputs["Vector"])
    links.new(environment_node.outputs["Color"], background.inputs["Color"])
    background.inputs["Strength"].default_value = rng.uniform(0.8, 1.25)
    bpy.context.scene.world = world


def add_lights(rng):
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = rng.uniform(1.2, 2.6)
    sun.data.angle = math.radians(rng.uniform(3, 10))
    sun.rotation_euler = (
        math.radians(rng.uniform(42, 65)),
        0,
        math.radians(rng.uniform(0, 360)),
    )


def add_camera(target, lens, rng):
    bpy.ops.object.camera_add()
    camera = bpy.context.object
    camera.data.lens = lens
    camera.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    camera.location = (rng.uniform(-0.6, 0.6), -distance, TARGET_HEIGHT * rng.uniform(0.36, 0.56))
    camera.rotation_euler = (
        math.radians(90 + rng.uniform(-2, 2)),
        0,
        math.radians(rng.uniform(-4, 4)),
    )
    camera.data.dof.use_dof = True
    camera.data.dof.focus_object = target
    camera.data.dof.aperture_fstop = rng.uniform(2.8, 5.6)
    bpy.context.scene.camera = camera


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def main():
    out, count, seed = parse_args()
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    for index in range(count):
        clean_scene()
        asset, object_name = ASSETS[index % len(ASSETS)]
        base = append_tree(asset, object_name)
        normalize(base, TARGET_HEIGHT)
        base.name = "tree_target"
        base.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))
        left = duplicate(base)
        left.name = "tree_left"
        left.scale = tuple(value * rng.uniform(0.55, 0.95) for value in base.scale)
        left.location = (-rng.uniform(3.4, 6.8), rng.uniform(-2.5, 2.5), 0)
        left.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))
        right = duplicate(base)
        right.name = "tree_right"
        right.scale = tuple(value * rng.uniform(0.55, 0.95) for value in base.scale)
        right.location = (rng.uniform(3.4, 6.8), rng.uniform(-2.5, 2.5), 0)
        right.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

        add_ground(rng)
        add_world(rng.choice(HDRIS), rng)
        add_lights(rng)
        add_camera(base, rng.uniform(28, 55), rng)
        bpy.context.scene.view_settings.exposure = rng.uniform(-0.25, 0.55)
        bpy.context.scene.render.filepath = str(out / f"{index + 1:02d}.png")
        bpy.ops.render.render(write_still=True)
        print(f"rendered {index + 1}/{count}", flush=True)
    (out / "assets.json").write_text(
        json.dumps({"assets": [a.name for a, _ in ASSETS], "hdris": HDRIS}, indent=2),
        encoding="utf-8",
    )
    print("done")


if __name__ == "__main__":
    main()
