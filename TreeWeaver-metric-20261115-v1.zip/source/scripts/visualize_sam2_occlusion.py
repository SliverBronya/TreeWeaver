"""Visualize the occlusion-aware SAM2 decoder on synthetic-occlusion val samples.

One row per sample: occluded input, GT visible, GT amodal, predicted visible,
predicted amodal, and the convex-hull baseline. Scale-free diagnostic only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from synthtree_instances import SynthTreeInstances  # noqa: E402

PANEL = 320
MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def denormalize(pixel_values: np.ndarray) -> np.ndarray:
    image = np.transpose(pixel_values, (1, 2, 0)) * STD + MEAN
    image = np.clip(image * 255.0, 0, 255).astype(np.uint8)
    return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)


def show(image, mask, colour, title):
    panel = image.copy()
    if mask is not None:
        overlay = np.array(colour, np.float32)
        panel[mask] = (0.55 * panel[mask] + 0.45 * overlay).astype(np.uint8)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 2)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 1)
    return panel


def hull_baseline(visible: np.ndarray, amodal: np.ndarray):
    contours = cv2.findContours(
        visible.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )[0]
    hull = np.zeros_like(visible, np.uint8)
    if contours:
        cv2.fillPoly(hull, [cv2.convexHull(np.vstack(contours))], 1)
    hull = hull.astype(bool)
    iou = float((hull & amodal).sum()) / max(float((hull | amodal).sum()), 1.0)
    return hull, iou


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=4)
    parser.add_argument("--max-images", type=int, default=200)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    dataset = SynthTreeInstances(
        ROOT / "data" / "external" / "synthtree43k" / "test_set",
        ROOT / "data" / "external" / "synthtree43k" / "annotations" / "val_RGB_entire_tree.json",
        max_images=args.max_images,
        seed=1,
        synthetic_occlusion=True,
    )

    samples = [dataset.sample(index, deterministic=True) for index in range(160)]
    rates = np.array([float(sample["occlusion_rate"]) for sample in samples])
    targets = np.linspace(0.05, 0.75, args.rows)
    chosen = []
    for target in targets:
        order = np.argsort(np.abs(rates - target))
        for index in order:
            if int(index) not in chosen:
                chosen.append(int(index))
                break

    titles = [
        "occluded input",
        "GT visible",
        "GT amodal",
        "pred visible",
        "pred amodal",
        "hull baseline",
    ]
    rows = []
    headers = []
    for index in chosen:
        sample = samples[index]
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(args.device)
        box = torch.as_tensor(sample["box"])[None, None].to(args.device)
        with torch.no_grad():
            output = model(pixel_values, input_boxes=box)
        image = cv2.resize(denormalize(sample["pixel_values"]), (PANEL, PANEL))
        gt_visible = cv2.resize(
            sample["mask"][0].astype(np.uint8), (PANEL, PANEL), interpolation=cv2.INTER_NEAREST
        ) > 0
        gt_amodal = cv2.resize(
            sample["amodal_mask"][0].astype(np.uint8),
            (PANEL, PANEL),
            interpolation=cv2.INTER_NEAREST,
        ) > 0
        pred_visible = cv2.resize(
            (output["masks"][0, 0, 0].cpu().numpy() > 0).astype(np.uint8),
            (PANEL, PANEL),
            interpolation=cv2.INTER_NEAREST,
        ) > 0
        pred_amodal = cv2.resize(
            (output["amodal_masks"][0, 0, 0].cpu().numpy() > 0).astype(np.uint8),
            (PANEL, PANEL),
            interpolation=cv2.INTER_NEAREST,
        ) > 0
        hull, hull_iou = hull_baseline(gt_visible, gt_amodal)
        modal_iou = float((pred_visible & gt_visible).sum()) / max(
            float((pred_visible | gt_visible).sum()), 1.0
        )
        amodal_iou = float((pred_amodal & gt_amodal).sum()) / max(
            float((pred_amodal | gt_amodal).sum()), 1.0
        )
        visibility = output["visibility"][0, 0].cpu().numpy()
        rows.append(
            [
                show(image, None, (0, 0, 0), titles[0]),
                show(image, gt_visible, (60, 200, 90), titles[1]),
                show(image, gt_amodal, (40, 100, 240), titles[2]),
                show(image, pred_visible, (60, 200, 90), titles[3]),
                show(image, pred_amodal, (40, 100, 240), titles[4]),
                show(image, hull, (0, 220, 220), titles[5]),
            ]
        )
        headers.append(
            f"#{index} rate={float(sample['occlusion_rate']):.2f} "
            f"modalIoU={modal_iou:.2f} amodalIoU={amodal_iou:.2f} hull={hull_iou:.2f} "
            f"vis={visibility[0]:.2f}/{visibility[1]:.2f}"
        )

    gap = 6
    header_height = 34
    row_height = PANEL + 26
    canvas = np.full(
        (header_height + len(rows) * row_height, len(titles) * (PANEL + gap), 3),
        248,
        np.uint8,
    )
    for column, title in enumerate(titles):
        cv2.putText(
            canvas,
            title,
            (column * (PANEL + gap) + 8, 22),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (30, 30, 30),
            1,
            cv2.LINE_AA,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = header_height + row_index * row_height
        cv2.putText(
            canvas, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (20, 20, 20), 1
        )
        for column, panel in enumerate(panels):
            x0 = column * (PANEL + gap)
            canvas[y0 + 24 : y0 + 24 + PANEL, x0 : x0 + PANEL] = panel

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(args.output), canvas):
        raise SystemExit(f"cannot write {args.output}")
    (args.output.parent / "visualization.json").write_text(
        json.dumps(
            {
                "checkpoint": str(args.checkpoint),
                "rows": headers,
                "column_titles": titles,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"saved {args.output} ({canvas.shape[1]}x{canvas.shape[0]})")
    for header in headers:
        print(header)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
