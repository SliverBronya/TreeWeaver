"""Stamp human review metadata on the 10-image LabelMe pack.

LabelMe cannot create TreeWeaver's review fields itself. This script only stamps
files that already contain human polygons; it refuses empty templates and never
creates or edits mask geometry.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from treeweaver.datasets.real_annotations import validate_human_labelme  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, default=ROOT / "reports" / "real-10-paired-2026-11-01" / "work")
    parser.add_argument("--pack", type=Path, default=ROOT / "reports" / "real-10-paired-2026-11-01")
    parser.add_argument("--reviewer", required=True)
    parser.add_argument(
        "--coverage",
        choices=("partial", "exhaustive_visible"),
        default="partial",
    )
    args = parser.parse_args()
    if not args.reviewer.strip():
        parser.error("reviewer must not be empty")

    approved = 0
    pending = []
    for annotation in sorted(args.work.glob("*.json")):
        document = json.loads(annotation.read_text(encoding="utf-8"))
        if not document.get("shapes"):
            pending.append(annotation.name)
            continue
        document["treeweaver_provenance"] = "human_annotation"
        document["flags"] = {**document.get("flags", {}), "assistant_draft": False}
        document["treeweaver_coverage"] = args.coverage
        document["treeweaver_review"] = {
            "state": "approved",
            "reviewer": args.reviewer.strip(),
        }
        try:
            validate_human_labelme(document)
        except ValueError as error:
            print(f"INVALID {annotation.name}: {error}")
            pending.append(annotation.name)
            continue
        annotation.write_text(json.dumps(document, indent=2, ensure_ascii=False), encoding="utf-8")
        destination = args.pack / "labelme" / annotation.name
        shutil.copy2(annotation, destination)
        approved += 1
        print(f"APPROVED {annotation.name}")

    print(json.dumps({"approved": approved, "pending": pending}, indent=2))
    return 0 if approved else 1


if __name__ == "__main__":
    raise SystemExit(main())
