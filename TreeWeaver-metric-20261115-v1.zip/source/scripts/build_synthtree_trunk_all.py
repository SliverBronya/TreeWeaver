"""Build trunk-level SynthTree43k annotations for all images (parallel, fast path).

Rule reconstructed from the paper:
    trunk_mask = flipud(_mask.png == treeMaskColor) AND inside(4-corner trunk box)

Speed: colours are packed into one int32 per pixel, so each tree needs a single
2-D comparison instead of a 3-channel one; images are processed in a thread pool.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

EXTRA = Path(r"D:\TreeWeaver\.worker-envs\convexmask-extra")
if EXTRA.is_dir() and str(EXTRA) not in sys.path:
    sys.path.insert(0, str(EXTRA))
from pycocotools import mask as mask_utils  # noqa: E402

ROOT = Path(r"D:\TreeWeaver\data\external\synthtree43k\test_set")
ANNOT = Path(r"D:\TreeWeaver\data\external\synthtree43k\annotations")
OUT = Path(r"D:\TreeWeaver\data\processed\synthtree43k-trunk-v3-2026-10-20")
OUT.mkdir(parents=True, exist_ok=True)
MIN_TRUNK_PX = 60
WORKERS = 6


def split_membership() -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for split in ("train", "val", "test"):
        with (ANNOT / f"{split}_RGB_entire_tree.json").open(encoding="utf-8") as stream:
            data = json.load(stream)
        result[split] = {
            str(im["file_name"]).split("_")[0]
            for im in data.get("images", [])
            if "file_name" in im
        }
        print(f"{split}: {len(result[split])} images", flush=True)
        del data
    return result


print("reading split membership from the original annotations...", flush=True)
splits = split_membership()
stem_to_split = {stem: split for split, stems in splits.items() for stem in stems}
del splits

rows = [
    {k.strip(): v for k, v in r.items()}
    for r in csv.DictReader((ROOT / "AllLabels.csv").open(newline="", encoding="utf-8"))
]
by_image: dict[str, list[dict]] = defaultdict(list)
for row in rows:
    by_image[row["image_id"]].append(row)
print(f"csv: {len(rows)} rows / {len(by_image)} images", flush=True)

targets = [img for img in sorted(by_image) if img in stem_to_split]
print(f"images to process: {len(targets)}", flush=True)


def process(image_id: str):
    mask_path = ROOT / f"{image_id}_mask.png"
    if not mask_path.is_file():
        return None
    m = np.array(Image.open(mask_path).convert("RGB"))
    h, w = m.shape[:2]
    packed = (
        (m[:, :, 0].astype(np.int32) << 16)
        | (m[:, :, 1].astype(np.int32) << 8)
        | m[:, :, 2].astype(np.int32)
    )
    del m
    out = []
    for row in by_image[image_id]:
        key = (
            (int(row["treeMaskColor_r"]) << 16)
            | (int(row["treeMaskColor_g"]) << 8)
            | int(row["treeMaskColor_b"])
        )
        hit = packed == key
        if not hit.any():
            continue
        quad = np.array(
            [
                [float(row["BBox_top_lx"]), float(row["BBox_top_ly"])],
                [float(row["BBox_top_rx"]), float(row["BBox_top_ry"])],
                [float(row["BBox_bot_rx"]), float(row["BBox_bot_ry"])],
                [float(row["BBox_bot_lx"]), float(row["BBox_bot_ly"])],
            ],
            np.int32,
        )
        # AllLabels.csv uses Unity screen coordinates (y up); the images use y down.
        # Verified on 000131/000183: unflipped quads land on the ground, y-flipped
        # quads wrap the trunks exactly.
        quad[:, 1] = (h - 1) - quad[:, 1]
        qm = np.zeros((h, w), np.uint8)
        cv2.fillPoly(qm, [quad], 1)
        trunk = hit & (qm > 0)
        area = int(trunk.sum())
        if area < MIN_TRUNK_PX:
            continue
        rle = mask_utils.encode(np.asfortranarray(trunk.astype(np.uint8)))
        rle["counts"] = rle["counts"].decode("ascii")
        ys, xs = np.nonzero(trunk)
        out.append(
            {
                "segmentation": rle,
                "area": area,
                "bbox": [
                    float(xs.min()),
                    float(ys.min()),
                    float(xs.max() - xs.min() + 1),
                    float(ys.max() - ys.min() + 1),
                ],
                "trunk_quad": quad.tolist(),
                "tree_visibility": float(row["Tree_visibility"]),
                "tree_diameter_m": float(row["Tree_diameter"]),
            }
        )
    return image_id, h, w, out


coco = {
    split: {
        "info": {"description": f"SynthTree43k trunk-level ({split}), reconstructed 2026-10-19"},
        "licenses": [],
        "categories": [{"id": 0, "name": "tree_trunk"}],
        "images": [],
        "annotations": [],
    }
    for split in ("train", "val", "test")
}
ann_id = 0
done = 0
with ThreadPoolExecutor(max_workers=WORKERS) as pool:
    for result in pool.map(process, targets, chunksize=32):
        done += 1
        if result is None:
            continue
        image_id, h, w, items = result
        split = stem_to_split[image_id]
        image_pk = int(image_id)
        coco[split]["images"].append(
            {"id": image_pk, "file_name": f"{image_id}_img.png", "width": w, "height": h}
        )
        for item in items:
            ann_id += 1
            coco[split]["annotations"].append(
                {"id": ann_id, "image_id": image_pk, "category_id": 0, "iscrowd": 0, **item}
            )
        if done % 3000 == 0:
            print(f"  {done}/{len(targets)} images, {ann_id} annotations", flush=True)

for split, payload in coco.items():
    path = OUT / f"{split}_trunk.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    print(
        f"{split:>5}: {len(payload['images']):6d} images  "
        f"{len(payload['annotations']):7d} annotations  {path.stat().st_size/1048576:.0f} MB"
    )
