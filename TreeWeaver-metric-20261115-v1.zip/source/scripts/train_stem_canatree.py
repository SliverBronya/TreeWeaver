"""Train the stem token on CanaTree100 fold_00 trunk masks, with a stock baseline.

CanaTree100 ships trunk-only COCO masks (one category, non-exhaustive) on 100
frames drawn from 33 hand-held ZED videos. The release carries no video
identity, so the official folds cannot be proven video-disjoint; fold_00 is used
here as a development set and the run refuses to start without
``--allow-unverified-video-split``, which is recorded in protocol.json.

The fold_00 val/test files are disjoint, but these images also appear in other
folds' train files, so fold_00 can never be a test set for anything that later
trains on folds 01-04.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from research_protocol import (  # noqa: E402
    assert_training_allowed,
    hash_files,
    pinned_snapshot,
    sha256_file,
)
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import (  # noqa: E402
    mask_row,
    mean_of,
    paired,
    stem_masks,
    stock_masks,
    write_json,
)

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
BASE = ROOT / "data/external/canatree100/extracted/CanaTree100"
CHECKPOINT = ROOT / "reports/fig500-long-5h-v2-2026-10-31/best.pth"
SEED = 1729


def load_fold(split: str):
    path = BASE / "annotations" / "fold_00" / f"{split}_fold_00.json"
    document = json.loads(path.read_text(encoding="utf-8"))
    by_image = {image["id"]: image for image in document["images"]}
    grouped = {image_id: [] for image_id in by_image}
    for annotation in document["annotations"]:
        grouped[annotation["image_id"]].append(annotation)
    return by_image, grouped, path


def rasterize(annotation, shape):
    mask = np.zeros(shape, np.uint8)
    for polygon in annotation.get("segmentation", []):
        points = np.rint(np.asarray(polygon).reshape(-1, 2)).astype(np.int32)
        if len(points) >= 3:
            cv2.fillPoly(mask, [points], 1)
    return mask


def sample_image(image, annotations, processor, device):
    image_bgr = cv2.imread(str(BASE / "images" / image["file_name"]))
    if image_bgr is None:
        raise ValueError(f"missing {image['file_name']}")
    height, width = image_bgr.shape[:2]
    pixels = processor(
        images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)), return_tensors="pt"
    )["pixel_values"].to(device)
    boxes, masks = [], []
    for annotation in annotations:
        mask = rasterize(annotation, (height, width))
        if not mask.any():
            continue
        ys, xs = np.nonzero(mask)
        box = np.array([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1], np.float32)
        box *= np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
        boxes.append(box)
        masks.append(mask)
    if not boxes:
        return None
    return (
        pixels,
        torch.as_tensor(np.stack(boxes), device=device)[None],
        np.stack(masks).astype(bool),
        height,
        width,
    )


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2)) + target.sum(dim=(1, 2)) + 1.0
    )


def evaluate(model, sam2, by_image, grouped, processor, device):
    """One row per labelled trunk; neighbour leakage is measured explicitly."""
    model.eval()
    rows = []
    for image_id, image in by_image.items():
        batch = sample_image(image, grouped[image_id], processor, device)
        if batch is None:
            continue
        pixels, boxes, masks, height, width = batch
        stem = stem_masks(model, pixels, boxes, height, width)
        stock = stock_masks(sam2, pixels, boxes, height, width)
        for index in range(len(masks)):
            others = [masks[other] for other in range(len(masks)) if other != index]
            identifier = f"{image['file_name']}:{index}"
            rows.append(
                {
                    "image": image["file_name"],
                    "tree_index": index,
                    "stem": mask_row(identifier, stem[index], masks[index], others=others),
                    "stock_sam2": mask_row(identifier, stock[index], masks[index], others=others),
                }
            )
    model.train()
    return rows


def build_protocol(args, counts):
    fold_directory = BASE / "annotations" / "fold_00"
    fold_files = sorted(fold_directory.glob("*.json"))
    images = load_images()
    return {
        "schema_version": "treeweaver-stem-training-1.0",
        "profile": "dataset_supplied_visible_trunk",
        "role": "development",
        "dataset": {
            "root": str(BASE.resolve()),
            "reference_semantics": (
                "COCO trunk-only polygons, single category 'Tree'; annotations are not "
                "exhaustive, so unlabelled background trunks are absent rather than negative"
            ),
            "annotated_trunks_per_fold": counts,
            "frames": len(images),
            "source_videos": 33,
        },
        "policy_scope": assert_training_allowed(BASE),
        "supervision": ["dataset_supplied_visible_trunk"],
        "prompt": "GT-derived trunk box per annotation; multiple boxes in one image",
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "trainable": ["stem_token", "stem_hypernet"],
            "frozen": "encoder, prompt encoder, all other decoder parameters",
            "init_checkpoint": str(CHECKPOINT),
            "init_checkpoint_sha256": sha256_file(CHECKPOINT),
            "init_checkpoint_note": (
                "fig-500 five-hour decoder; its stem token was never trained, so this run "
                "reports stem-head adaptation rather than a new encoder"
            ),
        },
        "optimizer": {"name": "AdamW", "lr": args.lr, "weight_decay": args.weight_decay},
        "seed": SEED,
        "steps": args.steps,
        "eval_every": args.eval_every,
        "selection": "fold_00 validation mean IoU only; test is scored once at the end",
        "split": {
            "origin": "official CanaTree100 fold_00",
            "fold_00_files": [path.name for path in fold_files],
            "train_val_test_disjoint": True,
            "video_disjoint": False,
            "video_disjoint_reason": (
                "release carries no video identity; 100 frames come from 33 videos and "
                "image-level folds cannot be proven video-disjoint"
            ),
            "cross_fold_overlap": (
                "fold_00 images reappear in other folds' train files; fold_00 is unusable as "
                "a test set for anything trained on folds 01-04"
            ),
            "acknowledged_by_flag": args.allow_unverified_video_split,
        },
        "data_sha256": {
            "fold_files": {path.name: sha256_file(path) for path in fold_files},
            "images": hash_files(
                [BASE / "images" / row["file_name"] for row in images], base=BASE
            ),
        },
        "limitations": [
            "no stem point and no neighbour negative point, so adhesion is measured, not solved",
            "annotation is trunk-only and non-exhaustive",
            "reference row for the published diameter is ~10 cm above ground, so this dataset "
            "cannot validate DBH",
            "seasonal/leafless Quebec forest, not urban street trees",
        ],
    }


def load_images():
    """Union of the fold_00 images, so the protocol hashes every file actually touched."""
    seen = {}
    for split in ("train", "val", "test"):
        path = BASE / "annotations" / "fold_00" / f"{split}_fold_00.json"
        for image in json.loads(path.read_text(encoding="utf-8"))["images"]:
            seen[image["id"]] = image
    return list(seen.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument(
        "--allow-unverified-video-split",
        action="store_true",
        help="required: fold_00 cannot be proven video-disjoint in this release",
    )
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if not args.allow_unverified_video_split:
        parser.error(
            "fold_00 has no provable video isolation; pass --allow-unverified-video-split and "
            "the run will be recorded as development-only"
        )
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    train_images, train_groups, _ = load_fold("train")
    val_images, val_groups, _ = load_fold("val")
    test_images, test_groups, _ = load_fold("test")
    counts = {
        name: sum(len(values) for values in groups.values())
        for name, groups in (
            ("train", train_groups),
            ("val", val_groups),
            ("test", test_groups),
        )
    }
    protocol = build_protocol(args, counts)
    write_json(args.output / "protocol.json", protocol)
    train_ids = list(train_images)
    print(json.dumps({"train_images": len(train_ids), "val_images": len(val_images)}), flush=True)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3, enable_stem=True).to(args.device)
    payload = torch.load(CHECKPOINT, map_location=args.device, weights_only=True)
    result = model.decoder.load_state_dict(payload["decoder"], strict=False)
    missing = [
        key for key in result.missing_keys if not key.startswith(("stem_token.", "stem_hypernet."))
    ]
    if missing or result.unexpected_keys:
        raise ValueError(f"unexpected checkpoint mismatch: {missing} {result.unexpected_keys}")
    for parameter in model.parameters():
        parameter.requires_grad = False
    for name, parameter in model.decoder.named_parameters():
        if name.startswith(("stem_token", "stem_hypernet")):
            parameter.requires_grad = True
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    history = []
    best = {"score": -1.0, "step": 0}
    for step in range(1, args.steps + 1):
        image_id = random.choice(train_ids)
        batch = sample_image(train_images[image_id], train_groups[image_id], processor, args.device)
        if batch is None:
            continue
        pixels, boxes, masks, height, width = batch
        output = model(pixel_values=pixels, input_boxes=boxes, multimask_output=False)
        logits = output["stem_masks"][0, :, 0]
        ground_truth = F.interpolate(
            torch.as_tensor(masks, device=args.device)[:, None].float(),
            logits.shape[-2:],
            mode="nearest",
        )[:, 0]
        loss = F.binary_cross_entropy_with_logits(logits, ground_truth) + dice_loss(
            logits, ground_truth
        ).mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step % 20 == 0:
            print(
                json.dumps(
                    {"step": step, "trees": len(boxes[0]), "loss": float(loss.detach())}
                ),
                flush=True,
            )
        if step % args.eval_every == 0 or step == args.steps:
            scored = evaluate(model, sam2, val_images, val_groups, processor, args.device)
            row = {
                "step": step,
                "val_iou": mean_of([item["stem"] for item in scored], "iou"),
                "val_stock_iou": mean_of([item["stock_sam2"] for item in scored], "iou"),
                "val_trees": len(scored),
                "loss": float(loss.detach()),
            }
            history.append(row)
            print("EVAL", json.dumps(row), flush=True)
            if row["val_iou"] > best["score"]:
                best = {"score": row["val_iou"], "step": step}
                torch.save(
                    {"decoder": model.decoder.state_dict(), "step": step, **row},
                    args.output / "stem_best.pth",
                )
                write_json(args.output / "history.json", history)

    checkpoint = torch.load(
        args.output / "stem_best.pth", map_location=args.device, weights_only=True
    )
    model.decoder.load_state_dict(checkpoint["decoder"])
    per_tree = evaluate(model, sam2, val_images, val_groups, processor, args.device) + evaluate(
        model, sam2, test_images, test_groups, processor, args.device
    )
    for item in per_tree:
        item["role"] = "test" if item["image"] in {
            image["file_name"] for image in test_images.values()
        } else "validation"
    write_json(args.output / "per_tree.json", per_tree)

    def block(items):
        stem_rows = [item["stem"] for item in items]
        stock_rows = [item["stock_sam2"] for item in items]
        return {
            "trees": len(items),
            "stem": {
                "mean_iou": mean_of(stem_rows, "iou"),
                "mean_boundary_f1": mean_of(stem_rows, "boundary_f1"),
                "mean_neighbour_fraction": mean_of(stem_rows, "neighbour_fraction"),
            },
            "stock_sam2": {
                "mean_iou": mean_of(stock_rows, "iou"),
                "mean_boundary_f1": mean_of(stock_rows, "boundary_f1"),
                "mean_neighbour_fraction": mean_of(stock_rows, "neighbour_fraction"),
            },
            "paired": paired(items),
        }

    summary = {
        "schema_version": protocol["schema_version"],
        "selected_step": checkpoint["step"],
        "selection_metric": "fold_00 validation mean IoU",
        "validation": block([item for item in per_tree if item["role"] == "validation"]),
        "test": block([item for item in per_tree if item["role"] == "test"]),
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "clean_holdout": False,
        "notes": [
            "test is fold_00 test, scored once; it is not an independent site or a blind test",
            "fold_00 images reappear in other folds' train files, so this cannot be a test set "
            "for anything trained on folds 01-04",
            "neighbour_fraction is the share of predicted trunk pixels that fall on another "
            "labelled trunk in the same frame: a direct adhesion/merge diagnostic",
        ],
    }
    write_json(args.output / "summary.json", summary)
    write_json(args.output / "history.json", history)
    print("DONE", json.dumps(summary))


if __name__ == "__main__":
    main()
