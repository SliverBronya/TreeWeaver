"""Blender pair render with AGRARSENSE birch trees + forest HDRI + leaf-litter ground."""

from __future__ import annotations

import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ASSET = Path(r"D:\TreeWeaver\tools\assets\agrarsense_birch.blend")
TARGET_OBJECT = "Birch_18m"
LEFT_OBJECT = "Birch_12m"
RIGHT_OBJECT = "Birch_8m"
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0
LENS = 50.0


def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    out = Path(argv[0]) if argv else Path(r"D:\TreeWeaver\reports\blender-pairs-birch")
    pairs = int(argv[1]) if len(argv) > 1 else 1
    seed = int(argv[2]) if len(argv) > 2 else 3
    return out, pairs, seed


def clean_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.image_settings.color_depth = "8"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.3
    scene.eevee.taa_render_samples = 64
    return scene


def recolor_materials():
    for material in bpy.data.materials:
        if not material.use_nodes:
            continue
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        if bsdf is None:
            continue
        name = material.name.lower()
        if name.startswith("leaves") or "leaf" in name:
            bsdf.inputs["Base Color"].default_value = (0.10, 0.30, 0.06, 1)
            bsdf.inputs["Roughness"].default_value = 0.55
        elif "trunk" in name or "branch" in name:
            bsdf.inputs["Base Color"].default_value = (0.28, 0.21, 0.15, 1)
            bsdf.inputs["Roughness"].default_value = 0.9


def append_objects(names):
    for name in names:
        bpy.ops.wm.append(directory=str(ASSET) + "/Object/", filename=name)
    for obj in list(bpy.data.objects):
        if obj.name not in names:
            bpy.data.objects.remove(obj, do_unlink=True)
    return {name: bpy.data.objects[name] for name in names}


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points),
        max(p.x for p in points),
        min(p.y for p in points),
        max(p.y for p in points),
        min(p.z for p in points),
        max(p.z for p in points),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(value * scale for value in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def add_ground():
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    ground = bpy.context.object
    material = bpy.data.materials.new("ground_mat")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    normal = nodes.new("ShaderNodeTexImage")
    normal.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    normal.image.colorspace_settings.name = "Non-Color"
    normal_map = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (26.0, 26.0, 26.0)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], texture.inputs["Vector"])
    links.new(mapping.outputs["Vector"], normal.inputs["Vector"])
    links.new(normal.outputs["Color"], normal_map.inputs["Color"])
    links.new(texture.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    ground.data.materials.append(material)
    return ground


def add_world():
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    background = nodes.get("Background")
    environment = nodes.new("ShaderNodeTexEnvironment")
    environment.image = bpy.data.images.load(str(ENV / "forest_slope_2k.hdr"))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, math.radians(40))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], environment.inputs["Vector"])
    links.new(environment.outputs["Color"], background.inputs["Color"])
    background.inputs["Strength"].default_value = 1.0
    bpy.context.scene.world = world


def add_lights():
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = 2.0
    sun.data.angle = math.radians(6)
    sun.rotation_euler = (math.radians(52), 0, math.radians(30))


def add_camera(target):
    bpy.ops.object.camera_add()
    camera = bpy.context.object
    camera.data.lens = LENS
    camera.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / LENS)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    camera.location = (0, -distance, TARGET_HEIGHT * 0.48)
    camera.rotation_euler = (math.radians(90), 0, 0)
    camera.data.dof.use_dof = True
    camera.data.dof.focus_object = target
    camera.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = camera
    return camera, distance


def render(path: Path, transparent: bool, hidden=()):
    scene = bpy.context.scene
    scene.render.film_transparent = transparent
    for obj in bpy.data.objects:
        if obj.type == "MESH":
            obj.hide_render = obj.name in hidden
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)


def main():
    out, pairs, seed = parse_args()
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    summary = []
    for index in range(pairs):
        clean_scene()
        objects = append_objects([TARGET_OBJECT, LEFT_OBJECT, RIGHT_OBJECT])
        recolor_materials()
        for name, obj in objects.items():
            print(
                "DBG",
                name,
                "before",
                [round(value, 2) for value in bbox(obj)],
                "scale",
                [round(value, 3) for value in obj.scale],
                flush=True,
            )
        target = objects[TARGET_OBJECT]
        left = objects[LEFT_OBJECT]
        right = objects[RIGHT_OBJECT]
        normalize(target, TARGET_HEIGHT)
        normalize(left, TARGET_HEIGHT * rng.uniform(0.78, 0.88))
        normalize(right, TARGET_HEIGHT * rng.uniform(0.75, 0.85))
        target.location = (0, 0, 0)
        target.rotation_euler = (0, 0, math.radians(rng.uniform(-12, 12)))
        left.location = (-rng.uniform(4.0, 4.8), rng.uniform(1.0, 2.0), 0)
        left.rotation_euler = (0, 0, math.radians(rng.uniform(40, 110)))
        right.location = (rng.uniform(4.0, 4.8), rng.uniform(-2.0, -1.0), 0)
        right.rotation_euler = (0, 0, math.radians(rng.uniform(-110, -40)))

        ground = add_ground()
        add_world()
        add_lights()
        camera, distance = add_camera(target)

        prefix = f"pair_{index:02d}"
        render(out / f"{prefix}_rgb.png", transparent=False)
        for name, obj in (("target", target), ("left", left), ("right", right)):
            others = [o.name for o in (target, left, right) if o is not obj] + [ground.name]
            render(out / f"{prefix}_{name}.png", transparent=True, hidden=others)

        summary.append(
            {
                "pair": index,
                "camera_distance": distance,
                "target_height_fraction": 0.85,
                "objects": {
                    "target": [round(v, 3) for v in target.location],
                    "left": [round(v, 3) for v in left.location],
                    "right": [round(v, 3) for v in right.location],
                },
            }
        )
        print(f"rendered {prefix}", flush=True)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("done", len(summary))


if __name__ == "__main__":
    main()
