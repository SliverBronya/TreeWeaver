"""One-variable pilot: identical visible training with/without derived stem examples.

Original SAM2 decoder only; no amodal, ownership, curve head or new stem token.
Real trunk references remain evaluation-only. No checkpoint selection on scores.
"""

from __future__ import annotations

import argparse
import copy
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from compare_synthetic_checkpoints import REVISION, scores  # noqa: E402
from evaluate_treestereo_visible import decode_reference, digest, reference_box  # noqa: E402
from instance_metrics import boundary_f1  # noqa: E402
from partial_supervision import masked_bce_dice  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot  # noqa: E402


def validated_whole_manifest(path):
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest["schema_version"] != "treeweaver-real-visible-split-1.0":
        raise ValueError("unsupported whole-visible manifest")
    train_ids = set(manifest["splits"]["train"])
    val_ids = set(manifest["splits"]["validation"])
    protected = set(manifest["protected_reference_tree_ids"] + manifest["excluded_legacy_tree_ids"])
    if train_ids & val_ids or (train_ids | val_ids) & protected:
        raise ValueError("whole-visible train/validation/protected identities overlap")
    rows = []
    for row in manifest["records"]:
        identity = int(row["tree_id"][2:])
        allowed = train_ids if row["split"] == "train" else val_ids
        if identity not in allowed:
            raise ValueError("record identity disagrees with split")
        rows.append(
            {
                **row,
                "id": row["tree_id"],
                "mask": row["visible_reference"],
                "mask_sha256": row["reference_sha256"],
                "decode": "jpeg",
            }
        )
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stem-manifest", type=Path, required=True)
    parser.add_argument(
        "--whole-manifest",
        type=Path,
        default=ROOT / "reports/real-visible-pilot-2026-11-01/splits.json",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 100:
        parser.error("fresh output and steps=1..100 required")
    stems = json.loads(args.stem_manifest.read_text(encoding="utf-8"))
    if stems["schema_version"] != "treeweaver-stem-retention-pilot-1.0":
        raise ValueError("unsupported stem manifest")
    if not stems["image_disjoint"] or stems["real_trunk_references_used_for_training"] != 0:
        raise ValueError("stem split is not isolated")
    if stems.get("annotation_coverage") != (
        "partial measured trunk segment; outside valid mask ignored"
    ):
        raise ValueError("partial stem coverage must be explicitly declared")
    rows = validated_whole_manifest(args.whole_manifest)
    stem_rows = [{**row, "decode": "png"} for row in stems["records"]]
    if {r["source_image_id"] for r in stem_rows if r["split"] == "train"} & {
        r["source_image_id"] for r in stem_rows if r["split"] == "validation"
    }:
        raise ValueError("stem train/validation images overlap")
    for row in rows + stem_rows:
        if (
            digest(Path(row["image"])) != row["image_sha256"]
            or digest(Path(row["mask"])) != row["mask_sha256"]
        ):
            raise ValueError("frozen source changed")
        if row["split"] == "train":
            assert_training_allowed(Path(row["image"]).parent)
        for key, checksum in (("valid_mask", "valid_sha256"), ("prompt_mask", "prompt_sha256")):
            if key in row and digest(Path(row[key])) != row[checksum]:
                raise ValueError("frozen partial supervision mask changed")
    trunk_protocol = json.loads(
        (ROOT / "reports/treestereo-trunk-reference-2026-11-01/selection.json").read_text(
            encoding="utf-8"
        )
    )
    trunks = [{**row, "decode": "jpeg", "split": "evaluation"} for row in trunk_protocol["records"]]
    for row in trunks:
        if (
            digest(Path(row["image"])) != row["image_sha256"]
            or digest(Path(row["mask"])) != row["mask_sha256"]
        ):
            raise ValueError("protected trunk reference changed")
    args.output.mkdir(parents=True)
    protocol = {
        "profile": "visible_stem_retention_single_variable_pilot",
        "steps_per_arm": args.steps,
        "lr": 1e-5,
        "seed": 20261103,
        "base": "original SAM2; no custom decoder checkpoint",
        "sam_revision": REVISION,
        "trained_parameters": "original mask_decoder only",
        "loss": "BCE + Dice",
        "control": "one whole-visible training sample per update",
        "stem_mixed": "same whole-visible sample plus 0.5 * partial derived-stem loss",
        "stem_partial_scope": "known segment and adjacent background only; rest ignored",
        "whole_manifest_sha256": digest(args.whole_manifest),
        "stem_manifest_sha256": digest(args.stem_manifest),
        "evaluation": "all attempts, same GT boxes, before and fixed final step only",
        "real_trunk_references_used_for_training": 0,
        "limitations": [
            "derived synthetic stem labels, not anatomical author GT",
            "real reference is development evaluation, not blind test",
            "no new branch/head, amodal or ownership training",
        ],
    }
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    source_dir = args.output / "source"
    source_dir.mkdir()
    for source in (
        Path(__file__),
        ROOT / "scripts/prepare_stem_retention_pilot.py",
        ROOT / "scripts/compare_synthetic_checkpoints.py",
        ROOT / "workers/tree_models/partial_supervision.py",
    ):
        (source_dir / source.name).write_bytes(source.read_bytes())
    torch.manual_seed(20261103)
    np.random.seed(20261103)
    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    baseline = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()

    def sample(row):
        image = cv2.imread(row["image"])
        mask_image = cv2.imread(row["mask"])
        target = decode_reference(mask_image) if row["decode"] == "jpeg" else mask_image[..., 0] > 0
        if image is None or target.shape != image.shape[:2] or not target.any():
            raise ValueError("invalid image/target")
        h, w = target.shape
        pixels = processor(
            images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), return_tensors="pt"
        )["pixel_values"].to(args.device)
        prompt = (
            cv2.imread(row["prompt_mask"], cv2.IMREAD_GRAYSCALE) > 0
            if row.get("prompt_mask")
            else target
        )
        valid = (
            cv2.imread(row["valid_mask"], cv2.IMREAD_GRAYSCALE) > 0
            if row.get("valid_mask")
            else None
        )
        box = torch.tensor(reference_box(prompt), device=args.device) * torch.tensor(
            [1024 / w, 1024 / h, 1024 / w, 1024 / h], device=args.device
        )
        return pixels, box[None, None], target, valid

    def objective(model, row):
        pixels, box, target, valid = sample(row)
        result = model(pixel_values=pixels, input_boxes=box, multimask_output=False)
        logits = result.pred_masks[0, 0, 0]
        truth = F.interpolate(
            torch.as_tensor(target.astype(np.float32), device=args.device)[None, None],
            size=logits.shape,
            mode="nearest" if valid is None else "area",
        )[0, 0]
        known = None
        if valid is not None:
            known = (
                F.interpolate(
                    torch.as_tensor(valid.astype(np.float32), device=args.device)[None, None],
                    size=logits.shape,
                    mode="area",
                )[0, 0]
                > 0.999
            )
        return masked_bce_dice(logits, truth, known)

    evaluations = {
        "whole_validation": [r for r in rows if r["split"] == "validation"],
        "synthetic_stem_validation": [r for r in stem_rows if r["split"] == "validation"],
        "real_trunk_reference": trunks,
    }
    all_results = {}

    def evaluate(model, name):
        model.eval()
        evaluation_rows = []
        for role, targets in evaluations.items():
            folder = args.output / name / role
            folder.mkdir(parents=True)
            for index, row in enumerate(targets):
                try:
                    pixels, box, target, valid = sample(row)
                    with torch.inference_mode():
                        logits = model(
                            pixel_values=pixels, input_boxes=box, multimask_output=False
                        ).pred_masks
                        pred = processor.post_process_masks(
                            logits, original_sizes=[list(target.shape)]
                        )
                        pred = pred[0][0, 0].cpu().numpy() > 0
                    metrics = scores(
                        pred if valid is None else pred & valid,
                        target if valid is None else target & valid,
                    )
                    if valid is not None:
                        metrics["boundary_f1"] = boundary_f1(pred, target, valid=valid, tolerance=2)
                    evaluation_rows.append(
                        {"scope": role, "id": row["id"], "failed": False, **metrics}
                    )
                    if index < 3 or role == "real_trunk_reference" and row["id"] == "T35":
                        cv2.imwrite(str(folder / f"{row['id']}.png"), pred.astype(np.uint8) * 255)
                except Exception as error:
                    evaluation_rows.append(
                        {
                            "scope": role,
                            "id": row["id"],
                            "failed": True,
                            "error": repr(error),
                            "iou": 0.0,
                            "recall": 0.0,
                            "precision": 0.0,
                            "boundary_f1": 0.0,
                            "miss_rate": 1.0,
                        }
                    )
            print(f"evaluated {name}: {role} {len(targets)}", flush=True)
        (args.output / name / "per_tree.json").write_text(
            json.dumps(evaluation_rows, indent=2), encoding="utf-8"
        )
        summary = {}
        for role in evaluations:
            selected = [r for r in evaluation_rows if r["scope"] == role]
            summary[role] = {
                key: float(np.mean([r[key] for r in selected]))
                for key in ("iou", "precision", "recall", "miss_rate", "boundary_f1")
            }
            summary[role].update(
                {"attempts": len(selected), "failures": sum(r["failed"] for r in selected)}
            )
        all_results[name] = summary
        (args.output / "summary.json").write_text(
            json.dumps(all_results, indent=2), encoding="utf-8"
        )

    evaluate(baseline, "original")
    whole_order = [r for r in rows if r["split"] == "train"]
    stem_order = [r for r in stem_rows if r["split"] == "train"]
    random.Random(20261103).shuffle(whole_order)
    random.Random(20261103).shuffle(stem_order)
    for name in ("visible_control", "visible_stem"):
        torch.manual_seed(20261103)
        model = copy.deepcopy(baseline)
        for parameter in model.parameters():
            parameter.requires_grad_(False)
        for parameter in model.mask_decoder.parameters():
            parameter.requires_grad_(True)
        optimizer = torch.optim.AdamW(model.mask_decoder.parameters(), lr=1e-5, weight_decay=1e-4)
        model.train()
        model.vision_encoder.eval()
        model.prompt_encoder.eval()
        history = []
        for step in range(args.steps):
            optimizer.zero_grad(set_to_none=True)
            whole_row = whole_order[step % len(whole_order)]
            loss = objective(model, whole_row)
            loss.backward()
            stem_loss = None
            if name == "visible_stem":
                stem_loss = 0.5 * objective(model, stem_order[step % len(stem_order)])
                stem_loss.backward()
            if not torch.isfinite(loss) or stem_loss is not None and not torch.isfinite(stem_loss):
                raise FloatingPointError("non-finite objective")
            torch.nn.utils.clip_grad_norm_(model.mask_decoder.parameters(), 1.0)
            optimizer.step()
            history.append(
                {
                    "step": step + 1,
                    "whole_id": whole_row["id"],
                    "whole_loss": float(loss.detach()),
                    "weighted_stem_loss": float(stem_loss.detach())
                    if stem_loss is not None
                    else 0.0,
                }
            )
            if (step + 1) % 20 == 0:
                print(name, json.dumps(history[-1]), flush=True)
        folder = args.output / name
        folder.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "sam2_mask_decoder": model.mask_decoder.state_dict(),
                "protocol": protocol,
                "arm": name,
                "step": args.steps,
            },
            folder / "final.pth",
        )
        (folder / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        evaluate(model, name)
        del model, optimizer
        torch.cuda.empty_cache()
    print(json.dumps(all_results, indent=2), flush=True)


if __name__ == "__main__":
    main()
