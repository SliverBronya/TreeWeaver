"""Freeze an image-disjoint, derived-label stem pilot without touching real references."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".worker-envs/convexmask-extra"))
from pycocotools import mask as coco_mask  # noqa: E402


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20261103)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output required")
    sources = ROOT / "data/processed/synthtree43k-trunk-v3-2026-10-20"
    raw = ROOT / "data/external/synthtree43k/test_set"
    candidates = {}
    source_hashes = {}
    memberships = {}
    for role, count in (("train", 100), ("validation", 24)):
        annotation = sources / ("train_trunk.json" if role == "train" else "val_trunk.json")
        source_hashes[str(annotation)] = sha(annotation)
        payload = json.loads(annotation.read_text(encoding="utf-8"))
        images = {row["id"]: row for row in payload["images"]}
        memberships[role] = set(images)
        groups = {}
        for row in payload["annotations"]:
            if row["area"] >= 200 and row["bbox"][2] >= 3 and row["bbox"][3] >= 40:
                groups.setdefault(row["image_id"], []).append(row)
        chosen = random.Random(args.seed).sample(sorted(groups), count)
        candidates[role] = [
            (images[key], random.Random(args.seed + key).choice(groups[key])) for key in chosen
        ]
    if memberships["train"] & memberships["validation"]:
        raise ValueError("source train/validation image overlap")
    args.output.mkdir(parents=True)
    masks = args.output / "masks"
    masks.mkdir()
    records, previews = [], []
    for role, selected in candidates.items():
        for image, annotation in selected:
            target = coco_mask.decode(annotation["segmentation"]).astype(bool)
            rgb_path = raw / image["file_name"]
            instance_path = raw / image["file_name"].replace("_img.png", "_mask.png")
            rgb = cv2.imread(str(rgb_path))
            instance = cv2.imread(str(instance_path))
            if rgb is None or instance is None or rgb.shape[:2] != target.shape:
                raise ValueError("missing or misaligned RGB/instance raster")
            quad = np.asarray(annotation["trunk_quad"], np.int32)
            region = np.zeros(target.shape, np.uint8)
            cv2.fillPoly(region, [quad], 1)
            colors = np.unique(instance[target], axis=0)
            if len(colors) != 1 or not colors.any() or (target & (region == 0)).any():
                raise ValueError(
                    "derived trunk disagrees with instance colors or trunk quadrilateral"
                )
            expected = (instance == colors[0]).all(-1) & (region > 0)
            if not np.array_equal(target, expected) or int(target.sum()) != annotation["area"]:
                raise ValueError(
                    "derived mask does not reproduce source instance/quad intersection"
                )
            mask_path = masks / f"{role}_{image['id']}.png"
            cv2.imwrite(str(mask_path), target.astype(np.uint8) * 255)
            # CSV quads cover a measured trunk segment, not the whole stem.
            # Keep the full visible instance as the prompt target, and never
            # label its unannotated continuation as background.
            full_instance = (instance == colors[0]).all(-1)
            x0, y0 = quad.min(0)
            x1, y1 = quad.max(0)
            margin = max(8, int((x1 - x0 + 1) * 0.75))
            valid = np.zeros(target.shape, bool)
            valid[
                max(0, y0) : min(target.shape[0], y1 + 1),
                max(0, x0 - margin) : min(target.shape[1], x1 + margin + 1),
            ] = True
            valid &= ~full_instance | target
            prompt_path = masks / f"{role}_{image['id']}_prompt.png"
            valid_path = masks / f"{role}_{image['id']}_valid.png"
            cv2.imwrite(str(prompt_path), full_instance.astype(np.uint8) * 255)
            cv2.imwrite(str(valid_path), valid.astype(np.uint8) * 255)
            records.append(
                {
                    "id": f"synth-{image['id']}",
                    "source_image_id": image["id"],
                    "split": role,
                    "image": str(rgb_path.resolve()),
                    "mask": str(mask_path.resolve()),
                    "image_sha256": sha(rgb_path),
                    "mask_sha256": sha(mask_path),
                    "instance_raster_sha256": sha(instance_path),
                    "annotation_id": annotation["id"],
                    "trunk_quad": annotation["trunk_quad"],
                    "area": annotation["area"],
                    "prompt_mask": str(prompt_path.resolve()),
                    "prompt_sha256": sha(prompt_path),
                    "valid_mask": str(valid_path.resolve()),
                    "valid_sha256": sha(valid_path),
                }
            )
            if role == "train" and len(previews) < 6:
                panel = rgb.copy()
                panel[target] = (0.45 * panel[target] + 0.55 * np.array([30, 80, 255])).astype(
                    np.uint8
                )
                cv2.polylines(panel, [quad], True, (0, 255, 0), 2)
                cv2.putText(
                    panel,
                    f"{image['id']} / derived stem",
                    (10, 26),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2,
                )
                previews.append(cv2.resize(panel, (480, 270)))
    cv2.imwrite(
        str(args.output / "label-check.jpg"),
        np.concatenate(
            [np.concatenate(previews[:3], axis=1), np.concatenate(previews[3:], axis=1)], axis=0
        ),
    )
    manifest = {
        "schema_version": "treeweaver-stem-retention-pilot-1.0",
        "seed": args.seed,
        "supervision": "derived instance-color intersected with CSV trunk quadrilateral",
        "not_anatomical_author_ground_truth": True,
        "image_disjoint": True,
        "asset_disjoint_verified": False,
        "source_sha256": source_hashes,
        "records": records,
        "source_reproduction_check": (
            "all selected masks exactly match source color/quad intersection"
        ),
        "real_trunk_references_used_for_training": 0,
        "annotation_coverage": "partial measured trunk segment; outside valid mask ignored",
        "prompt": "box of full visible source instance, not cropped trunk segment",
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"train": 100, "validation": 24, "all_source_checks_passed": True}))


if __name__ == "__main__":
    main()
