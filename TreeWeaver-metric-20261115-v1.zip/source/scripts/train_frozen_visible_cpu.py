"""Small CPU-only visible LoRA pilot on the frozen cohort.

This is a real optimization run, not a paper result: 20 single-sample steps on
CPU, reported honestly.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
OUT = ROOT / "reports/frozen-visible-cpu-pilot-2026-11-09"
CKPT = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask_tensor(path):
    image = np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16
    image = Image.fromarray(image.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)
    return torch.from_numpy(np.asarray(image, dtype=np.float32) / 255.0)[None, None]


def boxes(row):
    x0, y0, x1, y1 = row["box_xyxy"]
    width, height = row["mask_wh"]
    return torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(CKPT, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.endswith(("lora_a", "lora_b")):
            parameter.requires_grad_(True)
    return model


def evaluate(model, rows):
    model.eval()
    values = []
    with torch.no_grad():
        for row in rows:
            output = model(image_tensor(row["paths"]["image"]), input_boxes=boxes(row))
            prediction = output["masks"][0, 0, 0].sigmoid() > 0.5
            target = mask_tensor(row["paths"]["visible"])[0, 0] > 0.5
            intersection = (prediction & target).sum().item()
            union = (prediction | target).sum().item()
            values.append(intersection / union if union else 1.0)
    return float(np.mean(values)) if values else 0.0, values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--train-limit", type=int, default=12)
    parser.add_argument("--eval-limit", type=int, default=6)
    args = parser.parse_args()
    if OUT.exists():
        raise SystemExit(f"exists: {OUT}")
    OUT.mkdir(parents=True)
    torch.set_num_threads(2)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    train = index["train"]["records"][: args.train_limit]
    val = index["validation"]["records"][: args.eval_limit]
    model = build()
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(json.dumps({"trainable": sum(p.numel() for p in parameters), "train": len(train), "val": len(val), "device": "cpu"}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    before = evaluate(model, val)[0]
    print(json.dumps({"eval_step": 0, "visible_iou": before}), flush=True)
    model.train()
    history = []
    for step, row in enumerate(train[: args.steps], start=1):
        optimizer.zero_grad(set_to_none=True)
        output = model(image_tensor(row["paths"]["image"]), input_boxes=boxes(row))
        logits = output["masks"][:, 0, 0]
        target = mask_tensor(row["paths"]["visible"])[:, 0]
        bce = F.binary_cross_entropy_with_logits(logits, target)
        probability = logits.sigmoid()
        dice = 1 - (2 * (probability * target).sum() + 1) / (probability.sum() + target.sum() + 1)
        loss = bce + dice
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        history.append(float(loss.detach()))
        print(json.dumps({"step": step, "loss": float(loss.detach()), "bce": float(bce.detach()), "dice": float(dice.detach())}), flush=True)
        if step % 5 == 0 or step == args.steps:
            after = evaluate(model, val)[0]
            print(json.dumps({"eval_step": step, "visible_iou": after}), flush=True)
            torch.save({"lora": {k: v for k, v in model.state_dict().items() if "lora_" in k}}, OUT / "checkpoint.pth")
    after = evaluate(model, val)[0]
    result = {"before_visible_iou": before, "after_visible_iou": after, "steps": len(history), "loss_start": history[0] if history else None, "loss_end": history[-1] if history else None}
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
