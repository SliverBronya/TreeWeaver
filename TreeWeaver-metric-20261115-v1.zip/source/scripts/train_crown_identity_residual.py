"""Frozen whole-tree masks plus zero-start identity residual; local/anchor ablation."""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from train_paired_whole_tree import REVISION, evaluate, read_mask, tensors, write
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from crown_identity_residual import CrownIdentityResidual, residual_identity_loss  # noqa: E402
from paired_fig_dataset import PairedFigDataset  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PRIOR = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08"


class ResidualModel(torch.nn.Module):
    def __init__(self, cache, residual, device):
        super().__init__()
        self.cache, self.residual, self.device = cache, residual, device
        self.position = 0

    def forward(self, **inputs):
        frame = self.cache[self.position]
        self.position += 1
        raw, prior = frame["raw"].to(self.device), frame["prior"].to(self.device)
        anchors = frame["anchors"].to(self.device)
        if not torch.equal(anchors, inputs["input_points"][0, :, 0] / 1024):
            raise ValueError("cached frame does not match evaluation prompts")
        scores = prior
        if self.residual is not None:
            scores, _ = self.residual(
                frame["features"].to(self.device),
                raw,
                prior,
                anchors,
                frame["anchor_valid"].to(self.device),
            )
        logits = torch.cat([torch.zeros_like(scores[:1]), scores])[None]
        return {"masks": raw[None, :, None], "ownership_logits": logits}


def cache_frames(model, dataset, device):
    cache, metadata = [], []
    with torch.no_grad():
        for index, record in enumerate(dataset.items):
            sample = dataset.sample(index)
            inputs, _ = tensors(sample, device)
            output = model(**inputs)
            native = {
                key: torch.from_numpy(
                    np.stack([read_mask(dataset, item[key]) for item in record["instances"]])
                )
                for key in ("visible", "raster_unknown", "visible_stem", "visible_part_unknown")
            }
            raw = output["masks"][0, :, 0]
            prior = F.interpolate(
                raw[:, None], native["visible"].shape[-2:], mode="bilinear", align_corners=False
            )[:, 0]
            frame = {
                "features": output["query_pixel_embeddings"][0].cpu(),
                "raw": raw.cpu(),
                "prior": prior.cpu(),
                "anchors": inputs["input_points"][0, :, 0].cpu() / 1024,
                "anchor_valid": inputs["input_labels"][0, :, 0].cpu() > 0,
                "target": native["visible"],
                "valid": ~native["raster_unknown"],
                "stem": native["visible_stem"],
                "part_valid": ~native["raster_unknown"] & ~native["visible_part_unknown"],
            }
            active = frame["prior"] > 0
            recoverable = (active & frame["target"]).any(0) & (active.sum(0) > 1)
            recoverable &= frame["valid"].all(0) & (frame["target"].sum(0) == 1)
            metadata.append(
                {
                    "id": record["id"],
                    "recoverable_pixels": int(recoverable.sum()),
                    "ambiguous_stem_pixels": int(
                        (recoverable & (frame["stem"] & frame["part_valid"]).any(0)).sum()
                    ),
                }
            )
            cache.append(frame)
    return cache, metadata


def acceptance(reference, independent, candidate):
    return bool(
        reference["neighbour_fraction"] > 0.001
        and candidate["neighbour_fraction"] <= 0.9 * reference["neighbour_fraction"]
        and candidate["iou"] >= independent["iou"]
        and all(
            candidate[key] >= independent[key] - 0.005
            for key in ("recall", "crown_recall", "stem_recall")
        )
        and candidate["precision"] >= reference["precision"] - 0.005
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 300:
        parser.error("fresh output and steps=1..300 required")
    assert_training_allowed(args.data)
    audit = json.loads((args.data / "paired-audit.json").read_text())
    split = json.loads((args.data / "splits.json").read_text())
    if (
        not audit["planned_dataset_complete"]
        or not split["complete"]
        or any(row["frame_truncated"] for row in audit["records"])
    ):
        raise ValueError("qualified complete untruncated whole-tree data required")
    previous_protocol = json.loads((PRIOR / "protocol.json").read_text())
    prior_inputs = {
        Path(path).resolve(): digest for path, digest in previous_protocol["input_sha256"].items()
    }
    if (args.data / "paired-samples.json").resolve() not in prior_inputs:
        raise ValueError("residual experiment must use the frozen prior's paired corpus")
    for path, digest in previous_protocol["input_sha256"].items():
        if sha256_file(path) != digest:
            raise ValueError(f"frozen prior input changed: {path}")
    datasets = {role: PairedFigDataset(args.data, role) for role in ("train", "validation")}
    checkpoint = PRIOR / "coverage-final.pth"
    encoder_projection_checkpoint = Path(previous_protocol["initial_checkpoint"])
    if sha256_file(encoder_projection_checkpoint) != previous_protocol["initial_checkpoint_sha256"]:
        raise ValueError("original real-visible feature projection checkpoint changed")
    args.output.mkdir(parents=True)
    source = args.output / "source"
    source.mkdir()
    paths = [
        Path(__file__),
        ROOT / "scripts/train_paired_whole_tree.py",
        ROOT / "scripts/stem_eval_common.py",
    ] + [
        ROOT / "workers/tree_models" / name
        for name in (
            "crown_identity_residual.py",
            "paired_fig_dataset.py",
            "sam2_occlusion.py",
            "whole_tree_objective.py",
            "partial_supervision.py",
            "instance_metrics.py",
            "research_protocol.py",
        )
    ]
    protocol = {
        "profile": "whole-tree-prior-preserving-identity-v1",
        "seed": 20261108,
        "prior": str(checkpoint),
        "prior_sha256": sha256_file(checkpoint),
        "prior_protocol_sha256": sha256_file(PRIOR / "protocol.json"),
        "feature_projection_checkpoint": str(encoder_projection_checkpoint),
        "feature_projection_checkpoint_sha256": sha256_file(encoder_projection_checkpoint),
        "sam_revision": REVISION,
        "steps_per_arm": args.steps,
        "lr": 0.001,
        "arms": ["local", "anchor"],
        "prior_frozen": True,
        "initial_behavior": "exact simple mask-score competition; zero residual output",
        "architecture": (
            "query-conditioned pixels; optional point feature and relative anchor coordinates"
        ),
        "correction": "raw residual +/-2; center active queries; disputed pixels only",
        "loss": "owner CE + 0.5 visible-stem CE + 0.01 known-pixel residual squared",
        "sampling": "same 100-step order from TRAIN frames with recoverable ambiguous pixels",
        "validation": "fixed final step, native labels; reused development validation",
        "shared_cache": "one frozen feature/mask extraction per frame for both arms and control",
        "archived_prior_tolerance": {
            "changed_sign_fraction_at_most": 1e-6,
            "max_logit_difference": 0.05,
            "max_per_image_mean_logit_difference": 1e-4,
        },
        "test_images_accessed": False,
        "acceptance": (
            "10% neighbour fraction reduction vs simple control; IoU >= independent prior; "
            "recall/crown/stem drops <=0.005; precision drop vs control <=0.005"
        ),
        "scope": "whole visible-tree identity; single fig species/simple environment; no amodal",
        "input_sha256": dict(previous_protocol["input_sha256"]),
        "source_sha256": {},
        "versions": {"torch": str(torch.__version__)},
    }
    for path in paths:
        (source / path.name).write_bytes(path.read_bytes())
        protocol["source_sha256"][str(path)] = sha256_file(path)
    write(args.output / "protocol.json", protocol)
    torch.set_num_threads(4)
    torch.manual_seed(20261108)
    base = (
        Sam2Model.from_pretrained(
            pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    # Sam2Model.get_image_features uses its mask_decoder's conv_s0/conv_s1.
    # The frozen feature projection must therefore match the real-visible
    # initialization, in addition to restoring the custom coverage decoder.
    real_visible = torch.load(encoder_projection_checkpoint, map_location="cpu", weights_only=True)
    base.mask_decoder.load_state_dict(real_visible["sam2_mask_decoder"], strict=True)
    model = Sam2OcclusionModel(base, expose_query_features=True).to(args.device).eval()
    payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if (
        payload["arm"] != "coverage"
        or payload["protocol"]["profile"] != "whole-tree-visible-identity-pilot-v3-native-points"
    ):
        raise ValueError("expected qualified native-point whole-tree coverage checkpoint")
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    before_weights = {
        name: value.detach().cpu().clone() for name, value in model.state_dict().items()
    }
    cache, metadata = cache_frames(model, datasets["train"], args.device)
    validation_cache, _ = cache_frames(model, datasets["validation"], args.device)
    eligible = [i for i, row in enumerate(metadata) if row["recoverable_pixels"] > 0]
    if not eligible:
        raise ValueError("no recoverable ambiguous training owners")
    rng = random.Random(20261108)
    order = [rng.choice(eligible) for _ in range(args.steps)]
    protocol["train_sample_order"] = [metadata[i]["id"] for i in order]
    protocol["eligible_frames"] = [metadata[i] for i in eligible]
    write(args.output / "protocol.json", protocol)
    write(args.output / "training-cache-metadata.json", metadata)
    print(
        json.dumps(
            {
                "eligible_frames": len(eligible),
                "recoverable_pixels": sum(m["recoverable_pixels"] for m in metadata),
            }
        ),
        flush=True,
    )
    baseline, _ = evaluate(
        ResidualModel(validation_cache, None, args.device),
        datasets["validation"],
        args.device,
        args.output / "prior",
    )
    reproduction = {
        "sign_changes": 0,
        "pixels": 0,
        "maximum_logit_difference": 0.0,
        "maximum_image_mean_logit_difference": 0.0,
    }
    for record in datasets["validation"].items:
        filename = f"{record['id']}.npz"
        with (
            np.load(PRIOR / "coverage" / filename) as previous,
            np.load(args.output / "prior" / filename) as current,
        ):
            old, new = previous["logits"], current["logits"]
            difference = np.abs(old - new)
            reproduction["pixels"] += old.size
            reproduction["sign_changes"] += int(((old > 0) != (new > 0)).sum())
            reproduction["maximum_logit_difference"] = max(
                reproduction["maximum_logit_difference"], float(difference.max())
            )
            reproduction["maximum_image_mean_logit_difference"] = max(
                reproduction["maximum_image_mean_logit_difference"], float(difference.mean())
            )
    write(args.output / "prior-reproduction.json", reproduction)
    if (
        reproduction["sign_changes"] / reproduction["pixels"] > 1e-6
        or reproduction["maximum_logit_difference"] > 0.05
        or reproduction["maximum_image_mean_logit_difference"] > 1e-4
    ):
        raise ValueError("prior differs beyond FP32 numerical tolerance")
    results = {"prior": baseline}
    for mode in protocol["arms"]:
        torch.manual_seed(20261108)
        residual = CrownIdentityResidual(anchor=mode == "anchor").to(args.device)
        # Verify exact initialization on every eligible training frame.
        with torch.no_grad():
            for index in eligible:
                frame = {k: v.to(args.device) for k, v in cache[index].items()}
                scores, correction = residual(
                    frame["features"],
                    frame["raw"],
                    frame["prior"],
                    frame["anchors"],
                    frame["anchor_valid"],
                )
                if not torch.equal(scores, frame["prior"]) or correction.any():
                    raise ValueError("nonzero initial identity correction")
        optimizer = torch.optim.AdamW(residual.parameters(), lr=0.001, weight_decay=1e-4)
        history = []
        residual.train()
        for step, index in enumerate(order, 1):
            frame = {k: v.to(args.device) for k, v in cache[index].items()}
            scores, correction = residual(
                frame["features"],
                frame["raw"],
                frame["prior"],
                frame["anchors"],
                frame["anchor_valid"],
            )
            loss, info = residual_identity_loss(
                scores,
                frame["prior"],
                frame["target"],
                frame["valid"],
                frame["stem"],
                frame["part_valid"],
                correction,
            )
            if not torch.isfinite(loss):
                raise ValueError("nonfinite residual loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(residual.parameters(), 1)
            optimizer.step()
            history.append(
                {
                    "step": step,
                    "sample": metadata[index]["id"],
                    "loss": float(loss.detach()),
                    **{k: float(v.detach()) if torch.is_tensor(v) else v for k, v in info.items()},
                }
            )
            if step % 25 == 0:
                print(json.dumps({"arm": mode, **history[-1]}), flush=True)
        write(args.output / f"{mode}-history.json", history)
        residual.eval()
        torch.save(
            {"residual": residual.state_dict(), "protocol": protocol, "arm": mode},
            args.output / f"{mode}-final.pth",
        )
        results[mode], _ = evaluate(
            ResidualModel(validation_cache, residual, args.device).eval(),
            datasets["validation"],
            args.device,
            args.output / mode,
            learned=True,
        )
        passed = acceptance(
            baseline["mask_winner"]["multi_scene"],
            baseline["independent"]["multi_scene"],
            results[mode]["owner_winner"]["multi_scene"],
        )
        print(
            json.dumps(
                {
                    "arm": mode,
                    "acceptance_passed": passed,
                    "metrics": results[mode]["owner_winner"]["multi_scene"],
                }
            ),
            flush=True,
        )
    if any(
        not torch.equal(value.detach().cpu(), before_weights[name])
        for name, value in model.state_dict().items()
    ):
        raise ValueError("frozen whole-tree decoder changed")
    accepted = {
        mode: acceptance(
            baseline["mask_winner"]["multi_scene"],
            baseline["independent"]["multi_scene"],
            results[mode]["owner_winner"]["multi_scene"],
        )
        for mode in protocol["arms"]
    }
    write(
        args.output / "results.json",
        {
            "arms": results,
            "acceptance_passed": accepted,
            "frozen_prior_exact_binary_reproduction": reproduction["sign_changes"] == 0,
            "prior_reproduction": reproduction,
            "shared_prior_across_arms": True,
            "prior_weights_unchanged": True,
            "test_images_accessed": False,
        },
    )


if __name__ == "__main__":
    main()
