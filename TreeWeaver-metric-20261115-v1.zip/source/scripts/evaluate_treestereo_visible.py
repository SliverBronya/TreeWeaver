"""Bounded visible-reference comparison, excluding known composite-source trees.

Profile: dataset_supplied_visible_reference. This is not a human_verified
annotation manifest, a blind registered test, amodal truth or metric geometry.
Both models receive the same GT-derived box (a segmentation upper-bound prompt).
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import random
import re
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
from instance_metrics import boundary_f1, mask_iou  # noqa: E402

EXCLUDED_TREE_IDS = {"FT211", "FT88", "FT207", "FT161", "FT94", "FT149"}
SAM_REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def normalized_tree_id(name):
    match = re.match(r"FT(\d+)(?:_|$)", name, re.IGNORECASE)
    if not match:
        raise ValueError(f"missing numeric FT identity: {name}")
    return f"FT{int(match.group(1))}"


def select_records(source, count=24, seed=20261101):
    if count < 1:
        raise ValueError("count must be positive")
    groups = {}
    for path in sorted(Path(source).glob("*_LEFT_mask.jpg")):
        identity = normalized_tree_id(path.stem)
        if identity not in EXCLUDED_TREE_IDS:
            groups.setdefault(identity, []).append(path)
    identities = sorted(groups, key=lambda item: int(item[2:]))
    sampled = random.Random(seed).sample(identities, min(count, len(identities)))
    records = []
    for identity in sampled:
        mask = groups[identity][0]  # one predeclared lexicographic LEFT view per physical tree
        records.append(
            {
                "tree_id": identity,
                "image": str(
                    mask.with_name(mask.name.replace("_LEFT_mask.jpg", "_LEFT.jpg")).resolve()
                ),
                "mask": str(mask.resolve()),
                "available_left_views": len(groups[identity]),
            }
        )
    if not records:
        raise ValueError("no eligible paired LEFT references found")
    return records, len(groups)


def decode_reference(mask_image, threshold=127):
    if mask_image is None or mask_image.ndim != 3 or mask_image.shape[2] != 3:
        raise ValueError("expected colour JPEG mask with black background")
    if not 0 <= threshold < 255:
        raise ValueError("mask threshold must be in 0..254")
    # Do not fill holes, convexify, smooth or use model predictions to edit GT.
    return mask_image.max(axis=2) > threshold


def reference_box(mask, padding=0.05):
    ys, xs = np.nonzero(mask)
    if not len(xs):
        raise ValueError("dataset reference mask is empty")
    height, width = mask.shape
    dx, dy = padding * (xs.max() - xs.min() + 1), padding * (ys.max() - ys.min() + 1)
    return [
        max(0.0, float(xs.min() - dx)),
        max(0.0, float(ys.min() - dy)),
        min(float(width), float(xs.max() + 1 + dx)),
        min(float(height), float(ys.max() + 1 + dy)),
    ]


def check_training_exclusions(path):
    tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    for statement in tree.body:
        if isinstance(statement, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "TARGETS" for target in statement.targets
        ):
            actual = {normalized_tree_id(value) for value in ast.literal_eval(statement.value)}
            if actual != EXCLUDED_TREE_IDS:
                raise ValueError("composite training sources changed; re-audit exclusions first")
            return
    raise ValueError("cannot inspect composite TARGETS provenance")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source",
        type=Path,
        default=ROOT
        / "data"
        / "external"
        / "tree-stereo-biophysical-v4"
        / "extracted"
        / "full_trees",
    )
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--count", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20261101)
    parser.add_argument("--mask-threshold", type=int, default=127)
    parser.add_argument("--box-padding", type=float, default=0.05)
    parser.add_argument("--boundary-tolerance", type=int, default=2)
    parser.add_argument("--previews", type=int, default=4)
    parser.add_argument("--sam-revision", default=SAM_REVISION)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if not 1 <= args.count <= 24 or not 0 <= args.box_padding <= 0.25:
        parser.error("count must be 1..24 and box-padding in [0,0.25]")
    if args.boundary_tolerance < 0 or args.previews < 0:
        parser.error("boundary-tolerance and previews must be nonnegative")
    if args.output.exists():
        raise FileExistsError("use a new output directory")
    training_script = ROOT / "scripts" / "make_composite_dataset.py"
    check_training_exclusions(training_script)
    records, eligible = select_records(args.source, args.count, args.seed)
    args.output.mkdir(parents=True)
    protocol = {
        "profile": "dataset_supplied_visible_reference",
        "role": "evaluation_only",
        "split": "reference_validation",
        "seed": args.seed,
        "eligible_unique_tree_ids": eligible,
        "selected_count": len(records),
        "excluded_all_views_tree_ids": sorted(EXCLUDED_TREE_IDS),
        "source_training_script": str(training_script),
        "source_training_script_sha256": digest(training_script),
        "selection": "sample numeric FT IDs without replacement; first lexicographic LEFT per FT",
        "mask_decode": (
            f"colour JPEG max(BGR) > {args.mask_threshold}; no fill/morphology/convex hull"
        ),
        "reference_semantics": (
            "dataset-supplied filled visible silhouettes, not leaf-level alpha truth"
        ),
        "mask_threshold_chosen_before_inference": True,
        "boundary_tolerance_original_pixels": args.boundary_tolerance,
        "prompt": "same GT-derived visible target box with fixed padding for both models",
        "box_padding_fraction": args.box_padding,
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": digest(args.checkpoint),
        "sam_revision": args.sam_revision,
        "metric_resolution": "original LEFT image resolution",
        "failed_attempt_scoring": (
            "failed attempts receive IoU=0 and BoundaryF1=0 in all-attempt means"
        ),
        "limitations": [
            "dataset-supplied visible silhouette reference, not independently re-annotated",
            "no depth, amodal truth or metric dimensions used",
            "excludes six known composite-source trees, not a registered blind test",
            "GT-derived box is an upper-bound prompt, not autonomous detection",
            "background/location similarity may remain; cannot claim full scene-disjointness",
        ],
        "records": records,
    }
    # Freeze the tree selection before loading a model or observing any score.
    (args.output / "selection.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    import torch
    import transformers
    from evaluate_real_multitree import cached_snapshot, overlay, write_mask
    from PIL import Image
    from sam2_occlusion import Sam2OcclusionModel
    from transformers import Sam2Model, Sam2Processor

    sam_path = cached_snapshot("facebook/sam2.1-hiera-tiny", args.sam_revision)
    processor = Sam2Processor.from_pretrained(sam_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    rows = []
    for index, record in enumerate(records):
        row = dict(record)
        row["models"] = {}
        image_path, mask_path = Path(record["image"]), Path(record["mask"])
        predictions = {}
        try:
            row["image_sha256"], row["mask_sha256"] = digest(image_path), digest(mask_path)
            image, mask_colour = cv2.imread(str(image_path)), cv2.imread(str(mask_path))
            if image is None or mask_colour is None or image.shape != mask_colour.shape:
                raise ValueError("paired image/mask decoding or shape mismatch")
            target = decode_reference(mask_colour, args.mask_threshold)
            alternate = decode_reference(mask_colour, 30)
            row["mask_pixels"] = int(target.sum())
            reference_directory = args.output / "decoded_references"
            reference_directory.mkdir(exist_ok=True)
            write_mask(reference_directory / f"{record['tree_id']}_visible_reference.png", target)
            row["mask_decode_sensitivity_iou_vs_threshold30"] = mask_iou(target, alternate)
            box = reference_box(target, args.box_padding)
            row["gt_derived_prompt_box"] = box
            height, width = target.shape
            scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
            box_tensor = torch.as_tensor(np.asarray(box, np.float32) * scale, device=args.device)[
                None, None
            ]
            inputs = processor(
                images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), return_tensors="pt"
            )
            pixels = inputs["pixel_values"].to(args.device)
            for name in ("stock_sam2", "current"):
                try:
                    with torch.inference_mode():
                        if name == "stock_sam2":
                            output = sam2(
                                pixel_values=pixels, input_boxes=box_tensor, multimask_output=False
                            )
                            logits = output.pred_masks
                        else:
                            output = model(pixels, input_boxes=box_tensor)
                            logits = output["masks"]
                        prediction = (
                            processor.post_process_masks(logits, original_sizes=[[height, width]])[
                                0
                            ][0, 0]
                            .cpu()
                            .numpy()
                            > 0
                        )
                    predictions[name] = prediction
                    empty = not bool(prediction.any())
                    row["models"][name] = {
                        "status": "empty_prediction" if empty else "ok",
                        "visible_iou": mask_iou(prediction, target),
                        "boundary_f1": boundary_f1(
                            prediction, target, tolerance=args.boundary_tolerance
                        ),
                        "prediction_pixels": int(prediction.sum()),
                    }
                except Exception as error:
                    row["models"][name] = {
                        "status": "failed",
                        "error": repr(error),
                        "visible_iou": 0.0,
                        "boundary_f1": 0.0,
                    }
                    if args.device.startswith("cuda"):
                        torch.cuda.empty_cache()
            if index < args.previews and len(predictions) == 2:
                folder = args.output / record["tree_id"]
                folder.mkdir()
                for name, prediction in predictions.items():
                    write_mask(folder / f"{name}_visible.png", prediction)
                panels = [
                    overlay(image, target[None], "Supplied filled visible silhouette reference"),
                    overlay(image, predictions["stock_sam2"][None], "Stock SAM2: same GT box"),
                    overlay(image, predictions["current"][None], "Current: same GT box"),
                ]
                cv2.imwrite(str(folder / "comparison.png"), np.concatenate(panels, axis=1))
        except Exception as error:
            row["data_failure"] = repr(error)
            for name in ("stock_sam2", "current"):
                row["models"][name] = {
                    "status": "data_failed",
                    "visible_iou": 0.0,
                    "boundary_f1": 0.0,
                }
        left, right = row["models"]["stock_sam2"], row["models"]["current"]
        row["paired_current_minus_stock_iou"] = right["visible_iou"] - left["visible_iou"]
        row["paired_current_minus_stock_boundary_f1"] = right["boundary_f1"] - left["boundary_f1"]
        rows.append(row)
        (args.output / "per_tree.json").write_text(
            json.dumps(rows, indent=2, allow_nan=False), encoding="utf-8"
        )
        print(
            json.dumps(
                {
                    "tree_id": record["tree_id"],
                    "stock_iou": left["visible_iou"],
                    "current_iou": right["visible_iou"],
                    "delta": row["paired_current_minus_stock_iou"],
                }
            ),
            flush=True,
        )
    summary = {
        "profile": protocol["profile"],
        "role": protocol["role"],
        "split": protocol["split"],
        "reference_semantics": protocol["reference_semantics"],
        "attempted_trees": len(records),
        "all_attempts_scored": len(rows),
        "models": {},
        "versions": {"torch": torch.__version__, "transformers": transformers.__version__},
        "paired_delta_mean_iou": float(
            np.mean([r["paired_current_minus_stock_iou"] for r in rows])
        ),
        "paired_delta_mean_boundary_f1": float(
            np.mean([r["paired_current_minus_stock_boundary_f1"] for r in rows])
        ),
        "current_iou_wins": sum(r["paired_current_minus_stock_iou"] > 1e-6 for r in rows),
        "current_iou_ties": sum(abs(r["paired_current_minus_stock_iou"]) <= 1e-6 for r in rows),
        "current_iou_losses": sum(r["paired_current_minus_stock_iou"] < -1e-6 for r in rows),
        "selection_sha256": digest(args.output / "selection.json"),
        "limitations": protocol["limitations"],
    }
    for name in ("stock_sam2", "current"):
        values = [row["models"][name] for row in rows]
        failed = sum(value["status"] != "ok" for value in values)
        summary["models"][name] = {
            "attempted": len(values),
            "failures": failed,
            "failure_rate": failed / len(values),
            "all_attempt_mean_visible_iou": float(np.mean([v["visible_iou"] for v in values])),
            "all_attempt_mean_boundary_f1": float(np.mean([v["boundary_f1"] for v in values])),
        }
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8"
    )
    (args.output / "README.md").write_text(
        "# TreeStereo visible-reference comparison\n\n"
        "Role: evaluation_only / reference_validation. The frozen 24-or-fewer FT IDs in "
        "selection.json must not be reused for future model fitting.\n\n"
        "Dataset masks are supplied filled visible silhouettes, not leaf-level alpha masks. "
        "Colour JPEG foreground is decoded with max(BGR)>127 by default; no hole filling, "
        "morphology, convex hull or model-assisted editing is applied. Black holes present "
        "in the files are retained. Decoded binary references are saved separately.\n\n"
        "Both models receive exactly the same GT-derived padded target box. This is "
        "prompted segmentation, not automatic detection, amodal completion, depth, or "
        "metric measurement. No human_verified label or new human annotation is claimed.\n\n"
        "All views of FT211, FT88, FT207, FT161, FT94 and FT149 are excluded because those "
        "trees supplied real cutouts for composite fine-tuning. Other historical dataset "
        "inspection and common locations remain possible: this is not a registered blind "
        "test or an independent urban multi-tree benchmark.\n\n"
        "Selection is frozen before inference. Every attempted tree is recorded in "
        "per_tree.json; model/data failures remain in denominators with zero scores. "
        "summary.json reports current-minus-stock paired differences without filtering "
        "unfavourable cases. Boundary F1 tolerance is in original image pixels.\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
