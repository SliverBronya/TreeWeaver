"""Build one clean stock-vs-current comparison image per 20260411 photo."""

from __future__ import annotations

import html
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(r"D:\TreeWeaver\reports\real-20260411-full-2026-11-01")
OUT = ROOT / "compare2"


def font(size: int):
    try:
        return ImageFont.truetype("C:/Windows/Fonts/arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = json.loads((ROOT / "summary.json").read_text(encoding="utf-8"))
    rows = [row for row in rows if row.get("status") == "ok"]
    rows.sort(key=lambda row: row["iou"])
    cards = []
    for row in rows:
        panel = ROOT / row["image"].replace(".jpg", ".png")
        image = Image.open(panel).convert("RGB")
        width, height = image.size
        half_w, half_h = width // 2, height // 2
        original = image.crop((0, 48, half_w, half_h))
        stock = image.crop((half_w, 48, width, half_h))
        current = image.crop((0, half_h + 48, half_w, height))
        canvas = Image.new("RGB", (half_w * 2, (half_h - 48) + 44), "white")
        canvas.paste(stock, (0, 44))
        canvas.paste(current, (half_w, 44))
        draw = ImageDraw.Draw(canvas)
        title_font = font(18)
        draw.text(
            (8, 8),
            f"{row['image']}   IoU {row['iou']:.3f}   area {row['area_ratio']:.2f}",
            fill="black",
            font=title_font,
        )
        draw.text((8, 44 - 22), "stock SAM2", fill="white", font=title_font)
        draw.text((half_w + 8, 44 - 22), "current model", fill="white", font=title_font)
        destination = OUT / panel.name
        canvas.save(destination, quality=92)
        cards.append(
            f"<div class='card'><a href='{destination.name}'><img src='{destination.name}'></a>"
            f"<div>{html.escape(row['image'])} · IoU {row['iou']:.3f} · area {row['area_ratio']:.2f}</div></div>"
        )
    document = (
        "<!doctype html><meta charset='utf-8'><title>20260411 2-panel</title>"
        "<style>body{font-family:sans-serif;background:#111;color:#eee}"
        ".grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}"
        ".card{background:#222;padding:6px;font-size:14px}.card img{width:100%;display:block}</style>"
        "<h1>20260411: stock SAM2 vs current, worst first</h1>"
        "<div class='grid'>" + "".join(cards) + "</div>"
    )
    (OUT / "gallery.html").write_text(document, encoding="utf-8")
    print("images", len(rows), "out", OUT)


if __name__ == "__main__":
    main()

