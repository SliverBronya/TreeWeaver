"""Best-effort free-asset sample: dense-ish foreground, layered 3D forest, Cycles."""

from __future__ import annotations

import math
import random
from pathlib import Path

import bpy
from mathutils import Vector

ASSET = Path(r"D:\TreeWeaver\tools\assets\tree_small_02\tree_small_02_1k.blend")
TARGET = "tree_small_02_LOD0"
BACKGROUND = "tree_small_02_LOD1"
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRI = "autumn_field_puresky_2k.hdr"
OUT = Path(r"D:\TreeWeaver\reports\blender-best-free\sample.png")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.25
    return scene


def append(name):
    bpy.ops.wm.append(directory=str(ASSET) + "/Object/", filename=name)
    return bpy.data.objects[name]


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    s = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(v * s for v in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def ground():
    bpy.ops.mesh.primitive_plane_add(size=300, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for n in list(nodes):
        nodes.remove(n)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (28, 28, 28)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)
    return obj


def rock_material():
    mat = bpy.data.materials.new("rock")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.16, 0.15, 0.13, 1)
    bsdf.inputs["Roughness"].default_value = 0.95
    return mat


def rocks(rng):
    mat = rock_material()
    for _ in range(10):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=rng.uniform(0.2, 0.7))
        obj = bpy.context.object
        obj.scale.z = rng.uniform(0.3, 0.7)
        obj.location = (rng.uniform(-14, 14), rng.uniform(2, 30), 0)
        obj.rotation_euler = (0, 0, rng.uniform(0, 6.28))
        obj.data.materials.append(mat)


def world(rng):
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / HDRI))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 6.28))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.05
    bpy.context.scene.world = w


def sun():
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 18))
    s = bpy.context.object
    s.data.energy = 2.6
    s.data.angle = math.radians(5)
    s.rotation_euler = (math.radians(52), 0, math.radians(35))


def camera(target, lens=35.0):
    bpy.ops.object.camera_add()
    cam = bpy.context.object
    cam.data.lens = lens
    cam.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    d = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    cam.location = (0.4, -d, 1.55)
    look = Vector((0, 0, TARGET_HEIGHT * 0.48))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.dof.use_dof = True
    cam.data.dof.focus_object = target
    cam.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = cam


def main():
    rng = random.Random(71)
    clean()
    target = append(TARGET)
    normalize(target, TARGET_HEIGHT)
    target.location = (0, 0, 0)
    target.rotation_euler = (0, 0, math.radians(18))

    # one mid-ground neighbour, slightly behind and to the right
    neighbour = duplicate(target)
    neighbour.scale = tuple(v * 0.92 for v in target.scale)
    neighbour.location = (4.2, 3.5, 0)
    neighbour.rotation_euler = (0, 0, math.radians(140))

    template = append(BACKGROUND)
    normalize(template, 10.0)
    for i in range(12):
        tree = duplicate(template)
        tree.scale = tuple(v * rng.uniform(0.7, 1.4) for v in template.scale)
        tree.location = (rng.uniform(-30, 30), rng.uniform(12, 45), 0)
        tree.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))
    bpy.data.objects.remove(template, do_unlink=True)

    ground()
    rocks(rng)
    world(rng)
    sun()
    camera(target, lens=35.0)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    bpy.context.scene.render.filepath = str(OUT)
    bpy.ops.render.render(write_still=True)
    print(f"saved {OUT}")


if __name__ == "__main__":
    main()
