import re
import requests

url = "https://openxlab.org.cn/datasets/OpenDataLab/CanaTree100"
response = requests.get(url, timeout=60)
print(response.status_code, len(response.text))
print(response.text[:3000])
print("LINKS")
for link in re.findall(r"https?://[^\"<> ]+", response.text)[:50]:
    print(link)
