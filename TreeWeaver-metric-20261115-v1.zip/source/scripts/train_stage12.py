"""Professional stage 1/2 training on the 500-image fig dataset.

Stage 1: visible masks only (decoder fine-tune).
Stage 2: joint visible masks + pixel ownership.

Scene split: first 350 train, next 75 val, last 75 test.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from curve_consistency import band_rows, curve_profile_loss  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports" / "fig-500-v2-2026-10-31"
DEFAULT_CKPT = ROOT / "reports" / "composite-occlusion-500step-2026-10-26" / "decoder_best.pth"
RES = 1024
MASK = 256


def snapshot() -> Path:
    base = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "hub"
        / "models--facebook--sam2.1-hiera-tiny"
        / "snapshots"
    )
    return sorted(path for path in base.iterdir() if path.is_dir())[-1]


def load_rgb(path: Path, mean, std):
    image = Image.open(path).convert("RGB").resize((RES, RES), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.asarray(mean)) / np.asarray(std)
    return torch.from_numpy(array).permute(2, 0, 1)


def load_alpha(path: Path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def resize_bool(mask: np.ndarray):
    tensor = torch.from_numpy(mask.astype(np.float32))[None, None]
    return F.interpolate(tensor, size=(MASK, MASK), mode="nearest")[0, 0] > 0.5


class FigDataset(Dataset):
    def __init__(self, ids, mean, std):
        self.ids = ids
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, index):
        image_id = self.ids[index]
        scene = f"{image_id:06d}"
        meta = json.loads((DATA / "meta" / f"{scene}.json").read_text(encoding="utf-8"))
        mask_dir = DATA / "masks" / scene
        amodal = [load_alpha(p) for p in sorted(mask_dir.glob("amodal_*.png"))]
        visible = [load_alpha(p) for p in sorted(mask_dir.glob("visible_*.png"))]
        count = len(amodal)
        boxes = []
        for mask in amodal:
            ys, xs = np.where(mask)
            boxes.append([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1])
        boxes = torch.tensor(boxes, dtype=torch.float32)
        boxes[:, [0, 2]] *= RES / 640.0
        boxes[:, [1, 3]] *= RES / 360.0

        targets = torch.stack([resize_bool(mask) for mask in visible])
        amodal_targets = torch.stack([resize_bool(mask) for mask in amodal])
        rows = band_rows(MASK, 12)
        curves = []
        for mask in amodal_targets:
            width = torch.stack([mask[row].float().mean() for row in rows])
            curves.append(width / width.max().clamp_min(1e-6))
        curves = torch.stack(curves)
        ownership = torch.zeros((MASK, MASK), dtype=torch.long)
        for i, mask in enumerate(targets):
            ownership[mask] = i + 1

        names = meta["trees"]
        order = [names.index(name) for name in meta["layer_order_front_to_back"]]
        rank = {tree_index: rank_index for rank_index, tree_index in enumerate(order)}
        layer = torch.zeros((count, count), dtype=torch.float32)
        for i in range(count):
            for j in range(count):
                layer[i, j] = 1.0 if rank[i] < rank[j] else 0.0

        image = load_rgb(DATA / "images" / f"{scene}.png", self.mean, self.std)
        return {
            "image": image,
            "boxes": boxes,
            "visible": targets,
            "amodal": amodal_targets,
            "curve": curves,
            "curve_observed": torch.ones_like(curves),
            "ownership": ownership,
            "layer": layer,
            "id": image_id,
            "count": count,
        }


def build_model(device, checkpoint):
    path = snapshot()
    processor = Sam2Processor.from_pretrained(path, local_files_only=True)
    mean = processor.image_processor.image_mean
    std = processor.image_processor.image_std
    sam2 = Sam2Model.from_pretrained(path, local_files_only=True).to(device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(device)
    payload = torch.load(checkpoint, map_location="cpu")
    state = payload["decoder"] if "decoder" in payload else payload
    missing, unexpected = model.decoder.load_state_dict(state, strict=False)
    print(json.dumps({"missing": len(missing), "unexpected": len(unexpected)}), flush=True)
    return model, mean, std


def configure(model, stage):
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    if stage == "visible":
        for parameter in model.decoder.parameters():
            parameter.requires_grad_(True)
    elif stage == "ownership":
        prefixes = (
            "ownership_projection",
            "ownership_conv",
            "ownership_bg",
            "mask_tokens",
            "output_hypernetworks_mlps",
            "upscale_",
            "transformer",
            "iou_prediction_head",
            "pred_obj_score_head",
        )
        for name, parameter in model.decoder.named_parameters():
            if name.startswith(prefixes):
                parameter.requires_grad_(True)
    elif stage == "coupling":
        prefixes = (
            "ownership_projection",
            "ownership_conv",
            "ownership_bg",
            "mask_tokens",
            "output_hypernetworks_mlps",
            "upscale_",
            "transformer",
            "iou_prediction_head",
            "pred_obj_score_head",
        )
        for name, parameter in model.decoder.named_parameters():
            if name.startswith(prefixes):
                parameter.requires_grad_(True)
    elif stage == "layer":
        for name, parameter in model.decoder.named_parameters():
            if name.startswith(("layer_head", "layer_evidence")):
                parameter.requires_grad_(True)
        for module in (model.decoder.layer_head, model.decoder.layer_evidence):
            for layer in module:
                if isinstance(layer, torch.nn.Linear):
                    torch.nn.init.xavier_uniform_(layer.weight)
                    torch.nn.init.zeros_(layer.bias)
    elif stage == "layer_evidence":
        for parameter in model.decoder.layer_head.parameters():
            parameter.data.zero_()
            parameter.requires_grad_(False)
        for name, parameter in model.decoder.named_parameters():
            if name.startswith("layer_evidence"):
                parameter.requires_grad_(True)
    elif stage == "amodal":
        for name, parameter in model.decoder.named_parameters():
            if name.startswith(("amodal_hypernets", "amodal_scale", "amodal_token")):
                parameter.requires_grad_(True)
    elif stage == "curve":
        for name, parameter in model.decoder.named_parameters():
            if name.startswith(
                (
                    "curve_head",
                    "mask_tokens",
                    "output_hypernetworks_mlps",
                    "upscale_",
                    "transformer",
                )
            ):
                parameter.requires_grad_(True)
    else:
        raise ValueError(stage)
    return [p for p in model.parameters() if p.requires_grad]


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum()
    return 1.0 - (2.0 * intersection + 1.0) / (probability.sum() + target.sum() + 1.0)


def visible_loss(masks, target):
    masks = masks[:, :, 0]
    target = target.to(masks.dtype)
    bce = F.binary_cross_entropy_with_logits(masks, target)
    dice = dice_loss(masks, target)
    return bce + dice


def ownership_loss(output, target):
    logits = output["ownership_logits"]
    weight = torch.tensor([0.2, 1.0, 1.0, 1.0, 1.0], device=logits.device)[: logits.shape[1]]
    ce = F.cross_entropy(logits, target, weight=weight)
    probability = output["ownership"].softmax(dim=1)[:, 1:]
    exclusion = (probability.sum(dim=1) - 1.0).clamp(min=0).mean()
    return ce, exclusion


def mask_coupling_loss(output):
    masks = output["masks"][:, :, 0].sigmoid()
    count = masks.shape[1]
    pair = masks.new_zeros(())
    for i in range(count):
        for j in range(i + 1, count):
            pair = pair + (masks[:, i] * masks[:, j]).mean()
    ownership = output["ownership"].softmax(dim=1)[:, 1:]
    consistency = F.mse_loss(masks, ownership)
    return pair, consistency


def layer_loss(logits, target):
    count = logits.shape[1]
    mask = ~torch.eye(count, dtype=torch.bool, device=logits.device)
    mask = mask.unsqueeze(0).expand_as(logits)
    return F.binary_cross_entropy_with_logits(logits[mask], target[mask])


def amodal_stage_loss(output, batch, device):
    from occlusion_aware import amodal_bce

    logits = output["amodal_masks"][:, :, 0]
    target = batch["amodal"].to(device).to(logits.dtype)
    visible = batch["visible"].to(device).to(logits.dtype)
    layer = batch["layer"][0]
    back = layer.sum(dim=1) > 0
    if not bool(back.any()):
        return logits.sum() * 0.0
    return amodal_bce(
        logits[:, back],
        target[:, back],
        visible[:, back],
        occluded_weight=3.0,
    )


def metrics(
    masks,
    visible,
    ownership_pred,
    ownership_target,
    layer_logits=None,
    layer_target=None,
    amodal_pred=None,
    amodal_target=None,
    back=None,
    curve_pred=None,
    curve_target=None,
):
    predicted = masks.sigmoid() > 0.5
    ious = []
    for i in range(predicted.shape[0]):
        target = visible[i]
        intersection = (predicted[i] & target).sum().item()
        union = (predicted[i] | target).sum().item()
        if union:
            ious.append(intersection / union)
    foreground = ownership_target > 0
    accuracy = (
        (ownership_pred[foreground] == ownership_target[foreground]).float().mean().item()
        if foreground.any()
        else 0.0
    )
    layer_accuracy = 0.0
    if layer_logits is not None and layer_target is not None:
        count = layer_logits.shape[0]
        mask = ~torch.eye(count, dtype=torch.bool)
        layer_accuracy = (
            ((layer_logits > 0) == layer_target.bool())[mask].float().mean().item()
        )
    amodal_iou = 0.0
    if amodal_pred is not None and amodal_target is not None and back is not None:
        amodal_binary = amodal_pred.sigmoid() > 0.5
        values = []
        for i in range(amodal_binary.shape[0]):
            if not bool(back[i]):
                continue
            intersection = (amodal_binary[i] & amodal_target[i]).sum().item()
            union = (amodal_binary[i] | amodal_target[i]).sum().item()
            if union:
                values.append(intersection / union)
        amodal_iou = float(np.mean(values)) if values else 0.0
    merges = 0
    misses = 0
    curve_mae = 0.0
    if curve_pred is not None and curve_target is not None:
        curve_mae = float((curve_pred - curve_target).abs().mean())
    for i in range(predicted.shape[0]):
        area = predicted[i].sum().item()
        if area == 0:
            misses += 1
            continue
        for j in range(visible.shape[0]):
            if i == j:
                continue
            overlap = (predicted[i] & visible[j]).sum().item()
            if overlap > 0.25 * area:
                merges += 1
        if (predicted[i] & visible[i]).sum().item() < 0.3 * visible[i].sum().item():
            misses += 1
    return {
        "visible_iou": float(np.mean(ious)) if ious else 0.0,
        "ownership_accuracy": accuracy,
        "layer_accuracy": layer_accuracy,
        "amodal_iou": amodal_iou,
        "curve_mae": curve_mae,
        "merges": merges,
        "misses": misses,
    }


def evaluate(model, loader, device, limit):
    model.eval()
    records = []
    with torch.no_grad():
        for index, batch in enumerate(loader):
            if index >= limit:
                break
            output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
            predicted = output["masks"][0, :, 0]
            ownership_pred = output["ownership"].argmax(dim=1)[0]
            records.append(
                metrics(
                    predicted.cpu(),
                    batch["visible"][0],
                    ownership_pred.cpu(),
                    batch["ownership"][0],
                    output["layer_logits"][0].cpu(),
                    batch["layer"][0],
                    output["amodal_masks"][0, :, 0].cpu(),
                    batch["amodal"][0],
                    batch["layer"][0].sum(dim=1) > 0,
                    output["curve"][0].cpu(),
                    batch["curve"][0],
                )
            )
    return {key: float(np.mean([r[key] for r in records])) for key in records[0]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stage",
        choices=("visible", "ownership", "coupling", "layer", "layer_evidence", "amodal", "curve"),
        required=True,
    )
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CKPT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--eval-limit", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"output exists: {args.output}")
    args.output.mkdir(parents=True)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    model, mean, std = build_model(device, args.checkpoint)
    ids = sorted(int(p.stem) for p in (DATA / "meta").glob("*.json"))
    train_ids = ids[:350]
    val_ids = ids[350:425]
    test_ids = ids[425:]
    train_loader = DataLoader(FigDataset(train_ids, mean, std), batch_size=1, shuffle=True)
    val_loader = DataLoader(FigDataset(val_ids, mean, std), batch_size=1)
    parameters = configure(model, args.stage)
    print(
        json.dumps(
            {
                "stage": args.stage,
                "trainable": sum(p.numel() for p in parameters),
                "train": len(train_ids),
                "val": len(val_ids),
                "test": len(test_ids),
            }
        ),
        flush=True,
    )
    optimizer = torch.optim.AdamW(parameters, lr=args.lr, weight_decay=1e-4)
    warmup = min(50, args.steps // 10)

    def schedule(step):
        if step < warmup:
            return (step + 1) / warmup
        progress = (step - warmup) / max(1, args.steps - warmup)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
    iterator = iter(train_loader)
    history = []
    best = -1.0
    model.train()
    for step in range(1, args.steps + 1):
        optimizer.zero_grad(set_to_none=True)
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(train_loader)
            batch = next(iterator)
        output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
        if args.stage in ("layer", "layer_evidence"):
            loss = layer_loss(output["layer_logits"], batch["layer"].to(device))
        elif args.stage == "amodal":
            loss = amodal_stage_loss(output, batch, device)
        elif args.stage == "curve":
            curve_target = batch["curve"].to(device)
            observed = batch["curve_observed"].to(device)
            loss = visible_loss(output["masks"], batch["visible"].to(device))
            loss = loss + 0.1 * F.mse_loss(output["curve"], curve_target)
            loss = loss + 0.1 * curve_profile_loss(
                output["masks"],
                output["curve"],
                observed,
                output["curve_log_sigma"],
                reference_mask=batch["visible"].to(device),
            )
        else:
            loss = visible_loss(output["masks"], batch["visible"].to(device))
            if args.stage in ("ownership", "coupling"):
                ce, exclusion = ownership_loss(output, batch["ownership"].to(device))
                loss = loss + ce + 0.1 * exclusion
            if args.stage == "coupling":
                pair, consistency = mask_coupling_loss(output)
                loss = loss + 0.5 * pair + 0.5 * consistency
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        scheduler.step()
        if step % 20 == 0 or step == 1:
            print(
                json.dumps(
                    {
                        "step": step,
                        "loss": float(loss.detach()),
                        "lr": scheduler.get_last_lr()[0],
                    }
                ),
                flush=True,
            )
        if step % args.eval_every == 0 or step == args.steps:
            result = evaluate(model, val_loader, device, args.eval_limit)
            print(json.dumps({"eval_step": step, **result}), flush=True)
            history.append({"eval_step": step, **result})
            score = (
                result["ownership_accuracy"]
                if args.stage == "ownership"
                else result["layer_accuracy"]
                if args.stage in ("layer", "layer_evidence")
                else result["amodal_iou"]
                if args.stage == "amodal"
                else result["visible_iou"]
            )
            if score > best:
                best = score
                torch.save(
                    {
                        "decoder": model.decoder.state_dict(),
                        "stage": args.stage,
                        "step": step,
                        "metrics": result,
                    },
                    args.output / "best.pth",
                )
    config = {
        "stage": args.stage,
        "steps": args.steps,
        "lr": args.lr,
        "seed": args.seed,
        "train": len(train_ids),
        "val": len(val_ids),
        "test": len(test_ids),
        "trainable": sum(p.numel() for p in parameters),
        "best": best,
    }
    (args.output / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(json.dumps({"best": best, "output": str(args.output)}), flush=True)


if __name__ == "__main__":
    main()
