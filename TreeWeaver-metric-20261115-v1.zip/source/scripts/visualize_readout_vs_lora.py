"""Visual comparison: readout vs LoRA on frozen validation targets."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
READOUT = ROOT / "reports/frozen-visible-readout-300-viz-2026-11-09/checkpoint.pth"
LORA = ROOT / "reports/frozen-visible-lora-300-seed20261110-2026-11-09/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/frozen-visible-visual-compare-2026-11-09"
SIZE = 640


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask_native(path):
    image = np.asarray(Image.open(path).convert("RGBA"))
    return image[..., 3] > 16


def boxes(row):
    x0, y0, x1, y1 = row["box_xyxy"]
    width, height = row["mask_wh"]
    return torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model.cuda().eval()


def infer(model, row):
    output = model(
        image_tensor(row["paths"]["image"]).cuda(),
        input_boxes=boxes(row).cuda(),
    )
    return output["masks"][0, 0, 0].sigmoid().cpu().numpy()


def overlay(rgb, mask, color, alpha=0.45):
    image = rgb.copy()
    layer = np.zeros_like(image)
    layer[mask] = color
    image[mask] = (image[mask] * (1 - alpha) + layer[mask] * alpha).astype(np.uint8)
    return image


def error_map(rgb, target, pred):
    image = (rgb * 0.45).astype(np.uint8)
    tp = target & pred
    fp = pred & ~target
    fn = target & ~pred
    image[tp] = [40, 220, 80]
    image[fp] = [240, 50, 50]
    image[fn] = [50, 110, 255]
    return image


def select(rows):
    clear = [r for r in rows if r["relation"] == "clear"][:2]
    contact = [r for r in rows if r["relation"] == "contact"][:2]
    overlap = sorted([r for r in rows if r["relation"] == "overlap"], key=lambda r: r["hidden_fraction"])
    return clear + contact + overlap[:2] + overlap[-2:]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    rows = select(index["validation"]["records"])
    model = build()
    readout = torch.load(READOUT, map_location="cpu", weights_only=True)["state"]
    lora = torch.load(LORA, map_location="cpu", weights_only=True)["lora"]
    model.load_state_dict(readout, strict=False)
    readout_preds = [infer(model, row) > 0.5 for row in rows]
    model.load_state_dict(lora, strict=False)
    lora_preds = [infer(model, row) > 0.5 for row in rows]

    panels = []
    metrics = []
    per_image = OUT / "per-image"
    per_image.mkdir(exist_ok=True)
    for index, (row, readout_mask, lora_mask) in enumerate(
        zip(rows, readout_preds, lora_preds, strict=True), start=1
    ):
        native = mask_native(row["paths"]["visible"])
        target = np.asarray(
            Image.fromarray(native.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)
        ) > 127
        rgb = np.asarray(
            Image.open(row["paths"]["image"]).convert("RGB").resize((SIZE, SIZE), Image.BILINEAR)
        )
        readout_mask = np.asarray(
            Image.fromarray(readout_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)
        ) > 127
        lora_mask = np.asarray(
            Image.fromarray(lora_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)
        ) > 127
        def iou(pred):
            inter = (pred & target).sum()
            union = (pred | target).sum()
            return float(inter / union) if union else 1.0
        metrics.append({"scene": row["scene"], "relation": row["relation"], "hidden": row["hidden_fraction"], "readout_iou": iou(readout_mask), "lora_iou": iou(lora_mask)})
        tile = Image.new("RGB", (SIZE * 5, SIZE + 34), "white")
        labels = ["RGB", "GT visible", "readout", "LoRA", "error: TP green / FP red / FN blue"]
        images = [
            rgb,
            overlay(rgb, target, [0, 220, 120], 0.5),
            overlay(rgb, readout_mask, [0, 140, 255], 0.5),
            overlay(rgb, lora_mask, [255, 120, 0], 0.5),
            error_map(rgb, target, lora_mask),
        ]
        draw = ImageDraw.Draw(tile)
        for i, (label, image) in enumerate(zip(labels, images, strict=True)):
            tile.paste(Image.fromarray(image), (i * SIZE, 34))
            draw.text((i * SIZE + 8, 10), label, fill="black")
        draw.text((8, SIZE + 34 - 24), f"{row['scene']}  {row['relation']}  hidden={row['hidden_fraction']:.3f}  readout={iou(readout_mask):.3f}  lora={iou(lora_mask):.3f}", fill="black")
        panels.append(tile)
        tile.save(per_image / f"{index:02d}_{row['scene']}.jpg", quality=95)
    sheet = Image.new("RGB", (SIZE * 5, (SIZE + 34) * len(panels)), "white")
    for i, panel in enumerate(panels):
        sheet.paste(panel, (0, i * (SIZE + 34)))
    sheet.save(OUT / "readout-vs-lora-sheet.jpg", quality=92)
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()

