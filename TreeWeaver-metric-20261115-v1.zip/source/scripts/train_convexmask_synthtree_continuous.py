"""Resumable SynthTree43k baseline, separate from all SPREAD experiments."""

import argparse
import copy
import ctypes
import hashlib
import json
import os
import random
import shutil
import sys
import time
from datetime import UTC, datetime
from pathlib import Path


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(path)


def utc_now():
    return datetime.now(UTC).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--backbone", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--label-root",
        type=Path,
        default=None,
        help="Directory holding the annotation JSONs; defaults to <data-root>/annotations",
    )
    parser.add_argument(
        "--label-template",
        default="{split}_RGB_entire_tree.json",
        help="Annotation file name pattern; {split} is replaced by train/val",
    )
    parser.add_argument("--epochs", type=int, default=29)
    parser.add_argument(
        "--recipe",
        choices=("author", "legacy"),
        default="author",
        help=(
            "author: ConvexMask's own convex_synthtree_focal settings - 1280x720, SGD "
            "momentum 0.9 lr 1e-2 with 2000-iteration warmup and x0.1 drops at epochs "
            "27 and 33, trainable BN, effective batch 8 via gradient accumulation. "
            "legacy: the earlier AdamW 1e-4 / 512x288 / frozen-BN / batch-1 run."
        ),
    )
    parser.add_argument("--micro-batch", type=int, default=0, help="0 = recipe default")
    parser.add_argument("--accum-steps", type=int, default=0, help="0 = recipe default")
    parser.add_argument("--amp", dest="amp", action="store_true", default=True)
    parser.add_argument("--no-amp", dest="amp", action="store_false")
    parser.add_argument(
        "--eval-size",
        default="",
        help=(
            "W,H used only while validating. The detection/NMS step builds a "
            "proposal-by-proposal IoU matrix that is quadratic in the number of "
            "proposals and does not fit an 8 GB card at 1280x720. Training size is "
            "unaffected; report the reduced-resolution caveat with any AP number."
        ),
    )
    parser.add_argument(
        "--loader-threads",
        type=int,
        default=2,
        help="Background threads prefetching samples so image loading overlaps the GPU",
    )
    parser.add_argument(
        "--loader-timeout",
        type=float,
        default=300.0,
        help="Abort if the prefetcher produces nothing for this many seconds",
    )
    parser.add_argument(
        "--full-validate-every",
        type=int,
        default=5,
        help="Run the 1000-image full validation every N epochs (1 = every epoch)",
    )
    parser.add_argument("--checkpoint-every", type=int, default=500)
    parser.add_argument("--validate-every", type=int, default=5000)
    parser.add_argument(
        "--max-steps", type=int, default=0, help="Smoke testing only; 0 means full run"
    )
    parser.add_argument(
        "--stop-after-epoch",
        type=int,
        default=0,
        help=(
            "Stop cleanly once this many epochs are complete (0 = never). Checked "
            "only at epoch boundaries, so the epoch in progress always finishes and "
            "its validation is recorded."
        ),
    )
    args = parser.parse_args()
    if not 1 <= args.epochs <= 29 or args.checkpoint_every < 1 or args.validate_every < 1:
        parser.error("Invalid bounded baseline configuration")
    # Recipe defaults: the author trained a true batch of 8, so the author recipe
    # accumulates to an effective 8 with micro-batch 2; the legacy run was batch 1.
    if args.micro_batch <= 0:
        args.micro_batch = 2 if args.recipe == "author" else 1
    if args.accum_steps <= 0:
        args.accum_steps = 4 if args.recipe == "author" else 1
    if args.micro_batch * args.accum_steps != (
        8 if args.recipe == "author" else 1
    ):
        print(
            "note: effective batch is %d (author used 8)"
            % (args.micro_batch * args.accum_steps),
            flush=True,
        )
    args.output.mkdir(parents=True, exist_ok=True)
    # A stop request is a runtime signal, not persistent state. Remove any stale
    # one so a resumed run is not immediately stopped by it.
    stale_stop = args.output / "STOP_REQUESTED"
    if stale_stop.exists():
        stale_stop.unlink()
        print("removed stale STOP_REQUESTED from a previous run", flush=True)
    import msvcrt

    lock_file = (args.output / "worker.lock").open("a+b")
    lock_file.seek(0)
    if not lock_file.read(1):
        lock_file.write(b"0")
        lock_file.flush()
    lock_file.seek(0)
    msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from pycocotools import mask as mask_utils
    from pycocotools.cocoeval import COCOeval

    from data import cfg, set_cfg

    seed = 42
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    if args.recipe == "author":
        # Exactly data/config.py :: convex_synthtree_focal (the paper's own setup).
        cfg.max_size = (1280, 720)
        cfg.fixed_size = True
        cfg.freeze_bn = False
        cfg.freeze_backbone = False
    else:
        cfg.max_size = (512, 288)
        cfg.fixed_size = True
        cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    cfg.dataset.label_map = {0: 1}
    from convexmask import ConvexMask
    from data.coco import COCODetection
    from layers.modules.multibox_loss import MultiBoxLoss
    from layers.output_utils import postprocess
    from utils.augmentations import BaseTransform, FastBaseTransform, SSDAugmentation

    write_json(
        args.output / "status.json", {"state": "loading", "updated": utc_now(), "pid": os.getpid()}
    )
    rgb_root = args.data_root.resolve() / "test_set"
    label_root = (
        args.label_root.resolve() if args.label_root is not None
        else args.data_root.resolve() / "annotations"
    )
    datasets, source_hashes, split_names = {}, {}, {}
    for split in ("train", "val"):
        path = label_root / args.label_template.format(split=split)
        source_hashes[split] = hashlib.sha256(path.read_bytes()).hexdigest()
        transform = SSDAugmentation() if split == "train" else BaseTransform(resize_gt=True)
        dataset = COCODetection(str(rgb_root), str(path), transform=transform)
        datasets[split] = dataset
        names = {i["file_name"] for i in dataset.coco.imgs.values()}
        missing = [name for name in names if not (rgb_root / name).is_file()]
        if missing:
            raise FileNotFoundError(f"{split}: missing {len(missing)} RGB files")
        split_names[split] = names
    if split_names["train"] & split_names["val"]:
        raise ValueError("Training and validation filenames overlap")
    config = {
        "dataset": f"SynthTree43k labels: {args.label_template}",
        "label_root": str(label_root),
        "annotations_sha256": source_hashes,
        "backbone_sha256": hashlib.sha256(args.backbone.read_bytes()).hexdigest(),
        "rgb_root": str(rgb_root),
        "epochs": args.epochs,
        "seed": seed,
        "architecture": "ConvexMask ResNet50, 72 rays",
        "recipe": args.recipe,
        "size": list(cfg.max_size),
        "micro_batch": args.micro_batch,
        "accum_steps": args.accum_steps,
        "effective_batch_size": args.micro_batch * args.accum_steps,
        "amp": "bfloat16 autocast" if args.amp else "off (fp32)",
        "loader_threads": args.loader_threads,
        "eval_size": args.eval_size or list(cfg.max_size),
        "full_validate_every": args.full_validate_every,
        "freeze_bn": bool(cfg.freeze_bn),
        "optimizer": "SGD momentum 0.9" if args.recipe == "author" else "AdamW",
        "initial_lr": 1e-2 if args.recipe == "author" else 1e-4,
        "lr_warmup_iters": 2000 if args.recipe == "author" else 0,
        "lr_warmup_init": 1e-4 if args.recipe == "author" else None,
        "lr_drop_epochs": [27, 33] if args.recipe == "author" else [27],
        "lr_gamma": 0.1,
        "weight_decay": 1e-4,
        "augmentation": (
            "upstream SSDAugmentation, horizontal mirror; other configured flags disabled"
        ),
        "spread_weights_loaded": False,
        "test_set_used": False,
        "initialization": "ImageNet backbone only; no five-minute or SPREAD checkpoint",
        "paper_exact_reproduction": False,
        "deviations": (
            [f"effective batch {args.micro_batch} x {args.accum_steps} instead of 8 single-pass",
             "gradient accumulation instead of true batch 8",
             "bfloat16 autocast for speed/VRAM" if args.amp else "fp32 (matches author)"]
            if args.recipe == "author"
            else ["512x288", "batch 1", "AdamW 1e-4", "frozen BN"]
        ),
        "safety": "29 epoch cap, finite gradients, periodic full-state checkpoint, no test tuning",
    }
    config_path = args.output / "config.json"
    if config_path.exists():
        saved = json.loads(config_path.read_text())
        # Resume the Oct. 15 legacy run using its original metadata schema. The
        # author-recipe CLI was added later; preserving the saved config hash is
        # necessary to restore its optimizer/RNG state without weakening checks.
        if args.recipe == "legacy" and "batch_size" in saved:
            config = {
                "dataset": "SynthTree43k original whole-tree labels",
                "annotations_sha256": source_hashes,
                "backbone_sha256": hashlib.sha256(args.backbone.read_bytes()).hexdigest(),
                "rgb_root": str(rgb_root),
                "epochs": args.epochs,
                "seed": seed,
                "architecture": "ConvexMask ResNet50, 72 rays",
                "size": [512, 288],
                "batch_size": 1,
                "optimizer": "AdamW",
                "initial_lr": 1e-4,
                "weight_decay": 1e-4,
                "lr_drop_epoch": 27,
                "augmentation": "upstream SSDAugmentation, horizontal mirror; other configured flags disabled",
                "spread_weights_loaded": False,
                "test_set_used": False,
                "initialization": "ImageNet backbone only; no five-minute or SPREAD checkpoint",
                "paper_exact_reproduction": False,
                "deviations": ["512x288", "batch 1", "AdamW 1e-4", "frozen BN"],
                "safety": "29 epoch cap, finite gradients, periodic full-state checkpoint, no test tuning",
            }
        if saved != config:
            differences = {
                key: {"saved": saved.get(key), "now": config.get(key)}
                for key in sorted(set(saved) | set(config))
                if saved.get(key) != config.get(key)
            }
            raise ValueError(
                "Refusing resume with different dataset/configuration: "
                + json.dumps(differences, ensure_ascii=False)
            )
    else:
        write_json(config_path, config)
    config_sha = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    model = ConvexMask().cuda()
    model.train()
    if args.recipe == "author":
        optimizer = torch.optim.SGD(
            model.parameters(), lr=1e-2, momentum=0.9, weight_decay=1e-4
        )
    else:
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    latest = args.output / "latest.pth"
    epoch, position, step, best_ap = 0, 0, 0, -1.0
    train_seconds = 0.0
    restore_path = latest if latest.exists() else args.output / "previous.pth"
    if restore_path.exists():
        try:
            state = torch.load(restore_path, map_location="cpu", weights_only=True)
        except (OSError, RuntimeError, EOFError):
            backup = args.output / "previous.pth"
            if restore_path == backup or not backup.exists():
                raise
            state = torch.load(backup, map_location="cpu", weights_only=True)
            print("Restoring previous checkpoint after latest checkpoint read error", flush=True)
        if state["config_sha256"] != config_sha:
            raise ValueError("Checkpoint configuration mismatch")
        model.load_state_dict(state["model"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        epoch, position, step = state["epoch"], state["position"], state["step"]
        best_ap, train_seconds = state["best_ap"], state["train_seconds"]
        random.setstate(state["python_rng"])
        torch.set_rng_state(state["torch_rng"])
        torch.cuda.set_rng_state_all(state["cuda_rng"])
        # Numpy RNG is stored as primitive metadata plus tensor for safe loading.
        np_rng = state["numpy_rng"]
        np.random.set_state(
            (np_rng[0], np_rng[1].numpy().astype(np.uint32), np_rng[2], np_rng[3], np_rng[4])
        )
        del state
        print(f"Resumed step={step}, epoch={epoch}, position={position}", flush=True)
    else:
        backbone = torch.load(args.backbone, weights_only=True, map_location="cpu")
        remapped = {}
        for key, value in backbone.items():
            if key.startswith("fc."):
                continue
            if key.startswith("layer"):
                key = "layers." + str(int(key[5]) - 1) + key[6:]
            remapped[key] = value
        model.backbone.load_state_dict(remapped, strict=True)
        del backbone, remapped
    criterion = MultiBoxLoss(2, cfg.num_rays, cfg.ohem_negpos_ratio)
    train, validation = datasets["train"], datasets["val"]
    fast_transform = FastBaseTransform()
    last_losses = []
    failures = 0
    micro_since_step = 0
    eval_size = None
    if args.eval_size:
        _ew, _eh = (int(x) for x in args.eval_size.split(","))
        eval_size = (_ew, _eh)

    def checkpoint():
        if shutil.disk_usage(args.output).free < 3_000_000_000:
            raise OSError("Not enough disk space to safely checkpoint")
        np_rng = np.random.get_state()
        state = {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "position": position,
            "step": step,
            "best_ap": best_ap,
            "train_seconds": train_seconds,
            "config_sha256": config_sha,
            "python_rng": random.getstate(),
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state_all(),
            "numpy_rng": (
                np_rng[0],
                torch.from_numpy(np_rng[1].astype(np.int64)),
                np_rng[2],
                np_rng[3],
                np_rng[4],
            ),
        }
        temporary = args.output / "checkpoint.tmp.pth"
        torch.save(state, temporary)
        if latest.exists():
            latest.replace(args.output / "previous.pth")
        temporary.replace(latest)

    def status(state="training", **extra):
        write_json(
            args.output / "status.json",
            {
                "state": state,
                "updated": utc_now(),
                "pid": os.getpid(),
                "step": step,
                "completed_epochs": epoch,
                "position_in_epoch": position,
                "training_images_per_epoch": len(train),
                "target_epochs": args.epochs,
                "train_seconds": train_seconds,
                "best_validation_subset_ap": best_ap,
                "recent_mean_loss": sum(last_losses) / len(last_losses) if last_losses else None,
                "checkpoint": str(latest.resolve()),
                **extra,
            },
        )

    def evaluate(full=False):
        nonlocal best_ap
        status("validating", full_validation=full)
        # At 1280x720 the detection/NMS path builds a proposal-by-proposal IoU
        # matrix whose size grows with the square of the proposal count. Reclaim
        # the training allocator's reserved-but-unused blocks first.
        torch.cuda.empty_cache()
        train_size = cfg.max_size
        if eval_size is not None:
            cfg.max_size = eval_size
        identifiers = sorted(validation.coco.imgs)
        if not full:
            random.Random(1729).shuffle(identifiers)
            identifiers = identifiers[:100]
        predictions = []
        model.train()  # Raw-output interface, no gradients and frozen BN.
        with torch.inference_mode():
            for image_id in identifiers:
                info = validation.coco.imgs[image_id]
                original = cv2.imread(str(rgb_root / info["file_name"]))
                if original is None:
                    raise ValueError(f"Unreadable validation image {image_id}")
                h, w = original.shape[:2]
                # Detection/NMS builds a proposal-by-proposal IoU matrix that is
                # quadratic in the number of proposals; at the author's 1280x720
                # that does not fit an 8 GB card in fp32. Running the forward and
                # the detector under bf16 autocast halves that allocation.
                with torch.autocast("cuda", dtype=torch.bfloat16, enabled=args.amp):
                    raw = model(fast_transform(torch.as_tensor(original).float()[None]))
                    raw["conf"], raw["center"] = raw["conf"].sigmoid(), raw["center"].sigmoid()
                    detected = postprocess(model.detect(raw, model), w, h, score_threshold=0.05)
                for instance in range(detected[0].numel()):
                    mask = detected[4][instance].bool().cpu().numpy()
                    encoded = mask_utils.encode(np.asfortranarray(mask.astype(np.uint8)))
                    encoded["counts"] = encoded["counts"].decode("ascii")
                    predictions.append(
                        {
                            "image_id": image_id,
                            "category_id": 0,
                            "score": float(detected[1][instance]),
                            "segmentation": encoded,
                        }
                    )
        stats = [0.0] * 12
        if predictions:
            validation.coco.dataset.setdefault("info", {})
            result = validation.coco.loadRes(copy.deepcopy(predictions))
            evaluation = COCOeval(validation.coco, result, "segm")
            evaluation.params.imgIds = identifiers
            evaluation.evaluate()
            evaluation.accumulate()
            evaluation.summarize()
            stats = evaluation.stats.tolist()
        row = {
            "step": step,
            "epoch": epoch,
            "images": len(identifiers),
            "full_validation": full,
            "coco_segm_stats": stats,
            "updated": utc_now(),
            "test_used": False,
        }
        with (args.output / "validation.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
        # Never compare 100-image AP with 1000-image AP for best selection.
        if not full and stats[0] > best_ap:
            best_ap = stats[0]
            temporary = args.output / "best.tmp.pth"
            torch.save(model.state_dict(), temporary)
            temporary.replace(args.output / "best.pth")
            write_json(args.output / "best.json", row)
        if full:
            write_json(args.output / "latest_full_validation.json", row)
        print(json.dumps({"validation": row}), flush=True)
        cfg.max_size = train_size
        model.train()
        status()

    checkpoint()
    status()
    def make_prefetcher(dataset, indices, workers, depth=24):
        """Overlap image loading with GPU compute using background threads.

        Threads (not processes) are used deliberately: the COCO annotations are
        several GB in memory and forking workers would duplicate them. cv2
        decoding releases the GIL, so a few threads still recover most of the
        loading time. Items are handed out strictly in order and exceptions are
        passed through as values, so the consumer's position can never desync.
        """
        import queue as _queue
        import threading as _threading
        from concurrent.futures import ThreadPoolExecutor

        pool = ThreadPoolExecutor(max_workers=max(1, workers))
        handoff: _queue.Queue = _queue.Queue(maxsize=depth)
        stop = _threading.Event()

        def pump():
            # Drain correctly: the submit loop stops once cursor reaches total,
            # but items already submitted must still be delivered. Guarding the
            # OUTER loop with `cursor < total` stranded the last `depth` results
            # in `pending`, so the consumer blocked for ever on the final images
            # of every epoch (observed as a 300 s prefetch stall at each epoch
            # boundary). Only the inner submit loop may test the cursor.
            pending = []
            cursor = 0
            total = len(indices)
            while not stop.is_set():
                while len(pending) < depth and cursor < total:
                    pending.append(pool.submit(dataset.__getitem__, indices[cursor]))
                    cursor += 1
                if not pending:
                    break
                future = pending.pop(0)
                try:
                    item = future.result()
                except BaseException as exc:  # passed to the consumer as a value
                    item = exc
                while not stop.is_set():
                    try:
                        handoff.put(item, timeout=0.25)
                        break
                    except _queue.Full:
                        continue

        _threading.Thread(target=pump, daemon=True).start()

        def take_next():
            # Never block forever: if the pump thread dies the consumer would hang
            # silently, the pid would still look alive, and a liveness-only watchdog
            # would wait for ever. Failing loudly lets the watchdog restart us.
            try:
                return handoff.get(timeout=args.loader_timeout)
            except _queue.Empty as exc:
                raise RuntimeError(
                    "prefetch produced nothing for %ss; aborting so the watchdog can restart"
                    % args.loader_timeout
                ) from exc

        def stop_prefetch():
            stop.set()
            pool.shutdown(wait=False, cancel_futures=True)

        return take_next, stop_prefetch

    with (args.output / "training.jsonl").open("a", encoding="utf-8") as log:
        while epoch < args.epochs:
            indices = list(range(len(train)))
            random.Random(seed + epoch).shuffle(indices)
            take_next, stop_prefetch = make_prefetcher(train, indices, args.loader_threads)
            while position < len(indices):
                tick = time.perf_counter()
                image_id = None
                take = min(args.micro_batch, len(indices) - position)
                stepped = False
                try:
                    raw = [take_next() for _ in range(take)]
                    for item in raw:
                        if isinstance(item, BaseException):
                            raise item
                    batch_images = [entry[0] for entry in raw]
                    batch_targets = [entry[1][0] for entry in raw]
                    batch_masks = [entry[1][1] for entry in raw]
                    batch_polys = [entry[1][2] for entry in raw]
                    batch_crowds = [int(entry[1][3]) for entry in raw]
                    image_id = raw[-1][2]
                    stacked = torch.stack(batch_images).cuda()
                    if micro_since_step == 0:
                        optimizer.zero_grad(set_to_none=True)
                    with torch.autocast("cuda", dtype=torch.bfloat16, enabled=args.amp):
                        losses = criterion(
                            model,
                            model(stacked),
                            [
                                torch.as_tensor(t, device="cuda", dtype=torch.float32)
                                for t in batch_targets
                            ],
                            [
                                torch.as_tensor(m, device="cuda", dtype=torch.float32)
                                for m in batch_masks
                            ],
                            [
                                torch.as_tensor(p, device="cuda", dtype=torch.float32)
                                for p in batch_polys
                            ],
                            batch_crowds,
                        )
                        total = sum(losses.values())
                    if not torch.isfinite(total):
                        raise FloatingPointError("Non-finite training loss")
                    (total / args.accum_steps).backward()
                    micro_since_step += 1
                    if micro_since_step >= args.accum_steps:
                        if args.recipe == "author":
                            # Author schedule: linear warmup 1e-4 -> 1e-2 over 2000
                            # iterations, then x0.1 drops after epochs 27 and 33.
                            if step < 2000:
                                lr = 1e-4 + (1e-2 - 1e-4) * (step / 2000.0)
                            else:
                                lr = 1e-2 * (0.1 ** sum(1 for e in (27, 33) if epoch >= e))
                        else:
                            lr = 1e-4 * (0.1 if epoch >= 27 else 1.0)
                        for group in optimizer.param_groups:
                            group["lr"] = lr
                        torch.nn.utils.clip_grad_norm_(
                            model.parameters(), 10, error_if_nonfinite=True
                        )
                        optimizer.step()
                        micro_since_step = 0
                        step += 1
                        stepped = True
                    torch.cuda.synchronize()
                    last_losses.append(float(total.detach()))
                    last_losses[:] = last_losses[-100:]
                    failures = 0
                except (FloatingPointError, ValueError) as error:
                    optimizer.zero_grad(set_to_none=True)
                    failures += 1
                    log.write(
                        json.dumps(
                            {
                                "error": str(error),
                                "image_id": image_id,
                                "epoch": epoch,
                                "position": position,
                            }
                        )
                        + "\n"
                    )
                    log.flush()
                    if failures >= 3:
                        checkpoint()
                        raise
                    position += take
                    micro_since_step = 0
                    optimizer.zero_grad(set_to_none=True)
                    continue
                position += take
                train_seconds += time.perf_counter() - tick
                # Periodic work must fire once per optimiser step, not once per
                # micro-batch: with gradient accumulation `step` is unchanged
                # across the micro-batches that make up one step.
                if stepped and step > 0 and step % 50 == 0:
                    row = {
                        "step": step,
                        "epoch": epoch,
                        "position": position,
                        "image_id": image_id,
                        "loss": float(total.detach()),
                        "recent_mean_loss": sum(last_losses) / len(last_losses),
                        "train_seconds": train_seconds,
                        "updated": utc_now(),
                    }
                    log.write(json.dumps(row) + "\n")
                    log.flush()
                    print(json.dumps(row), flush=True)
                    status()
                if stepped and step > 0 and step % args.checkpoint_every == 0:
                    checkpoint()
                    if shutil.disk_usage(args.output).free < 10_000_000_000:
                        raise OSError("Low disk: checkpoint saved, stopping safely")
                if stepped and step > 0 and step % args.validate_every == 0:
                    evaluate()
                    checkpoint()
                if args.max_steps and step >= args.max_steps:
                    checkpoint()
                    status("smoke_complete")
                    return
                if (args.output / "STOP_REQUESTED").exists():
                    checkpoint()
                    status("stopped_by_request")
                    return
            stop_prefetch()
            epoch += 1
            position = 0
            if epoch % max(1, args.full_validate_every) == 0 or epoch >= args.epochs:
                evaluate(full=True)
            evaluate()
            checkpoint()
            if args.stop_after_epoch and epoch >= args.stop_after_epoch:
                status("stopped_after_epoch")
                print(
                    json.dumps({"stopped_after_epoch": epoch, "step": step}), flush=True
                )
                return
        status("completed")


if __name__ == "__main__":
    main()
