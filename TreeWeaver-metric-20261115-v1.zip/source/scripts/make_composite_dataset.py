"""Generate a training set of real-tree cutout composites.

Each sample has one target tree at ~85% image height and two neighbour crowns
overlapping its edges. Saved per sample: composite PNG, visible/amodal masks,
target box, occlusion rate and split tag.
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "external" / "tree-stereo-biophysical-v4" / "extracted" / "full_trees"
OUTPUT = ROOT / "reports" / "broadleaf-dataset-2026-10-26"
TARGETS = [
    "FT211_IMG_20220906_114747",
    "FT88_IMG_20220906_142405",
    "FT207_IMG_20220906_114458",
    "FT161_IMG_20230309_134113",
    "FT94_IMG_20220906_144142",
    "FT149_IMG_20230309_125900",
]


def load(stem: str):
    image = cv2.imread(str(SOURCE / f"{stem}_LEFT.jpg"))
    mask_image = cv2.imread(str(SOURCE / f"{stem}_LEFT_mask.jpg"))
    if image is None or mask_image is None:
        raise FileNotFoundError(stem)
    mask = mask_image.max(axis=2) > 30
    ys, xs = np.nonzero(mask)
    if len(xs) < 100:
        raise ValueError(stem)
    return image, mask, (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)


def crop_target(image, mask, box):
    height, width = image.shape[:2]
    x0, y0, x1, y1 = box
    target_h = y1 - y0
    crop_h = min(height, max(int(round(target_h / 0.85)), 200))
    crop_w = min(width, int(round(crop_h * 16 / 9)))
    centre_x, centre_y = (x0 + x1) // 2, (y0 + y1) // 2
    left = min(max(centre_x - crop_w // 2, 0), width - crop_w)
    top = min(max(centre_y - crop_h // 2, 0), height - crop_h)
    return (
        image[top : top + crop_h, left : left + crop_w].copy(),
        mask[top : top + crop_h, left : left + crop_w].copy(),
    )


def cutout(stem: str):
    image, mask, box = load(stem)
    x0, y0, x1, y1 = box
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=240)
    parser.add_argument("--train", type=int, default=200)
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "images").mkdir(exist_ok=True)
    (OUTPUT / "gt").mkdir(exist_ok=True)
    rng = random.Random(args.seed)
    index = []
    for number in range(args.samples):
        target = TARGETS[number % len(TARGETS)]
        candidates = [stem for stem in TARGETS if stem != target]
        rng.shuffle(candidates)
        left_stem, right_stem = candidates[0], candidates[1]
        image, mask, _ = load(target)
        canvas, target_mask = crop_target(image, mask, _)
        height, width = canvas.shape[:2]
        ys, xs = np.nonzero(target_mask)
        t_left, t_top, t_right, t_bottom = xs.min(), ys.min(), xs.max(), ys.max()
        t_h, t_w = t_bottom - t_top, t_right - t_left
        amodal = [target_mask.copy()]
        for side, stem in (("left", left_stem), ("right", right_stem)):
            patch, alpha = cutout(stem)
            target_height = min(int(round(t_h * rng.uniform(0.82, 0.95))), int(t_bottom))
            scale = target_height / patch.shape[0]
            patch = cv2.resize(
                patch, (max(1, int(round(patch.shape[1] * scale))), target_height)
            )
            alpha = cv2.resize(
                alpha.astype(np.uint8),
                (patch.shape[1], patch.shape[0]),
                interpolation=cv2.INTER_NEAREST,
            ) > 0
            overlap = int(rng.uniform(0.12, 0.22) * t_w)
            max_width = min(t_left, width - t_right) + overlap
            if patch.shape[1] > max_width:
                scale = max_width / patch.shape[1]
                patch = cv2.resize(
                    patch, (max_width, max(1, int(round(patch.shape[0] * scale))))
                )
                alpha = cv2.resize(
                    alpha.astype(np.uint8),
                    (patch.shape[1], patch.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                ) > 0
            if side == "left":
                x0 = max(0, t_left + overlap - patch.shape[1])
            else:
                x0 = min(width - patch.shape[1], t_right - overlap)
            y0 = min(max(int(t_bottom) - patch.shape[0], 0), height - patch.shape[0])
            region = canvas[y0 : y0 + patch.shape[0], x0 : x0 + patch.shape[1]]
            region[alpha] = patch[alpha]
            placed = np.zeros((height, width), bool)
            placed[y0 : y0 + patch.shape[0], x0 : x0 + patch.shape[1]] = alpha
            amodal.append(placed)

        visible = [amodal[0] & ~(amodal[1] | amodal[2]), amodal[1].copy(), amodal[2].copy()]
        target_visible = visible[0]
        occlusion = 1.0 - float(target_visible.sum()) / max(int(amodal[0].sum()), 1)
        box = np.array([t_left, t_top, t_right, t_bottom], np.int32)
        ownership = np.zeros((height, width), np.uint8)
        for tree_index, tree_mask in enumerate(visible):
            ownership[tree_mask] = tree_index + 1
        boxes_all = []
        for tree_mask in amodal:
            ys, xs = np.nonzero(tree_mask)
            boxes_all.append([int(xs.min()), int(ys.min()), int(xs.max() + 1), int(ys.max() + 1)])
        boxes_all = np.asarray(boxes_all, np.int32)
        layer_rank = np.asarray([2, 0, 1], np.int32)  # lower = closer to camera
        name = f"{number:04d}"
        cv2.imwrite(str(OUTPUT / "images" / f"{name}.png"), canvas)
        np.savez_compressed(
            OUTPUT / "gt" / f"{name}.npz",
            visible=target_visible.astype(np.uint8),
            amodal=amodal[0].astype(np.uint8),
            box=box,
            occlusion_rate=occlusion,
            visible_all=np.stack(visible).astype(np.uint8),
            amodal_all=np.stack(amodal).astype(np.uint8),
            ownership=ownership,
            boxes_all=boxes_all,
            layer_rank=layer_rank,
        )
        index.append(
            {
                "name": name,
                "target": target.split("_")[0],
                "flanks": [left_stem.split("_")[0], right_stem.split("_")[0]],
                "occlusion_rate": round(occlusion, 4),
                "split": "train" if number < args.train else "val",
            }
        )
        if (number + 1) % 20 == 0:
            print(f"generated {number + 1}/{args.samples}", flush=True)
    (OUTPUT / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
    print(f"saved {len(index)} samples to {OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
