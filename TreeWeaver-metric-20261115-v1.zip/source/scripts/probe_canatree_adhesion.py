"""Zero-shot prompt ablation for tree adhesion on CanaTree100 fold_00.

Step 1 of the adhesion ladder, deliberately before any training or architecture
change: does the prompt contract (stem point, neighbour negative points) change
how much of a target trunk prediction leaks onto the neighbouring trunk?

Three conditions share the *same* GT-derived box per tree:

* ``box``         - box only, the current training prompt;
* ``box+pos``     - box plus one positive point at the base of the target trunk;
* ``box+pos+neg`` - plus up to three negative points on the nearest other trunks.

Everything is frozen: no weight update, same revision, same mask threshold. The
prompt geometry is generated from GT masks, so the numbers are an upper-bound
prompt study, not autonomous detection. Adhesion is measured as
``neighbour_fraction``: the share of predicted trunk pixels that fall on another
labelled trunk in the same frame.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import mask_row, mean_of, write_json  # noqa: E402

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
BASE = ROOT / "data/external/canatree100/extracted/CanaTree100"
CONDITIONS = ("box", "box+pos", "box+pos+neg")
MAX_NEGATIVES = 3


def load_fold(split: str):
    path = BASE / "annotations" / "fold_00" / f"{split}_fold_00.json"
    document = json.loads(path.read_text(encoding="utf-8"))
    by_image = {image["id"]: image for image in document["images"]}
    grouped = {image_id: [] for image_id in by_image}
    for annotation in document["annotations"]:
        grouped[annotation["image_id"]].append(annotation)
    return by_image, grouped, path


def rasterize(annotation, shape):
    mask = np.zeros(shape, np.uint8)
    for polygon in annotation.get("segmentation", []):
        points = np.rint(np.asarray(polygon).reshape(-1, 2)).astype(np.int32)
        if len(points) >= 3:
            cv2.fillPoly(mask, [points], 1)
    return mask


def decode_image(image, annotations):
    image_bgr = cv2.imread(str(BASE / "images" / image["file_name"]))
    if image_bgr is None:
        raise ValueError(f"missing {image['file_name']}")
    height, width = image_bgr.shape[:2]
    boxes, masks = [], []
    for annotation in annotations:
        mask = rasterize(annotation, (height, width))
        if not mask.any():
            continue
        ys, xs = np.nonzero(mask)
        boxes.append(np.array([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1], np.float32))
        masks.append(mask > 0)
    return image_bgr, np.stack(boxes), np.stack(masks), height, width


def prepare(by_image, grouped, processor, device):
    """Decode each frame once; conditions only change the prompt tensors."""
    prepared = []
    for image_id, image in by_image.items():
        image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
        pixels = processor(
            images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)), return_tensors="pt"
        )["pixel_values"].to(device)
        prepared.append(
            {
                "name": image["file_name"],
                "boxes": boxes,
                "masks": masks,
                "height": height,
                "width": width,
                "pixels": pixels,
            }
        )
    return prepared


def base_point(mask: np.ndarray, box: np.ndarray) -> tuple[float, float]:
    """Centre of the lowest tenth of the trunk mask: on the trunk, near its base."""
    x0, y0, x1, y1 = box
    band_height = max(2.0, 0.1 * float(y1 - y0))
    band_start = max(0, int(round(y1 - band_height)))
    band = mask[band_start : int(round(y1)), int(round(x0)) : int(round(x1))]
    ys, xs = np.nonzero(band)
    if len(xs):
        return float(xs.mean() + x0), float(ys.mean() + band_start)
    ys, xs = np.nonzero(mask)
    return float(xs.mean()), float(ys.mean())


def nearest_neighbours(index: int, boxes: np.ndarray, limit: int) -> list[int]:
    """Other trunks ranked by box edge distance."""
    target = boxes[index]
    candidates = []
    for other in range(len(boxes)):
        if other == index:
            continue
        box = boxes[other]
        dx = max(0.0, max(target[0] - box[2], box[0] - target[2]))
        dy = max(0.0, max(target[1] - box[3], box[1] - target[3]))
        candidates.append((dx * dx + dy * dy, other))
    candidates.sort()
    return [other for _, other in candidates[:limit]]


def build_prompts(frame, condition):
    height, width = frame["height"], frame["width"]
    scale = np.asarray([1024 / width, 1024 / height], np.float32)
    points, labels = [], []
    for index in range(len(frame["boxes"])):
        positive = [base_point(frame["masks"][index], frame["boxes"][index])]
        if condition == "box":
            positive = []
        negatives = []
        if condition == "box+pos+neg":
            for other in nearest_neighbours(index, frame["boxes"], MAX_NEGATIVES):
                negatives.append(base_point(frame["masks"][other], frame["boxes"][other]))
        points.append([np.asarray(point, np.float32) * scale for point in positive + negatives])
        labels.append([1] * len(positive) + [0] * len(negatives))
    count = max((len(item) for item in points), default=0)
    if not count:
        return None, None
    coordinates = np.zeros((len(frame["boxes"]), count, 2), np.float32)
    padded = np.full((len(frame["boxes"]), count), -1, np.int64)
    for index, (point_list, label_list) in enumerate(zip(points, labels, strict=True)):
        coordinates[index, : len(point_list)] = point_list
        padded[index, : len(label_list)] = label_list
    return coordinates, padded


def predict(model, frame, points, labels):
    height, width = frame["height"], frame["width"]
    device = frame["pixels"].device
    scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
    arguments = {
        "pixel_values": frame["pixels"],
        "input_boxes": torch.as_tensor(frame["boxes"] * scale, device=device)[None],
        "multimask_output": False,
    }
    if points is not None:
        arguments["input_points"] = torch.as_tensor(points, device=device)[None]
        arguments["input_labels"] = torch.as_tensor(labels, device=device)[None]
    with torch.inference_mode():
        output = model(**arguments)
        # transformers' ModelOutput is a dict subclass, so branch on the attribute.
        logits = output.pred_masks if hasattr(output, "pred_masks") else output["masks"]
        logits = logits[0, :, 0]
    upscaled = F.interpolate(logits[:, None], (height, width), mode="bilinear", align_corners=False)
    return (upscaled[:, 0] > 0).cpu().numpy()


def evaluate(model, prepared, condition):
    rows = []
    for frame in prepared:
        points, labels = build_prompts(frame, condition)
        predicted = predict(model, frame, points, labels)
        masks = frame["masks"]
        for index in range(len(masks)):
            others = [masks[other] for other in range(len(masks)) if other != index]
            rows.append(
                {
                    "image": frame["name"],
                    "tree_index": index,
                    "condition": condition,
                    "metrics": mask_row(
                        f"{frame['name']}:{index}",
                        predicted[index],
                        masks[index],
                        others=others,
                    ),
                }
            )
    return rows


def block(rows):
    metrics = [row["metrics"] for row in rows]
    return {
        "trees": len(rows),
        "mean_iou": mean_of(metrics, "iou"),
        "mean_boundary_f1": mean_of(metrics, "boundary_f1"),
        "mean_recall": mean_of(metrics, "recall"),
        "mean_precision": mean_of(metrics, "precision"),
        "mean_neighbour_fraction": mean_of(metrics, "neighbour_fraction"),
        "empty_predictions": sum(1 for item in metrics if item["empty_prediction"]),
    }


def paired(left_rows, right_rows, left_name, right_name):
    left = {f"{row['image']}:{row['tree_index']}": row["metrics"] for row in left_rows}
    right = {f"{row['image']}:{row['tree_index']}": row["metrics"] for row in right_rows}
    shared = sorted(set(left) & set(right))
    delta_iou = [right[key]["iou"] - left[key]["iou"] for key in shared]
    delta_neighbour = [
        right[key]["neighbour_fraction"] - left[key]["neighbour_fraction"] for key in shared
    ]
    delta_boundary = [right[key]["boundary_f1"] - left[key]["boundary_f1"] for key in shared]
    return {
        "left": left_name,
        "right": right_name,
        "compared": len(shared),
        "mean_delta_iou": float(np.mean(delta_iou)) if shared else 0.0,
        "mean_delta_boundary_f1": float(np.mean(delta_boundary)) if shared else 0.0,
        "mean_delta_neighbour_fraction": float(np.mean(delta_neighbour)) if shared else 0.0,
        "iou_wins": sum(value > 1e-6 for value in delta_iou),
        "iou_ties": sum(abs(value) <= 1e-6 for value in delta_iou),
        "iou_losses": sum(value < -1e-6 for value in delta_iou),
        "neighbour_improved": sum(value < -1e-6 for value in delta_neighbour),
        "neighbour_worse": sum(value > 1e-6 for value in delta_neighbour),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--splits", nargs="+", default=["val", "test"])
    parser.add_argument("--checkpoint", type=Path, default=None)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    documents = {split: load_fold(split) for split in args.splits}
    protocol = {
        "schema_version": "treeweaver-prompt-probe-1.0",
        "purpose": "isolate the prompt lever for tree adhesion before any training",
        "dataset": {
            "root": str(BASE),
            "annotations": "trunk-only COCO polygons, single category, non-exhaustive",
            "splits": {
                split: {
                    "fold_file": str(document[2].relative_to(BASE)),
                    "fold_file_sha256": sha256_file(document[2]),
                    "images": len(document[0]),
                    "trunks": sum(len(values) for values in document[1].values()),
                }
                for split, document in documents.items()
            },
        },
        "prompt_conditions": list(CONDITIONS),
        "prompt_geometry": {
            "box": "GT trunk bounding box, no padding",
            "positive_point": "centre of the lowest 10% of the target GT trunk mask",
            "negative_points": (
                f"centres of the lowest 10% bands of up to {MAX_NEGATIVES} other GT trunks, "
                "ranked by box edge distance"
            ),
            "coordinates": "scaled to the 1024 input frame per axis",
        },
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "checkpoint": str(args.checkpoint) if args.checkpoint else None,
            "checkpoint_sha256": sha256_file(args.checkpoint) if args.checkpoint else None,
        },
        "frozen": "no weights updated; identical boxes across conditions; mask logit > 0",
        "metrics": {
            "neighbour_fraction": (
                "share of predicted trunk pixels that fall on another labelled trunk"
            ),
            "boundary_f1": "tolerance 2 px in original resolution",
        },
        "limitations": [
            "GT-derived box and GT-derived points: an upper-bound prompt study",
            "trunk annotations are non-exhaustive, so unlabelled background trunks are not "
            "counted as neighbours and neighbour_fraction is a lower bound",
            "fold_00 is not video-disjoint from other folds and is development-only",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    models = {"stock_sam2": sam2}
    if args.checkpoint is not None:
        custom = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device)
        payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
        report = custom.decoder.load_state_dict(payload["decoder"], strict=False)
        missing = [
            key
            for key in report.missing_keys
            if not key.startswith(("stem_token.", "stem_hypernet."))
        ]
        if missing or report.unexpected_keys:
            raise ValueError(f"checkpoint mismatch: {missing} {report.unexpected_keys}")
        custom.eval()
        models["finetuned_decoder"] = custom

    prepared = {
        split: prepare(document[0], document[1], processor, args.device)
        for split, document in documents.items()
    }
    summary = {
        "schema_version": protocol["schema_version"],
        "prompt_conditions": list(CONDITIONS),
        "results": {},
        "paired": {},
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "limitations": protocol["limitations"],
    }
    for model_name, model in models.items():
        for split in documents:
            rows = {}
            for condition in CONDITIONS:
                rows[condition] = evaluate(model, prepared[split], condition)
                summary["results"].setdefault(model_name, {}).setdefault(split, {})[condition] = (
                    block(rows[condition])
                )
                print(
                    json.dumps(
                        {
                            "model": model_name,
                            "split": split,
                            "condition": condition,
                            **summary["results"][model_name][split][condition],
                        }
                    ),
                    flush=True,
                )
                write_json(
                    args.output
                    / f"per_tree_{model_name}_{split}_{condition.replace('+', '_')}.json",
                    rows[condition],
                )
            summary["paired"].setdefault(model_name, {})[split] = {
                "box -> box+pos": paired(rows["box"], rows["box+pos"], "box", "box+pos"),
                "box+pos -> box+pos+neg": paired(
                    rows["box+pos"], rows["box+pos+neg"], "box+pos", "box+pos+neg"
                ),
                "box -> box+pos+neg": paired(
                    rows["box"], rows["box+pos+neg"], "box", "box+pos+neg"
                ),
            }
            write_json(args.output / "summary.json", summary)
    write_json(args.output / "summary.json", summary)
    print("DONE", json.dumps(summary["paired"]))


if __name__ == "__main__":
    main()
