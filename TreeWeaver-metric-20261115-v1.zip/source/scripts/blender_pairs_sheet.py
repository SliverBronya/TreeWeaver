"""Contact sheet for a folder of Blender pair renders."""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

COLOURS = [(60, 80, 240), (240, 160, 60), (80, 200, 80)]
PANEL_W, PANEL_H = 460, 259


def coloured(masks, shape):
    panel = np.zeros((*shape, 3), np.uint8)
    for index, mask in enumerate(masks):
        panel[mask] = COLOURS[index]
    return panel


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    pairs = sorted(args.input.glob("*_gt.npz"))
    rows = []
    for path in pairs:
        name = path.name.replace("_gt.npz", "")
        rgb = cv2.imread(str(args.input / f"{name}_rgb.png"))
        data = np.load(path)
        amodal, visible = data["amodal"], data["visible"]
        height, width = amodal.shape[1:]
        ys, _ = np.nonzero(amodal[0])
        fraction = (ys.max() - ys.min()) / height
        occlusion = 1.0 - visible[0].sum() / max(amodal[0].sum(), 1)
        header = f"{name}  target height={fraction * 100:.0f}%  occlusion={occlusion * 100:.1f}%"
        rows.append(
            (
                header,
                [
                    cv2.resize(rgb, (PANEL_W, PANEL_H)),
                    cv2.resize(coloured(visible, (height, width)), (PANEL_W, PANEL_H)),
                    cv2.resize(coloured(amodal, (height, width)), (PANEL_W, PANEL_H)),
                ],
            )
        )
    if not rows:
        raise SystemExit("no pairs")
    gap = 8
    sheet = np.full((44 + len(rows) * (PANEL_H + 32), 3 * (PANEL_W + gap), 3), 30, np.uint8)
    for column, title in enumerate(["Blender render", "visible GT", "amodal GT"]):
        cv2.putText(
            sheet, title, (column * (PANEL_W + gap) + 8, 26),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (220, 220, 220), 1,
        )
    for row_index, (header, panels) in enumerate(rows):
        y0 = 44 + row_index * (PANEL_H + 32)
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
        for column, panel in enumerate(panels):
            x0 = column * (PANEL_W + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL_H, x0 : x0 + PANEL_W] = panel
    cv2.imwrite(str(args.input / "contact_sheet.png"), sheet)
    print(f"saved {args.input / 'contact_sheet.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
