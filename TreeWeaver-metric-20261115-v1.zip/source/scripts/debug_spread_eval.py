"""Debug held-out oracle IoU for the SPREAD ConvexMask pilot (throwaway)."""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--palette", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--max-instances", type=int, default=24)
    args = parser.parse_args()
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    import torch.nn.functional as functional
    from data import cfg, set_cfg
    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    set_cfg("convex_synthtree_focal")
    cfg.max_size = (512, 512)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    cfg.dataset.class_names = ("tree",)
    from convexmask import ConvexMask

    pal = {int(k): tuple(v) for k, v in
           json.loads(args.palette.read_text(encoding="utf-8"))["palette"].items()}

    def build(scenes, cap):
        rng = random.Random(42)
        records = []
        per_scene = max(1, cap // len(scenes))
        for scene in scenes:
            rgb_dir = args.data_root / scene / "rgb"
            inst_dir = args.data_root / scene / "instance_segmentation"
            frames = sorted(p.stem for p in rgb_dir.glob("*.png"))
            rng.shuffle(frames)
            selected = frames[:per_scene if len(scenes) > 1 else cap]
            for stem in selected:
                image = cv2.imread(str(rgb_dir / f"{stem}.png"))
                instance = cv2.cvtColor(cv2.imread(str(inst_dir / f"{stem}.png")),
                                        cv2.COLOR_BGR2RGB)
                inst = []
                for line in (inst_dir / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
                    p = line.split()
                    if len(p) == 2 and p[0].startswith("Tree"):
                        idx = int(p[1])
                        if idx in pal:
                            m = cv2.inRange(instance, np.array(pal[idx]), np.array(pal[idx]))
                            a = int(m.sum() // 255)
                            if a >= 10:
                                inst.append((a, m))
                inst.sort(reverse=True, key=lambda x: x[0])
                inst = inst[:args.max_instances]
                masks, boxes, hulls = [], [], []
                for _, m in inst:
                    m = (cv2.resize(m, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
                    ys, xs = np.nonzero(m)
                    if len(xs) < 10:
                        continue
                    cs = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
                    hull = cv2.convexHull(np.concatenate(cs))[:, 0]
                    masks.append(m)
                    hulls.append(hull.astype(np.float32) / 512)
                    boxes.append([xs.min()/512, ys.min()/512, (xs.max()+1)/512,
                                  (ys.max()+1)/512, 0])
                if not masks:
                    continue
                resized = cv2.resize(image, (512, 512)).astype(np.float32)
                resized = ((resized - np.array([103.94, 116.78, 123.68]))
                           / np.array([57.38, 57.12, 58.40]))[:, :, ::-1].copy()
                tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)
                polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
                for i, h in enumerate(hulls):
                    polys[i, :len(h)] = h
                records.append({"scene": scene, "frame": stem, "tensor": tensor,
                                "masks": torch.tensor(np.stack(masks), dtype=torch.uint8),
                                "count": len(masks)})
        return records

    train = build(["birch_forest", "broadleaf_forest"], 240)
    test = build(["city_park"], 30)
    print("records:", len(train), len(test), flush=True)

    model = ConvexMask().cuda()
    model.load_state_dict(torch.load(args.checkpoint, map_location="cuda"))
    model.train()

    def eval_frame(r):
        with torch.no_grad():
            pred = model(r["tensor"][None].cuda())
            probs = (pred["proto"][0] @ pred["mask"][0].T).sigmoid()
            scores = pred["conf"][0, :, 1].sigmoid()
            idx = scores.topk(min(32, scores.numel())).indices
            raw = functional.interpolate(
                probs[:, :, idx].permute(2, 0, 1)[None], (512, 512),
                mode="bilinear", align_corners=False)[0]
            print(f"--- {r['scene']}/{r['frame']} N={r['count']} | "
                  f"conf max={float(scores.max()):.3f} top32 min={float(scores[idx].min()):.3f} "
                  f"prob max={float(probs.max()):.3f} mean={float(probs.mean()):.4f}", flush=True)
            for ti in range(min(3, r["count"])):
                target = r["masks"][ti].bool().cuda()
                line = f"  target {ti} size={int(target.sum()):6d}"
                for th in (0.3, 0.4, 0.5):
                    cm = raw > th
                    iou = ((cm & target).sum((1, 2)) /
                           (cm | target).sum((1, 2)).clamp_min(1))
                    line += f" | thr{th} best={float(iou.max()):.3f}"
                print(line, flush=True)

    for r in train[:2]:
        eval_frame(r)
    for r in test[:2]:
        eval_frame(r)


if __name__ == "__main__":
    main()
