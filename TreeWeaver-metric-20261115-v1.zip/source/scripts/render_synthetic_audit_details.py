"""Render saved synthetic predictions with explicit amodal GT and omission errors."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()
    protocol = json.loads((args.audit / "protocol.json").read_text(encoding="utf-8"))
    data = Path(protocol["dataset"])
    rows = json.loads((args.audit / "per_tree.json").read_text(encoding="utf-8"))
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 17)
    width, height = 384, 216
    colors = np.array([[255, 90, 60], [30, 160, 240], [130, 210, 50], [210, 90, 220]])

    def image_for(image_id):
        return cv2.cvtColor(
            cv2.imread(str(data / "images" / f"{image_id:06d}.png")), cv2.COLOR_BGR2RGB
        )

    def truth_for(image_id, kind):
        count = len(json.loads((data / "meta" / f"{image_id:06d}.json").read_text())["trees"])
        return np.stack(
            [
                cv2.resize(
                    (
                        cv2.imread(
                            str(data / "masks" / f"{image_id:06d}" / f"{kind}_{k}.png"),
                            cv2.IMREAD_UNCHANGED,
                        )[..., 3]
                        > 16
                    ).astype(np.uint8),
                    (256, 256),
                    interpolation=cv2.INTER_NEAREST,
                )
                > 0
                for k in range(1, count + 1)
            ]
        )

    def overlay(image, masks):
        panel = cv2.resize(image, (width, height))
        for k, mask in enumerate(masks):
            keep = (
                cv2.resize(mask.astype(np.uint8), (width, height), interpolation=cv2.INTER_NEAREST)
                > 0
            )
            panel[keep] = (0.55 * panel[keep] + 0.45 * colors[k % 4]).astype(np.uint8)
        return Image.fromarray(panel)

    candidates = [r for r in rows if r["model"] == "five_hour"]
    occluded = max(candidates, key=lambda row: row["occluded_fraction"])
    chosen = [protocol["images"][0], occluded["image_id"]]
    sheet = Image.new("RGB", (width * 5, (height + 65) * 2 + 40), "white")
    draw = ImageDraw.Draw(sheet)
    draw.text(
        (8, 6),
        "合成完整轮廓对照：同一相机的单树渲染标签；旧开发集，共用树资产",
        fill="black",
        font=font,
    )
    columns = [
        ("可见真值", None, "visible"),
        ("完整真值", None, "amodal"),
        ("Stage B 完整预测", "stageB", "amodal"),
        ("5小时 完整预测", "five_hour", "amodal"),
        ("旧300步 完整预测", "short_improve", "amodal"),
    ]
    for r, image_id in enumerate(chosen):
        rgb = image_for(image_id)
        y = 40 + r * (height + 65)
        for c, (label, name, kind) in enumerate(columns):
            masks = (
                truth_for(image_id, kind)
                if name is None
                else np.load(args.audit / name / f"{image_id:06d}.npz")[kind]
            )
            draw.text((c * width + 5, y), label, fill="black", font=font)
            sheet.paste(overlay(rgb, masks), (c * width, y + 27))
        reason = "固定首图" if r == 0 else "5小时模型评价中，真值遮挡比例最大的目标所在图"
        draw.text((5, y + height + 32), f"图 {image_id} | {reason}", fill="black", font=font)
    sheet.save(args.audit / "amodal-comparison.jpg", quality=94)

    low = [r for r in candidates if r["occluded_fraction"] <= 0.01]
    chosen_row = max(low, key=lambda row: row["miss_rate"])
    image_id, tree = chosen_row["image_id"], chosen_row["tree"] - 1
    rgb = image_for(image_id)
    gt = truth_for(image_id, "visible")[tree]
    prediction = np.load(args.audit / "five_hour" / f"{image_id:06d}.npz")
    raw, owner = prediction["visible"][tree], prediction["owner_visible"][tree]
    sheet = Image.new("RGB", (width * 5, height + 100), "white")
    draw = ImageDraw.Draw(sheet)
    panels = [
        Image.fromarray(cv2.resize(rgb, (width, height))),
        overlay(rgb, gt[None]),
        overlay(rgb, raw[None]),
        overlay(rgb, owner[None]),
    ]
    error = cv2.resize(rgb, (width, height))
    for keep, color in ((gt & ~raw, (240, 40, 40)), (~gt & raw, (40, 100, 255))):
        keep = (
            cv2.resize(keep.astype(np.uint8), (width, height), interpolation=cv2.INTER_NEAREST) > 0
        )
        error[keep] = color
    panels.append(Image.fromarray(error))
    labels = ["原图", "该树可见真值", "5小时原始可见预测", "再经过归属裁剪", "红：漏分；蓝：多分"]
    for c, (panel, label) in enumerate(zip(panels, labels, strict=True)):
        draw.text((c * width + 5, 7), label, fill="black", font=font)
        sheet.paste(panel, (c * width, 38))
    draw.text(
        (7, height + 45),
        f"低遮挡组漏分最严重样本：图 {image_id} 第{tree + 1}棵；"
        f"真值遮挡 {chosen_row['occluded_fraction']:.1%}，"
        f"可见召回 {chosen_row['recall']:.1%}，归属后召回 {chosen_row['owner_recall']:.1%}",
        fill="black",
        font=font,
    )
    draw.text(
        (7, height + 72),
        "低遮挡定义：隐藏面积≤完整面积1%；此图无解剖树干标签，不能报告树干精度。",
        fill="black",
        font=font,
    )
    sheet.save(args.audit / "low-occlusion-omission.jpg", quality=94)
    print(json.dumps(chosen_row, ensure_ascii=False))


if __name__ == "__main__":
    main()
