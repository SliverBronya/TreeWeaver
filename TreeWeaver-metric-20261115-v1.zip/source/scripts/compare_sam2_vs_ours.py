"""Qualitative comparison on 20260411: stock SAM2 vs the current occlusion decoder.

No ground-truth masks exist for these phone photos, so this is a visual/agreement
comparison only.
"""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL_W, PANEL_H = 420, 236


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def overlay(image, mask, colour, title):
    panel = image.copy()
    if mask is not None:
        colour_array = np.array(colour, np.float32)
        panel[mask] = (0.55 * panel[mask] + 0.45 * colour_array).astype(np.uint8)
        contours = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(panel, contours, -1, colour, 1)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    return panel


def difference_panel(stock, ours, title):
    panel = np.zeros((*stock.shape, 3), np.uint8)
    panel[stock & ours] = (170, 170, 170)
    panel[stock & ~ours] = (240, 120, 40)
    panel[ours & ~stock] = (60, 80, 240)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    return panel


def contour_overlay(image, masks_colours, title):
    panel = image.copy()
    for mask, colour in masks_colours:
        contours = cv2.findContours(
            mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(panel, contours, -1, colour, 2)
    cv2.putText(panel, title, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)
    cv2.putText(panel, title, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)
    return panel


def build_single(image, stock, ours, amodal, header):
    big_w, big_h = 560, 315
    ys, xs = np.nonzero(stock | ours)
    pad = 0.12
    left = max(0, int(xs.min() - pad * (xs.max() - xs.min())))
    right = min(image.shape[1], int(xs.max() + pad * (xs.max() - xs.min())))
    top = max(0, int(ys.min() - pad * (ys.max() - ys.min())))
    bottom = min(image.shape[0], int(ys.max() + pad * (ys.max() - ys.min())))
    crop = image[top:bottom, left:right].copy()
    zoom_masks = [
        (stock[top:bottom, left:right], (240, 120, 40)),
        (ours[top:bottom, left:right], (60, 80, 240)),
    ]
    zoom = contour_overlay(crop, zoom_masks, "zoom: stock blue, ours red")
    panels = [
        contour_overlay(
            image,
            [(stock, (240, 120, 40)), (ours, (60, 80, 240))],
            "photo: stock blue, ours red",
        ),
        overlay(image, stock, (240, 120, 40), "stock SAM2"),
        overlay(image, ours, (60, 200, 90), "ours visible"),
        overlay(image, amodal, (60, 80, 240), "ours amodal"),
        difference_panel(stock, ours, "stock-only blue / ours-only red"),
        zoom,
    ]
    gap = 8
    figure = np.full((76 + 2 * (big_h + 30), 3 * (big_w + gap), 3), 248, np.uint8)
    cv2.putText(figure, header, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (20, 20, 20), 1)
    for index, panel in enumerate(panels):
        row, col = divmod(index, 3)
        x0 = col * (big_w + gap)
        y0 = 76 + row * (big_h + 30)
        cv2.putText(
            figure, panel_title(index), (x0 + 6, y0 - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (30, 30, 30), 1,
        )
        figure[y0 : y0 + big_h, x0 : x0 + big_w] = cv2.resize(panel, (big_w, big_h))
    return figure


def panel_title(index):
    return [
        "photo + contours",
        "stock SAM2",
        "ours visible",
        "ours amodal",
        "difference",
        "zoom",
    ][index]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--images",
        type=Path,
        nargs="+",
        default=[
            ROOT / "data" / "20260411" / "7001.jpg",
            ROOT / "data" / "20260411" / "7002.jpg",
            ROOT / "data" / "20260411" / "10002.jpg",
        ],
    )
    parser.add_argument("--boxes-per-image", type=int, default=2)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    parameters = inspect.signature(
        detector_processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"

    rows, headers = [], []
    for path in args.images:
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(
            images=image, text="tree.", return_tensors="pt"
        ).to(args.device)
        with torch.no_grad():
            detector_outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            detector_outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **{threshold_keyword: 0.28},
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        for box_number, rank in enumerate(
            np.argsort(scores)[::-1][: args.boxes_per_image], start=1
        ):
            box = boxes[rank]
            scale = np.array(
                [1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32
            )
            scaled = torch.as_tensor(box * scale, device=args.device)[None, None]
            inputs = processor(images=image, return_tensors="pt")
            with torch.no_grad():
                base = sam2(
                    pixel_values=inputs["pixel_values"].to(args.device),
                    input_boxes=scaled,
                    multimask_output=True,
                )
                index = int(torch.argmax(base.iou_scores[0, 0]))
                stock_mask = processor.post_process_masks(
                    base.pred_masks[:, :, index : index + 1],
                    original_sizes=[[height, width]],
                )[0][0, 0].cpu().numpy() > 0
                output = model(
                    inputs["pixel_values"].to(args.device), input_boxes=scaled
                )
                our_visible = processor.post_process_masks(
                    output["masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
                our_amodal = processor.post_process_masks(
                    output["amodal_masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
            if stock_mask.sum() < 1000:
                continue
            photo = cv2.resize(image_bgr, (PANEL_W, PANEL_H))
            rows.append(
                [
                    photo,
                    cv2.resize(
                        overlay(image_bgr, stock_mask, (240, 120, 40), "stock SAM2"),
                        (PANEL_W, PANEL_H),
                    ),
                    cv2.resize(
                        overlay(image_bgr, our_visible, (60, 200, 90), "ours visible"),
                        (PANEL_W, PANEL_H),
                    ),
                    cv2.resize(
                        overlay(image_bgr, our_amodal, (240, 120, 40), "ours amodal"),
                        (PANEL_W, PANEL_H),
                    ),
                    cv2.resize(
                        difference_panel(
                            stock_mask, our_visible, "stock-only blue / ours-only red"
                        ),
                        (PANEL_W, PANEL_H),
                    ),
                ]
            )
            stock_only = int((stock_mask & ~our_visible).sum())
            ours_only = int((our_visible & ~stock_mask).sum())
            headers.append(
                f"{path.name} score={scores[rank]:.2f} "
                f"IoU(vis vs SAM2)={iou(our_visible, stock_mask):.2f} "
                f"IoU(amodal vs SAM2)={iou(our_amodal, stock_mask):.2f} "
                f"stock-only={stock_only} ours-only={ours_only}"
            )
            figure = build_single(
                image_bgr,
                stock_mask,
                our_visible,
                our_amodal,
                f"{path.name}  box {box_number}  score={scores[rank]:.2f}  "
                f"IoU={iou(our_visible, stock_mask):.2f}  "
                f"ours-only={ours_only}  stock-only={stock_only}",
            )
            cv2.imwrite(
                str(args.output.parent / f"{path.stem}_box{box_number}.png"), figure
            )
            print(headers[-1], flush=True)

    if not rows:
        raise SystemExit("no samples")
    gap = 6
    row_height = PANEL_H + 28
    sheet = np.full((40 + len(rows) * row_height, 5 * (PANEL_W + gap), 3), 248, np.uint8)
    for column, title in enumerate(
        ["photo", "stock SAM2", "ours visible", "ours amodal", "difference"]
    ):
        cv2.putText(
            sheet, title, (column * (PANEL_W + gap) + 8, 24),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 1,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = 40 + row_index * row_height
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (25, 25, 25), 1)
        for column, panel in enumerate(panels):
            x0 = column * (PANEL_W + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL_H, x0 : x0 + PANEL_W] = panel
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(args.output), sheet)
    (args.output.parent / "comparison.json").write_text(
        json.dumps({"checkpoint": str(args.checkpoint), "rows": headers}, indent=2),
        encoding="utf-8",
    )
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
