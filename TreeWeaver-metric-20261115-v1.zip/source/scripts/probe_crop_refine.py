"""Does a high-resolution strip crop beat the full frame for trunk masks?

Step 3 of the adhesion ladder. Step 1 showed the prompt lever is small and this
data punishes negatives; step 2 showed 300-step fine-tuning overfits after 50
steps, so the mask decoder weights are not the bottleneck. The remaining
structural suspicion is resolution: CanaTree trunks are often 10-40 px wide in
1280x720, while the mask logits live at 256x256. A trunk 20 px wide is roughly
4 px wide at mask resolution, which is where boundary and adhesion errors are
made.

This probe therefore changes only the observation window, not the weights:

* ``full``      - current path: whole frame, GT box prompt;
* ``strip``     - crop a vertical strip around the trunk, resize to 1024, then
  paste the mask back at original resolution;
* ``strip+pos`` - same crop plus a positive point at the trunk base.

``full`` is re-run inside this script as a control so every number comes from
the same code path.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from probe_canatree_adhesion import (  # noqa: E402
    BASE,
    REVISION,
    base_point,
    decode_image,
    load_fold,
)
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from stem_eval_common import mask_row, mean_of, write_json  # noqa: E402
from strip_refine import refine_mask  # noqa: E402

CONDITIONS = ("full", "strip", "strip+pos")


def run_full(model, pixels, boxes, height, width):
    scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
    with torch.inference_mode():
        output = model(
            pixel_values=pixels,
            input_boxes=torch.as_tensor(boxes * scale, device=pixels.device)[None],
            multimask_output=False,
        )
        logits = output.pred_masks[0, :, 0]
    upscaled = F.interpolate(logits[:, None], (height, width), mode="bilinear", align_corners=False)
    return (upscaled[:, 0] > 0).cpu().numpy()


def run_strip(model, processor, image_bgr, box, point, device, x_margin, y_margin):
    """Thin wrapper: the single implementation lives in workers/tree_models/strip_refine.py."""
    return refine_mask(
        model, processor, image_bgr, box, point, device, x_margin=x_margin, y_margin=y_margin
    )


def evaluate(model, processor, prepared, condition, device, x_margin, y_margin):
    rows = []
    for frame in prepared:
        image_bgr = cv2.imread(str(BASE / "images" / frame["name"]))
        masks = frame["masks"]
        if condition == "full":
            predicted = run_full(
                model, frame["pixels"], frame["boxes"], frame["height"], frame["width"]
            )
        else:
            predicted = np.stack(
                [
                    run_strip(
                        model,
                        processor,
                        image_bgr,
                        frame["boxes"][index],
                        frame["points"][index] if condition == "strip+pos" else None,
                        device,
                        x_margin,
                        y_margin,
                    )
                    for index in range(len(masks))
                ]
            )
        for index in range(len(masks)):
            others = [masks[other] for other in range(len(masks)) if other != index]
            rows.append(
                {
                    "image": frame["name"],
                    "tree_index": index,
                    "condition": condition,
                    "metrics": mask_row(
                        f"{frame['name']}:{index}",
                        predicted[index],
                        masks[index],
                        others=others,
                    ),
                }
            )
    return rows


def block(rows):
    metrics = [row["metrics"] for row in rows]
    return {
        "trees": len(rows),
        "mean_iou": mean_of(metrics, "iou"),
        "mean_boundary_f1": mean_of(metrics, "boundary_f1"),
        "mean_recall": mean_of(metrics, "recall"),
        "mean_precision": mean_of(metrics, "precision"),
        "mean_neighbour_fraction": mean_of(metrics, "neighbour_fraction"),
    }


def paired(left_rows, right_rows):
    left = {f"{row['image']}:{row['tree_index']}": row["metrics"] for row in left_rows}
    right = {f"{row['image']}:{row['tree_index']}": row["metrics"] for row in right_rows}
    shared = sorted(set(left) & set(right))
    delta_iou = [right[key]["iou"] - left[key]["iou"] for key in shared]
    delta_neighbour = [
        right[key]["neighbour_fraction"] - left[key]["neighbour_fraction"] for key in shared
    ]
    return {
        "compared": len(shared),
        "mean_delta_iou": float(np.mean(delta_iou)) if shared else 0.0,
        "mean_delta_neighbour_fraction": float(np.mean(delta_neighbour)) if shared else 0.0,
        "iou_wins": sum(value > 1e-6 for value in delta_iou),
        "iou_losses": sum(value < -1e-6 for value in delta_iou),
        "neighbour_improved": sum(value < -1e-6 for value in delta_neighbour),
        "neighbour_worse": sum(value > 1e-6 for value in delta_neighbour),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--splits", nargs="+", default=["val", "test"])
    parser.add_argument("--x-margin", type=float, default=0.5)
    parser.add_argument("--y-margin", type=float, default=0.05)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    documents = {split: load_fold(split) for split in args.splits}
    protocol = {
        "schema_version": "treeweaver-crop-probe-1.0",
        "purpose": "test whether observation resolution, not weights, limits trunk masks",
        "ladder_step": 3,
        "conditions": list(CONDITIONS),
        "crop": {
            "shape": "vertical strip around the GT box",
            "x_margin_fraction_of_box_width": args.x_margin,
            "y_margin_fraction_of_box_height": args.y_margin,
            "resize": "crop resized to the 1024 input frame, mask pasted back at original scale",
        },
        "model": {
            "base": "facebook/sam2.1-hiera-tiny",
            "revision": REVISION,
            "weights": "stock, frozen; no fine-tuning",
        },
        "splits": {
            split: {
                "fold_file_sha256": sha256_file(document[2]),
                "images": len(document[0]),
                "trunks": sum(len(values) for values in document[1].values()),
            }
            for split, document in documents.items()
        },
        "limitations": [
            "GT-derived box; prompted segmentation, not detection",
            "strip crop is a fixed rule, not a learned refine head",
            "fold_00 is development-only and not video-disjoint",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()

    summary = {
        "schema_version": protocol["schema_version"],
        "conditions": list(CONDITIONS),
        "results": {},
        "paired": {},
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "limitations": protocol["limitations"],
    }
    for split, (by_image, grouped, _) in documents.items():
        prepared = []
        for image_id, image in by_image.items():
            image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
            pixels = processor(
                images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)),
                return_tensors="pt",
            )["pixel_values"].to(args.device)
            prepared.append(
                {
                    "name": image["file_name"],
                    "boxes": boxes,
                    "masks": masks,
                    "height": height,
                    "width": width,
                    "pixels": pixels,
                    "points": np.stack(
                        [
                            np.asarray(base_point(masks[index], boxes[index]), np.float32)
                            for index in range(len(boxes))
                        ]
                    ),
                }
            )
        results = {}
        for condition in CONDITIONS:
            results[condition] = evaluate(
                sam2,
                processor,
                prepared,
                condition,
                args.device,
                args.x_margin,
                args.y_margin,
            )
            summary["results"].setdefault(split, {})[condition] = block(results[condition])
            print(
                json.dumps(
                    {
                        "split": split,
                        "condition": condition,
                        **summary["results"][split][condition],
                    }
                ),
                flush=True,
            )
            write_json(
                args.output / f"per_tree_{split}_{condition.replace('+', '_')}.json",
                results[condition],
            )
        summary["paired"][split] = {
            "full -> strip": paired(results["full"], results["strip"]),
            "full -> strip+pos": paired(results["full"], results["strip+pos"]),
            "strip -> strip+pos": paired(results["strip"], results["strip+pos"]),
        }
        write_json(args.output / "summary.json", summary)
    write_json(args.output / "summary.json", summary)
    print("DONE", json.dumps(summary["paired"]))


if __name__ == "__main__":
    main()
