"""No-training ablation of visible identity support for all three part readouts."""

from __future__ import annotations

import sys

import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, predict, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from whole_tree_objective import competitive_decode  # noqa: E402


def main():
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = ROOT / "reports/part-readout-controlled-2026-11-08"
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = (
        Sam2OcclusionModel(base, enable_crown=True, enable_stem=True, expose_query_features=True)
        .to(device)
        .eval()
    )
    frozen = torch.load(
        ROOT / "reports/part-readout-pilot-2026-11-08/decoder-final.pth",
        map_location="cpu",
        weights_only=True,
    )
    model.decoder.load_state_dict(frozen["decoder"], strict=True)
    heads = {k: getattr(model.decoder, k + "_hypernet") for k in ("stem", "crown")}
    states = {
        arm: torch.load(out / f"{arm}-final.pth", map_location="cpu", weights_only=True)["heads"]
        for arm in ("baseline", "stem_weighted", "native_gt")
    }
    dataset = PairedFigDataset(ROOT / "reports/fig-paired-v6-framing-30-2026-11-08", "validation")
    rows = []
    with torch.no_grad():
        for i, record in enumerate(dataset.items):
            if record["condition"] != "scene":
                continue
            sample = dataset.sample(i)
            inputs, _ = tensors(sample, device)
            result = model(**inputs)
            native = {
                key: np.stack([dataset._native_mask(item[key]) for item in record["instances"]])
                for key in (
                    "visible_stem",
                    "visible_crown",
                    "raster_unknown",
                    "visible_part_unknown",
                )
            }
            valid = torch.from_numpy(
                ~(native["raster_unknown"] | native["visible_part_unknown"])
            ).to(device)
            height, width = valid.shape[-2:]
            visible = F.interpolate(
                result["masks"][0], size=(height, width), mode="bilinear", align_corners=False
            )[:, 0]
            supports = {
                "raw": torch.ones_like(visible, dtype=torch.bool),
                "own_visible": visible > 0,
                "mask_winner": competitive_decode(visible),
            }
            for arm, state in states.items():
                predictions = {}
                for name, head in heads.items():
                    head.load_state_dict(state[name], strict=True)
                    logits = predict(
                        head, result[name + "_token_features"], result["query_pixel_embeddings"]
                    )
                    predictions[name] = (
                        F.interpolate(
                            logits, size=(height, width), mode="bilinear", align_corners=False
                        )[0]
                        > 0
                    )
                for mode, support in supports.items():
                    metrics = {"id": record["id"], "arm": arm, "mode": mode}
                    for name in heads:
                        pred = predictions[name] & support & valid
                        target = torch.from_numpy(native["visible_" + name]).to(device) & valid
                        intersection = (pred & target).sum((-2, -1)).float()
                        metrics[name + "_iou"] = float(
                            (intersection / (pred | target).sum((-2, -1)).clamp_min(1)).mean()
                        )
                        metrics[name + "_recall"] = float(
                            (intersection / target.sum((-2, -1)).clamp_min(1)).mean()
                        )
                        if name == "stem":
                            others = target.sum(0)[None] - target.long() > 0
                            metrics["neighbour_stem_fraction"] = float(
                                (
                                    (pred & others).sum((-2, -1)) / pred.sum((-2, -1)).clamp_min(1)
                                ).mean()
                            )
                    rows.append(metrics)
    summary = {}
    for arm in states:
        summary[arm] = {}
        for mode in supports:
            selected = [r for r in rows if r["arm"] == arm and r["mode"] == mode]
            summary[arm][mode] = {
                k: float(np.mean([r[k] for r in selected]))
                for k in selected[0]
                if k not in ("id", "arm", "mode")
            }
    write(
        out / "identity-support-audit.json",
        {
            "training": False,
            "learned_ownership": False,
            "postprocessing_only": True,
            "validation_scenes": 10,
            "mask_resolution": [640, 360],
            "summary": summary,
            "records": rows,
            "test_accessed": False,
            "promoted": False,
        },
    )
    print(summary)


if __name__ == "__main__":
    main()
