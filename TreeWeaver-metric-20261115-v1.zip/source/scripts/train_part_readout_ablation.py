"""Same features/init/order/budget: baseline vs stem weighting vs native GT."""

from __future__ import annotations

import argparse
import copy
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, predict, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from part_readout_objective import part_loss  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261108)
    parser.add_argument(
        "--out", type=Path, default=ROOT / "reports/part-readout-controlled-2026-11-08"
    )
    args = parser.parse_args()
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = args.out
    out.mkdir(exist_ok=False)
    data = ROOT / "reports/fig-paired-v6-framing-30-2026-11-08"
    scope = assert_training_allowed(data)
    previous = ROOT / "reports/part-readout-pilot-2026-11-08"
    saved = torch.load(previous / "readouts-final.pth", map_location="cpu", weights_only=True)
    full = torch.load(previous / "decoder-final.pth", map_location="cpu", weights_only=True)
    protocol = {
        "arms": ["baseline", "stem_weighted", "native_gt"],
        "seed": args.seed,
        "seed_scope": "sample order only; fixed features, tokens and initial readouts across seeds",
        "epochs": 20,
        "lr": 0.001,
        "steps_per_arm": 700,
        "init": str(previous),
        "init_sha256": sha256_file(previous / "decoder-final.pth"),
        "data": str(data),
        "scope": scope,
        "manifest_sha256": sha256_file(data / "paired-samples.json"),
        "split_sha256": sha256_file(data / "splits.json"),
        "shared": "same cached features, tokens, initial readouts and sample order",
        "native_gt_changes_prompts": False,
        "test_accessed": False,
        "evaluation": "all arms native640x360, 10 validation scenes, scene macro",
        "changes_visible_ownership": False,
        "promoted": False,
    }
    write(out / "protocol.json", protocol)
    (out / "source").mkdir()
    for path in (Path(__file__), ROOT / "workers/tree_models/part_readout_objective.py"):
        (out / "source" / path.name).write_bytes(path.read_bytes())
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = (
        Sam2OcclusionModel(base, enable_crown=True, enable_stem=True, expose_query_features=True)
        .to(device)
        .eval()
    )
    model.decoder.load_state_dict(full["decoder"], strict=True)
    model.requires_grad_(False)
    cache = {}
    with torch.no_grad():
        for split in ("train", "validation"):
            dataset = PairedFigDataset(data, split)
            cache[split] = []
            for i, record in enumerate(dataset.items):
                sample = dataset.sample(i)
                inputs, _ = tensors(sample, device)
                result = model(**inputs)
                native = {}
                for key in (
                    "visible_crown",
                    "visible_stem",
                    "raster_unknown",
                    "visible_part_unknown",
                ):
                    native[key] = np.stack(
                        [dataset._native_mask(item[key]) for item in record["instances"]]
                    )
                known = ~(native["raster_unknown"] | native["visible_part_unknown"])
                entry = {
                    "id": record["id"],
                    "condition": record["condition"],
                    "features": result["query_pixel_embeddings"].cpu(),
                    "crown_tokens": result["crown_token_features"].cpu(),
                    "stem_tokens": result["stem_token_features"].cpu(),
                    "valid": torch.from_numpy(sample["visible_part_valid"])[None],
                    "native_valid": torch.from_numpy(known)[None],
                }
                for name in ("crown", "stem"):
                    entry[name] = torch.from_numpy(sample[f"visible_{name}"])[None]
                    entry[f"native_{name}"] = torch.from_numpy(native[f"visible_{name}"])[None]
                cache[split].append(entry)
                if i % 10 == 0:
                    print(f"cached {split} {i + 1}/{len(dataset)}", flush=True)
    heads = {name: getattr(model.decoder, f"{name}_hypernet") for name in ("crown", "stem")}
    for head in heads.values():
        head.requires_grad_(True)
    rng = random.Random(args.seed)
    order = []
    for _ in range(20):
        epoch = list(range(len(cache["train"])))
        rng.shuffle(epoch)
        order.extend(epoch)

    def forward(row, name):
        return predict(heads[name], row[f"{name}_tokens"].to(device), row["features"].to(device))

    def native_logits(logits, row):
        return F.interpolate(
            logits, size=row["native_valid"].shape[-2:], mode="bilinear", align_corners=False
        )

    @torch.no_grad()
    def evaluate():
        rows = []
        for row in cache["validation"]:
            valid = row["native_valid"].to(device)
            metrics = {"id": row["id"], "condition": row["condition"]}
            predictions = {}
            for name in heads:
                pred = (native_logits(forward(row, name), row) > 0) & valid
                predictions[name] = pred
                target = row[f"native_{name}"].to(device) & valid
                intersection = (pred & target).sum((-2, -1)).float()
                metrics[f"{name}_iou"] = float(
                    (intersection / (pred | target).sum((-2, -1)).clamp_min(1)).mean()
                )
                metrics[f"{name}_recall"] = float(
                    (intersection / target.sum((-2, -1)).clamp_min(1)).mean()
                )
                metrics[f"{name}_precision"] = float(
                    (intersection / pred.sum((-2, -1)).clamp_min(1)).mean()
                )
                if name == "stem":
                    others = (target.sum(1, keepdim=True) - target.long()) > 0
                    metrics["neighbour_stem_fraction"] = float(
                        ((pred & others).sum((-2, -1)) / pred.sum((-2, -1)).clamp_min(1)).mean()
                    )
            metrics["part_overlap_fraction"] = float(
                (predictions["crown"] & predictions["stem"]).sum()
                / (predictions["crown"] | predictions["stem"]).sum().clamp_min(1)
            )
            rows.append(metrics)
        scenes = [r for r in rows if r["condition"] == "scene"]
        return {
            "scene_macro": {
                k: sum(r[k] for r in scenes) / len(scenes)
                for k in scenes[0]
                if k not in ("id", "condition")
            },
            "records": rows,
        }

    results = {}
    for arm in protocol["arms"]:
        for name, head in heads.items():
            head.load_state_dict(saved["initial"][name], strict=True)
        optimizer = torch.optim.AdamW([p for h in heads.values() for p in h.parameters()], lr=0.001)
        history = []
        for step, index in enumerate(order):
            row = cache["train"][index]
            optimizer.zero_grad(set_to_none=True)
            loss = torch.zeros((), device=device)
            for name in heads:
                logits = forward(row, name)
                prefix = "native_" if arm == "native_gt" else ""
                if prefix:
                    logits = native_logits(logits, row)
                loss = loss + part_loss(
                    logits,
                    row[prefix + name].to(device),
                    row[prefix + "valid"].to(device),
                    foreground_weighted=arm == "stem_weighted" and name == "stem",
                )
            if not torch.isfinite(loss):
                raise ValueError("nonfinite loss")
            loss.backward()
            optimizer.step()
            history.append(float(loss.detach()))
            if (step + 1) % 175 == 0:
                print(f"{arm}: {step + 1}/700 loss={np.mean(history[-35:]):.5f}", flush=True)
        results[arm] = evaluate()
        results[arm]["train_loss"] = history
        torch.save(
            {
                "heads": {k: copy.deepcopy(h.state_dict()) for k, h in heads.items()},
                "protocol": protocol,
                "arm": arm,
            },
            out / f"{arm}-final.pth",
        )
        write(out / "results.json", results)
        print(json.dumps({"arm": arm, "metrics": results[arm]["scene_macro"]}), flush=True)
    baseline = results["baseline"]["scene_macro"]
    acceptance = {}
    for arm in protocol["arms"][1:]:
        candidate = results[arm]["scene_macro"]
        acceptance[arm] = bool(
            candidate["stem_iou"] > baseline["stem_iou"] + 0.01
            and candidate["stem_recall"] >= baseline["stem_recall"] - 0.005
            and candidate["crown_iou"] >= baseline["crown_iou"] - 0.005
            and candidate["neighbour_stem_fraction"] <= baseline["neighbour_stem_fraction"] + 0.001
        )
    write(
        out / "acceptance.json",
        {
            "development_gate": acceptance,
            "promotion": False,
            "requires": "multi-seed, more shapes and independent real validation",
        },
    )


if __name__ == "__main__":
    main()
