"""Build GT masks and a preview sheet from Blender pair renders."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

COLOURS = [(60, 80, 240), (240, 160, 60), (80, 200, 80)]  # target, left, right


def load_mask(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None or image.shape[2] != 4:
        raise ValueError(path)
    return image[:, :, 3] > 128


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--name", default="pair_00")
    args = parser.parse_args()
    root = args.input
    name = args.name

    rgb = cv2.imread(str(root / f"{name}_rgb.png"), cv2.IMREAD_COLOR)
    target = load_mask(root / f"{name}_target.png")
    left = load_mask(root / f"{name}_left.png")
    right = load_mask(root / f"{name}_right.png")
    amodal = [target, left, right]
    visible = [target & ~(left | right), left.copy(), right.copy()]

    height, width = target.shape
    ys, xs = np.nonzero(target)
    target_fraction = (ys.max() - ys.min()) / height
    stats = []
    for index, mask in enumerate(amodal):
        stats.append(
            {
                "tree": index,
                "amodal_pixels": int(mask.sum()),
                "visible_pixels": int(visible[index].sum()),
                "occlusion_rate": 1.0 - float(visible[index].sum()) / max(int(mask.sum()), 1),
            }
        )

    ownership = np.zeros((height, width), np.uint8)
    for index, mask in enumerate(visible):
        ownership[mask] = index + 1

    def overlay(masks, background):
        panel = (
            background.copy()
            if background is not None
            else np.zeros((height, width, 3), np.uint8)
        )
        for index, mask in enumerate(masks):
            colour = np.array(COLOURS[index], np.float32)
            panel[mask] = (0.55 * panel[mask] + 0.45 * colour).astype(np.uint8)
        return panel

    panels = [
        ("composite", rgb),
        ("visible GT", overlay(visible, None)),
        ("amodal GT", overlay(amodal, None)),
        ("ownership", overlay(visible, None)),
    ]
    panel_w, panel_h = 480, 270
    gap = 8
    sheet = np.full((44 + 2 * (panel_h + 30), 2 * (panel_w + gap), 3), 30, np.uint8)
    for index, (title, panel) in enumerate(panels):
        row, col = divmod(index, 2)
        x0 = col * (panel_w + gap)
        y0 = 44 + row * (panel_h + 30)
        cv2.putText(
            sheet, title, (x0 + 6, y0 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (220, 220, 220), 1
        )
        sheet[y0 : y0 + panel_h, x0 : x0 + panel_w] = cv2.resize(panel, (panel_w, panel_h))
    header = (
        f"{name}: target height={target_fraction * 100:.0f}%  "
        f"target occlusion={stats[0]['occlusion_rate'] * 100:.1f}%"
    )
    cv2.putText(sheet, header, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (230, 230, 230), 1)
    cv2.imwrite(str(root / f"{name}_preview.png"), sheet)
    np.savez_compressed(
        root / f"{name}_gt.npz",
        amodal=np.stack(amodal),
        visible=np.stack(visible),
        ownership=ownership,
    )
    (root / f"{name}_gt.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps({"target_height_fraction": target_fraction, "stats": stats}, indent=2))
    print(f"saved {root / f'{name}_preview.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
