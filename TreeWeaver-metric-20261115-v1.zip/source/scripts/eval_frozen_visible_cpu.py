"""Evaluate the CPU LoRA pilot on all frozen validation targets."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
CKPT = ROOT / "reports/frozen-visible-cpu-pilot-2026-11-09/checkpoint.pth"
OUT = ROOT / "reports/frozen-visible-cpu-pilot-2026-11-09/eval-25.json"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask_tensor(path):
    image = np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16
    image = Image.fromarray(image.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)
    return torch.from_numpy(np.asarray(image, dtype=np.float32) / 255.0)[None, None]


def boxes(row):
    x0, y0, x1, y1 = row["box_xyxy"]
    width, height = row["mask_wh"]
    return torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.endswith(("lora_a", "lora_b")):
            parameter.requires_grad_(True)
    return model


def evaluate(model, rows):
    values = []
    with torch.no_grad():
        for row in rows:
            output = model(image_tensor(row["paths"]["image"]), input_boxes=boxes(row))
            prediction = output["masks"][0, 0, 0].sigmoid() > 0.5
            target = mask_tensor(row["paths"]["visible"])[0, 0] > 0.5
            intersection = (prediction & target).sum().item()
            union = (prediction | target).sum().item()
            values.append(intersection / union if union else 1.0)
    return float(np.mean(values)), values


def main():
    torch.set_num_threads(2)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    rows = index["validation"]["records"]
    model = build()
    before, _ = evaluate(model, rows)
    state = torch.load(CKPT, map_location="cpu", weights_only=True)
    model.load_state_dict(state["lora"], strict=False)
    after, per_target = evaluate(model, rows)
    result = {
        "validation_targets": len(rows),
        "before_visible_iou": before,
        "after_visible_iou": after,
        "delta": after - before,
        "per_target_iou": per_target,
    }
    OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("validation_targets", "before_visible_iou", "after_visible_iou", "delta")}, indent=2))


if __name__ == "__main__":
    main()
