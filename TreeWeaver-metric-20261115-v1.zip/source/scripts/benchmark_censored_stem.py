"""Synthetic falsification of censored image-width bounds; no field-accuracy claim."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

from treeweaver.geometry.censored_stem import (
    StemRowEvidence,
    WidthBoundStatus,
    bound_projected_stem_width,
)


def _fit_width(rows: tuple[StemRowEvidence, ...], mode: str) -> float | None:
    intercepts: list[float] = []
    for side in ("left", "right"):
        chosen = [
            row for row in rows if mode != "exposed_only" or getattr(row, f"{side}_is_exposed_edge")
        ]
        if len(chosen) < 2:
            return None
        matrix = np.asarray([[1, (row.y_px - 50) / 100] for row in chosen])
        values = np.asarray([getattr(row, f"{side}_visible_px") for row in chosen])
        initial = np.linalg.lstsq(matrix, values, rcond=None)[0]
        fitted = (
            least_squares(
                lambda p, a=matrix, b=values: a @ p - b, initial, loss="huber", f_scale=1
            ).x
            if mode == "huber"
            else initial
        )
        intercepts.append(float(fitted[0]))
    return intercepts[1] - intercepts[0]


def trial(seed: int, scenario: str) -> dict[str, object]:
    random = np.random.default_rng(seed)
    width = float(random.uniform(20, 100))
    slope = float(random.uniform(-20, 20))
    taper = float(random.uniform(-4, 4))
    rows: list[StemRowEvidence] = []
    for index, y in enumerate(np.linspace(0, 100, 30)):
        t = (float(y) - 50) / 100
        left = 100 + slope * t
        right = left + width + taper * t
        if scenario == "curved_stem":
            left += 20 * t * t
            right += 20 * t * t
        visible_left, visible_right = left, right
        left_exposed = right_exposed = True
        if scenario == "alternating_occlusion":
            loss = float(random.uniform(0.25, 0.60)) * (right - left)
            if index % 2:
                visible_left += loss
                left_exposed = False
            else:
                visible_right -= loss
                right_exposed = False
        elif scenario in {"permanent_right_occlusion", "wrong_visibility_labels"}:
            visible_right = left + 0.6 * (right - left)
            right_exposed = scenario == "wrong_visibility_labels"
        rows.append(
            StemRowEvidence(
                float(y),
                visible_left + float(random.uniform(-0.5, 0.5)),
                visible_right + float(random.uniform(-0.5, 0.5)),
                left_exposed,
                right_exposed,
            )
        )
    observations = tuple(rows)
    bounds = bound_projected_stem_width(observations, 50, pixel_tolerance=0.5)
    contains = (
        bounds.minimum_width_px is not None
        and bounds.minimum_width_px <= width + 1e-6
        and (bounds.maximum_width_px is None or width <= bounds.maximum_width_px + 1e-6)
    )
    estimates = {
        name: _fit_width(observations, name) for name in ("ordinary", "huber", "exposed_only")
    }
    return {
        "seed": seed,
        "scenario": scenario,
        "true_projected_width_px": width,
        "bounds": asdict(bounds),
        "conditional_interval_contains_truth": contains,
        "baseline_absolute_errors_px": {
            name: abs(value - width) if value is not None else None
            for name, value in estimates.items()
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output_json")
    parser.add_argument("--seeds", type=int, default=60)
    args = parser.parse_args()
    if args.seeds < 1:
        raise ValueError("seeds must be positive")
    output = Path(args.output_json).resolve()
    if output.exists():
        raise FileExistsError(output)
    scenarios = (
        "clear",
        "alternating_occlusion",
        "permanent_right_occlusion",
        "curved_stem",
        "wrong_visibility_labels",
    )
    records = [trial(seed, scenario) for scenario in scenarios for seed in range(args.seeds)]
    summaries = []
    for scenario in scenarios:
        subset = [row for row in records if row["scenario"] == scenario]
        summary = {
            "scenario": scenario,
            "attempted": len(subset),
            "status_counts": {
                status.value: sum(row["bounds"]["status"] == status for row in subset)
                for status in WidthBoundStatus
            },
            "truth_contained_count": sum(
                row["conditional_interval_contains_truth"] for row in subset
            ),
            "baseline_mae_px": {},
        }
        for name in ("ordinary", "huber", "exposed_only"):
            values = [row["baseline_absolute_errors_px"][name] for row in subset]
            present = [value for value in values if value is not None]
            summary["baseline_mae_px"][name] = float(np.mean(present)) if present else None
        summaries.append(summary)
        print(json.dumps(summary), flush=True)
    payload = {
        "schema_version": "censored-projected-stem-synthetic-1.0",
        "interpretation": "Synthetic pixel-width experiment, not metric DBH or field accuracy",
        "visibility_labels": "Oracle labels except explicitly corrupted wrong_visibility_labels",
        "assumptions": (
            "Local linear boundaries; independently located query row; bounded pixel noise"
        ),
        "summaries": summaries,
        "records": records,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
