"""Capture the actual BCE tensors inside lincomb_mask_loss (throwaway)."""
from __future__ import annotations
import json, random, sys
from pathlib import Path
sys.path.insert(0, r".worker-envs\convexmask-extra")
sys.path.insert(0, r"data/external/convexmask-source")
import cv2
import numpy as np
import torch
import torch.nn.functional as F
from data import cfg, set_cfg
torch.set_default_tensor_type(torch.cuda.FloatTensor)
set_cfg("convex_synthtree_focal")
cfg.max_size = (512, 512)
cfg.fixed_size = True
cfg.freeze_bn = True
cfg.mask_proto_debug = False
cfg.dataset.class_names = ("tree",)
from convexmask import ConvexMask
from layers.modules import multibox_loss as MBL

pal = {int(k): tuple(v) for k, v in json.loads(
    Path("data/external/spread/color_palette.json").read_text(encoding="utf-8"))["palette"].items()}
root = Path("data/external/spread/birch_forest")
rng = random.Random(42)
frames = sorted(p.stem for p in (root / "rgb").glob("*.png"))
rng.shuffle(frames)
stem = frames[0]
image = cv2.imread(str(root / "rgb" / f"{stem}.png"))
inst = cv2.cvtColor(cv2.imread(str(root / "instance_segmentation" / f"{stem}.png")), cv2.COLOR_BGR2RGB)
cands = []
for line in (root / "instance_segmentation" / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
    pr = line.split()
    if len(pr) == 2 and pr[0].startswith("Tree") and int(pr[1]) in pal:
        c = pal[int(pr[1])]
        mm = cv2.inRange(inst, np.array(c), np.array(c))
        if int(mm.sum() // 255) >= 10:
            cands.append((int(mm.sum() // 255), mm))
cands.sort(key=lambda x: x[0], reverse=True)
cands = cands[:24]
masks, boxes, hulls = [], [], []
for _, mm in cands:
    mm = (cv2.resize(mm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
    ys, xs = np.nonzero(mm)
    if len(xs) >= 10:
        cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        hulls.append(cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32) / 512)
        masks.append(mm)
        boxes.append([xs.min()/512, ys.min()/512, (xs.max()+1)/512, (ys.max()+1)/512, 0])
polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
for i, h in enumerate(hulls):
    polys[i, :len(h)] = h
resized = cv2.resize(image, (512, 512)).astype(np.float32)
resized = ((resized - np.array([103.94, 116.78, 123.68])) / np.array([57.38, 57.12, 58.40]))[:, :, ::-1].copy()
tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)

ckpt = sys.argv[1] if len(sys.argv) > 1 else "reports/convexmask-spread-2026-10-13-debug3/pilot_checkpoint.pth"
model = ConvexMask().cuda()
model.load_state_dict(torch.load(ckpt, map_location="cuda"))
model.train()

captured = {}
orig_bce = F.binary_cross_entropy_with_logits
def spy_bce(pred, target, **kw):
    captured["pred"] = pred.detach()
    captured["tgt"] = target.detach()
    return orig_bce(pred, target, **kw)
MBL.F.binary_cross_entropy_with_logits = spy_bce

crit = MBL.MultiBoxLoss(1, 72, 3)
with torch.no_grad():
    pred = model(tensor[None].cuda())
    losses = crit(model, pred,
                  [torch.tensor(boxes, dtype=torch.float32).cuda()],
                  [torch.tensor(np.stack(masks), dtype=torch.float32).cuda()],
                  [torch.tensor(polys, dtype=torch.float32).cuda()],
                  [0])
    print("losses:", {k: round(float(v), 4) for k, v in losses.items()})
    pm = captured["pred"]
    tm = captured["tgt"]
    # -10 = outside crop (ignored)
    inside = pm > -9.5
    print("pred logits inside crop: mean", float(pm[inside].mean()),
          "max", float(pm[inside].max()), "min", float(pm[inside].min()))
    print("sigmoid inside crop: mean", float(pm[inside].sigmoid().mean()),
          "share>0.5", float((pm[inside].sigmoid() > 0.5).float().mean()))
    # Among crop pixels where GT target == 1
    gt1 = inside & (tm > 0.5)
    gt0 = inside & (tm <= 0.5)
    print("crop pixels GT=1:", int(gt1.sum()), " sigmoid mean", float(pm[gt1].sigmoid().mean()),
          "share>0.5", float((pm[gt1].sigmoid() > 0.5).float().mean()))
    print("crop pixels GT=0:", int(gt0.sum()), " sigmoid mean", float(pm[gt0].sigmoid().mean()))
    # Per-mask crop/GT alignment
    crop_m = inside.float()
    gt_m = (tm > 0.5).float()
    inter = (crop_m * gt_m).sum((0, 1))
    union = crop_m.sum((0, 1)) + gt_m.sum((0, 1)) - inter
    iou = inter / union.clamp_min(1)
    print("per-mask crop vs GT IoU: mean", float(iou.mean()), "median", float(iou.median()),
          "min", float(iou.min()), "max", float(iou.max()))
    print("per-mask GT px: mean", float(gt_m.sum((0, 1)).mean()),
          " | per-mask crop px: mean", float(crop_m.sum((0, 1)).mean()))
    # How many of the 100 masks have any real positive coverage
    covered = (inter > 20).float().mean()
    print("fraction of trained masks with >20 px GT overlap:", float(covered))

    # Reproduce the crop ourselves (with vs without convex indices) to isolate
    from layers.polar_utils import polar_target, polar2mask, detect_convex_indices
    pts = pred["points"]
    rr = pred["regress_ranges"]
    lab, bbt, pt, idxt, cent = polar_target(
        torch.tensor(boxes, dtype=torch.float32)[:, :-1].cuda(),
        torch.tensor(polys, dtype=torch.float32).cuda(),
        torch.zeros(len(boxes), dtype=torch.long).cuda(),
        pts, rr, cfg.num_rays, pred["img_size"], None, cfg.radius, cfg.force_gt_attribute)
    posp = lab > 0
    pos_pts = pts[posp]
    ray = pred["polygon"][0][posp]
    gt_down = tm  # (128,128,k) from capture, but that was the sampled 100; just rebuild full GT
    gtm = F.interpolate(torch.tensor(np.stack(masks), dtype=torch.float32).cuda()[None],
                        (128, 128), mode="nearest")[0].permute(1, 2, 0)  # (128,128,N)
    gi = idxt[posp]
    for tag, use_conv in [("raw", False), ("convex", True)]:
        rr2 = ray.clone()
        if use_conv:
            rr2 = rr2 * detect_convex_indices(rr2.clone())
        crop = polar2mask(pos_pts.clone(), rr2.clone() * (1 + cfg.extend_factor), (128, 128))
        cropf = crop.float()
        gtsel = gtm[:, :, gi]
        ii = (cropf * gtsel).sum((0, 1))
        uu = cropf.sum((0, 1)) + gtsel.sum((0, 1)) - ii
        iou2 = ii / uu.clamp_min(1)
        print(f"[{tag}] crop vs GT IoU mean={float(iou2.mean()):.3f} "
              f"crop px/mask={float(cropf.sum((0,1)).mean()):.0f} "
              f"GT px/mask={float(gtsel.sum((0,1)).mean()):.0f}")
