"""Exact CPU viewport crops of paired data; no render, hallucination or mask resize."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from focal_view_protocol import focal_viewport
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
MASK_KEYS = (
    "visible",
    "amodal",
    "visible_stem",
    "amodal_stem",
    "visible_crown",
    "amodal_crown",
    "raster_unknown",
    "visible_part_unknown",
    "amodal_part_unknown",
)


def mask(path):
    with Image.open(path) as im:
        return np.asarray(im.getchannel("A")) > 16


def main():
    source = ROOT / "reports/mixed-identity-layout-qualification-2026-11-08"
    destination = ROOT / "reports/focal-view-qualification-2026-11-09"
    destination.mkdir(exist_ok=False)
    for name in ("images", "masks", "controls"):
        (destination / name).mkdir()
    manifest = json.loads((source / "paired-samples.json").read_text())
    splits = json.loads((source / "splits.json").read_text())
    records = []
    views = []
    hashes = {}
    checks = 0

    def path(relative):
        result = (source / relative).resolve()
        if not result.is_relative_to(source.resolve()):
            raise ValueError("source outside pinned data root")
        if relative not in hashes:
            hashes[relative] = hashlib.sha256(result.read_bytes()).hexdigest()
        return result

    def crop_file(relative, target, roi):
        with Image.open(path(relative)) as image:
            image.crop(roi).save(destination / target)
        return target

    for scene in manifest["records"]:
        if scene["split"] != "train" or scene["condition"] != "scene":
            continue
        amodals = [mask(path(item["amodal"])) for item in scene["instances"]]
        for focal_index, focal in enumerate(amodals):
            view = focal_viewport(focal)
            roi = view["roi_xyxy"]
            x0, y0, x1, y1 = roi
            index = len(views) + 1
            prefix = f"{index:06d}"
            folder = destination / "masks" / prefix
            folder.mkdir()
            kept = [q for q, value in enumerate(amodals) if value[y0:y1, x0:x1].any()]
            instances = []
            visible = []
            focal_new_index = None
            for new_index, old_index in enumerate(kept, 1):
                item = scene["instances"][old_index]
                entry = {
                    "asset": item["asset"],
                    "source_tree_index": new_index,
                    "original_tree_index": old_index + 1,
                }
                for key in MASK_KEYS:
                    entry[key] = crop_file(item[key], f"masks/{prefix}/{key}_{new_index}.png", roi)
                v = mask(destination / entry["visible"])
                a = mask(destination / entry["amodal"])
                if (v & ~a).any():
                    raise AssertionError("visible outside complete support")
                visible.append(v)
                for mode in ("visible", "amodal"):
                    parts = [
                        mask(destination / entry[mode + "_" + part]) for part in ("stem", "crown")
                    ]
                    parts.append(mask(destination / entry[mode + "_part_unknown"]))
                    support = v if mode == "visible" else a
                    if not np.array_equal(np.stack(parts).sum(0), support.astype(int)):
                        raise AssertionError("part partition damaged")
                    checks += 1
                truncated = int(a.sum()) < int(amodals[old_index].sum())
                source_a = amodals[old_index]
                truncated |= bool(item.get("frame_truncated", False)) or bool(
                    source_a[0].any()
                    or source_a[-1].any()
                    or source_a[:, 0].any()
                    or source_a[:, -1].any()
                )
                entry["frame_truncated"] = truncated
                entry["amodal_supervision_allowed"] = not truncated and bool(
                    item.get("amodal_supervision_allowed", True)
                )
                entry["focal_target"] = old_index == focal_index
                if entry["focal_target"]:
                    if truncated:
                        raise AssertionError("focal support lost")
                    focal_new_index = new_index
                instances.append(entry)
                control = f"controls/{prefix}-target{new_index}.png"
                original_control = next(
                    r
                    for r in manifest["records"]
                    if r["group_id"] == scene["group_id"]
                    and r["condition"] == "isolated"
                    and r["instances"][0]["source_tree_index"] == item["source_tree_index"]
                )
                crop_file(original_control["image"], control, roi)
                # Same known isolated target support, never reconstruct an unseen contour.
                isolated = dict(entry)
                isolated.update(
                    {
                        "visible": entry["amodal"],
                        "visible_stem": entry["amodal_stem"],
                        "visible_crown": entry["amodal_crown"],
                        "visible_part_unknown": entry["amodal_part_unknown"],
                    }
                )
                records.append(
                    {
                        "id": prefix + f"-control-{new_index}",
                        "group_id": scene["group_id"],
                        "split": "train",
                        "condition": "isolated",
                        "image": control,
                        "instances": [isolated],
                    }
                )
            native = np.stack(visible)
            if (native.sum(0) > 1).any():
                raise AssertionError("visible ID overlap")
            ids = (native * np.arange(1, len(native) + 1)[:, None, None]).sum(0).astype(np.uint16)
            Image.fromarray(ids).save(folder / "instance_ids.png")
            image = crop_file(scene["image"], f"images/{prefix}.png", roi)
            records.append(
                {
                    "id": prefix + "-scene",
                    "group_id": scene["group_id"],
                    "split": "train",
                    "condition": "scene",
                    "image": image,
                    "instances": instances,
                }
            )
            views.append(
                {
                    "view": prefix,
                    "source_scene": scene["id"],
                    "source_group": scene["group_id"],
                    "source_focal_index": focal_index + 1,
                    "focal_index": focal_new_index,
                    "asset": scene["instances"][focal_index]["asset"],
                    "mainline_scale_candidate": view["height_fraction"] >= 0.45,
                    **view,
                }
            )
    (destination / "paired-samples.json").write_text(
        json.dumps({"schema_version": "treeweaver-paired-1.0", "records": records}, indent=2),
        encoding="utf-8",
    )
    (destination / "splits.json").write_text(json.dumps(splits, indent=2), encoding="utf-8")
    audit = {
        "status": "viewport/label qualification only; no model inference or training",
        "source": str(source),
        "source_file_sha256": hashes,
        "views": views,
        "paired_records": len(records),
        "source_groups": len({v["source_group"] for v in views}),
        "partitions_checked": checks,
        "focal_pixels_preserved": True,
        "native_masks_resized": False,
        "RGB_resized": False,
        "training_allowed": False,
        "test_accessed": False,
        "limitations": [
            "repeated viewports are not new trees or independent scenes",
            "same simple background",
            "cropped neighbour A is within-view support; full-tree completion gate required",
        ],
    }
    (destination / "viewport-audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    selected = [
        views[0],
        next(v for v in views if v["width_limited"]),
        next(v for v in views if "dense" in v["asset"]),
    ]
    sheet = Image.new("RGB", (1200, 660), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 17)
    for row, view in enumerate(selected):
        source_scene = next(r for r in manifest["records"] if r["id"] == view["source_scene"])
        with Image.open(path(source_scene["image"])) as im:
            preview = ImageOps.contain(im.convert("RGB"), (210, 580))
            sheet.paste(preview, (row * 400, 55))
        with Image.open(destination / "images" / f"{view['view']}.png") as im:
            preview = ImageOps.contain(im.convert("RGB"), (185, 580))
            sheet.paste(preview, (row * 400 + 210, 55))
        draw.text(
            (row * 400 + 3, 4),
            f"{view['view']} focal height {view['height_fraction']:.1%}",
            font=font,
            fill="black",
        )
        draw.text(
            (row * 400 + 3, 26), "Source | exact viewport; no new pixels", font=font, fill="black"
        )
    sheet.save(destination / "viewport-preview.jpg", quality=94)
    print(json.dumps({k: v for k, v in audit.items() if k not in ("source_file_sha256", "views")}))


if __name__ == "__main__":
    main()
