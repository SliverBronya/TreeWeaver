"""Read-only RGB review sheets; never infer hidden-area ground truth from RGB."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("data/20260411"))
    parser.add_argument(
        "--out", type=Path, default=Path("reports/real-occlusion-reference-2026-11-08")
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    photos = sorted(args.source.glob("*.jpg"), key=lambda path: int(path.stem))
    groups = defaultdict(list)
    records = []
    for path in photos:
        group = int(path.stem) // 1000
        groups[group].append(path)
        with Image.open(path) as im:
            size = list(im.size)
        records.append(
            {
                "file": path.as_posix(),
                "provisional_capture_group": group,
                "size": size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)
    sheets = []
    for name, paths in (
        ("representatives", [paths[0] for paths in groups.values()]),
        ("all-views", photos),
    ):
        for start in range(0, len(paths), 15):
            selection = paths[start : start + 15]
            sheet = Image.new("RGB", (1200, 1400), "white")
            draw = ImageDraw.Draw(sheet)
            draw.text(
                (8, 8),
                f"20260411 / {name} / {start + 1}-{start + len(selection)}; RGB only",
                font=font,
                fill="black",
            )
            for index, path in enumerate(selection):
                x, y = (index % 5) * 240, 38 + (index // 5) * 450
                with Image.open(path) as im:
                    thumb = ImageOps.contain(ImageOps.exif_transpose(im).convert("RGB"), (236, 420))
                    sheet.paste(thumb, (x, y + 24))
                draw.text((x + 5, y), path.name, font=font, fill="black")
            target = args.out / f"{name}-{start // 15 + 1:02d}.jpg"
            sheet.save(target, quality=92)
            sheets.append(target.as_posix())
    manifest = {
        "source": args.source.as_posix(),
        "photos": records,
        "photo_count": len(photos),
        "provisional_group_count": len(groups),
        "grouping_rule": "integer filename // 1000; NOT verified physical-tree/site identity",
        "representative_rule": "first numerical filename per provisional group",
        "training_allowed": False,
        "independent_test": False,
        "hidden_area_ground_truth_available": False,
        "sheets": sheets,
    }
    (args.out / "inventory.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {"photos": len(photos), "provisional_groups": len(groups), "sheets": len(sheets)}
        )
    )


if __name__ == "__main__":
    main()
