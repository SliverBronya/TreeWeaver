"""Run the current occlusion-aware decoder on the hand-composited three-tree example.

Each GT tree box is used as a prompt; predictions are compared with the known
visible/amodal GT of the composite. This is an in-domain synthetic check, not a
real-photo accuracy result.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL = 300


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def precision_recall(prediction, target):
    tp = float((prediction & target).sum())
    precision = tp / max(float(prediction.sum()), 1.0)
    recall = tp / max(float(target.sum()), 1.0)
    return precision, recall


def hull_of(mask):
    contours = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )[0]
    hull = np.zeros_like(mask, np.uint8)
    if contours:
        cv2.fillPoly(hull, [cv2.convexHull(np.vstack(contours))], 1)
    return hull.astype(bool)


def panel(image, mask, colour, title):
    out = image.copy()
    if mask is not None:
        overlay = np.array(colour, np.float32)
        out[mask] = (0.55 * out[mask] + 0.45 * overlay).astype(np.uint8)
    cv2.putText(out, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 2)
    cv2.putText(out, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 1)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--composite", type=Path, required=True)
    parser.add_argument("--gt", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    image = cv2.imread(str(args.composite))
    if image is None:
        raise SystemExit(f"cannot read {args.composite}")
    height, width = image.shape[:2]
    gt = np.load(args.gt)
    amodal_gt = gt["amodal"]
    visible_gt = gt["visible"]
    boxes = gt["boxes"]
    layers = gt["layers"]

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    from PIL import Image

    pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    inputs = processor(images=pil, return_tensors="pt")
    scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)

    titles = ["input", "GT visible", "pred visible", "GT amodal", "pred amodal"]
    rows, headers, report = [], [], []
    for index in range(amodal_gt.shape[0]):
        box = boxes[index].astype(np.float32)
        pad = 0.05 * np.array([box[2] - box[0], box[3] - box[1]] * 2)
        padded = np.array(
            [box[0] - pad[0], box[1] - pad[1], box[2] + pad[0], box[3] + pad[1]], np.float32
        )
        scaled = torch.as_tensor(padded * scale, device=args.device)[None, None]
        with torch.no_grad():
            output = model(inputs["pixel_values"].to(args.device), input_boxes=scaled)
            pred_visible = processor.post_process_masks(
                output["masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
            pred_amodal = processor.post_process_masks(
                output["amodal_masks"], original_sizes=[[height, width]]
            )[0][0, 0].cpu().numpy() > 0
        visible_iou = iou(pred_visible, visible_gt[index])
        amodal_iou = iou(pred_amodal, amodal_gt[index])
        hull = hull_of(visible_gt[index])
        hull_iou = iou(hull, amodal_gt[index])
        precision, recall = precision_recall(pred_amodal, amodal_gt[index])
        visibility = output["visibility"][0, 0].cpu().numpy()

        ys, xs = np.nonzero(amodal_gt[index])
        margin = 0.15
        left = max(0, int(xs.min() - margin * (xs.max() - xs.min())))
        top = max(0, int(ys.min() - margin * (ys.max() - ys.min())))
        right = min(width, int(xs.max() + margin * (xs.max() - xs.min())))
        bottom = min(height, int(ys.max() + margin * (ys.max() - ys.min())))
        side = max(right - left, bottom - top)
        left = max(0, min(left, width - side))
        top = max(0, min(top, height - side))
        right, bottom = left + side, top + side

        def crop(mask, top=top, bottom=bottom, left=left, right=right):
            return cv2.resize(
                mask[top:bottom, left:right].astype(np.uint8),
                (PANEL, PANEL),
                interpolation=cv2.INTER_NEAREST,
            ) > 0

        crop_bgr = cv2.resize(image[top:bottom, left:right], (PANEL, PANEL))
        rows.append(
            [
                panel(crop_bgr, None, (0, 0, 0), titles[0]),
                panel(crop_bgr, crop(visible_gt[index]), (60, 200, 90), titles[1]),
                panel(crop_bgr, crop(pred_visible), (60, 200, 90), titles[2]),
                panel(crop_bgr, crop(amodal_gt[index]), (240, 120, 40), titles[3]),
                panel(crop_bgr, crop(pred_amodal), (240, 120, 40), titles[4]),
            ]
        )
        header = (
            f"tree {index + 1} (layer {int(layers[index])}): "
            f"visibleIoU={visible_iou:.2f} amodalIoU={amodal_iou:.2f} "
            f"hull={hull_iou:.2f} P={precision:.2f} R={recall:.2f} "
            f"vis={visibility[0]:.2f}/{visibility[1]:.2f}"
        )
        headers.append(header)
        report.append(
            {
                "tree": index + 1,
                "layer": int(layers[index]),
                "visible_iou": visible_iou,
                "amodal_iou": amodal_iou,
                "hull_iou": hull_iou,
                "amodal_precision": precision,
                "amodal_recall": recall,
                "predicted_visibility": [float(visibility[0]), float(visibility[1])],
            }
        )
        print(header, flush=True)

    gap = 6
    row_height = PANEL + 28
    sheet = np.full((40 + len(rows) * row_height, len(titles) * (PANEL + gap), 3), 248, np.uint8)
    for column, title in enumerate(titles):
        cv2.putText(
            sheet, title, (column * (PANEL + gap) + 8, 22),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 1, cv2.LINE_AA,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = 40 + row_index * row_height
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (20, 20, 20), 1)
        for column, item in enumerate(panels):
            x0 = column * (PANEL + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL, x0 : x0 + PANEL] = item
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(args.output), sheet):
        raise SystemExit(f"cannot write {args.output}")
    (args.output.parent / "model_on_composite.json").write_text(
        json.dumps({"checkpoint": str(args.checkpoint), "rows": report}, indent=2),
        encoding="utf-8",
    )
    print(f"saved {args.output} ({sheet.shape[1]}x{sheet.shape[0]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
