"""Oracle-group pilot only: test view complementarity without claiming RGB association."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import cv2
import numpy as np

from treeweaver.measurement.multiview_readiness import AssociatedTreeView, assess_unordered_views
from treeweaver.visibility.image_complexity import audit_target_view


def _read_mask(path: str) -> np.ndarray:
    value = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if value is None:
        raise FileNotFoundError(path)
    return value > 0


def _tree_id(name: str) -> str:
    match = re.fullmatch(r"(\d+)00(\d+)", Path(name).stem)
    if match is None:
        raise ValueError(f"filename does not follow the evaluation tree-view contract: {name}")
    return match.group(1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("multi_instance_report")
    parser.add_argument("trunk_refinement_report")
    parser.add_argument("output_json")
    args = parser.parse_args()
    output = Path(args.output_json).resolve()
    if output.exists():
        raise FileExistsError(output)
    multi = json.loads(Path(args.multi_instance_report).read_text(encoding="utf-8"))
    refined = json.loads(Path(args.trunk_refinement_report).read_text(encoding="utf-8"))
    if (
        multi.get("schema_version") != "multi-tree-root-anchor-pilot-1.0"
        or refined.get("schema_version") != "root-seeded-sam2-trunk-pilot-1.0"
    ):
        raise ValueError("unsupported segmentation reports")
    trunks = {str(item["filename"]): item for item in refined["records"]}
    groups: dict[str, list[AssociatedTreeView]] = {}
    invalid: list[str] = []
    for item in multi["records"]:
        name = str(item["filename"])
        selected = item.get("target_index")
        if selected is None or "failure" in item:
            invalid.append(name)
            continue
        masks = tuple(_read_mask(str(path)) for path in item["mask_paths"])
        index = int(selected)
        target = _read_mask(str(item.get("target_mask_path", item["mask_paths"][index])))
        trunk = _read_mask(str(trunks[name]["mask_path"])) & target
        crown = target & ~trunk
        if not np.any(trunk) or not np.any(crown):
            invalid.append(name)
            continue
        audit = audit_target_view(
            target,
            trunk,
            crown,
            competing_instance_masks=tuple(mask for i, mask in enumerate(masks) if i != index),
            non_tree_object_masks=tuple(
                _read_mask(str(path)) for path in item.get("non_tree_mask_paths", ())
            ),
        )
        groups.setdefault(_tree_id(name), []).append(AssociatedTreeView(name, audit, True))
    results: list[dict[str, object]] = []
    for tree_id, views in sorted(groups.items(), key=lambda entry: int(entry[0])):
        gates = assess_unordered_views(tuple(views))
        results.append(
            {
                "tree_id": tree_id,
                "view_ids": sorted(view.image_id for view in views),
                "parameter_gates": {
                    gate.parameter.value: {
                        "readiness": gate.readiness.value,
                        "supporting_view_ids": list(gate.supporting_view_ids),
                        "blocked_view_ids": list(gate.blocked_view_ids),
                        "reasons": list(gate.reasons),
                    }
                    for gate in gates
                },
            }
        )
    payload = {
        "schema_version": "oracle-rgb-view-complementarity-pilot-1.0",
        "identity_provenance": (
            "User-provided 00 filename convention, used as evaluation oracle only; "
            "not automatic RGB tree association"
        ),
        "invalid_views": invalid,
        "trees": results,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"trees": len(results), "invalid_views": len(invalid)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
