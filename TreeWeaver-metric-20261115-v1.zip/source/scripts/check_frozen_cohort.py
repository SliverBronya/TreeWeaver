"""CPU-only readiness check for the frozen qualification cohort."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(r"D:\TreeWeaver")
FROZEN = ROOT / "reports/data-qualification-2026-11-09/frozen"
ROOTS = {
    "v6": ROOT / "reports/fig-paired-v6-framing-30-2026-11-08",
    "mixed": ROOT / "reports/mixed-identity-layout-qualification-2026-11-08",
    "supplement": ROOT / "reports/qualification-supplement-v2-2026-11-09",
    "hidden-heavy": ROOT / "reports/hidden-heavy-supplement-2026-11-09",
    "hidden-heavy-v2": ROOT / "reports/hidden-heavy-v2-2026-11-09",
    "hidden-heavy-v3": ROOT / "reports/hidden-heavy-v3-2026-11-09",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(rows, split):
    missing = []
    for row in rows:
        root = ROOTS.get(row["root"])
        if root is None:
            missing.append({"reason": "unknown root", "row": row})
            continue
        scene = root / row["scene"].replace("-scene", "")
        candidates = [scene, root / "masks" / row["scene"].replace("-scene", "")]
        if not any(path.is_dir() for path in candidates):
            missing.append({"reason": "missing scene", "scene": str(candidates[0])})
    return {"split": split, "rows": len(rows), "missing": missing}


def main():
    split = json.loads((FROZEN / "splits.json").read_text(encoding="utf-8"))
    freeze = json.loads((FROZEN / "freeze.json").read_text(encoding="utf-8"))
    checks = [
        check(split["train"], "train"),
        check(split["validation"], "validation"),
        check(split["test"], "test"),
    ]
    hashes = {
        "splits.json": sha(FROZEN / "splits.json"),
        "freeze.json": sha(FROZEN / "freeze.json"),
    }
    result = {
        "schema_version": "treeweaver-frozen-readiness-1.0",
        "test_images_read": False,
        "test_labels_read": False,
        "checks": checks,
        "all_scenes_present": all(not c["missing"] for c in checks),
        "counts": freeze["counts"],
        "hidden": freeze["hidden"],
        "isolation": freeze["isolation"],
        "hashes": hashes,
        "training_allowed": False,
        "gpu_allowed": False,
    }
    (FROZEN / "readiness.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
