"""Create five qualification targets: 2 clear + 3 overlap, same-camera controls."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from blender_stem_pilot import ground, load, world  # noqa: E402

ASSETS = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
OUT = Path(r"D:\TreeWeaver\reports\qualification-supplement-v2-2026-11-09")
RES_X, RES_Y = 960, 540
MASK_X, MASK_Y = 480, 270
CASES = [
    ("clear", "realistic_hd_common_fig_tree_1030", "realistic_hd_common_fig_tree_2830"),
    ("clear", "realistic_hd_common_fig_tree_130", "realistic_hd_common_fig_tree_2930"),
    ("overlap", "realistic_hd_common_fig_tree_1730", "realistic_hd_common_fig_tree_2230"),
    ("overlap", "realistic_hd_common_fig_tree_1830", "realistic_hd_common_fig_tree_430"),
    ("overlap", "realistic_hd_common_fig_tree_1930", "realistic_hd_common_fig_tree_530"),
]


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points), max(p.x for p in points),
        min(p.y for p in points), max(p.y for p in points),
        min(p.z for p in points), max(p.z for p in points),
    )


def setup_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.eevee.taa_render_samples = 24
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    return scene


def camera(center, span):
    lens = 35.0
    hfov = 2 * math.atan(18 / lens)
    distance = max(span / (2 * math.tan(hfov / 2)) * 1.2, 14.0)
    bpy.ops.object.camera_add(location=(center, -distance, 2.0))
    cam = bpy.context.object
    cam.data.lens = lens
    look = Vector((center, 0, 4.8))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam
    return cam


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for index, (relation, target_name, neighbour_name) in enumerate(CASES, start=1):
        scene = setup_scene()
        target, target_stem = load(ASSETS / f"{target_name}.glb", 9.0)
        neighbour, neighbour_stem = load(ASSETS / f"{neighbour_name}.glb", 9.0)
        target.location = (0, 0, 0)
        neighbour.location.y = 1.2
        target_stem.location = target.location
        target_stem.rotation_euler = target.rotation_euler
        target_stem.scale = target.scale
        neighbour_stem.location = neighbour.location
        neighbour_stem.rotation_euler = neighbour.rotation_euler
        neighbour_stem.scale = neighbour.scale
        bpy.context.view_layer.update()
        x0, x1, _, _, _, _ = bbox(target)
        target_width = x1 - x0
        x0, x1, _, _, _, _ = bbox(neighbour)
        neighbour_width = x1 - x0
        if relation == "clear":
            neighbour.location.x = (target_width + neighbour_width) / 2 + 4.0
        else:
            neighbour.location.x = (target_width + neighbour_width) / 2 * 0.82
        neighbour_stem.location.x = neighbour.location.x
        bpy.context.view_layer.update()

        ground_obj = ground()
        world()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.2
        sun.rotation_euler = (math.radians(50), 0, math.radians(25))
        center = (target.location.x + neighbour.location.x) / 2
        span = abs(target.location.x - neighbour.location.x) + target_width + neighbour_width
        camera(center, span)

        scene_dir = OUT / f"{index:06d}"
        scene_dir.mkdir()
        bpy.context.scene.render.filepath = str(scene_dir / "full.png")
        bpy.ops.render.render(write_still=True)

        neighbour.hide_render = True
        neighbour_stem.hide_render = True
        bpy.context.scene.render.filepath = str(scene_dir / "control_target.png")
        bpy.ops.render.render(write_still=True)
        neighbour.hide_render = False
        neighbour_stem.hide_render = True

        scene.render.film_transparent = True
        scene.render.resolution_x, scene.render.resolution_y = MASK_X, MASK_Y
        ground_obj.hide_render = True
        for name, tree, stem in (
            ("target", target, target_stem),
            ("neighbour", neighbour, neighbour_stem),
        ):
            for other_tree, other_stem in (
                (target, target_stem),
                (neighbour, neighbour_stem),
            ):
                other_tree.hide_render = True
                other_stem.hide_render = True
            tree.hide_render = False
            scene.render.filepath = str(scene_dir / f"amodal_{name}.png")
            bpy.ops.render.render(write_still=True)
            tree.hide_render = True
            stem.hide_render = False
            scene.render.filepath = str(scene_dir / f"stem_{name}.png")
            bpy.ops.render.render(write_still=True)
        for tree, stem in ((target, target_stem), (neighbour, neighbour_stem)):
            tree.hide_render = False
            stem.hide_render = True
        ground_obj.hide_render = False
        scene.render.film_transparent = False
        scene.render.resolution_x, scene.render.resolution_y = RES_X, RES_Y

        meta = {
            "scene_id": index,
            "relation": relation,
            "target": target_name,
            "neighbour": neighbour_name,
            "group_id": 100 + index,
            "split": "train",
            "target_box": [0, 0, 0, 0],
        }
        (scene_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("SCENE", index, relation, flush=True)


if __name__ == "__main__":
    main()
