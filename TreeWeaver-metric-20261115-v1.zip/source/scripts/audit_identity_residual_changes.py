"""Count corrected versus newly broken assignments; verify a shared mask prior."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
from preview_whole_tree_mainline import compete, masks, read


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    rows = read(args.data / "paired-samples.json")["records"]
    totals = {}
    for arm in ("local", "anchor"):
        counts = {
            key: 0
            for key in (
                "frames_checked",
                "multi_scene_foreground_pixels_corrected",
                "multi_scene_foreground_pixels_broken",
                "multi_scene_wrong_owner_changed",
                "multi_scene_background_false_positive_union_pixels",
            )
        }
        for row in rows:
            if row["split"] != "validation":
                continue
            filename = f"{row['id']}.npz"
            with (
                np.load(args.run / "prior" / filename) as baseline,
                np.load(args.run / arm / filename) as candidate,
            ):
                raw = baseline["logits"]
                if not np.array_equal(raw, candidate["logits"]):
                    raise ValueError("underlying visible logits changed across arms")
                simple = compete(raw)
                corrected = compete(raw, candidate["ownership_logits"])
            if not np.array_equal(simple.any(0), corrected.any(0)):
                raise ValueError("foreground union changed")
            if (corrected & ~(raw > 0)).any():
                raise ValueError("ownership assigned to an inactive query")
            counts["frames_checked"] += 1
            if row["condition"] != "scene" or len(row["instances"]) < 2:
                continue
            known = ~np.stack(
                [
                    np.asarray(Image.open(args.data / item["raster_unknown"]))[..., 3] > 16
                    for item in row["instances"]
                ]
            ).any(0)
            target = masks(args.data, row)
            foreground = target.any(0) & known
            ids = np.arange(1, len(target) + 1)[:, None, None]
            truth, before, after = ((value * ids).sum(0) for value in (target, simple, corrected))
            old_ok, new_ok = before == truth, after == truth
            counts["multi_scene_foreground_pixels_corrected"] += int(
                (foreground & ~old_ok & new_ok).sum()
            )
            counts["multi_scene_foreground_pixels_broken"] += int(
                (foreground & old_ok & ~new_ok).sum()
            )
            counts["multi_scene_wrong_owner_changed"] += int(
                (foreground & ~old_ok & ~new_ok & (before != after)).sum()
            )
            counts["multi_scene_background_false_positive_union_pixels"] += int(
                (known & ~target.any(0) & corrected.any(0)).sum()
            )
        totals[arm] = counts
    result = {"all_validation_priors_and_foreground_unions_identical": True, "pixel_counts": totals}
    with (args.run / "assignment-changes.json").open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
