"""Fetch a bounded RGB subset with original author split membership preserved."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

from audit_forest_dataset_samples import RemoteZip
from fetch_synthtree_author_labels import ROOT

URL = (
    "https://norlab.s3.valeria.science/SynthTree43k.zip?"
    "AWSAccessKeyId=VCI7FLOHYPGLOOOAH0S5&Expires=2274019241&"
    "Signature=KfOgwrHX8WHejopspqQ8XMwlMJE%3D"
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-only", action="store_true")
    args = parser.parse_args()
    records = []
    for split, limit in ([("val", 2)] if args.validation_only else [("train", 8), ("val", 2)]):
        label_path = ROOT / "annotations" / f"{split}_RGB_entire_tree.json"
        if not label_path.exists():
            raise FileNotFoundError(f"Author annotations not downloaded yet: {label_path}")
        document = json.loads(label_path.read_text())
        annotated_ids = {a["image_id"] for a in document["annotations"]}
        selected = sorted(
            (i for i in document["images"] if i["id"] in annotated_ids), key=lambda i: i["id"]
        )[:limit]
        ids = {image["id"] for image in selected}
        subset = {k: v for k, v in document.items() if k not in ("images", "annotations")}
        subset["images"] = selected
        subset["annotations"] = [a for a in document["annotations"] if a["image_id"] in ids]
        subset_path = ROOT / "pilot" / "annotations" / f"{split}_RGB_entire_tree.json"
        subset_path.parent.mkdir(parents=True, exist_ok=True)
        subset_path.write_text(json.dumps(subset))
        for image in selected:
            records.append({"split": split, "image": image})
    remote = RemoteZip(URL, transfer_budget=100_000_000)
    with zipfile.ZipFile(remote) as archive:
        by_basename = {}
        for entry in archive.infolist():
            if entry.filename.endswith("_img.png"):
                by_basename.setdefault(Path(entry.filename).name, []).append(entry)
        for record in records:
            basename = Path(record["image"]["file_name"]).name
            candidates = by_basename.get(basename, [])
            if len(candidates) != 1:
                raise ValueError(f"Cannot uniquely match author RGB filename: {basename}")
            destination = ROOT / "pilot" / f"{record['split']}_set" / basename
            destination.parent.mkdir(parents=True, exist_ok=True)
            if not destination.exists():
                destination.write_bytes(archive.read(candidates[0]))
            record["path"] = str(destination)
            record["archive_entry"] = candidates[0].filename
            record["sha256"] = hashlib.sha256(destination.read_bytes()).hexdigest()
            print(json.dumps(record), flush=True)
    (ROOT / "pilot" / "manifest.json").write_text(
        json.dumps(
            {
                "records": records,
                "original_split_preserved": True,
                "test_images_downloaded": False,
                "subset_only": True,
                "paper_reproduction_completed": False,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
