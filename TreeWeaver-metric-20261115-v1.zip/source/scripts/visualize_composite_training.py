"""Mask-only preview of the composite-trained decoder on held-out composites."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from broadleaf_composites import BroadleafComposites  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL = 320


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def mask_panel(mask, title):
    panel = np.zeros((PANEL, PANEL, 3), np.uint8)
    small = cv2.resize(
        mask.astype(np.uint8), (PANEL, PANEL), interpolation=cv2.INTER_NEAREST
    ) > 0
    panel[small] = (255, 255, 255)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
    return panel


def error_panel(gt, pred, title):
    panel = np.zeros((PANEL, PANEL, 3), np.uint8)
    gt = cv2.resize(gt.astype(np.uint8), (PANEL, PANEL), interpolation=cv2.INTER_NEAREST) > 0
    pred = cv2.resize(pred.astype(np.uint8), (PANEL, PANEL), interpolation=cv2.INTER_NEAREST) > 0
    panel[gt & pred] = (255, 255, 255)
    panel[pred & ~gt] = (0, 0, 255)
    panel[gt & ~pred] = (255, 0, 0)
    cv2.putText(panel, title, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
    return panel


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--items", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    dataset = BroadleafComposites(args.dataset, "val", mean=mean, std=std)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    titles = [
        "GT visible",
        "pred visible",
        "GT amodal",
        "pred amodal",
        "visible errors",
        "amodal errors",
    ]
    rows, headers = [], []
    for index in range(min(args.items, len(dataset))):
        sample = dataset.sample(index, deterministic=True)
        with torch.no_grad():
            output = model(
                torch.as_tensor(sample["pixel_values"])[None].to(args.device),
                input_boxes=torch.as_tensor(sample["box"])[None, None].to(args.device),
            )
        gt_visible = sample["mask"][0] > 0.5
        gt_amodal = sample["amodal_mask"][0] > 0.5
        pred_visible = output["masks"][0, 0, 0].cpu().numpy() > 0
        pred_amodal = output["amodal_masks"][0, 0, 0].cpu().numpy() > 0
        rows.append(
            [
                mask_panel(gt_visible, titles[0]),
                mask_panel(pred_visible, titles[1]),
                mask_panel(gt_amodal, titles[2]),
                mask_panel(pred_amodal, titles[3]),
                error_panel(gt_visible, pred_visible, titles[4]),
                error_panel(gt_amodal, pred_amodal, titles[5]),
            ]
        )
        headers.append(
            f"val {index}: visibleIoU={iou(pred_visible, gt_visible):.3f} "
            f"amodalIoU={iou(pred_amodal, gt_amodal):.3f}"
        )

    gap = 6
    row_height = PANEL + 30
    sheet = np.full((46 + len(rows) * row_height, len(titles) * (PANEL + gap), 3), 25, np.uint8)
    for column, title in enumerate(titles):
        cv2.putText(
            sheet,
            title,
            (column * (PANEL + gap) + 6, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (220, 220, 220),
            1,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = 46 + row_index * row_height
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1)
        for column, panel in enumerate(panels):
            x0 = column * (PANEL + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL, x0 : x0 + PANEL] = panel
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(args.output), sheet)
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
