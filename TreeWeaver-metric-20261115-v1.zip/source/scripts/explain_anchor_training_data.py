"""Render actually sampled training images and verify every reported pixel count."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from probe_canatree_adhesion import BASE, decode_image, load_fold
from train_anchor_competition import safe_anchor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output required")
    args.output.mkdir(parents=True)
    history = json.loads((args.run / "exchange/history.json").read_text())
    used = list(dict.fromkeys(row["image"] for row in history))
    images, grouped, _ = load_fold("train")
    names = {image["file_name"]: (image_id, image) for image_id, image in images.items()}
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    sheet = Image.new("RGB", (1280, 3 * 420), "white")
    selection = []
    for row_index, name in enumerate(used[:3]):
        image_id, image = names[name]
        bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        overlay = rgb.copy()
        for index, (box, mask) in enumerate(zip(boxes, masks, strict=True)):
            hsv = np.uint8([[[int(index * 179 / max(len(masks), 1)), 210, 245]]])
            color = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)[0, 0]
            overlay[mask] = (0.45 * overlay[mask] + 0.55 * color).astype(np.uint8)
            point = np.rint(safe_anchor(mask, box)).astype(int)
            cv2.circle(overlay, tuple(point), 5, (255, 255, 0), -1)
            cv2.putText(
                overlay,
                str(index + 1),
                tuple(point + [4, -8]),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2,
            )
        panel = Image.new("RGB", (1280, 420), "white")
        draw = ImageDraw.Draw(panel)
        draw.text(
            (8, 4),
            f"训练样张 {row_index + 1}：{name} / {len(masks)}个树干标注",
            fill="black",
            font=font,
        )
        draw.text((648, 4), "不同颜色＝不同标注实例；黄点＝训练提示", fill="black", font=font)
        panel.paste(Image.fromarray(cv2.resize(rgb, (640, 360))), (0, 31))
        panel.paste(Image.fromarray(cv2.resize(overlay, (640, 360))), (640, 31))
        draw.text(
            (8, 395),
            "左：原始RGB；右：人工树干多边形叠加。未着色区域可能仍有未标注树。",
            fill="black",
            font=font,
        )
        panel.save(args.output / f"training-sample-{row_index + 1}.jpg", quality=95)
        sheet.paste(panel, (0, row_index * 420))
        selection.append(
            {
                "file": name,
                "annotation_instances": len(masks),
                "original_size_wh": [width, height],
                "image_path": str(BASE / "images" / name),
                "times_sampled": sum(row["image"] == name for row in history),
            }
        )
    sheet.save(args.output / "training-examples.jpg", quality=95)
    originals = {
        mode: {
            row["id"]: row for row in json.loads((args.run / mode / "per_tree.json").read_text())
        }
        for mode in ("frozen", "exchange")
    }
    counts = {mode: [] for mode in originals}
    val_images, val_grouped, _ = load_fold("val")
    for image_id, image in val_images.items():
        _, boxes, masks, _, _ = decode_image(image, val_grouped[image_id])
        for mode in originals:
            predictions = np.load(args.run / mode / (Path(image["file_name"]).stem + ".npz"))[
                "masks"
            ]
            for index, (pred, gt) in enumerate(zip(predictions, masks, strict=True)):
                foreign = masks[np.arange(len(masks)) != index].any(0) & ~gt
                tp, fp, fn = (
                    int((pred & gt).sum()),
                    int((pred & ~gt).sum()),
                    int((~pred & gt).sum()),
                )
                leaked = int((pred & foreign).sum())
                key = f"{image['file_name']}:{index}"
                row = {
                    "id": key,
                    "TP": tp,
                    "FP": fp,
                    "FN": fn,
                    "predicted_px": int(pred.sum()),
                    "target_px": int(gt.sum()),
                    "neighbour_px": leaked,
                    "iou": tp / max(tp + fp + fn, 1),
                    "neighbour_fraction": leaked / max(int(pred.sum()), 1),
                }
                assert abs(row["iou"] - originals[mode][key]["iou"]) < 1e-12
                assert (
                    abs(row["neighbour_fraction"] - originals[mode][key]["neighbour_fraction"])
                    < 1e-12
                )
                counts[mode].append(row)
    aggregates = {}
    for mode, rows in counts.items():
        foreign, prediction = (
            sum(r["neighbour_px"] for r in rows),
            sum(r["predicted_px"] for r in rows),
        )
        aggregates[mode] = {
            "instances": len(rows),
            "macro_iou": float(np.mean([r["iou"] for r in rows])),
            "macro_neighbour_fraction": float(np.mean([r["neighbour_fraction"] for r in rows])),
            "sum_foreign_px": foreign,
            "sum_prediction_px": prediction,
            "micro_neighbour_fraction": foreign / prediction,
        }
    baseline = [row for row in counts["frozen"] if row["neighbour_px"] > 0]
    baseline.sort(key=lambda row: row["neighbour_fraction"])
    example = baseline[len(baseline) // 2]
    document = {
        "dataset": "CanaTree100 fold_00; RGB only, visible trunks",
        "training_split_images": len(images),
        "training_split_annotation_instances": sum(map(len, grouped.values())),
        "actual_unique_sampled_images": len(used),
        "optimizer_steps": len(history),
        "actual_annotation_instances_in_sampled_images": sum(
            len(grouped[names[name][0]]) for name in used
        ),
        "training_examples": selection,
        "aggregates": aggregates,
        "worked_example": example,
        "per_instance": counts,
    }
    (args.output / "pixel-counts.json").write_text(
        json.dumps(document, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    render_worked_example(args, example, val_images, val_grouped, font)
    print(
        json.dumps(
            {key: value for key, value in document.items() if key != "per_instance"},
            ensure_ascii=False,
            indent=2,
        )
    )


def render_worked_example(args, example, images, grouped, font):
    name, index = example["id"].rsplit(":", 1)
    index = int(index)
    image_id, image = next(
        (key, value) for key, value in images.items() if value["file_name"] == name
    )
    bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
    pred = np.load(args.run / "frozen" / (Path(name).stem + ".npz"))["masks"][index]
    gt = masks[index]
    foreign = masks[np.arange(len(masks)) != index].any(0) & ~gt
    x0, y0, x1, y1 = boxes[index]
    dx = max(100, 2 * (x1 - x0))
    left, top = max(0, int(x0 - dx)), max(0, int(y0 - 20))
    right, bottom = min(width, int(x1 + dx)), min(height, int(y1 + 20))
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    panels = [rgb.copy() for _ in range(4)]
    panels[1][gt] = (20, 190, 80)
    panels[2][pred] = (30, 160, 240)
    panels[3][pred & gt] = (20, 190, 80)
    panels[3][pred & ~gt] = (30, 160, 240)
    panels[3][gt & ~pred] = (255, 170, 20)
    panels[3][pred & foreign] = (240, 40, 40)
    sheet = Image.new("RGB", (1280, 432), "white")
    draw = ImageDraw.Draw(sheet)
    for column, (panel, title) in enumerate(
        zip(panels, ("原图局部", "目标树干真值", "底座预测", "像素计数示意"), strict=True)
    ):
        draw.text((column * 320 + 6, 3), title, fill="black", font=font)
        crop = panel[top:bottom, left:right]
        # Preserve aspect ratio; the illustrated crop does not change metric scope.
        image = Image.fromarray(crop)
        image.thumbnail((320, 360))
        sheet.paste(image, (column * 320 + (320 - image.width) // 2, 31))
    draw.text(
        (6, 393),
        "绿色＝正确目标；红色＝混入已标邻树；橙色＝漏分；蓝色＝其他多分。计数按全图。",
        fill="black",
        font=font,
    )
    draw.text((6, 414), f"{name} / 目标索引{index}（从0计）", fill="black", font=font)
    sheet.save(args.output / "worked-example.jpg", quality=95)


if __name__ == "__main__":
    main()
