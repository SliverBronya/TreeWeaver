"""Bounded original-SAM2 decoder adaptation, visible silhouettes only, no test use."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from evaluate_treestereo_visible import decode_reference, reference_box  # noqa: E402
from instance_metrics import boundary_f1, mask_iou  # noqa: E402
from research_protocol import pinned_snapshot  # noqa: E402

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--seed", type=int, default=20261102)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 1000 or not 0 < args.lr <= 1e-3:
        parser.error("fresh output, steps=1..1000 and lr in (0,1e-3] required")
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != "treeweaver-real-visible-split-1.0":
        raise ValueError("unsupported visible-only manifest")
    train = [r for r in manifest["records"] if r["split"] == "train"]
    validation = [r for r in manifest["records"] if r["split"] == "validation"]
    forbidden = set(manifest["protected_reference_tree_ids"] + manifest["excluded_legacy_tree_ids"])
    train_ids, val_ids = set(manifest["splits"]["train"]), set(manifest["splits"]["validation"])
    if train_ids & val_ids or (train_ids | val_ids) & forbidden or not train or not validation:
        raise ValueError("training, validation and protected source identities must be disjoint")
    for row in manifest["records"]:
        identity = int(row["tree_id"][2:])
        expected = train_ids if row["split"] == "train" else val_ids
        if identity not in expected:
            raise ValueError("record identity disagrees with frozen split")
        if (
            digest(row["image"]) != row["image_sha256"]
            or digest(row["visible_reference"]) != row["reference_sha256"]
        ):
            raise ValueError("frozen source image or annotation changed")
    args.output.mkdir(parents=True)
    protocol = {
        "profile": "visible_silhouette_decoder_only_pilot",
        "steps": args.steps,
        "lr": args.lr,
        "seed": args.seed,
        "sam_revision": REVISION,
        "manifest_sha256": digest(args.manifest),
        "train_trees": len(train_ids),
        "validation_trees": len(val_ids),
        "protected_reference_trees_used": 0,
        "supervision": ["dataset_supplied_visible_silhouette"],
        "initialization": "original pretrained SAM2; no legacy fine-tuned decoder",
        "evaluation": "same GT-derived box; fixed validation before and after only",
        "scene_disjoint": False,
        "mask_decode": manifest["mask_decode"],
    }
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    path = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(path, local_files_only=True)
    baseline = Sam2Model.from_pretrained(path, local_files_only=True).to(args.device).eval()
    model = copy.deepcopy(baseline)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in model.mask_decoder.parameters():
        parameter.requires_grad_(True)
    optimizer = torch.optim.AdamW(model.mask_decoder.parameters(), lr=args.lr, weight_decay=1e-4)

    def sample(row):
        image = cv2.imread(row["image"])
        target = decode_reference(cv2.imread(row["visible_reference"]))
        if image is None or image.shape[:2] != target.shape:
            raise ValueError("image/reference dimensions disagree")
        h, w = target.shape
        pixels = processor(
            images=Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)), return_tensors="pt"
        )["pixel_values"].to(args.device)
        box = torch.tensor(reference_box(target), device=args.device) * torch.tensor(
            [1024 / w, 1024 / h, 1024 / w, 1024 / h], device=args.device
        )
        return pixels, box[None, None], target

    def evaluate(candidate):
        candidate.eval()
        rows = []
        for row in validation:
            try:
                pixels, box, target = sample(row)
                with torch.inference_mode():
                    result = candidate(pixel_values=pixels, input_boxes=box, multimask_output=False)
                    pred = (
                        processor.post_process_masks(
                            result.pred_masks, original_sizes=[list(target.shape)]
                        )[0][0, 0]
                        .cpu()
                        .numpy()
                        > 0
                    )
                rows.append(
                    {
                        "tree_id": row["tree_id"],
                        "iou": mask_iou(pred, target),
                        "boundary_f1": boundary_f1(pred, target, tolerance=2),
                        "failed": False,
                    }
                )
            except Exception as error:
                rows.append(
                    {
                        "tree_id": row["tree_id"],
                        "iou": 0.0,
                        "boundary_f1": 0.0,
                        "failed": True,
                        "error": repr(error),
                    }
                )
        return rows

    initial = evaluate(baseline)
    (args.output / "baseline_validation.json").write_text(
        json.dumps(initial, indent=2), encoding="utf-8"
    )
    model.train()
    model.vision_encoder.eval()
    model.prompt_encoder.eval()
    history = []
    order = list(train)
    for step in range(args.steps):
        if step % len(order) == 0:
            random.shuffle(order)
        row = order[step % len(order)]
        pixels, box, target = sample(row)
        result = model(pixel_values=pixels, input_boxes=box, multimask_output=False)
        logits = result.pred_masks[0, 0, 0]
        gt = F.interpolate(
            torch.tensor(target.astype(np.float32), device=args.device)[None, None],
            size=logits.shape,
            mode="nearest",
        )[0, 0]
        prob = logits.sigmoid()
        loss = (
            F.binary_cross_entropy_with_logits(logits, gt)
            + 1
            - (2 * (prob * gt).sum() + 1) / (prob.sum() + gt.sum() + 1)
        )
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite training loss")
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.mask_decoder.parameters(), 1.0)
        optimizer.step()
        history.append({"step": step + 1, "tree_id": row["tree_id"], "loss": float(loss.detach())})
        if (step + 1) % 20 == 0:
            print(json.dumps(history[-1]), flush=True)
    torch.save(
        {"sam2_mask_decoder": model.mask_decoder.state_dict(), "protocol": protocol},
        args.output / "final.pth",
    )
    final = evaluate(model)
    summary = {
        "protocol": protocol,
        "baseline_iou": float(np.mean([r["iou"] for r in initial])),
        "pilot_iou": float(np.mean([r["iou"] for r in final])),
        "baseline_boundary_f1": float(np.mean([r["boundary_f1"] for r in initial])),
        "pilot_boundary_f1": float(np.mean([r["boundary_f1"] for r in final])),
        "baseline_failures": sum(r["failed"] for r in initial),
        "pilot_failures": sum(r["failed"] for r in final),
        "paired_iou_wins": sum(b["iou"] > a["iou"] for a, b in zip(initial, final, strict=True)),
        "evaluation_scope": "development validation, not frozen 24-tree evaluation or blind test",
    }
    for name, value in [
        ("summary.json", summary),
        ("history.json", history),
        ("pilot_validation.json", final),
    ]:
        (args.output / name).write_text(json.dumps(value, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
