"""Export visible stem/crown/unknown masks from saved logits, using CPU NumPy only.

The input NPZ must contain ``visible_masks`` (K,H,W). Optional arrays are
``stem_logits``, ``crown_logits`` (K,H,W), ``owner_ids`` (H,W), ``valid``
(H,W or K,H,W) and ``query_valid`` (K,). All arrays must already share one
pixel frame; no image resizing, model loading or inference is performed.

Without --heads-validated every committed visible pixel remains unknown.
That option is an explicit caller assertion that BOTH part heads have been
validated together with the same architecture, weights and preprocessing.
The exporter does not independently validate model accuracy or DBH readiness.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from visible_tree_parts import decode_visible_tree_parts  # noqa: E402

INPUT_KEYS = (
    "visible_masks",
    "stem_logits",
    "crown_logits",
    "owner_ids",
    "valid",
    "query_valid",
)


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def export_parts(
    input_path,
    output_path,
    *,
    heads_validated=False,
    positive_threshold=0.7,
    negative_threshold=0.3,
    dominance_margin=0.2,
    ignore_owner_id=-1,
):
    """Validate and decode before creating a fresh output directory.

    A failed write leaves its directory without a completed status.json; no
    existing directory/file is ever overwritten, including an incomplete run.
    NPZ object arrays are never unpickled. The input is checked for changes
    before output creation, and original logits remain in the output archive.
    """
    source = Path(input_path).resolve(strict=True)
    output = Path(output_path).resolve()
    if not source.is_file() or source.suffix.lower() != ".npz":
        raise ValueError("input must be an existing .npz file")
    # is_symlink covers a broken destination symlink as well as an existing one.
    requested_output = Path(output_path)
    if output.exists() or requested_output.is_symlink():
        raise FileExistsError("output exists; refusing to overwrite: " + str(output))
    source_hash = sha256_file(source)
    with np.load(source, allow_pickle=False) as archive:
        if "visible_masks" not in archive.files:
            raise ValueError("input NPZ is missing required visible_masks")
        input_keys = sorted(archive.files)
        arrays = {key: archive[key] for key in INPUT_KEYS if key in archive.files}
    result = decode_visible_tree_parts(
        arrays["visible_masks"],
        arrays.get("stem_logits"),
        arrays.get("crown_logits"),
        heads_validated=heads_validated,
        owner_ids=arrays.get("owner_ids"),
        valid=arrays.get("valid"),
        query_valid=arrays.get("query_valid"),
        positive_threshold=positive_threshold,
        negative_threshold=negative_threshold,
        dominance_margin=dominance_margin,
        ignore_owner_id=ignore_owner_id,
    )
    if sha256_file(source) != source_hash:
        raise ValueError("input NPZ changed during decoding; no export created")

    count, height, width = result["visible_support"].shape
    labels = np.zeros((count, height, width), np.uint8)
    for name, value in (("stem", 1), ("crown", 2), ("unknown", 255)):
        labels[result[name]] = value
    export_arrays = {
        **arrays,
        "part_labels": labels,
        **{
            name: result[name]
            for name in (
                "stem",
                "crown",
                "unknown",
                "visible_support",
                "part_valid",
                "nonfinite_head_pixels",
                "stem_score",
                "crown_score",
            )
            if result[name] is not None
        },
    }
    # Explicit names make it clear these are unchanged diagnostics, not new logits.
    for name in ("raw_stem_logits", "raw_crown_logits"):
        if result[name] is not None:
            export_arrays[name] = result[name]
    queries = []
    for index in range(count):
        prefix = f"query_{index + 1:04d}"
        files = {name: f"{prefix}/{name}.png" for name in ("stem", "crown", "unknown")}
        queries.append(
            {
                "query_index": index,
                "owner_id": index + 1,
                "query_valid": bool(arrays.get("query_valid", np.ones(count, bool))[index]),
                "visible_support_pixels": int(result["visible_support"][index].sum()),
                "stem_pixels": int(result["stem"][index].sum()),
                "crown_pixels": int(result["crown"][index].sum()),
                "unknown_pixels": int(result["unknown"][index].sum()),
                "nonfinite_head_pixels": int(result["nonfinite_head_pixels"][index].sum()),
                "files": files,
            }
        )
    status = {
        "schema_version": "treeweaver-visible-parts-export-1.0",
        "status": "complete",
        "input": str(source),
        "input_sha256": source_hash,
        "input_keys": input_keys,
        "ignored_input_keys": sorted(set(input_keys) - set(INPUT_KEYS)),
        "decoder_source_sha256": sha256_file(ROOT / "workers/tree_models/visible_tree_parts.py"),
        "exporter_source_sha256": sha256_file(Path(__file__).resolve()),
        "runtime": "NumPy CPU postprocessing; no model execution",
        "shape_KHW": [count, height, width],
        "coordinate_frame": "unchanged input pixel frame",
        "pixel_resampling_performed": False,
        "head_status": result["head_status"],
        "heads_validated_asserted_by_caller": bool(heads_validated),
        "head_validation_scope": (
            "same architecture, weights and preprocessing; caller assertion only"
        ),
        "ownership_applied": result["ownership_applied"],
        "ignore_owner_id": ignore_owner_id,
        "thresholds": {
            "positive": positive_threshold,
            "negative": negative_threshold,
            "dominance_margin": dominance_margin,
            "calibrated_by_exporter": False,
        },
        "part_label_values": {"outside_support": 0, "stem": 1, "crown": 2, "unknown": 255},
        "partition_union_equals_visible_support": True,
        "archive": "parts.npz",
        "png_values": {"outside_mask": 0, "inside_mask": 255},
        "measurement_readiness_verified": False,
        "queries": queries,
    }

    # Atomic directory reservation refuses an output created by another process.
    output.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(output / "parts.npz", **export_arrays)
    for index, query in enumerate(queries):
        (output / f"query_{index + 1:04d}").mkdir()
        for name, relative in query["files"].items():
            Image.fromarray(result[name][index].astype(np.uint8) * 255).save(output / relative)
    # Completion is recorded last; incomplete outputs are never silently reused.
    (output / "status.json").write_text(
        json.dumps(status, indent=2, allow_nan=False), encoding="utf-8"
    )
    return status


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--heads-validated",
        action="store_true",
        help="Assert both heads are validated for the same architecture/weights/preprocessing; "
        "default keeps all committed support unknown.",
    )
    parser.add_argument("--positive-threshold", type=float, default=0.7)
    parser.add_argument("--negative-threshold", type=float, default=0.3)
    parser.add_argument("--dominance-margin", type=float, default=0.2)
    parser.add_argument("--ignore-owner-id", type=int, default=-1)
    args = parser.parse_args(argv)
    try:
        status = export_parts(
            args.input,
            args.output,
            heads_validated=args.heads_validated,
            positive_threshold=args.positive_threshold,
            negative_threshold=args.negative_threshold,
            dominance_margin=args.dominance_margin,
            ignore_owner_id=args.ignore_owner_id,
        )
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(
        json.dumps(
            {
                "output": str(args.output.resolve()),
                "head_status": status["head_status"],
                "shape_KHW": status["shape_KHW"],
                "queries": len(status["queries"]),
                "pixel_resampling_performed": False,
            }
        )
    )


if __name__ == "__main__":
    main()
