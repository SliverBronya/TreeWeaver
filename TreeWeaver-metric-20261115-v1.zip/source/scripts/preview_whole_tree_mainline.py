"""Deterministic whole-tree training examples and held-out prediction panels."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

COLORS = np.array([[255, 95, 70], [30, 195, 255], [250, 210, 40], [180, 95, 255]])
NAMES = {
    "single": "单树",
    "separated": "分离",
    "touching": "接触设置",
    "light": "轻重叠设置",
    "moderate": "中重叠设置",
    "hard": "重重叠设置",
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def masks(root, row):
    return np.stack(
        [np.asarray(Image.open(root / item["visible"]))[..., 3] > 16 for item in row["instances"]]
    )


def overlay(rgb, supports):
    output = np.asarray(rgb).copy()
    for index, mask in enumerate(supports):
        mask = cv2.resize(mask.astype(np.uint8), rgb.size, interpolation=cv2.INTER_NEAREST) > 0
        output[mask] = (output[mask] * 0.35 + COLORS[index] * 0.65).astype(np.uint8)
    return Image.fromarray(output)


def compete(raw, owner=None):
    active = raw > 0
    score = raw if owner is None else owner[1:]
    winner = np.where(active, score, -np.inf).argmax(0)
    return (np.arange(len(raw))[:, None, None] == winner) & active.any(0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run", type=Path)
    parser.add_argument("--reference-arm", default="coverage")
    parser.add_argument("--candidate-arm", default="coverage_identity")
    parser.add_argument("--reference-title", default="覆盖训练 + 分数分配")
    parser.add_argument("--candidate-title", default="联合训练 + 学习归属分配")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 17)
    plan = read(args.data / "generation_plan.json")
    audit = read(args.data / "paired-audit.json")
    rows = read(args.data / "paired-samples.json")["records"]
    by_id = {row["id"]: row for row in rows}
    train = [row for row in plan["records"] if row["split"] == "train"]
    chosen = [next(row for row in train if row["spacing_class"] == kind) for kind in NAMES]
    sheet = Image.new("RGB", (960, 6 * 305), "white")
    draw = ImageDraw.Draw(sheet)
    for index, spec in enumerate(chosen):
        row = by_id[f"{spec['id']:06d}-scene"]
        rgb = Image.open(args.data / row["image"]).convert("RGB")
        prefix = f"训练场景 {spec['id']} · {NAMES[spec['spacing_class']]}"
        draw.text(
            (6, index * 305 + 4), prefix + "  |  RGB / 每棵整树的可见真值", font=font, fill="black"
        )
        sheet.paste(rgb.resize((480, 270)), (0, index * 305 + 30))
        sheet.paste(overlay(rgb, masks(args.data, row)).resize((480, 270)), (480, index * 305 + 30))
    sheet.save(args.output / "training-spacing.jpg", quality=93)
    summary = {
        "scenes": audit["scenes"],
        "targets": audit["targets_and_controls"],
        "scene_and_control_rgb": audit["training_sample_records"],
        "truncated_targets": sum(row["frame_truncated"] for row in audit["records"]),
        "nominal_spacing_counts": dict(Counter(row["spacing_class"] for row in plan["records"])),
        "spacing_note": "Nominal geometry settings; measure hidden fractions from rendered masks.",
    }
    (args.output / "data-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if args.run:
        selected = [
            row
            for row in plan["records"]
            if row["split"] == "validation"
            and row["spacing_class"] in {"light", "moderate", "hard"}
        ]
        sheet = Image.new("RGB", (1536, len(selected) * 257 + 32), "white")
        draw = ImageDraw.Draw(sheet)
        for col, title in enumerate(
            ("验证RGB", "整株可见真值", args.reference_title, args.candidate_title)
        ):
            draw.text((col * 384 + 5, 5), title, font=font, fill="black")
        for index, spec in enumerate(selected):
            row = by_id[f"{spec['id']:06d}-scene"]
            rgb = Image.open(args.data / row["image"]).convert("RGB")
            simple = np.load(args.run / args.reference_arm / f"{row['id']}.npz")
            learned = np.load(args.run / args.candidate_arm / f"{row['id']}.npz")
            panels = [
                rgb,
                overlay(rgb, masks(args.data, row)),
                overlay(rgb, compete(simple["logits"])),
                overlay(rgb, compete(learned["logits"], learned["ownership_logits"])),
            ]
            y = 32 + index * 257
            draw.text(
                (5, y),
                f"验证场景 {spec['id']} · {NAMES[spec['spacing_class']]} · 按固定场景顺序展示",
                font=font,
                fill="black",
            )
            for col, panel in enumerate(panels):
                sheet.paste(panel.resize((384, 216)), (col * 384, y + 31))
        sheet.save(args.output / "validation-predictions.jpg", quality=93)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
