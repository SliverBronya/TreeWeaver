"""Real-photo test of the occlusion-aware decoder using SAM2 masks as pseudo-truth.

For each detected tree box:
1. stock SAM2 segments the unoccluded photo -> pseudo-amodal reference;
2. a rectangle is pasted over ~30-60% of that mask to create a real-texture occlusion;
3. the trained decoder predicts visible and amodal masks from the occluded photo;
4. IoU is measured against the SAM2 reference, with a convex-hull baseline.

The reference is another model's visible mask, not true amodal ground truth.
"""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

PANEL = 300


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def detect_boxes(image: Image.Image, device: str, box_threshold=0.28, text_threshold=0.22):
    path = snapshot("IDEA-Research/grounding-dino-tiny")
    processor = AutoProcessor.from_pretrained(path, local_files_only=True)
    model = (
        AutoModelForZeroShotObjectDetection.from_pretrained(path, local_files_only=True)
        .to(device)
        .eval()
    )
    inputs = processor(images=image, text="tree.", return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = model(**inputs)
    parameters = inspect.signature(processor.post_process_grounded_object_detection).parameters
    keyword = "threshold" if "threshold" in parameters else "box_threshold"
    result = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        text_threshold=text_threshold,
        target_sizes=[image.size[::-1]],
        **{keyword: box_threshold},
    )[0]
    return result["boxes"].detach().cpu().numpy(), result["scores"].detach().cpu().numpy()


def hull_baseline(visible: np.ndarray, reference: np.ndarray):
    contours = cv2.findContours(
        visible.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )[0]
    hull = np.zeros_like(visible, np.uint8)
    if contours:
        cv2.fillPoly(hull, [cv2.convexHull(np.vstack(contours))], 1)
    hull = hull.astype(bool)
    return hull, float((hull & reference).sum()) / max(float((hull | reference).sum()), 1.0)


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def panel(image, mask, colour, title):
    out = image.copy()
    if mask is not None:
        overlay = np.array(colour, np.float32)
        out[mask] = (0.55 * out[mask] + 0.45 * overlay).astype(np.uint8)
    cv2.putText(out, title, (5, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 2)
    cv2.putText(out, title, (5, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 0, 0), 1)
    return out


def small_mask(mask: np.ndarray) -> np.ndarray:
    resized = cv2.resize(
        mask.astype(np.uint8), (PANEL, PANEL), interpolation=cv2.INTER_NEAREST
    )
    return resized > 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--images",
        type=Path,
        nargs="+",
        default=[
            ROOT / "data" / "20260411" / "7001.jpg",
            ROOT / "data" / "20260411" / "7002.jpg",
            ROOT / "data" / "20260411" / "10002.jpg",
        ],
    )
    parser.add_argument("--boxes-per-image", type=int, default=2)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    titles = [
        "photo",
        "occluded",
        "SAM2 reference",
        "pred visible",
        "pred amodal",
        "hull baseline",
    ]
    rows = []
    headers = []
    for path in args.images:
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            print(f"skip unreadable {path}")
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        boxes, scores = detect_boxes(image, args.device)
        if len(boxes) == 0:
            print(f"skip {path.name}: no boxes")
            continue
        order = np.argsort(scores)[::-1][: args.boxes_per_image]
        scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
        for rank in order:
            box = boxes[rank]
            scaled = torch.as_tensor(box * scale, device=args.device)[None, None]
            base_inputs = processor(images=image, return_tensors="pt")
            with torch.no_grad():
                base = sam2(
                    pixel_values=base_inputs["pixel_values"].to(args.device),
                    input_boxes=scaled,
                    multimask_output=True,
                )
                index = int(torch.argmax(base.iou_scores[0, 0]))
                reference_full = processor.post_process_masks(
                    base.pred_masks[:, :, index : index + 1],
                    original_sizes=[[height, width]],
                )[0][0, 0].cpu().numpy() > 0
            if int(reference_full.sum()) < 2000:
                continue
            ys, xs = np.nonzero(reference_full)
            left, top, right, bottom = xs.min(), ys.min(), xs.max(), ys.max()
            centre_x, centre_y = int((left + right) / 2), int((top + bottom) / 2)
            rect_w = max(12, int(0.6 * (right - left + 1)))
            rect_h = max(12, int(0.6 * (bottom - top + 1)))
            x0 = min(max(centre_x - rect_w // 2, 0), width - rect_w)
            y0 = min(max(centre_y - rect_h // 2, 0), height - rect_h)
            rectangle = np.zeros((height, width), bool)
            rectangle[y0 : y0 + rect_h, x0 : x0 + rect_w] = True
            rate = float((rectangle & reference_full).sum()) / max(int(reference_full.sum()), 1)
            if not 0.2 <= rate <= 0.7:
                continue
            occluded = image_bgr.copy()
            occluded[y0 : y0 + rect_h, x0 : x0 + rect_w] = (85, 85, 85)
            occluded_image = Image.fromarray(cv2.cvtColor(occluded, cv2.COLOR_BGR2RGB))
            inputs = processor(images=occluded_image, return_tensors="pt")
            with torch.no_grad():
                output = model(
                    inputs["pixel_values"].to(args.device),
                    input_boxes=torch.as_tensor(box * scale, device=args.device)[None, None],
                )
                pred_visible = processor.post_process_masks(
                    output["masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
                pred_amodal = processor.post_process_masks(
                    output["amodal_masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
            visible_truth = reference_full & ~rectangle
            hull, hull_iou = hull_baseline(visible_truth, reference_full)
            modal_iou = iou(pred_visible, visible_truth)
            amodal_iou = iou(pred_amodal, reference_full)
            visibility = output["visibility"][0, 0].cpu().numpy()
            photo_small = cv2.resize(image_bgr, (PANEL, PANEL))
            occ_small = cv2.resize(occluded, (PANEL, PANEL))
            ref_small = small_mask(reference_full)
            vis_small = small_mask(pred_visible)
            amo_small = small_mask(pred_amodal)
            hull_small = small_mask(hull)
            rows.append(
                [
                    panel(photo_small, None, (0, 0, 0), titles[0]),
                    panel(occ_small, None, (0, 0, 0), titles[1]),
                    panel(photo_small, ref_small, (220, 60, 220), titles[2]),
                    panel(occ_small, vis_small, (60, 200, 90), titles[3]),
                    panel(occ_small, amo_small, (240, 120, 40), titles[4]),
                    panel(occ_small, hull_small, (0, 220, 220), titles[5]),
                ]
            )
            headers.append(
                f"{path.name} score={scores[rank]:.2f} rate={rate:.2f} "
                f"modalIoU={modal_iou:.2f} amodalIoU={amodal_iou:.2f} hull={hull_iou:.2f} "
                f"vis={visibility[0]:.2f}/{visibility[1]:.2f}"
            )
            print(headers[-1], flush=True)

    if not rows:
        raise SystemExit("no sample passed the filters")
    gap = 6
    row_height = PANEL + 26
    canvas = np.full((34 + len(rows) * row_height, len(titles) * (PANEL + gap), 3), 248, np.uint8)
    for column, title in enumerate(titles):
        cv2.putText(
            canvas, title, (column * (PANEL + gap) + 8, 22),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 1, cv2.LINE_AA,
        )
    for row_index, (panels, header) in enumerate(zip(rows, headers, strict=True)):
        y0 = 34 + row_index * row_height
        cv2.putText(canvas, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (20, 20, 20), 1)
        for column, item in enumerate(panels):
            x0 = column * (PANEL + gap)
            canvas[y0 + 24 : y0 + 24 + PANEL, x0 : x0 + PANEL] = item
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(args.output), canvas):
        raise SystemExit(f"cannot write {args.output}")
    (args.output.parent / "visualization.json").write_text(
        json.dumps(
            {"checkpoint": str(args.checkpoint), "rows": headers, "titles": titles},
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"saved {args.output} ({canvas.shape[1]}x{canvas.shape[0]})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
