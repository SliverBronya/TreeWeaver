"""CPU-only forward/backward smoke for one frozen-cohort visible arm."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
OUT = ROOT / "reports/frozen-visible-smoke-2026-11-09"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def rgb(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array(
        [0.229, 0.224, 0.225]
    )
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask(path):
    image = np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16
    image = Image.fromarray(image.astype(np.uint8) * 255).resize(
        (256, 256), Image.NEAREST
    )
    return torch.from_numpy(np.asarray(image, dtype=np.float32) / 255.0)[None, None]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", default="lora_only")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    row = index["train"]["records"][0]
    image = rgb(row["paths"]["image"])
    target = mask(row["paths"]["visible"])
    x0, y0, x1, y1 = row["box_xyxy"]
    width, height = row["mask_wh"]
    boxes = torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(
        base,
        encoder_lora_rank=4 if args.arm in {"lora_only", "lora_pf"} else 0,
        encoder_focus_rank=16 if args.arm in {"encoder_pf_only", "lora_pf"} else 0,
        encoder_focus_chunked=True,
        encoder_focus_null_token=True,
    )
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        enabled = (
            args.arm in {"lora_only", "lora_pf"} and name.endswith(("lora_a", "lora_b"))
        ) or (
            args.arm in {"encoder_pf_only", "lora_pf"} and name.startswith("encoder_focus.")
        ) or (
            args.arm == "mask_readout"
            and name.startswith(
                (
                    "decoder.mask_tokens",
                    "decoder.output_hypernetworks_mlps",
                    "decoder.iou_token",
                    "decoder.obj_score_token",
                )
            )
        )
        if enabled:
            parameter.requires_grad_(True)
    model.train()
    output = model(image, input_boxes=boxes)
    logits = output["masks"][:, 0, 0]
    loss = F.binary_cross_entropy_with_logits(logits, target[:, 0])
    loss.backward()
    trainable = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
    with_grad = [(n, float(p.grad.abs().sum())) for n, p in trainable if p.grad is not None]
    report = {
        "arm": args.arm,
        "device": "cpu",
        "sample": row["scene"],
        "image_pixels": image.shape[-2:],
        "box": row["box_xyxy"],
        "loss": float(loss.detach()),
        "trainable_tensors": len(trainable),
        "trainable_params": sum(p.numel() for _, p in trainable),
        "tensors_with_grad": len(with_grad),
        "nonzero_grad_tensors": sum(value > 0 for _, value in with_grad),
        "sample_grad": with_grad[:5],
    }
    (OUT / f"{args.arm}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
