"""Fine-tune the focused cohort with box+positive+negative prompts."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-negative-prompt-training-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def point(mask):
    ys, xs = np.where(mask)
    if not len(xs):
        return None
    k = np.argmin((xs - xs.mean()) ** 2 + (ys - ys.mean()) ** 2)
    return float(xs[k]), float(ys[k])


def sample(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = mask(DATA / row["scene"] / "visible_target.png")
    neighbour = mask(DATA / row["scene"] / "visible_neighbour.png")
    ys, xs = np.where(visible)
    box = np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32)
    box = lb.boxes(box)
    pos, neg = point(visible), point(neighbour)
    def transform(p):
        return [p[0] * lb.scale + lb.pad_x, p[1] * lb.scale + lb.pad_y] if p else None
    pos, neg = transform(pos), transform(neg)
    target = np.asarray(
        Image.fromarray(visible.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)
    ) > 127
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        torch.tensor([pos, neg], dtype=torch.float32)[None, None],
        torch.tensor([1, 0], dtype=torch.int64)[None, None],
        torch.from_numpy(target.astype(np.float32))[None, None],
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    model.cuda()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.endswith(("lora_a", "lora_b")):
            parameter.requires_grad_(True)
    return model


def infer(model, image, box, points, labels, use_points):
    kwargs = {"input_boxes": box}
    if use_points:
        kwargs["input_points"] = points
        kwargs["input_labels"] = labels
    with torch.no_grad():
        output = model(image, **kwargs)
    return output["masks"][0, 0, 0].sigmoid().cpu() > 0.5


def evaluate(model, rows, use_points):
    values = []
    for row in rows:
        image, box, points, labels, target = sample(row)
        pred = infer(model, image.cuda(), box.cuda(), points.cuda(), labels.cuda(), use_points)
        t = target[0, 0] > 0.5
        inter = (pred & t).sum().item()
        union = (pred | t).sum().item()
        values.append(inter / union if union else 1.0)
    return float(np.mean(values))


def main():
    OUT.mkdir(exist_ok=True)
    rows = json.loads((DATA / "index.json").read_text())
    train = [r for r in rows if r["split"] == "train"]
    val = [r for r in rows if r["split"] == "validation"]
    model = build()
    parameters = [p for p in model.parameters() if p.requires_grad]
    before_box = evaluate(model, val, False)
    before_prompt = evaluate(model, val, True)
    print(json.dumps({"train": len(train), "val": len(val), "before_box": before_box, "before_prompt": before_prompt, "trainable": sum(p.numel() for p in parameters)}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    model.train()
    history = []
    for step in range(1, 301):
        row = train[(step - 1) % len(train)]
        image, box, points, labels, target = sample(row)
        optimizer.zero_grad(set_to_none=True)
        output = model(
            image.cuda(),
            input_boxes=box.cuda(),
            input_points=points.cuda(),
            input_labels=labels.cuda(),
        )
        logits = output["masks"][:, 0, 0]
        t = target.cuda()[:, 0]
        bce = F.binary_cross_entropy_with_logits(logits, t)
        p = logits.sigmoid()
        dice = 1 - (2 * (p * t).sum() + 1) / (p.sum() + t.sum() + 1)
        loss = bce + dice
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        history.append(float(loss.detach()))
        if step % 25 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 50 == 0 or step == 300:
            print(json.dumps({"eval_step": step, "box": evaluate(model, val, False), "prompt": evaluate(model, val, True)}), flush=True)
            torch.save({"state": {k: v.detach().cpu() for k, v in model.named_parameters() if v.requires_grad}}, OUT / "checkpoint.pth")
    result = {
        "before_box": before_box,
        "before_prompt": before_prompt,
        "after_box": evaluate(model, val, False),
        "after_prompt": evaluate(model, val, True),
        "loss_start": history[0],
        "loss_end": history[-1],
        "train": len(train),
        "val": len(val),
    }
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
