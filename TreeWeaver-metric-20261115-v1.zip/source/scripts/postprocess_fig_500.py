"""Index new full-scene target-ID renders without inventing visible labels.

Legacy datasets are deliberately read-only. Use audit_fig_data.py to inspect
historical metadata; do not repair past experiment labels in place.
"""

from __future__ import annotations

import argparse
import json
import os
from collections import Counter
from pathlib import Path

import cv2
import numpy as np
from fig_data_protocol import GENERATOR_SCHEMA, pair_metrics

COLORS = [(60, 130, 255), (255, 150, 40), (80, 210, 100), (220, 80, 160)]


def read_mask(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None or image.ndim != 3 or image.shape[-1] != 4:
        raise ValueError(f"expected RGBA mask: {path}")
    return image[..., 3] > 16


def postprocess(root: Path) -> dict:
    if (root / "index.json").exists():
        raise FileExistsError("index exists; refusing to overwrite an indexed dataset")
    meta_files = sorted((root / "meta").glob("*.json"))
    if not meta_files:
        raise ValueError("no rendered metadata")
    metas = [json.loads(path.read_text(encoding="utf-8")) for path in meta_files]
    for meta in metas:
        if (
            meta.get("generator_schema") != GENERATOR_SCHEMA
            or meta.get("visible_label_source") != "full-scene-target-id-alpha-preserved"
        ):
            raise ValueError("legacy labels are read-only: render a new v3 dataset instead")
        checks = root / "masks" / f"{int(meta['id']):06d}" / "label_checks.json"
        if not checks.exists():
            raise ValueError(f"missing target-ID checks for image {meta['id']}")
    usage, counts = Counter(), Counter()
    records = []
    for meta_path, meta in zip(meta_files, metas, strict=True):
        image_id = int(meta["id"])
        mask_dir = root / "masks" / f"{image_id:06d}"
        masks = [read_mask(mask_dir / f"amodal_{i + 1}.png") for i in range(len(meta["trees"]))]
        visible = [read_mask(mask_dir / f"visible_{i + 1}.png") for i in range(len(meta["trees"]))]
        if (np.stack(visible).sum(axis=0) > 1).any():
            raise ValueError(f"conflicting visible IDs in {image_id}")
        for i, (full, seen) in enumerate(zip(masks, visible, strict=True)):
            if (seen & ~full).any():
                raise ValueError(f"visible outside isolated support: {image_id} tree {i + 1}")
        ownership = np.zeros((*masks[0].shape, 3), np.uint8)
        instance_ids = np.zeros(masks[0].shape, np.uint16)
        for i, mask in enumerate(visible):
            ownership[mask] = COLORS[i % len(COLORS)]
            instance_ids[mask] = i + 1
        cv2.imwrite(str(mask_dir / "ownership.png"), ownership[..., ::-1])
        cv2.imwrite(str(mask_dir / "instance_ids.png"), instance_ids)
        meta["pairs"] = pair_metrics(masks)
        meta["pair_metrics_source"] = "all unordered pairs of isolated amodal supports"
        meta["visible_px"] = [int(mask.sum()) for mask in visible]
        meta["amodal_px"] = [int(mask.sum()) for mask in masks]
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        usage.update(meta["trees"])
        counts[meta["count"]] += 1
        records.append(
            {
                "id": image_id,
                "image": f"images/{image_id:06d}.png",
                "masks": f"masks/{image_id:06d}",
                "count": meta["count"],
                "split": meta["split"],
            }
        )
    index = {
        "schema_version": GENERATOR_SCHEMA,
        "images": len(records),
        "by_tree_count": dict(sorted(counts.items())),
        "tree_usage": dict(sorted(usage.items())),
        "records": records,
        "visible_label_source": "full-scene-target-id-alpha-preserved",
        "split_manifest": "splits.json",
    }
    (root / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
    return index


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=os.environ.get("FIG_ROOT"))
    args = parser.parse_args()
    if args.root is None:
        parser.error("--root or FIG_ROOT is required; there is no legacy default")
    result = postprocess(args.root)
    print(json.dumps({key: result[key] for key in ("schema_version", "images", "by_tree_count")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
