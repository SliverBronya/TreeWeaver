"""Ownership-only, same frozen prior: old training data versus qualified extra layouts."""

from __future__ import annotations

import argparse
import copy
import json
import random
import sys

import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from ownership_features import ownership_logits as build_ownership_logits  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from resource_guard import assert_pretrained_experiment_allowed  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from whole_tree_objective import (  # noqa: E402
    balanced_ownership_ce,
    competitive_decode,
    ownership_target,
)


def main():
    assert_pretrained_experiment_allowed()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare-query-features", action="store_true")
    parser.add_argument("--seed", type=int, default=20261108)
    parser.add_argument("--out", type=str)
    args = parser.parse_args()
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = ROOT / (
        "reports/ownership-query-feature-ablation-2026-11-08"
        if args.compare_query_features
        else "reports/frozen-ownership-data-ablation-2026-11-08"
    )
    if args.out:
        out = ROOT / args.out
    out.mkdir(exist_ok=False)
    old = ROOT / "reports/fig-paired-v6-framing-30-2026-11-08"
    new = ROOT / "reports/mixed-identity-layout-qualification-2026-11-08"
    scopes = [assert_training_allowed(root) for root in (old, new)]
    admission = json.loads((new / "qualification-review.json").read_text())
    if not admission.get("bounded_ownership_training_allowed"):
        raise ValueError("extra layouts not admitted for this training task")
    frozen_path = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    protocol = {
        "steps_per_arm": 500,
        "lr": 0.001,
        "seed": args.seed,
        "seed_scope": "training sample order; frozen features and initial heads identical",
        "arms": ["shared_features", "query_features"]
        if args.compare_query_features
        else ["old_only", "mixed"],
        "trainable": ["ownership_projection", "ownership_conv", "ownership_bg"],
        "frozen_prior": str(frozen_path),
        "frozen_prior_sha256": sha256_file(frozen_path),
        "train_scopes": scopes,
        "split_hashes": [sha256_file(p / "splits.json") for p in (old, new)],
        "mix": "alternate old/new records; old_only uses same old record at each matching step",
        "new_data": str(new),
        "only_change_between_arms": "shared vs query-specific pixel evidence"
        if args.compare_query_features
        else "training data at alternating updates",
        "training_resolution": [256, 256],
        "evaluation_resolution": [640, 360],
        "test_accessed": False,
        "promoted": False,
        "gate": {
            "neighbour_relative_reduction": 0.10,
            "iou_drop_allowed": 0,
            "whole_crown_stem_recall_drop_at_most": 0.005,
        },
    }
    write(out / "protocol.json", protocol)
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = Sam2OcclusionModel(base, expose_query_features=True).to(device).eval()
    model.decoder.load_state_dict(
        torch.load(frozen_path, map_location="cpu", weights_only=True)["decoder"], strict=True
    )
    model.requires_grad_(False)
    datasets = {
        "old": PairedFigDataset(old, "train"),
        "new": PairedFigDataset(new, "train"),
        "validation": PairedFigDataset(old, "validation"),
    }
    train_assets = {
        i["asset"] for key in ("old", "new") for r in datasets[key].items for i in r["instances"]
    }
    val_assets = {i["asset"] for r in datasets["validation"].items for i in r["instances"]}
    if train_assets & val_assets:
        raise ValueError("cross-corpus source-asset leakage")
    cache = {}
    with torch.no_grad():
        for role, dataset in datasets.items():
            cache[role] = []
            for i, record in enumerate(dataset.items):
                sample = dataset.sample(i)
                inputs, _ = tensors(sample, device)
                result = model(**inputs)
                entry = {
                    "id": record["id"],
                    "condition": record["condition"],
                    "features": result["query_pixel_embeddings"].mean(1).cpu(),
                    "query_features": result["query_pixel_embeddings"].cpu()
                    if args.compare_query_features
                    else None,
                    "tokens": result["sam_tokens"][:, :, 0].cpu(),
                    "raw": result["masks"][0, :, 0].cpu(),
                    "target": torch.from_numpy(sample["visible"]),
                    "valid": torch.from_numpy(sample["whole_valid"]),
                }
                if role == "validation":
                    for name in (
                        "visible",
                        "visible_stem",
                        "visible_crown",
                        "raster_unknown",
                        "visible_part_unknown",
                    ):
                        entry["native_" + name] = np.stack(
                            [dataset._native_mask(x[name]) for x in record["instances"]]
                        )
                cache[role].append(entry)
            print(f"cached {role}: {len(cache[role])}", flush=True)
    heads = {name: getattr(model.decoder, name) for name in protocol["trainable"]}
    initial = {name: copy.deepcopy(head.state_dict()) for name, head in heads.items()}
    for head in heads.values():
        head.requires_grad_(True)
    frozen_state = {
        k: v.cpu().clone()
        for k, v in model.state_dict().items()
        if not k.startswith(tuple("decoder." + name + "." for name in heads))
    }

    pixel_mode = False

    def logits(row):
        if args.compare_query_features:
            features = row["query_features"].to(device)
            result, _ = build_ownership_logits(
                features,
                row["tokens"].to(device),
                heads["ownership_projection"],
                heads["ownership_conv"],
                heads["ownership_bg"],
                query_specific=pixel_mode,
            )
            return result[0]
        pixels = row["features"].to(device)
        query = heads["ownership_projection"](row["tokens"].to(device))
        object_map = heads["ownership_conv"](pixels)
        return torch.cat(
            [heads["ownership_bg"](pixels), torch.einsum("bchw,bkc->bkhw", object_map, query)], 1
        )[0]

    @torch.no_grad()
    def evaluate(learned):
        scores = {"independent": [], "mask_winner": [], "owner_winner": []}
        for row in cache["validation"]:
            if row["condition"] != "scene" or len(row["target"]) < 2:
                continue
            target = row["native_visible"]
            common = ~row["native_raster_unknown"].any(0)
            raw = F.interpolate(
                row["raw"][:, None], target.shape[-2:], mode="bilinear", align_corners=False
            )[:, 0]
            variants = {"independent": raw > 0, "mask_winner": competitive_decode(raw)}
            if learned:
                owner = F.interpolate(
                    logits(row)[None], target.shape[-2:], mode="bilinear", align_corners=False
                )[0].cpu()
                variants["owner_winner"] = competitive_decode(raw, owner)
            for variant, preds in variants.items():
                if not torch.equal(preds.any(0), (raw > 0).any(0)):
                    raise ValueError("foreground union changed")
                pred = preds.numpy() & common
                truth = target & common
                for q in range(len(pred)):
                    p, t = pred[q], truth[q]
                    intersection = int((p & t).sum())
                    foreign = np.delete(truth, q, axis=0).any(0) & ~t
                    metrics = {
                        "iou": intersection / max(int((p | t).sum()), 1),
                        "recall": intersection / max(int(t.sum()), 1),
                        "neighbour_fraction": int((p & foreign).sum()) / max(int(p.sum()), 1),
                    }
                    for part in ("crown", "stem"):
                        support = (
                            row["native_visible_" + part][q]
                            & common
                            & ~row["native_visible_part_unknown"][q]
                        )
                        metrics[part + "_recall"] = (
                            float((p & support).sum() / support.sum()) if support.any() else None
                        )
                    scores[variant].append(metrics)
        return {
            variant: {
                key: float(np.mean([r[key] for r in rows if r[key] is not None])) for key in rows[0]
            }
            for variant, rows in scores.items()
            if rows
        }

    control = evaluate(False)
    rng = random.Random(args.seed)
    order = [
        (rng.randrange(len(cache["old"])), rng.randrange(len(cache["new"]))) for _ in range(500)
    ]
    results = {"controls": control}
    for arm in protocol["arms"]:
        pixel_mode = arm == "query_features"
        for name, head in heads.items():
            head.load_state_dict(initial[name], strict=True)
        optimizer = torch.optim.AdamW([p for h in heads.values() for p in h.parameters()], lr=0.001)
        history = []
        for step, (old_index, new_index) in enumerate(order):
            row = (
                cache["new"][new_index]
                if (args.compare_query_features or arm == "mixed") and step % 2
                else cache["old"][old_index]
            )
            optimizer.zero_grad(set_to_none=True)
            target, known = ownership_target(row["target"].to(device), row["valid"].to(device))
            loss = balanced_ownership_ce(logits(row), target, known)
            if not torch.isfinite(loss):
                raise ValueError("nonfinite ownership loss")
            loss.backward()
            optimizer.step()
            history.append(float(loss.detach()))
            if (step + 1) % 100 == 0:
                print(f"{arm}: {step + 1}/500 CE={np.mean(history[-50:]):.5f}", flush=True)
        results[arm] = evaluate(True)
        reference = control["mask_winner"]
        candidate = results[arm]["owner_winner"]
        results[arm]["accepted"] = bool(
            candidate["neighbour_fraction"] <= reference["neighbour_fraction"] * 0.9
            and candidate["iou"] >= reference["iou"]
            and all(
                candidate[k] >= reference[k] - 0.005
                for k in ("recall", "crown_recall", "stem_recall")
            )
            and candidate["iou"] >= control["independent"]["iou"]
            and all(
                candidate[k] >= control["independent"][k] - 0.005
                for k in ("recall", "crown_recall", "stem_recall")
            )
        )
        for key, value in model.state_dict().items():
            if key in frozen_state and not torch.equal(value.cpu(), frozen_state[key]):
                raise ValueError(f"non-ownership weights changed: {key}")
        results[arm]["non_ownership_weights_bitwise_unchanged"] = True
        results[arm]["train_loss"] = history
        torch.save(
            {"heads": {k: h.state_dict() for k, h in heads.items()}, "protocol": protocol},
            out / f"{arm}-final.pth",
        )
        write(out / "results.json", results)
        print(arm, results[arm]["owner_winner"], "accepted", results[arm]["accepted"], flush=True)


if __name__ == "__main__":
    main()
