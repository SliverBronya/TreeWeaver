"""Render synthetic two-tree occlusion pairs in Blender (EEVEE).

Each pair places one target tree in the centre and two neighbour trees at the
crown edges. Outputs:
  pair_XX_rgb.png    full scene
  pair_XX_tree0.png  target tree alone, transparent background (alpha = amodal)
  pair_XX_tree1.png  left neighbour alone
  pair_XX_tree2.png  right neighbour alone
  pair_XX.json       transforms and camera data
"""

from __future__ import annotations

import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ASSET = Path(r"D:\TreeWeaver\tools\assets\jacaranda_tree\jacaranda_tree_1k.blend")
OBJECT = "jacaranda_tree_LOD1"
RES_X, RES_Y = 960, 540
TARGET_HEIGHT = 10.0
LENS = 35.0


def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    out = Path(argv[0]) if argv else Path(r"D:\TreeWeaver\reports\blender-pairs-test")
    pairs = int(argv[1]) if len(argv) > 1 else 1
    seed = int(argv[2]) if len(argv) > 2 else 7
    return out, pairs, seed


def clean_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "None"
    scene.render.image_settings.color_depth = "8"
    scene.eevee.taa_render_samples = 32
    return scene


def append_tree():
    bpy.ops.wm.append(directory=str(ASSET) + "/Object/", filename=OBJECT)
    obj = bpy.data.objects[OBJECT]
    for other in list(bpy.data.objects):
        if other is not obj:
            bpy.data.objects.remove(other, do_unlink=True)
    return obj


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points),
        max(p.x for p in points),
        min(p.y for p in points),
        max(p.y for p in points),
        min(p.z for p in points),
        max(p.z for p in points),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = (scale, scale, scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def add_ground():
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    ground = bpy.context.object
    material = bpy.data.materials.new("ground_mat")
    material.use_nodes = True
    bsdf = material.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.16, 0.22, 0.10, 1.0)
    bsdf.inputs["Roughness"].default_value = 1.0
    ground.data.materials.append(material)
    return ground


def add_world():
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    background = world.node_tree.nodes.get("Background")
    background.inputs["Color"].default_value = (0.55, 0.70, 0.85, 1.0)
    background.inputs["Strength"].default_value = 0.8
    bpy.context.scene.world = world


def add_lights():
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = 3.0
    sun.data.angle = math.radians(8)
    sun.rotation_euler = (math.radians(55), 0, math.radians(25))
    bpy.ops.object.light_add(type="AREA", location=(-12, -8, 12))
    fill = bpy.context.object
    fill.data.energy = 800
    fill.data.size = 12
    fill.rotation_euler = (math.radians(60), 0, math.radians(-30))


def add_camera():
    bpy.ops.object.camera_add()
    camera = bpy.context.object
    camera.data.lens = LENS
    camera.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / LENS)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    camera.location = (0, -distance, TARGET_HEIGHT / 2)
    camera.rotation_euler = (math.radians(90), 0, 0)
    bpy.context.scene.camera = camera
    return camera, distance


def render(path: Path, transparent: bool, hidden=()):
    scene = bpy.context.scene
    scene.render.film_transparent = transparent
    for obj in bpy.data.objects:
        if obj.type == "MESH":
            obj.hide_render = obj.name in hidden
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)


def main():
    out, pairs, seed = parse_args()
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    summary = []
    for index in range(pairs):
        scene = clean_scene()
        base = append_tree()
        normalize(base, TARGET_HEIGHT)
        base.name = "tree_target"
        base.rotation_euler = (0, 0, math.radians(rng.uniform(-8, 8)))

        left = duplicate(base)
        left.name = "tree_left"
        left.scale = tuple(value * rng.uniform(0.80, 0.95) for value in base.scale)
        left.location = (-rng.uniform(6.3, 7.1), rng.uniform(0.5, 1.5), 0)
        left.rotation_euler = (0, 0, math.radians(rng.uniform(70, 140)))

        right = duplicate(base)
        right.name = "tree_right"
        right.scale = tuple(value * rng.uniform(0.82, 0.96) for value in base.scale)
        right.location = (rng.uniform(6.3, 7.1), rng.uniform(-1.5, -0.5), 0)
        right.rotation_euler = (0, 0, math.radians(rng.uniform(-140, -70)))

        ground = add_ground()
        add_world()
        add_lights()
        camera, distance = add_camera()

        prefix = f"pair_{index:02d}"
        render(out / f"{prefix}_rgb.png", transparent=False)
        for name, obj in (("target", base), ("left", left), ("right", right)):
            others = [o.name for o in (base, left, right) if o is not obj] + [ground.name]
            render(out / f"{prefix}_{name}.png", transparent=True, hidden=others)

        summary.append(
            {
                "pair": index,
                "camera_distance": distance,
                "target_height_fraction": 0.85,
                "objects": {
                    "target": [round(v, 3) for v in base.location],
                    "left": [round(v, 3) for v in left.location],
                    "right": [round(v, 3) for v in right.location],
                },
            }
        )
        print(f"rendered {prefix}", flush=True)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("done", len(summary))


if __name__ == "__main__":
    main()
