"""Compare mask/curve consistency between two checkpoints on the composite val split."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from broadleaf_composites import BroadleafComposites  # noqa: E402
from curve_consistency import band_observed, curve_profile_loss  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def evaluate(checkpoint: Path, dataset, model, device: str, items: int):
    payload = torch.load(checkpoint, map_location=device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    model.eval()
    profile_errors = []
    curve_errors = []
    mask_ious = []
    with torch.no_grad():
        for index in range(min(items, len(dataset))):
            sample = dataset.sample(index, deterministic=True)
            pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
            box = torch.as_tensor(sample["box"])[None, None].to(device)
            output = model(pixel_values, input_boxes=box)
            target = torch.as_tensor(sample["mask"])[None].to(device)
            target_curve = torch.as_tensor(sample["curve"])[None, None].to(device)
            observed = torch.as_tensor(sample["curve_observed"])[None, None].to(device)
            bands = band_observed(target, target_curve.shape[-1])[:, None]
            observed = observed * bands.to(observed.dtype)
            logits = output["masks"][:, :, 0]
            curve = output["curve"]
            profile_errors.append(
                float(curve_profile_loss(logits, target_curve, observed).cpu())
            )
            curve_errors.append(
                float(
                    (((curve - target_curve) ** 2) * observed).sum()
                    / observed.sum().clamp_min(1.0)
                )
            )
            pred = logits > 0
            truth = target > 0.5
            mask_ious.append(
                float((pred & truth).sum()) / max(float((pred | truth).sum()), 1.0)
            )
    return {
        "profile_error": float(np.mean(profile_errors)),
        "curve_error": float(np.mean(curve_errors)),
        "mask_iou": float(np.mean(mask_ious)),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--curve", type=Path, required=True)
    parser.add_argument("--items", type=int, default=40)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    dataset = BroadleafComposites(args.dataset, "val", mean=mean, std=std)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()

    baseline = evaluate(args.baseline, dataset, model, args.device, args.items)
    curve = evaluate(args.curve, dataset, model, args.device, args.items)
    result = {"baseline": baseline, "curve": curve}
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
