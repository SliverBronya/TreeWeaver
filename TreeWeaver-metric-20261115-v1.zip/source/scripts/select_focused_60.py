"""Select 60 eligible focused composites and freeze a pilot split."""

from __future__ import annotations

import json
import shutil
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(r"D:\TreeWeaver\reports\focused-composite-v3-2026-11-10")
OUT = Path(r"D:\TreeWeaver\reports\focused-composite-v3-60-2026-11-10")


def main():
    rows = json.loads((ROOT / "index.json").read_text(encoding="utf-8"))
    eligible = [
        r
        for r in rows
        if 0.05 <= r["crown_overlap_fraction"] <= 0.30
        and 0.05 <= r["target_hidden_fraction"] <= 0.30
        and 0.85 <= r["target_height_fraction"] <= 0.95
        and abs(r["target_center_x_fraction"] - 0.5) <= 0.10
        and abs(r["target_center_y_fraction"] - 0.5) <= 0.10
    ]
    assets = sorted({r["target_asset"] for r in eligible})
    train_assets = set(assets[: max(1, round(len(assets) * 0.7))])
    val_assets = set(assets[len(train_assets) : len(train_assets) + max(1, len(assets) // 6)])
    test_assets = set(assets) - train_assets - val_assets
    selected = []
    for row in eligible:
        if len(selected) >= 60:
            break
        if row["target_asset"] in train_assets:
            split = "train"
        elif row["target_asset"] in val_assets:
            split = "validation"
        else:
            split = "test"
        selected.append({**row, "split": split})
    # Ensure all splits exist; reassign if needed.
    if not any(r["split"] == "validation" for r in selected):
        selected[0]["split"] = "validation"
    if not any(r["split"] == "test" for r in selected):
        selected[1]["split"] = "test"
    OUT.mkdir(parents=True, exist_ok=True)
    for row in selected:
        source = ROOT / row["scene"]
        target = OUT / row["scene"]
        if not target.exists():
            shutil.copytree(source, target)
    (OUT / "index.json").write_text(json.dumps(selected, indent=2), encoding="utf-8")
    summary = {
        "targets": len(selected),
        "splits": dict(Counter(r["split"] for r in selected)),
        "target_assets": len(assets),
        "height_mean": float(np.mean([r["target_height_fraction"] for r in selected])),
        "height_median": float(np.median([r["target_height_fraction"] for r in selected])),
        "overlap_mean": float(np.mean([r["crown_overlap_fraction"] for r in selected])),
        "overlap_min": min(r["crown_overlap_fraction"] for r in selected),
        "overlap_max": max(r["crown_overlap_fraction"] for r in selected),
        "hidden_mean": float(np.mean([r["target_hidden_fraction"] for r in selected])),
        "hidden_min": min(r["target_hidden_fraction"] for r in selected),
        "hidden_max": max(r["target_hidden_fraction"] for r in selected),
        "center_x_range": [min(r["target_center_x_fraction"] for r in selected), max(r["target_center_x_fraction"] for r in selected)],
        "center_y_range": [min(r["target_center_y_fraction"] for r in selected), max(r["target_center_y_fraction"] for r in selected)],
        "note": "neighbour assets are not split-isolated; pilot only",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
