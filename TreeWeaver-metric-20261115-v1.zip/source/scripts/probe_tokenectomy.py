"""Tokenectomy: is the real-domain gap caused by the extra decoder tokens?

The five-hour checkpoint decodes with a 10-token sequence (6 stock tokens + 4 extra:
amodal, visibility, curve, occluder). This probe loads the *same weights* into the
stock 6-token decoder, which simply drops the extra tokens, and evaluates three
models under identical prompts:

* ``stock_sam2``          - untouched SAM2.1 tiny;
* ``five_hour``           - the checkpoint with its extra tokens;
* ``five_hour_tokenless`` - the checkpoint's weights with the extra tokens removed.

No training and no weight change: the only difference between the last two is whether
the extra tokens sit in the attention sequence. If the tokenless version recovers a
large part of the 20-point gap on real trunks, the tokens are the main cause; if it
stays low, the synthetic training itself is.

Data: CanaTree100 fold_00 (val/test, dense winter forest) and the TreeStereo trunk
reference (near-view, one annotated trunk per frame).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from evaluate_treestereo_visible import decode_reference, reference_box  # noqa: E402
from probe_canatree_adhesion import (  # noqa: E402
    REVISION,
    base_point,
    decode_image,
    load_fold,
)
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import mask_row, mean_of, write_json  # noqa: E402
from strip_refine import refine_mask  # noqa: E402

CHECKPOINT = ROOT / "reports/fig500-long-5h-v2-2026-10-31/best.pth"
TRUNKS = ROOT / "data/external/tree-stereo-biophysical-v4/extracted/trunks"
CONDITIONS = (("full", "box"), ("full", "pos"), ("strip", "pos"))
EXTRA_PREFIXES = (
    "amodal_token",
    "visibility_token",
    "curve_token",
    "occluder_token",
    "stem_token",
    "amodal_hypernets",
    "occluder_hypernet",
    "stem_hypernet",
    "router",
    "visibility_mean",
    "visibility_log_variance",
    "curve_head",
    "amodal_scale",
    "ownership_projection",
    "ownership_conv",
    "ownership_bg",
    "layer_head",
)
X_MARGIN, Y_MARGIN = 5.0, 0.05


def mask_logits(model, pixels, boxes, height, width, point=None):
    scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
    with torch.inference_mode():
        arguments = {
            "pixel_values": pixels,
            "input_boxes": torch.as_tensor(boxes * scale, device=pixels.device)[None],
            "multimask_output": False,
        }
        if point is not None:
            point_scale = np.asarray([1024 / width, 1024 / height], np.float32)
            scaled = np.atleast_2d(point).astype(np.float32) * point_scale
            arguments["input_points"] = torch.as_tensor(
                scaled, device=pixels.device
            )[None, :, None, :]
            arguments["input_labels"] = torch.ones(
                (1, scaled.shape[0], 1), dtype=torch.long, device=pixels.device
            )
        output = model(**arguments)
        if hasattr(output, "pred_masks"):
            logits = output.pred_masks[0, :, 0]
        else:
            logits = output["masks"][0, :, 0]
    upscaled = F.interpolate(logits[:, None], (height, width), mode="bilinear", align_corners=False)
    return (upscaled[:, 0] > 0).cpu().numpy()


def build_models(device):
    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    payload = torch.load(CHECKPOINT, map_location=device, weights_only=True)
    decoder = payload["decoder"]

    stock = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(device).eval()

    five_hour = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(device)
    occlusion = Sam2OcclusionModel(five_hour, knots=12, experts=3).to(device)
    report = occlusion.decoder.load_state_dict(decoder, strict=False)
    missing = [
        key for key in report.missing_keys if not key.startswith(("stem_token.", "stem_hypernet."))
    ]
    if missing:
        raise ValueError(f"unexpected missing keys: {missing}")
    if report.unexpected_keys:
        raise ValueError(f"unexpected keys: {report.unexpected_keys}")
    occlusion.eval()

    tokenless_host = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(device)
    report = tokenless_host.mask_decoder.load_state_dict(decoder, strict=False)
    extra = [key for key in report.unexpected_keys if key.split(".")[0] in EXTRA_PREFIXES]
    other = [key for key in report.unexpected_keys if key.split(".")[0] not in EXTRA_PREFIXES]
    if report.missing_keys or other or len(extra) != len(report.unexpected_keys):
        raise ValueError(
            f"token removal was not clean: missing={report.missing_keys} other={other}"
        )
    tokenless_host.eval()

    return {
        "stock_sam2": stock,
        "five_hour": occlusion,
        "five_hour_tokenless": tokenless_host,
    }, {"removed_extra_keys": sorted(extra), "checkpoint_sha256": sha256_file(CHECKPOINT)}


def prepare_canatree(by_image, grouped, processor, device):
    prepared = []
    for image_id, image in by_image.items():
        image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
        pixels = processor(
            images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)), return_tensors="pt"
        )["pixel_values"].to(device)
        prepared.append(
            {
                "name": image["file_name"],
                "image_bgr": image_bgr,
                "boxes": boxes,
                "masks": masks,
                "height": height,
                "width": width,
                "pixels": pixels,
                "points": np.stack(
                    [
                        np.asarray(base_point(masks[index], boxes[index]), np.float32)
                        for index in range(len(boxes))
                    ]
                ),
            }
        )
    return prepared


def evaluate_canatree(model, model_name, prepared, processor, device, window, prompt):
    rows = []
    for frame in prepared:
        if window == "full":
            predicted = mask_logits(
                model,
                frame["pixels"],
                frame["boxes"],
                frame["height"],
                frame["width"],
                point=frame["points"] if prompt == "pos" else None,
            )
        else:
            predicted = np.stack(
                [
                    refine_mask(
                        model,
                        processor,
                        frame["image_bgr"],
                        frame["boxes"][index],
                        frame["points"][index] if prompt == "pos" else None,
                        device,
                        x_margin=X_MARGIN,
                        y_margin=Y_MARGIN,
                    )
                    for index in range(len(frame["masks"]))
                ]
            )
        for index in range(len(frame["masks"])):
            others = [
                frame["masks"][other] for other in range(len(frame["masks"])) if other != index
            ]
            rows.append(
                {
                    "tree": f"{frame['name']}:{index}",
                    "model": model_name,
                    "condition": f"{window}/{prompt}",
                    "metrics": mask_row(
                        f"{frame['name']}:{index}",
                        predicted[index],
                        frame["masks"][index],
                        others=others,
                    ),
                }
            )
    return rows


def tree_stereo_records():
    records = []
    for mask_path in sorted(TRUNKS.glob("*_LEFT_mask.jpg")):
        records.append(
            {
                "tree_id": mask_path.name.split("_")[0],
                "image": mask_path.with_name(mask_path.name.replace("_mask.jpg", ".jpg")),
                "mask": mask_path,
            }
        )
    return records


def evaluate_treestereo(model, model_name, processor, device, window, prompt):
    rows = []
    for record in tree_stereo_records():
        image_bgr = cv2.imread(str(record["image"]))
        mask = decode_reference(cv2.imread(str(record["mask"])))
        height, width = mask.shape
        box = np.asarray(reference_box(mask), np.float32)
        point = base_point(mask, box)
        if window == "full":
            pixels = processor(
                images=Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)),
                return_tensors="pt",
            )["pixel_values"].to(device)
            predicted = mask_logits(
                model, pixels, box[None], height, width, point=point if prompt == "pos" else None
            )[0]
        else:
            predicted = refine_mask(
                model,
                processor,
                image_bgr,
                box,
                point if prompt == "pos" else None,
                device,
                x_margin=X_MARGIN,
                y_margin=Y_MARGIN,
            )
        rows.append(
            {
                "tree": record["tree_id"],
                "model": model_name,
                "condition": f"{window}/{prompt}",
                "metrics": mask_row(record["tree_id"], predicted, mask),
            }
        )
    return rows


def block(rows):
    metrics = [row["metrics"] for row in rows]
    return {
        "trees": len(rows),
        "mean_iou": mean_of(metrics, "iou"),
        "mean_boundary_f1": mean_of(metrics, "boundary_f1"),
        "mean_recall": mean_of(metrics, "recall"),
        "mean_precision": mean_of(metrics, "precision"),
        "mean_neighbour_fraction": (
            mean_of(metrics, "neighbour_fraction") if "neighbour_fraction" in metrics[0] else None
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    models, removal = build_models(args.device)

    documents = {split: load_fold(split) for split in ("val", "test")}
    protocol = {
        "schema_version": "treeweaver-tokenectomy-1.0",
        "purpose": "separate extra-token architecture from synthetic-domain training",
        "intervention": (
            "load the identical five-hour decoder weights into the stock 6-token decoder; "
            "the amodal/visibility/curve/occluder tokens are dropped, nothing is retrained"
        ),
        "models": list(models),
        "conditions": [f"{window}/{prompt}" for window, prompt in CONDITIONS],
        "prompt": "GT-derived trunk box; pos = base-of-trunk point",
        "window": {"full": "whole frame", "strip": {"x_margin": X_MARGIN, "y_margin": Y_MARGIN}},
        "checkpoint": str(CHECKPOINT),
        "checkpoint_sha256": removal["checkpoint_sha256"],
        "removed_extra_keys": removal["removed_extra_keys"],
        "datasets": {
            "canatree100_fold00": {
                split: {
                    "fold_file_sha256": sha256_file(document[2]),
                    "images": len(document[0]),
                    "trunks": sum(len(values) for values in document[1].values()),
                }
                for split, document in documents.items()
            },
            "treestereo_trunks": {"trees": len(tree_stereo_records())},
        },
        "limitations": [
            "no retraining: the transformer weights were fit with ten tokens, so this is an "
            "inference-time intervention, not the model that training would produce",
            "CanaTree fold_00 is development-only and not video-disjoint",
            "TreeStereo annotates one trunk per frame, so it cannot measure adhesion",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    summary = {"results": {}, "protocol_sha256": sha256_file(args.output / "protocol.json")}
    prepared = {
        split: prepare_canatree(document[0], document[1], processor, args.device)
        for split, document in documents.items()
    }
    for model_name, model in models.items():
        summary["results"][model_name] = {}
        for split in ("val", "test"):
            for window, prompt in CONDITIONS:
                rows = evaluate_canatree(
                    model, model_name, prepared[split], processor, args.device, window, prompt
                )
                summary["results"][model_name].setdefault(split, {})[f"{window}/{prompt}"] = block(
                    rows
                )
                print(
                    json.dumps(
                        {
                            "dataset": "canatree",
                            "model": model_name,
                            "split": split,
                            "condition": f"{window}/{prompt}",
                            **block(rows),
                        }
                    ),
                    flush=True,
                )
                write_json(
                    args.output
                    / f"per_tree_canatree_{split}_{model_name}_{window}-{prompt}.json",
                    rows,
                )
        for window, prompt in CONDITIONS:
            rows = evaluate_treestereo(model, model_name, processor, args.device, window, prompt)
            summary["results"][model_name].setdefault("treestereo", {})[
                f"{window}/{prompt}"
            ] = block(rows)
            print(
                json.dumps(
                    {
                        "dataset": "treestereo",
                        "model": model_name,
                        "split": "all",
                        "condition": f"{window}/{prompt}",
                        **block(rows),
                    }
                ),
                flush=True,
            )
            write_json(
                args.output / f"per_tree_treestereo_{model_name}_{window}-{prompt}.json",
                rows,
            )
        write_json(args.output / "summary.json", summary)
    write_json(args.output / "summary.json", summary)
    print("DONE", json.dumps(summary["results"]))


if __name__ == "__main__":
    main()
