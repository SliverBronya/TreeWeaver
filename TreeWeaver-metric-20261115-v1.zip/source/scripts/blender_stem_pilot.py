"""Small labeled pilot with real stem masks (no depth yet)."""

from __future__ import annotations

import math
import json
import os
import random
from pathlib import Path

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
OUT = Path(
    os.environ.get(
        "PILOT_OUT",
        r"D:\TreeWeaver\reports\stem-depth-100-2026-11-06",
    )
)
COUNT = int(os.environ.get("PILOT_COUNT", "8"))
RES_X, RES_Y = 960, 540
MASK_X, MASK_Y = 480, 270


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 12
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(v * scale for v in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0


def load(path, height=9.0, trunk_only=False):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [o for o in bpy.data.objects if o not in before]
    meshes = [o for o in new if o.type == "MESH" and o.name not in {"Cube", "Camera", "Light"}]
    bpy.ops.object.select_all(action="DESELECT")
    for o in meshes:
        o.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for o in list(new):
        if o not in meshes:
            bpy.data.objects.remove(o, do_unlink=True)

    stem_meshes = [
        o for o in meshes if "bark" in o.name.lower() or (not trunk_only and "branch" in o.name.lower())
    ]
    stem_copies = []
    for o in stem_meshes:
        copy = o.copy()
        copy.data = o.data
        bpy.context.collection.objects.link(copy)
        stem_copies.append(copy)
    bpy.ops.object.select_all(action="DESELECT")
    for o in stem_copies:
        o.select_set(True)
    bpy.context.view_layer.objects.active = stem_copies[0]
    bpy.ops.object.join()
    stem = bpy.context.view_layer.objects.active
    stem.name = path.stem + "_stem"
    stem.hide_render = True

    bpy.ops.object.select_all(action="DESELECT")
    for o in meshes:
        o.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    normalize(tree, height)
    stem.scale = tree.scale
    stem.location = tree.location
    stem.rotation_euler = tree.rotation_euler
    return tree, stem


def ground():
    bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.22, 0.18, 0.12, 1)
    bsdf.inputs["Roughness"].default_value = 1.0
    obj.data.materials.append(mat)
    return obj


def world():
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs["Color"].default_value = (0.55, 0.62, 0.72, 1)
    w.node_tree.nodes["Background"].inputs["Strength"].default_value = 1.0
    bpy.context.scene.world = w


def camera(center, span, height=2.0):
    lens = 35.0
    hfov = 2 * math.atan(18 / lens)
    distance = max(span / (2 * math.tan(hfov / 2)) * 1.1, 16.0)
    bpy.ops.object.camera_add(location=(center, -distance, height))
    cam = bpy.context.object
    cam.data.lens = lens
    look = Vector((center, 0, 5.0))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam
    return cam


def depth_output(scene, scene_dir):
    scene.use_nodes = True
    scene.view_layers[0].use_pass_z = True
    tree = scene.node_tree
    tree.nodes.clear()
    layers = tree.nodes.new("CompositorNodeRLayers")
    output = tree.nodes.new("CompositorNodeOutputFile")
    output.base_path = str(scene_dir)
    output.format.file_format = "OPEN_EXR"
    output.file_slots[0].path = "depth_"
    composite = tree.nodes.new("CompositorNodeComposite")
    tree.links.new(layers.outputs["Image"], composite.inputs["Image"])
    depth_socket = layers.outputs.get("Depth") or layers.outputs.get("Z")
    tree.links.new(depth_socket, output.inputs[0])


def project_box(scene, camera_obj, obj, width, height):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    projected = [world_to_camera_view(scene, camera_obj, point) for point in points]
    xs = [p.x * width for p in projected]
    ys = [(1.0 - p.y) * height for p in projected]
    return [min(xs), min(ys), max(xs), max(ys)]


def main():
    rng = random.Random(20261106)
    paths = sorted(ROOT.glob("*.glb"))
    OUT.mkdir(parents=True, exist_ok=True)
    for scene_id in range(1, COUNT + 1):
        clean()
        chosen = rng.sample(paths, 3)
        trees, stems, widths = [], [], []
        for rank, path in enumerate(chosen):
            tree, stem = load(path, rng.uniform(8.5, 10.0))
            tree.location.y = rank * 2.5
            stem.location.y = tree.location.y
            trees.append(tree)
            stems.append(stem)
            bpy.context.view_layer.update()
            x0, x1, _, _, _, _ = bbox(tree)
            widths.append(x1 - x0)

        overlap = rng.uniform(0.35, 0.55)
        centers = [0.0]
        for i in range(1, 3):
            step = (widths[i - 1] + widths[i]) / 2 - overlap * min(widths[i - 1], widths[i])
            centers.append(centers[-1] + step)
        center = (centers[0] + centers[-1]) / 2
        for tree, stem, x in zip(trees, stems, centers, strict=True):
            tree.location.x = x - center
            stem.location.x = tree.location.x

        ground_obj = ground()
        world()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.0
        sun.rotation_euler = (math.radians(50), 0, math.radians(25))
        cam = camera(center, max(centers) - min(centers) + widths[-1], 2.0)

        scene_dir = OUT / f"{scene_id:06d}"
        scene_dir.mkdir()
        depth_output(bpy.context.scene, scene_dir)
        bpy.context.scene.render.filepath = str(scene_dir / "rgb.png")
        bpy.ops.render.render(write_still=True)
        bpy.context.scene.use_nodes = False
        bpy.context.scene.render.engine = "BLENDER_EEVEE_NEXT"
        bpy.context.scene.eevee.taa_render_samples = 16

        bpy.context.scene.render.film_transparent = True
        bpy.context.scene.render.resolution_x, bpy.context.scene.render.resolution_y = MASK_X, MASK_Y
        ground_obj.hide_render = True
        for i, (tree, stem) in enumerate(zip(trees, stems, strict=True), start=1):
            for other in trees + stems:
                other.hide_render = True
            tree.hide_render = False
            bpy.context.scene.render.filepath = str(scene_dir / f"amodal_{i}.png")
            bpy.ops.render.render(write_still=True)
            tree.hide_render = True
            stem.hide_render = False
            bpy.context.scene.render.filepath = str(scene_dir / f"stem_{i}.png")
            bpy.ops.render.render(write_still=True)
        for tree, stem in zip(trees, stems, strict=True):
            tree.hide_render = False
            stem.hide_render = True
        ground_obj.hide_render = False
        bpy.context.scene.render.film_transparent = False
        bpy.context.scene.render.resolution_x, bpy.context.scene.render.resolution_y = RES_X, RES_Y

        boxes = [
            project_box(bpy.context.scene, cam, tree, MASK_X, MASK_Y)
            for tree in trees
        ]
        meta = {
            "scene_id": scene_id,
            "trees": [path.stem for path in chosen],
            "layer_order_front_to_back": [path.stem for path in chosen],
            "boxes_xyxy": boxes,
            "count": len(chosen),
        }
        (scene_dir / "meta.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )
        print("SCENE", scene_id, flush=True)


if __name__ == "__main__":
    main()





