"""Freeze tree-disjoint visible-only training data, protecting prior evaluation IDs."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
from pathlib import Path

LEGACY_IDS = {211, 88, 207, 161, 94, 149}


def identity(filename):
    match = re.match(r"FT(\d+)(?:_|$)", filename, re.IGNORECASE)
    if not match:
        raise ValueError(f"Missing FT identity: {filename}")
    return int(match.group(1))


def partition(identities, protected, seed=20261102):
    available = sorted(set(identities) - set(protected) - LEGACY_IDS)
    random.Random(seed).shuffle(available)
    cut = int(len(available) * 0.8)
    if not cut or cut == len(available):
        raise ValueError("Insufficient source trees for train and validation")
    return {"train": sorted(available[:cut]), "validation": sorted(available[cut:])}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source",
        type=Path,
        default=Path("data/external/tree-stereo-biophysical-v4/extracted/full_trees"),
    )
    parser.add_argument(
        "--reference",
        type=Path,
        default=Path("reports/treestereo-visible-reference-2026-11-01/selection.json"),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20261102)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("Use a new frozen manifest path")
    reference = json.loads(args.reference.read_text(encoding="utf-8"))
    if reference.get("role") != "evaluation_only" or not reference.get("records"):
        raise ValueError("A frozen evaluation-only reference selection is required")
    if {identity(i) for i in reference["excluded_all_views_tree_ids"]} != LEGACY_IDS:
        raise ValueError("Legacy source exclusions changed; re-audit before preparing training")
    if sha(Path(reference["source_training_script"])) != reference["source_training_script_sha256"]:
        raise ValueError("Recorded composite training source changed; re-audit exclusions")
    protected = {identity(r["tree_id"]) for r in reference["records"]}
    pairs = []
    for mask in sorted(args.source.glob("*_LEFT_mask.jpg")):
        image = mask.with_name(mask.name.replace("_LEFT_mask.jpg", "_LEFT.jpg"))
        if not image.is_file():
            raise FileNotFoundError(image)
        pairs.append((identity(mask.stem), image, mask))
    splits = partition([i for i, _, _ in pairs], protected, args.seed)
    records = []
    for group, image, mask in pairs:
        if group in protected or group in LEGACY_IDS:
            continue
        role = "train" if group in splits["train"] else "validation"
        records.append(
            {
                "tree_id": f"FT{group}",
                "split": role,
                "image": str(image.resolve()),
                "visible_reference": str(mask.resolve()),
                "image_sha256": sha(image),
                "reference_sha256": sha(mask),
            }
        )
    result = {
        "schema_version": "treeweaver-real-visible-split-1.0",
        "seed": args.seed,
        "profile": "dataset_supplied_visible_reference",
        "supervision": ["visible_silhouette"],
        "mask_decode": "max(BGR)>127; filled JPEG silhouette, not leaf-alpha or amodal",
        "protected_reference_tree_ids": sorted(protected),
        "excluded_legacy_tree_ids": sorted(LEGACY_IDS),
        "reference_selection_sha256": sha(args.reference),
        "splits": splits,
        "records": records,
        "tree_disjoint": True,
        "scene_disjoint": False,
        "notes": (
            "Prepared for a separate visible-only pilot; no training performed. "
            "No independent blind-test claim."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "trees": {k: len(v) for k, v in splits.items()},
                "records": len(records),
                "output": str(args.output),
            }
        )
    )


if __name__ == "__main__":
    main()
