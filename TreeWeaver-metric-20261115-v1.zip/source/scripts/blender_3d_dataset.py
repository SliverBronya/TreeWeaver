"""Generate the target-centric 3D candidate cohort with trunk/crown labels."""

from __future__ import annotations

import json
import math
import random
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from blender_focused_3d import fit_camera, ground, setup  # noqa: E402
from blender_stem_pilot import load  # noqa: E402

ASSETS = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
OUT = Path(r"D:\TreeWeaver\reports\focused-3d-candidates-2026-11-10")
COUNT = 220


def save_mask(path, mask):
    height, width = mask.shape
    image = bpy.data.images.new("mask", width=width, height=height, alpha=True)
    pixels = np.zeros((height, width, 4), np.float32)
    pixels[..., 3] = mask.astype(np.float32)
    image.pixels = pixels.ravel()
    image.filepath_raw = str(path)
    image.file_format = "PNG"
    image.save()
    bpy.data.images.remove(image)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rng = random.Random(20261110)
    assets = sorted(path.stem for path in ASSETS.glob("*.glb"))
    cases = []
    for index in range(COUNT):
        count = 2 if index % 3 == 0 else 3
        chosen = rng.sample(assets, count)
        cases.append(chosen)
    for number, names in enumerate(cases, start=1):
        if (OUT / f"{number:06d}").exists():
            continue
        setup()
        trees, stems = [], []
        for index, name in enumerate(names):
            tree, stem = load(ASSETS / f"{name}.glb", [9.0, 7.5, 7.0][index], trunk_only=True)
            tree.location.y = index * 2.2
            trees.append(tree)
            stems.append(stem)
        ground()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 14))
        sun = bpy.context.object
        sun.data.energy = 2.2
        sun.rotation_euler = (math.radians(45), 0, math.radians(30))
        bpy.ops.object.camera_add(location=(0, -20, 2.5))
        camera = bpy.context.object
        camera.data.lens = 50
        bpy.context.scene.camera = camera
        fit_camera(camera, trees[0])
        trees[1].location.x, trees[1].location.y = 7.5, 4.0
        if len(trees) == 3:
            trees[2].location.x, trees[2].location.y = -7.5, 6.0
        for stem, tree in zip(stems, trees, strict=True):
            stem.location = tree.location
            stem.rotation_euler = tree.rotation_euler
            stem.scale = tree.scale
        scene_dir = OUT / f"{number:06d}"
        scene_dir.mkdir()
        scene = bpy.context.scene
        scene.render.filepath = str(scene_dir / "rgb.png")
        bpy.ops.render.render(write_still=True)
        scene.render.film_transparent = True
        scene.render.resolution_x, scene.render.resolution_y = 768, 512
        for obj in scene.objects:
            if obj.type in {"MESH", "CURVE"}:
                obj.hide_render = True
        amodal, stem_masks = [], []
        for index, (tree, stem) in enumerate(zip(trees, stems, strict=True), start=1):
            tree.hide_render = False
            scene.render.filepath = str(scene_dir / f"amodal_{index}.png")
            bpy.ops.render.render(write_still=True)
            tree.hide_render = True
            stem.hide_render = False
            scene.render.filepath = str(scene_dir / f"stem_{index}.png")
            bpy.ops.render.render(write_still=True)
            stem.hide_render = True
        for index in range(1, len(trees) + 1):
            for kind, values in (("amodal", amodal), ("stem", stem_masks)):
                image = bpy.data.images.load(str(scene_dir / f"{kind}_{index}.png"))
                width, height = image.size
                array = np.array(image.pixels[:], dtype=np.float32).reshape(height, width, 4)
                values.append(array[..., 3] > 0.5)
                bpy.data.images.remove(image)
        for index in range(len(trees)):
            current = amodal[index].copy()
            current_stem = stem_masks[index].copy()
            for front in range(index):
                current &= ~amodal[front]
                current_stem &= ~amodal[front]
            save_mask(scene_dir / f"visible_{index + 1}.png", current)
            save_mask(scene_dir / f"visible_stem_{index + 1}.png", current_stem)
            save_mask(scene_dir / f"crown_{index + 1}.png", amodal[index] & ~stem_masks[index])
            save_mask(scene_dir / f"visible_crown_{index + 1}.png", current & ~current_stem)
        ys, xs = np.where(amodal[0])
        visible_ys, visible_xs = np.where(amodal[0] & ~amodal[0])  # placeholder, target visible below
        visible_target = amodal[0].copy()
        for front in range(1):
            visible_target &= ~amodal[0]
        visible_target = amodal[0]
        meta = {
            "scene": f"{number:06d}",
            "trees": names,
            "target_height_fraction": float((ys.max() - ys.min() + 1) / amodal[0].shape[0]),
            "target_center": [float((xs.min() + xs.max()) / 2 / amodal[0].shape[1]), float((ys.min() + ys.max()) / 2 / amodal[0].shape[0])],
            "overlap_target_neighbour": float((amodal[0] & amodal[1]).sum()) / max(min(amodal[0].sum(), amodal[1].sum()), 1),
            "target_hidden_fraction": float(1 - visible_target.sum() / max(amodal[0].sum(), 1)),
            "trunk_pixels": int(stem_masks[0].sum()),
            "crown_pixels": int((amodal[0] & ~stem_masks[0]).sum()),
            "count": len(trees),
        }
        (scene_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print("SCENE", number, names, meta["target_height_fraction"], meta["overlap_target_neighbour"], flush=True)


if __name__ == "__main__":
    main()



