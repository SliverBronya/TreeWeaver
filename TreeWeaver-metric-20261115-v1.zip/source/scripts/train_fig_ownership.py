"""Train two-to-four-object ownership on the fig-overlap Blender dataset."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from fig_overlap import FigOverlapDataset  # noqa: E402
from occlusion_metrics import mask_iou, merge_split, ownership_accuracy  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def dice_loss(logits: torch.Tensor, target: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(2, 3))
    denominator = probability.sum(dim=(2, 3)) + target.sum(dim=(2, 3))
    dice = 1.0 - (2.0 * intersection + 1.0) / (denominator + 1.0)
    return (dice * weight[:, :, 0, 0]).sum() / weight[:, :, 0, 0].sum().clamp_min(1.0)


def build_model(sam2_path: Path, device: str, args) -> Sam2OcclusionModel:
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(device).eval()
    return Sam2OcclusionModel(
        sam2,
        knots=12,
        encoder_lora_rank=args.encoder_lora_rank,
        principal_focus=args.principal_focus,
        depth_adapter=False,
    ).to(device)


def forward_batch(model, batch, device):
    pixel_values = batch["pixel_values"].to(device)
    boxes = batch["boxes_all"].to(device)
    points = batch["stem_points_all"].to(device)[:, :, None, :]
    labels = torch.ones_like(points[..., 0], dtype=torch.long, device=device)
    return model(
        pixel_values,
        input_boxes=boxes,
        input_points=points,
        input_labels=labels,
    )


def evaluate(model, dataset, items, device, max_objects: int):
    model.eval()
    tree_ious, ownership_values, merges, splits, layer_values = [], [], [], [], []
    with torch.no_grad():
        for index in range(min(items, len(dataset))):
            sample = dataset.sample(index, deterministic=True)
            pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
            boxes = torch.as_tensor(sample["boxes_all"])[None].to(device)
            points = torch.as_tensor(sample["stem_points_all"])[None, :, None, :].to(device)
            labels = torch.ones_like(points[..., 0], dtype=torch.long, device=device)
            output = model(
                pixel_values,
                input_boxes=boxes,
                input_points=points,
                input_labels=labels,
            )
            valid = np.asarray(sample["valid"], bool)
            predicted = output["masks"][0, :, 0].cpu().numpy() > 0
            target = sample["visible_all"] > 0.5
            ious = [
                mask_iou(predicted[i], target[i])
                for i in range(max_objects)
                if valid[i]
            ]
            tree_ious.append(float(np.mean(ious)))
            predicted_owner = output["ownership_logits"][0].argmax(dim=0).cpu().numpy()
            ownership_values.append(ownership_accuracy(predicted_owner, sample["ownership"]))
            stats = merge_split(predicted[valid], target[valid])
            merges.append(stats["merge_count"])
            splits.append(stats["split_count"])
            rank = np.asarray(sample["layer_rank"])
            target_layer = (rank[:, None] < rank[None, :]) & valid[:, None] & valid[None, :]
            pair_mask = valid[:, None] & valid[None, :] & ~np.eye(max_objects, dtype=bool)
            predicted_layer = output["layer_logits"][0].cpu().numpy() > 0
            if pair_mask.any():
                layer_values.append(
                    float(
                        (
                            predicted_layer[pair_mask]
                            == target_layer[pair_mask]
                        ).mean()
                    )
                )
    model.train()
    return {
        "tree_iou": float(np.mean(tree_ious)),
        "ownership_accuracy": float(np.nanmean(ownership_values)),
        "merge_count": float(np.mean(merges)),
        "split_count": float(np.mean(splits)),
        "layer_accuracy": float(np.mean(layer_values)) if layer_values else float("nan"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--sam2-path", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=500)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--eval-every", type=int, default=100)
    parser.add_argument("--eval-items", type=int, default=25)
    parser.add_argument("--max-objects", type=int, default=4)
    parser.add_argument("--encoder-lora-rank", type=int, default=8)
    parser.add_argument("--principal-focus", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    if args.output.exists():
        raise SystemExit(f"output already exists: {args.output}")
    args.output.mkdir(parents=True)
    sam2_path = args.sam2_path if args.sam2_path is not None else snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    train_dataset = FigOverlapDataset(
        args.dataset, "train", mean=mean, std=std, max_objects=args.max_objects
    )
    val_dataset = FigOverlapDataset(
        args.dataset, "val", mean=mean, std=std, max_objects=args.max_objects
    )
    loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
    model = build_model(sam2_path, args.device, args)
    model.train()
    parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=args.lr, weight_decay=1e-4)
    print(json.dumps({
        "trainable_parameters": sum(parameter.numel() for parameter in parameters),
        "train_images": len(train_dataset),
        "val_images": len(val_dataset),
        "max_objects": args.max_objects,
    }), flush=True)

    history = []
    best = {"tree_iou": -1.0}
    iterator = iter(loader)
    started = time.perf_counter()
    for step in range(1, args.steps + 1):
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(loader)
            batch = next(iterator)
        output = forward_batch(model, batch, args.device)
        visible_target = batch["visible_all"].to(args.device)
        valid = batch["valid"].to(args.device).float()
        visible_logits = output["masks"][:, :, 0]
        weight = valid[:, :, None, None]
        bce = F.binary_cross_entropy_with_logits(
            visible_logits, visible_target, reduction="none"
        )
        visible_loss = (bce * weight).sum() / (
            weight.sum() * visible_logits.shape[-2] * visible_logits.shape[-1]
        ).clamp_min(1.0)
        visible_loss = visible_loss + dice_loss(visible_logits, visible_target, weight)
        ownership_loss = F.cross_entropy(
            output["ownership_logits"], batch["ownership"].to(args.device).long()
        )
        rank = batch["layer_rank"].to(args.device)
        layer_target = (rank[:, :, None] < rank[:, None, :]).float()
        pair_mask = (
            valid[:, :, None] * valid[:, None, :]
            * (1.0 - torch.eye(args.max_objects, device=args.device))
        )
        layer_loss = (
            F.binary_cross_entropy_with_logits(
                output["layer_logits"], layer_target, reduction="none"
            )
            * pair_mask
        ).sum() / pair_mask.sum().clamp_min(1.0)
        probability = visible_logits.sigmoid()
        exclusion = torch.zeros((), device=args.device)
        for i in range(args.max_objects):
            for j in range(i + 1, args.max_objects):
                exclusion = exclusion + (
                    probability[:, i] * probability[:, j] * valid[:, i] * valid[:, j]
                ).mean()
        total = visible_loss + ownership_loss + 0.5 * layer_loss + 0.1 * exclusion
        if not torch.isfinite(total):
            raise FloatingPointError(f"non-finite loss at {step}")
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        entry = {
            "step": step,
            "visible": float(visible_loss.detach()),
            "ownership": float(ownership_loss.detach()),
            "layer": float(layer_loss.detach()),
            "exclusion": float(exclusion.detach()),
            "total": float(total.detach()),
            "seconds": time.perf_counter() - started,
        }
        history.append(entry)
        print(json.dumps(entry), flush=True)
        if step % args.eval_every == 0 or step == args.steps:
            metrics = evaluate(model, val_dataset, args.eval_items, args.device, args.max_objects)
            print(json.dumps({"eval_step": step, **metrics}), flush=True)
            if metrics["tree_iou"] > best["tree_iou"]:
                best = {"step": step, **metrics}
                adapters = {
                    name: parameter.detach().cpu()
                    for name, parameter in model.named_parameters()
                    if parameter.requires_grad and not name.startswith("decoder.")
                }
                torch.save(
                    {"decoder": model.decoder.state_dict(), "adapters": adapters},
                    args.output / "best.pth",
                )
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (args.output / "run.json").write_text(
        json.dumps({"args": vars(args), "best": best}, indent=2, default=str),
        encoding="utf-8",
    )
    print(f"saved {args.output / 'best.pth'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
