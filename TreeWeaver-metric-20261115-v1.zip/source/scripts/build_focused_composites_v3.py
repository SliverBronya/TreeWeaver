"""Focused composites v2: 90% target height, centered, 5-30% crown overlap."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(r"D:\TreeWeaver\reports\fig-paired-v6-framing-30-2026-11-08")
OUT = Path(r"D:\TreeWeaver\reports\focused-composite-v3-2026-11-10")
W, H = 1600, 1024
COUNT = 180


def alpha(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def cutout(rgb, mask):
    ys, xs = np.where(mask)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    return rgb[y0:y1, x0:x1].copy(), mask[y0:y1, x0:x1].copy()


def scale(image, mask, height, max_width):
    h, w = mask.shape
    factor = min(height / h, max_width / w)
    width, height = max(1, round(w * factor)), max(1, round(h * factor))
    image = np.asarray(Image.fromarray(image).resize((width, height), Image.BILINEAR))
    mask = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)) > 127
    return image, mask


def background():
    y = np.arange(H)[:, None]
    image = np.zeros((H, W, 3), np.uint8)
    image[..., 0] = np.clip(155 - y * 0.10, 0, 255)
    image[..., 1] = np.clip(190 - y * 0.08, 0, 255)
    image[..., 2] = np.clip(230 - y * 0.04, 0, 255)
    ground = y[:, 0] > int(H * 0.86)
    image[ground] = [120, 115, 95]
    return image


def paste(canvas, image, mask, left, top):
    h, w = mask.shape
    left = max(0, min(W - w, left))
    top = max(0, min(H - h, top))
    region = canvas[top : top + h, left : left + w]
    region[mask] = image[mask]
    full = np.zeros((H, W), bool)
    full[top : top + h, left : left + w] = mask
    return full


def load(record, item):
    rgb = np.asarray(Image.open(ROOT / record["image"]).convert("RGB"))
    mask = alpha(ROOT / item["amodal"])
    if mask.shape != rgb.shape[:2]:
        mask = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((rgb.shape[1], rgb.shape[0]), Image.NEAREST)) > 127
    return cutout(rgb, mask)


def main():
    OUT.mkdir(exist_ok=True)
    (OUT / "images").mkdir(exist_ok=True)
    (OUT / "masks").mkdir(exist_ok=True)
    manifest = json.loads((ROOT / "paired-samples.json").read_text(encoding="utf-8"))
    pool = []
    for record in manifest["records"]:
        if record["condition"] != "scene" or record["split"] != "train":
            continue
        for index, item in enumerate(record["instances"]):
            pool.append((record, item, index))
    rows = []
    for k in range(COUNT):
        target_record, target_item, _ = pool[k % len(pool)]
        neighbour_record, neighbour_item, _ = pool[(k + 7) % len(pool)]
        if target_item["asset"] == neighbour_item["asset"]:
            neighbour_record, neighbour_item, _ = pool[(k + 11) % len(pool)]
        target_rgb, target_mask = load(target_record, target_item)
        neighbour_rgb, neighbour_mask = load(neighbour_record, neighbour_item)
        target_rgb, target_mask = scale(target_rgb, target_mask, 900, 1200)
        neighbour_rgb, neighbour_mask = scale(neighbour_rgb, neighbour_mask, 700, 700)
        target_left = (W - target_mask.shape[1]) // 2
        target_top = (H - target_mask.shape[0]) // 2
        best = None
        for shift in range(-W // 2, W // 2, 4):
            neighbour_left = W // 2 + shift - neighbour_mask.shape[1] // 2
            if neighbour_left < 0 or neighbour_left + neighbour_mask.shape[1] > W:
                continue
            neighbour_top = (H - neighbour_mask.shape[0]) // 2
            temp = background()
            tmask = paste(temp, target_rgb, target_mask, target_left, target_top)
            nmask = paste(temp, neighbour_rgb, neighbour_mask, neighbour_left, neighbour_top)
            inter = (tmask & nmask).sum()
            overlap = inter / max(min(tmask.sum(), nmask.sum()), 1)
            score = abs(overlap - 0.15)
            if best is None or score < best[0]:
                best = (score, overlap, neighbour_left, neighbour_top, tmask, nmask, temp)
        _, overlap, left, top, tmask, nmask, canvas = best
        visible_target, visible_neighbour = tmask & ~nmask, nmask
        scene_dir = OUT / f"{k + 1:06d}"
        scene_dir.mkdir()
        Image.fromarray(canvas).save(scene_dir / "rgb.png")
        for name, mask in (("target", tmask), ("neighbour", nmask)):
            out = np.zeros((H, W, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene_dir / f"amodal_{name}.png")
        for name, mask in (("target", visible_target), ("neighbour", visible_neighbour)):
            out = np.zeros((H, W, 4), np.uint8)
            out[..., 3] = mask.astype(np.uint8) * 255
            Image.fromarray(out, "RGBA").save(scene_dir / f"visible_{name}.png")
        own = np.zeros((H, W, 3), np.uint8)
        own[visible_target] = [60, 130, 255]
        own[visible_neighbour] = [255, 150, 40]
        Image.fromarray(own).save(scene_dir / "ownership.png")
        row = {
            "scene": f"{k + 1:06d}",
            "target_asset": target_item["asset"],
            "neighbour_asset": neighbour_item["asset"],
            "target_height_fraction": float(target_mask.shape[0] / H),
            "crown_overlap_fraction": float(overlap),
            "target_hidden_fraction": float(1 - visible_target.sum() / max(tmask.sum(), 1)),
            "target_center_x_fraction": float((target_left + target_mask.shape[1] / 2) / W),
            "target_center_y_fraction": float((target_top + target_mask.shape[0] / 2) / H),
        }
        (scene_dir / "meta.json").write_text(json.dumps(row, indent=2), encoding="utf-8")
        rows.append(row)
        print(k + 1, row["target_asset"], "h", round(row["target_height_fraction"], 3), "overlap", round(overlap, 3), "hidden", round(row["target_hidden_fraction"], 3), flush=True)
    (OUT / "index.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print("done", len(rows))


if __name__ == "__main__":
    main()




