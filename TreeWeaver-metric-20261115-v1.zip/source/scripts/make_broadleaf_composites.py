"""Ten broadleaf composites: real TreeStereo target photo + two pasted neighbor crowns.

Requirements addressed:
* broadleaf/temperate trees, not conifers;
* target tree occupies ~85% of the crop height;
* background is the target photo's real background (cropped, not a gradient);
* the two neighbors overlap only the target's crown edges, not the trunk.

Caveat: TreeStereo masks are visible-pixel masks. The target is treated as
complete only because the selected trees are isolated in their source photos.
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "external" / "tree-stereo-biophysical-v4" / "extracted" / "full_trees"
OUTPUT = ROOT / "reports" / "broadleaf-composites-2026-10-26"
PANEL_W, PANEL_H = 480, 270

TARGETS = [
    "FT211_IMG_20220906_114747",
    "FT88_IMG_20220906_142405",
    "FT207_IMG_20220906_114458",
    "FT161_IMG_20230309_134113",
    "FT94_IMG_20220906_144142",
    "FT149_IMG_20230309_125900",
]
POOL = TARGETS
SAMPLES = 10
COLOURS = [(60, 80, 240), (240, 160, 60), (80, 200, 80)]  # target, left, right


def load(stem: str):
    image = cv2.imread(str(SOURCE / f"{stem}_LEFT.jpg"))
    mask_image = cv2.imread(str(SOURCE / f"{stem}_LEFT_mask.jpg"))
    if image is None or mask_image is None:
        raise FileNotFoundError(stem)
    mask = mask_image.max(axis=2) > 30
    ys, xs = np.nonzero(mask)
    if len(xs) < 100:
        raise ValueError(stem)
    return image, mask, (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)


def crop_target(image, mask, box):
    height, width = image.shape[:2]
    x0, y0, x1, y1 = box
    target_h = y1 - y0
    crop_h = min(height, max(int(round(target_h / 0.85)), 200))
    crop_w = min(width, int(round(crop_h * 16 / 9)))
    centre_x = (x0 + x1) // 2
    centre_y = (y0 + y1) // 2
    left = min(max(centre_x - crop_w // 2, 0), width - crop_w)
    top = min(max(centre_y - crop_h // 2, 0), height - crop_h)
    right, bottom = left + crop_w, top + crop_h
    return (
        image[top:bottom, left:right].copy(),
        mask[top:bottom, left:right].copy(),
        (int(left), int(top), int(right), int(bottom)),
    )


def cutout(stem: str):
    image, mask, box = load(stem)
    x0, y0, x1, y1 = box
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    samples = []
    sheet_rows = []
    for index in range(1, SAMPLES + 1):
        target_stem = TARGETS[(index - 1) % len(TARGETS)]
        flank_pool = [stem for stem in POOL if stem != target_stem]
        flank_stems = (
            flank_pool[(index * 2) % len(flank_pool)],
            flank_pool[(index * 2 + 1) % len(flank_pool)],
        )
        image, mask, box = load(target_stem)
        canvas, target_mask, crop_box = crop_target(image, mask, box)
        height, width = canvas.shape[:2]
        ys, xs = np.nonzero(target_mask)
        t_left, t_top, t_right, t_bottom = xs.min(), ys.min(), xs.max(), ys.max()
        t_h = t_bottom - t_top
        t_w = t_right - t_left

        amodal = [np.zeros((height, width), bool)]
        amodal[0][target_mask] = True
        for side, flank_stem in zip(("left", "right"), flank_stems, strict=True):
            patch, alpha = cutout(flank_stem)
            overlap = int((0.18 + 0.02 * (index % 4)) * t_w)
            target_height = min(int(round(t_h * 0.9)), int(t_bottom))
            scale = target_height / patch.shape[0]
            patch = cv2.resize(patch, (max(1, int(round(patch.shape[1] * scale))), target_height))
            alpha = cv2.resize(
                alpha.astype(np.uint8),
                (patch.shape[1], patch.shape[0]),
                interpolation=cv2.INTER_NEAREST,
            ) > 0
            max_width = min(t_left, width - t_right) + overlap
            if patch.shape[1] > max_width:
                scale = max_width / patch.shape[1]
                patch = cv2.resize(
                    patch, (max_width, max(1, int(round(patch.shape[0] * scale))))
                )
                alpha = cv2.resize(
                    alpha.astype(np.uint8),
                    (patch.shape[1], patch.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                ) > 0
            if side == "left":
                x0 = max(0, t_left + overlap - patch.shape[1])
            else:
                x0 = min(width - patch.shape[1], t_right - overlap)
            y0 = min(max(int(t_bottom) - patch.shape[0], 0), height - patch.shape[0])
            region = canvas[y0 : y0 + patch.shape[0], x0 : x0 + patch.shape[1]]
            region[alpha] = patch[alpha]
            placed_mask = np.zeros((height, width), bool)
            placed_mask[y0 : y0 + patch.shape[0], x0 : x0 + patch.shape[1]] = alpha
            amodal.append(placed_mask)

        visible = [amodal[0] & ~(amodal[1] | amodal[2]), amodal[1].copy(), amodal[2].copy()]

        ownership = np.zeros((height, width), np.uint8)
        for i, m in enumerate(visible):
            ownership[m] = i + 1

        stats = []
        for i, m in enumerate(amodal):
            stats.append(
                {
                    "tree": i,
                    "amodal_pixels": int(m.sum()),
                    "visible_pixels": int(visible[i].sum()),
                    "occlusion_rate": 1.0 - float(visible[i].sum()) / max(int(m.sum()), 1),
                }
            )
        samples.append(
            {
                "sample": index,
                "target": target_stem,
                "flanks": list(flank_stems),
                "crop_box": list(crop_box),
                "target_height_fraction": float(t_h / height),
                "stats": stats,
            }
        )
        cv2.imwrite(str(OUTPUT / f"sample_{index:02d}.png"), canvas)
        np.savez_compressed(
            OUTPUT / f"sample_{index:02d}_gt.npz",
            amodal=np.stack(amodal),
            visible=np.stack(visible),
            ownership=ownership,
        )

        visible_panel = np.zeros((height, width, 3), np.uint8)
        amodal_panel = np.zeros((height, width, 3), np.uint8)
        ownership_panel = np.zeros((height, width, 3), np.uint8)
        for i in range(3):
            visible_panel[visible[i]] = COLOURS[i]
            amodal_panel[amodal[i]] = COLOURS[i]
            ownership_panel[ownership == i + 1] = COLOURS[i]
        sheet_rows.append(
            [
                cv2.resize(canvas, (PANEL_W, PANEL_H)),
                cv2.resize(visible_panel, (PANEL_W, PANEL_H)),
                cv2.resize(amodal_panel, (PANEL_W, PANEL_H)),
                cv2.resize(ownership_panel, (PANEL_W, PANEL_H)),
            ]
        )

    titles = ["composite (real background)", "visible GT", "amodal GT", "ownership"]
    gap = 8
    sheet = np.full((44 + len(sheet_rows) * (PANEL_H + 34), 4 * (PANEL_W + gap), 3), 30, np.uint8)
    for column, title in enumerate(titles):
        cv2.putText(
            sheet, title, (column * (PANEL_W + gap) + 8, 26),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (220, 220, 220), 1,
        )
    for row_index, (row, sample) in enumerate(zip(sheet_rows, samples, strict=True)):
        y0 = 44 + row_index * (PANEL_H + 34)
        header = (
            f"{sample['sample']:02d} {sample['target']}  "
            f"target height={sample['target_height_fraction'] * 100:.0f}%  "
            f"target occlusion={sample['stats'][0]['occlusion_rate'] * 100:.0f}%"
        )
        cv2.putText(sheet, header, (8, y0 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
        for column, panel in enumerate(row):
            x0 = column * (PANEL_W + gap)
            sheet[y0 + 24 : y0 + 24 + PANEL_H, x0 : x0 + PANEL_W] = panel
    cv2.imwrite(str(OUTPUT / "contact_sheet.png"), sheet)
    (OUTPUT / "samples.json").write_text(json.dumps(samples, indent=2), encoding="utf-8")
    print(json.dumps(samples, indent=2))
    print(f"saved {OUTPUT / 'contact_sheet.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
