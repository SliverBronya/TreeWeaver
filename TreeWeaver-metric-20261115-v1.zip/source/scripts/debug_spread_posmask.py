"""Inspect positive-anchor mask probs on a training frame (throwaway)."""
from __future__ import annotations
import argparse, json, random, sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--checkpoint", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, r".worker-envs\convexmask-extra")
sys.path.insert(0, r"data/external/convexmask-source")
import cv2
import numpy as np
import torch
import torch.nn.functional as functional
from data import cfg, set_cfg
torch.set_default_tensor_type(torch.cuda.FloatTensor)
set_cfg("convex_synthtree_focal")
cfg.max_size = (512, 512)
cfg.fixed_size = True
cfg.freeze_bn = True
cfg.mask_proto_debug = False
cfg.dataset.class_names = ("tree",)
from convexmask import ConvexMask
from layers.polar_utils import polar_target

pal = {int(k): tuple(v) for k, v in json.loads(
    Path("data/external/spread/color_palette.json").read_text(encoding="utf-8"))["palette"].items()}

root = Path("data/external/spread/birch_forest")
rng = random.Random(42)
frames = sorted(p.stem for p in (root / "rgb").glob("*.png"))
rng.shuffle(frames)
stem = frames[0]

image = cv2.imread(str(root / "rgb" / f"{stem}.png"))
inst = cv2.cvtColor(cv2.imread(str(root / "instance_segmentation" / f"{stem}.png")), cv2.COLOR_BGR2RGB)
cands = []
for line in (root / "instance_segmentation" / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
    pr = line.split()
    if len(pr) == 2 and pr[0].startswith("Tree") and int(pr[1]) in pal:
        c = pal[int(pr[1])]
        mm = cv2.inRange(inst, np.array(c), np.array(c))
        a = int(mm.sum() // 255)
        if a >= 10:
            cands.append((a, mm))
cands.sort(key=lambda x: x[0], reverse=True)
cands = cands[:24]
masks, boxes, hulls = [], [], []
for _, mm in cands:
    mm = (cv2.resize(mm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
    ys, xs = np.nonzero(mm)
    if len(xs) < 10:
        continue
    cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
    hulls.append(cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32) / 512)
    masks.append(mm)
    boxes.append([xs.min()/512, ys.min()/512, (xs.max()+1)/512, (ys.max()+1)/512, 0])
polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
for i, h in enumerate(hulls):
    polys[i, :len(h)] = h
resized = cv2.resize(image, (512, 512)).astype(np.float32)
resized = ((resized - np.array([103.94, 116.78, 123.68])) / np.array([57.38, 57.12, 58.40]))[:, :, ::-1].copy()
tensor = torch.as_tensor(resized, dtype=torch.float32).permute(2, 0, 1)

model = ConvexMask().cuda()
model.load_state_dict(torch.load(args.checkpoint, map_location="cuda"))
model.train()
with torch.no_grad():
    pred = model(tensor[None].cuda())
    lab, bbt, pt, idxt, cent = polar_target(
        torch.tensor(boxes, dtype=torch.float32)[:, :-1].cuda(),
        torch.tensor(polys, dtype=torch.float32).cuda(),
        torch.zeros(len(boxes), dtype=torch.long).cuda(),
        pred["points"], pred["regress_ranges"], cfg.num_rays, pred["img_size"],
        None, cfg.radius, cfg.force_gt_attribute)
    pos = lab > 0
    gt_idx = idxt[pos]
    mh, mw = pred["proto"].shape[1:3]
    probs = (pred["proto"][0] @ pred["mask"][0].T).sigmoid()
    gt_masks = torch.tensor(np.stack(masks), dtype=torch.float32).cuda()
    gt138 = functional.interpolate(gt_masks[None], (mh, mw), mode="nearest")[0]
    from layers.polar_utils import polar2mask
    pos_pts = pred["points"][pos]
    pos_ray = pred["polygon"][0][pos]
    crop = polar2mask(pos_pts, pos_ray * (1 + cfg.extend_factor), (mh, mw)) > 0.5
    probs_pos = probs[:, :, pos.nonzero()[:, 0]]
    crop_p = probs_pos[crop]
    print(f"pos anchors={int(pos.sum())}  crop pixels={int(crop.sum())}")
    print(f"  mean prob INSIDE predicted polygon crop={float(crop_p.mean()):.3f} "
          f"(share >0.5={float((crop_p > 0.5).float().mean()):.3f})")
    for pi in range(min(10, len(pos_anchors))):
        ai = int(pos_anchors[pi])
        gi = int(gt_idx[pi])
        pmap = probs[:, :, ai]
        t138 = gt138[gi].bool()  # already at proto resolution
        in_target = float(pmap[t138].mean())
        out_target = float(pmap[~t138].mean())
        print(f"  pos {pi} anchor {ai} gt{gi}: mean prob INSIDE gt={in_target:.3f} outside={out_target:.3f}")
