"""Visual sheet: synthetic GT vs Stage B vs 5h model vs stock SAM2."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from transformers import Sam2Model

ROOT = Path(r"D:\TreeWeaver")
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
from fig500_dataset import Fig500Multi  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports" / "fig-500-v2-2026-10-31"
STAGE_B = ROOT / "reports" / "fig500-stageB-2026-10-31" / "decoder_best.pth"
BEST = ROOT / "reports" / "fig500-long-5h-v2-2026-10-31" / "best.pth"
OUT = ROOT / "reports" / "synthetic-progress-2026-11-01"
SAM2 = sorted((Path.home() / ".cache" / "huggingface" / "hub" / "models--facebook--sam2.1-hiera-tiny" / "snapshots").iterdir())[-1]
COLORS = [(60, 130, 255), (255, 150, 40), (80, 210, 100), (220, 80, 160)]
PANEL_W, PANEL_H = 360, 203


def font(size=14):
    try:
        return ImageFont.truetype("C:/Windows/Fonts/arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


def overlay(image, masks, title):
    base = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).copy()
    for i, mask in enumerate(masks):
        small = cv2.resize(mask.astype(np.uint8), (base.shape[1], base.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
        color = np.array(COLORS[i % len(COLORS)], np.float32)
        base[small] = (0.45 * color + 0.55 * base[small]).astype(np.uint8)
    panel = Image.fromarray(base)
    draw = ImageDraw.Draw(panel)
    draw.text((6, 6), title, fill="white", font=font(16), stroke_width=2, stroke_fill="black")
    return panel


def output_masks(model, sample, device):
    pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
    boxes = torch.as_tensor(sample["boxes"])[None].to(device)
    with torch.no_grad():
        output = model(pixel_values, input_boxes=boxes)
    return [(output["masks"][0, i, 0] > 0).cpu().numpy() for i in range(sample["num_objects"])], output


def load_occlusion(path, device):
    model = Sam2OcclusionModel(Sam2Model.from_pretrained(SAM2, local_files_only=True).to(device).eval(), knots=12)
    payload = torch.load(path, map_location=device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)
    return model.to(device).eval()


def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dataset = Fig500Multi(DATA, "val")
    indices = [i for i in range(len(dataset)) if dataset.sample(i)["num_objects"] >= 3][:4]
    rows = []
    # Stage B
    model_b = load_occlusion(STAGE_B, device)
    stage_b = [output_masks(model_b, dataset.sample(i), device)[0] for i in indices]
    del model_b
    torch.cuda.empty_cache()
    # 5h
    model_c = load_occlusion(BEST, device)
    best = []
    best_amodal = []
    for i in indices:
        s = dataset.sample(i)
        masks, output = output_masks(model_c, s, device)
        best.append(masks)
        best_amodal.append([(output["amodal_masks"][0, k, 0] > 0).cpu().numpy() for k in range(s["num_objects"])])
    del model_c
    torch.cuda.empty_cache()
    # stock
    stock_model = Sam2Model.from_pretrained(SAM2, local_files_only=True).to(device).eval()
    stock = []
    for i in indices:
        s = dataset.sample(i)
        with torch.no_grad():
            out = stock_model(
                pixel_values=torch.as_tensor(s["pixel_values"])[None].to(device),
                input_boxes=torch.as_tensor(s["boxes"])[None].to(device),
                multimask_output=True,
            )
        selected = out.iou_scores[0].argmax(-1)
        stock.append([(out.pred_masks[0, k, selected[k]] > 0).cpu().numpy() for k in range(s["num_objects"])])
    del stock_model
    torch.cuda.empty_cache()

    sheet = Image.new("RGB", (PANEL_W * 5, PANEL_H * 4 + 40), "white")
    draw = ImageDraw.Draw(sheet)
    headers = ["original + boxes", "GT visible", "Stage B visible", "5h visible", "5h amodal"]
    for c, title in enumerate(headers):
        draw.text((c * PANEL_W + 8, 8), title, fill="black", font=font(16))
    for r, i in enumerate(indices):
        s = dataset.sample(i)
        image = cv2.imread(str(DATA / "images" / f"{s['image_id']:06d}.png"))
        h, w = image.shape[:2]
        original = image.copy()
        for k, box in enumerate(s["boxes"]):
            x0, y0, x1, y1 = box
            x0, x1 = int(x0 * w / 1024), int(x1 * w / 1024)
            y0, y1 = int(y0 * h / 1024), int(y1 * h / 1024)
            cv2.rectangle(original, (x0, y0), (x1, y1), COLORS[k], 2)
        panels = [
            Image.fromarray(cv2.cvtColor(original, cv2.COLOR_BGR2RGB)).resize((PANEL_W, PANEL_H)),
            overlay(image, [m > 0.5 for m in s["visible"]], f"{s['image_id']} GT visible"),
            overlay(image, stage_b[r], "Stage B"),
            overlay(image, best[r], "5h"),
            overlay(image, best_amodal[r], "5h amodal"),
        ]
        y = 40 + r * PANEL_H
        for c, panel in enumerate(panels):
            sheet.paste(panel, (c * PANEL_W, y))
    OUT.mkdir(parents=True, exist_ok=True)
    sheet.save(OUT / "sheet.jpg", quality=92)
    print("saved", OUT / "sheet.jpg")


if __name__ == "__main__":
    main()
