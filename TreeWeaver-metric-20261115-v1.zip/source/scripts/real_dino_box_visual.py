"""Grounding DINO boxes only -> SAM2 / readout / LoRA on real photos."""

from __future__ import annotations

import inspect
import json
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

REAL = ROOT / "data/20260411"
OUT = ROOT / "reports/real-20260411-box-only-2026-11-10"
READOUT = ROOT / "reports/frozen-visible-readout-300-viz-2026-11-09/checkpoint.pth"
LORA = ROOT / "reports/frozen-visible-lora-300-seed20261110-2026-11-09/checkpoint.pth"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
NAMES = ["10001", "10002", "10003"]
SIZE = 640


def snapshot(repo):
    base = Path.home() / ".cache/huggingface/hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def detect(image):
    path = snapshot("IDEA-Research/grounding-dino-tiny")
    processor = AutoProcessor.from_pretrained(path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(path, local_files_only=True)
        .cuda()
        .eval()
    )
    inputs = processor(images=image, text="tree.", return_tensors="pt").to("cuda")
    with torch.no_grad():
        outputs = detector(**inputs)
    kwargs = {"threshold" if "threshold" in inspect.signature(
        processor.post_process_grounded_object_detection
    ).parameters else "box_threshold": 0.28}
    result = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        text_threshold=0.22,
        target_sizes=[image.size[::-1]],
        **kwargs,
    )[0]
    return result["boxes"].detach().cpu().numpy(), result["scores"].detach().cpu().numpy()


def tensor(image):
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def build_ours():
    base = Sam2Model.from_pretrained(snapshot("facebook/sam2.1-hiera-tiny"), local_files_only=True)
    model = Sam2OcclusionModel(base, encoder_lora_rank=4)
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model.cuda().eval()


def mask_from_output(output, lb):
    mask = output["masks"][0, 0, 0].sigmoid().cpu().numpy() > 0.5
    mask = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize((1024, 1024), Image.NEAREST)) > 127
    source_width, source_height = lb.source_size
    new_width = round(source_width * lb.scale)
    new_height = round(source_height * lb.scale)
    cropped = mask[lb.pad_y : lb.pad_y + new_height, lb.pad_x : lb.pad_x + new_width]
    return np.asarray(Image.fromarray(cropped.astype(np.uint8) * 255).resize((source_width, source_height), Image.NEAREST)) > 127


def overlay(rgb, mask, color, alpha=0.45):
    out = rgb.copy()
    out[mask] = (out[mask] * (1 - alpha) + np.array(color) * alpha).astype(np.uint8)
    return out


def main():
    OUT.mkdir(parents=True)
    per_image = OUT / "per-image"
    per_image.mkdir()
    base = Sam2Model.from_pretrained(
        snapshot("facebook/sam2.1-hiera-tiny"), local_files_only=True
    ).cuda().eval()
    ours = build_ours()
    readout = torch.load(READOUT, map_location="cpu", weights_only=True)["state"]
    lora = torch.load(LORA, map_location="cpu", weights_only=True)["lora"]
    records = []
    for name in NAMES:
        rgb_image = Image.open(REAL / f"{name}.jpg").convert("RGB")
        width, height = rgb_image.size
        boxes, scores = detect(rgb_image)
        if len(boxes) == 0:
            print(name, "no boxes")
            continue
        order = np.argsort(scores)[::-1][:3]
        boxes, scores = boxes[order], scores[order]
        lb = letterbox(rgb_image)
        transformed = lb.boxes(boxes)
        inputs = tensor(lb.image).cuda()
        box_tensor = torch.tensor(transformed, dtype=torch.float32)[None].cuda()
        with torch.no_grad():
            stock = base(pixel_values=inputs, input_boxes=box_tensor)
        stock_scores = stock["iou_scores"][0, 0]
        best = int(stock_scores.argmax())
        stock_mask = stock["pred_masks"][0, 0, best].sigmoid().cpu().numpy() > 0.5
        stock_mask = np.asarray(Image.fromarray(stock_mask.astype(np.uint8) * 255).resize((1024, 1024), Image.NEAREST)) > 127
        new_width, new_height = round(width * lb.scale), round(height * lb.scale)
        stock_mask = stock_mask[lb.pad_y : lb.pad_y + new_height, lb.pad_x : lb.pad_x + new_width]
        stock_mask = np.asarray(Image.fromarray(stock_mask.astype(np.uint8) * 255).resize((width, height), Image.NEAREST)) > 127
        ours.load_state_dict(readout, strict=False)
        with torch.no_grad():
            output = ours(inputs, input_boxes=box_tensor)
        readout_mask = mask_from_output(output, lb)
        ours.load_state_dict(lora, strict=False)
        with torch.no_grad():
            output = ours(inputs, input_boxes=box_tensor)
        lora_mask = mask_from_output(output, lb)
        ours.load_state_dict(readout, strict=False)

        display = np.asarray(rgb_image.resize((SIZE, SIZE), Image.BILINEAR)).copy()
        ratio = np.array([SIZE / width, SIZE / height, SIZE / width, SIZE / height])
        panel = display.copy()
        draw = ImageDraw.Draw(Image.fromarray(panel))
        canvas = Image.fromarray(panel)
        draw = ImageDraw.Draw(canvas)
        for box, score in zip(boxes, scores, strict=True):
            x0, y0, x1, y1 = (box * ratio).tolist()
            draw.rectangle([x0, y0, x1, y1], outline=(255, 220, 0), width=3)
            draw.text((x0 + 4, y0 + 4), f"{score:.2f}", fill=(255, 255, 0))
        panels = [
            ("DINO boxes", np.asarray(canvas)),
            ("stock SAM", overlay(display, np.asarray(Image.fromarray(stock_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127, [0, 220, 120])),
            ("readout", overlay(display, np.asarray(Image.fromarray(readout_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127, [0, 140, 255])),
            ("LoRA", overlay(display, np.asarray(Image.fromarray(lora_mask.astype(np.uint8) * 255).resize((SIZE, SIZE), Image.NEAREST)) > 127, [255, 120, 0])),
        ]
        tile = Image.new("RGB", (SIZE * 4, SIZE + 34), "white")
        td = ImageDraw.Draw(tile)
        for i, (label, image) in enumerate(panels):
            tile.paste(Image.fromarray(image), (i * SIZE, 34))
            td.text((i * SIZE + 8, 10), label, fill="black")
        td.text((8, SIZE + 8), f"{name} boxes={len(boxes)} scores={[round(float(s),3) for s in scores]}", fill="black")
        tile.save(per_image / f"{name}.jpg", quality=95)
        records.append({"image": name, "boxes": [[float(v) for v in b] for b in boxes], "scores": [float(s) for s in scores], "readout_area": float(readout_mask.mean()), "lora_area": float(lora_mask.mean()), "stock_area": float(stock_mask.mean())})
    (OUT / "metrics.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()

