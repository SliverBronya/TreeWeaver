"""Compare polar targets of local pilot3 vs SPREAD frames (throwaway probe)."""
from __future__ import annotations
import json
import sys
from pathlib import Path

sys.path.insert(0, r".worker-envs\convexmask-extra")
sys.path.insert(0, r"data/external/convexmask-source")
import cv2
import numpy as np
import torch
from data import cfg, set_cfg

torch.set_default_tensor_type(torch.cuda.FloatTensor)
set_cfg("convex_synthtree_focal")
cfg.max_size = (512, 512)
cfg.fixed_size = True
cfg.freeze_bn = True
cfg.mask_proto_debug = False
cfg.dataset.class_names = ("tree",)
from convexmask import ConvexMask
from layers.polar_utils import polar_target

m = ConvexMask().cuda()
m.train()  # Raw dict outputs; BN stays frozen by cfg.freeze_bn.
with torch.no_grad():
    pred = m(torch.zeros(1, 3, 512, 512).cuda())
points = pred["points"]
rr = pred["regress_ranges"]
img_size = pred["img_size"]


def analyze(tag, boxes, polys, masks):
    b = torch.tensor(boxes, dtype=torch.float32)[:, :-1]
    p = torch.tensor(polys, dtype=torch.float32)
    lab, bbt, pt, idxt, cent = polar_target(
        b, p, torch.zeros(len(boxes), dtype=torch.long), points, rr,
        cfg.num_rays, img_size, None, cfg.radius, cfg.force_gt_attribute)
    npos = int((lab > 0).sum())
    posv = pt[(lab > 0)]
    rays = posv[posv > 0]
    print(f"{tag}: n_obj={len(boxes)} num_pos_points={npos} "
          f"ray mean={float(rays.mean()):.3f} max={float(rays.max()):.3f} "
          f"zero-ray frac={float((posv == 0).float().mean()):.2f} "
          f"box area~{float(np.mean([(x[2]-x[0])*(x[3]-x[1]) for x in boxes])):.3f}")


def local_sample(label_path):
    label = json.loads(Path(label_path).read_text(encoding="utf-8"))
    size = 512
    masks, boxes, hulls = [], [], []
    for shape in [s for s in label["shapes"] if s["label"] == "tree"]:
        pts = np.asarray(shape["points"], dtype=np.float32)
        mask = np.zeros((label["imageHeight"], label["imageWidth"]), np.uint8)
        cv2.fillPoly(mask, [np.round(pts).astype(np.int32)], 1)
        mask = cv2.resize(mask, (size, size), interpolation=cv2.INTER_NEAREST)
        ys, xs = np.nonzero(mask)
        if len(xs) < 10:
            continue
        masks.append(mask)
        boxes.append([xs.min()/size, ys.min()/size, (xs.max()+1)/size,
                      (ys.max()+1)/size, 0])
        cs = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
        hulls.append(cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32)/size)
    if not hulls:
        return None
    polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
    for i, h in enumerate(hulls):
        polys[i, :len(h)] = h
    return boxes, polys, masks


# local frames
man = json.loads(Path("reports/convexmask-train-2026-10-12-pilot3/manifest.json").read_text(encoding="utf-8"))
for r in man["train"][:6] + man["test"]:
    s = local_sample(r["annotation"])
    if s:
        analyze("LOCAL " + Path(r["annotation"]).stem, *s)

# SPREAD frames
pal = {int(k): tuple(v) for k, v in json.loads(
    Path("data/external/spread/color_palette.json").read_text(encoding="utf-8"))["palette"].items()}
import random
rng = random.Random(42)
for scene, tag in [("birch_forest", "BIRCH"), ("city_park", "CITY")]:
    frames = sorted(p.stem for p in Path(f"data/external/spread/{scene}/rgb").glob("*.png"))
    rng.shuffle(frames)
    for stem in frames[:5]:
        idir = Path(f"data/external/spread/{scene}/instance_segmentation")
        inst = cv2.cvtColor(cv2.imread(str(idir / f"{stem}.png")), cv2.COLOR_BGR2RGB)
        size = 512
        cands = []
        for line in (idir / f"{stem}.txt").read_text(encoding="utf-8").splitlines():
            pr = line.split()
            if len(pr) == 2 and pr[0].startswith("Tree") and int(pr[1]) in pal:
                c = pal[int(pr[1])]
                mm = cv2.inRange(inst, np.array(c), np.array(c))
                a = int(mm.sum() // 255)
                if a >= 10:
                    cands.append((a, mm))
        cands.sort(key=lambda x: x[0], reverse=True)
        # take only the largest
        cands = cands[:1]
        masks, boxes, hulls = [], [], []
        for _, mm in cands:
            mm = (cv2.resize(mm, (size, size), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
            ys, xs = np.nonzero(mm)
            if len(xs) < 10:
                continue
            cs = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]
            hulls.append(cv2.convexHull(np.concatenate(cs))[:, 0].astype(np.float32)/size)
            masks.append(mm)
            boxes.append([xs.min()/size, ys.min()/size, (xs.max()+1)/size,
                          (ys.max()+1)/size, 0])
        if hulls:
            polys = np.full((len(hulls), max(len(h) for h in hulls), 2), -1, np.float32)
            for i, h in enumerate(hulls):
                polys[i, :len(h)] = h
            analyze(f"{tag} {stem[:14]}", boxes, polys, masks)
