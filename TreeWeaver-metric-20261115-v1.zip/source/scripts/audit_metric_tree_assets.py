"""Bounded CPU inspection of static local GLB geometry, not rendering or training.

Only GLB2 embedded, non-sparse, non-skinned triangle geometry is supported.
Refuse unsupported geometry rather than silently measuring a different mesh.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from synthetic_geometry import (  # noqa: E402
    closed_wood_volume_m3,
    crown_widths_m,
    dbh_horizontal_section_m,
    tree_height_m,
)

MAX_GLB_BYTES = 128 * 1024**2
MAX_JSON_BYTES = 16 * 1024**2
MAX_WORLD_VERTICES = 1_000_000
MAX_WORLD_TRIANGLES = 2_000_000


def _integer(value, description, *, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{description} must be an integer >= {minimum}")
    return value


def _entry(values, index, description):
    index = _integer(index, description)
    if index >= len(values):
        raise ValueError(f"{description} outside document")
    return values[index]


def _vector(value, size, description):
    array = np.asarray(value, dtype=np.float64)
    if array.shape != (size,) or not np.isfinite(array).all():
        raise ValueError(f"{description} must contain {size} finite values")
    return array


def local_matrix(node):
    if "matrix" in node:
        if any(key in node for key in ("translation", "rotation", "scale")):
            raise ValueError("node cannot combine matrix and TRS")
        result = _vector(node["matrix"], 16, "node matrix").reshape((4, 4), order="F")
        if not np.allclose(result[3], [0, 0, 0, 1], atol=1e-12, rtol=0):
            raise ValueError("only affine node matrices are supported")
        return result
    quaternion = _vector(node.get("rotation", [0, 0, 0, 1]), 4, "node quaternion")
    if not np.isclose(np.linalg.norm(quaternion), 1, atol=1e-5, rtol=0):
        raise ValueError("node quaternion must have unit norm")
    x, y, z, w = quaternion
    rotation = np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )
    result = np.eye(4)
    result[:3, :3] = rotation @ np.diag(_vector(node.get("scale", [1, 1, 1]), 3, "node scale"))
    result[:3, 3] = _vector(node.get("translation", [0, 0, 0]), 3, "node translation")
    return result


class StaticGLB:
    def __init__(self, path):
        self.path = Path(path)
        self.document = None
        self.bin_start = None
        self.bin_length = 0
        file_size = self.path.stat().st_size
        if not 20 <= file_size <= MAX_GLB_BYTES:
            raise ValueError("GLB size outside bounded static-audit limit")
        with self.path.open("rb") as handle:
            magic, version, length = struct.unpack("<4sII", handle.read(12))
            if magic != b"glTF" or version != 2 or length != file_size:
                raise ValueError("not a complete GLB2 file")
            first = True
            while handle.tell() < length:
                if length - handle.tell() < 8:
                    raise ValueError("truncated GLB chunk header")
                size, kind = struct.unpack("<I4s", handle.read(8))
                if size % 4 or size > length - handle.tell():
                    raise ValueError("invalid GLB chunk length")
                if first and kind != b"JSON":
                    raise ValueError("first GLB chunk must be JSON")
                first = False
                if kind == b"JSON":
                    if self.document is not None or size > MAX_JSON_BYTES:
                        raise ValueError("duplicate or oversized JSON chunk")
                    self.document = json.loads(handle.read(size))
                elif kind == b"BIN\0":
                    if self.bin_start is not None:
                        raise ValueError("multiple embedded BIN chunks unsupported")
                    self.bin_start, self.bin_length = handle.tell(), size
                    handle.seek(size, 1)
                else:
                    handle.seek(size, 1)
        if (
            not isinstance(self.document, dict)
            or self.document.get("asset", {}).get("version") != "2.0"
        ):
            raise ValueError("missing or unsupported glTF asset version")
        if self.bin_start is None or self.document.get("skins") or self.document.get("animations"):
            raise ValueError("only static embedded GLB meshes are supported")
        if self.document.get("extensionsRequired"):
            raise ValueError("required glTF extensions need independent qualification")
        buffers = self.document.get("buffers", [])
        if len(buffers) != 1 or "uri" in buffers[0]:
            raise ValueError("only one embedded geometry buffer is supported")
        self.buffer_length = _integer(buffers[0]["byteLength"], "buffer byteLength", minimum=1)
        if not self.buffer_length <= self.bin_length <= self.buffer_length + 3:
            raise ValueError("embedded BIN disagrees with declared buffer length")

    def accessor(self, index):
        entry = _entry(self.document.get("accessors", []), index, "accessor index")
        if "sparse" in entry or entry.get("normalized"):
            raise ValueError("sparse/normalized geometry accessor unsupported")
        if entry.get("extensions"):
            raise ValueError("geometry accessor extensions require qualification")
        view = _entry(
            self.document.get("bufferViews", []), entry.get("bufferView"), "bufferView index"
        )
        if view.get("buffer", 0) != 0:
            raise ValueError("external geometry buffer unsupported")
        if view.get("extensions"):
            raise ValueError("geometry buffer-view extensions require qualification")
        types = {5121: "u1", 5123: "<u2", 5125: "<u4", 5126: "<f4"}
        if entry.get("componentType") not in types or entry.get("type") not in {"SCALAR", "VEC3"}:
            raise ValueError("unsupported static geometry accessor component/type")
        dtype = np.dtype(types[entry["componentType"]])
        channels = {"SCALAR": 1, "VEC3": 3}[entry["type"]]
        count = _integer(entry.get("count"), "accessor count", minimum=1)
        offset = _integer(entry.get("byteOffset", 0), "accessor byteOffset")
        element_size = dtype.itemsize * channels
        stride = _integer(
            view.get("byteStride", element_size), "bufferView byteStride", minimum=element_size
        )
        if stride % dtype.itemsize or offset % dtype.itemsize:
            raise ValueError("geometry accessor is not component-aligned")
        view_start = _integer(view.get("byteOffset", 0), "bufferView byteOffset")
        view_length = _integer(view.get("byteLength"), "bufferView byteLength", minimum=1)
        if view_start + view_length > self.buffer_length:
            raise ValueError("buffer view extends past declared embedded buffer")
        size = (count - 1) * stride + element_size
        if offset + size > view_length:
            raise ValueError("accessor extends past buffer view")
        start = view_start + offset
        if start % dtype.itemsize:
            raise ValueError("geometry accessor is not absolutely component-aligned")
        with self.path.open("rb") as handle:
            handle.seek(self.bin_start + start)
            raw = handle.read(size)
        if len(raw) != size:
            raise ValueError("truncated geometry data")
        return np.ndarray(
            (count, channels), dtype, buffer=raw, strides=(stride, dtype.itemsize)
        ).copy()

    def primitives(self):
        document = self.document
        scene = _entry(document.get("scenes", []), document.get("scene", 0), "scene index")
        roots = scene.get("nodes", [])
        axis = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)  # glTF Y-up -> Z-up
        world_vertices, world_triangles = 0, 0
        visited = set()

        def visit(index, parent, ancestors):
            nonlocal world_vertices, world_triangles
            if index in ancestors:
                raise ValueError("cyclic node hierarchy")
            if index in visited:
                raise ValueError("node reused by multiple parents or active roots")
            visited.add(index)
            if len(ancestors) >= 128:
                raise ValueError("node hierarchy exceeds bounded audit depth")
            node = _entry(document.get("nodes", []), index, "node index")
            if "skin" in node or node.get("weights") or node.get("extensions"):
                raise ValueError("skinned, weighted or extended node unsupported")
            matrix = parent @ local_matrix(node)
            if "mesh" in node:
                mesh = _entry(document.get("meshes", []), node["mesh"], "mesh index")
                if mesh.get("extensions"):
                    raise ValueError("mesh extensions require qualification")
                for primitive in mesh["primitives"]:
                    if (
                        primitive.get("mode", 4) != 4
                        or primitive.get("targets")
                        or primitive.get("extensions")
                    ):
                        raise ValueError("only static triangle primitives supported")
                    position_id = primitive.get("attributes", {}).get("POSITION")
                    position = _entry(
                        document.get("accessors", []), position_id, "POSITION accessor"
                    )
                    if position.get("componentType") != 5126 or position.get("type") != "VEC3":
                        raise ValueError("POSITION must be a FLOAT VEC3 accessor")
                    world_vertices += _integer(position.get("count"), "POSITION count", minimum=1)
                    if world_vertices > MAX_WORLD_VERTICES:
                        raise ValueError("world geometry exceeds bounded vertex limit")
                    points = self.accessor(position_id).astype(float)
                    world = (points @ matrix[:3, :3].T + matrix[:3, 3]) @ axis.T
                    if not np.isfinite(world).all():
                        raise ValueError("nonfinite transformed world vertices")
                    if "indices" in primitive:
                        index_entry = _entry(
                            document.get("accessors", []), primitive["indices"], "index accessor"
                        )
                        if (
                            index_entry.get("componentType") not in {5121, 5123, 5125}
                            or index_entry.get("type") != "SCALAR"
                        ):
                            raise ValueError("triangle indices must be unsigned integer SCALAR")
                        indices = self.accessor(primitive["indices"]).ravel().astype(np.int64)
                    else:
                        indices = np.arange(len(points), dtype=np.int64)
                    if len(indices) % 3 or (indices >= len(points)).any():
                        raise ValueError("invalid triangle index count or vertex reference")
                    world_triangles += len(indices) // 3
                    if world_triangles > MAX_WORLD_TRIANGLES:
                        raise ValueError("world geometry exceeds bounded triangle limit")
                    material = (
                        _entry(
                            document.get("materials", []), primitive["material"], "material index"
                        )
                        if "material" in primitive
                        else {}
                    )
                    yield material.get("name", "unknown"), world, indices.reshape(-1, 3)
            for child in node.get("children", []):
                yield from visit(child, matrix, ancestors | {index})

        for root in roots:
            yield from visit(root, np.eye(4), set())


def inspect_asset(path, height_m):
    if not np.isfinite(height_m) or height_m <= 0:
        raise ValueError("height_m must be positive finite virtual metres")
    primitives = list(StaticGLB(path).primitives())
    if not primitives:
        raise ValueError("active scene contains no supported triangle geometry")
    points = np.concatenate([item[1] for item in primitives])
    low, high = points.min(0), points.max(0)
    if high[2] <= low[2]:
        raise ValueError("asset has no positive vertical mesh envelope")
    factor = height_m / (high[2] - low[2])
    origin = np.array([(low[0] + high[0]) / 2, (low[1] + high[1]) / 2, low[2]])
    normalized = [(name, (p - origin) * factor, f) for name, p, f in primitives]
    bark = [(p, f) for name, p, f in normalized if name == "Ficus_carica_bark"]
    crown_prefixes = (
        "Ficus_carica_branch_",
        "Ficus_carica_leaf_",
        "Ficus_car_lf_stk_",
        "Ficus_carica_twig_",
        "Ficus_fruit",
    )
    crown = [p for name, p, _ in normalized if name.startswith(crown_prefixes)]
    unqualified = sorted(
        {
            name
            for name, _, _ in normalized
            if name != "Ficus_carica_bark" and not name.startswith(crown_prefixes)
        }
    )
    crown_measurement = crown_widths_m(np.concatenate(crown) if crown else np.empty((0, 3)))
    if unqualified:
        crown_measurement["valid"] = False
        crown_measurement["invalid_reason"] = "unqualified_materials_prevent_complete_crown_extent"
        # Keep partial extents only as separately named diagnostics.
        crown_measurement["known_crown_partial_widths_m"] = {
            key: crown_measurement[key] for key in ("width_x_m", "width_y_m", "max_axis_width_m")
        }
        for key in ("width_x_m", "width_y_m", "max_axis_width_m"):
            crown_measurement[key] = None
    measurements = {
        "mesh_envelope_height": tree_height_m((points - origin) * factor, ground_z_m=0),
        "mesh_envelope_crown_width": crown_measurement,
    }
    if len(bark) == 1:
        p, f = bark[0]
        measurements["source_bark_horizontal_section"] = dbh_horizontal_section_m(
            p, f, ground_z_m=0, main_stem_verified=False, upright_single_stem=False
        )
        measurements["source_bark_enclosed_volume"] = closed_wood_volume_m3(
            p, f, wood_geometry_verified=False, self_intersection_free=None
        )
    else:
        reason = (
            "no_reviewed_bark_geometry" if not bark else "multiple_bark_primitives_not_qualified"
        )
        for key, unit in (
            ("source_bark_horizontal_section", "m"),
            ("source_bark_enclosed_volume", "m^3"),
        ):
            measurements[key] = {
                "value": None,
                "unit": unit,
                "valid": False,
                "invalid_reason": reason,
                "provenance": "synthetic_world_geometry",
                "real_tree_field_measurement": False,
            }
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "asset": str(Path(path).resolve()),
        "sha256": digest.hexdigest(),
        "chosen_synthetic_height_m": height_m,
        "source_to_virtual_meter_scale": factor,
        "geometry_coordinates": {
            "source": "active glTF scene after parent/local node transforms; Y-up",
            "axis_transform": "X_world=X_gltf; Y_world=-Z_gltf; Z_world=Y_gltf",
            "virtual_scale": "uniformly assigned from active-scene vertex envelope height",
            "real_source_tree_scale_verified": False,
        },
        "unqualified_material_names": unqualified,
        "measurements": measurements,
        "source_bark_vertices": int(len(bark[0][0])) if len(bark) == 1 else None,
        "source_bark_triangles": int(len(bark[0][1])) if len(bark) == 1 else None,
        "real_field_measurements": False,
        "metric_dataset_ready": False,
        "limitations": [
            "height is assigned by virtual scaling, not real-tree measurement",
            "mesh envelope includes alpha-card vertices; not alpha-resolved plant surface",
            "bark object/material names do not certify an upright single main stem",
            "no automatic mesh healing, volume allometry, or fabricated forestry truth",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--asset",
        type=Path,
        default=ROOT / "tools/assets/sketchfab/fig_trees/realistic_hd_common_fig_tree_1830.glb",
    )
    parser.add_argument("--height-m", type=float, default=9)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if not np.isfinite(args.height_m) or args.height_m <= 0:
        parser.error("height must be positive finite meters")
    report = inspect_asset(args.asset, args.height_m)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
