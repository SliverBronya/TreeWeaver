"""First predeclared seed: show largest and smallest net GT assignment gains."""

from __future__ import annotations

import json
import sys

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageDraw, ImageFont, ImageOps
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from whole_tree_objective import competitive_decode  # noqa: E402


def main():
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    root = ROOT / "reports/ownership-query-feature-ablation-2026-11-08"
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = Sam2OcclusionModel(base, query_ownership=True).to(device).eval()
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    model.decoder.load_state_dict(
        torch.load(prior, map_location="cpu", weights_only=True)["decoder"], strict=True
    )
    payload = torch.load(root / "query_features-final.pth", map_location="cpu", weights_only=True)
    for key, state in payload["heads"].items():
        getattr(model.decoder, key).load_state_dict(state, strict=True)
    dataset = PairedFigDataset(ROOT / "reports/fig-paired-v6-framing-30-2026-11-08", "validation")
    colors = np.array([[250, 140, 40], [40, 180, 240], [170, 90, 220], [80, 210, 100]], np.uint8)
    pictures = []
    records = []
    (root / "predictions-seed108").mkdir(exist_ok=False)
    with torch.no_grad():
        for i, row in enumerate(dataset.items):
            if row["condition"] != "scene" or len(row["instances"]) < 2:
                continue
            sample = dataset.sample(i)
            inputs, _ = tensors(sample, device)
            result = model(**inputs)
            target = np.stack([dataset._native_mask(x["visible"]) for x in row["instances"]])
            common = ~np.stack(
                [dataset._native_mask(x["raster_unknown"]) for x in row["instances"]]
            ).any(0)
            raw = F.interpolate(
                result["masks"][0], target.shape[-2:], mode="bilinear", align_corners=False
            )[:, 0].cpu()
            owner = F.interpolate(
                result["ownership_logits"], target.shape[-2:], mode="bilinear", align_corners=False
            )[0].cpu()
            baseline = competitive_decode(raw).numpy() & common
            candidate = competitive_decode(raw, owner).numpy() & common
            assert np.array_equal(baseline.any(0), candidate.any(0))
            fixed = (target & ~baseline & candidate).any(0) & common
            broken = (target & baseline & ~candidate).any(0) & common
            changed = (baseline != candidate).any(0) & common
            metrics = {
                "id": row["id"],
                "fixed_gt_foreground_pixels": int(fixed.sum()),
                "broken_gt_foreground_pixels": int(broken.sum()),
                "changed_background_owner_pixels": int((changed & ~target.any(0)).sum()),
                "foreground_union_changed": False,
            }
            records.append(metrics)
            np.savez_compressed(
                root / "predictions-seed108" / (row["id"] + ".npz"),
                baseline=baseline,
                candidate=candidate,
                known=common,
            )
            rgb = cv2.cvtColor(cv2.imread(str(dataset._path(row["image"]))), cv2.COLOR_BGR2RGB)
            rgb = cv2.resize(rgb, (raw.shape[-1], raw.shape[-2]))
            positions = np.argwhere(changed)
            if len(positions):
                y0, x0 = positions.min(0)
                y1, x1 = positions.max(0) + 1
                x0 = max(int(x0) - 30, 0)
                y0 = max(int(y0) - 30, 0)
                x1 = min(int(x1) + 30, rgb.shape[1])
                y1 = min(int(y1) + 30, rgb.shape[0])
            else:
                y0, x0, y1, x1 = 0, 0, *rgb.shape[:2]
            panels = [rgb]
            for masks in (target, baseline, candidate):
                overlay = rgb.copy()
                for q, mask in enumerate(masks):
                    overlay[mask] = (overlay[mask] * 0.35 + colors[q] * 0.65).astype(np.uint8)
                panels.append(overlay[y0:y1, x0:x1])
            delta = rgb.copy()
            delta[changed] = (170, 170, 170)
            delta[fixed] = (40, 210, 70)
            delta[broken] = (240, 50, 50)
            panels.append(delta[y0:y1, x0:x1])
            pictures.append((metrics, panels))
    ordered = sorted(
        pictures,
        key=lambda x: x[0]["fixed_gt_foreground_pixels"] - x[0]["broken_gt_foreground_pixels"],
    )
    chosen = [ordered[-1], ordered[0]]
    sheet = Image.new("RGB", (1500, 690), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)
    draw.text(
        (8, 5),
        "Seed108 only; largest / smallest net gain. Same crop across GT/baseline/query/change.",
        font=font,
        fill="black",
    )
    titles = [
        "Full RGB",
        "GT ownership crop",
        "Mask-score competition",
        "Query-feature ownership",
        "Green fixed / red broken",
    ]
    for ri, (metrics, panels) in enumerate(chosen):
        y = 35 + ri * 320
        draw.text(
            (8, y),
            json.dumps(metrics),
            font=ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 14),
            fill="black",
        )
        for ci, (title, panel) in enumerate(zip(titles, panels, strict=True)):
            draw.text(
                (ci * 300 + 3, y + 25),
                title,
                font=ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 16),
                fill="black",
            )
            image = ImageOps.contain(Image.fromarray(panel), (296, 260))
            sheet.paste(image, (ci * 300, y + 52))
    sheet.save(root / "ownership-comparison-seed108.jpg", quality=94)
    write(
        root / "pixel-assignment-audit-seed108.json",
        {
            "seed": 20261108,
            "selection": "largest/smallest net gain, not chosen best seed",
            "fixed": sum(x["fixed_gt_foreground_pixels"] for x in records),
            "broken": sum(x["broken_gt_foreground_pixels"] for x in records),
            "records": records,
            "foreground_union_preserved": True,
            "test_accessed": False,
        },
    )
    print(records)


if __name__ == "__main__":
    main()
