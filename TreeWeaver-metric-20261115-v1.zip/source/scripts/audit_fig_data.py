"""Prepare asset-disjoint scene plans or audit Fig datasets without changing them."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from fig_data_protocol import (
    audit_metadata,
    make_generation_plan,
    make_paired_generation_plan,
    make_spaced_paired_generation_plan,
    sha256_file,
    validate_plan,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    prepare = subparsers.add_parser("plan")
    prepare.add_argument("--assets", required=True, type=Path)
    prepare.add_argument("--seed", type=int, default=20261101)
    prepare.add_argument("--output", required=True, type=Path)
    prepare.add_argument("--paired", action="store_true")
    prepare.add_argument("--spacing-mix", action="store_true")
    audit = subparsers.add_parser("audit")
    audit.add_argument("--root", required=True, type=Path)
    audit.add_argument("--compare", type=Path)
    audit.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output exists; refusing to overwrite a frozen plan or audit")
    if args.command == "plan":
        paths = sorted(args.assets.glob("*.glb"))
        builder = make_paired_generation_plan if args.paired else make_generation_plan
        if args.spacing_mix:
            if not args.paired:
                parser.error("--spacing-mix requires --paired")
            builder = make_spaced_paired_generation_plan
        result = builder([path.stem for path in paths], args.seed)
        validate_plan(result)
        result["asset_manifest"] = {
            path.stem: {
                "path": str(path.resolve()),
                "sha256": sha256_file(path),
            }
            for path in paths
        }
    else:
        result = audit_metadata(args.root, args.compare)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"output": str(args.output), "schema_version": result["schema_version"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
