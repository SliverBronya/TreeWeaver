from pathlib import Path
import html

root = Path(r"D:\TreeWeaver\reports\synthetic-val-dino-readout-2026-11-10")
images = sorted((root / "per-image").glob("*.jpg"))
parts = [
    "<!doctype html><html><head><meta charset='utf-8'>",
    "<title>Synthetic validation: DINO top-1 box + readout</title>",
    "<style>body{font-family:sans-serif;background:#222;color:#eee}",
    "img{width:100%;max-width:2240px;display:block;margin:12px auto;border:1px solid #555}",
    "a{color:#8cf}</style></head><body>",
    "<h1>Synthetic validation: DINO top-1 box + readout</h1>",
    "<p>No GT box as input. GT visible is used only for scoring.</p>",
]
for path in images:
    name = html.escape(path.name)
    stem = html.escape(path.stem)
    parts.append(
        f"<h2>{stem}</h2><a href='per-image/{name}'>"
        f"<img loading='lazy' src='per-image/{name}' alt='{stem}'></a>"
    )
parts.append("</body></html>")
(root / "gallery.html").write_text("\n".join(parts), encoding="utf-8")
print(root / "gallery.html", len(images))
