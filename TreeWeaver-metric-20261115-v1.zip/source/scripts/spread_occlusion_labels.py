"""Derive occlusion-order labels for SPREAD frames and export diagnostic overlays.

Label definition (per frame, per target tree named in the filename)
------------------------------------------------------------------
Using the shipped depth map we can decide, for every pixel, whether the surface
seen there lies in front of or behind the target tree. That yields the first
piece of supervision SPREAD can give for the occlusion problem, with no manual
annotation:

* ``target_visible``   pixels labelled as the target instance (its visible skin)
* ``in_front``         valid-depth pixels closer than the target surface
* ``behind``           valid-depth pixels farther than the target surface
* ``unknown``          invalid depth (PFM sentinel 65504)

Per-instance ordering versus the target (front / behind / mixed) is also written
to JSON. This is geometric ordering evidence, NOT a claim about hidden extent.

Read-only; a handful of small PNG/PFM files per run so it does not compete with
the ongoing archive extraction.
"""

from __future__ import annotations

import argparse
import json
import os

import cv2
import numpy as np

BASE = r"D:\TreeWeaver\data\external\spread"
SENTINEL = 65504.0


def load_palette() -> dict[int, tuple[int, int, int]]:
    raw = json.load(open(os.path.join(BASE, "color_palette.json"), encoding="utf-8"))
    return {int(k): tuple(reversed([int(x) for x in v])) for k, v in raw["palette"].items()}


def read_depth(path: str) -> np.ndarray:
    """Read a SPREAD depth PFM in the same orientation as the RGB frames.

    PFM stores rows bottom-up. ``cv2.imread`` returns them as stored, so the
    array is vertically flipped with respect to the RGB/instance PNGs. Measured
    proof (2026-10-13): the no-hit sentinel (65504, i.e. sky) occupies 24-53% of
    the *bottom* fifth and 0% of the top fifth on four independent frames, while
    sky must be at the top. Flipping moves it to the top, so the flip is applied
    here and every consumer gets RGB-aligned depth.
    """
    depth = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if depth is None:
        raise FileNotFoundError(path)
    if depth.ndim == 3:
        depth = depth[:, :, 0]
    return np.flipud(depth.astype(np.float32))


def orientation_evidence(scene: str, frame: str) -> str:
    """Report the sky-band position, which is what actually pins the flip."""
    raw = cv2.imread(os.path.join(BASE, scene, "depth_pfm", frame + ".pfm"), cv2.IMREAD_UNCHANGED)
    if raw.ndim == 3:
        raw = raw[:, :, 0]
    raw = raw.astype(np.float32)
    h = raw.shape[0]
    invalid = (raw >= SENTINEL - 1) | (raw <= 0)
    msg = (
        f"{frame}: sentinel(sky) share  top-fifth={invalid[: h // 5].mean():.3f}"
        f"  bottom-fifth={invalid[-h // 5 :].mean():.3f}"
    )
    flipped = np.flipud(invalid)
    return msg + f"  | after flip  top-fifth={flipped[: h // 5].mean():.3f}"


def process_frame(scene: str, frame: str, pal: dict, out_dir: str) -> dict:
    inst = cv2.imread(os.path.join(BASE, scene, "instance_segmentation", frame + ".png"), cv2.IMREAD_UNCHANGED)
    rgb = cv2.imread(os.path.join(BASE, scene, "rgb", frame + ".png"), cv2.IMREAD_UNCHANGED)
    sem = cv2.imread(os.path.join(BASE, scene, "semantic_segmentation", frame + ".png"), cv2.IMREAD_UNCHANGED)
    dep = read_depth(os.path.join(BASE, scene, "depth_pfm", frame + ".pfm"))
    h, w = dep.shape

    listed: dict[str, int] = {}
    txt = os.path.join(BASE, scene, "instance_segmentation", frame + ".txt")
    if os.path.exists(txt):
        for line in open(txt, encoding="utf-8"):
            parts = line.split()
            if len(parts) >= 2:
                listed[parts[0]] = int(parts[1])

    target = frame.split("_")[0]

    def mask_of(idx: int) -> np.ndarray:
        c = pal.get(idx)
        if c is None:
            return np.zeros((h, w), bool)
        return np.all(inst[:, :, :3] == np.array(c, dtype=np.uint8), axis=2)

    target_mask = mask_of(listed.get(target, -1))
    if target_mask.sum() < 50:
        return {"frame": frame, "skipped": "target not visible"}

    valid = (dep > 0) & (dep < SENTINEL - 1)
    tgt_depth = float(np.median(dep[target_mask & valid])) if (target_mask & valid).any() else float("nan")
    tol = 0.05 * tgt_depth

    in_front = valid & (dep < tgt_depth - tol) & ~target_mask
    behind = valid & (dep > tgt_depth + tol) & ~target_mask
    unknown = ~valid

    per_instance = []
    for name, idx in listed.items():
        if name == target:
            continue
        m = mask_of(idx) & valid
        n = int(m.sum())
        if n < 20:
            continue
        med = float(np.median(dep[m]))
        share = float((m & in_front).sum()) / float(n)
        relation = "in_front" if share > 0.66 else ("behind" if share < 0.34 else "mixed")
        per_instance.append({"tree": name, "px": n, "median_depth": round(med, 3),
                             "front_share": round(share, 3), "relation": relation})
    per_instance.sort(key=lambda d: d["median_depth"])

    n_comp = cv2.connectedComponents(target_mask.astype(np.uint8))[0] - 1
    record = {
        "frame": frame,
        "scene": scene,
        "target": target,
        "target_px": int(target_mask.sum()),
        "target_components": int(n_comp),
        "target_median_depth": round(tgt_depth, 3),
        "instances_listed": len(listed),
        "instances_visible": sum(1 for nm, ix in listed.items() if mask_of(ix).sum() >= 20),
        "in_front_px": int(in_front.sum()),
        "behind_px": int(behind.sum()),
        "unknown_depth_px": int(unknown.sum()),
        "in_front_instances": [d["tree"] for d in per_instance if d["relation"] == "in_front"],
        "ordering": per_instance[:8],
    }

    canvas = np.zeros((h, w * 4 + 30, 3), np.uint8)
    canvas[:, :w] = cv2.resize(rgb[:, :, :3], (w, h), interpolation=cv2.INTER_AREA)
    canvas[:, w + 10 : 2 * w + 10] = inst[:, :, :3]
    order = np.zeros((h, w, 3), np.uint8)
    order[behind] = (70, 70, 70)
    order[in_front] = (0, 0, 255)
    order[unknown] = (25, 25, 25)
    order[target_mask] = (0, 220, 0)
    canvas[:, 2 * w + 20 : 3 * w + 20] = order
    vis = np.clip((np.where(valid, dep, np.nan) - np.nanmin(dep[valid])) /
                  (np.nanpercentile(dep[valid], 95) - np.nanmin(dep[valid])) * 255, 0, 255)
    vis = np.nan_to_num(vis).astype(np.uint8)
    canvas[:, 3 * w + 30 : 4 * w + 30] = cv2.applyColorMap(255 - vis, cv2.COLORMAP_TURBO)
    if sem is not None:
        sem_small = cv2.resize(sem, (w, h), interpolation=cv2.INTER_NEAREST)
        canvas[:, 3 * w + 30 : 4 * w + 30][sem_small == 1] = (255, 255, 255)

    for i, label in enumerate(["rgb", "instance", "GREEN=target RED=in front GREY=behind", "depth + white=sem1"]):
        cv2.putText(canvas, label, (i * (w + 10) + 4, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(os.path.join(out_dir, f"{scene}__{frame}.png"), canvas)
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scene", default="city_park")
    ap.add_argument("--frames", type=int, default=3)
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--output", default=r"D:\TreeWeaver\reports\spread-occlusion-2026-10-13\probe")
    args = ap.parse_args()

    os.makedirs(args.output, exist_ok=True)
    pal = load_palette()
    names = sorted(f for f in os.listdir(os.path.join(BASE, args.scene, "instance_segmentation")) if f.endswith(".png"))
    picks = names[args.start : args.start + args.frames]

    print(orientation_evidence(args.scene, picks[0][:-4]))

    records = []
    for n in picks:
        rec = process_frame(args.scene, n[:-4], pal, args.output)
        records.append(rec)
        if "skipped" in rec:
            print(json.dumps(rec))
        else:
            print(json.dumps({k: rec[k] for k in (
                "frame", "target_px", "target_components", "target_median_depth",
                "instances_listed", "instances_visible", "in_front_px", "in_front_instances")}))
            for d in rec["ordering"][:3]:
                print("      ", json.dumps(d))

    with open(os.path.join(args.output, f"{args.scene}-labels.json"), "w", encoding="utf-8") as fh:
        json.dump(records, fh, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
