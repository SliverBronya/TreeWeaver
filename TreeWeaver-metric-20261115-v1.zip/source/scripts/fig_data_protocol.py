"""Pure data protocol shared by the Blender generator and its audit CLI.

Asset pools are frozen before scenes are sampled. Global object-origin depth
rank is metadata, not pixel-wise occlusion truth for interpenetrating crowns.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import random
from collections import Counter
from pathlib import Path

import numpy as np

GENERATOR_SCHEMA = "treeweaver-fig-generator-2.0"
SPLIT_SCHEMA = "treeweaver-image-splits-1.0"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def make_generation_plan(assets: list[str], seed: int) -> dict:
    """Prepare 400/50/50 scenes using strictly disjoint >=4-asset pools."""
    if len(assets) != len(set(assets)):
        raise ValueError("asset identities must be unique")
    if len(assets) < 12:
        raise ValueError("need at least 12 assets for three disjoint 4-tree pools")
    rng = random.Random(seed)
    shuffled = sorted(assets)
    rng.shuffle(shuffled)
    validation_count = max(4, len(shuffled) // 5)
    test_count = max(4, len(shuffled) // 5)
    train_end = len(shuffled) - validation_count - test_count
    pools = {
        "train": shuffled[:train_end],
        "validation": shuffled[train_end : train_end + validation_count],
        "test": shuffled[train_end + validation_count :],
    }
    records = []
    for split, counts in (
        ("train", [2] * 120 + [3] * 160 + [4] * 120),
        ("validation", [2] * 15 + [3] * 20 + [4] * 15),
        ("test", [2] * 15 + [3] * 20 + [4] * 15),
    ):
        rng.shuffle(counts)
        for count in counts:
            records.append(
                {
                    "id": len(records) + 1,
                    "split": split,
                    "trees": rng.sample(pools[split], count),
                    "scene_seed": rng.randrange(2**32),
                }
            )
    return {
        "schema_version": GENERATOR_SCHEMA,
        "seed": seed,
        "asset_pools": pools,
        "records": records,
        "label_semantics": {
            "visible": "full-scene target-ID coverage, preserving material alpha",
            "amodal": "isolated target-ID coverage",
            "layer_order": "object-origin depth rank; not pixel-wise occlusion truth",
        },
    }


def validate_plan(plan: dict) -> None:
    if plan.get("schema_version") != GENERATOR_SCHEMA:
        raise ValueError("unsupported generation plan schema")
    pools = {name: set(plan["asset_pools"][name]) for name in ("train", "validation", "test")}
    for name, pool in pools.items():
        if len(pool) < 4:
            raise ValueError(f"{name} asset pool needs at least 4 unique assets")
    for left, right in itertools.combinations(pools, 2):
        if pools[left] & pools[right]:
            raise ValueError(f"asset leakage between {left} and {right}")
    seen = set()
    for record in plan["records"]:
        image_id = int(record["id"])
        if image_id in seen:
            raise ValueError("duplicate image id in plan")
        seen.add(image_id)
        split = record["split"]
        trees = record["trees"]
        allowed_counts = (1, 2, 3, 4) if plan.get("profile") == "paired-parts-v1" else (2, 3, 4)
        if len(trees) not in allowed_counts or len(trees) != len(set(trees)):
            raise ValueError("scene has an unsupported number of distinct trees")
        if not set(trees) <= pools[split]:
            raise ValueError(f"scene {image_id} uses assets outside its split")
        if not isinstance(record["scene_seed"], int):
            raise ValueError("scene_seed must be an integer")


def make_paired_generation_plan(assets: list[str], seed: int) -> dict:
    """Thirty qualification scenes, each with same-camera counterfactual controls."""
    base = make_generation_plan(assets, seed)
    rng = random.Random(seed + 101)
    records = []
    counts = [1, 2, 3, 4, 2, 3, 4, 1, 2, 3]
    overlaps = [0.0, 0.10, 0.35, 0.65, 0.65, 0.10, 0.35, 0.0, 0.35, 0.65]
    for split, pool in base["asset_pools"].items():
        for count, overlap in zip(counts, overlaps, strict=True):
            records.append(
                {
                    "id": len(records) + 1,
                    "split": split,
                    "trees": rng.sample(pool, count),
                    "scene_seed": rng.randrange(2**32),
                    "requested_bbox_overlap": overlap,
                }
            )
    base.update(
        {
            "profile": "paired-parts-v1",
            "records": records,
            "grouping": "scene and every counterfactual target remain in the same split",
            "qualification_only": True,
        }
    )
    return base


def make_spaced_paired_generation_plan(assets: list[str], seed: int) -> dict:
    """Keep source trees/seeds matched, but include separated multi-tree scenes.

    This is a declared development mix, not a measured real-forest distribution.
    Negative overlap means a crown-envelope gap relative to the smaller width.
    """
    plan = make_paired_generation_plan(assets, seed)
    classes = [
        "single",
        "separated",
        "separated",
        "separated",
        "touching",
        "light",
        "moderate",
        "single",
        "light",
        "hard",
    ]
    overlaps = [0.0, -0.35, -0.25, -0.20, 0.0, 0.10, 0.25, 0.0, 0.10, 0.50]
    for index, record in enumerate(plan["records"]):
        record["spacing_class"] = classes[index % 10]
        record["requested_bbox_overlap"] = overlaps[index % 10]
        record["minimum_origin_separation_ratio"] = 0.60
    plan["layout_profile"] = "spacing-mix-v1"
    plan["spacing_mix_per_split"] = dict(Counter(classes))
    return plan


def crown_layout_centers(widths, overlap):
    """Centers based on *all* crown envelopes, allowing gaps and unequal widths."""
    if not widths or any(width <= 0 for width in widths) or not -0.8 <= overlap <= 0.8:
        raise ValueError("positive widths and overlap in [-.8,.8] required")
    centers = [0.0]
    for previous, current in zip(widths[:-1], widths[1:], strict=True):
        centers.append(centers[-1] + (previous + current) / 2 - overlap * min(previous, current))
    left = min(center - width / 2 for center, width in zip(centers, widths, strict=True))
    right = max(center + width / 2 for center, width in zip(centers, widths, strict=True))
    return [center - (left + right) / 2 for center in centers]


def separated_depths(xs, widths, depth_order, base_gap, minimum_ratio=0.60):
    """Keep object origins apart in XY without coupling front order to left/right."""
    ys = [0.0] * len(xs)
    placed = []
    for rank, index in enumerate(depth_order):
        y = rank * base_gap
        for previous in placed:
            minimum = minimum_ratio * min(widths[index], widths[previous])
            dx = abs(xs[index] - xs[previous])
            if dx < minimum:
                y = max(y, ys[previous] + (minimum**2 - dx**2) ** 0.5)
            else:
                y = max(y, ys[previous] + base_gap)
        ys[index] = y
        placed.append(index)
    return ys


def material_part(name: str) -> str:
    """Explicit source-material semantics, not a geometric lower-mask proxy."""
    if name.startswith(("QualifiedOlive_Leaf", "QualifiedDense_Leaf")):
        return "crown_surface"
    if name.startswith(
        ("QualifiedOlive_WoodUnknown", "QualifiedOlive_Unassigned", "QualifiedDense_WoodUnknown")
    ):
        return "part_unknown"
    # Reviewed southern-magnolia source mesh. Cut caps have no unambiguous
    # trunk/crown attribution and remain part-unknown, while whole-tree GT stays known.
    if name.startswith("MagnoliaBark_Mat"):
        return "stem"
    if name.startswith(
        ("Branches_04_Mat", "Branches_06_Mat", "MagnoliaLeaf_Mat", "MagnoliaBud_Mat")
    ):
        return "crown_surface"
    if name.startswith("Cap_02_Mat"):
        return "part_unknown"
    if name.startswith("Ficus_carica_bark"):
        return "stem"
    if name.startswith(
        (
            "Ficus_carica_branch_",
            "Ficus_carica_leaf_",
            "Ficus_car_lf_stk_",
            "Ficus_carica_twig_",
            "Ficus_fruit",
        )
    ):
        return "crown_surface"
    raise ValueError(f"unreviewed tree material: {name}")


def partition_part_coverage(support, stem, crown, epsilon=1 / 255):
    """Partition target support; mixed/zero-coverage boundaries stay unknown."""
    support = np.asarray(support, bool)
    stem, crown = np.asarray(stem), np.asarray(crown)
    if stem.shape != support.shape or crown.shape != support.shape:
        raise ValueError("part coverage shape mismatch")
    trunk = support & (stem > crown + epsilon)
    canopy = support & (crown > stem + epsilon)
    unknown = support & ~(trunk | canopy)
    return trunk, canopy, unknown


def absolute_crown_profile(mask, knots=12):
    """Outer surface spans with absolute image coordinates, preserving scale.

    This records a profile; it never fills the leaf gaps in the mask.
    """
    mask = np.asarray(mask, bool)
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return {"observed": False, "bands": []}
    top, bottom = int(ys.min()), int(ys.max())
    bands = []
    for index in range(knots):
        y = max(top, bottom - int((index + 0.5) * (bottom - top + 1) / knots))
        columns = np.flatnonzero(mask[y])
        bands.append(
            {
                "y_px": y,
                "observed": bool(len(columns)),
                "left_px": int(columns.min()) if len(columns) else None,
                "right_px": int(columns.max()) if len(columns) else None,
                "width_px": int(columns.max() - columns.min() + 1) if len(columns) else 0,
            }
        )
    return {
        "observed": True,
        "bounds_xyxy": [int(xs.min()), top, int(xs.max()) + 1, bottom + 1],
        "image_width_px": mask.shape[1],
        "image_height_px": mask.shape[0],
        "bands": bands,
    }


def paired_support_masks(visible, scene_coverage, isolated_coverage, *, single_tree=False):
    """Use one majority threshold; ignore raster ambiguity instead of inventing amodal area."""
    visible = np.asarray(visible, bool)
    scene = np.asarray(scene_coverage)
    isolated = np.asarray(isolated_coverage)
    if scene.shape != visible.shape or isolated.shape != visible.shape:
        raise ValueError("coverage shape mismatch")
    amodal = isolated >= 0.5
    unknown = (np.abs(isolated - 0.5) < 1 / 32) | (np.abs(scene - 0.5) < 1 / 32)
    unknown |= visible & ~amodal
    if single_tree:
        difference = visible ^ amodal
        if difference.sum() / max(int((visible | amodal).sum()), 1) > 0.01:
            raise ValueError("single-tree coverage disagrees by more than 1%; inspect renderer")
        unknown |= difference
    return visible & ~unknown, amodal & ~unknown, unknown


def layout_orders(count: int, rng: random.Random) -> tuple[list[int], list[int]]:
    """Independent random permutations for origin depth and horizontal layout."""
    depth_order = list(range(count))
    horizontal_order = list(range(count))
    rng.shuffle(depth_order)
    rng.shuffle(horizontal_order)
    return depth_order, horizontal_order


def pair_metrics(masks: list[np.ndarray]) -> list[dict]:
    pairs = []
    for i, j in itertools.combinations(range(len(masks)), 2):
        intersection = int(np.logical_and(masks[i], masks[j]).sum())
        smaller = min(int(masks[i].sum()), int(masks[j].sum()))
        pairs.append(
            {
                "pair": [i + 1, j + 1],
                "area_overlap_px": intersection,
                "ratio_min": round(intersection / max(smaller, 1), 6),
            }
        )
    return pairs


def ownership_from_coverage(coverages: list[np.ndarray], threshold: float = 0.5) -> np.ndarray:
    """Resolve antialiased ID boundaries once into a mutually exclusive ID map."""
    if not coverages:
        raise ValueError("no object coverages")
    stack = np.stack(coverages)
    if not np.isfinite(stack).all() or stack.min() < 0 or stack.max() > 1:
        raise ValueError("coverage must be finite in [0,1]")
    owner = np.argmax(stack, axis=0).astype(np.uint16) + 1
    owner[stack.max(axis=0) < threshold] = 0
    return owner


def audit_metadata(root: Path, compare: Path | None = None) -> dict:
    """Read-only audit; never repair old metadata or silently certify old labels."""
    metas = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted((root / "meta").glob("*.json"))
    ]
    if not metas:
        raise ValueError("no image metadata")
    assets = set()
    split_assets: dict[str, set] = {}
    missing_pairs = []
    pair_count = 0
    shortcut_correct = 0
    shortcut_total = 0
    label_sources = Counter()
    for meta in metas:
        assets.update(meta["trees"])
        split_assets.setdefault(meta.get("split", "unspecified"), set()).update(meta["trees"])
        expected = set(itertools.combinations(range(1, len(meta["trees"]) + 1), 2))
        actual_list = [tuple(pair["pair"]) for pair in meta.get("pairs", [])]
        actual = set(actual_list)
        if actual != expected or len(actual_list) != len(actual):
            missing_pairs.append(
                {
                    "id": meta["id"],
                    "missing": sorted(expected - actual),
                    "unexpected": sorted(actual - expected),
                    "duplicates": len(actual_list) - len(actual),
                }
            )
        pair_count += len(actual_list)
        label_sources[meta.get("visible_label_source", "legacy-unspecified")] += 1
        # Read rendered visible masks, not scene transforms, for the shortcut baseline.
        centers = []
        for i in range(len(meta["trees"])):
            path = root / "masks" / f"{int(meta['id']):06d}" / f"visible_{i + 1}.png"
            import cv2

            image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
            if image is None:
                centers.append(None)
                continue
            mask = image[..., 3] > 16 if image.ndim == 3 and image.shape[-1] == 4 else image > 16
            xs = np.nonzero(mask)[1]
            centers.append(float(xs.min() + xs.max()) / 2 if len(xs) else None)
        ranks = {name: i for i, name in enumerate(meta["layer_order_front_to_back"])}
        for i, j in itertools.combinations(range(len(centers)), 2):
            if centers[i] is not None and centers[j] is not None and centers[i] != centers[j]:
                shortcut_total += 1
                shortcut_correct += int(
                    (centers[i] < centers[j]) == (ranks[meta["trees"][i]] < ranks[meta["trees"][j]])
                )
    shared = {}
    for left, right in itertools.combinations(split_assets, 2):
        shared[f"{left}/{right}"] = sorted(split_assets[left] & split_assets[right])
    result = {
        "schema_version": "treeweaver-fig-audit-1.0",
        "root": str(root.resolve()),
        "images": len(metas),
        "unique_assets": len(assets),
        "recorded_pairs": pair_count,
        "expected_pairs": sum(len(meta["trees"]) * (len(meta["trees"]) - 1) // 2 for meta in metas),
        "incomplete_pair_images": missing_pairs,
        "visible_label_sources": dict(label_sources),
        "left_is_front_baseline": {
            "correct": shortcut_correct,
            "total": shortcut_total,
            "accuracy": shortcut_correct / shortcut_total if shortcut_total else None,
        },
        "cross_split_shared_assets": shared,
    }
    if compare is not None:
        other = [
            json.loads(path.read_text(encoding="utf-8"))
            for path in (compare / "meta").glob("*.json")
        ]
        other_by_id = {int(meta["id"]): meta for meta in other}
        fields = ("trees", "layer_order_front_to_back", "lens_mm", "count")
        result["comparison"] = {
            "root": str(compare.resolve()),
            "shared_assets": sorted(assets & {name for meta in other for name in meta["trees"]}),
            "same_id_matching_scene_fields": sum(
                int(meta["id"]) in other_by_id
                and all(meta.get(key) == other_by_id[int(meta["id"])].get(key) for key in fields)
                for meta in metas
            ),
        }
    manifest = root / "splits.json"
    if manifest.exists():
        frozen = json.loads(manifest.read_text(encoding="utf-8"))
        splits = frozen["splits"]
        actual_ids = {int(meta["id"]) for meta in metas}
        sets = {key: set(map(int, value)) for key, value in splits.items()}
        result["split_manifest"] = {
            "sha256": sha256_file(manifest),
            "missing_ids": sorted(set().union(*sets.values()) - actual_ids),
            "unassigned_ids": sorted(actual_ids - set().union(*sets.values())),
            "overlapping_ids": {
                f"{a}/{b}": sorted(sets[a] & sets[b]) for a, b in itertools.combinations(sets, 2)
            },
        }
    return result
