"""Improved Blender pair render: dense broadleaf tree + forest HDRI + textured ground."""

from __future__ import annotations

import json
import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ASSET = Path(r"D:\TreeWeaver\tools\assets\tree_small_02\tree_small_02_1k.blend")
OBJECT = "tree_small_02_LOD1"
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0
LENS = 40.0


def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    out = Path(argv[0]) if argv else Path(r"D:\TreeWeaver\reports\blender-pairs-v2")
    pairs = int(argv[1]) if len(argv) > 1 else 1
    seed = int(argv[2]) if len(argv) > 2 else 3
    return out, pairs, seed


def clean_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.image_settings.color_depth = "8"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.4
    scene.eevee.taa_render_samples = 64
    return scene


def append_tree():
    bpy.ops.wm.append(directory=str(ASSET) + "/Object/", filename=OBJECT)
    obj = bpy.data.objects[OBJECT]
    for other in list(bpy.data.objects):
        if other is not obj:
            bpy.data.objects.remove(other, do_unlink=True)
    return obj


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points),
        max(p.x for p in points),
        min(p.y for p in points),
        max(p.y for p in points),
        min(p.z for p in points),
        max(p.z for p in points),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = (scale, scale, scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def add_ground():
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    ground = bpy.context.object
    material = bpy.data.materials.new("ground_mat")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    normal = nodes.new("ShaderNodeTexImage")
    normal.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    normal.image.colorspace_settings.name = "Non-Color"
    normal_map = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (24.0, 24.0, 24.0)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], texture.inputs["Vector"])
    links.new(mapping.outputs["Vector"], normal.inputs["Vector"])
    links.new(normal.outputs["Color"], normal_map.inputs["Color"])
    links.new(texture.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    ground.data.materials.append(material)
    return ground


def add_world():
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    background = nodes.get("Background")
    environment = nodes.new("ShaderNodeTexEnvironment")
    environment.image = bpy.data.images.load(str(ENV / "forest_slope_2k.hdr"))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, math.radians(40))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], environment.inputs["Vector"])
    links.new(environment.outputs["Color"], background.inputs["Color"])
    background.inputs["Strength"].default_value = 1.1
    bpy.context.scene.world = world


def add_lights():
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = 2.2
    sun.data.angle = math.radians(6)
    sun.rotation_euler = (math.radians(52), 0, math.radians(30))


def add_camera(target):
    bpy.ops.object.camera_add()
    camera = bpy.context.object
    camera.data.lens = LENS
    camera.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / LENS)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    camera.location = (0, -distance, TARGET_HEIGHT * 0.48)
    camera.rotation_euler = (math.radians(90), 0, 0)
    camera.data.dof.use_dof = True
    camera.data.dof.focus_object = target
    camera.data.dof.aperture_fstop = 4.0
    bpy.context.scene.camera = camera
    return camera, distance


def render(path: Path, transparent: bool, hidden=()):
    scene = bpy.context.scene
    scene.render.film_transparent = transparent
    for obj in bpy.data.objects:
        if obj.type == "MESH":
            obj.hide_render = obj.name in hidden
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)


def main():
    out, pairs, seed = parse_args()
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    summary = []
    for index in range(pairs):
        clean_scene()
        base = append_tree()
        normalize(base, TARGET_HEIGHT)
        base.name = "tree_target"
        base.rotation_euler = (0, 0, math.radians(rng.uniform(-10, 10)))

        left = duplicate(base)
        left.name = "tree_left"
        left.scale = tuple(value * rng.uniform(0.80, 0.92) for value in base.scale)
        left.location = (-rng.uniform(4.2, 5.0), rng.uniform(1.0, 2.0), 0)
        left.rotation_euler = (0, 0, math.radians(rng.uniform(60, 130)))

        right = duplicate(base)
        right.name = "tree_right"
        right.scale = tuple(value * rng.uniform(0.82, 0.94) for value in base.scale)
        right.location = (rng.uniform(4.2, 5.0), rng.uniform(-2.0, -1.0), 0)
        right.rotation_euler = (0, 0, math.radians(rng.uniform(-130, -60)))

        ground = add_ground()
        add_world()
        add_lights()
        camera, distance = add_camera(base)

        prefix = f"pair_{index:02d}"
        render(out / f"{prefix}_rgb.png", transparent=False)
        for name, obj in (("target", base), ("left", left), ("right", right)):
            others = [o.name for o in (base, left, right) if o is not obj] + [ground.name]
            render(out / f"{prefix}_{name}.png", transparent=True, hidden=others)

        summary.append(
            {
                "pair": index,
                "camera_distance": distance,
                "target_height_fraction": 0.85,
                "objects": {
                    "target": [round(v, 3) for v in base.location],
                    "left": [round(v, 3) for v in left.location],
                    "right": [round(v, 3) for v in right.location],
                },
            }
        )
        print(f"rendered {prefix}", flush=True)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("done", len(summary))


if __name__ == "__main__":
    main()


