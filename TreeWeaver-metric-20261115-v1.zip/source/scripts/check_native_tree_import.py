"""Blender integration check: an appended parent mesh must not become the tree."""

import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from generate_fig_500 import load_tree  # noqa: E402

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(size=50)
parent = bpy.context.object
parent.name = "UnselectedColliderParent"
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 4))
tree = bpy.context.object
tree.name = "SelectedTree"
tree.parent = parent
out = ROOT / "reports/native-tree-import-integration-2026-11-08"
out.mkdir(exist_ok=False)
fixture = out / "fixture.blend"
bpy.ops.wm.save_as_mainfile(filepath=str(fixture), check_existing=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
loaded = load_tree(fixture, ["SelectedTree"])
assert len(loaded.data.vertices) == 8, "unselected parent/collider leaked into tree geometry"
assert len(loaded.data.polygons) == 6
assert loaded.parent is None
try:
    load_tree(fixture, ["MissingTree"])
except ValueError:
    pass
else:
    raise AssertionError("missing selected mesh must fail")
(out / "result.json").write_text('{"selected_mesh_only":true,"missing_mesh_rejected":true}')
print("NATIVE IMPORT CHECK PASSED: parent/collider excluded")
