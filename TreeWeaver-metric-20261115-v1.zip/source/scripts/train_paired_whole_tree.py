"""Controlled whole-tree coverage/identity pilot on qualified paired renders.

No trunk-only data, legacy Fig500, test images, amodal or layer-order losses.
Both arms start from the same real-whole-tree adapted decoder and share prompts,
training order and step budget. This is an asset-held-out development pilot.
"""

from __future__ import annotations

import argparse
import copy
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from paired_fig_dataset import PairedFigDataset  # noqa: E402
from research_protocol import assert_training_allowed, pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import mask_row  # noqa: E402
from whole_tree_objective import competitive_decode, whole_tree_loss  # noqa: E402

REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
INITIAL = ROOT / "reports/real-visible-pilot-2026-11-01/run-200/final.pth"


def write(path, value):
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def anchor_points(sample):
    # Sample BEFORE downsampling: thin stems can disappear or shift at 256x256.
    return sample["identity_points"], sample["identity_sources"]


def tensors(sample, device):
    points, sources = anchor_points(sample)
    labels = sample["identity_labels"]
    inputs = {
        "pixel_values": torch.from_numpy(sample["pixel_values"])[None].to(device),
        "input_boxes": torch.from_numpy(sample["boxes"])[None].to(device),
        "input_points": torch.from_numpy(points)[None, :, None].to(device),
        "input_labels": torch.tensor(labels, device=device)[None, :, None],
    }
    return inputs, sources


def read_mask(dataset, relative):
    rgba = cv2.imread(str(dataset._path(relative)), cv2.IMREAD_UNCHANGED)
    if rgba is None or rgba.shape[-1] != 4:
        raise ValueError(f"not an RGBA supervision mask: {relative}")
    return rgba[..., 3] > 16


def evaluate(model, dataset, device, folder, *, learned=False):
    model.eval()
    folder.mkdir()
    rows, predictions = [], {}
    with torch.no_grad():
        for index, record in enumerate(dataset.items):
            sample = dataset.sample(index)
            inputs, sources = tensors(sample, device)
            result = model(**inputs)
            instances = record["instances"]
            target = np.stack([read_mask(dataset, item["visible"]) for item in instances])
            known = ~np.stack([read_mask(dataset, item["raster_unknown"]) for item in instances])
            common = known.all(0)
            raw = F.interpolate(
                result["masks"][0, :, 0][:, None],
                target.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )[:, 0].cpu()
            owner = F.interpolate(
                result["ownership_logits"],
                target.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )[0].cpu()
            variants = {
                "independent": (raw > 0).numpy() & common,
                "mask_winner": competitive_decode(raw).numpy() & common,
            }
            if learned:
                variants["owner_winner"] = competitive_decode(raw, owner).numpy() & common
            target = target & common
            predictions[record["id"]] = variants
            np.savez_compressed(
                folder / f"{record['id']}.npz", logits=raw.numpy(), ownership_logits=owner.numpy()
            )
            for variant, predicted in variants.items():
                if not np.array_equal(predicted.any(0), variants["independent"].any(0)):
                    raise ValueError("identity decoding changed foreground union")
                for tree, item in enumerate(instances):
                    metrics = mask_row(
                        f"{record['id']}:{tree + 1}",
                        predicted[tree],
                        target[tree],
                        others=np.delete(target, tree, axis=0),
                    )
                    metrics.update(
                        {
                            "sample_id": record["id"],
                            "group_id": record["group_id"],
                            "condition": record["condition"],
                            "anchor_source": sources[tree],
                            "decoder": variant,
                        }
                    )
                    for part in ("crown", "stem"):
                        support = read_mask(dataset, item[f"visible_{part}"])
                        part_known = common & ~read_mask(dataset, item["visible_part_unknown"])
                        support &= part_known
                        metrics[f"{part}_recall"] = (
                            float((predicted[tree] & support).sum() / support.sum())
                            if support.any()
                            else None
                        )
                    rows.append(metrics)
    summary = {}
    for variant in sorted({row["decoder"] for row in rows}):
        summary[variant] = {}
        for condition in ("all", "scene", "isolated", "multi_scene"):
            subset = [
                row
                for row in rows
                if row["decoder"] == variant
                and (
                    condition == "all"
                    or row["condition"] == condition
                    or (
                        condition == "multi_scene"
                        and row["condition"] == "scene"
                        and len(predictions[row["sample_id"]][variant]) > 1
                    )
                )
            ]
            summary[variant][condition] = {"instances": len(subset)}
            for key in (
                "iou",
                "recall",
                "precision",
                "neighbour_fraction",
                "crown_recall",
                "stem_recall",
            ):
                values = [row[key] for row in subset if row[key] is not None]
                summary[variant][condition][key] = float(np.mean(values)) if values else None
    write(folder / "per-tree.json", rows)
    write(folder / "summary.json", summary)
    return summary, predictions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.steps <= 300:
        parser.error("fresh output and 1..300 steps required")
    assert_training_allowed(args.data)
    audit = json.loads((args.data / "paired-audit.json").read_text(encoding="utf-8"))
    splits = json.loads((args.data / "splits.json").read_text(encoding="utf-8"))
    if not audit["planned_dataset_complete"] or not splits["complete"]:
        raise ValueError("incomplete paired data is not admitted")
    if any(record["frame_truncated"] for record in audit["records"]):
        raise ValueError("main whole-tree pilot requires fully framed source targets")
    datasets = {role: PairedFigDataset(args.data, role) for role in ("train", "validation")}
    train = datasets["train"]
    scenes = [i for i, row in enumerate(train.items) if row["condition"] == "scene"]
    controls = [i for i, row in enumerate(train.items) if row["condition"] == "isolated"]
    rng = random.Random(20261108)
    order = [rng.choice(controls if step % 4 == 3 else scenes) for step in range(args.steps)]
    args.output.mkdir(parents=True)
    protocol = {
        "profile": "whole-tree-visible-identity-pilot-v3-native-points",
        "seed": 20261108,
        "sam_revision": REVISION,
        "steps_per_arm": args.steps,
        "lr": 1e-5,
        "initial_checkpoint": str(INITIAL),
        "initial_checkpoint_sha256": sha256_file(INITIAL),
        "initialization": "176 real TreeStereo full-tree references; no legacy Fig500 weights",
        "arms": ["coverage", "coverage_identity"],
        "decoding": (
            "independent masks; simple mask-score competition control; learned ownership "
            "competition on jointly positive queries; every decoder preserves foreground union"
        ),
        "task": "whole visible trees; crowns and stems; adjacent-tree identity",
        "prompt": "identical GT visible boxes + positive pixel sampled at native label resolution",
        "prompt_scope": "given-target diagnostic, not autonomous instance detection",
        "sampling": "three scene steps per one isolated-control step; fixed shared order",
        "train_sample_order": [train.items[i]["id"] for i in order],
        "selection": "fixed final step; validation after each arm, no checkpoint search",
        "test_images_accessed": False,
        "amodal_loss_enabled": False,
        "canatree_or_legacy_fig500_used": False,
        "evaluation": "native 640x360 labels; unknown ignored; all decoding ablations saved",
        "versions": {"torch": str(torch.__version__), "opencv": cv2.__version__},
        "scope": "single fig species, simple background; development only, no real-domain claim",
        "acceptance": {
            "scene_neighbour_fraction_relative_reduction": 0.10,
            "scene_iou_drop_at_most": 0.0,
            "scene_recall_drop_at_most": 0.005,
            "scene_precision_drop_at_most": 0.005,
        },
        "input_sha256": {},
        "source_sha256": {},
    }
    for filename in (
        "paired-samples.json",
        "splits.json",
        "paired-audit.json",
        "generation_plan.json",
    ):
        path = args.data / filename
        protocol["input_sha256"][str(path)] = sha256_file(path)
    for dataset in datasets.values():
        for row in dataset.items:
            paths = [row["image"]]
            for item in row["instances"]:
                paths.extend(
                    value
                    for value in item.values()
                    if isinstance(value, str) and value.endswith(".png")
                )
            for relative in paths:
                path = dataset._path(relative)
                protocol["input_sha256"][str(path)] = sha256_file(path)
    source = args.output / "source"
    source.mkdir()
    for path in (
        Path(__file__),
        ROOT / "workers/tree_models/whole_tree_objective.py",
        ROOT / "workers/tree_models/paired_fig_dataset.py",
        ROOT / "workers/tree_models/partial_supervision.py",
        ROOT / "workers/tree_models/sam2_occlusion.py",
        ROOT / "scripts/stem_eval_common.py",
        ROOT / "workers/tree_models/instance_metrics.py",
        ROOT / "workers/tree_models/research_protocol.py",
    ):
        (source / path.name).write_bytes(path.read_bytes())
        protocol["source_sha256"][str(path)] = sha256_file(path)
    write(args.output / "protocol.json", protocol)
    torch.manual_seed(20261108)
    torch.set_num_threads(4)
    base = (
        Sam2Model.from_pretrained(
            pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    payload = torch.load(INITIAL, map_location="cpu", weights_only=True)
    if (
        payload["protocol"]["manifest_sha256"]
        != "af2380f89a2cabe2369bec0d200e1d5303a40601428e4982e7d9c59b9b09c4b9"
    ):
        raise ValueError("unexpected real-visible initialization history")
    base.mask_decoder.load_state_dict(payload["sam2_mask_decoder"], strict=True)
    model = Sam2OcclusionModel(base).to(args.device)
    initial = copy.deepcopy(model.decoder.state_dict())
    results = {}
    for arm in protocol["arms"]:
        torch.manual_seed(20261108)
        model.decoder.load_state_dict(initial, strict=True)
        joint = arm == "coverage_identity"
        for parameter in model.parameters():
            parameter.requires_grad_(False)
        for name, parameter in model.decoder.named_parameters():
            unused = name.startswith(
                ("amodal", "visibility", "curve", "occluder", "stem", "router", "layer")
            )
            parameter.requires_grad_(not unused and (joint or not name.startswith("ownership")))
        optimizer = torch.optim.AdamW(
            [p for p in model.parameters() if p.requires_grad], lr=1e-5, weight_decay=1e-4
        )
        model.train()
        history = []
        for step, index in enumerate(order, 1):
            sample = train.sample(index)
            inputs, _ = tensors(sample, args.device)
            output = model(**inputs)
            loss, components = whole_tree_loss(
                output["masks"][0, :, 0],
                output["ownership_logits"][0],
                torch.from_numpy(sample["visible"]).to(args.device),
                torch.from_numpy(sample["whole_valid"]).to(args.device),
                joint=joint,
            )
            if not torch.isfinite(loss):
                raise ValueError("nonfinite whole-tree training loss")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.decoder.parameters(), 1.0)
            optimizer.step()
            history.append(
                {
                    "step": step,
                    "sample": sample["sample_id"],
                    "loss": float(loss.detach()),
                    **{k: float(v.detach()) for k, v in components.items()},
                }
            )
            if step % 25 == 0:
                print(json.dumps({"arm": arm, **history[-1]}), flush=True)
        write(args.output / f"{arm}-history.json", history)
        torch.save(
            {"decoder": model.decoder.state_dict(), "protocol": protocol, "arm": arm},
            args.output / f"{arm}-final.pth",
        )
        results[arm], _ = evaluate(
            model, datasets["validation"], args.device, args.output / arm, learned=joint
        )
        print(json.dumps({"arm": arm, "validation": results[arm]}), flush=True)
    reference = results["coverage"]["mask_winner"]["multi_scene"]
    candidate = results["coverage_identity"]["owner_winner"]["multi_scene"]
    independent = results["coverage"]["independent"]["multi_scene"]
    accepted = bool(
        reference["neighbour_fraction"] > 0.001
        and candidate["neighbour_fraction"] <= reference["neighbour_fraction"] * 0.9
        and candidate["iou"] >= reference["iou"]
        and candidate["recall"] >= reference["recall"] - 0.005
        and candidate["precision"] >= reference["precision"] - 0.005
        and candidate["iou"] >= independent["iou"]
        and candidate["recall"] >= independent["recall"] - 0.005
    )
    write(
        args.output / "results.json",
        {"arms": results, "acceptance_passed": accepted, "test_images_accessed": False},
    )
    print(json.dumps({"acceptance_passed": accepted}), flush=True)


if __name__ == "__main__":
    main()
