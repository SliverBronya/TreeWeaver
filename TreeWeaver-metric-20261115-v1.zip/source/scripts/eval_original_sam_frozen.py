"""Evaluate vanilla SAM2 box prompting on the frozen validation cohort."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model

ROOT = Path(r"D:\TreeWeaver")
INDEX = ROOT / "reports/data-qualification-2026-11-09/frozen/index.json"
OUT = ROOT / "reports/frozen-original-sam2-val-2026-11-09"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(path):
    image = Image.open(path).convert("RGB").resize((1024, 1024), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask_tensor(path):
    image = np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16
    image = Image.fromarray(image.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)
    return torch.from_numpy(np.asarray(image, dtype=np.float32) / 255.0)[None, None]


def boxes(row):
    x0, y0, x1, y1 = row["box_xyxy"]
    width, height = row["mask_wh"]
    return torch.tensor(
        [[[x0 * 1024 / width, y0 * 1024 / height, x1 * 1024 / width, y1 * 1024 / height]]]
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--single", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda")
    torch.cuda.set_per_process_memory_fraction(0.45)
    model = Sam2Model.from_pretrained(snapshot(), local_files_only=True).to(device).eval()
    index = json.loads(INDEX.read_text(encoding="utf-8"))
    rows = index["validation"]["records"]
    values = []
    records = []
    with torch.no_grad():
        for row in rows:
            output = model(
                pixel_values=image_tensor(row["paths"]["image"]).to(device),
                input_boxes=boxes(row).to(device),
                multimask_output=not args.single,
            )
            scores = output["iou_scores"][0, 0]
            best = 0 if args.single else int(scores.argmax())
            prediction = output["pred_masks"][0, 0, best].sigmoid() > 0.5
            target = mask_tensor(row["paths"]["visible"])[0, 0].to(device) > 0.5
            intersection = (prediction & target).sum().item()
            union = (prediction | target).sum().item()
            value = intersection / union if union else 1.0
            values.append(value)
            records.append(
                {
                    "scene": row["scene"],
                    "relation": row["relation"],
                    "hidden": row["hidden_fraction"],
                    "iou": value,
                    "chosen_multimask": best,
                    "iou_scores": [float(x) for x in scores],
                }
            )
    result = {
        "device": str(device),
        "validation_targets": len(rows),
        "mean_visible_iou": float(np.mean(values)),
        "median_visible_iou": float(np.median(values)),
        "records": records,
        "test_accessed": False,
        "multimask": not args.single,
    }
    name = "metrics-single.json" if args.single else "metrics.json"
    (OUT / name).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("validation_targets", "mean_visible_iou", "median_visible_iou")}, indent=2))


if __name__ == "__main__":
    main()
