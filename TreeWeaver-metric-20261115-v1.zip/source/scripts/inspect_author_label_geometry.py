"""Check actual author masks through upstream polygon generator without RGB."""

import json
import sys
from pathlib import Path


def main():
    root = Path("D:/TreeWeaver")
    sys.path.insert(0, str(root / ".worker-envs/convexmask-extra"))
    sys.path.insert(0, str(root / "data/external/convexmask-source"))
    import numpy as np
    from pycocotools.coco import COCO
    from utils.augmentations import GeneratePolygons

    labels = root / "data/external/synthtree43k/annotations/val_RGB_entire_tree.json"
    coco = COCO(str(labels))
    rows = []
    for image in list(coco.imgs.values())[:3]:
        annotations = coco.loadAnns(coco.getAnnIds(imgIds=image["id"]))
        masks = np.stack([coco.annToMask(annotation) for annotation in annotations])
        original = masks.copy()
        boxes = np.array([a["bbox"] for a in annotations], dtype=np.float32)
        _, output_masks, _, polygons, _, _ = GeneratePolygons()(
            np.zeros((image["height"], image["width"], 3), np.uint8),
            masks,
            boxes,
            None,
            {"num_crowds": 0, "labels": np.zeros(len(annotations))},
        )
        if not np.array_equal(output_masks, original):
            raise ValueError("Upstream polygon generation changed masks")
        if not np.isfinite(polygons).all():
            raise ValueError("Non-finite generated polygon")
        rows.append(
            {
                "image_id": image["id"],
                "filename": image["file_name"],
                "instances": len(annotations),
                "mask_shape": list(masks.shape),
                "polygon_shape": list(polygons.shape),
                "original_mask_unchanged": True,
            }
        )
    destination = root / "reports/synthtree-author-label-check-2026-10-14"
    destination.mkdir(parents=True, exist_ok=True)
    report = {
        "rows": rows,
        "rgb_used": False,
        "training_run": False,
        "actual_author_labels": True,
        "source_polygon_generator_used": True,
        "paper_reproduction_completed": False,
    }
    (destination / "run.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
