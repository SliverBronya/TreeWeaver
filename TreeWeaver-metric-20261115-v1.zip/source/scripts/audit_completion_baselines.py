"""Train-only GT baselines expose easy full-mask scores and leaf-gap hull errors."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from completion_metrics import completion_report  # noqa: E402
from paired_target_contract import paired_part_validity  # noqa: E402
from research_protocol import sha256_file  # noqa: E402


def mask(path):
    with Image.open(path) as image:
        return np.asarray(image.getchannel("A")) > 16


def hull(mask):
    result = np.zeros(mask.shape, np.uint8)
    ys, xs = np.nonzero(mask)
    if len(xs) >= 3:
        points = np.stack((xs, ys), -1).astype(np.int32)
        cv2.fillConvexPoly(result, cv2.convexHull(points), 1)
    else:
        result[ys, xs] = 1
    return result.astype(bool)


def main():
    cohorts = [
        "fig-paired-v6-framing-30-2026-11-08",
        "mixed-identity-layout-qualification-2026-11-08",
    ]
    report = {
        "scope": (
            "native TRAIN scene masks only; no controls, predictions, training, or weights"
        ),
        "full_target_source": "same-camera synthetic isolated support; no real amodal claim",
        "baselines": ["copy_GT_visible", "convex_hull_of_GT_visible", "GT_complete_upper_bound"],
        "query_selection": (
            "all train scene queries; report hidden>0 and hidden>=25px + fraction>=1% separately"
        ),
        "model_improvement": False,
        "test_accessed": False,
        "cohorts": {},
    }
    for name in cohorts:
        root = ROOT / "reports" / name
        manifest_path = root / "paired-samples.json"
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        rows = []
        for row in data["records"]:
            if row["split"] != "train" or row["condition"] != "scene":
                continue
            for q, item in enumerate(row["instances"]):
                complete = not item.get("frame_truncated", False) and item.get(
                    "amodal_supervision_allowed", True
                )
                for part in ("whole", "crown"):
                    suffix = "" if part == "whole" else "_crown"
                    visible, amodal = (
                        mask(root / item[key + suffix]) for key in ("visible", "amodal")
                    )
                    known = ~mask(root / item["raster_unknown"])
                    if part == "crown":
                        known &= ~mask(root / item["visible_part_unknown"])
                        known &= ~mask(root / item["amodal_part_unknown"])
                        known, conflict = paired_part_validity(
                            np.stack((mask(root / item["visible_stem"]), visible))[:, None],
                            np.stack((mask(root / item["amodal_stem"]), amodal))[:, None],
                            known[None],
                        )
                        known = known[0]
                        conflict_pixels = int(conflict.sum())
                    else:
                        conflict_pixels = 0
                    variants = {
                        "copy_GT_visible": visible,
                        "convex_hull_of_GT_visible": hull(visible),
                        "GT_complete_upper_bound": amodal,
                    }
                    for variant, prediction in variants.items():
                        metrics = completion_report(
                            prediction,
                            visible,
                            amodal,
                            visible,
                            known,
                            full_target_verified=complete,
                        )
                        rows.append(
                            {
                                "scene": row["id"],
                                "query": q + 1,
                                "part": part,
                                "baseline": variant,
                                "paired_part_conflict_ignored": conflict_pixels,
                                **metrics,
                            }
                        )
        summaries = {}
        for part in ("whole", "crown"):
            summaries[part] = {}
            for variant in report["baselines"]:
                selected = [
                    r
                    for r in rows
                    if r["part"] == part and r["baseline"] == variant and r["eligible"]
                ]
                summaries[part][variant] = {}
                for stratum in ("all", "any_hidden", "hidden_ge_25px_and_1pct"):
                    group = [
                        r
                        for r in selected
                        if stratum == "all"
                        or (stratum == "any_hidden" and r["hidden_area"] > 0)
                        or (
                            stratum == "hidden_ge_25px_and_1pct"
                            and r["hidden_area"] >= 25
                            and r["hidden_area"] / r["known_amodal_area"] >= 0.01
                        )
                    ]
                    summaries[part][variant][stratum] = {"queries": len(group)}
                    for metric in (
                        "amodal_iou",
                        "hidden_recall",
                        "hidden_iou_oracle_visible",
                        "outside_target_expansion_fraction",
                    ):
                        values = [r[metric] for r in group if r[metric] is not None]
                        summaries[part][variant][stratum][metric] = (
                            float(np.mean(values)) if values else None
                        )
        report["cohorts"][name] = {
            "manifest_sha256": sha256_file(manifest_path),
            "summary": summaries,
            "records": rows,
        }
        print(name, json.dumps(summaries["whole"]["copy_GT_visible"]))
    (ROOT / "reports/two-hour-development-2026-11-09/completion-baseline-audit.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
