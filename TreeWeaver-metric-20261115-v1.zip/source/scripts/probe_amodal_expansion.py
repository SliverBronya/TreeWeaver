"""Does the amodal head expand a real trunk mask onto its neighbours?

The amodal head is trained so that ``amodal = visible + softplus(delta)``: it can only
add area. On synthetic data that added area is the target's own occluded surface. On
real photos the added area may be somebody else's tree. This probe measures, per tree:

* visible IoU and amodal IoU against the trunk-only annotation;
* how much larger the amodal mask is than the visible mask;
* where the added pixels land: on the target's own GT, on another labelled trunk, or
  on unlabelled background.

No weights are updated.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))
sys.path.insert(0, str(ROOT / "scripts"))
from probe_canatree_adhesion import REVISION, decode_image, load_fold  # noqa: E402
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from stem_eval_common import mean_of, write_json  # noqa: E402


def iou(prediction, target):
    union = np.logical_or(prediction, target).sum()
    return float(np.logical_and(prediction, target).sum() / union) if union else 0.0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--split", default="val")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    by_image, grouped, fold_path = load_fold(args.split)
    protocol = {
        "schema_version": "treeweaver-amodal-expansion-1.0",
        "question": "does the amodal head add area onto neighbouring trunks in real photos?",
        "checkpoint": str(args.checkpoint),
        "checkpoint_sha256": sha256_file(args.checkpoint),
        "sam_revision": REVISION,
        "split": args.split,
        "fold_file_sha256": sha256_file(fold_path),
        "frozen": "no weight update; GT-derived box prompts; mask logit > 0",
        "limitations": [
            "trunk annotations are visible-only and non-exhaustive",
            "unlabelled background trunks are counted as background, not neighbours",
            "development split, not video-disjoint",
        ],
    }
    write_json(args.output / "protocol.json", protocol)

    snapshot = pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION)
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(snapshot, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device)
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    report = model.decoder.load_state_dict(payload["decoder"], strict=False)
    missing = [
        key for key in report.missing_keys if not key.startswith(("stem_token.", "stem_hypernet."))
    ]
    if missing or report.unexpected_keys:
        raise ValueError(f"checkpoint mismatch: {missing} {report.unexpected_keys}")
    model.eval()

    rows = []
    for image_id, image in by_image.items():
        image_bgr, boxes, masks, height, width = decode_image(image, grouped[image_id])
        pixels = processor(
            images=Image.fromarray(np.asarray(image_bgr)[:, :, ::-1].copy()), return_tensors="pt"
        )["pixel_values"].to(args.device)
        scale = np.asarray([1024 / width, 1024 / height] * 2, np.float32)
        with torch.inference_mode():
            output = model(
                pixel_values=pixels,
                input_boxes=torch.as_tensor(boxes * scale, device=args.device)[None],
                multimask_output=False,
            )
        for name in ("masks", "amodal_masks"):
            logits = output[name][0, :, 0]
            upscaled = F.interpolate(
                logits[:, None], (height, width), mode="bilinear", align_corners=False
            )[:, 0]
            output[name] = (upscaled > 0).cpu().numpy()
        for index in range(len(masks)):
            visible = output["masks"][index]
            amodal = output["amodal_masks"][index]
            added = amodal & ~visible
            others = np.zeros_like(visible)
            for other in range(len(masks)):
                if other != index:
                    others |= masks[other]
            rows.append(
                {
                    "image": image["file_name"],
                    "tree_index": index,
                    "visible_iou": iou(visible, masks[index]),
                    "amodal_iou": iou(amodal, masks[index]),
                    "visible_pixels": int(visible.sum()),
                    "amodal_pixels": int(amodal.sum()),
                    "added_pixels": int(added.sum()),
                    "added_on_target_gt": int((added & masks[index]).sum()),
                    "added_on_other_trunk": int((added & others).sum()),
                    "added_on_background": int((added & ~masks[index] & ~others).sum()),
                }
            )

    def share(key):
        added = sum(row["added_pixels"] for row in rows)
        return sum(row[key] for row in rows) / added if added else 0.0

    summary = {
        "trees": len(rows),
        "mean_visible_iou": mean_of(rows, "visible_iou"),
        "mean_amodal_iou": mean_of(rows, "amodal_iou"),
        "amodal_over_visible_area": sum(row["amodal_pixels"] for row in rows)
        / max(sum(row["visible_pixels"] for row in rows), 1),
        "added_share_on_target_gt": share("added_on_target_gt"),
        "added_share_on_other_trunk": share("added_on_other_trunk"),
        "added_share_on_background": share("added_on_background"),
        "trees_with_any_added_area": sum(1 for row in rows if row["added_pixels"]),
        "protocol_sha256": sha256_file(args.output / "protocol.json"),
        "limitations": protocol["limitations"],
    }
    write_json(args.output / "per_tree.json", rows)
    write_json(args.output / "summary.json", summary)
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
