"""Whole-tree annotations straight from _mask.png (aligned at (0,0), crowns included).

The CSV supplies only WHICH colours are trees in a frame (treeMaskColor); its
boxes are never used, so the known bbox/pairing problems cannot leak in.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from PIL import Image

EXTRA = Path(r"D:\TreeWeaver\.worker-envs\convexmask-extra")
if EXTRA.is_dir() and str(EXTRA) not in sys.path:
    sys.path.insert(0, str(EXTRA))
from pycocotools import mask as mask_utils  # noqa: E402

ROOT = Path(r"D:\TreeWeaver\data\external\synthtree43k\test_set")
ANNOT = Path(r"D:\TreeWeaver\data\external\synthtree43k\annotations")
OUT = Path(r"D:\TreeWeaver\data\processed\synthtree43k-whole-2026-10-20")
OUT.mkdir(parents=True, exist_ok=True)
MIN_AREA = 200
WORKERS = 6


def split_membership():
    out = {}
    for split in ("train", "val", "test"):
        with (ANNOT / f"{split}_RGB_entire_tree.json").open(encoding="utf-8") as fh:
            data = json.load(fh)
        out[split] = {str(im["file_name"]).split("_")[0] for im in data.get("images", []) if "file_name" in im}
        print(f"{split}: {len(out[split])} images", flush=True)
        del data
    return out


print("reading splits...", flush=True)
splits = split_membership()
stem_to_split = {s: k for k, v in splits.items() for s in v}
del splits

rows = [
    {k.strip(): v for k, v in r.items()}
    for r in csv.DictReader((ROOT / "AllLabels.csv").open(newline="", encoding="utf-8"))
]
colours_by_image: dict[str, set[int]] = defaultdict(set)
meta_by_image: dict[str, dict[int, dict]] = defaultdict(dict)
for r in rows:
    key = (int(r["treeMaskColor_r"]) << 16) | (int(r["treeMaskColor_g"]) << 8) | int(r["treeMaskColor_b"])
    colours_by_image[r["image_id"]].add(key)
    meta_by_image[r["image_id"]][key] = {
        "diameter": float(r["Tree_diameter"]),
        "visibility": float(r["Tree_visibility"]),
    }
targets = [i for i in sorted(colours_by_image) if i in stem_to_split]
print(f"images to process: {len(targets)}   colours total: {sum(len(v) for v in colours_by_image.values())}", flush=True)


def process(image_id: str):
    p = ROOT / f"{image_id}_mask.png"
    if not p.is_file():
        return None
    m = np.array(Image.open(p).convert("RGB"))
    h, w = m.shape[:2]
    packed = (m[:, :, 0].astype(np.int32) << 16) | (m[:, :, 1].astype(np.int32) << 8) | m[:, :, 2].astype(np.int32)
    del m
    items = []
    for key in colours_by_image[image_id]:
        hit = packed == key
        area = int(hit.sum())
        if area < MIN_AREA:
            continue
        rle = mask_utils.encode(np.asfortranarray(hit.astype(np.uint8)))
        rle["counts"] = rle["counts"].decode("ascii")
        ys, xs = np.nonzero(hit)
        items.append(
            {
                "segmentation": rle,
                "area": area,
                "bbox": [float(xs.min()), float(ys.min()),
                         float(xs.max() - xs.min() + 1), float(ys.max() - ys.min() + 1)],
                **meta_by_image[image_id][key],
            }
        )
    return image_id, h, w, items


coco = {
    s: {"info": {"description": f"SynthTree43k whole tree ({s}), from _mask.png"},
        "licenses": [], "categories": [{"id": 0, "name": "tree"}],
        "images": [], "annotations": []}
    for s in ("train", "val", "test")
}
ann_id = 0
done = 0
with ThreadPoolExecutor(max_workers=WORKERS) as pool:
    for res in pool.map(process, targets, chunksize=32):
        done += 1
        if res is None:
            continue
        image_id, h, w, items = res
        if not items:
            continue
        split = stem_to_split[image_id]
        pk = int(image_id)
        coco[split]["images"].append({"id": pk, "file_name": f"{image_id}_img.png", "width": w, "height": h})
        for it in items:
            ann_id += 1
            coco[split]["annotations"].append({"id": ann_id, "image_id": pk, "category_id": 0, "iscrowd": 0, **it})
        if done % 4000 == 0:
            print(f"  {done}/{len(targets)} images, {ann_id} instances", flush=True)

for split, payload in coco.items():
    path = OUT / f"{split}_whole.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    print(f"{split:>5}: {len(payload['images']):6d} images  {len(payload['annotations']):7d} instances  "
          f"{path.stat().st_size/1048576:.0f} MB")
