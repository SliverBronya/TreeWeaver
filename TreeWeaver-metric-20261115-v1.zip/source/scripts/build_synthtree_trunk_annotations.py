"""Build trunk-level SynthTree43k annotations from AllLabels.csv + _mask.png.

Rule (reconstructed from the paper, not the authors' code):
    trunk_mask = flipud(_mask.png == treeMaskColor)  AND  inside(4-corner trunk box)

The vertical flip is required: as stored, the mask is upside down relative to
_img.png, which drops the trunk-box overlap from 22% to 0.4%.

Output: a COCO-style JSON with RLE masks + trunk boxes + 5 keypoints, plus a
contact sheet for eyeball verification.
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

# pycocotools lives in the ConvexMask extra-packages env, not in the sam2 env
EXTRA = Path(r"D:\TreeWeaver\.worker-envs\convexmask-extra")
if EXTRA.is_dir() and str(EXTRA) not in sys.path:
    sys.path.insert(0, str(EXTRA))
from pycocotools import mask as mask_utils  # noqa: E402

ROOT = Path(r"D:\TreeWeaver\data\external\synthtree43k\test_set")
OUT = Path(r"D:\TreeWeaver\data\processed\synthtree43k-trunk-sample-2026-10-19")
OUT.mkdir(parents=True, exist_ok=True)

N_IMAGES = 10
MIN_TRUNK_PX = 60

all_rows = [
    {k.strip(): v for k, v in r.items()}
    for r in csv.DictReader((ROOT / "AllLabels.csv").open(newline="", encoding="utf-8"))
]
by_image: dict[str, list[dict]] = {}
for row in all_rows:
    by_image.setdefault(row["image_id"], []).append(row)

# pick the first N images that actually have a mask file and a few trees
chosen = [
    img
    for img in sorted(by_image)
    if (ROOT / f"{img}_mask.png").is_file() and 2 <= len(by_image[img]) <= 6
][:N_IMAGES]

coco = {"info": {"description": "SynthTree43k trunk-level, reconstructed 2026-10-19"},
        "licenses": [], "categories": [{"id": 1, "name": "tree_trunk"}],
        "images": [], "annotations": []}
ann_id = 0
panels = []
stats = []

for image_id in chosen:
    rgb = np.array(Image.open(ROOT / f"{image_id}_img.png").convert("RGB"))
    mask = np.flipud(np.array(Image.open(ROOT / f"{image_id}_mask.png").convert("RGB")))
    h, w = mask.shape[:2]
    image_pk = int(image_id)
    coco["images"].append({"id": image_pk, "file_name": f"{image_id}_img.png",
                           "width": w, "height": h})

    vis = rgb.copy()
    kept = 0
    for row in by_image[image_id]:
        colour = np.array([int(row["treeMaskColor_r"]), int(row["treeMaskColor_g"]),
                           int(row["treeMaskColor_b"])])
        hit = np.all(mask == colour, axis=-1)
        quad = np.array(
            [
                [float(row["BBox_top_lx"]), float(row["BBox_top_ly"])],
                [float(row["BBox_top_rx"]), float(row["BBox_top_ry"])],
                [float(row["BBox_bot_rx"]), float(row["BBox_bot_ry"])],
                [float(row["BBox_bot_lx"]), float(row["BBox_bot_ly"])],
            ],
            np.int32,
        )
        qm = np.zeros((h, w), np.uint8)
        cv2.fillPoly(qm, [quad], 1)
        trunk = hit & (qm > 0)
        area = int(trunk.sum())
        if area < MIN_TRUNK_PX:
            continue
        kept += 1
        rle = mask_utils.encode(np.asfortranarray(trunk.astype(np.uint8)))
        rle["counts"] = rle["counts"].decode("ascii")
        ys, xs = np.nonzero(trunk)
        keypoints = []
        for k in range(6):
            kx = float(row[f"Keypoint_{k:02d}_x"])
            ky = float(row[f"Keypoint_{k:02d}_y"])
            keypoints += [kx, ky, 2]
        ann_id += 1
        coco["annotations"].append(
            {
                "id": ann_id,
                "image_id": image_pk,
                "category_id": 1,
                "segmentation": rle,
                "area": area,
                "bbox": [float(xs.min()), float(ys.min()),
                         float(xs.max() - xs.min() + 1), float(ys.max() - ys.min() + 1)],
                "iscrowd": 0,
                "trunk_quad": quad.tolist(),
                "keypoints": keypoints,
                "num_keypoints": 6,
                "tree_visibility": float(row["Tree_visibility"]),
                "tree_diameter_m_at_10cm": float(row["Tree_diameter"]),
                "mask_source": "flipud(_mask.png) & trunk_quad",
            }
        )
        overlay = vis.copy()
        overlay[trunk] = (255, 40, 40)
        vis = cv2.addWeighted(vis, 0.45, overlay, 0.55, 0)
        cv2.polylines(vis, [quad], True, (0, 255, 0), 2)

    stats.append((image_id, len(by_image[image_id]), kept))
    panels.append(cv2.cvtColor(cv2.resize(vis, (426, 240)), cv2.COLOR_RGB2BGR))

coco_path = OUT / "sample_10_trunk.json"
coco_path.write_text(json.dumps(coco), encoding="utf-8")

while len(panels) % 5:
    panels.append(np.zeros_like(panels[0]))
rows = [np.hstack(panels[i:i + 5]) for i in range(0, len(panels), 5)]
sheet = np.vstack(rows)
sheet_path = OUT / "contact_sheet.png"
cv2.imwrite(str(sheet_path), sheet)

print(f"images: {len(coco['images'])}   annotations kept: {len(coco['annotations'])}")
print(f"{'image':>8}  {'csv rows':>8}  {'kept':>5}")
for image_id, total, kept in stats:
    print(f"{image_id:>8}  {total:>8}  {kept:>5}")
areas = [a["area"] for a in coco["annotations"]]
print(f"\ntrunk area px: min {min(areas)}  median {int(np.median(areas))}  max {max(areas)}")
print(f"diameters (m @10cm): {sorted({round(a['tree_diameter_m_at_10cm'],3) for a in coco['annotations']})[:8]}")
print(f"wrote {coco_path}\nwrote {sheet_path}")
