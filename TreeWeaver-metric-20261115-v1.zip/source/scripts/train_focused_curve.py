"""Train the crown-curve head on the target-centric cohort (proxy curve)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from curve_consistency import soft_width_profile  # noqa: E402
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
BASE = ROOT / "reports/professional-stage6-curve-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-curve-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def sample(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = mask(DATA / row["scene"] / "visible_target.png")
    amodal = mask(DATA / row["scene"] / "amodal_target.png")
    ys, xs = np.where(visible)
    box = np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32)
    box = lb.boxes(box)
    am = torch.from_numpy(amodal.astype(np.float32))[None, None]
    am = F.interpolate(am, size=(256, 256), mode="nearest")
    curve = soft_width_profile(am, 12)
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        curve,
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base).cuda()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)["decoder"]
    own = model.decoder.state_dict()
    model.decoder.load_state_dict({k: v for k, v in payload.items() if k in own and v.shape == own[k].shape}, strict=False)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.startswith(("decoder.curve_", "decoder.curve_token")):
            parameter.requires_grad_(True)
    return model


def evaluate(model, rows):
    model.eval()
    values = []
    with torch.no_grad():
        for row in rows:
            image, box, curve = sample(row)
            output = model(image.cuda(), input_boxes=box.cuda())
            pred = output["curve"][0, 0].cpu()
            values.append(F.l1_loss(pred, curve[0, 0]).item())
    return float(np.mean(values))


def main():
    OUT.mkdir(exist_ok=True)
    rows = json.loads((DATA / "index.json").read_text())
    train = [r for r in rows if r["split"] == "train"]
    val = [r for r in rows if r["split"] == "validation"]
    model = build()
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(json.dumps({"train": len(train), "val": len(val), "trainable": sum(p.numel() for p in parameters)}), flush=True)
    before = evaluate(model, val)
    print(json.dumps({"before_curve_mae": before}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=2e-4, weight_decay=1e-4)
    model.train()
    history = []
    for step in range(1, 301):
        row = train[(step - 1) % len(train)]
        image, box, curve = sample(row)
        optimizer.zero_grad(set_to_none=True)
        output = model(image.cuda(), input_boxes=box.cuda())
        loss = F.smooth_l1_loss(output["curve"][:, 0], curve.cuda()[:, 0])
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        history.append(float(loss.detach()))
        if step % 25 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 50 == 0 or step == 300:
            print(json.dumps({"eval_step": step, "curve_mae": evaluate(model, val)}), flush=True)
            torch.save({"state": {k: v.detach().cpu() for k, v in model.named_parameters() if v.requires_grad}}, OUT / "checkpoint.pth")
    after = evaluate(model, val)
    result = {"before_curve_mae": before, "after_curve_mae": after, "train": len(train), "val": len(val), "loss_start": history[0], "loss_end": history[-1]}
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
