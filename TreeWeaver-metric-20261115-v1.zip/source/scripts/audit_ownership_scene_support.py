"""Read-only effective identity supervision audit with one frozen visible prior."""

from __future__ import annotations

import sys

import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, PairedFigDataset, tensors, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import pinned_snapshot  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def main():
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = Sam2OcclusionModel(base).to(device).eval()
    prior = ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth"
    model.decoder.load_state_dict(
        torch.load(prior, map_location="cpu", weights_only=True)["decoder"], strict=True
    )
    rows = []
    with torch.no_grad():
        for name in (
            "fig-paired-v6-framing-30-2026-11-08",
            "mixed-tree-grounded-qualification-2026-11-08",
            "dense-mixed-portrait-qualification-2026-11-08",
        ):
            dataset = PairedFigDataset(ROOT / "reports" / name, "train")
            for i, record in enumerate(dataset.items):
                if record["condition"] != "scene":
                    continue
                sample = dataset.sample(i)
                inputs, _ = tensors(sample, device)
                result = model(**inputs)
                target = np.stack([dataset._native_mask(x["visible"]) for x in record["instances"]])
                valid = ~np.stack(
                    [dataset._native_mask(x["raster_unknown"]) for x in record["instances"]]
                ).any(0)
                if (target.sum(0)[valid] > 1).any():
                    raise ValueError("visible IDs overlap on known pixels")
                raw = (
                    F.interpolate(
                        result["masks"][0], size=valid.shape, mode="bilinear", align_corners=False
                    )[:, 0]
                    .cpu()
                    .numpy()
                )
                active = raw > 0
                fg = target.any(0) & valid
                correct_active = (active & target).any(0)
                recoverable = fg & correct_active & (active.sum(0) > 1)
                winner = raw.argmax(0)
                correct = target.argmax(0)
                rows.append(
                    {
                        "dataset": name,
                        "scene": record["id"],
                        "trees": len(target),
                        "native_mask_wh": list(reversed(valid.shape)),
                        "known_visible_tree_pixels": int(fg.sum()),
                        "recoverable_dispute_pixels": int(recoverable.sum()),
                        "recoverable_fraction": float(recoverable.sum() / max(fg.sum(), 1)),
                        "correct_query_missed_pixels": int((fg & ~correct_active).sum()),
                        "winner_wrong_pixels": int(
                            (fg & active.any(0) & (winner != correct)).sum()
                        ),
                        "predicted_background_false_pixels": int(
                            (valid & ~fg & active.any(0)).sum()
                        ),
                    }
                )
    summary = {}
    for name in dict.fromkeys(r["dataset"] for r in rows):
        selected = [r for r in rows if r["dataset"] == name]
        summary[name] = {
            "scenes": len(selected),
            "scenes_with_recoverable_disputes": sum(
                r["recoverable_dispute_pixels"] > 0 for r in selected
            ),
            "recoverable_fraction_of_known_visible_pixels": sum(
                r["recoverable_dispute_pixels"] for r in selected
            )
            / max(sum(r["known_visible_tree_pixels"] for r in selected), 1),
        }
    destination = ROOT / "reports/ownership-effective-support-2026-11-08.json"
    write(
        destination,
        {
            "purpose": "data qualification only; frozen model, no training",
            "summary": summary,
            "records": rows,
            "different_native_pixel_counts_not_directly_comparable": True,
            "oracle_prompts": True,
            "test_accessed": False,
        },
    )
    print(summary)


if __name__ == "__main__":
    main()
