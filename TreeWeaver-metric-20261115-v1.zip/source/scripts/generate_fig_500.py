"""Generate 500 fig-tree composites with 2/3/4 overlapping trees.

Outputs:
  images/000001.png
  masks/000001/amodal_1..k.png
  masks/000001/visible_1..k.png
  masks/000001/ownership.png
  meta/000001.json

The output directory must be new. Run with FIG_LIMIT=2 for a smoke test.
FIG_PLAN may name a frozen generation_plan.json prepared before rendering.
Visible labels are full-scene target-ID renders preserving material alpha;
they are never reconstructed by subtracting globally ranked tree silhouettes.
"""

from __future__ import annotations

import json
import math
import os
import random
import sys
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fig_data_protocol import (
    GENERATOR_SCHEMA,
    SPLIT_SCHEMA,
    crown_layout_centers,
    layout_orders,
    make_generation_plan,
    material_part,
    ownership_from_coverage,
    paired_support_masks,
    partition_part_coverage,
    separated_depths,
    sha256_file,
    validate_plan,
)

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
OUT = Path(os.environ.get("FIG_OUT", r"D:\TreeWeaver\reports\fig-asset-split-v3-2026-11-01"))
LIMIT = int(os.environ.get("FIG_LIMIT", "0"))
SEED = int(os.environ.get("FIG_SEED", "20261101"))
PLAN = os.environ.get("FIG_PLAN")
SELECTED_IDS = os.environ.get("FIG_IDS")
OVERLAP_MIN = float(os.environ.get("FIG_OVERLAP_MIN", "0"))
OVERLAP_MAX = float(os.environ.get("FIG_OVERLAP_MAX", "0"))
RES_X, RES_Y = int(os.environ.get("FIG_RES_X", "1280")), int(os.environ.get("FIG_RES_Y", "720"))
MASK_X, MASK_Y = int(os.environ.get("FIG_MASK_X", "640")), int(os.environ.get("FIG_MASK_Y", "360"))
HEIGHT = 10.0
PAIRED = os.environ.get("FIG_PAIRED") == "1"


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.eevee.taa_render_samples = 16
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.2


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts),
        max(p.x for p in pts),
        min(p.y for p in pts),
        max(p.y for p in pts),
        min(p.z for p in pts),
        max(p.z for p in pts),
    )


def load_tree(path, source_meshes=None):
    before = set(bpy.data.objects)
    if path.suffix.lower() == ".blend":
        if not source_meshes or len(source_meshes) != len(set(source_meshes)):
            raise ValueError("native asset requires explicit unique source mesh names")
        with bpy.data.libraries.load(str(path), link=False) as (available, requested):
            if not set(source_meshes) <= set(available.objects):
                raise ValueError("native asset meshes missing")
            requested.objects = list(source_meshes)
        for obj in requested.objects:
            if obj.type != "MESH" or not obj.data.polygons:
                raise ValueError("native selected object must be a nonempty mesh")
            bpy.context.collection.objects.link(obj)
    else:
        bpy.ops.import_scene.gltf(filepath=str(path))
    # Native libraries can also append dependency objects (parents/colliders).
    # Only explicitly selected meshes belong to this tree identity.
    new = (
        list(requested.objects)
        if path.suffix.lower() == ".blend"
        else [obj for obj in bpy.data.objects if obj not in before]
    )
    meshes = [
        obj for obj in new if obj.type == "MESH" and obj.name not in {"Cube", "Camera", "Light"}
    ]
    if not meshes:
        raise RuntimeError(f"no meshes in {path}")
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(tree)
    scale = HEIGHT / max(z1 - z0, 1e-6)
    tree.scale = tuple(v * scale for v in tree.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(tree)
    tree.location.x -= (x0 + x1) / 2
    tree.location.y -= (y0 + y1) / 2
    tree.location.z -= z0
    bpy.context.view_layer.update()
    tree.hide_render = True
    return tree


def ground():
    bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (150, 150, 150)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)
    return obj


def world():
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / "autumn_field_puresky_2k.hdr"))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, math.radians(35))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.0
    bpy.context.scene.world = w


def camera_for(center_x, span, lens, height, object_height=HEIGHT):
    hfov = 2 * math.atan(18 / lens)
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = max(
        span / (2 * math.tan(hfov / 2)) * 1.08,
        (object_height * 1.12) / (2 * math.tan(vfov / 2)),
    )
    bpy.ops.object.camera_add(location=(center_x, -distance, height))
    cam = bpy.context.object
    cam.data.type = "PERSP"
    cam.data.lens = lens
    cam.data.sensor_width = 36
    look = Vector((center_x, 0, object_height / 2))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam
    return cam


def fit_projected_bounds(camera, trees, margin=0.04):
    """Fit every transformed tree corner in the actual perspective camera.

    World-space width/height estimates miss asymmetric crowns and perspective
    shifts at different depths. Move along the optical axis without changing
    focal length or the subsequent scene/control camera relationship.
    """
    from bpy_extras.object_utils import world_to_camera_view

    scene = bpy.context.scene
    corners = [tree.matrix_world @ Vector(corner) for tree in trees for corner in tree.bound_box]
    backward = camera.rotation_euler.to_matrix() @ Vector((0, 0, 1))
    step = max(1.0, camera.location.length * 0.08)
    for iteration in range(100):
        bpy.context.view_layer.update()
        points = [world_to_camera_view(scene, camera, point) for point in corners]
        inside = all(
            point.z > 0 and margin <= point.x <= 1 - margin and margin <= point.y <= 1 - margin
            for point in points
        )
        if inside:
            return {
                "profile": "projected-bounds-margin-v1",
                "margin": margin,
                "backward_steps": iteration,
                "projected_xy_bounds": [
                    min(point.x for point in points),
                    min(point.y for point in points),
                    max(point.x for point in points),
                    max(point.y for point in points),
                ],
            }
        camera.location += backward * step
    raise ValueError("could not fit complete tree bounds in the camera")


def fit_ground_camera_bounds(camera, trees, margin=0.04):
    """Fit the scene while keeping the observer above ground at fixed height."""
    from bpy_extras.object_utils import world_to_camera_view

    corners = [tree.matrix_world @ Vector(corner) for tree in trees for corner in tree.bound_box]
    target = Vector(
        tuple(
            (min(p[axis] for p in corners) + max(p[axis] for p in corners)) / 2 for axis in range(3)
        )
    )
    observer_height = camera.location.z
    if observer_height <= 0:
        raise ValueError("ground camera height must be positive")
    for iteration in range(100):
        camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()
        bpy.context.view_layer.update()
        points = [world_to_camera_view(bpy.context.scene, camera, point) for point in corners]
        if all(
            p.z > 0 and margin <= p.x <= 1 - margin and margin <= p.y <= 1 - margin for p in points
        ):
            return {
                "profile": "projected-ground-bounds-v2",
                "margin": margin,
                "backward_steps": iteration,
                "camera_height": observer_height,
                "projected_xy_bounds": [
                    min(p.x for p in points),
                    min(p.y for p in points),
                    max(p.x for p in points),
                    max(p.y for p in points),
                ],
            }
        camera.location.x = target.x + (camera.location.x - target.x) * 1.08
        camera.location.y = target.y + (camera.location.y - target.y) * 1.08
        camera.location.z = observer_height
    raise ValueError("could not fit tree bounds with an above-ground camera")


def id_material(source, value):
    """Replace surface colour only; preserve the imported alpha graph/settings."""
    material = source.copy()
    material.name = f"id_{value}_{source.name}"
    material.use_nodes = True
    nodes, links = material.node_tree.nodes, material.node_tree.links
    output = next(
        node for node in nodes if node.type == "OUTPUT_MATERIAL" and node.is_active_output
    )
    principled = [node for node in nodes if node.type == "BSDF_PRINCIPLED"]
    if len(principled) != 1:
        raise ValueError(f"ID renderer requires one Principled alpha source: {source.name}")
    alpha = principled[0].inputs["Alpha"]
    alpha_link = alpha.links[0].from_socket if alpha.is_linked else None
    alpha_value = alpha.default_value
    for link in list(output.inputs["Surface"].links):
        links.remove(link)
    emission = nodes.new("ShaderNodeEmission")
    emission.inputs["Color"].default_value = (value, value, value, 1)
    emission.inputs["Strength"].default_value = 1
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    mix = nodes.new("ShaderNodeMixShader")
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(emission.outputs[0], mix.inputs[2])
    if alpha_link is not None:
        links.new(alpha_link, mix.inputs[0])
    else:
        mix.inputs[0].default_value = alpha_value
    links.new(mix.outputs[0], output.inputs["Surface"])
    return material


def read_coverage(path):
    image = bpy.data.images.load(str(path), check_existing=False)
    width, height = image.size
    rgba = np.asarray(image.pixels[:], dtype=np.float32).reshape(height, width, 4)
    # Blender PNG pixels have unassociated RGB. Premultiply to measure target
    # contribution at transparent sky/leaf edges, rather than count white RGB
    # with zero or fractional alpha as fully covered pixels.
    coverage = np.clip(rgba[..., 0] * rgba[..., 3], 0, 1)
    bpy.data.images.remove(image)
    return coverage


def save_mask(path, mask):
    height, width = mask.shape
    image = bpy.data.images.new(path.stem, width=width, height=height, alpha=True)
    rgba = np.zeros((height, width, 4), dtype=np.float32)
    rgba[mask] = (1, 1, 1, 1)
    image.pixels.foreach_set(rgba.ravel())
    image.file_format = "PNG"
    image.filepath_raw = str(path)
    image.save()
    bpy.data.images.remove(image)


def write_masks(image_id, trees, order, ground_obj):
    mask_dir = OUT / "masks" / f"{image_id:06d}"
    mask_dir.mkdir(parents=True, exist_ok=False)
    scene = bpy.context.scene
    old_resolution = (scene.render.resolution_x, scene.render.resolution_y)
    old_mode = scene.render.image_settings.color_mode
    old_view = (
        scene.view_settings.view_transform,
        scene.view_settings.look,
        scene.view_settings.exposure,
        scene.view_settings.gamma,
    )
    original_materials = {obj: list(obj.data.materials) for obj in [*trees, ground_obj]}
    id_materials = {}
    for materials in original_materials.values():
        for material in materials:
            if material is not None and material not in id_materials:
                id_materials[material] = (id_material(material, 0), id_material(material, 1))
    old_background = scene.world.node_tree.nodes.get("Background").inputs["Strength"].default_value
    coverages, amodal, isolated_coverages = [], [], []
    part_coverages = {mode: [] for mode in ("visible", "amodal")}

    def render_parts(target, index, mode):
        values = []
        for part in ("stem", "crown_surface"):
            for slot, material in enumerate(original_materials[target]):
                if material is not None:
                    target.data.materials[slot] = id_materials[material][
                        int(material_part(material.name) == part)
                    ]
            output = mask_dir / f"{mode}_{part}_coverage_{index + 1}.png"
            scene.render.filepath = str(output)
            bpy.ops.render.render(write_still=True)
            values.append(read_coverage(output))
        return values

    try:
        scene.render.resolution_x, scene.render.resolution_y = MASK_X, MASK_Y
        scene.render.film_transparent = True
        scene.render.image_settings.color_mode = "RGBA"
        scene.view_settings.view_transform = "Standard"
        scene.view_settings.look = "None"
        scene.view_settings.exposure = 0
        scene.view_settings.gamma = 1
        scene.world.node_tree.nodes.get("Background").inputs["Strength"].default_value = 0
        for index, target in enumerate(trees):
            # Every other object remains in the *full scene*. Black ID shading
            # occludes white target shading through the same alpha textures.
            for obj, materials in original_materials.items():
                obj.hide_render = False
                for slot, material in enumerate(materials):
                    if material is not None:
                        obj.data.materials[slot] = id_materials[material][int(obj is target)]
            full_path = mask_dir / f"visible_coverage_{index + 1}.png"
            scene.render.filepath = str(full_path)
            bpy.ops.render.render(write_still=True)
            coverages.append(read_coverage(full_path))
            if PAIRED:
                part_coverages["visible"].append(render_parts(target, index, "visible"))
            for obj in [*trees, ground_obj]:
                obj.hide_render = obj is not target and (not PAIRED or obj is not ground_obj)
            for slot, material in enumerate(original_materials[target]):
                if material is not None:
                    target.data.materials[slot] = id_materials[material][1]
            isolated_path = mask_dir / f"amodal_coverage_{index + 1}.png"
            scene.render.filepath = str(isolated_path)
            bpy.ops.render.render(write_still=True)
            # Conservative isolated alpha support includes fractional fringes;
            # visible IDs below use majority coverage. Record both thresholds.
            isolated = read_coverage(isolated_path)
            isolated_coverages.append(isolated)
            amodal.append(isolated >= 1 / 16)
            if PAIRED:
                part_coverages["amodal"].append(render_parts(target, index, "amodal"))
        ownership = ownership_from_coverage(coverages)
        diagnostics = []
        for index, mask in enumerate(amodal):
            visible = ownership == index + 1
            if PAIRED:
                visible, mask, unknown = paired_support_masks(
                    visible,
                    coverages[index],
                    isolated_coverages[index],
                    single_tree=len(trees) == 1,
                )
                amodal[index] = mask
                save_mask(mask_dir / f"raster_unknown_{index + 1}.png", unknown)
            outside = int((visible & ~mask).sum())
            diagnostics.append({"tree": index + 1, "visible_outside_amodal_px": outside})
            if outside:
                raise ValueError(
                    f"target-ID consistency failed for tree {index + 1}: {outside} pixels"
                )
            save_mask(mask_dir / f"amodal_{index + 1}.png", mask)
            save_mask(mask_dir / f"visible_{index + 1}.png", visible)
            if PAIRED:
                for mode, support in (("visible", visible), ("amodal", mask)):
                    partitions = partition_part_coverage(support, *part_coverages[mode][index])
                    for part, labels in zip(
                        ("stem", "crown_surface", "part_unknown"), partitions, strict=True
                    ):
                        save_mask(mask_dir / f"{mode}_{part}_{index + 1}.png", labels)
                save_mask(mask_dir / f"hidden_{index + 1}.png", mask & ~visible)
        (mask_dir / "label_checks.json").write_text(
            json.dumps(
                {
                    "source": "full-scene-target-id-alpha-preserved",
                    "visible_coverage_threshold": 0.5,
                    "amodal_coverage_threshold": 0.5 if PAIRED else 1 / 16,
                    "alpha_rasterization": (
                        "same majority threshold; uncertainty ignored; same ground in both views"
                        if PAIRED
                        else "majority-visible ID; conservative isolated alpha support"
                    ),
                    "ownership_conflict_resolution": "maximum full-scene target contribution",
                    "trees": diagnostics,
                    "visible_pair_overlap_px": 0,
                    "mask_resolution": [MASK_X, MASK_Y],
                    "part_semantics": (
                        "source bark material vs other crown surfaces; not crown envelope"
                    )
                    if PAIRED
                    else None,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
    finally:
        for obj, materials in original_materials.items():
            obj.hide_render = False
            for slot, material in enumerate(materials):
                obj.data.materials[slot] = material
        scene.render.resolution_x, scene.render.resolution_y = old_resolution
        scene.render.film_transparent = False
        scene.render.image_settings.color_mode = old_mode
        scene.view_settings.view_transform = old_view[0]
        scene.view_settings.look = old_view[1]
        scene.view_settings.exposure = old_view[2]
        scene.view_settings.gamma = old_view[3]
        scene.world.node_tree.nodes.get("Background").inputs[
            "Strength"
        ].default_value = old_background
        for pair in id_materials.values():
            for material in pair:
                bpy.data.materials.remove(material)
    (mask_dir / "layer_order.json").write_text(
        json.dumps(
            {
                "order": order,
                "semantics": "object-origin depth rank, not per-pixel occlusion order",
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def write_counterfactuals(image_id, trees):
    """Same target geometry, camera and light; remove only external trees."""
    folder = OUT / "counterfactuals" / f"{image_id:06d}"
    folder.mkdir(parents=True, exist_ok=False)
    scene = bpy.context.scene
    camera_matrix = [list(row) for row in scene.camera.matrix_world]
    records = []
    try:
        for index, target in enumerate(trees):
            for obj in trees:
                obj.hide_render = obj is not target
            path = folder / f"target_{index + 1}_rgb.png"
            scene.render.filepath = str(path)
            bpy.ops.render.render(write_still=True)
            if [list(row) for row in scene.camera.matrix_world] != camera_matrix:
                raise ValueError("camera changed in a counterfactual pair")
            records.append(
                {
                    "target": index + 1,
                    "image": path.relative_to(OUT).as_posix(),
                    "group_id": image_id,
                    "visible_mask": f"masks/{image_id:06d}/amodal_{index + 1}.png",
                    "amodal_mask": f"masks/{image_id:06d}/amodal_{index + 1}.png",
                    "raster_unknown": f"masks/{image_id:06d}/raster_unknown_{index + 1}.png",
                    "occlusion_by_other_trees": 0,
                    "note": (
                        "same-view majority support; visible equals full; raster ambiguity ignored"
                    ),
                }
            )
    finally:
        for obj in trees:
            obj.hide_render = False
    return records


def main():
    if os.environ.get("FIG_MASKS_ONLY") == "1":
        raise ValueError("mask-only relabelling is unsafe: render new RGB with the frozen plan")
    if OUT.exists() and any(OUT.iterdir()):
        raise FileExistsError(f"refusing to overwrite existing data: {OUT}")
    paths = {path.stem: path for path in sorted(ROOT.glob("*.glb"))}
    plan = (
        json.loads(Path(PLAN).read_text(encoding="utf-8"))
        if PLAN
        else make_generation_plan(list(paths), SEED)
    )
    validate_plan(plan)
    for name, source in plan.get("asset_manifest", {}).items():
        if name not in paths:
            path = Path(source["path"])
            if (
                path.suffix.lower() not in {".glb", ".blend"}
                or path.stem != name
                or not source.get("sha256")
            ):
                raise ValueError(f"external asset requires a named, hash-pinned GLB/BLEND: {name}")
            if path.suffix.lower() == ".blend" and not source.get("source_meshes"):
                raise ValueError("native external asset requires explicit selected meshes")
            paths[name] = path
    if PAIRED != (plan.get("profile") == "paired-parts-v1"):
        raise ValueError("FIG_PAIRED=1 and a --paired frozen plan must be used together")
    specs = list(plan["records"])
    if SELECTED_IDS:
        selected = {int(value.strip()) for value in SELECTED_IDS.split(",")}
        available = {int(record["id"]) for record in specs}
        if not selected <= available:
            raise ValueError(f"selected IDs missing from plan: {sorted(selected - available)}")
        specs = [record for record in specs if int(record["id"]) in selected]
    if LIMIT:
        specs = specs[:LIMIT]
    if not specs:
        raise ValueError("no scenes selected")
    needed = {name for record in specs for name in record["trees"]}
    if not needed <= paths.keys():
        raise FileNotFoundError(f"missing assets: {sorted(needed - paths.keys())}")
    asset_manifest = {
        name: {
            **plan.get("asset_manifest", {}).get(name, {}),
            "path": str(paths[name]),
            "sha256": sha256_file(paths[name]),
        }
        for name in sorted(needed)
    }
    if "asset_manifest" in plan:
        for name, source in asset_manifest.items():
            if source["sha256"] != plan["asset_manifest"][name]["sha256"]:
                raise ValueError(f"asset changed since the frozen plan: {name}")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "generation_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    (OUT / "asset_manifest.json").write_text(
        json.dumps(asset_manifest, indent=2),
        encoding="utf-8",
    )
    if PAIRED:
        source_dir = OUT / "source"
        source_dir.mkdir()
        for source in (Path(__file__), Path(__file__).with_name("fig_data_protocol.py")):
            (source_dir / source.name).write_bytes(source.read_bytes())
    (OUT / "render_request.json").write_text(
        json.dumps(
            {
                "selected_image_ids": [int(record["id"]) for record in specs],
                "generator_sha256": sha256_file(Path(__file__)),
                "rgb_resolution": [RES_X, RES_Y],
                "mask_resolution": [MASK_X, MASK_Y],
                "samples": 16,
                "paired_counterfactuals_and_material_parts": PAIRED,
                "camera_framing": plan.get("camera_framing"),
                "blender_version": bpy.app.version_string,
                "protocol_sha256": sha256_file(Path(__file__).with_name("fig_data_protocol.py")),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    clean()
    trees = [
        load_tree(paths[name], asset_manifest[name].get("source_meshes")) for name in sorted(needed)
    ]
    trees_by_name = {tree.name: tree for tree in trees}
    base_scales = {tree.name: tuple(tree.scale) for tree in trees}
    ground_obj = ground()
    world()
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 16))
    sun = bpy.context.object
    sun.data.energy = 2.0
    sun.data.angle = math.radians(12)
    sun.rotation_euler = (math.radians(50), 0, math.radians(25))

    (OUT / "images").mkdir(exist_ok=True)
    (OUT / "meta").mkdir(exist_ok=True)
    completed_splits = {split: [] for split in ("train", "validation", "test")}
    for spec in specs:
        image_id = int(spec["id"])
        rng = random.Random(spec["scene_seed"])
        chosen = [trees_by_name[name] for name in spec["trees"]]
        for tree in trees:
            tree.hide_render = True
        order, horizontal_order = layout_orders(len(chosen), rng)
        rank_by_index = {tree_index: rank for rank, tree_index in enumerate(order)}
        widths = []
        if PAIRED:
            world_nodes = bpy.context.scene.world.node_tree.nodes
            world_nodes.get("Mapping").inputs["Rotation"].default_value[2] = rng.uniform(
                0, 2 * math.pi
            )
            world_nodes.get("Background").inputs["Strength"].default_value = rng.uniform(0.6, 1.3)
            sun.data.energy = rng.uniform(1.0, 2.8)
            sun.rotation_euler = (rng.uniform(0.5, 1.1), 0, rng.uniform(0, 2 * math.pi))
        depth_gap = rng.uniform(0.8, 2.5) if PAIRED else 0.45
        for tree_index in horizontal_order:
            tree = chosen[tree_index]
            tree.hide_render = False
            size_scale = rng.uniform(0.7, 1.1) if PAIRED else 1.0
            tree.scale = (
                tuple(v * size_scale for v in base_scales[tree.name])
                if PAIRED
                else tuple(v * rng.uniform(0.88, 1.08) for v in base_scales[tree.name])
            )
            tree.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))
            tree.location.y = rank_by_index[tree_index] * depth_gap
            bpy.context.view_layer.update()
            x0, x1, _, _, _, _ = bbox(tree)
            widths.append((tree, x1 - x0))

        if PAIRED:
            overlap_ratio = spec["requested_bbox_overlap"]
        elif OVERLAP_MIN > 0 and OVERLAP_MAX > OVERLAP_MIN:
            overlap_ratio = rng.uniform(OVERLAP_MIN, OVERLAP_MAX)
        elif len(widths) == 2:
            overlap_ratio = rng.uniform(0.55, 0.75)
        else:
            overlap_ratio = rng.uniform(0.35, 0.60)
        centers = [0.0]
        for pair_index in range(1, len(widths)):
            prev_width = widths[pair_index - 1][1]
            width = widths[pair_index][1]
            step = (prev_width + width) / 2 - overlap_ratio * min(prev_width, width)
            centers.append(centers[-1] + step)
        center_x = (centers[0] + centers[-1]) / 2
        spaced_layout = plan.get("layout_profile") == "spacing-mix-v1"
        if spaced_layout:
            desired = crown_layout_centers([width for _, width in widths], overlap_ratio)
            for center, (tree, _width) in zip(desired, widths, strict=True):
                # Imported crown asymmetry means object origin != bbox center.
                # Translate actual crown bounds instead of resetting its origin.
                bounds = bbox(tree)
                tree.location.x += center - (bounds[0] + bounds[1]) / 2
                tree.location.z = 0
                bpy.context.view_layer.update()
            width_by_tree = {tree.name: width for tree, width in widths}
            depths = separated_depths(
                [tree.location.x for tree in chosen],
                [width_by_tree[tree.name] for tree in chosen],
                order,
                depth_gap,
                spec["minimum_origin_separation_ratio"],
            )
            for tree, depth in zip(chosen, depths, strict=True):
                tree.location.y = depth
            bpy.context.view_layer.update()
        else:
            for center, (tree, _width) in zip(centers, widths, strict=True):
                tree.location.x = center - center_x
                tree.location.z = 0

        if plan.get("camera_framing") == "projected-ground-bounds-v2":
            for tree in chosen:
                tree.location.z -= bbox(tree)[4]
            bpy.context.view_layer.update()
        left = min(centers[0] - widths[0][1] / 2, centers[-1] - widths[-1][1] / 2)
        right = max(centers[0] + widths[0][1] / 2, centers[-1] + widths[-1][1] / 2)
        span = right - left
        if spaced_layout:
            span = max(bbox(tree)[1] for tree in chosen) - min(bbox(tree)[0] for tree in chosen)
        lens = rng.uniform(24, 35)
        camera = camera_for(
            0,
            span,
            lens,
            rng.uniform(1.8, 2.6),
            object_height=max(bbox(tree)[-1] for tree in chosen) if PAIRED else HEIGHT,
        )
        framing = None
        if plan.get("camera_framing") == "projected-bounds-margin-v1":
            framing = fit_projected_bounds(camera, chosen)
        elif plan.get("camera_framing") == "projected-ground-bounds-v2":
            framing = fit_ground_camera_bounds(camera, chosen)

        bpy.context.scene.render.resolution_x = RES_X
        bpy.context.scene.render.resolution_y = RES_Y
        bpy.context.scene.render.film_transparent = False
        bpy.context.scene.render.image_settings.color_mode = "RGB"
        bpy.context.scene.render.filepath = str(OUT / "images" / f"{image_id:06d}.png")
        bpy.ops.render.render(write_still=True)

        write_masks(image_id, chosen, order, ground_obj)
        controls = write_counterfactuals(image_id, chosen) if PAIRED else []
        meta = {
            "id": image_id,
            "generator_schema": GENERATOR_SCHEMA,
            "split": spec["split"],
            "scene_seed": spec["scene_seed"],
            "visible_label_source": "full-scene-target-id-alpha-preserved",
            "layer_semantics": "object-origin depth rank, not per-pixel occlusion order",
            "horizontal_order_left_to_right": [chosen[i].name for i in horizontal_order],
            "trees": [tree.name for tree in chosen],
            "layer_order_front_to_back": [chosen[i].name for i in order],
            "count": len(chosen),
            "bbox_overlap_ratio": round(overlap_ratio, 3),
            "lens_mm": round(lens, 1),
            "profile": plan.get("profile", "legacy-v3"),
            "layout_profile": plan.get("layout_profile"),
            "camera_framing": framing,
            "spacing_class": spec.get("spacing_class"),
            "minimum_origin_separation_ratio": spec.get("minimum_origin_separation_ratio"),
            "counterfactuals": controls,
            "camera_world_matrix": [list(row) for row in bpy.context.scene.camera.matrix_world],
            "tree_world_matrices": {
                tree.name: [list(row) for row in tree.matrix_world] for tree in chosen
            },
            "tree_world_bounds": {tree.name: list(bbox(tree)) for tree in chosen},
            "part_materials": {
                tree.name: {
                    material.name: material_part(material.name)
                    for material in tree.data.materials
                    if material
                }
                for tree in chosen
            }
            if PAIRED
            else {},
        }
        (OUT / "meta" / f"{image_id:06d}.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        completed_splits[spec["split"]].append(image_id)
        (OUT / "splits.json").write_text(
            json.dumps(
                {
                    "schema_version": SPLIT_SCHEMA,
                    "seed": plan["seed"],
                    "asset_pools": plan["asset_pools"],
                    "splits": completed_splits,
                    "generation_plan_sha256": sha256_file(OUT / "generation_plan.json"),
                    "complete": sum(map(len, completed_splits.values())) == len(plan["records"]),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        print("IMAGE", image_id, "OF", len(specs), "COUNT", len(chosen), flush=True)

    print("DONE", len(specs), OUT, flush=True)


if __name__ == "__main__":
    main()
