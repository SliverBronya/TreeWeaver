"""Build a worst-first HTML gallery and contact sheet for the 20260411 run."""

from __future__ import annotations

import html
import json
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(r"D:\TreeWeaver\reports\real-20260411-full-2026-11-01")


def main() -> None:
    rows = json.loads((ROOT / "summary.json").read_text(encoding="utf-8"))
    rows = [row for row in rows if row.get("status") == "ok"]
    rows.sort(key=lambda row: row["iou"])

    cards = []
    for row in rows:
        panel = row["image"].replace(".jpg", ".png")
        cards.append(
            "<div class='card'>"
            f"<a href='{panel}'><img src='{panel}'></a>"
            f"<div>{html.escape(row['image'])}<br>IoU {row['iou']:.3f} · area {row['area_ratio']:.2f}</div>"
            "</div>"
        )
    document = (
        "<!doctype html><meta charset='utf-8'><title>20260411 full</title>"
        "<style>body{font-family:sans-serif;background:#111;color:#eee}"
        ".grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}"
        ".card{background:#222;padding:6px;font-size:13px}.card img{width:100%;display:block}"
        "</style><h1>20260411: stock SAM2 vs current, worst first</h1>"
        "<div class='grid'>" + "".join(cards) + "</div>"
    )
    (ROOT / "gallery.html").write_text(document, encoding="utf-8")

    worst = rows[:12]
    thumbs = []
    for row in worst:
        image = Image.open(ROOT / row["image"].replace(".jpg", ".png")).convert("RGB")
        image.thumbnail((400, 250))
        thumbs.append((row, image))
    width, height = 400, 250
    sheet = Image.new("RGB", (width * 4, height * 3 + 30), "white")
    draw = ImageDraw.Draw(sheet)
    for index, (row, image) in enumerate(thumbs):
        x = (index % 4) * width
        y = (index // 4) * height
        sheet.paste(image, (x, y))
        draw.text(
            (x + 4, y + 4),
            f"{row['image']} IoU {row['iou']:.3f} area {row['area_ratio']:.2f}",
            fill="yellow",
        )
    sheet.save(ROOT / "worst12.jpg", quality=90)
    print("worst", [(row["image"], round(row["iou"], 3), round(row["area_ratio"], 2)) for row in worst])


if __name__ == "__main__":
    main()
