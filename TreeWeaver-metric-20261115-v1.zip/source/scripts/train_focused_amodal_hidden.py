"""Amodal-focused training on the target-centric cohort with hidden-pixel weighting."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
BASE = ROOT / "reports/professional-stage5-amodal-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-amodal-hidden-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def sample(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible, amodal = mask(DATA / row["scene"] / "visible_target.png"), mask(DATA / row["scene"] / "amodal_target.png")
    ys, xs = np.where(visible)
    box = np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], np.float32)
    box = lb.boxes(box)
    def resize(m):
        return np.asarray(Image.fromarray(m.astype(np.uint8) * 255).resize((256, 256), Image.NEAREST)) > 127
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        torch.from_numpy(resize(visible).astype(np.float32))[None, None],
        torch.from_numpy(resize(amodal).astype(np.float32))[None, None],
    )


def build():
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(base).cuda()
    payload = torch.load(BASE, map_location="cpu", weights_only=True)["decoder"]
    own = model.decoder.state_dict()
    model.decoder.load_state_dict({k: v for k, v in payload.items() if k in own and v.shape == own[k].shape}, strict=False)
    if hasattr(model.decoder, "amodal_scale"):
        model.decoder.amodal_scale.data.fill_(0.0)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        if name.startswith("decoder.amodal_"):
            parameter.requires_grad_(True)
    return model


def evaluate(model, rows):
    model.eval()
    ious, hidden_recalls = [], []
    with torch.no_grad():
        for row in rows:
            image, box, visible, amodal = sample(row)
            out = model(image.cuda(), input_boxes=box.cuda())
            pred = out["amodal_masks"][0, 0, 0].sigmoid().cpu() > 0.5
            target = amodal[0, 0] > 0.5
            inter, union = (pred & target).sum().item(), (pred | target).sum().item()
            ious.append(inter / union if union else 1.0)
            hidden = target & ~(visible[0, 0] > 0.5)
            if hidden.any():
                hidden_recalls.append((pred & hidden).sum().item() / hidden.sum().item())
    return {"amodal_iou": float(np.mean(ious)), "hidden_recall": float(np.mean(hidden_recalls)) if hidden_recalls else 0.0}


def main():
    OUT.mkdir(exist_ok=True)
    rows = json.loads((DATA / "index.json").read_text())
    train = [r for r in rows if r["split"] == "train"]
    val = [r for r in rows if r["split"] == "validation"]
    model = build()
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(json.dumps({"train": len(train), "val": len(val), "trainable": sum(p.numel() for p in parameters)}), flush=True)
    before = evaluate(model, val)
    print(json.dumps({"before": before}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=3e-4, weight_decay=1e-4)
    model.train()
    history = []
    for step in range(1, 301):
        row = train[(step - 1) % len(train)]
        image, box, visible, amodal = sample(row)
        optimizer.zero_grad(set_to_none=True)
        out = model(image.cuda(), input_boxes=box.cuda())
        logits = out["amodal_masks"][:, 0, 0]
        target = amodal.cuda()[:, 0]
        hidden = (target > 0.5) & ~(visible.cuda()[:, 0] > 0.5)
        weight = 1.0 + 12.0 * hidden.float()
        bce = F.binary_cross_entropy_with_logits(logits, target, weight=weight)
        p = logits.sigmoid()
        dice = 1 - (2 * (p * target).sum() + 1) / (p.sum() + target.sum() + 1)
        loss = bce + dice
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        history.append(float(loss.detach()))
        if step % 25 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 50 == 0 or step == 300:
            print(json.dumps({"eval_step": step, **evaluate(model, val)}), flush=True)
            torch.save({"state": {k: v.detach().cpu() for k, v in model.named_parameters() if v.requires_grad}}, OUT / "checkpoint.pth")
    after = evaluate(model, val)
    result = {"before": before, "after": after, "train": len(train), "val": len(val), "loss_start": history[0], "loss_end": history[-1]}
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
