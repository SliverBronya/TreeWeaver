"""Keep-alive watchdog for the ConvexMask author-recipe training run.

Why this exists
---------------
A training run needs ~45 hours. Any process started from an agent session is
reclaimed once the session goes idle, and even a user's own run can die for
unrelated reasons (power, update reboot, accident). This watchdog runs the
training as a child process and restarts it whenever it stops without the run
being complete. The training script resumes from ``latest.pth`` automatically,
so a restart costs at most one checkpoint interval.

It also refuses to start a second copy: it checks the pid recorded in
``status.json`` and only launches when that process is really gone.

Usage
-----
    <python> scripts/watch_convexmask_training.py --output reports/<run> \
        -- --data-root ... --recipe author ...

Everything after ``--`` is passed straight to the training script.
Stop conditions (all clean):
  * ``status.json`` reports ``state == "completed"``
  * an empty file named ``STOP_REQUESTED`` appears in the output directory
  * ``--max-restarts`` is reached
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def read_status(output: Path) -> dict:
    path = output / "status.json"
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def pid_alive(pid: int) -> bool:
    """True only if `pid` exists AND looks like a python process.

    tasklist prints a LOCALISED message when nothing matches, which on a Chinese
    Windows is GBK. Decoding that as utf-8 without errors="replace" raised
    UnicodeDecodeError inside the reader thread, left stdout as None, and crashed
    this function with a TypeError - i.e. the watchdog died exactly when the run
    was gone and needed restarting. The image-name check also guards against pid
    reuse, because a stalled run gets killed and an unrelated process must never
    be the target.
    """
    if not pid or pid <= 0:
        return False
    try:
        out = subprocess.run(
            ["tasklist", "/FI", f"PID eq {int(pid)}", "/NH"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        ).stdout or ""
    except Exception:
        return False
    if str(int(pid)) not in out:
        return False
    return "python" in out.lower()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--train-script", default="scripts/train_convexmask_synthtree_continuous.py")
    ap.add_argument("--max-restarts", type=int, default=0, help="0 = unlimited")
    ap.add_argument("--backoff", type=float, default=20.0)
    ap.add_argument("--fast-exit-seconds", type=float, default=180.0)
    ap.add_argument("--fast-exit-backoff", type=float, default=180.0)
    ap.add_argument(
        "--stall-minutes",
        type=float,
        default=15.0,
        help=(
            "Kill the training if status.json stops advancing for this long. A live "
            "pid is not proof of progress: the training can deadlock while still "
            "existing, and then a liveness-only watchdog waits forever."
        ),
    )
    ap.add_argument("train_args", nargs=argparse.REMAINDER)
    args = ap.parse_args()

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    train_args = [a for a in args.train_args if a != "--"]
    if not train_args:
        print("ERROR: pass the training arguments after --", flush=True)
        return 2

    watchdog_log = output / "watchdog.log"
    command = [args.python, str(Path(args.train_script).resolve())] + train_args

    def say(message: str) -> None:
        line = f"{now()} {message}"
        print(line, flush=True)
        with watchdog_log.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")

    say("watchdog started")
    say("command: " + " ".join(command))
    # A STOP_REQUESTED left behind by an earlier session is stale: nothing is
    # running, so honouring it would make the watchdog exit immediately. Only a
    # file that appears while we are looping counts as a real stop request.
    stale = output / "STOP_REQUESTED"
    if stale.exists():
        stale.unlink()
        say("removed stale STOP_REQUESTED from a previous session")
    restarts = fast_exits = 0

    while True:
        status = read_status(output)
        state = status.get("state")
        if state == "completed":
            say("run reports state=completed; watchdog exiting cleanly")
            return 0
        if (output / "STOP_REQUESTED").exists():
            say("STOP_REQUESTED present; leaving without restarting")
            return 0

        pid = int(status.get("pid") or 0)
        if pid_alive(pid):
            stalled_for = None
            stamp = status.get("updated")
            if stamp:
                try:
                    stalled_for = time.time() - datetime.fromisoformat(stamp).timestamp()
                except Exception:
                    stalled_for = None
            if stalled_for is not None and stalled_for > args.stall_minutes * 60:
                say(
                    f"pid {pid} has not advanced status.json for {stalled_for/60:.1f} min "
                    f"(step={status.get('step')}); treating it as stalled and killing it"
                )
                try:
                    subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                                   capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", timeout=60)
                except Exception as exc:
                    say(f"taskkill failed: {exc}")
                time.sleep(args.backoff)
                continue
            age = "unknown" if stalled_for is None else f"{stalled_for/60:.1f} min"
            say(f"training pid {pid} is alive (state={state}, step={status.get('step')}, "
                f"last update {age} ago); waiting")
            time.sleep(30.0)
            continue

        if args.max_restarts and restarts >= args.max_restarts:
            say(f"reached --max-restarts {args.max_restarts}; stopping")
            return 1

        say(f"starting training (restart #{restarts})")
        started = time.time()
        env = dict(os.environ)
        env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
        with (output / f"worker-{restarts}.log").open("a", encoding="utf-8") as log:
            result = subprocess.run(command, cwd=Path.cwd(), stdout=log, stderr=subprocess.STDOUT,
                                    env=env, check=False)
        lived = time.time() - started
        say(f"training exited with code {result.returncode} after {lived/60:.1f} min")

        status = read_status(output)
        if status.get("state") == "completed":
            say("state=completed; watchdog done")
            return 0

        restarts += 1
        if lived < args.fast_exit_seconds:
            fast_exits += 1
            if fast_exits >= 3:
                say(f"{fast_exits} fast failures; backing off {args.fast_exit_backoff:.0f}s "
                    "(check worker logs before trusting this)")
                time.sleep(args.fast_exit_backoff)
                fast_exits = 0
                continue
        else:
            fast_exits = 0
        time.sleep(args.backoff)


if __name__ == "__main__":
    raise SystemExit(main())
