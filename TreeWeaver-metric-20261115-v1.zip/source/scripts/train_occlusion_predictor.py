"""Train an occlusion-relation predictor on SPREAD, scene-disjoint.

Task
----
Input  : RGB (3ch) + the target tree's **visible** mask (1ch), conditionated on
         ground-truth segmentation, exactly like the earlier boundary pilot.
Output : for every pixel, the probability that the surface seen there lies
         *in front of* the target tree.

Why this task: at deployment time there is no depth map and no camera pose, so
the operational question is "what in this image is closer than my target tree?".
SPREAD ships depth, so the label can be generated automatically and at scale.

Label definition (per frame)
----------------------------
* valid       : 0 < depth < 65504 (65504 is the no-hit sentinel)
* target_d    : median depth over (target mask AND valid)
* in_front    : valid AND depth < target_d * 0.95 AND NOT target mask
* ignore      : NOT valid  -> excluded from the loss, never treated as negative

This is **not** a claim of hidden-extent recovery: it orders *visible* surfaces.

Evaluation is scene-disjoint (train on two scenes, test on a third), and the
report includes trivial baselines so the number can be read honestly.
"""

from __future__ import annotations

import argparse
import json
import os
import time

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

BASE = r"D:\TreeWeaver\data\external\spread"
SENTINEL = 65504.0
SIZE = (136, 240)  # h, w of the working resolution (even, so strides line up)


def load_palette() -> dict[int, tuple[int, int, int]]:
    raw = json.load(open(os.path.join(BASE, "color_palette.json"), encoding="utf-8"))
    return {int(k): tuple(reversed([int(x) for x in v])) for k, v in raw["palette"].items()}


def frame_names(scene: str, limit: int, stride: int) -> list[str]:
    d = os.path.join(BASE, scene, "instance_segmentation")
    names = sorted(f for f in os.listdir(d) if f.endswith(".png"))
    return [n[:-4] for n in names[::stride][:limit]]


def build_sample(scene: str, frame: str, pal: dict):
    inst = cv2.imread(os.path.join(BASE, scene, "instance_segmentation", frame + ".png"), cv2.IMREAD_UNCHANGED)
    rgb = cv2.imread(os.path.join(BASE, scene, "rgb", frame + ".png"), cv2.IMREAD_UNCHANGED)
    dep = cv2.imread(os.path.join(BASE, scene, "depth_pfm", frame + ".pfm"), cv2.IMREAD_UNCHANGED)
    if inst is None or rgb is None or dep is None:
        return None
    if dep.ndim == 3:
        dep = dep[:, :, 0]
    dep = np.flipud(dep.astype(np.float32))  # PFM is stored bottom-up
    h, w = dep.shape

    listed: dict[str, int] = {}
    txt = os.path.join(BASE, scene, "instance_segmentation", frame + ".txt")
    if os.path.exists(txt):
        for line in open(txt, encoding="utf-8"):
            parts = line.split()
            if len(parts) >= 2:
                listed[parts[0]] = int(parts[1])
    target = frame.split("_")[0]
    idx = listed.get(target, -1)
    colour = pal.get(idx)
    if colour is None:
        return None
    target_mask = np.all(inst[:, :, :3] == np.array(colour, dtype=np.uint8), axis=2)

    valid = (dep > 0) & (dep < SENTINEL - 1)
    if not (target_mask & valid).any() or target_mask.sum() < 200:
        return None
    target_d = float(np.median(dep[target_mask & valid]))
    in_front = valid & (dep < target_d * 0.95) & ~target_mask
    ignore = ~valid

    rgb_s = cv2.resize(rgb[:, :, :3], (SIZE[1], SIZE[0]), interpolation=cv2.INTER_AREA)
    tm_s = cv2.resize(target_mask.astype(np.uint8), (SIZE[1], SIZE[0]), interpolation=cv2.INTER_NEAREST)
    if_s = cv2.resize(in_front.astype(np.uint8), (SIZE[1], SIZE[0]), interpolation=cv2.INTER_NEAREST)
    ig_s = cv2.resize(ignore.astype(np.uint8), (SIZE[1], SIZE[0]), interpolation=cv2.INTER_NEAREST)

    img = np.concatenate([rgb_s.astype(np.float32) / 255.0, tm_s[..., None].astype(np.float32)], axis=2)
    meta = {
        "scene": scene,
        "frame": frame,
        "target_px_full": int(target_mask.sum()),
        "in_front_px_full": int(in_front.sum()),
        "target_median_depth": round(target_d, 3),
    }
    return (img.transpose(2, 0, 1), if_s.astype(np.float32), ig_s.astype(np.float32), meta)


class TinyUNet(nn.Module):
    def __init__(self, in_ch: int = 4, base: int = 16) -> None:
        super().__init__()
        self.e1 = nn.Sequential(nn.Conv2d(in_ch, base, 3, padding=1), nn.ReLU(inplace=True),
                                nn.Conv2d(base, base, 3, padding=1), nn.ReLU(inplace=True))
        self.e2 = nn.Sequential(nn.Conv2d(base, base * 2, 3, stride=2, padding=1), nn.ReLU(inplace=True),
                                nn.Conv2d(base * 2, base * 2, 3, padding=1), nn.ReLU(inplace=True))
        self.e3 = nn.Sequential(nn.Conv2d(base * 2, base * 4, 3, stride=2, padding=1), nn.ReLU(inplace=True),
                                nn.Conv2d(base * 4, base * 4, 3, padding=1), nn.ReLU(inplace=True))
        self.u2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.d2 = nn.Sequential(nn.Conv2d(base * 4, base * 2, 3, padding=1), nn.ReLU(inplace=True))
        self.u1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.d1 = nn.Sequential(nn.Conv2d(base * 2, base, 3, padding=1), nn.ReLU(inplace=True))
        self.head = nn.Conv2d(base, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        a = self.e1(x)
        b = self.e2(a)
        c = self.e3(b)
        y = self.d2(torch.cat([self.u2(c), b], dim=1))
        y = self.d1(torch.cat([self.u1(y), a], dim=1))
        return self.head(y)


def evaluate(model, samples, device, thr: float = 0.0) -> dict:
    """Micro (pooled) and macro (per-frame mean) IoU at a logit threshold."""
    model.eval()
    tp = fp = fn = tn = 0
    per_frame = []
    with torch.no_grad():
        for img, lab, ign, _meta in samples:
            logit = model(torch.from_numpy(img[None]).to(device))[0, 0].cpu().numpy()
            valid = ign < 0.5
            pred = (logit > thr) & valid
            gt = (lab > 0.5) & valid
            tp += int((pred & gt).sum()); fp += int((pred & ~gt).sum())
            fn += int((~pred & gt).sum()); tn += int((~pred & ~gt).sum())
            f_gt = int(gt.sum()); f_pred = int(pred.sum())
            per_frame.append((int((pred & gt).sum()) / max(f_gt + f_pred - int((pred & gt).sum()), 1)))
    eps = 1e-9
    return {"frames": len(samples), "threshold_logit": round(thr, 3),
            "iou_micro": tp / (tp + fp + fn + eps),
            "iou_macro": float(np.mean(per_frame)) if per_frame else 0.0,
            "precision": tp / (tp + fp + eps), "recall": tp / (tp + fn + eps),
            "gt_positive_px": tp + fn, "pred_positive_px": tp + fp, "tn": tn}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-scenes", nargs="+", default=["birch_forest", "broadleaf_forest"])
    ap.add_argument("--test-scenes", nargs="+", default=["city_park"])
    ap.add_argument("--train-frames", type=int, default=160)
    ap.add_argument("--test-frames", type=int, default=40)
    ap.add_argument("--stride", type=int, default=7)
    ap.add_argument("--steps", type=int, default=400)
    ap.add_argument("--minutes", type=float, default=0.0,
                    help="wall-clock training budget in minutes; 0 means use --steps only")
    ap.add_argument("--base", type=int, default=16, help="base channel width of TinyUNet")
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--output", default=r"D:\TreeWeaver\reports\spread-occlusion-train-2026-10-13")
    args = ap.parse_args()

    os.makedirs(args.output, exist_ok=True)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    pal = load_palette()

    per_scene = max(1, args.train_frames // len(args.train_scenes))
    train, test = [], []
    for scene in args.train_scenes:
        for f in frame_names(scene, per_scene, args.stride):
            s = build_sample(scene, f, pal)
            if s:
                train.append(s)
    for scene in args.test_scenes:
        for f in frame_names(scene, args.test_frames, args.stride):
            s = build_sample(scene, f, pal)
            if s:
                test.append(s)
    print(json.dumps({"device": device, "train_samples": len(train), "test_samples": len(test)}), flush=True)
    if not train or not test:
        print("not enough samples", flush=True)
        return 1

    # trivial baselines on the held-out scenes
    zero_iou = {"frames": len(test), "iou": 0.0, "note": "predict nothing positive"}
    all_iou_num = sum(float(s[1].sum()) for s in test)
    all_iou_den = sum(float(((s[1] > 0.5) | (s[2] < 0.5)).sum()) for s in test)
    all_iou = {"frames": len(test), "iou": all_iou_num / max(all_iou_den, 1e-9), "note": "predict all valid positive"}

    model = TinyUNet(base=args.base).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)

    # The label is rare (about 7% of valid pixels), so a plain BCE collapses to
    # the all-negative solution. Weight the positive term and add a soft Dice
    # term, both computed over valid pixels only.
    pos = sum(float((s[1] * (1 - s[2])).sum()) for s in train)
    neg = sum(float(((1 - s[1]) * (1 - s[2])).sum()) for s in train)
    pos_weight = torch.tensor([max(1.0, neg / max(pos, 1.0))], device=device)
    print(json.dumps({"pos_px": pos, "neg_px": neg, "pos_weight": float(pos_weight.item())}), flush=True)

    history = []
    t0 = time.time()
    deadline = t0 + args.minutes * 60.0 if args.minutes > 0 else None
    step = 0
    while True:
        step += 1
        if step > args.steps:
            step -= 1
            break
        if deadline is not None and time.time() > deadline:
            step -= 1
            print(json.dumps({"stopped_on_time_budget": True, "steps_run": step}), flush=True)
            break
        idx = np.random.randint(0, len(train), size=min(args.batch, len(train)))
        x = torch.from_numpy(np.stack([train[i][0] for i in idx])).to(device)
        y = torch.from_numpy(np.stack([train[i][1] for i in idx])).to(device)
        ig = torch.from_numpy(np.stack([train[i][2] for i in idx])).to(device)
        logit = model(x)[:, 0]
        w = 1.0 - ig
        wsum = w.sum().clamp_min(1.0)
        bce = F.binary_cross_entropy_with_logits(logit, y, reduction="none", pos_weight=pos_weight)
        loss_bce = (bce * w).sum() / wsum
        prob = torch.sigmoid(logit) * w
        yv = y * w
        dice = 1.0 - (2.0 * (prob * yv).sum() + 1.0) / (prob.sum() + yv.sum() + 1.0)
        loss = loss_bce + dice
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        if step % 200 == 0 or step == 1:
            entry = {"step": step, "loss": round(float(loss.item()), 4),
                     "bce": round(float(loss_bce.item()), 4), "dice": round(float(dice.item()), 4),
                     "train_seconds": round(time.time() - t0, 1)}
            history.append(entry)
            print(json.dumps(entry), flush=True)

    ckpt_path = os.path.join(args.output, "occlusion_predictor.pth")
    torch.save({"model": model.state_dict(), "params": n_params,
                "train_scenes": args.train_scenes, "test_scenes": args.test_scenes,
                "size": SIZE, "steps_run": step}, ckpt_path)
    print(json.dumps({"checkpoint": ckpt_path, "steps_run": step}), flush=True)

    # pick the decision threshold on TRAIN only, then apply it to the held-out scenes
    sweep = []
    for thr in (0.0, 0.5, 1.0, 1.5, 2.0):
        m = evaluate(model, train[:30], device, thr)
        sweep.append({"threshold_logit": thr, "train_iou_micro": round(m["iou_micro"], 4),
                      "train_iou_macro": round(m["iou_macro"], 4)})
    best_thr = max(sweep, key=lambda d: d["train_iou_macro"])["threshold_logit"]
    print(json.dumps({"threshold_sweep_on_train": sweep, "chosen_threshold": best_thr}), flush=True)

    train_metrics = evaluate(model, train[:30], device, best_thr)
    test_metrics = evaluate(model, test, device, best_thr)
    report = {
        "task": "pixel-wise occlusion relation: is the surface in front of the target tree",
        "input": "RGB(3) + ground-truth target visible mask(1); conditioned on GT segmentation",
        "not_claimed": "hidden-extent recovery, detector accuracy, metric measurement, field accuracy",
        "label_rule": "in_front = valid depth < 0.95 * median target depth, excluding target pixels; invalid depth ignored",
        "split": {"train_scenes": args.train_scenes, "test_scenes": args.test_scenes,
                  "scene_disjoint": True, "seed": args.seed},
        "resolution": {"h": SIZE[0], "w": SIZE[1]},
        "params": n_params,
        "base_channels": args.base,
        "steps": args.steps,
        "steps_run": step,
        "minutes_budget": args.minutes,
        "train_samples": len(train),
        "test_samples": len(test),
        "loss": "BCE(pos_weight) over valid pixels + soft Dice, to counter ~7% positive rate",
        "pos_weight": float(pos_weight.item()),
        "history": history,
        "chosen_threshold_logit": best_thr,
        "threshold_sweep_on_train": sweep,
        "train_subset": train_metrics,
        "held_out": test_metrics,
        "baselines_held_out": [zero_iou, all_iou],
        "peak_vram_gib": round(torch.cuda.max_memory_allocated() / 1024**3, 3) if device == "cuda" else None,
        "wall_seconds": round(time.time() - t0, 1),
    }
    with open(os.path.join(args.output, "run.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)

    # qualitative overlays on held-out frames
    model.eval()
    for k, (img, lab, ign, meta) in enumerate(test[:6]):
        with torch.no_grad():
            logit = model(torch.from_numpy(img[None]).to(device))[0, 0].cpu().numpy()
        pred = (logit > best_thr) & (ign < 0.5)
        gt = (lab > 0.5) & (ign < 0.5)
        canvas = np.zeros((SIZE[0], SIZE[1] * 3 + 20, 3), np.uint8)
        canvas[:, :SIZE[1]] = (img[:3].transpose(1, 2, 0) * 255).astype(np.uint8)
        canvas[:, :SIZE[1]][img[3] > 0.5] = (canvas[:, :SIZE[1]][img[3] > 0.5] * 0.5 + np.array([0, 128, 0]) * 0.5)
        gtimg = np.zeros((SIZE[0], SIZE[1], 3), np.uint8); gtimg[gt] = (0, 0, 255); gtimg[~gt & (ign < 0.5)] = (70, 70, 70)
        canvas[:, SIZE[1] + 10 : 2 * SIZE[1] + 10] = gtimg
        primg = np.zeros((SIZE[0], SIZE[1], 3), np.uint8); primg[pred] = (0, 255, 255)
        primg[gt & pred] = (0, 255, 0); primg[gt & ~pred] = (0, 0, 255)
        canvas[:, 2 * SIZE[1] + 20 :] = primg
        for i, lab_txt in enumerate(["rgb+target", "gt in-front", "green=hit red=miss yellow=false-pos"]):
            cv2.putText(canvas, lab_txt, (i * (SIZE[1] + 10) + 3, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.34, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.imwrite(os.path.join(args.output, f"{k:02d}_{meta['scene']}__{meta['frame']}.png"), canvas)

    print(json.dumps({"held_out": test_metrics, "baselines": [zero_iou, all_iou],
                      "params": n_params, "wall_seconds": report["wall_seconds"],
                      "peak_vram_gib": report["peak_vram_gib"]}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
