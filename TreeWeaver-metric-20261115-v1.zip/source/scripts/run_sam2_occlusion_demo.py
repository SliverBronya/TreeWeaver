"""Run the occlusion-aware SAM2 decoder on one tree photograph.

Pipeline: Grounding DINO proposes tree boxes -> SAM2 image encoder + prompt
encoder -> our extended mask decoder -> visible mask, amodal hypothesis,
tree/stem visibility, crown curve.

This is a visual diagnostic, not an accuracy benchmark: no ground truth is read
and no metric measurement is produced. All outputs are scale-free.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    revisions = sorted((base / "snapshots").iterdir())
    if not revisions:
        raise FileNotFoundError(f"no cached snapshot for {repo}")
    return revisions[-1]


def detect_boxes(image: Image.Image, device: str, box_threshold: float, text_threshold: float):
    path = snapshot("IDEA-Research/grounding-dino-tiny")
    processor = AutoProcessor.from_pretrained(path, local_files_only=True)
    model = (
        AutoModelForZeroShotObjectDetection.from_pretrained(path, local_files_only=True)
        .to(device)
        .eval()
    )
    inputs = processor(images=image, text="tree.", return_tensors="pt").to(device)
    with torch.no_grad():
        outputs = model(**inputs)
    parameters = inspect.signature(
        processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"
    result = processor.post_process_grounded_object_detection(
        outputs,
        inputs.input_ids,
        text_threshold=text_threshold,
        target_sizes=[image.size[::-1]],
        **{threshold_keyword: box_threshold},
    )[0]
    boxes = result["boxes"].detach().cpu().numpy()
    scores = result["scores"].detach().cpu().numpy()
    return boxes, scores


def draw_curve(canvas, curve, origin, size):
    x0, y0 = origin
    width, height = size
    cv2.rectangle(canvas, (x0, y0), (x0 + width, y0 + height), (40, 40, 40), 1)
    points = []
    for index, value in enumerate(curve):
        x = x0 + int(round(index / max(len(curve) - 1, 1) * (width - 8))) + 4
        y = y0 + height - 6 - int(round(float(value) * (height - 12)))
        points.append((x, y))
    if len(points) >= 2:
        cv2.polylines(canvas, [np.array(points, np.int32)], False, (0, 255, 255), 1, cv2.LINE_AA)
    cv2.putText(
        canvas, "crown c(t)", (x0 + 4, y0 - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (240, 240, 240), 1
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-boxes", type=int, default=3)
    parser.add_argument("--box-threshold", type=float, default=0.28)
    parser.add_argument("--text-threshold", type=float, default=0.22)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    if args.output.exists():
        raise SystemExit(f"output directory already exists: {args.output}")
    if not torch.cuda.is_available() and args.device == "cuda":
        args.device = "cpu"

    image_bgr = cv2.imread(str(args.image))
    if image_bgr is None:
        raise SystemExit(f"cannot read image: {args.image}")
    height, width = image_bgr.shape[:2]
    image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))

    boxes, scores = detect_boxes(image, args.device, args.box_threshold, args.text_threshold)
    if len(boxes) == 0:
        raise SystemExit("Grounding DINO found no tree boxes; nothing to prompt SAM2")
    order = np.argsort(scores)[::-1][: args.max_boxes]
    boxes, scores = boxes[order], scores[order]
    scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
    scaled_boxes = boxes * scale

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "workers" / "tree_models"))
    from sam2_occlusion import Sam2OcclusionModel

    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device).eval()
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    inputs = processor(images=image, return_tensors="pt").to(args.device)

    with torch.no_grad():
        output = model(
            inputs["pixel_values"],
            input_boxes=torch.as_tensor(scaled_boxes, device=args.device)[None],
        )
        modal = processor.post_process_masks(
            output["masks"], original_sizes=inputs["original_sizes"]
        )[0]
        amodal = processor.post_process_masks(
            output["amodal_masks"], original_sizes=inputs["original_sizes"]
        )[0]
    modal = modal.detach().cpu().numpy()
    amodal = amodal.detach().cpu().numpy()
    visibility = output["visibility"].detach().cpu().numpy()[0]
    log_variance = output["visibility_log_variance"].detach().cpu().numpy()[0]
    curve = output["curve"].detach().cpu().numpy()[0]
    routing = output["routing"].detach().cpu().numpy()[0]

    palette = [(255, 120, 40), (60, 200, 90), (40, 90, 240), (220, 60, 190)]
    overlay = image_bgr.copy()
    instances = []
    for index in range(modal.shape[0]):
        visible_mask = modal[index, 0] > 0
        amodal_mask = amodal[index, 0] > 0
        color = np.array(palette[index % len(palette)], np.float32)
        overlay[visible_mask] = (0.55 * overlay[visible_mask] + 0.45 * color).astype(np.uint8)
        contours = cv2.findContours(
            amodal_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )[0]
        cv2.drawContours(overlay, contours, -1, (0, 255, 255), 2)
        x0, y0, x1, y1 = [int(round(value)) for value in boxes[index]]
        cv2.rectangle(overlay, (x0, y0), (x1, y1), (0, 200, 0), 1)
        label = (
            f"#{index} score={scores[index]:.2f} "
            f"vis tree={visibility[index, 0]:.2f} stem={visibility[index, 1]:.2f}"
        )
        cv2.putText(overlay, label, (max(x0, 4), max(y0 - 6, 16)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.45, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.putText(overlay, label, (max(x0, 4), max(y0 - 6, 16)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.45, (0, 0, 0), 1, cv2.LINE_AA)
        curve_origin = (8, height - 150 - 8 * index)
        draw_curve(overlay, curve[index], curve_origin, (150, 110))
        instances.append(
            {
                "instance": index,
                "detector_score": float(scores[index]),
                "box_xyxy": [float(value) for value in boxes[index]],
                "visibility_tree": float(visibility[index, 0]),
                "visibility_stem": float(visibility[index, 1]),
                "visibility_log_variance": [float(value) for value in log_variance[index]],
                "curve": [float(value) for value in curve[index]],
                "routing": [float(value) for value in routing[index]],
                "modal_pixels": int(visible_mask.sum()),
                "amodal_pixels": int(amodal_mask.sum()),
                "amodal_over_modal": float(amodal_mask.sum()) / max(int(visible_mask.sum()), 1),
            }
        )

    args.output.mkdir(parents=True)
    overlay_path = args.output / "overlay.png"
    if not cv2.imwrite(str(overlay_path), overlay):
        raise SystemExit(f"cannot write overlay: {overlay_path}")
    report = {
        "mode": "scale_free_diagnostic",
        "image": str(args.image.resolve()),
        "image_sha256": hashlib.sha256(args.image.read_bytes()).hexdigest(),
        "sam2_checkpoint": str(sam2_path),
        "detector": "IDEA-Research/grounding-dino-tiny",
        "box_threshold": args.box_threshold,
        "text_threshold": args.text_threshold,
        "input_size": [
            int(inputs["pixel_values"].shape[-1]),
            int(inputs["pixel_values"].shape[-2]),
        ],
        "instances": instances,
        "overlay": str(overlay_path),
        "note": "amodal masks are hypotheses; no metric scale and no measurement produced",
    }
    (args.output / "run.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"overlay": str(overlay_path), "instances": len(instances)}), flush=True)
    for instance in instances:
        print(
            f"#{instance['instance']} score={instance['detector_score']:.3f} "
            f"vis_tree={instance['visibility_tree']:.3f} "
            f"vis_stem={instance['visibility_stem']:.3f} "
            f"modal_px={instance['modal_pixels']} amodal_px={instance['amodal_pixels']}",
            flush=True,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
