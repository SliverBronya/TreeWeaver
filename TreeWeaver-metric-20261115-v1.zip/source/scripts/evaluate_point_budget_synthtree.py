"""Cross-source development check: annotated-foreground identity, not amodal."""

from __future__ import annotations

import json
import sys
from collections import defaultdict

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from train_part_readouts import INITIAL, REVISION, ROOT, write
from transformers import Sam2Model

sys.path.insert(0, str(ROOT / ".worker-envs/convexmask-extra"))
from pycocotools import mask as coco_mask  # noqa: E402

sys.path.insert(0, str(ROOT / "workers/tree_models"))
from identity_prompts import point_prompt_suite  # noqa: E402
from ownership_features import ownership_logits  # noqa: E402
from research_protocol import pinned_snapshot, sha256_file  # noqa: E402
from resource_guard import assert_pretrained_experiment_allowed  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402
from whole_tree_objective import competitive_decode  # noqa: E402


def main():
    assert_pretrained_experiment_allowed()
    torch.set_num_threads(2)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    original = ROOT / "reports/query-ownership-synthtree-val-2026-11-08"
    out = ROOT / "reports/point-budget-synthtree-2026-11-09"
    out.mkdir(exist_ok=False)
    selection = json.loads((original / "selection.json").read_text())
    source = ROOT / "data/external/synthtree43k"
    annotation = source / "annotations/val_RGB_entire_tree.json"
    doc = json.loads(annotation.read_text())
    groups = defaultdict(list)
    for row in doc["annotations"]:
        groups[row["image_id"]].append(row)
    write(
        out / "protocol.json",
        {
            "selection_sha256": sha256_file(original / "selection.json"),
            "annotation_sha256": sha256_file(annotation),
            "images": 50,
            "official_role": "val",
            "scope": "unambiguous labelled foreground only; outside union ignored; no BG FP claims",
            "prompts": "single positive vs K positives vs positive + K-1 neighbour negatives; same GT boxes",
            "metric": "image macro of instance means, native1280x720",
            "full_crown_or_amodal_metric": False,
            "training": False,
            "official_test_accessed": False,
            "physical_folder_name_is_not_split_authority": True,
            "promoted": False,
        },
    )
    base = Sam2Model.from_pretrained(
        pinned_snapshot("facebook/sam2.1-hiera-tiny", REVISION), local_files_only=True
    )
    base.mask_decoder.load_state_dict(
        torch.load(INITIAL, map_location="cpu", weights_only=True)["sam2_mask_decoder"]
    )
    model = Sam2OcclusionModel(base, expose_query_features=True).to(device).eval()
    model.decoder.load_state_dict(
        torch.load(
            ROOT / "reports/whole-tree-identity-native-pilot-2026-11-08/coverage-final.pth",
            map_location="cpu",
            weights_only=True,
        )["decoder"],
        strict=True,
    )
    names = [
        "ownership-query-feature-ablation-2026-11-08",
        "ownership-query-feature-seed109-2026-11-08",
        "ownership-query-feature-seed110-2026-11-08",
    ]
    states = [
        torch.load(
            ROOT / "reports" / name / "query_features-final.pth",
            map_location="cpu",
            weights_only=True,
        )["heads"]
        for name in names
    ]
    rows = []
    with torch.no_grad():
        for index, image in enumerate(selection["images"]):
            ann = groups[image["id"]]
            target = np.stack([coco_mask.decode(a["segmentation"]).astype(bool) for a in ann])
            h, w = target.shape[-2:]
            known = target.sum(0) == 1
            boxes = []
            points = []
            for mask in target:
                ys, xs = np.nonzero(mask)
                dx = max(2, 0.05 * (xs.max() - xs.min() + 1))
                dy = max(2, 0.05 * (ys.max() - ys.min() + 1))
                boxes.append(
                    [
                        max(0, xs.min() - dx) * 1024 / w,
                        max(0, ys.min() - dy) * 1024 / h,
                        min(w, xs.max() + 1 + dx) * 1024 / w,
                        min(h, ys.max() + 1 + dy) * 1024 / h,
                    ]
                )
                pi = np.argmin((xs - np.median(xs)) ** 2 + (ys - np.median(ys)) ** 2)
                points.append([[(xs[pi] + 0.5) * 1024 / w, (ys[pi] + 0.5) * 1024 / h]])
            rgb = cv2.cvtColor(
                cv2.imread(str(source / "test_set" / image["file_name"])), cv2.COLOR_BGR2RGB
            )
            pixels = cv2.resize(rgb, (1024, 1024)).astype(np.float32) / 255
            pixels = (pixels - np.array([0.485, 0.456, 0.406], np.float32)) / np.array(
                [0.229, 0.224, 0.225], np.float32
            )
            for prompt_mode, (prompt_points, prompt_labels) in point_prompt_suite(target).items():
                result = model(
                    pixel_values=torch.from_numpy(pixels.transpose(2, 0, 1))[None].to(device),
                    input_boxes=torch.tensor([boxes], device=device, dtype=torch.float32),
                    input_points=torch.from_numpy(prompt_points)[None].to(device),
                    input_labels=torch.from_numpy(prompt_labels)[None].to(device),
                )
                raw = F.interpolate(
                    result["masks"][0], (h, w), mode="bilinear", align_corners=False
                )[:, 0].cpu()
                variants = {"independent": raw > 0, "mask_winner": competitive_decode(raw)}
                for seed, state in enumerate(states):
                    for key, value in state.items():
                        getattr(model.decoder, key).load_state_dict(value, strict=True)
                    logits, _ = ownership_logits(
                        result["query_pixel_embeddings"],
                        result["sam_tokens"][:, :, 0],
                        model.decoder.ownership_projection,
                        model.decoder.ownership_conv,
                        model.decoder.ownership_bg,
                        query_specific=True,
                    )
                    owner = F.interpolate(logits, (h, w), mode="bilinear", align_corners=False)[
                        0
                    ].cpu()
                    variants[f"query_order_seed_{108 + seed}"] = competitive_decode(raw, owner)
                for mode, pred in variants.items():
                    assert torch.equal(pred.any(0), (raw > 0).any(0))
                    pred = pred.numpy() & known
                    truth = target & known
                    instance = []
                    for q in range(len(target)):
                        p, t = pred[q], truth[q]
                        intersection = (p & t).sum()
                        foreign = np.delete(truth, q, 0).any(0)
                        instance.append(
                            {
                                "annotated_foreground_iou": float(
                                    intersection / max((p | t).sum(), 1)
                                ),
                                "annotation_recall": float(intersection / max(t.sum(), 1)),
                                "neighbour_fraction_within_annotated_foreground": float(
                                    (p & foreign).sum() / max(p.sum(), 1)
                                ),
                            }
                        )
                    rows.append(
                        {
                            "image": image["file_name"],
                            "mode": prompt_mode + "/" + mode,
                            "instances": len(target),
                            "frame_cut_instances": sum(
                                bool(m[0].any() or m[-1].any() or m[:, 0].any() or m[:, -1].any())
                                for m in target
                            ),
                            "ambiguous_annotation_overlap_pixels": int((target.sum(0) > 1).sum()),
                            **{k: float(np.mean([r[k] for r in instance])) for k in instance[0]},
                        }
                    )
            if (index + 1) % 10 == 0:
                print(f"evaluated {index + 1}/50", flush=True)
    metrics = [
        "annotated_foreground_iou",
        "annotation_recall",
        "neighbour_fraction_within_annotated_foreground",
    ]
    summary = {
        mode: {k: float(np.mean([r[k] for r in rows if r["mode"] == mode])) for k in metrics}
        for mode in dict.fromkeys(r["mode"] for r in rows)
    }
    write(
        out / "results.json",
        {
            "summary": summary,
            "records": rows,
            "foreground_union_preserved": True,
            "training": False,
            "official_test_accessed": False,
            "promoted": False,
        },
    )
    print(summary)


if __name__ == "__main__":
    main()
