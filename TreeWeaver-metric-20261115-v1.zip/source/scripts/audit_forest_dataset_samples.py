"""Bounded remote ZIP inspection and local SPREAD metadata audit, not training."""

import io
import json
import re
import urllib.request
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

OUTPUT = Path("D:/TreeWeaver/reports/forest-dataset-audit-2026-10-12")


class RemoteZip(io.RawIOBase):
    def __init__(self, url, transfer_budget=40_000_000):
        self.url, self.position, self.transferred = url, 0, 0
        self.transfer_budget = transfer_budget
        request = urllib.request.Request(url, headers={"Range": "bytes=0-31"})
        with urllib.request.urlopen(request, timeout=25) as response:
            if response.status != 206:
                raise ValueError("Server does not support bounded range reads")
            self.size = int(response.headers["Content-Range"].split("/")[-1])
            response.read(32)

    def seekable(self):
        return True

    def seek(self, offset, whence=0):
        self.position = offset + (0 if whence == 0 else self.position if whence == 1 else self.size)
        return self.position

    def tell(self):
        return self.position

    def read(self, size=-1):
        size = self.size - self.position if size < 0 else min(size, self.size - self.position)
        if size <= 0:
            return b""
        if size > 24_000_000 or self.transferred + size > self.transfer_budget:
            raise ValueError("Sample transfer budget exceeded")
        start = self.position
        request = urllib.request.Request(
            self.url, headers={"Range": f"bytes={start}-{start + size - 1}"}
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            if response.status != 206:
                raise ValueError("Range request ignored")
            actual = int(response.headers["Content-Range"].split()[1].split("-")[0])
            if actual != start:
                raise ValueError("Server returned wrong range")
            data = response.read(size)
        self.position += len(data)
        self.transferred += len(data)
        return data


def xlsx_rows(path, limit=4, tree_only=False):
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            shared = [
                "".join(e.itertext())
                for e in ET.fromstring(archive.read("xl/sharedStrings.xml")).findall("m:si", ns)
            ]
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
        rows = []
        for row in sheet.findall(".//m:row", ns):
            values = []
            for cell in row.findall("m:c", ns):
                value = cell.find("m:v", ns)
                text = value.text if value is not None else "".join(cell.itertext())
                values.append(shared[int(text)] if cell.get("t") == "s" else text)
            if not tree_only or (values and values[0].startswith("Tree")):
                rows.append(values)
            if len(rows) >= limit:
                break
        return rows


def main():
    OUTPUT.mkdir(exist_ok=False, parents=True)
    report = {}
    readme = (
        urllib.request.urlopen(
            "https://raw.githubusercontent.com/norlab-ulaval/PercepTreeV1/main/README.md",
            timeout=25,
        )
        .read()
        .decode()
    )
    urls = re.findall(r'http://norlab[^"\s]+', readme)
    for url in urls:
        name = "CanaTree100" if "CanaTree100" in url else "SynthTree43k"
        print("Inspecting " + name, flush=True)
        record = {"archive_url_without_query": url.split("?")[0]}
        report[name] = record
        try:
            remote = RemoteZip(url.replace("http://", "https://"))
            with zipfile.ZipFile(remote) as archive:
                entries = archive.infolist()
                record["archive_bytes"] = remote.size
                record["entry_count"] = len(entries)
                record["extensions"] = dict(Counter(Path(e.filename).suffix for e in entries))
                record["annotation_entries"] = [
                    {"name": e.filename, "bytes": e.file_size}
                    for e in entries
                    if e.filename.endswith((".json", ".txt", ".csv"))
                ][:80]
                (OUTPUT / f"{name}_archive_names.json").write_text(
                    json.dumps([e.filename for e in entries], indent=2)
                )
                annotations = [
                    e for e in entries if e.filename.endswith(".json") and e.file_size < 24_000_000
                ]
                annotations.sort(key=lambda e: e.file_size)
                for entry in annotations[:2]:
                    document = json.loads(archive.read(entry))
                    (OUTPUT / f"{name}_{Path(entry.filename).name}").write_text(
                        json.dumps(document)
                    )
                    annotations_data = document.get("annotations", [])
                    record.setdefault("sample_annotations", []).append(
                        {
                            "name": entry.filename,
                            "keys": list(document),
                            "categories": document.get("categories"),
                            "images": len(document.get("images", [])),
                            "annotations": len(annotations_data),
                            "example": annotations_data[:2],
                        }
                    )
                images = [e for e in entries if e.filename.lower().endswith((".jpg", ".png"))]
                if images:
                    entry = images[0]
                    (OUTPUT / f"{name}_sample{Path(entry.filename).suffix}").write_bytes(
                        archive.read(entry)
                    )
                    record["sample_image"] = entry.filename
            record["range_bytes_transferred"] = remote.transferred
        except Exception as error:
            record["inspection_error"] = str(error)
        (OUTPUT / "audit.json").write_text(json.dumps(report, indent=2))
        print(json.dumps({name: record}, ensure_ascii=False)[:6000], flush=True)
    spread = Path("D:/SAM3DepthPro/SPREAD_labels")
    report["SPREAD_local"] = []
    for scene in sorted(spread.iterdir()):
        if not scene.is_dir():
            continue
        files = list(scene.rglob("*"))
        table = scene / "obj_info_final.xlsx"
        mappings = sorted((scene / "instance_segmentation").glob("*.txt"))
        record = {
            "scene": scene.name,
            "extensions": dict(Counter(p.suffix for p in files if p.is_file())),
            "parameter_sample_rows": xlsx_rows(table) if table.exists() else None,
            "instance_mapping_example": mappings[0].read_text() if mappings else None,
        }
        report["SPREAD_local"].append(record)
    report["SPREAD_palette_rows"] = xlsx_rows(spread / "color_palette.xlsx")
    (OUTPUT / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Local SPREAD metadata inspected", flush=True)


if __name__ == "__main__":
    main()
