"""Audit the extracted CanaTree100 release before training."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(r"D:\TreeWeaver\data\external\canatree100\extracted\CanaTree100")
OUT = Path(r"D:\TreeWeaver\reports\canatree100-audit-2026-11-03")
OUT.mkdir(parents=True, exist_ok=True)
FOLDS = [f"fold_{i:02d}" for i in range(5)]
SPLITS = ["train", "val", "test"]


def names(document):
    return [Path(image["file_name"]).name for image in document["images"]]


def main():
    report = {"root": str(ROOT), "folds": {}, "warnings": []}
    all_sets = {}
    for fold in FOLDS:
        report["folds"][fold] = {}
        for split in SPLITS:
            path = ROOT / "annotations" / fold / f"{split}_{fold}.json"
            document = json.loads(path.read_text(encoding="utf-8"))
            image_names = names(document)
            annotations = document["annotations"]
            polygon_lengths = []
            for annotation in annotations:
                if annotation.get("segmentation"):
                    polygon_lengths.extend(len(poly) for poly in annotation["segmentation"])
            report["folds"][fold][split] = {
                "images": len(document["images"]),
                "annotations": len(annotations),
                "categories": document["categories"],
                "unique_images": len(set(image_names)),
                "polygon_count": len(polygon_lengths),
                "polygon_vertices_median": sorted(polygon_lengths)[len(polygon_lengths) // 2] if polygon_lengths else 0,
                "iscrowd_values": dict(Counter(annotation.get("iscrowd") for annotation in annotations)),
                "first_images": image_names[:3],
            }
            all_sets[(fold, split)] = set(image_names)

        overlaps = {}
        for i, left in enumerate(SPLITS):
            for right in SPLITS[i + 1 :]:
                overlaps[f"{left}__{right}"] = sorted(all_sets[(fold, left)] & all_sets[(fold, right)])
        report["folds"][fold]["overlaps"] = overlaps

    # Compare the same split across folds, and known suspicious pair.
    cross = {}
    for split in SPLITS:
        for i, left in enumerate(FOLDS):
            for right in FOLDS[i + 1 :]:
                key = f"{split}:{left}__{right}"
                overlap = sorted(all_sets[(left, split)] & all_sets[(right, split)])
                if overlap:
                    cross[key] = overlap
    report["cross_fold_overlaps"] = cross
    report["known_val02_test03"] = sorted(all_sets[("fold_02", "val")] & all_sets[("fold_03", "test")])

    rgb = {path.name for path in (ROOT / "images").glob("*.png")}
    depth = {path.name for path in (ROOT / "images_depth").glob("*.png")}
    neural = {path.name for path in (ROOT / "images_depth_neural").glob("*.png")}
    used = set().union(*all_sets.values())
    report["inventory"] = {
        "rgb": len(rgb),
        "depth": len(depth),
        "depth_neural": len(neural),
        "used_by_annotations": len(used),
        "unused_rgb": sorted(rgb - used),
        "annotation_images_missing_rgb": sorted(used - rgb),
        "rgb_without_depth": sorted(rgb - depth),
    }
    if report["known_val02_test03"]:
        report["warnings"].append(
            f"fold_02 validation and fold_03 test share {len(report['known_val02_test03'])} images"
        )
    if len(rgb) != 100:
        report["warnings"].append(f"expected 100 RGB images, found {len(rgb)}")
    (OUT / "audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "folds"}, indent=2)[:4000])
    print("wrote", OUT / "audit.json")


if __name__ == "__main__":
    main()
