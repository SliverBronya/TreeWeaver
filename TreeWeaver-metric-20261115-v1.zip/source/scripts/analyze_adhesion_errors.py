"""Where do trunk-mask errors actually live? Join probe rows with GT geometry.

Analysis only, no model. Answers three questions that decide the next ladder step:

1. How wide are the trunks in pixels? Is the mask resolution the limit?
2. Do the CanaTree trunk polygons fill across occluders (no interior holes)? If
   so, a higher-resolution prediction that excludes branches is penalised by the
   label convention, not by being wrong.
3. Does IoU degrade with trunk width, i.e. is thin-trunk error the dominant term?
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from probe_canatree_adhesion import decode_image, load_fold  # noqa: E402

PROBES = {
    "prompt": ROOT / "reports/canatree-adhesion-probe-2026-11-03",
    "crop": ROOT / "reports/canatree-crop-probe-2026-11-03",
}


def hole_count(mask: np.ndarray) -> int:
    """Interior background components: a filled trunk polygon has none."""
    padded = np.pad(mask.astype(np.uint8), 1)
    count, labels = cv2.connectedComponents(padded, connectivity=4)
    background = labels == labels[0, 0]
    interior = 0
    for component in range(1, count):
        region = labels == component
        if not region.any() or not background.any():
            continue
        if region[0, :].any() or region[-1, :].any() or region[:, 0].any() or region[:, -1].any():
            continue
        interior += 1
    return interior


def geometry(split: str) -> dict:
    by_image, grouped, _ = load_fold(split)
    rows = {}
    for image_id, image in by_image.items():
        _, boxes, masks, height, width = decode_image(image, grouped[image_id])
        for index in range(len(masks)):
            x0, y0, x1, y1 = boxes[index]
            rows[f"{image['file_name']}:{index}"] = {
                "box_width_px": float(x1 - x0),
                "box_height_px": float(y1 - y0),
                "mask_area": int(masks[index].sum()),
                "fill_ratio_in_box": float(masks[index].sum() / max(1.0, (x1 - x0) * (y1 - y0))),
                "spans_full_height": bool(y1 - y0 > 0.9 * height),
                "interior_holes": hole_count(masks[index]),
                "image_width": width,
            }
    return rows


def load_rows(path: Path) -> dict:
    document = json.loads(path.read_text(encoding="utf-8"))
    return {f"{row['image']}:{row['tree_index']}": row["metrics"] for row in document}


def summarise(name: str, metrics: dict, geometry_rows: dict) -> dict:
    keys = [key for key in metrics if key in geometry_rows]
    widths = np.array([geometry_rows[key]["box_width_px"] for key in keys])
    ious = np.array([metrics[key]["iou"] for key in keys])
    neighbour = np.array([metrics[key]["neighbour_fraction"] for key in keys])
    recall = np.array([metrics[key]["recall"] for key in keys])
    order = np.argsort(widths)
    bins = []
    for chunk in np.array_split(order, 5):
        if not len(chunk):
            continue
        bins.append(
            {
                "width_px_range": [float(widths[chunk].min()), float(widths[chunk].max())],
                "trees": int(len(chunk)),
                "mean_iou": float(ious[chunk].mean()),
                "mean_recall": float(recall[chunk].mean()),
                "mean_neighbour_fraction": float(neighbour[chunk].mean()),
            }
        )
    correlation = float(np.corrcoef(widths, ious)[0, 1]) if len(keys) > 2 else 0.0
    holes = np.array([geometry_rows[key]["interior_holes"] for key in keys])
    return {
        "condition": name,
        "trees": len(keys),
        "mean_iou": float(ious.mean()),
        "iou_by_trunk_width_quintile": bins,
        "width_iou_correlation": correlation,
        "fraction_with_interior_holes": float((holes > 0).mean()),
        "mean_interior_holes": float(holes.mean()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("fresh output directory required")
    args.output.mkdir(parents=True)

    report = {}
    for split in ("val", "test"):
        geometry_rows = geometry(split)
        report[split] = {"geometry": {}, "conditions": {}}
        widths = np.array([row["box_width_px"] for row in geometry_rows.values()])
        holes = np.array([row["interior_holes"] for row in geometry_rows.values()])
        fills = np.array([row["fill_ratio_in_box"] for row in geometry_rows.values()])
        report[split]["geometry"] = {
            "trunks": len(geometry_rows),
            "width_px_median": float(np.median(widths)),
            "width_px_p10_p90": [
                float(np.percentile(widths, 10)),
                float(np.percentile(widths, 90)),
            ],
            "fraction_narrower_than_32px": float((widths < 32).mean()),
            "fraction_with_interior_holes": float((holes > 0).mean()),
            "mean_interior_holes": float(holes.mean()),
            "mean_fill_ratio_in_box": float(fills.mean()),
        }
        for label, directory in PROBES.items():
            for path in sorted(directory.glob(f"per_tree_*_{split}_*.json")):
                condition = f"{label}:{path.stem}"
                report[split]["conditions"][condition] = summarise(
                    condition, load_rows(path), geometry_rows
                )
        print(json.dumps({split: report[split]["geometry"]}), flush=True)
    (args.output / "analysis.json").write_text(
        json.dumps(report, indent=2, allow_nan=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
