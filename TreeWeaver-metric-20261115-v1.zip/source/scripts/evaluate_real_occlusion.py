"""Real-photo proxy test for the occlusion-aware decoder (20260411 captures).

Protocol per detected tree:
1. stock SAM2 segments the unoccluded photo -> pseudo-amodal reference;
2. a rectangle is pasted over 25-65% of that reference;
3. the trained decoder predicts the visible part and the amodal hypothesis;
4. metrics: visible IoU, amodal IoU vs reference, convex-hull baseline,
   completion gain, and visibility error against the known occlusion rate.

The reference is another model's visible mask, not human amodal truth.
No metric scale and no tree dimension are produced.
"""

from __future__ import annotations

import argparse
import inspect
import json
import statistics
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from transformers import (
    AutoModelForZeroShotObjectDetection,
    AutoProcessor,
    Sam2Model,
    Sam2Processor,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402


def snapshot(repo: str) -> Path:
    base = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{repo.replace('/', '--')}"
    return sorted((base / "snapshots").iterdir())[-1]


def iou(prediction: np.ndarray, target: np.ndarray) -> float:
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def hull_of(mask: np.ndarray) -> np.ndarray:
    contours = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )[0]
    hull = np.zeros_like(mask, np.uint8)
    if contours:
        cv2.fillPoly(hull, [cv2.convexHull(np.vstack(contours))], 1)
    return hull.astype(bool)


def make_rect(mask: np.ndarray, rng: np.random.Generator):
    ys, xs = np.nonzero(mask)
    area = max(int(mask.sum()), 1)
    centre_x, centre_y = float(np.median(xs)), float(np.median(ys))
    height, width = mask.shape
    side = max(12, int(round(np.sqrt(0.5 * area))))
    for _ in range(6):
        half = side // 2
        x0 = int(min(max(centre_x - half, 0), width - side))
        y0 = int(min(max(centre_y - half, 0), height - side))
        rect = np.zeros_like(mask)
        rect[y0 : y0 + side, x0 : x0 + side] = True
        rate = float((rect & mask).sum()) / area
        if 0.25 <= rate <= 0.65:
            return rect, rate
        side = max(10, int(round(side * (1.15 if rate < 0.25 else 0.85))))
    return rect, rate


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--images", type=Path, default=ROOT / "data" / "20260411")
    parser.add_argument("--count", type=int, default=30)
    parser.add_argument("--boxes-per-image", type=int, default=1)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    sam2_path = snapshot("facebook/sam2.1-hiera-tiny")
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12).to(args.device).eval()
    payload = torch.load(args.checkpoint, map_location=args.device, weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=True)

    detector_path = snapshot("IDEA-Research/grounding-dino-tiny")
    detector_processor = AutoProcessor.from_pretrained(detector_path, local_files_only=True)
    detector = (
        AutoModelForZeroShotObjectDetection.from_pretrained(
            detector_path, local_files_only=True
        )
        .to(args.device)
        .eval()
    )
    parameters = inspect.signature(
        detector_processor.post_process_grounded_object_detection
    ).parameters
    threshold_keyword = "threshold" if "threshold" in parameters else "box_threshold"

    paths = sorted(args.images.glob("*.jpg"))[: args.count]
    rng = np.random.default_rng(7)
    rows = []
    skipped = 0
    for path in paths:
        image_bgr = cv2.imread(str(path))
        if image_bgr is None:
            skipped += 1
            continue
        height, width = image_bgr.shape[:2]
        image = Image.fromarray(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB))
        detector_inputs = detector_processor(
            images=image, text="tree.", return_tensors="pt"
        ).to(args.device)
        with torch.no_grad():
            detector_outputs = detector(**detector_inputs)
        detected = detector_processor.post_process_grounded_object_detection(
            detector_outputs,
            detector_inputs.input_ids,
            text_threshold=0.22,
            target_sizes=[image.size[::-1]],
            **{threshold_keyword: 0.28},
        )[0]
        boxes = detected["boxes"].detach().cpu().numpy()
        scores = detected["scores"].detach().cpu().numpy()
        if len(boxes) == 0:
            skipped += 1
            continue
        scale = np.array([1024 / width, 1024 / height, 1024 / width, 1024 / height], np.float32)
        for rank in np.argsort(scores)[::-1][: args.boxes_per_image]:
            box = boxes[rank]
            scaled = torch.as_tensor(box * scale, device=args.device)[None, None]
            base_inputs = processor(images=image, return_tensors="pt")
            with torch.no_grad():
                base = sam2(
                    pixel_values=base_inputs["pixel_values"].to(args.device),
                    input_boxes=scaled,
                    multimask_output=True,
                )
                selected = int(torch.argmax(base.iou_scores[0, 0]))
                reference = processor.post_process_masks(
                    base.pred_masks[:, :, selected : selected + 1],
                    original_sizes=[[height, width]],
                )[0][0, 0].cpu().numpy() > 0
            if int(reference.sum()) < 2000:
                skipped += 1
                continue

            with torch.no_grad():
                plain = model(
                    base_inputs["pixel_values"].to(args.device), input_boxes=scaled
                )
                plain_mask = processor.post_process_masks(
                    plain["masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
            drift_iou = iou(plain_mask, reference)

            rect, rate = make_rect(reference, rng)
            occluded = image_bgr.copy()
            occluded[rect] = (85, 85, 85)
            occluded_image = Image.fromarray(cv2.cvtColor(occluded, cv2.COLOR_BGR2RGB))
            occluded_inputs = processor(images=occluded_image, return_tensors="pt")
            with torch.no_grad():
                output = model(
                    occluded_inputs["pixel_values"].to(args.device), input_boxes=scaled
                )
                pred_visible = processor.post_process_masks(
                    output["masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
                pred_amodal = processor.post_process_masks(
                    output["amodal_masks"], original_sizes=[[height, width]]
                )[0][0, 0].cpu().numpy() > 0
            visible_truth = reference & ~rect
            hull = hull_of(visible_truth)
            visibility = float(output["visibility"][0, 0, 0])
            row = {
                "image": path.name,
                "score": float(scores[rank]),
                "rate": rate,
                "modal_iou_visible": iou(pred_visible, visible_truth),
                "amodal_iou_reference": iou(pred_amodal, reference),
                "hull_iou_reference": iou(hull, reference),
                "completion_gain": iou(pred_amodal, reference) - iou(hull, reference),
                "visibility_error": abs(visibility - (1.0 - rate)),
                "drift_iou": drift_iou,
            }
            rows.append(row)
            print(json.dumps(row), flush=True)

    def summarise(key):
        values = [row[key] for row in rows]
        return {
            "mean": float(np.mean(values)),
            "median": float(statistics.median(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }

    keys = [
        "modal_iou_visible",
        "amodal_iou_reference",
        "hull_iou_reference",
        "completion_gain",
        "visibility_error",
        "drift_iou",
    ]
    summary = {
        "checkpoint": str(args.checkpoint),
        "images_attempted": len(paths),
        "samples": len(rows),
        "skipped": skipped,
        "metrics": {key: summarise(key) for key in keys},
        "note": (
            "pseudo-amodal reference is stock SAM2 on the unoccluded photo; "
            "this is a proxy test, not human amodal truth and not measurement accuracy"
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps({"summary": summary, "rows": rows}, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    print(f"saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
