"""Step 1: train only the ownership head on the 500-image fig dataset."""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports" / "fig-500-v2-2026-10-31"
CKPT = ROOT / "reports" / "composite-occlusion-500step-2026-10-26" / "decoder_best.pth"
RES = 1024
MASK = 256


def load_rgb(path: Path, mean, std):
    image = Image.open(path).convert("RGB").resize((RES, RES), Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.asarray(mean)) / np.asarray(std)
    return torch.from_numpy(array).permute(2, 0, 1)


def load_rgba(path: Path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def resize_mask(mask: np.ndarray):
    tensor = torch.from_numpy(mask.astype(np.float32))[None, None]
    return F.interpolate(tensor, size=(MASK, MASK), mode="nearest")[0, 0] > 0.5


class FigOwnership(Dataset):
    def __init__(self, ids, mean, std):
        self.ids = ids
        self.mean = mean
        self.std = std

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, index):
        image_id = self.ids[index]
        scene = f"{image_id:06d}"
        meta = json.loads((DATA / "meta" / f"{scene}.json").read_text(encoding="utf-8"))
        mask_dir = DATA / "masks" / scene
        amodal = [load_rgba(p) for p in sorted(mask_dir.glob("amodal_*.png"))]
        visible = [load_rgba(p) for p in sorted(mask_dir.glob("visible_*.png"))]
        count = len(amodal)
        boxes = []
        for mask in amodal:
            ys, xs = np.where(mask)
            boxes.append([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1])
        boxes = torch.tensor(boxes, dtype=torch.float32)
        boxes[:, [0, 2]] *= RES / 640.0
        boxes[:, [1, 3]] *= RES / 360.0

        targets = torch.stack([resize_mask(mask) for mask in visible])
        ownership = torch.zeros((MASK, MASK), dtype=torch.long)
        for i, mask in enumerate(targets):
            ownership[mask] = i + 1

        front_to_back = meta["layer_order_front_to_back"]
        index_by_name = {name: i for i, name in enumerate(meta["trees"])}
        order = [index_by_name[name] for name in front_to_back]
        rank = {tree_index: rank_index for rank_index, tree_index in enumerate(order)}
        layer = torch.zeros((count, count), dtype=torch.float32)
        for i in range(count):
            for j in range(count):
                layer[i, j] = 1.0 if rank[i] < rank[j] else 0.0

        image = load_rgb(DATA / "images" / f"{scene}.png", self.mean, self.std)
        return {
            "image": image,
            "boxes": boxes,
            "visible": targets,
            "ownership": ownership,
            "layer": layer,
            "id": image_id,
        }


def build_model(device):
    from transformers import Sam2Processor

    base = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "hub"
        / "models--facebook--sam2.1-hiera-tiny"
        / "snapshots"
    )
    snapshots = sorted(path for path in base.iterdir() if path.is_dir())
    snapshot = snapshots[-1]
    processor = Sam2Processor.from_pretrained(snapshot, local_files_only=True)
    mean = processor.image_processor.image_mean
    std = processor.image_processor.image_std
    sam2 = Sam2Model.from_pretrained(
        snapshot, local_files_only=True
    ).to(device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(device)
    checkpoint = torch.load(CKPT, map_location="cpu")
    state = checkpoint["decoder"] if "decoder" in checkpoint else checkpoint
    missing, unexpected = model.decoder.load_state_dict(state, strict=False)
    print(json.dumps({"missing": len(missing), "unexpected": len(unexpected)}), flush=True)
    return model, mean, std


def trainable(model):
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for module in (
        model.decoder.ownership_projection,
        model.decoder.ownership_conv,
        model.decoder.ownership_bg,
    ):
        for parameter in module.parameters():
            parameter.requires_grad_(True)
    model.decoder.eval()
    return [p for p in model.parameters() if p.requires_grad]


def evaluate(model, loader, device, limit=8):
    model.eval()
    correct = 0
    total = 0
    ious = []
    with torch.no_grad():
        for index, batch in enumerate(loader):
            if index >= limit:
                break
            output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
            prediction = output["ownership"].argmax(dim=1)[0].cpu()
            target = batch["ownership"][0]
            foreground = target > 0
            if foreground.any():
                correct += int((prediction[foreground] == target[foreground]).sum())
                total += int(foreground.sum())
            masks = output["masks"][0, :, 0].sigmoid() > 0.5
            for i in range(masks.shape[0]):
                target_mask = batch["visible"][0, i]
                intersection = (masks[i].cpu() & target_mask).sum().item()
                union = (masks[i].cpu() | target_mask).sum().item()
                if union:
                    ious.append(intersection / union)
    return {
        "ownership_accuracy_foreground": correct / max(1, total),
        "visible_iou": float(np.mean(ious)) if ious else 0.0,
        "pixels": total,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--eval-every", type=int, default=10)
    parser.add_argument("--train-limit", type=int, default=200)
    parser.add_argument("--val-limit", type=int, default=20)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "reports" / "ownership-step-2026-11-06",
    )
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"output exists: {args.output}")
    args.output.mkdir(parents=True)
    random.seed(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, mean, std = build_model(device)
    ids = sorted(int(p.stem) for p in (DATA / "meta").glob("*.json"))
    train_ids = [i for i in ids if i % 5 != 0][: args.train_limit]
    val_ids = [i for i in ids if i % 5 == 0][: args.val_limit]
    train_loader = DataLoader(FigOwnership(train_ids, mean, std), batch_size=1, shuffle=True)
    val_loader = DataLoader(FigOwnership(val_ids, mean, std), batch_size=1)
    parameters = trainable(model)
    print(
        json.dumps(
            {
                "trainable": sum(p.numel() for p in parameters),
                "train": len(train_ids),
                "val": len(val_ids),
            }
        ),
        flush=True,
    )
    optimizer = torch.optim.AdamW(parameters, lr=args.lr)
    iterator = iter(train_loader)
    history = []
    best = -1.0
    for step in range(1, args.steps + 1):
        model.train()
        model.decoder.eval()
        optimizer.zero_grad(set_to_none=True)
        try:
            batch = next(iterator)
        except StopIteration:
            iterator = iter(train_loader)
            batch = next(iterator)
        output = model(batch["image"].to(device), input_boxes=batch["boxes"].to(device))
        logits = output["ownership_logits"][0].unsqueeze(0)
        target = batch["ownership"][0].to(device).unsqueeze(0)
        weight = torch.tensor([0.2, 1, 1, 1, 1], device=device)[: logits.shape[1]]
        loss = F.cross_entropy(logits, target, weight=weight)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        entry = {"step": step, "loss": float(loss.detach())}
        history.append(entry)
        print(json.dumps(entry), flush=True)
        if step % args.eval_every == 0 or step == args.steps:
            metrics = evaluate(model, val_loader, device)
            print(json.dumps({"eval_step": step, **metrics}), flush=True)
            history.append({"eval_step": step, **metrics})
            if metrics["ownership_accuracy_foreground"] > best:
                best = metrics["ownership_accuracy_foreground"]
                torch.save(
                    {"decoder": model.decoder.state_dict(), "step": step, "metrics": metrics},
                    args.output / "ownership_best.pth",
                )
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(json.dumps({"best_foreground_accuracy": best, "output": str(args.output)}), flush=True)


if __name__ == "__main__":
    main()
