"""Paired weak-anchor vs no-anchor RGB refinement on a fixed local development split.

Uses predicted anchors only. Existing test split is now development validation,
not an untouched publication test after iterative tuning.
"""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--extra-packages", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if not 1 <= args.steps <= 1000 or args.output.exists():
        parser.error("Require1..1000steps and a fresh output directory")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, str(args.extra_packages.resolve()))
    sys.path.insert(0, str(args.source.resolve()))
    import cv2
    import numpy as np
    import torch
    from torch import nn
    from torch.nn import functional as F

    from data import cfg, set_cfg

    torch.set_default_tensor_type(torch.cuda.FloatTensor)
    torch.manual_seed(args.seed)
    set_cfg("convex_synthtree_focal")
    baseline_run = json.loads((args.run / "run.json").read_text(encoding="utf-8"))
    size = baseline_run["image_size"]
    cfg.max_size = (size, size)
    cfg.fixed_size = True
    cfg.freeze_bn = True
    cfg.mask_proto_debug = False
    from convexmask import ConvexMask
    from layers.output_utils import postprocess
    from utils.augmentations import FastBaseTransform

    from workers.tree_models.stem_ownership import StemOwnershipHead, ownership_loss
    from workers.tree_models.stem_proxy import lower_mask_proxy

    baseline = ConvexMask().cuda()
    baseline.load_state_dict(
        torch.load(args.run / "pilot_checkpoint.pth", map_location="cuda", weights_only=True),
        strict=True,
    )
    baseline.requires_grad_(False)
    baseline.train()  # Raw prototypes, with frozen BN and no weight updates.
    transform = FastBaseTransform()
    manifest = json.loads((args.run / "manifest.json").read_text(encoding="utf-8"))
    args.output.mkdir(parents=True)
    cache = {}
    with torch.no_grad():
        for record in manifest["train"] + manifest["test"]:
            original = cv2.imread(record["image"])
            image = cv2.resize(original, (size, size))
            raw = baseline(transform(torch.as_tensor(image).float()[None]))
            features = raw["proto"].permute(0, 3, 1, 2).detach()
            raw["conf"] = raw["conf"].sigmoid()
            raw["center"] = raw["center"].sigmoid()
            detected = postprocess(baseline.detect(raw, baseline), size, size, score_threshold=0.3)
            coarse = np.zeros((size, size), bool)
            if detected[0].numel():
                # Score selection only. GT never selects a detection or builds a seed.
                selected = int(detected[1].argmax())
                coarse = detected[4][selected].bool().cpu().numpy()
            proxy = lower_mask_proxy(coarse)
            fh, fw = features.shape[-2:]
            stem = torch.as_tensor(cv2.resize(proxy.astype(np.float32), (fw, fh)))
            support = cv2.dilate(coarse.astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
            label = json.loads(Path(record["annotation"]).read_text(encoding="utf-8"))
            target = np.zeros(original.shape[:2], np.uint8)
            for shape in label["shapes"]:
                if shape["label"] == "tree":
                    points = np.round(np.asarray(shape["points"])).astype(np.int32)
                    cv2.fillPoly(target, [points], 1)
            resized_gt = cv2.resize(target, (fw, fh), interpolation=cv2.INTER_NEAREST)
            cache[record["image"]] = {
                "features": features,
                "stem": stem[None, None],
                "labels": torch.as_tensor(resized_gt, dtype=torch.long)[None],
                "target": target.astype(bool),
                "coarse": coarse,
                "support": support,
                "proxy_pixels": int(proxy.sum()),
                "original": original,
            }
    channels = next(iter(cache.values()))["features"].shape[1]
    anchor = StemOwnershipHead(channels).cuda()
    control = nn.Sequential(nn.Conv2d(channels, 32, 1), nn.ReLU(), nn.Conv2d(32, 2, 1)).cuda()
    optimizers = [torch.optim.AdamW(model.parameters(), lr=1e-3) for model in (anchor, control)]
    train = [record for record in manifest["train"] if cache[record["image"]]["proxy_pixels"] > 0]
    if not train:
        raise ValueError("No predicted lower-stem proxies; never fall back to GT anchors")
    history = []
    for step in range(args.steps):
        sample = cache[train[step % len(train)]["image"]]
        losses = []
        for model, optimizer in zip((anchor, control), optimizers, strict=True):
            optimizer.zero_grad(set_to_none=True)
            if model is anchor:
                logits = model(sample["features"], sample["stem"])["logits"]
            else:
                logits = model(sample["features"])
            loss = ownership_loss(logits, sample["labels"])
            if not torch.isfinite(loss):
                raise FloatingPointError("Non-finite refinement loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 10, error_if_nonfinite=True)
            optimizer.step()
            losses.append(float(loss.detach()))
        history.append({"step": step + 1, "anchor_loss": losses[0], "control_loss": losses[1]})
        if (step + 1) % 50 == 0:
            print(json.dumps(history[-1]), flush=True)
    torch.save(
        {
            "anchor": anchor.state_dict(),
            "control": control.state_dict(),
            "channels": channels,
            "steps": args.steps,
        },
        args.output / "refiner_checkpoint.pth",
    )
    rows = []
    with torch.no_grad():
        for record in manifest["test"]:
            sample = cache[record["image"]]
            h, w = sample["target"].shape
            masks = {
                "baseline": cv2.resize(
                    sample["coarse"].astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST
                )
                > 0
            }
            for name, model in (("anchor", anchor), ("control", control)):
                if sample["proxy_pixels"] == 0:
                    masks[name] = masks["baseline"].copy()
                    continue
                logits = (
                    model(sample["features"], sample["stem"])["logits"]
                    if name == "anchor"
                    else model(sample["features"])
                )
                probability = F.interpolate(
                    logits.softmax(1)[:, 1:2], (size, size), mode="bilinear", align_corners=False
                )[0, 0]
                predicted = (probability.cpu().numpy() > 0.5) & sample["support"]
                masks[name] = (
                    cv2.resize(predicted.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
                    > 0
                )
            row = {"image": record["image"], "proxy_pixels": sample["proxy_pixels"], "iou": {}}
            for name, mask in masks.items():
                gt = sample["target"]
                row["iou"][name] = int((mask & gt).sum()) / max(int((mask | gt).sum()), 1)
                overlay = sample["original"].copy()
                overlay[mask] = (0.6 * overlay[mask] + 0.4 * np.array([255, 80, 0])).astype(
                    np.uint8
                )
                destination = args.output / f"{Path(record['image']).stem}_{name}_overlay.png"
                cv2.imwrite(str(destination), overlay)
            rows.append(row)
    report = {
        "mode": "weak-anchor paired RGB development pilot",
        "steps": args.steps,
        "seed": args.seed,
        "training_images_with_proxy": len(train),
        "validation_images": len(rows),
        "anchor_source": "lower narrow region of automatic baseline prediction, no GT seed",
        "same_support_constraint_for_anchor_and_control": True,
        "depth_used": False,
        "baseline_frozen": True,
        "images": rows,
        "mean_iou": {
            name: float(np.mean([row["iou"][name] for row in rows]))
            for name in ("baseline", "anchor", "control")
        },
        "parameters": {
            name: sum(p.numel() for p in model.parameters())
            for name, model in (("anchor", anchor), ("control", control))
        },
        "limitations": [
            "Target outline labels, not precise visible-stem/branch labels",
            "Only three repeatedly used development images, not untouched final test",
            "Single-target refinement, not all-tree ownership validation",
            "Geometric proxy may be wrong; no learned stem detector yet",
            "No tree dimension accuracy tested",
        ],
    }
    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (args.output / "run.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
