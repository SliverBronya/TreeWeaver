"""Separate candidate-mask failures from ownership decisions on development data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
from preview_whole_tree_mainline import compete, masks, read


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    records = read(args.data / "paired-samples.json")["records"]
    totals = {}
    for arm in ("coverage", "coverage_identity"):
        counts = dict.fromkeys(
            (
                "foreign_pixels",
                "foreign_pixels_correct_query_active",
                "foreign_pixels_correct_query_inactive",
                "target_pixels",
                "target_pixels_correct_query_inactive",
                "target_pixels_lost_in_competition",
                "background_false_positive_union_pixels",
            ),
            0,
        )
        for row in records:
            if (
                row["split"] != "validation"
                or row["condition"] != "scene"
                or len(row["instances"]) < 2
            ):
                continue
            target = masks(args.data, row)
            known = ~np.stack(
                [
                    np.asarray(Image.open(args.data / item["raster_unknown"]))[..., 3] > 16
                    for item in row["instances"]
                ]
            ).any(0)
            target &= known
            with np.load(args.run / arm / f"{row['id']}.npz") as saved:
                active = (saved["logits"] > 0) & known
                predicted = (
                    compete(
                        saved["logits"],
                        saved["ownership_logits"] if arm == "coverage_identity" else None,
                    )
                    & known
                )
            union = target.any(0)
            correct_query_active = (active & target).any(0)
            for i in range(len(target)):
                foreign = predicted[i] & union & ~target[i]
                counts["foreign_pixels"] += int(foreign.sum())
                counts["foreign_pixels_correct_query_active"] += int(
                    (foreign & correct_query_active).sum()
                )
                counts["foreign_pixels_correct_query_inactive"] += int(
                    (foreign & ~correct_query_active).sum()
                )
                counts["target_pixels"] += int(target[i].sum())
                counts["target_pixels_correct_query_inactive"] += int(
                    (target[i] & ~active[i]).sum()
                )
                counts["target_pixels_lost_in_competition"] += int(
                    (target[i] & active[i] & ~predicted[i]).sum()
                )
            counts["background_false_positive_union_pixels"] += int(
                (predicted.any(0) & ~union).sum()
            )
        assert counts["foreign_pixels"] == (
            counts["foreign_pixels_correct_query_active"]
            + counts["foreign_pixels_correct_query_inactive"]
        )
        totals[arm] = counts
    result = {
        "scope": "multi-tree validation scenes only; pixel totals, not macro neighbour_fraction",
        "interpretation": "Candidate-only competition cannot recover inactive correct queries.",
        "counts": totals,
    }
    path = args.run / "identity-diagnostic.json"
    with path.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
