"""Separate disconnected false islands from real bridges into neighbouring trunks.

Uses the exact positive prompt point from the frozen-mask experiment, never a
GT mask to select a component. GT is used only for evaluation and diagnosis.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from probe_canatree_adhesion import decode_image, load_fold
from stem_eval_common import mask_row
from train_anchor_competition import safe_anchor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    output = args.run / "connectivity-diagnostic.json"
    if output.exists():
        parser.error("diagnostic already exists")
    images, grouped, _ = load_fold("val")
    rows = []
    connected_leak = total_leak = true_component_leak = fallback_leak = missing_anchors = 0
    for image_id, image in images.items():
        _, boxes, targets, _, _ = decode_image(image, grouped[image_id])
        frozen = np.load(args.run / "frozen" / (Path(image["file_name"]).stem + ".npz"))["masks"]
        refined = []
        for index, prediction in enumerate(frozen):
            anchor = safe_anchor(targets[index], boxes[index])
            x, y = np.rint(anchor).astype(int)
            _, labels = cv2.connectedComponents(prediction.astype(np.uint8), connectivity=8)
            label = labels[y, x]
            # A failed positive prompt is not repaired using GT shape information.
            kept = labels == label if label > 0 else prediction.copy()
            foreign = targets[np.arange(len(targets)) != index].any(0) & ~targets[index]
            leaked = prediction & foreign
            total_leak += int(leaked.sum())
            connected_leak += int((kept & leaked).sum())
            if label > 0:
                true_component_leak += int((kept & leaked).sum())
            else:
                fallback_leak += int(leaked.sum())
                missing_anchors += 1
            others = [target for j, target in enumerate(targets) if j != index]
            rows.append(
                mask_row(f"{image['file_name']}:{index}", kept, targets[index], others=others)
            )
            refined.append(kept)
        folder = args.run / "anchor_component"
        folder.mkdir(exist_ok=True)
        np.savez_compressed(folder / (Path(image["file_name"]).stem + ".npz"), masks=refined)
    summary = {
        key: float(np.mean([row[key] for row in rows]))
        for key in ("iou", "recall", "precision", "boundary_f1", "neighbour_fraction")
    }
    report = {
        "scope": "same validation and prompts; no train/test changes",
        "heuristic_summary": summary,
        "total_foreign_pixels": total_leak,
        "foreign_pixels_remaining_after_component_selection": connected_leak,
        "foreign_fraction_retained_by_filter": connected_leak / max(total_leak, 1),
        "true_anchor_component_foreign_pixels": true_component_leak,
        "foreign_pixels_preserved_on_missing_anchor": fallback_leak,
        "missing_positive_anchors": missing_anchors,
        "rows": rows,
    }
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}, indent=2))


if __name__ == "__main__":
    main()
