"""Contact sheet of fig-tree variants to pick one with a visible trunk."""

from __future__ import annotations

import math
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
OUT = Path(r"D:\TreeWeaver\reports\fig-variants")
NUMBERS = [23, 24, 16, 30, 5, 20, 3, 13]


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 512
    scene.render.resolution_y = 512
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = False
    scene.world = bpy.data.worlds.new("w")
    scene.world.use_nodes = True
    scene.world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.18, 0.2, 0.22, 1)
    scene.world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.8


def import_tree(path):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [o for o in bpy.data.objects if o not in before]
    meshes = [o for o in new if o.type == "MESH" and o.name not in {"Cube", "Camera", "Light"}]
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    pts = [tree.matrix_world @ Vector(c) for c in tree.bound_box]
    z0 = min(p.z for p in pts)
    z1 = max(p.z for p in pts)
    s = 10.0 / max(z1 - z0, 1e-6)
    tree.scale = tuple(v * s for v in tree.scale)
    bpy.context.view_layer.update()
    pts = [tree.matrix_world @ Vector(c) for c in tree.bound_box]
    tree.location.z -= min(p.z for p in pts)
    tree.location.x -= (min(p.x for p in pts) + max(p.x for p in pts)) / 2
    tree.location.y -= (min(p.y for p in pts) + max(p.y for p in pts)) / 2
    return tree


def camera():
    bpy.ops.object.camera_add(location=(0, -24, 5.0))
    cam = bpy.context.object
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = 12
    look = Vector((0, 0, 5))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for number in NUMBERS:
        path = ROOT / f"realistic_hd_common_fig_tree_{number}30.glb"
        if not path.exists():
            continue
        reset()
        import_tree(path)
        camera()
        bpy.ops.object.light_add(type="SUN", location=(0, -8, 15))
        sun = bpy.context.object
        sun.data.energy = 3.0
        sun.rotation_euler = (math.radians(55), 0, math.radians(30))
        bpy.context.scene.render.filepath = str(OUT / f"{number}.png")
        bpy.ops.render.render(write_still=True)
        print("saved", number)


if __name__ == "__main__":
    main()
