"""Audit Grounding DINO + SAM2 exploratory masks without using metric truth."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
import numpy.typing as npt

from treeweaver.measurement.image_readiness import assess_single_image_measurement
from treeweaver.visibility.image_complexity import audit_target_view
from treeweaver.visibility.part_consistency import assess_tree_part_consistency


def _read_mask(path: Path) -> npt.NDArray[np.bool_]:
    image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(path)
    return image > 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("experiment_report")
    parser.add_argument("output_json")
    parser.add_argument("--trunk-refinement-report")
    args = parser.parse_args()
    source = Path(args.experiment_report).resolve()
    destination = Path(args.output_json).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    report = json.loads(source.read_text(encoding="utf-8"))
    if report.get("schema_version") != "whole-tree-zero-shot-experiment-1.0":
        raise ValueError("unsupported segmentation experiment report")
    refinement_by_name: dict[str, dict[str, object]] = {}
    if args.trunk_refinement_report:
        refinement = json.loads(Path(args.trunk_refinement_report).read_text(encoding="utf-8"))
        if refinement.get("schema_version") != "root-seeded-sam2-trunk-pilot-1.0":
            raise ValueError("unsupported trunk refinement report")
        refinement_by_name = {str(item["filename"]): item for item in refinement["records"]}
    records: list[dict[str, object]] = []
    for item in report["records"]:
        record: dict[str, object] = {"filename": item["filename"]}
        trunk_item = refinement_by_name.get(str(item["filename"])) if refinement_by_name else item
        if "failure" in item or trunk_item is None or "failure" in trunk_item:
            record.update({"accepted": False, "reasons": ["missing segmentation output"]})
        else:
            whole = _read_mask(Path(item["mask_path"]))
            trunk_path = trunk_item.get("trunk_mask_path", trunk_item.get("mask_path"))
            if trunk_path is None:
                record.update({"accepted": False, "reasons": ["missing trunk mask"]})
                records.append(record)
                continue
            trunk = _read_mask(Path(str(trunk_path)))
            audit = assess_tree_part_consistency(whole, trunk)
            record.update(
                {
                    "accepted": audit.accepted,
                    "trunk_area_fraction": audit.trunk_area_fraction,
                    "trunk_outside_fraction": audit.trunk_outside_fraction,
                    "reasons": list(audit.reasons),
                    "sam_predicted_iou": trunk_item.get(
                        "trunk_sam_predicted_iou", trunk_item.get("sam_predicted_iou")
                    ),
                    "overlay_path": trunk_item.get("overlay_path"),
                }
            )
            if audit.accepted:
                view_audit = audit_target_view(whole, trunk, whole & ~trunk)
                gates = assess_single_image_measurement(view_audit)
                record["image_challenges"] = {
                    evidence.cue.value: evidence.score for evidence in view_audit.evidence
                }
                record["image_parameter_gates"] = {
                    gate.parameter.value: {
                        "readiness": gate.readiness.value,
                        "reasons": list(gate.reasons),
                    }
                    for gate in gates
                }
        records.append(record)
    payload = {
        "schema_version": "tree-part-consistency-pilot-1.0",
        "source_report": str(source),
        "trunk_refinement_report": (
            str(Path(args.trunk_refinement_report).resolve())
            if args.trunk_refinement_report
            else None
        ),
        "thresholds": {"maximum_trunk_area_fraction": 0.5, "maximum_outside_fraction": 0.01},
        "interpretation": (
            "Exploratory structural rejection; not a validated segmentation accuracy metric"
        ),
        "summary": {
            "attempted": len(records),
            "accepted": sum(bool(item["accepted"]) for item in records),
            "rejected": sum(not bool(item["accepted"]) for item in records),
        },
        "records": records,
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(payload["summary"], ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
