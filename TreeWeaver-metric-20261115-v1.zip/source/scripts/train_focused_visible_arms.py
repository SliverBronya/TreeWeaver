"""Controlled visible arms on the target-centric 60-scene cohort."""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import Sam2Model

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from deployment_preprocess import letterbox  # noqa: E402
from sam2_occlusion import Sam2OcclusionModel  # noqa: E402

DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
BASE = ROOT / "reports/professional-stage4-coupling-2026-11-06/best.pth"
OUT = ROOT / "reports/focused-visible-arms-2026-11-10"
RES, MASK = 1024, 256


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def sample(row):
    image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
    lb = letterbox(image)
    array = np.asarray(lb.image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    visible = mask(DATA / row["scene"] / "visible_target.png")
    ys, xs = np.where(visible)
    box = np.array([[xs.min(), ys.min(), xs.max() + 1, ys.max() + 1]], dtype=np.float32)
    box = lb.boxes(box)
    target = np.asarray(
        Image.fromarray(visible.astype(np.uint8) * 255).resize((MASK, MASK), Image.NEAREST)
    ) > 127
    return (
        torch.from_numpy(array).permute(2, 0, 1)[None],
        torch.from_numpy(box)[None].float(),
        torch.from_numpy(target.astype(np.float32))[None, None],
    )


def build(device, arm):
    base = Sam2Model.from_pretrained(snapshot(), local_files_only=True)
    model = Sam2OcclusionModel(
        base,
        encoder_lora_rank=4 if arm in {"lora_only", "lora_pf"} else 0,
        encoder_focus_rank=16 if arm in {"encoder_pf_only", "lora_pf"} else 0,
        encoder_focus_chunked=True,
        encoder_focus_null_token=True,
    )
    payload = torch.load(BASE, map_location="cpu", weights_only=True)
    model.decoder.load_state_dict(payload["decoder"], strict=False)
    model.to(device)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for name, parameter in model.named_parameters():
        enabled = (
            arm in {"lora_only", "lora_pf"} and name.endswith(("lora_a", "lora_b"))
        ) or (
            arm in {"encoder_pf_only", "lora_pf"} and name.startswith("encoder_focus.")
        ) or (
            arm == "mask_readout"
            and name.startswith(
                (
                    "decoder.mask_tokens",
                    "decoder.output_hypernetworks_mlps",
                    "decoder.iou_token",
                    "decoder.obj_score_token",
                )
            )
        )
        if enabled:
            parameter.requires_grad_(True)
    return model


def evaluate(model, rows, device):
    model.eval()
    values = []
    with torch.no_grad():
        for row in rows:
            image, box, target = sample(row)
            output = model(image.to(device), input_boxes=box.to(device))
            prediction = output["masks"][0, 0, 0].sigmoid().cpu() > 0.5
            t = target[0, 0] > 0.5
            inter = (prediction & t).sum().item()
            union = (prediction | t).sum().item()
            values.append(inter / union if union else 1.0)
    return float(np.mean(values)) if values else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", required=True)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20261109)
    args = parser.parse_args()
    out_dir = OUT / args.arm
    if out_dir.exists():
        raise SystemExit(f"exists: {out_dir}")
    out_dir.mkdir(parents=True)
    device = torch.device("cuda")
    torch.cuda.set_per_process_memory_fraction(0.45)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    rows = json.loads((DATA / "index.json").read_text(encoding="utf-8"))
    train = [r for r in rows if r["split"] == "train"]
    val = [r for r in rows if r["split"] == "validation"]
    model = build(device, args.arm)
    parameters = [p for p in model.parameters() if p.requires_grad]
    print(json.dumps({"arm": args.arm, "train": len(train), "val": len(val), "trainable": sum(p.numel() for p in parameters), "device": "cuda", "seed": args.seed}), flush=True)
    before = evaluate(model, val, device)
    print(json.dumps({"eval_step": 0, "visible_iou": before}), flush=True)
    optimizer = torch.optim.AdamW(parameters, lr=1e-4, weight_decay=1e-4)
    model.train()
    history = []
    for step in range(1, args.steps + 1):
        row = train[(step - 1) % len(train)]
        image, box, target = sample(row)
        optimizer.zero_grad(set_to_none=True)
        output = model(image.to(device), input_boxes=box.to(device))
        logits = output["masks"][:, 0, 0]
        target = target.to(device)
        bce = F.binary_cross_entropy_with_logits(logits, target[:, 0])
        probability = logits.sigmoid()
        dice = 1 - (2 * (probability * target[:, 0]).sum() + 1) / (
            probability.sum() + target[:, 0].sum() + 1
        )
        loss = bce + dice
        loss.backward()
        torch.nn.utils.clip_grad_norm_(parameters, 1.0)
        optimizer.step()
        history.append(float(loss.detach()))
        if step % 20 == 0 or step == 1:
            print(json.dumps({"step": step, "loss": float(loss.detach())}), flush=True)
        if step % 50 == 0 or step == args.steps:
            after = evaluate(model, val, device)
            print(json.dumps({"eval_step": step, "visible_iou": after}), flush=True)
            saved = {
                key: value.detach().cpu()
                for key, value in model.named_parameters()
                if value.requires_grad
            }
            torch.save({"arm": args.arm, "state": saved}, out_dir / "checkpoint.pth")
    after = evaluate(model, val, device)
    result = {"arm": args.arm, "before": before, "after": after, "delta_pp": (after - before) * 100, "steps": args.steps, "train": len(train), "val": len(val)}
    (out_dir / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
