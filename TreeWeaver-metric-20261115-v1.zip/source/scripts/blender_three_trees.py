"""Three fig trees side by side with ~10% crown overlap between neighbours."""

from __future__ import annotations

import math
import random
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(r"D:\TreeWeaver\tools\assets\sketchfab\fig_trees")
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
OUT = Path(r"D:\TreeWeaver\reports\three-trees-overlap10")
FILES = [
    "realistic_hd_common_fig_tree_3030.glb",
    "realistic_hd_common_fig_tree_1330.glb",
    "realistic_hd_common_fig_tree_530.glb",
]
HEIGHT = 10.0
RES_X, RES_Y = 1280, 720


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "GPU"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = True
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.view_settings.exposure = 0.2


def bbox(obj):
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (
        min(p.x for p in pts), max(p.x for p in pts),
        min(p.y for p in pts), max(p.y for p in pts),
        min(p.z for p in pts), max(p.z for p in pts),
    )


def load_tree(path):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(path))
    new = [obj for obj in bpy.data.objects if obj not in before]
    meshes = [obj for obj in new if obj.type == "MESH" and obj.name not in {"Cube", "Camera", "Light"}]
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for obj in list(new):
        if obj not in meshes:
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.join()
    tree = bpy.context.view_layer.objects.active
    tree.name = path.stem
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(tree)
    scale = HEIGHT / max(z1 - z0, 1e-6)
    tree.scale = tuple(v * scale for v in tree.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(tree)
    tree.location.x -= (x0 + x1) / 2
    tree.location.y -= (y0 + y1) / 2
    tree.location.z -= z0
    bpy.context.view_layer.update()
    return tree


def ground():
    bpy.ops.mesh.primitive_plane_add(size=2000, location=(0, 0, 0))
    obj = bpy.context.object
    mat = bpy.data.materials.new("ground")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    nor = nodes.new("ShaderNodeTexImage")
    nor.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    nor.image.colorspace_settings.name = "Non-Color"
    nmap = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (200, 200, 200)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    links.new(mapping.outputs["Vector"], nor.inputs["Vector"])
    links.new(nor.outputs["Color"], nmap.inputs["Color"])
    links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    obj.data.materials.append(mat)
    return obj


def world():
    w = bpy.data.worlds.new("world")
    w.use_nodes = True
    nodes, links = w.node_tree.nodes, w.node_tree.links
    bg = nodes.get("Background")
    env = nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(str(ENV / "autumn_field_puresky_2k.hdr"))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, math.radians(35))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 1.0
    bpy.context.scene.world = w


def main():
    random.seed(5)
    clean()
    trees = [load_tree(ROOT / name) for name in FILES]
    widths = []
    for tree in trees:
        x0, x1, _, _, _, _ = bbox(tree)
        widths.append(x1 - x0)
    avg = sum(widths) / 3
    gap = 0.10 * avg
    d12 = (widths[0] + widths[1]) / 2 - gap
    d23 = (widths[1] + widths[2]) / 2 - gap
    trees[0].location.x = -d12 + 1.55
    trees[1].location.x = 0
    trees[2].location.x = d23 - 2.4
    # small depth offsets keep the middle tree in front at the touching edges
    trees[0].location.y = 0.4
    trees[1].location.y = 0.0
    trees[2].location.y = -0.4
    for tree, angle in zip(trees, (8, 0, -8), strict=True):
        tree.rotation_euler = (0, 0, math.radians(angle))

    # basic background: sky + ground only; no competing background trees
    background = []

    ground_obj = ground()
    world()
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 16))
    sun = bpy.context.object
    sun.data.energy = 2.2
    sun.data.angle = math.radians(10)
    sun.rotation_euler = (math.radians(52), 0, math.radians(20))

    left = trees[0].location.x - widths[0] / 2
    right = trees[2].location.x + widths[2] / 2
    span = right - left
    lens = 24.0
    hfov = 2 * math.atan(18 / lens)
    distance = span / (2 * math.tan(hfov / 2)) * 1.06
    bpy.ops.object.camera_add(location=((left + right) / 2, -distance, 2.0))
    cam = bpy.context.object
    cam.data.type = "PERSP"
    cam.data.lens = lens
    cam.data.sensor_width = 36
    look = Vector(((left + right) / 2, 0, 5.0))
    cam.rotation_euler = (look - cam.location).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = cam

    OUT.mkdir(parents=True, exist_ok=True)
    bpy.context.scene.render.filepath = str(OUT / "sample.png")
    bpy.ops.render.render(write_still=True)

    # per-tree amodal alpha, same camera, neutral transparent film
    bpy.context.scene.render.film_transparent = True
    bpy.context.scene.render.image_settings.color_mode = "RGBA"
    ground_obj.hide_render = True
    for index, tree in enumerate(trees):
        for other in trees + background:
            other.hide_render = other is not tree
        bpy.context.scene.render.filepath = str(OUT / f"amodal_{index + 1}.png")
        bpy.ops.render.render(write_still=True)
    for tree in trees + background:
        tree.hide_render = False
    ground_obj.hide_render = False

    print("WIDTHS", [round(w, 3) for w in widths])
    print("SPACING", round(d12, 3), round(d23, 3), "GAP", round(gap, 3))
    print("OVERLAP_RATIO", round(gap / avg, 3))
    print("saved", OUT)


if __name__ == "__main__":
    main()
