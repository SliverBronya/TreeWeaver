"""Prepare the visible-branch controlled comparison on the frozen 60-target cohort."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(r"D:\TreeWeaver")
FROZEN = ROOT / "reports/data-qualification-2026-11-09/frozen"
OUT = ROOT / "reports/visible-branch-control-protocol-2026-11-09"
GPU_DISABLED = ROOT / "reports/two-hour-development-2026-11-09/GPU_DISABLED"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    split = json.loads((FROZEN / "splits.json").read_text(encoding="utf-8"))
    assert split["counts"]["train"] == 60
    assert split["counts"]["validation"] == 25
    assert split["counts"]["test"] == 25
    assert split["isolation"] == {
        "group_train_val": 0,
        "group_train_test": 0,
        "group_val_test": 0,
        "asset_train_val": 0,
        "asset_train_test": 0,
        "asset_val_test": 0,
    }
    protocol = {
        "schema_version": "treeweaver-visible-branch-control-1.0",
        "status": "prepared_not_run",
        "frozen_cohort": str(FROZEN / "splits.json"),
        "frozen_cohort_sha256": sha(FROZEN / "splits.json"),
        "freeze_sha256": sha(FROZEN / "freeze.json"),
        "train_targets": 60,
        "validation_targets": 25,
        "test_targets": 25,
        "test_accessed": False,
        "gpu_experiment_allowed": not GPU_DISABLED.exists(),
        "gpu_blocker": (
            GPU_DISABLED.read_text(encoding="utf-8").strip()
            if GPU_DISABLED.exists()
            else ""
        ),
        "common_factors": {
            "base": "SAM2.1 hiera-tiny",
            "decoder": "frozen base decoder plus tree tokens",
            "prompts": "GT boxes from frozen cohort; no test-time point tuning",
            "seed": 20261109,
            "steps": 1200,
            "lr": 1e-4,
            "weight_decay": 1e-4,
            "precision": "BF16 training, FP32 evaluation",
            "train_split": "frozen train 60 targets",
            "validation_split": "frozen validation 25 targets",
        },
        "arms": [
            {
                "name": "mask_readout",
                "trainable": "mask readout only",
                "purpose": "control for decoder adaptation",
            },
            {
                "name": "lora_only",
                "trainable": "image-encoder LoRA only",
                "purpose": "measure encoder appearance adaptation without PF",
            },
            {
                "name": "encoder_pf_only",
                "trainable": "encoder PF cross-attention only",
                "purpose": "measure prompt-conditioned encoder focus without LoRA",
            },
            {
                "name": "lora_pf",
                "trainable": "LoRA + encoder PF",
                "purpose": "combination only after each single arm passes",
            },
        ],
        "metrics": [
            "whole-tree IoU",
            "crown IoU",
            "stem IoU",
            "whole-tree recall",
            "crown recall",
            "stem recall",
            "neighbour-tree contamination fraction",
            "hidden-region IoU where hidden exists",
            "empty/occluded prediction area",
        ],
        "acceptance_gates": {
            "whole_recall_drop_pp": 0.5,
            "crown_recall_drop_pp": 0.5,
            "stem_recall_drop_pp": 0.5,
            "neighbour_contamination_relative_increase": 0.0,
            "hidden_iou_regression": 0.0,
            "must_beat_mask_readout_on_at_least_two_primary_metrics": True,
        },
        "stop_rules": [
            "No training if GPU_DISABLED exists.",
            "No test access until the method is frozen.",
            "Do not combine LoRA+PF before each single arm passes.",
            "Do not start ownership/amodal/curve training from this protocol.",
        ],
        "artifacts": [
            "protocol.json",
            "README.md",
            "frozen/splits.json",
            "frozen/freeze.json",
        ],
    }
    (OUT / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    (OUT / "README.md").write_text(
        "# Visible-branch controlled comparison\n\n"
        "Prepared, not run. GPU experiments are disabled by the stability guard.\n\n"
        "The frozen cohort has 60 train targets (32 clear / 12 contact / 16 overlap), "
        "25 validation and 25 test targets. Test is not accessed.\n\n"
        "Arms: mask_readout, lora_only, encoder_pf_only, lora_pf. "
        "See protocol.json for common factors, metrics and gates.\n",
        encoding="utf-8",
    )
    print(json.dumps(protocol, indent=2))


if __name__ == "__main__":
    main()
