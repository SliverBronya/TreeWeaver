"""Check whether the layer head uses image evidence or prompt-order shortcuts."""

from __future__ import annotations

import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from train_stage12 import DATA, FigDataset, build_model  # noqa: E402


def accuracy(logits, target):
    count = logits.shape[0]
    mask = ~torch.eye(count, dtype=torch.bool)
    return ((logits > 0) == target.bool())[mask].float().mean().item()


def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    checkpoint = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "reports" / "professional-stage3-layer-2026-11-06" / "best.pth"
    model, mean, std = build_model(device, checkpoint)
    ids = sorted(int(p.stem) for p in (DATA / "meta").glob("*.json"))[425:445]
    loader = DataLoader(FigDataset(ids, mean, std), batch_size=1)
    original, permuted, identical = [], [], []
    with torch.no_grad():
        for batch in loader:
            image = batch["image"].to(device)
            boxes = batch["boxes"].to(device)
            target = batch["layer"][0].cpu()
            output = model(image, input_boxes=boxes)
            original.append(accuracy(output["layer_logits"][0].cpu(), target))

            count = boxes.shape[1]
            order = torch.randperm(count)
            permuted_boxes = boxes[:, order.to(device)]
            permuted_target = target[order][:, order]
            output = model(image, input_boxes=permuted_boxes)
            permuted.append(accuracy(output["layer_logits"][0].cpu(), permuted_target))

            same = boxes[:, :1].repeat(1, count, 1)
            output = model(image, input_boxes=same)
            identical.append(accuracy(output["layer_logits"][0].cpu(), target))

    print(
        {
            "original": sum(original) / len(original),
            "permuted_boxes": sum(permuted) / len(permuted),
            "identical_boxes": sum(identical) / len(identical),
        },
        flush=True,
    )


if __name__ == "__main__":
    main()

