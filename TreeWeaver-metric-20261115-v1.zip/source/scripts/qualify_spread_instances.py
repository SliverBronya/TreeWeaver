"""Bounded CPU inspection of six existing SPREAD RGB/instance sample pairs."""

from __future__ import annotations

import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np
from audit_forest_dataset_samples import xlsx_rows
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers/tree_models"))
from research_protocol import sha256_file  # noqa: E402
from spread_instances import decode_tree_instances, parse_instance_mapping  # noqa: E402


def main():
    root = ROOT / "data/external/spread/city_park_sample"
    out = ROOT / "reports/spread-instance-qualification-2026-11-09"
    out.mkdir(exist_ok=True)
    rows = xlsx_rows(ROOT / "SPREAD/color_palette.xlsx", limit=1000)
    if rows[0] != ["Index", "R", "G", "B"]:
        raise ValueError("unexpected palette columns")
    palette = {int(r[0]): tuple(map(int, r[1:4])) for r in rows[1:]}
    metadata = xlsx_rows(root / "obj_info_final.xlsx", limit=100000)
    objects = {row[0]: dict(zip(metadata[0], row, strict=True)) for row in metadata[1:]}
    frames, visible_sets, hashes = [], {}, {}
    sheet = Image.new("RGB", (1440, 1254), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 17)
    for n, path in enumerate(sorted((root / "instance_segmentation").glob("*.png"))):
        rgb_path = root / "rgb" / path.name
        mapping_path = path.with_suffix(".txt")
        for source in (path, rgb_path, mapping_path):
            hashes[str(source.relative_to(ROOT))] = sha256_file(source)
        with Image.open(path) as image:
            raw = np.asarray(image.convert("RGB"))
        with Image.open(rgb_path) as image:
            rgb_size = image.size
            rgb = np.asarray(
                image.convert("RGB").resize((raw.shape[1], raw.shape[0]), Image.Resampling.BOX)
            )
        if rgb_size[0] * raw.shape[0] != rgb_size[1] * raw.shape[1]:
            raise ValueError("RGB/instance aspect mismatch")
        mapping = parse_instance_mapping(mapping_path.read_text(encoding="utf-8"))
        decoded = decode_tree_instances(raw, palette, mapping)
        owner, names = decoded["owner"], decoded["tree_ids"]
        visible_sets[path.stem] = set(names)
        target = path.stem.split("_")[0]
        instances = []
        overlay = rgb.copy()
        for index, name in enumerate(names, 1):
            mask = owner == index
            ys, xs = np.nonzero(mask)
            color = np.asarray(palette[mapping[name]])
            overlay[mask] = (overlay[mask] * 0.5 + color * 0.5).astype(np.uint8)
            instances.append(
                {
                    "tree_id": name,
                    "frame_local_palette_index": mapping[name],
                    "label_pixels": int(mask.sum()),
                    "label_bbox_xyxy": [
                        int(xs.min()),
                        int(ys.min()),
                        int(xs.max() + 1),
                        int(ys.max() + 1),
                    ],
                    "visible_height_fraction": float((ys.max() - ys.min() + 1) / raw.shape[0]),
                    "touches_frame": bool(
                        mask[0].any() or mask[-1].any() or mask[:, 0].any() or mask[:, -1].any()
                    ),
                    "source_mesh": objects.get(name, {}).get("StaticMesh"),
                }
            )
        focal = next((row for row in instances if row["tree_id"] == target), None)
        if focal is None:
            raise ValueError("filename target missing from visible IDs")
        frames.append(
            {
                "frame": path.stem,
                "focal_tree": target,
                "focal": focal,
                "RGB_wh": list(rgb_size),
                "native_label_wh": [raw.shape[1], raw.shape[0]],
                "listed_tree_count": len(mapping),
                "visible_tree_count": len(names),
                "known_tree_fraction": float((owner > 0).mean()),
                "ignored_unrecognized_colour_fraction": float(
                    decoded["unrecognized_colour"].mean()
                ),
                "palette_recognized_but_unmapped_fraction": float(
                    ((owner < 0) & (decoded["palette_indices"] >= 0)).mean()
                ),
                "instances": instances,
            }
        )
        x, y = (n % 2) * 720, (n // 2) * 418
        title = (
            f"{target}: {focal['label_pixels']} label pixels; frame cut={focal['touches_frame']}"
        )
        draw.text((x + 6, y + 4), title, font=font, fill="black")
        sheet.paste(ImageOps.contain(Image.fromarray(rgb), (356, 370)), (x, y + 35))
        sheet.paste(ImageOps.contain(Image.fromarray(overlay), (356, 370)), (x + 360, y + 35))
    edges = [
        {
            "frames": [left, right],
            "shared_visible_tree_ids": sorted(visible_sets[left] & visible_sets[right]),
        }
        for left, right in combinations(visible_sets, 2)
        if visible_sets[left] & visible_sets[right]
    ]
    all_instances = [item for frame in frames for item in frame["instances"]]
    selected = [item for item in all_instances if item["label_pixels"] >= 500]
    result = {
        "scope": "six existing ground-view city_park samples; label qualification only",
        "official_source": "https://github.com/FrankFeng-23/SPREAD#readme",
        "mask_semantics": "visible instance surfaces; no amodal truth",
        "decode": "exact RGB palette -> frame-local colour index -> persistent actor Tree ID",
        "training_allowed": False,
        "model_inference": False,
        "official_test_split_claimed": False,
        "palette_sha256": sha256_file(ROOT / "SPREAD/color_palette.xlsx"),
        "objects_sha256": sha256_file(root / "obj_info_final.xlsx"),
        "file_sha256": hashes,
        "frames": frames,
        "shared_identity_edges": edges,
        "summary": {
            "frames": len(frames),
            "focal_targets_touching_frame": sum(f["focal"]["touches_frame"] for f in frames),
            "unique_visible_tree_actor_ids": len(set().union(*visible_sets.values())),
            "instance_occurrences_at_least_500_label_pixels": len(selected),
            "those_occurrences_touching_frame": sum(i["touches_frame"] for i in selected),
            "pairs_with_shared_visible_tree_identity": len(edges),
            "different_focal_trees_imply_disjoint_frames": False,
            "full_scene_background_supervision_verified": False,
            "RGB_label_resolution_equal": all(f["RGB_wh"] == f["native_label_wh"] for f in frames),
        },
        "limits": [
            "sample cohort is small and selected earlier; no population estimates",
            "RGB 960x540 versus labels 480x270; report metrics at native label resolution",
            "white and palette-only non-tree codes ignored; not certified exhaustive background",
            "only decoded tree-foreground ownership is qualified; no full-image background CE",
            "split by scene/actor exposure, not only filename focal actor; neighbours recur",
            "frame-boundary contact flags possible truncation; hidden fraction is unknown",
        ],
    }
    (out / "qualification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    sheet.save(out / "six-samples-review.jpg", quality=94)
    print(json.dumps(result["summary"]))


if __name__ == "__main__":
    main()
