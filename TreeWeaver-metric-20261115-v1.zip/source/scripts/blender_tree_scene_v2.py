"""Ten scenes with matched 3D background trees and a sky-only HDRI."""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ASSET = Path(r"D:\TreeWeaver\tools\assets\tree_small_02\tree_small_02_1k.blend")
TARGET_OBJECT = "tree_small_02_LOD0"
BACKGROUND_OBJECT = "tree_small_02_LOD1"
ENV = Path(r"D:\TreeWeaver\tools\assets\env")
HDRI = "autumn_field_puresky_2k.hdr"
RES_X, RES_Y = 1280, 720
TARGET_HEIGHT = 10.0


def parse_args():
    argv = sys.argv
    argv = argv[argv.index("--") + 1 :] if "--" in argv else []
    out = Path(argv[0]) if argv else Path(r"D:\TreeWeaver\reports\blender-tree-matched")
    count = int(argv[1]) if len(argv) > 1 else 10
    seed = int(argv[2]) if len(argv) > 2 else 41
    return out, count, seed


def clean_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = RES_X
    scene.render.resolution_y = RES_Y
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.eevee.taa_render_samples = 48
    return scene


def append_object(name: str):
    bpy.ops.wm.append(directory=str(ASSET) + "/Object/", filename=name)
    return bpy.data.objects[name]


def bbox(obj):
    points = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        min(p.x for p in points),
        max(p.x for p in points),
        min(p.y for p in points),
        max(p.y for p in points),
        min(p.z for p in points),
        max(p.z for p in points),
    )


def normalize(obj, height):
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    scale = height / max(z1 - z0, 1e-6)
    obj.scale = tuple(value * scale for value in obj.scale)
    bpy.context.view_layer.update()
    x0, x1, y0, y1, z0, z1 = bbox(obj)
    obj.location.x -= (x0 + x1) / 2
    obj.location.y -= (y0 + y1) / 2
    obj.location.z -= z0
    bpy.context.view_layer.update()


def duplicate(obj):
    copy = obj.copy()
    copy.data = obj.data
    bpy.context.collection.objects.link(copy)
    return copy


def add_ground():
    bpy.ops.mesh.primitive_plane_add(size=300, location=(0, 0, 0))
    ground = bpy.context.object
    material = bpy.data.materials.new("ground")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    for node in list(nodes):
        nodes.remove(node)
    output = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    texture = nodes.new("ShaderNodeTexImage")
    texture.image = bpy.data.images.load(str(ENV / "forest_floor_Diffuse_2k.jpg"))
    normal = nodes.new("ShaderNodeTexImage")
    normal.image = bpy.data.images.load(str(ENV / "forest_floor_nor_gl_2k.png"))
    normal.image.colorspace_settings.name = "Non-Color"
    normal_map = nodes.new("ShaderNodeNormalMap")
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (22, 22, 22)
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], texture.inputs["Vector"])
    links.new(mapping.outputs["Vector"], normal.inputs["Vector"])
    links.new(normal.outputs["Color"], normal_map.inputs["Color"])
    links.new(texture.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    ground.data.materials.append(material)
    return ground


def add_world(rng):
    world = bpy.data.worlds.new("world")
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    background = nodes.get("Background")
    environment = nodes.new("ShaderNodeTexEnvironment")
    environment.image = bpy.data.images.load(str(ENV / HDRI))
    mapping = nodes.new("ShaderNodeMapping")
    mapping.inputs["Rotation"].default_value = (0, 0, rng.uniform(0, 2 * math.pi))
    coords = nodes.new("ShaderNodeTexCoord")
    links.new(coords.outputs["Generated"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], environment.inputs["Vector"])
    links.new(environment.outputs["Color"], background.inputs["Color"])
    background.inputs["Strength"].default_value = rng.uniform(0.9, 1.2)
    bpy.context.scene.world = world


def add_lights(rng):
    bpy.ops.object.light_add(type="SUN", location=(0, -10, 20))
    sun = bpy.context.object
    sun.data.energy = rng.uniform(1.8, 2.8)
    sun.data.angle = math.radians(rng.uniform(3, 8))
    sun.rotation_euler = (
        math.radians(rng.uniform(40, 62)),
        0,
        math.radians(rng.uniform(0, 360)),
    )


def add_camera(target, lens, rng):
    bpy.ops.object.camera_add()
    camera = bpy.context.object
    camera.data.lens = lens
    camera.data.sensor_width = 36
    vfov = 2 * math.atan((18 * RES_Y / RES_X) / lens)
    distance = (TARGET_HEIGHT / 0.85) / (2 * math.tan(vfov / 2))
    camera.location = (rng.uniform(-0.3, 0.3), -distance, rng.uniform(1.4, 1.8))
    look_at = Vector((0, 0, TARGET_HEIGHT * 0.5))
    direction = look_at - camera.location
    camera.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    camera.data.dof.use_dof = True
    camera.data.dof.focus_object = target
    camera.data.dof.aperture_fstop = rng.uniform(2.8, 5.6)
    bpy.context.scene.camera = camera


def main():
    out, count, seed = parse_args()
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    for index in range(count):
        clean_scene()
        target = append_object(TARGET_OBJECT)
        normalize(target, TARGET_HEIGHT)
        target.name = "tree_target"
        target.location = (0, 0, 0)
        target.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

        neighbour = duplicate(target)
        neighbour.name = "tree_neighbour"
        neighbour.scale = tuple(value * rng.uniform(0.85, 1.05) for value in target.scale)
        neighbour.location = (rng.uniform(2.8, 4.6), rng.uniform(-0.6, 0.6), 0)
        neighbour.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))

        background_template = append_object(BACKGROUND_OBJECT)
        normalize(background_template, 10.0)
        for bg_index in range(7):
            bg = duplicate(background_template)
            bg.name = f"background_{bg_index}"
            bg.scale = tuple(
                value * rng.uniform(0.75, 1.35) for value in background_template.scale
            )
            bg.location = (
                rng.uniform(-24, 24),
                rng.uniform(14, 42),
                0,
            )
            bg.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360)))
        bpy.data.objects.remove(background_template, do_unlink=True)

        add_ground()
        add_world(rng)
        add_lights(rng)
        add_camera(target, rng.uniform(24, 38), rng)
        bpy.context.scene.view_settings.exposure = rng.uniform(-0.2, 0.4)
        bpy.context.scene.render.filepath = str(out / f"{index + 1:02d}.png")
        bpy.ops.render.render(write_still=True)
        print(f"rendered {index + 1}/{count}", flush=True)
    print("done")


if __name__ == "__main__":
    main()
