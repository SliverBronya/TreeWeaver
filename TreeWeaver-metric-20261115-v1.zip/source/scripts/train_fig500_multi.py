"""Train the ownership-aware SAM2 decoder on the 500-image fig overlap set."""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from research_protocol import (  # noqa: E402
    assert_training_allowed,
    pinned_snapshot,
    training_protocol,
    validate_initialization,
)
from supervision import masked_visibility_mse  # noqa: E402

SAM2_REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2, 3))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + 1.0
    )


def trainable_groups(model):
    new_prefixes = (
        "amodal_token",
        "visibility_token",
        "curve_token",
        "occluder_token",
        "amodal_hypernets",
        "occluder_hypernet",
        "router",
        "visibility_mean",
        "visibility_log_variance",
        "curve_head",
        "amodal_scale",
        "ownership_projection",
        "ownership_conv",
        "ownership_bg",
        "layer_head",
    )
    new, base = [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if not name.startswith("decoder."):
            new.append(parameter)
            continue
        local = name[len("decoder.") :]
        (new if local.startswith(new_prefixes) else base).append(parameter)
    return new, base


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def evaluate(model, dataset, limit, device):
    model.eval()
    values = {"visible": [], "amodal": [], "ownership": [], "layer": [], "visibility": []}
    with torch.no_grad():
        for index in range(min(limit, len(dataset))):
            sample = dataset.sample(index)
            pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
            boxes = torch.as_tensor(sample["boxes"])[None].to(device)
            output = model(pixel_values, input_boxes=boxes)
            count = int(sample["num_objects"])
            visible_pred = output["masks"][0, :, 0] > 0
            visible_gt = torch.as_tensor(sample["visible"]).to(device) > 0.5
            amodal_pred = output["amodal_masks"][0, :, 0] > 0
            amodal_gt = torch.as_tensor(sample["amodal"]).to(device) > 0.5
            for i in range(count):
                values["visible"].append(iou(visible_pred[i], visible_gt[i]))
                values["amodal"].append(iou(amodal_pred[i], amodal_gt[i]))
            ownership_pred = output["ownership_logits"][0].argmax(0)
            ownership_gt = torch.as_tensor(sample["ownership"]).to(device)
            values["ownership"].append(float((ownership_pred == ownership_gt).float().mean()))
            layer_pred = output["layer_logits"][0]
            layer_gt = torch.as_tensor(sample["layer"]).to(device)
            upper = torch.triu_indices(count, count, 1, device=device)
            if upper.shape[1]:
                predicted = layer_pred[upper[0], upper[1]] > 0
                target = layer_gt[upper[0], upper[1]] > 0
                values["layer"].append(float((predicted == target).float().mean()))
            visibility_pred = output["visibility"][0].cpu().numpy()
            visibility_gt = np.asarray(sample["visibility"], dtype=np.float64)
            valid = np.asarray(sample["visibility_valid"], dtype=bool)
            values["visibility"].append(
                float(np.abs(visibility_pred - visibility_gt)[valid].mean())
            )
    return {key: (float(np.mean(v)) if v else float("nan")) for key, v in values.items()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-root", type=Path, default=ROOT / "reports" / "fig-500-v2-2026-10-31"
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, default=None)
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--stage", choices=("A", "B"), default="A")
    parser.add_argument("--split-manifest", type=Path)
    parser.add_argument("--allow-legacy-image-split", action="store_true")
    parser.add_argument("--allow-unverified-initialization", action="store_true")
    parser.add_argument("--supervise-origin-rank", action="store_true")
    parser.add_argument("--supervise-legacy-occluder", action="store_true")
    parser.add_argument("--curve-consistency-weight", type=float, default=0.0)
    parser.add_argument(
        "--amodal-weight",
        type=float,
        default=None,
        help="override the stage default for the amodal loss",
    )
    parser.add_argument("--sam2-revision", default=SAM2_REVISION)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--lr-new", type=float, default=3e-4)
    parser.add_argument("--lr-base", type=float, default=1e-5)
    parser.add_argument("--eval-every", type=int, default=10)
    parser.add_argument("--eval-images", type=int, default=5)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if not 0 <= args.curve_consistency_weight <= 1:
        parser.error("curve consistency weight must be in [0,1]")

    assert_training_allowed(args.data_root)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    if args.output.exists():
        raise SystemExit(f"output exists: {args.output}")
    args.output.mkdir(parents=True)

    from fig500_dataset import Fig500Multi
    from occlusion_aware import (
        amodal_bce,
        amodal_containment_loss,
        curve_nll,
        routing_balance_loss,
    )
    from sam2_occlusion import Sam2OcclusionModel

    sam2_path = pinned_snapshot("facebook/sam2.1-hiera-tiny", args.sam2_revision)
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    train = Fig500Multi(
        args.data_root, "train", mean=mean, std=std, split_manifest=args.split_manifest
    )
    val = Fig500Multi(args.data_root, "val", mean=mean, std=std, split_manifest=args.split_manifest)
    if not train.split_independence_verified and not args.allow_legacy_image_split:
        raise ValueError(
            "Supply asset/scene-disjoint splits.json; "
            "legacy reproduction requires --allow-legacy-image-split"
        )
    protocol = training_protocol(
        args.data_root, train.split_origin, args.sam2_revision, args.seed, args.checkpoint
    )
    initial = (
        torch.load(args.checkpoint, map_location="cpu", weights_only=True)
        if args.checkpoint
        else None
    )
    validate_initialization(
        protocol,
        initial.get("protocol") if initial else None,
        args.allow_unverified_initialization,
    )
    protocol.update(
        {
            "origin_rank_supervision": args.supervise_origin_rank,
            "legacy_occluder_supervision": args.supervise_legacy_occluder,
            "stage": args.stage,
            "curve_consistency_weight": args.curve_consistency_weight,
            "amodal_weight_effective": (
                0.0 if args.stage == "A" else 0.5
            )
            if args.amodal_weight is None
            else float(args.amodal_weight),
            "curve_consistency_contract": "all-instances-amodal-relative-span-v1",
        }
    )
    (args.output / "protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")

    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device)
    if args.checkpoint is not None:
        report = model.decoder.load_state_dict(initial["decoder"], strict=False)
        print("missing", report.missing_keys, "unexpected", report.unexpected_keys)
    model.train()

    if args.stage == "A":
        for module in (
            model.decoder.amodal_hypernets,
            model.decoder.curve_head,
            model.decoder.occluder_hypernet,
        ):
            for parameter in module.parameters():
                parameter.requires_grad_(False)
        model.decoder.amodal_scale.requires_grad_(False)
        model.decoder.occluder_token.requires_grad_(False)
        amodal_weight = 0.0
        visibility_weight = 0.0
        curve_weight = 0.0
        occluder_weight = 0.0
        ownership_weight = 0.5
        layer_weight = 0.2 if args.supervise_origin_rank else 0.0
    else:
        amodal_weight = 0.5
        visibility_weight = 0.25
        curve_weight = 0.1
        occluder_weight = 0.1 if args.supervise_legacy_occluder else 0.0
        ownership_weight = 0.5
        layer_weight = 0.2 if args.supervise_origin_rank else 0.0

    if args.amodal_weight is not None:
        if not 0.0 <= args.amodal_weight <= 1.0:
            parser.error("amodal weight must be in [0,1]")
        amodal_weight = float(args.amodal_weight)

    new, base = trainable_groups(model)
    optimizer = torch.optim.AdamW(
        [
            {"params": new, "lr": args.lr_new},
            {"params": base, "lr": args.lr_base},
        ],
        weight_decay=1e-4,
    )
    print("train images", len(train), "val images", len(val))
    print("trainable", sum(p.numel() for p in model.parameters() if p.requires_grad))
    print("frozen", sum(p.numel() for p in model.parameters() if not p.requires_grad))

    history = []
    best = -1.0
    started = time.time()
    for step in range(1, args.steps + 1):
        sample = train.sample(np.random.randint(len(train)))
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(args.device)
        boxes = torch.as_tensor(sample["boxes"])[None].to(args.device)
        visible = torch.as_tensor(sample["visible"])[None].to(args.device)
        amodal = torch.as_tensor(sample["amodal"])[None].to(args.device)
        ownership = torch.as_tensor(sample["ownership"])[None].to(args.device)
        layer = torch.as_tensor(sample["layer"])[None].to(args.device)
        visibility = torch.as_tensor(sample["visibility"])[None].to(args.device)
        visibility_valid = torch.as_tensor(sample["visibility_valid"])[None].to(args.device)
        curve = torch.as_tensor(sample["curve"])[None].to(args.device)
        observed = torch.as_tensor(sample["curve_observed"])[None].to(args.device)
        occluder = torch.as_tensor(sample["occluder"])[None].to(args.device)

        output = model(pixel_values, input_boxes=boxes)
        visible_logits = output["masks"][:, :, 0]
        amodal_logits = output["amodal_masks"][:, :, 0]
        mask_loss = (
            F.binary_cross_entropy_with_logits(visible_logits, visible)
            + dice_loss(visible_logits, visible).mean()
        )
        ownership_logits = output["ownership_logits"]
        count = int(sample["num_objects"])
        class_weight = torch.tensor([0.2] + [1.0] * count, device=args.device)
        ownership_loss = F.cross_entropy(ownership_logits, ownership, weight=class_weight)
        upper = torch.triu_indices(count, count, 1, device=args.device)
        if upper.shape[1]:
            layer_loss = F.binary_cross_entropy_with_logits(
                output["layer_logits"][0, upper[0], upper[1]],
                (layer[0, upper[0], upper[1]] > 0).float(),
            )
        else:
            layer_loss = visible_logits.sum() * 0
        loss = mask_loss + ownership_weight * ownership_loss + layer_weight * layer_loss
        loss = loss + 0.01 * routing_balance_loss(output["routing"])
        if amodal_weight:
            loss = loss + amodal_weight * amodal_bce(amodal_logits, amodal, visible, 3.0)
            loss = loss + 0.1 * amodal_containment_loss(amodal_logits, visible)
        if visibility_weight:
            loss = loss + visibility_weight * masked_visibility_mse(
                output["visibility"], visibility, visibility_valid
            )
        if curve_weight:
            loss = loss + curve_weight * curve_nll(
                output["curve"], output["curve_log_sigma"], curve, observed
            )
        if args.curve_consistency_weight:
            from curve_consistency import curve_profile_loss

            loss = loss + args.curve_consistency_weight * curve_profile_loss(
                amodal_logits, curve, observed, reference_mask=amodal
            )
        if occluder_weight:
            loss = loss + occluder_weight * F.binary_cross_entropy_with_logits(
                output["occluder_masks"][:, :, 0], occluder
            )

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        if step % 10 == 0 or step == 1:
            print(
                f"step {step}/{args.steps} loss {float(loss.detach()):.4f} "
                f"mask {float(mask_loss.detach()):.4f} own {float(ownership_loss.detach()):.4f} "
                f"layer {float(layer_loss.detach()):.4f}",
                flush=True,
            )
        if step % args.eval_every == 0 or step == args.steps:
            metrics = evaluate(model, val, args.eval_images, args.device)
            row = {"step": step, **metrics, "loss": float(loss.detach())}
            history.append(row)
            print("EVAL", json.dumps(row), flush=True)
            score = metrics["visible"] + metrics["ownership"] + 0.5 * metrics["amodal"]
            if score > best:
                best = score
                torch.save(
                    {
                        "decoder": model.decoder.state_dict(),
                        "knots": 12,
                        "step": step,
                        "protocol": protocol,
                        **metrics,
                    },
                    args.output / "decoder_best.pth",
                )
            model.train()

    (args.output / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
    (args.output / "run.json").write_text(
        json.dumps(
            {
                "data_root": str(args.data_root),
                "train_images": len(train),
                "val_images": len(val),
                "steps": args.steps,
                "stage": args.stage,
                "best_score": best,
                "seconds": round(time.time() - started, 1),
                "checkpoint": str(args.checkpoint) if args.checkpoint else None,
                "sam2_revision": args.sam2_revision,
                "seed": args.seed,
                "split_origin": train.split_origin,
                "visibility_metric": "tree_visibility_mae; stem channel unavailable",
                "supervision_version": "fig500-visible-only-visibility-v2",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("DONE", args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
