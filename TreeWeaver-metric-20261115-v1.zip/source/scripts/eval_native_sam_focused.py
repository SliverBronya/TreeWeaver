"""Native SAM2 baseline on the focused validation cohort."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import Sam2Model

ROOT = Path(r"D:\TreeWeaver")
DATA = ROOT / "reports/focused-composite-v3-60-2026-11-10"
OUT = ROOT / "reports/focused-native-sam-2026-11-10"


def snapshot():
    base = Path.home() / ".cache/huggingface/hub/models--facebook--sam2.1-hiera-tiny/snapshots"
    return sorted(p for p in base.iterdir() if p.is_dir())[-1]


def image_tensor(image):
    array = np.asarray(image, dtype=np.float32) / 255.0
    array = (array - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    return torch.from_numpy(array).permute(2, 0, 1)[None]


def mask(path):
    return np.asarray(Image.open(path).convert("RGBA"))[..., 3] > 16


def main():
    OUT.mkdir(exist_ok=True)
    model = Sam2Model.from_pretrained(snapshot(), local_files_only=True).cuda().eval()
    rows = [r for r in json.loads((DATA / "index.json").read_text()) if r["split"] == "validation"]
    values = []
    for row in rows:
        image = Image.open(DATA / row["scene"] / "rgb.png").convert("RGB")
        array = image.resize((1024, 1024), Image.BILINEAR)
        visible = mask(DATA / row["scene"] / "visible_target.png")
        ys, xs = np.where(visible)
        scale_x, scale_y = 1024 / image.width, 1024 / image.height
        box = torch.tensor(
            [[[xs.min() * scale_x, ys.min() * scale_y, (xs.max() + 1) * scale_x, (ys.max() + 1) * scale_y]]],
            dtype=torch.float32,
        ).cuda()
        with torch.no_grad():
            out = model(pixel_values=image_tensor(array).cuda(), input_boxes=box)
        index = int(out["iou_scores"][0, 0].argmax())
        prediction = out["pred_masks"][0, 0, index].sigmoid().cpu() > 0.5
        target = torch.from_numpy(visible.astype(np.float32))[None, None]
        target = torch.nn.functional.interpolate(target, size=(256, 256), mode="nearest")[0, 0] > 0.5
        inter, union = (prediction & target).sum().item(), (prediction | target).sum().item()
        values.append(inter / union if union else 1.0)
    result = {"val": len(values), "mean_iou": float(np.mean(values)), "values": values}
    (OUT / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"val": len(values), "mean_iou": float(np.mean(values))}, indent=2))


if __name__ == "__main__":
    main()
