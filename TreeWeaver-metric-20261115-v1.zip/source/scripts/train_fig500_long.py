"""Long-running hard-example training for the fig500 multi-object model."""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import Sam2Model, Sam2Processor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "workers" / "tree_models"))

from research_protocol import (  # noqa: E402
    assert_training_allowed,
    pinned_snapshot,
    training_protocol,
    validate_initialization,
)
from supervision import masked_visibility_mse  # noqa: E402

SAM2_REVISION = "de431c4043854a71d8101e17995dfe596bf101a5"
SUPERVISION_VERSION = "fig500-visible-only-visibility-v2"


def dice_loss(logits, target):
    probability = logits.sigmoid()
    intersection = (probability * target).sum(dim=(1, 2, 3))
    return 1.0 - (2.0 * intersection + 1.0) / (
        probability.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + 1.0
    )


def trainable_groups(model):
    new_prefixes = (
        "amodal_token",
        "visibility_token",
        "curve_token",
        "occluder_token",
        "amodal_hypernets",
        "occluder_hypernet",
        "router",
        "visibility_mean",
        "visibility_log_variance",
        "curve_head",
        "amodal_scale",
        "ownership_projection",
        "ownership_conv",
        "ownership_bg",
        "layer_head",
    )
    new, base = [], []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if not name.startswith("decoder."):
            new.append(parameter)
            continue
        local = name[len("decoder.") :]
        (new if local.startswith(new_prefixes) else base).append(parameter)
    return new, base


def iou(prediction, target):
    return float((prediction & target).sum()) / max(float((prediction | target).sum()), 1.0)


def metadata_hard_ids(dataset):
    ids = []
    for record in dataset.items:
        meta = json.loads(
            (dataset.root / "meta" / f"{int(record['id']):06d}.json").read_text(encoding="utf-8")
        )
        ratios = [p["ratio_min"] for p in meta.get("pairs", [])]
        if ratios and 0.02 <= min(ratios) <= 0.30:
            ids.append(int(record["id"]))
    return ids


def score_sample(model, dataset, index, device):
    sample = dataset.sample(index)
    pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
    boxes = torch.as_tensor(sample["boxes"])[None].to(device)
    with torch.no_grad():
        output = model(pixel_values, input_boxes=boxes)
    pred = output["masks"][0, :, 0] > 0
    gt = torch.as_tensor(sample["visible"]).to(device) > 0.5
    visible = float(np.mean([iou(pred[i], gt[i]) for i in range(len(gt))]))
    own = output["ownership_logits"][0].argmax(0)
    ownership_gt = torch.as_tensor(sample["ownership"]).to(device)
    foreground = ownership_gt > 0
    own_acc = (
        float((own[foreground] == ownership_gt[foreground]).float().mean())
        if foreground.any()
        else 1.0
    )
    return visible, own_acc


def mine_hard(model, dataset, ids, device, count=48, keep=20):
    model.eval()
    pool = random.sample(ids, min(count, len(ids)))
    scored = []
    for image_id in pool:
        index = dataset.id_to_index[image_id]
        visible, own = score_sample(model, dataset, index, device)
        scored.append((visible + own, image_id))
    scored.sort()
    model.train()
    return [image_id for _, image_id in scored[:keep]]


def evaluate(model, dataset, limit, device):
    model.eval()
    visible_all, amodal_all, own_all, own_fg, layer_all, vis_all = [], [], [], [], [], []
    for index in range(min(limit, len(dataset))):
        sample = dataset.sample(index)
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(device)
        boxes = torch.as_tensor(sample["boxes"])[None].to(device)
        with torch.no_grad():
            output = model(pixel_values, input_boxes=boxes)
        count = int(sample["num_objects"])
        pred_visible = output["masks"][0, :, 0] > 0
        pred_amodal = output["amodal_masks"][0, :, 0] > 0
        gt_visible = torch.as_tensor(sample["visible"]).to(device) > 0.5
        gt_amodal = torch.as_tensor(sample["amodal"]).to(device) > 0.5
        for i in range(count):
            visible_all.append(iou(pred_visible[i], gt_visible[i]))
            amodal_all.append(iou(pred_amodal[i], gt_amodal[i]))
        ownership = output["ownership_logits"][0].argmax(0)
        ownership_gt = torch.as_tensor(sample["ownership"]).to(device)
        correct = ownership == ownership_gt
        own_all.append(float(correct.float().mean()))
        foreground = ownership_gt > 0
        if foreground.any():
            own_fg.append(float(correct[foreground].float().mean()))
        upper = torch.triu_indices(count, count, 1, device=device)
        if upper.shape[1]:
            pred_layer = output["layer_logits"][0, upper[0], upper[1]] > 0
            gt_layer = torch.as_tensor(sample["layer"]).to(device)[upper[0], upper[1]] > 0
            layer_all.append(float((pred_layer == gt_layer).float().mean()))
        visibility = output["visibility"][0].cpu().numpy()
        valid = np.asarray(sample["visibility_valid"], dtype=bool)
        vis_all.append(float(np.abs(visibility - sample["visibility"])[valid].mean()))
    model.train()
    return {
        "visible": float(np.mean(visible_all)),
        "amodal": float(np.mean(amodal_all)),
        "ownership": float(np.mean(own_all)),
        "ownership_fg": float(np.mean(own_fg)),
        "layer": float(np.mean(layer_all)) if layer_all else float("nan"),
        "visibility": float(np.mean(vis_all)),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-root", type=Path, default=ROOT / "reports" / "fig-500-v2-2026-10-31"
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=ROOT / "reports" / "fig500-stageB-2026-10-31" / "decoder_best.pth",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--hours", type=float, default=5.0)
    parser.add_argument("--eval-every", type=int, default=1000)
    parser.add_argument("--eval-images", type=int, default=100)
    parser.add_argument("--save-every", type=int, default=100)
    parser.add_argument("--hard-every", type=int, default=500)
    parser.add_argument("--split-manifest", type=Path)
    parser.add_argument("--allow-legacy-image-split", action="store_true")
    parser.add_argument("--allow-unverified-initialization", action="store_true")
    parser.add_argument("--supervise-origin-rank", action="store_true")
    parser.add_argument("--supervise-legacy-occluder", action="store_true")
    parser.add_argument("--curve-consistency-weight", type=float, default=0.0)
    parser.add_argument("--sam2-revision", default=SAM2_REVISION)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    if not 0 <= args.curve_consistency_weight <= 1:
        parser.error("curve consistency weight must be in [0,1]")
    assert_training_allowed(args.data_root)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    args.output.mkdir(parents=True, exist_ok=True)

    from fig500_dataset import Fig500Multi
    from occlusion_aware import (
        amodal_bce,
        amodal_containment_loss,
        curve_nll,
        routing_balance_loss,
    )
    from sam2_occlusion import Sam2OcclusionModel

    sam2_path = pinned_snapshot("facebook/sam2.1-hiera-tiny", args.sam2_revision)
    processor = Sam2Processor.from_pretrained(sam2_path, local_files_only=True)
    mean = tuple(processor.image_processor.image_mean)
    std = tuple(processor.image_processor.image_std)
    train = Fig500Multi(
        args.data_root, "train", mean=mean, std=std, split_manifest=args.split_manifest
    )
    val = Fig500Multi(args.data_root, "val", mean=mean, std=std, split_manifest=args.split_manifest)
    if not train.split_independence_verified and not args.allow_legacy_image_split:
        raise ValueError(
            "Supply asset/scene-disjoint splits.json; "
            "legacy reproduction requires --allow-legacy-image-split"
        )
    protocol = training_protocol(
        args.data_root, train.split_origin, args.sam2_revision, args.seed, args.checkpoint
    )
    payload = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    validate_initialization(protocol, payload.get("protocol"), args.allow_unverified_initialization)
    protocol.update(
        {
            "origin_rank_supervision": args.supervise_origin_rank,
            "legacy_occluder_supervision": args.supervise_legacy_occluder,
            "curve_consistency_weight": args.curve_consistency_weight,
            "curve_consistency_contract": "all-instances-amodal-relative-span-v1",
        }
    )
    protocol_file = args.output / "protocol.json"
    if protocol_file.exists() and json.loads(protocol_file.read_text(encoding="utf-8")) != protocol:
        raise ValueError("Training inputs changed; use a new experiment output directory")
    protocol_file.write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    train.id_to_index = {int(record["id"]): i for i, record in enumerate(train.items)}
    val.id_to_index = {int(record["id"]): i for i, record in enumerate(val.items)}

    sam2 = Sam2Model.from_pretrained(sam2_path, local_files_only=True).to(args.device).eval()
    model = Sam2OcclusionModel(sam2, knots=12, experts=3).to(args.device)
    report = model.decoder.load_state_dict(payload["decoder"], strict=True)
    print("loaded", report, flush=True)
    model.train()

    new, base = trainable_groups(model)
    optimizer = torch.optim.AdamW(
        [{"params": new, "lr": 5e-5}, {"params": base, "lr": 1e-6}],
        weight_decay=1e-4,
    )
    start_step = 0
    best = -1.0
    history = []
    latest = args.output / "latest.pth"
    if latest.exists():
        state = torch.load(latest, map_location=args.device, weights_only=False)
        if state.get("supervision_version") != SUPERVISION_VERSION:
            raise ValueError(
                "Legacy checkpoint uses different supervision; "
                "use a fresh output and --checkpoint for warm start"
            )
        if state.get("protocol") != protocol:
            raise ValueError("Checkpoint protocol differs from current training inputs")
        model.decoder.load_state_dict(state["decoder"], strict=True)
        optimizer.load_state_dict(state["optimizer"])
        start_step = int(state.get("step", 0))
        best = float(state.get("best", -1.0))
        history = list(state.get("history", []))
        hard_ids = list(state.get("hard_ids", []))
        random.setstate(state["python_rng"])
        np.random.set_state(state["numpy_rng"])
        torch.set_rng_state(state["torch_rng"].cpu())
        if args.device.startswith("cuda") and state.get("cuda_rng") is not None:
            torch.cuda.set_rng_state_all([rng.cpu() for rng in state["cuda_rng"]])
        print("resumed", start_step, flush=True)
    else:
        hard_ids = metadata_hard_ids(train)

    if not hard_ids:
        hard_ids = [int(record["id"]) for record in train.items[:80]]
    hard_ids = [image_id for image_id in hard_ids if image_id in train.id_to_index]
    print("hard ids", len(hard_ids), "train", len(train), "val", len(val), flush=True)
    (args.output / "hard_ids.json").write_text(json.dumps(hard_ids, indent=2), encoding="utf-8")

    deadline = time.time() + args.hours * 3600.0
    step = start_step
    last_eval = None
    while time.time() < deadline:
        step += 1
        if hard_ids and random.random() < 0.6:
            image_id = random.choice(hard_ids)
            index = train.id_to_index[image_id]
        else:
            index = random.randrange(len(train))
        sample = train.sample(index)
        pixel_values = torch.as_tensor(sample["pixel_values"])[None].to(args.device)
        boxes = torch.as_tensor(sample["boxes"])[None].to(args.device)
        visible = torch.as_tensor(sample["visible"])[None].to(args.device)
        amodal = torch.as_tensor(sample["amodal"])[None].to(args.device)
        ownership = torch.as_tensor(sample["ownership"])[None].to(args.device)
        layer = torch.as_tensor(sample["layer"])[None].to(args.device)
        visibility = torch.as_tensor(sample["visibility"])[None].to(args.device)
        visibility_valid = torch.as_tensor(sample["visibility_valid"])[None].to(args.device)
        curve = torch.as_tensor(sample["curve"])[None].to(args.device)
        observed = torch.as_tensor(sample["curve_observed"])[None].to(args.device)
        occluder = torch.as_tensor(sample["occluder"])[None].to(args.device)

        output = model(pixel_values, input_boxes=boxes)
        visible_logits = output["masks"][:, :, 0]
        amodal_logits = output["amodal_masks"][:, :, 0]
        mask_loss = (
            F.binary_cross_entropy_with_logits(visible_logits, visible)
            + dice_loss(visible_logits, visible).mean()
        )
        count = int(sample["num_objects"])
        class_weight = torch.tensor([0.2] + [1.0] * count, device=args.device)
        ownership_loss = F.cross_entropy(output["ownership_logits"], ownership, weight=class_weight)
        upper = torch.triu_indices(count, count, 1, device=args.device)
        layer_loss = (
            F.binary_cross_entropy_with_logits(
                output["layer_logits"][0, upper[0], upper[1]],
                (layer[0, upper[0], upper[1]] > 0).float(),
            )
            if upper.shape[1]
            else visible_logits.sum() * 0
        )
        loss = (
            mask_loss
            + 0.5 * ownership_loss
            + (0.2 if args.supervise_origin_rank else 0.0) * layer_loss
            + 0.5 * amodal_bce(amodal_logits, amodal, visible, 3.0)
            + 0.1 * amodal_containment_loss(amodal_logits, visible)
            + 0.2 * masked_visibility_mse(output["visibility"], visibility, visibility_valid)
            + 0.1 * curve_nll(output["curve"], output["curve_log_sigma"], curve, observed)
            + (0.05 if args.supervise_legacy_occluder else 0.0)
            * F.binary_cross_entropy_with_logits(output["occluder_masks"][:, :, 0], occluder)
            + 0.01 * routing_balance_loss(output["routing"])
        )
        if args.curve_consistency_weight:
            from curve_consistency import curve_profile_loss

            loss = loss + args.curve_consistency_weight * curve_profile_loss(
                amodal_logits, curve, observed, reference_mask=amodal
            )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        if step % 10 == 0:
            print(f"step {step} loss {float(loss.detach()):.4f}", flush=True)
        if step % args.eval_every == 0:
            metrics = evaluate(model, val, args.eval_images, args.device)
            row = {
                "step": step,
                **metrics,
                "loss": float(loss.detach()),
                "elapsed_h": round((time.time() - (deadline - args.hours * 3600)) / 3600, 2),
            }
            history.append(row)
            last_eval = metrics
            print("EVAL", json.dumps(row), flush=True)
            score = metrics["visible"] + metrics["ownership_fg"] + 0.5 * metrics["amodal"]
            if score > best:
                best = score
                torch.save(
                    {
                        "decoder": model.decoder.state_dict(),
                        "step": step,
                        "protocol": protocol,
                        **metrics,
                    },
                    args.output / "best.pth",
                )
            (args.output / "history.json").write_text(
                json.dumps(history, indent=2), encoding="utf-8"
            )
        if step % args.hard_every == 0:
            mined = mine_hard(model, train, list(train.id_to_index), args.device, count=48, keep=20)
            hard_ids = sorted(set(mined) | set(metadata_hard_ids(train)))[:120]
            print("HARD", len(hard_ids), mined, flush=True)
            (args.output / "hard_ids.json").write_text(
                json.dumps(hard_ids, indent=2), encoding="utf-8"
            )
        if step % args.save_every == 0:
            torch.save(
                {
                    "decoder": model.decoder.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "step": step,
                    "best": best,
                    "history": history,
                    "hard_ids": hard_ids,
                    "supervision_version": SUPERVISION_VERSION,
                    "protocol": protocol,
                    "sam2_revision": args.sam2_revision,
                    "split_origin": train.split_origin,
                    "seed": args.seed,
                    "python_rng": random.getstate(),
                    "numpy_rng": np.random.get_state(),
                    "torch_rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state_all()
                    if args.device.startswith("cuda")
                    else None,
                },
                latest,
            )
            (args.output / "hard_ids.json").write_text(
                json.dumps(hard_ids, indent=2), encoding="utf-8"
            )
            (args.output / "status.json").write_text(
                json.dumps(
                    {"step": step, "best": best, "last_eval": last_eval, "hard_ids": len(hard_ids)},
                    indent=2,
                ),
                encoding="utf-8",
            )

    metrics = evaluate(model, val, 100, args.device)
    torch.save(
        {"decoder": model.decoder.state_dict(), "step": step, "protocol": protocol, **metrics},
        args.output / "final.pth",
    )
    (args.output / "final_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print("DONE", step, json.dumps(metrics), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
