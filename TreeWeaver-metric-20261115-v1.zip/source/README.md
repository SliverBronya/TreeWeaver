# TreeWeaver

## Dataset production and team handoff (2026-11-15)

Start with [team handoff](docs/collaboration/README.md),
[dataset requirements](docs/collaboration/DATASET_REQUIREMENTS.md),
[progress journal](docs/collaboration/PROGRESS.md), and
[machine-readable progress](configs/research/team-progress.json).
The current priority is trustworthy visible instance ownership, visible
stem/crown parts, same-camera amodal supervision, and qualified metric depth
and geometry using existing assets. Foundation checks are not a claim of
accepted rendered data or improved model accuracy.

Large assets, phone photographs and model weights stay in separately authorized
storage. Their local paths do not become downloadable merely by cloning this
repository. See the handoff documents before running historical experiments.

TreeWeaver is a clean research system for measuring individual trees in
complex scenes from one ordinary RGB photograph or several unordered RGB
photographs. ARCore, LiDAR, video, and depth sensors are optional evidence
sources, not prerequisites.

The research question is not "which existing vision model should be used?".
It is:

> Can target-tree identity, explicit occlusion reasoning, observation
> reliability, and parameter-specific identifiability reduce measurement error
> in cluttered multi-tree scenes and tell the user when a result is trustworthy?

## Scope

- One commodity-phone RGB photo, or unordered photos, with camera metadata;
  video and IMU are optional acquisition aids.
- Optional ARCore / ToF / LiDAR depth through the same observation contract.
- Multiple trees and partial occlusion through persistent tree identities.
- Height, DBH, crown dimensions, species evidence, volume, and uncertainty.
- A closed loop: observe -> estimate -> quantify uncertainty -> request the
  next most useful view.

## Repository status

The implemented system foundation now includes:

- versioned capture and measurement domain models;
- metric-scale estimation from explicit anchors;
- reliability-weighted robust scalar fusion;
- parameter-specific next-view guidance;
- TreeFactor v0, a project-owned joint robust optimizer for metric scale,
  height, DBH, taper, root, axis, and local covariance;
- crown dimensions/volume, provenance-locked forestry equations, multi-organ
  species evidence fusion, and fail-closed quality decisions;
- leakage-safe evaluation, frozen split protocols, resumable run journals, and
  controlled synthetic fault-injection ablations;
- an optional FastAPI service and executable unit tests;
- a research and data-collection protocol.

Existing segmentation, depth, reconstruction, and recognition models enter
through typed evidence-provider contracts. They are treated as replaceable
observation providers, never as the claimed novelty.

See `docs/system_readiness.md` for the exact boundary between implemented
functionality and conclusions that remain blocked on inspected field data.
See `docs/model_strategy.md` for the selected model roles and the precise
boundary between pretrained components and project-owned novelty.
See `docs/research/complex-scene-rgb-literature-2026-09.md` for the primary
papers, the current scientific hypothesis, and its falsification experiment.
See `docs/end_to_end.md` for the complete staged command sequence.

The selected external validation suite is GreenLens ARCore v2, WHU-STree 2026,
and the Quebec 98-tree destructive-volume release. Their non-overlapping roles,
truth provenance, and claim limits are recorded in
`docs/datasets/selected-benchmarks-1-3-6.md`. Dataset downloads are checksum
verified; request-gated WHU-STree data is never treated as locally available
until its received release passes `treeweaver inspect-whu-stree`.

Run the complete fail-closed workflow from one committed configuration with:

```powershell
treeweaver run-full configs\full-run.local.json
```

Start from `configs/full-run.example.json`. No dataset is downloaded by this
command; it consumes only the capture and model worker explicitly named in the
configuration.

## Quick start

Requires Python 3.11 or newer.

```powershell
cd D:\TreeWeaver
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev,api,vision]"
python -m unittest discover -s tests -v
uvicorn treeweaver.api.app:app --reload
```

Run the data-free geometry stress test with:

```powershell
treeweaver simulate-ablation reports\synthetic-ablation.json --seeds 3
```

After installing the selected extras, the complete test suite can also be run
without activating the environment by setting the source path explicitly:

```powershell
$env:PYTHONPATH = "D:\TreeWeaver\src"
python -m unittest discover -s tests -v
```

## Clean-room rule

`D:\SAM3DepthPro` is read-only legacy input. Do not import modules from it at
runtime and do not copy its model caches, generated outputs, Android signing
keys, or hard-coded device calibration. Reusable assets must first be recorded
in `docs/legacy_asset_register.md`, checked for license and provenance, and
then exposed through a new adapter.

See `docs/architecture.md` and `docs/research_plan.md` for the build sequence.
See `docs/treefactor_v0.md` for the first original inference component, its
reproducible command, and the evidence still required before publication.

## Android capture

`android-capture` is a standalone CameraX application with no ARCore library.
It records video, timestamped IMU data, camera calibration metadata, device
capabilities, and an explicit scale anchor. Build it with JDK 17:

```powershell
$env:JAVA_HOME = "path-to-jdk-17"
cd D:\TreeWeaver\android-capture
.\gradlew.bat assembleDebug
```

The debug APK is generated at
`android-capture/app/build/outputs/apk/debug/app-debug.apk`.

## Ingest a phone capture

Copy one complete session directory from the phone without renaming its files,
then run:

```powershell
cd D:\TreeWeaver
.venv\Scripts\treeweaver.exe ingest-raw D:\captures\<session>\capture.json D:\TreeWeaver\data\interim
.venv\Scripts\treeweaver.exe validate-capture D:\TreeWeaver\data\interim\<session>\capture.json
```

Ingestion decodes the video, samples quality-analysis frames, maps Camera2
intrinsics through the recording crop, checks IMU clock overlap, and preserves
provenance. Detecting the physical scale object in the reconstructed scene is a
separate auditable geometry step; `register-marker` now detects and triangulates
the recorded ArUco marker into TreeFactor anchors. The importer itself never
invents reconstructed length.
