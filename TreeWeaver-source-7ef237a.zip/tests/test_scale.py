import unittest

from treeweaver.calibration.scale import estimate_metric_scale
from treeweaver.domain.models import ScaleAnchor


class ScaleEstimationTests(unittest.TestCase):
    def test_requires_explicit_anchor(self) -> None:
        with self.assertRaises(ValueError):
            estimate_metric_scale(())

    def test_rejects_large_outlier(self) -> None:
        anchors = (
            ScaleAnchor("marker", 1.0, 2.0, 1.0),
            ScaleAnchor("camera_height", 1.5, 3.0, 0.9),
            ScaleAnchor("bad_user_height", 1.7, 0.5, 0.2),
        )
        result = estimate_metric_scale(anchors)
        self.assertAlmostEqual(result.metres_per_unit, 0.5, places=6)
        self.assertEqual(result.inlier_count, 2)


if __name__ == "__main__":
    unittest.main()
