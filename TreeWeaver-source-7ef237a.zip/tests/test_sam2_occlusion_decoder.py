"""Run with a PyTorch worker Python; the core project's runtime stays torch-free."""

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("transformers")

from transformers.models.sam2.configuration_sam2 import Sam2MaskDecoderConfig  # noqa: E402
from transformers.models.sam2.modeling_sam2 import Sam2MaskDecoder  # noqa: E402

MODEL_DIRECTORY = Path(__file__).resolve().parents[1] / "workers" / "tree_models"
sys.path.insert(0, str(MODEL_DIRECTORY))
SPEC = importlib.util.spec_from_file_location(
    "sam2_occlusion",
    MODEL_DIRECTORY / "sam2_occlusion.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def decoder_config(**overrides):
    values = dict(
        hidden_size=32,
        num_attention_heads=2,
        num_hidden_layers=1,
        mlp_dim=64,
        attention_downsample_rate=2,
        num_multimask_outputs=3,
        iou_head_depth=2,
        iou_head_hidden_dim=32,
    )
    values.update(overrides)
    return Sam2MaskDecoderConfig(**values)


def inputs():
    torch.manual_seed(11)
    batch, prompts, channels, size = 1, 2, 32, 8
    image = torch.randn(batch, channels, size, size)
    positions = torch.randn(batch, channels, size, size)
    sparse = torch.randn(batch, prompts, 2, channels)
    dense = torch.randn(batch, channels, size, size)
    high_resolution = [
        torch.randn(batch, channels // 8, size * 4, size * 4),
        torch.randn(batch, channels // 4, size * 2, size * 2),
    ]
    return image, positions, sparse, dense, high_resolution


def call(decoder, multimask=False):
    image, positions, sparse, dense, high_resolution = inputs()
    return decoder(
        image_embeddings=image,
        image_positional_embeddings=positions,
        sparse_prompt_embeddings=sparse,
        dense_prompt_embeddings=dense,
        multimask_output=multimask,
        high_resolution_features=high_resolution,
    )


def test_exposing_query_features_does_not_change_decoder_predictions():
    torch.manual_seed(19)
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config()).eval()
    plain = call(decoder)
    decoder.expose_query_features = True
    exposed = call(decoder)
    assert "query_pixel_embeddings" not in plain
    assert exposed["query_pixel_embeddings"].shape[:3] == (1, 2, 4)
    torch.testing.assert_close(plain["masks"], exposed["masks"], rtol=0, atol=0)


def test_query_ownership_switch_changes_only_ownership_and_keeps_parameter_shapes():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config()).eval()
    keys = set(decoder.state_dict())
    shared = call(decoder)
    decoder.query_ownership = True
    query = call(decoder)
    assert set(decoder.state_dict()) == keys
    assert not torch.allclose(shared["ownership_logits"], query["ownership_logits"])
    for key in shared:
        if key not in {"ownership", "ownership_logits"}:
            torch.testing.assert_close(shared[key], query[key], rtol=0, atol=0)


def test_outputs_have_expected_shapes_and_ranges():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6, experts=3)
    out = call(decoder)
    assert out["masks"].shape == (1, 2, 1, 32, 32)
    assert out["amodal_masks"].shape == (1, 2, 1, 32, 32)
    assert out["occluder_masks"].shape == (1, 2, 1, 32, 32)
    assert out["visibility"].shape == (1, 2, 2)
    assert out["curve"].shape == (1, 2, 6)
    assert (out["visibility"] >= 0).all() and (out["visibility"] <= 1).all()
    assert (out["curve"] >= 0).all() and (out["curve"] <= 1).all()
    torch.testing.assert_close(out["routing"].sum(-1), torch.ones(1, 2))
    assert out["ownership_logits"].shape == (1, 3, 32, 32)
    torch.testing.assert_close(out["ownership"].sum(1), torch.ones(1, 32, 32))
    assert out["layer_logits"].shape == (1, 2, 2)
    torch.testing.assert_close(out["layer_logits"], -out["layer_logits"].transpose(1, 2))


def test_amodal_contains_modal_and_starts_nearly_equal():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6)
    out = call(decoder)
    difference = out["amodal_masks"] - out["masks"]
    assert (difference >= 0).all()
    # Near-zero residual at initialisation; the decoder starts as SAM2 modal.
    assert float(difference.detach().max()) < 0.01


def test_legacy_inference_ignores_untrained_stem_parameters():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6).eval()
    image, positions, sparse, dense, high_resolution = inputs()

    def predict():
        return decoder(
            image_embeddings=image,
            image_positional_embeddings=positions,
            sparse_prompt_embeddings=sparse,
            dense_prompt_embeddings=dense,
            multimask_output=False,
            high_resolution_features=high_resolution,
        )

    original = predict()
    with torch.no_grad():
        decoder.stem_token.weight.fill_(1000)
    updated = predict()
    assert decoder.extra_token_count == 4
    torch.testing.assert_close(updated["masks"], original["masks"], rtol=0, atol=0)
    torch.testing.assert_close(updated["amodal_masks"], original["amodal_masks"], rtol=0, atol=0)


def test_explicit_stem_head_has_instance_shape_and_gradient():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6, enable_stem=True)
    out = call(decoder)
    assert decoder.extra_token_count == 5
    assert out["stem_masks"].shape == (1, 2, 1, 32, 32)
    out["stem_masks"].mean().backward()
    assert torch.isfinite(decoder.stem_hypernet[-1].weight.grad).all()
    assert decoder.stem_hypernet[-1].weight.grad.abs().sum() > 0


def test_multimask_output_keeps_existing_indices():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6)
    out = call(decoder, multimask=True)
    assert out["masks"].shape == (1, 2, 3, 32, 32)
    assert out["iou_scores"].shape == (1, 2, 3)
    assert out["amodal_masks"].shape == (1, 2, 3, 32, 32)
    assert out["sam_tokens"].shape[:3] == (1, 2, 3)


def test_swapping_prompt_order_permutes_ownership_and_layer_outputs():
    torch.manual_seed(13)
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6).eval()
    image, positions, sparse, dense, high_resolution = inputs()

    def predict(prompts):
        return decoder(
            image_embeddings=image,
            image_positional_embeddings=positions,
            sparse_prompt_embeddings=prompts,
            dense_prompt_embeddings=dense,
            multimask_output=False,
            high_resolution_features=high_resolution,
        )

    original = predict(sparse)
    swapped = predict(sparse[:, [1, 0]])
    torch.testing.assert_close(swapped["masks"], original["masks"][:, [1, 0]])
    torch.testing.assert_close(
        swapped["ownership_logits"], original["ownership_logits"][:, [0, 2, 1]]
    )
    torch.testing.assert_close(
        swapped["layer_logits"], original["layer_logits"][:, [1, 0]][:, :, [1, 0]]
    )


def test_base_decoder_weights_load_with_only_new_keys_missing():
    config = decoder_config()
    base = Sam2MaskDecoder(config)
    decoder = MODULE.Sam2OcclusionMaskDecoder(config, knots=6)
    report = decoder.load_state_dict(base.state_dict(), strict=False)
    assert report.unexpected_keys == []
    assert report.missing_keys
    assert all(
        key.split(".")[0]
        in {
            "amodal_token",
            "visibility_token",
            "curve_token",
            "occluder_token",
            "amodal_hypernets",
            "occluder_hypernet",
            "stem_token",
            "stem_hypernet",
            "router",
            "visibility_mean",
            "visibility_log_variance",
            "curve_head",
            "amodal_scale",
            "ownership_projection",
            "ownership_conv",
            "ownership_bg",
            "layer_head",
            "layer_evidence",
            "layer_depth",
        }
        for key in report.missing_keys
    )


def test_new_parameters_receive_finite_gradients():
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), knots=6)
    out = call(decoder)
    loss = (
        out["amodal_masks"].mean()
        + out["visibility"].mean()
        + out["curve"].mean()
        + out["occluder_masks"].mean()
    )
    loss.backward()
    for name, parameter in decoder.named_parameters():
        if name.startswith(
            (
                "amodal_token",
                "visibility_token",
                "curve_token",
                "occluder_token",
                "amodal_hypernets",
                "visibility_mean",
                "curve_head",
            )
        ):
            assert parameter.grad is not None, name
            assert torch.isfinite(parameter.grad).all(), name


class TinyPromptEncoder(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.project = torch.nn.Linear(4, 64)
        self.dense = torch.nn.Parameter(torch.randn(1, 32, 8, 8))
        self.last_requires_grad = None

    def forward(self, *, input_boxes, **_):
        batch, prompts = input_boxes.shape[:2]
        sparse = self.project(input_boxes).reshape(batch, prompts, 2, 32)
        self.last_requires_grad = sparse.requires_grad
        return sparse, self.dense.expand(batch, -1, -1, -1)


class TinySam2(torch.nn.Module):
    """Small image-feature fixture implementing the SAM2 wrapper's real interface.

    A real attention qkv/proj path is wrapped by apply_lora and a real SAM2
    decoder consumes all three feature levels. No weights or images download.
    """

    def __init__(self):
        super().__init__()
        self.config = SimpleNamespace(mask_decoder_config=decoder_config())
        self.mask_decoder = Sam2MaskDecoder(self.config.mask_decoder_config)
        self.prompt_encoder = TinyPromptEncoder()
        self.project_rgb = torch.nn.Conv2d(3, 32, kernel_size=1)
        self.vision_encoder = torch.nn.Module()
        self.vision_encoder.backbone = torch.nn.Module()
        block = torch.nn.Module()
        block.attn = torch.nn.Module()
        block.attn.qkv = torch.nn.Linear(32, 32)
        block.attn.proj = torch.nn.Linear(32, 32)
        self.vision_encoder.backbone.blocks = torch.nn.ModuleList([block])
        self.no_memory_embedding = torch.nn.Parameter(torch.zeros(1, 1, 32))
        self.positions = torch.nn.Parameter(torch.randn(1, 32, 8, 8))
        self.backbone_feature_sizes = [(32, 32), (16, 16), (8, 8)]
        self.last_features_require_grad = None

    def get_image_features(self, pixel_values):
        coarse = self.project_rgb(torch.nn.functional.avg_pool2d(pixel_values, 4))
        attention = self.vision_encoder.backbone.blocks[0].attn
        coarse = attention.proj(torch.tanh(attention.qkv(coarse.permute(0, 2, 3, 1))))
        coarse = coarse.permute(0, 3, 1, 2)
        self.last_features_require_grad = coarse.requires_grad
        features = [
            torch.nn.functional.interpolate(coarse[:, :4], size=(32, 32)),
            torch.nn.functional.interpolate(coarse[:, :8], size=(16, 16)),
            coarse,
        ]
        return SimpleNamespace(
            fpn_hidden_states=[feature.flatten(2).permute(2, 0, 1) for feature in features]
        )

    def get_image_wide_positional_embeddings(self):
        return self.positions


def test_wrapper_lora_receives_gradients_and_updates_without_unfreezing_base():
    torch.manual_seed(23)
    model = MODULE.Sam2OcclusionModel(TinySam2(), knots=6, encoder_lora_rank=2).train()
    pixels = torch.randn(1, 3, 32, 32)
    boxes = torch.tensor([[[1.0, 2.0, 20.0, 30.0], [10.0, 3.0, 31.0, 29.0]]])
    frozen_before = {
        name: parameter.detach().clone()
        for name, parameter in model.sam2.named_parameters()
        if not parameter.requires_grad
    }
    lora_before = {
        name: parameter.detach().clone()
        for name, parameter in model.sam2.named_parameters()
        if name.endswith("lora_b")
    }
    optimizer = torch.optim.SGD((p for p in model.parameters() if p.requires_grad), lr=0.1)
    output = model(pixels, input_boxes=boxes)
    loss = output["masks"].square().mean() + output["ownership_logits"].square().mean()
    loss.backward()
    assert model.sam2.last_features_require_grad
    assert not model.sam2.prompt_encoder.last_requires_grad
    for name, parameter in model.sam2.named_parameters():
        if name.endswith("lora_b"):
            assert parameter.grad is not None, name
            assert torch.isfinite(parameter.grad).all(), name
            assert torch.count_nonzero(parameter.grad) > 0, name
        elif name in frozen_before:
            assert parameter.grad is None, name
    optimizer.step()
    for name, parameter in model.sam2.named_parameters():
        if name in lora_before:
            assert not torch.equal(parameter, lora_before[name]), name
        elif name in frozen_before:
            torch.testing.assert_close(parameter, frozen_before[name], rtol=0, atol=0)


def test_wrapper_frozen_encoder_skips_graph_and_lora_respects_inference_no_grad():
    torch.manual_seed(31)
    pixels = torch.randn(1, 3, 32, 32, requires_grad=True)
    boxes = torch.tensor([[[1.0, 2.0, 20.0, 30.0]]], requires_grad=True)
    model = MODULE.Sam2OcclusionModel(TinySam2(), knots=6).train()
    output = model(pixels, input_boxes=boxes)
    output["masks"].square().mean().backward()
    assert not model.sam2.last_features_require_grad
    assert not model.sam2.prompt_encoder.last_requires_grad
    assert pixels.grad is None
    assert boxes.grad is None
    assert any(
        parameter.grad is not None
        for parameter in model.decoder.output_hypernetworks_mlps[0].parameters()
    )

    model = MODULE.Sam2OcclusionModel(TinySam2(), knots=6, encoder_lora_rank=2).eval()
    with torch.no_grad():
        output = model(pixels, input_boxes=boxes)
    assert not model.sam2.last_features_require_grad
    assert not output["masks"].requires_grad


def test_query_features_match_shared_path_at_zero_focus_and_swap_queries():
    from encoder_adapters import PromptFocus

    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config()).eval()
    image, positions, sparse, dense, high = inputs()
    boxes = torch.tensor([[[0.0, 0.0, 512.0, 1024.0], [512.0, 0.0, 1024.0, 1024.0]]])
    focus = PromptFocus()

    def predict(strength, order):
        focus.strength.data.fill_(strength)
        features = focus([*high, image], boxes=boxes[:, order])
        return decoder(
            image_embeddings=features[-1],
            image_positional_embeddings=positions,
            sparse_prompt_embeddings=sparse[:, order],
            dense_prompt_embeddings=dense,
            multimask_output=False,
            high_resolution_features=features[:-1],
        )

    plain = call(decoder)
    zero = predict(0.0, [0, 1])
    for key in ("masks", "ownership_logits", "layer_logits"):
        torch.testing.assert_close(zero[key], plain[key], rtol=0, atol=0)
    before, after = predict(0.5, [0, 1]), predict(0.5, [1, 0])
    torch.testing.assert_close(after["masks"], before["masks"][:, [1, 0]])
    torch.testing.assert_close(after["ownership_logits"], before["ownership_logits"][:, [0, 2, 1]])
    (before["masks"].square().mean() + before["ownership_logits"].square().mean()).backward()
    assert focus.strength.grad is not None and focus.strength.grad.abs() > 0


@pytest.mark.parametrize("stem", [False, True])
def test_crown_token_outputs_and_gradients_with_or_without_stem(stem):
    decoder = MODULE.Sam2OcclusionMaskDecoder(decoder_config(), enable_stem=stem, enable_crown=True)
    out = call(decoder)
    assert decoder.extra_token_count == 5 + int(stem)
    assert out["crown_masks"].shape == out["masks"].shape
    out["crown_masks"].square().mean().backward()
    for parameter in [decoder.crown_token.weight, decoder.crown_hypernet[-1].weight]:
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all()
        assert parameter.grad.abs().sum() > 0


def test_wrapper_spatial_focus_gradients_keep_encoder_frozen():
    torch.manual_seed(41)
    model = MODULE.Sam2OcclusionModel(TinySam2(), principal_focus=True, enable_crown=True)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    model.prompt_focus.strength.requires_grad_(True)
    before = {k: v.clone() for k, v in model.sam2.state_dict().items()}
    boxes = torch.tensor([[[0.0, 0.0, 512.0, 1024.0], [512.0, 0.0, 1024.0, 1024.0]]])
    output = model(torch.randn(1, 3, 32, 32), input_boxes=boxes)
    output["masks"].square().mean().backward()
    assert model.prompt_focus.strength.grad.abs() > 0
    for key, value in model.sam2.state_dict().items():
        torch.testing.assert_close(value, before[key], rtol=0, atol=0)


class HookableTinySam2(TinySam2):
    def __init__(self):
        super().__init__()
        attention = self.vision_encoder.backbone.blocks[0].attn

        class GlobalBlock(torch.nn.Module):
            window_size = 0
            dim_out = 32

            def __init__(self):
                super().__init__()
                self.attn = attention

            def forward(self, hidden):
                return self.attn.proj(torch.tanh(self.attn.qkv(hidden)))

        self.vision_encoder.backbone.blocks[0] = GlobalBlock()

    def get_image_features(self, pixel_values):
        coarse = self.project_rgb(torch.nn.functional.avg_pool2d(pixel_values, 4))
        coarse = self.vision_encoder.backbone.blocks[0](coarse.permute(0, 2, 3, 1))
        coarse = coarse.permute(0, 3, 1, 2)
        features = [
            torch.nn.functional.interpolate(coarse[:, :4], size=(32, 32)),
            torch.nn.functional.interpolate(coarse[:, :8], size=(16, 16)),
            coarse,
        ]
        return SimpleNamespace(fpn_hidden_states=[f.flatten(2).permute(2, 0, 1) for f in features])


@pytest.mark.parametrize("include_null_token", [False, True])
def test_encoder_pf_chunked_matches_batched_and_updates_only_pf(include_null_token):
    torch.manual_seed(51)
    model = MODULE.Sam2OcclusionModel(
        HookableTinySam2(), encoder_focus_rank=4, encoder_focus_null_token=include_null_token
    ).eval()
    model.encoder_focus.adapters["0"].output.weight.data.normal_(std=0.01)
    pixels = torch.randn(2, 3, 32, 32)
    boxes = torch.tensor([[[0.0, 0.0, 512.0, 1024.0], [512.0, 0.0, 1024.0, 1024.0]]]).repeat(
        2, 1, 1
    )
    batched = model(pixels, input_boxes=boxes)
    model.encoder_focus_chunked = True
    chunked = model(pixels, input_boxes=boxes)
    torch.testing.assert_close(chunked["masks"], batched["masks"], atol=1e-5, rtol=1e-5)
    assert model.encoder_focus.context is None
    model.requires_grad_(False)
    model.encoder_focus.requires_grad_(True)
    frozen = {
        k: v.clone() for k, v in model.state_dict().items() if not k.startswith("encoder_focus.")
    }
    model(pixels, input_boxes=boxes)["masks"].square().mean().backward()
    assert model.encoder_focus.adapters["0"].output.weight.grad.abs().sum() > 0
    for k, v in model.state_dict().items():
        if k in frozen:
            torch.testing.assert_close(v, frozen[k], rtol=0, atol=0)


def test_encoder_pf_context_clears_on_encoder_failure():
    model = MODULE.Sam2OcclusionModel(HookableTinySam2(), encoder_focus_rank=4).eval()

    def fail(_pixels):
        raise RuntimeError("fixture failure")

    model.sam2.get_image_features = fail
    with pytest.raises(RuntimeError, match="fixture failure"):
        model(torch.zeros(1, 3, 32, 32), input_boxes=torch.tensor([[[0.0, 0.0, 10.0, 10.0]]]))
    assert model.encoder_focus.context is None
