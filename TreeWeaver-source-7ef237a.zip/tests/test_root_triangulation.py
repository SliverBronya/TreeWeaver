import numpy as np
import pytest

from treeweaver.association.multiview import ProjectionCamera
from treeweaver.association.root_triangulation import (
    RootPixelObservation,
    triangulate_root_anchor,
)
from treeweaver.domain.models import CameraIntrinsics
from treeweaver.reconstruction.model import CameraPose


def _camera(name: str, centre_x: float) -> ProjectionCamera:
    return ProjectionCamera(
        name,
        CameraPose(1, 1, name, np.eye(3), np.array([-centre_x, 0.0, 0.0])),
        CameraIntrinsics(900, 900, 320, 240, 640, 480),
    )


def _pixel(camera: ProjectionCamera, point: np.ndarray) -> np.ndarray:
    local = camera.pose.rotation_world_to_camera @ point + camera.pose.translation_world_to_camera
    return np.array(
        [
            camera.intrinsics.fx * local[0] / local[2] + camera.intrinsics.cx,
            camera.intrinsics.fy * local[1] / local[2] + camera.intrinsics.cy,
        ]
    )


def test_recovers_root_and_rejects_one_bad_click() -> None:
    cameras = tuple(
        _camera(name, centre)
        for name, centre in zip("abcd", (-1.2, -0.4, 0.5, 1.3), strict=True)
    )
    root = np.array([0.1, -0.2, 6.0])
    observations = [
        RootPixelObservation(camera.image_name, _pixel(camera, root)) for camera in cameras
    ]
    observations[-1] = RootPixelObservation("d", observations[-1].pixel + np.array([80.0, -50.0]))

    result = triangulate_root_anchor(cameras, tuple(observations), tree_id=7)

    np.testing.assert_allclose(result.position, root, atol=1e-8)
    assert result.inlier_images == ("a", "b", "c")
    assert result.rejected_images == ("d",)
    assert result.mean_reprojection_error_px < 1e-8
    assert result.parallax_deg > 1.5
    assert result.position_standard_deviation_units > 0


def test_rejects_negligible_camera_motion() -> None:
    cameras = (_camera("a", 0.0), _camera("b", 0.001))
    root = np.array([0.0, 0.0, 8.0])
    observations = tuple(
        RootPixelObservation(camera.image_name, _pixel(camera, root)) for camera in cameras
    )

    with pytest.raises(ValueError, match="parallax"):
        triangulate_root_anchor(cameras, observations, tree_id=1)
