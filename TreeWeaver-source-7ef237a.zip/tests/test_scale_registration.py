import unittest

import numpy as np

from treeweaver.reconstruction.model import CameraPose, Reconstruction, SparsePoint
from treeweaver.reconstruction.scale_registration import (
    AnchorCorrespondence,
    estimate_scale_from_correspondences,
    scale_reconstruction,
)


class ScaleRegistrationTests(unittest.TestCase):
    def test_fuses_anchor_correspondences_and_scales_all_geometry(self) -> None:
        correspondences = (
            AnchorCorrespondence("marker", 1.0, np.array([0, 0, 0.0]), np.array([2, 0, 0.0])),
            AnchorCorrespondence("staff", 1.5, np.array([0, 0, 0.0]), np.array([0, 3, 0.0])),
            AnchorCorrespondence("bad", 1.0, np.array([0, 0, 0.0]), np.array([0.1, 0, 0.0]), 0.1),
        )
        scale = estimate_scale_from_correspondences(correspondences)
        self.assertAlmostEqual(scale.metres_per_unit, 0.5)
        self.assertEqual(scale.inlier_count, 2)

        reconstruction = Reconstruction(
            poses=(CameraPose(1, 1, "a.jpg", np.eye(3), np.array([-2.0, 0, 0])),),
            points=(SparsePoint(1, np.array([2.0, 4.0, 6.0]), 0.5, 4),),
        )
        metric = scale_reconstruction(reconstruction, scale)
        self.assertEqual(metric.coordinate_system, "metric")
        np.testing.assert_allclose(metric.poses[0].centre_world, [1, 0, 0])
        np.testing.assert_allclose(metric.points[0].xyz, [1, 2, 3])

    def test_refuses_to_scale_metric_reconstruction_twice(self) -> None:
        metric = Reconstruction((), (), coordinate_system="metric", scale_metres_per_unit=1.0)
        scale = estimate_scale_from_correspondences(
            (AnchorCorrespondence("marker", 1, np.zeros(3), np.ones(3)),)
        )
        with self.assertRaisesRegex(ValueError, "already metric"):
            scale_reconstruction(metric, scale)


if __name__ == "__main__":
    unittest.main()
