import json
import tempfile
import unittest
from pathlib import Path

from treeweaver.calibration.scale_file import estimate_scale_file


class ScaleFileTests(unittest.TestCase):
    def test_writes_metric_scale_with_uncertainty(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            anchors = root / "anchors.json"
            anchors.write_text(
                json.dumps(
                    {
                        "schema_version": "treefactor-anchors-1.0",
                        "anchors": [
                            {
                                "kind": "edge",
                                "metric_length_m": 0.2,
                                "endpoint_a": [0, 0, 0],
                                "endpoint_b": [0.5, 0, 0],
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            output = estimate_scale_file(anchors, root / "scale.json")
            payload = json.loads(output.read_text(encoding="utf-8"))
            self.assertAlmostEqual(payload["metres_per_unit"], 0.4)
            self.assertIn("standard_deviation", payload)


if __name__ == "__main__":
    unittest.main()
